package fuzs.tooltipinsights.impl.client;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.event.v1.gui.ItemTooltipCallback;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.DescriptionLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.InternalNameLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.ModNameLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.TooltipLinesExtractor;
import fuzs.tooltipinsights.api.v1.client.handler.TooltipDescriptionsHandler;
import fuzs.tooltipinsights.api.v1.config.StyledTooltipsConfig;
import fuzs.tooltipinsights.api.v1.config.TooltipComponentsConfig;
import fuzs.tooltipinsights.api.v1.config.TooltipDescriptionMode;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.class_1293;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_9334;

public class TooltipInsightsClientDevelopment implements ClientModConstructor {
    private static final TooltipLinesExtractor<class_1293, TooltipComponentsConfig> DESCRIPTION = new DescriptionLines<>() {
        @Override
        public Stream<class_2561> getTooltipLines(class_1293 value, int maxWidth) {
            return Stream.of(class_2561.method_43470("Prevents fire and lava damage."));
        }

        @Override
        protected String getDescriptionId(class_1293 value) {
            throw new UnsupportedOperationException();
        }
    };
    private static final TooltipLinesExtractor<class_1293, TooltipComponentsConfig> MOD_NAME = new ModNameLines<>() {
        @Override
        protected class_5321<?> getResourceKey(class_1293 mobEffect) {
            return mobEffect.method_5579().method_40230().orElseThrow();
        }
    };
    private static final TooltipLinesExtractor<class_1293, TooltipComponentsConfig> INTERNAL_NAME = new InternalNameLines<>() {
        @Override
        protected class_5321<?> getResourceKey(class_1293 mobEffect) {
            return mobEffect.method_5579().method_40230().orElseThrow();
        }
    };
    private static final List<TooltipLinesExtractor<class_1293, TooltipComponentsConfig>> ITEM_SUPPLIERS = ImmutableList.of(
            DESCRIPTION,
            MOD_NAME,
            INTERNAL_NAME);

    @Override
    public void onConstructMod() {
        registerEventHandlers();
    }

    private static void registerEventHandlers() {
        ItemTooltipCallback.EVENT.register(EventPhase.LAST, new TooltipDescriptionsHandler<>(ITEM_SUPPLIERS) {
            @Override
            protected StyledTooltipsConfig<TooltipComponentsConfig> getStyleConfig() {
                TooltipComponentsConfig tooltipLines = new TooltipComponentsConfig();
                tooltipLines.afterConfigReload();
                tooltipLines.modName = tooltipLines.internalName = true;
                StyledTooltipsConfig<TooltipComponentsConfig> styleConfig = new StyledTooltipsConfig<>(tooltipLines);
                styleConfig.afterConfigReload();
                styleConfig.tooltipDescriptions = TooltipDescriptionMode.SHIFT;
                return styleConfig;
            }

            @Override
            protected Map<String, class_1293> getByDescriptionId(class_1799 itemStack, class_7225.class_7874 registries) {
                // an item can contain the same effect multiple times, so make sure to include a merge function in our collect call
                return StreamSupport.stream(itemStack.method_57825(class_9334.field_49651, class_1844.field_49274)
                                .method_57397()
                                .spliterator(), false)
                        .collect(Collectors.toMap(class_1293::method_5586,
                                Function.identity(),
                                (class_1293 o1, class_1293 o2) -> o2));
            }
        }::onItemTooltip);
    }
}
