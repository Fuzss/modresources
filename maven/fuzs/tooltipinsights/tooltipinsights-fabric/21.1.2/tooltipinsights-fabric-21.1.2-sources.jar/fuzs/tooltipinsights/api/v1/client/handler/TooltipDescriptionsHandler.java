package fuzs.tooltipinsights.api.v1.client.handler;

import fuzs.puzzleslib.api.client.event.v1.entity.player.ClientPlayerNetworkEvents;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.DescriptionLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.TooltipLinesExtractor;
import fuzs.tooltipinsights.api.v1.config.StyledTooltipsConfig;
import fuzs.tooltipinsights.api.v1.config.TooltipComponentsConfig;
import fuzs.tooltipinsights.api.v1.config.TooltipDescriptionMode;
import fuzs.tooltipinsights.impl.TooltipInsights;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2378;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_636;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_746;

public abstract class TooltipDescriptionsHandler<T, C extends TooltipComponentsConfig> {
    protected final List<TooltipLinesExtractor<T, C>> extractorList;

    public TooltipDescriptionsHandler(List<TooltipLinesExtractor<T, C>> extractorList) {
        this.extractorList = extractorList;
    }

    public void onItemTooltip(class_1799 itemStack, List<class_2561> tooltipLines, class_1792.class_9635 tooltipContext, @Nullable class_1657 player, class_1836 tooltipFlag) {
        this.modifyTooltip(itemStack, tooltipLines, tooltipContext.method_59527(), tooltipFlag);
    }

    public void onGatherTooltipComponents(class_310 minecraft, List<class_2561> tooltipLines) {
        this.modifyTooltip(class_1799.field_8037,
                tooltipLines,
                minecraft.method_1562().method_29091(),
                minecraft.field_1690.field_1827 ? class_1836.field_41071 : class_1836.field_41070);
    }

    private void modifyTooltip(class_1799 itemStack, List<class_2561> tooltipLines, class_7225.class_7874 registries, class_1836 tooltipFlag) {
        StyledTooltipsConfig<C> styleConfig = this.getStyleConfig();

        if (styleConfig.tooltipDescriptions == TooltipDescriptionMode.DISABLED) {
            return;
        }

        Map<String, T> descriptionIds = this.getByDescriptionId(itemStack, registries);

        if (!descriptionIds.isEmpty()) {
            MutableBoolean tooltipDescriptionsHint = new MutableBoolean(styleConfig.tooltipDescriptionsHint);

            for (MutableInt mutableInt = new MutableInt();
                 mutableInt.intValue() < tooltipLines.size(); mutableInt.increment()) {

                class_2561 previousComponent = tooltipLines.get(mutableInt.intValue());
                modifyTranslatableContents(previousComponent,
                        UnaryOperator.identity(),
                        (class_2588 translatableContents, UnaryOperator<class_2561> componentReplacer) -> {

                            if (descriptionIds.containsKey(translatableContents.method_11022())) {
                                T value = descriptionIds.get(translatableContents.method_11022());
                                class_2561 component = this.getValueComponent(value);

                                if (component != null) {
                                    tooltipLines.set(mutableInt.intValue(), componentReplacer.apply(component));
                                }

                                if (styleConfig.tooltipDescriptions.isActive()) {
                                    List<class_2561> list = this.getItemTooltipLines(value, styleConfig);
                                    tooltipLines.addAll(mutableInt.intValue() + 1, list);
                                    mutableInt.add(list.size());
                                    return true;
                                } else if (tooltipDescriptionsHint.isTrue()) {
                                    // make sure the view description line is only added when there will actually be a description
                                    tooltipDescriptionsHint.setFalse();
                                    styleConfig.tooltipDescriptions.processTooltipLines(itemStack,
                                            tooltipLines,
                                            tooltipFlag);
                                    return true;
                                }
                            }

                            return false;
                        });
            }
        }
    }

    protected abstract StyledTooltipsConfig<C> getStyleConfig();

    protected abstract Map<String, T> getByDescriptionId(class_1799 itemStack, class_7225.class_7874 registries);

    @Nullable
    protected class_2561 getValueComponent(T value) {
        return null;
    }

    protected List<class_2561> getItemTooltipLines(T value, StyledTooltipsConfig<C> styleConfig) {
        return TooltipLinesExtractor.getTooltipLines(this.extractorList,
                styleConfig.descriptionDecorationComponent,
                styleConfig.descriptionStyle,
                value,
                styleConfig.tooltipLines);
    }

    public static boolean modifyTranslatableContents(class_2561 component, UnaryOperator<class_2561> componentReplacer, BiPredicate<class_2588, UnaryOperator<class_2561>> contentsGatherer) {
        if (component.method_10851() instanceof class_2588 contents) {
            if (contentsGatherer.test(contents, componentReplacer)) {
                return true;
            } else {
                for (int i = 0; i < contents.method_11023().length; i++) {
                    int index = i;

                    if (contents.method_11023()[index] instanceof class_2561 previousComponent) {
                        if (modifyTranslatableContents(previousComponent, (class_2561 updatedComponent) -> {
                            contents.method_11023()[index] = updatedComponent;
                            return componentReplacer.apply(component);
                        }, contentsGatherer)) {
                            return true;
                        }
                    }
                }
            }
        }

        for (int i = 0; i < component.method_10855().size(); i++) {
            int index = i;

            class_2561 previousComponent = component.method_10855().get(index);
            if (modifyTranslatableContents(previousComponent, (class_2561 updatedComponent) -> {
                component.method_10855().set(index, updatedComponent);
                return componentReplacer.apply(component);
            }, contentsGatherer)) {
                return true;
            }
        }

        return false;
    }

    public static <T> void printMissingDescriptionWarnings(class_5321<? extends class_2378<? extends T>> registryKey, Function<class_6880.class_6883<T>, String> descriptionIdGetter) {
        if (!ModLoaderEnvironment.INSTANCE.isDevelopmentEnvironment(TooltipInsights.MOD_ID)) {
            return;
        }

        ClientPlayerNetworkEvents.LOGGED_IN.register((class_746 player, class_636 multiPlayerGameMode, class_2535 connection) -> {
            player.method_56673().method_46762(registryKey).method_42017().forEach((class_6880.class_6883<T> holder) -> {
                String translationKey = descriptionIdGetter.apply(holder);
                if (DescriptionLines.getDescriptionTranslationKey(translationKey) == null) {
                    TooltipInsights.LOGGER.warn("Missing description for {}: {}",
                            holder.method_40237(),
                            translationKey + ".desc");
                }
            });
        });
    }
}
