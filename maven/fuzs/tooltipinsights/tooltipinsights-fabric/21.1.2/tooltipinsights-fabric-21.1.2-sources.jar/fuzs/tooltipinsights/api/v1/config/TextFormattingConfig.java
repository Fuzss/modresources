package fuzs.tooltipinsights.api.v1.config;

import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.config.v3.Config;
import fuzs.puzzleslib.api.config.v3.ConfigCore;
import fuzs.puzzleslib.api.config.v3.ValueCallback;
import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_5251;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;

/**
 * @see net.minecraft.class_124
 */
public class TextFormattingConfig implements ConfigCore {
    private static final Set<class_124> TEXT_COLORS = Stream.of(class_124.values())
            .filter((class_124 formatting) -> {
                return class_5251.method_27718(formatting) != null;
            })
            .collect(Sets.toImmutableEnumSet());

    @Config(description = "Should text appear colored.")
    public boolean colored = true;
    public class_124 color;
    @Config(description = "Should text appear bold.")
    public TriState bold = TriState.DEFAULT;
    @Config(description = "Should text appear struck-through.")
    public TriState strikethrough = TriState.DEFAULT;
    @Config(description = "Should text appear with an underline.")
    public TriState underline = TriState.DEFAULT;
    @Config(description = "Should text appear italic.")
    public TriState italic = TriState.DEFAULT;

    public TextFormattingConfig() {
        this(false, class_124.field_1068);
    }

    public TextFormattingConfig(class_124 color) {
        this(true, color.method_543() ? color : null);
    }

    private TextFormattingConfig(boolean colored, class_124 color) {
        Objects.requireNonNull(color, "color is null");
        this.colored = colored;
        this.color = color;
    }

    @Override
    public void addToBuilder(ModConfigSpec.Builder builder, ValueCallback callback) {
        callback.accept(builder.comment("The text color.").defineEnum("color", this.color, TEXT_COLORS),
                v -> this.color = v);
    }

    public class_2583 getStyle() {
        class_2583 style = class_2583.field_24360;
        if (this.colored) {
            style = style.method_10977(this.color);
        }

        if (this.bold != TriState.DEFAULT) {
            style = style.method_10982(this.bold.toBoolean(false));
        }

        if (this.strikethrough != TriState.DEFAULT) {
            style = style.method_36140(this.strikethrough.toBoolean(false));
        }

        if (this.underline != TriState.DEFAULT) {
            style = style.method_30938(this.underline.toBoolean(false));
        }

        if (this.italic != TriState.DEFAULT) {
            style = style.method_10978(this.italic.toBoolean(false));
        }

        return style;
    }
}
