package fuzs.tooltipinsights.api.v1.client.gui.tooltip;

import fuzs.tooltipinsights.api.v1.config.AbstractClientConfig;
import org.apache.commons.lang3.mutable.MutableBoolean;

import java.util.ArrayList;
import java.util.List;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

public abstract class TooltipLinesExtractor<T, C extends AbstractClientConfig.TooltipComponents> {
    private final boolean supportsDecorations;

    public TooltipLinesExtractor(boolean supportsDecorations) {
        this.supportsDecorations = supportsDecorations;
    }

    /**
     * @see net.minecraft.class_8002#BACKGROUND_COLOR
     */
    public static <T, C extends AbstractClientConfig.TooltipComponents> List<class_2561> getTooltipLines(List<TooltipLinesExtractor<T, C>> extractorList, class_2561 decorationComponent, class_2583 style, T t, C tooltipComponents) {
        // This works much better in 1.21.9+ with the custom object info component which can represent an arbitrary width,
        // but here this seems like a good enough workaround.
        class_2561 indentComponent = modifyAllStyles(decorationComponent, (class_2583 styleX) -> {
            return styleX.method_36139(0xF0100010);
        });
        MutableBoolean mutableBoolean = new MutableBoolean(true);
        List<class_2561> tooltipLines = new ArrayList<>();

        for (TooltipLinesExtractor<T, C> extractor : extractorList) {
            List<class_2561> list = extractor.getTooltipLines(tooltipComponents, t).toList();

            if (extractor.supportsDecorations) {
                for (class_2561 tooltipLine : list) {
                    class_2561 component;

                    if (mutableBoolean.isTrue()) {
                        mutableBoolean.setFalse();
                        component = decorationComponent;
                    } else {
                        component = indentComponent;
                    }

                    tooltipLines.add(class_2561.method_43473().method_10852(component).method_10852(tooltipLine).method_27696(style));
                }
            } else {
                tooltipLines.addAll(list);
            }
        }

        return tooltipLines;
    }

    private static class_2561 modifyAllStyles(class_2561 component, UnaryOperator<class_2583> modifier) {
        class_5250 mutable = component.method_27661();
        mutable.method_27694(modifier);
        mutable.method_10855().replaceAll((class_2561 sibling) -> {
            return modifyAllStyles(sibling, modifier);
        });
        return mutable;
    }

    protected abstract boolean isEnabled(C tooltipComponents);

    protected abstract Stream<class_2561> getTooltipLines(T t);

    public final Stream<class_2561> getTooltipLines(C tooltipComponents, T t) {
        if (this.isEnabled(tooltipComponents)) {
            return this.getTooltipLines(t);
        } else {
            return Stream.empty();
        }
    }

    public <E extends TooltipLinesExtractor<?, ?>> E cast() {
        return (E) this;
    }
}
