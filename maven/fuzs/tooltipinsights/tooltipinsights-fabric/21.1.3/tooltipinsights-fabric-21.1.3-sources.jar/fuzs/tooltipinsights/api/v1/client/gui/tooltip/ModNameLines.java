package fuzs.tooltipinsights.api.v1.client.gui.tooltip;

import fuzs.puzzleslib.api.core.v1.ModContainer;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.tooltipinsights.api.v1.config.TooltipComponentsConfig;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5321;

public abstract class ModNameLines<T> extends TooltipLinesExtractor<T, TooltipComponentsConfig> {

    public ModNameLines() {
        super(true);
    }

    @Override
    protected boolean isEnabled(TooltipComponentsConfig tooltipComponents) {
        return tooltipComponents.modName;
    }

    @Override
    public Stream<class_2561> getTooltipLines(T value, int maxWidth) {
        class_5321<?> resourceKey = this.getResourceKey(value);
        return ModLoaderEnvironment.INSTANCE.getModContainer(resourceKey.method_29177().method_12836())
                .map(ModContainer::getDisplayName)
                .<class_2561>map((String string) -> class_2561.method_43470(string).method_27692(class_124.field_1078))
                .stream();
    }

    protected abstract class_5321<?> getResourceKey(T t);
}
