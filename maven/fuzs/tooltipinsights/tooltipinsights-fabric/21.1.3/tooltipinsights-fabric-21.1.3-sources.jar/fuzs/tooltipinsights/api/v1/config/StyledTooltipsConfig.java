package fuzs.tooltipinsights.api.v1.config;

import fuzs.puzzleslib.api.config.v3.Config;
import fuzs.puzzleslib.api.config.v3.ConfigCore;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;

public abstract class StyledTooltipsConfig<T extends TooltipComponentsConfig> implements ConfigCore {
    @Config(description = "Add descriptions and other useful information to tooltips.")
    public TooltipDescriptionMode tooltipDescriptions = TooltipDescriptionMode.ALWAYS;
    @Config(description = "Add a note on how to show descriptions when they are hidden.")
    public boolean tooltipDescriptionsHint = true;
    @Config(description = "Formatting for setting a text color and various styles for the description component.")
    final TextFormattingConfig descriptionFormatting = new TextFormattingConfig(class_124.field_1080);
    @Config(description = "Apply a fixed string before every initial description line.")
    String descriptionDecoration = " \u25C6 ";

    public class_2583 descriptionStyle;
    public class_2561 descriptionDecorationComponent;

    @Override
    public void afterConfigReload() {
        this.descriptionStyle = this.descriptionFormatting.getStyle();
        this.descriptionDecorationComponent = class_2561.method_43470(this.descriptionDecoration);
    }

    public abstract T tooltipLines();
}
