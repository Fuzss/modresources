package fuzs.tooltipinsights.api.v1.config;

import fuzs.puzzleslib.api.util.v1.CommonHelper;
import fuzs.tooltipinsights.impl.TooltipInsights;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public enum TooltipDescriptionMode {
    DISABLED {
        @Override
        public boolean isActive() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void processTooltipLines(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
            throw new UnsupportedOperationException();
        }
    },
    NEVER {
        @Override
        public boolean isActive() {
            return false;
        }

        @Override
        public void processTooltipLines(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
            // NO-OP
        }
    },
    ALWAYS {
        @Override
        public boolean isActive() {
            return true;
        }

        @Override
        public void processTooltipLines(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
            // NO-OP
        }
    },
    SHIFT {
        @Override
        public boolean isActive() {
            return CommonHelper.hasShiftDown();
        }

        @Override
        Optional<class_2561> component() {
            return Optional.of(SHIFT_COMPONENT);
        }
    },
    CONTROL {
        @Override
        public boolean isActive() {
            return CommonHelper.hasControlDown();
        }

        @Override
        Optional<class_2561> component() {
            return Optional.of(CONTROL_COMPONENT);
        }
    },
    ALT {
        @Override
        public boolean isActive() {
            return CommonHelper.hasAltDown();
        }

        @Override
        Optional<class_2561> component() {
            return Optional.of(ALT_COMPONENT);
        }
    };

    public static final class_2561 SHIFT_COMPONENT = component("tooltip.shift");
    public static final class_2561 CONTROL_COMPONENT = component("tooltip.control");
    public static final class_2561 ALT_COMPONENT = component("tooltip.alt");
    public static final String VIEW_DESCRIPTIONS_KEY = class_156.method_646("gui",
            TooltipInsights.id("tooltip.view_descriptions"));

    private static class_2561 component(String name) {
        return class_2561.method_43471(class_156.method_646("gui", TooltipInsights.id(name)))
                .method_27692(class_124.field_1076);
    }

    public abstract boolean isActive();

    Optional<class_2561> component() {
        return Optional.empty();
    }

    public void processTooltipLines(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
        class_2561 component = class_2561.method_43469(VIEW_DESCRIPTIONS_KEY, this.component().orElseThrow())
                .method_27692(class_124.field_1080);
        tooltipLines.add(this.getLineIndex(itemStack, tooltipLines, tooltipFlag), component);
    }

    private int getLineIndex(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
        int lineIndex = -1;

        if (!itemStack.method_7960() && tooltipFlag.method_8035()) {
            // add this just before the 'dev-only' tooltip lines
            class_2561 component = class_2561.method_43470(class_7923.field_41178.method_10221(itemStack.method_7909()).toString())
                    .method_27692(class_124.field_1063);
            // also this is probably the most reliable way instead of using fixes indices regarding mod interference
            lineIndex = tooltipLines.lastIndexOf(component);
        }

        if (lineIndex == -1) {
            return tooltipLines.size();
        } else {
            return lineIndex;
        }
    }
}
