package fuzs.tooltipinsights.api.v1.config;

import fuzs.puzzleslib.api.config.v3.Config;
import fuzs.puzzleslib.api.config.v3.ConfigCore;
import fuzs.puzzleslib.api.config.v3.ValueCallback;
import net.minecraft.class_124;
import net.minecraft.class_2583;
import net.minecraft.class_5251;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @see net.minecraft.class_124
 */
public class TextFormattingConfig implements ConfigCore {
    @Config(description = "Should text appear colored.")
    public boolean colored;
    public String color;
    @Config(description = "Should text appear bold.")
    public TriState bold = TriState.DEFAULT;
    @Config(description = "Should text appear struck-through.")
    public TriState strikethrough = TriState.DEFAULT;
    @Config(description = "Should text appear with an underline.")
    public TriState underline = TriState.DEFAULT;
    @Config(description = "Should text appear italic.")
    public TriState italic = TriState.DEFAULT;

    private class_5251 textColor;

    public TextFormattingConfig() {
        this(false, class_124.field_1068);
    }

    public TextFormattingConfig(class_124 color) {
        this(true, color);
    }

    private TextFormattingConfig(boolean colored, class_124 color) {
        class_5251 textColor = class_5251.method_27718(color);
        Objects.requireNonNull(textColor, "color is null");
        this.colored = colored;
        this.color = textColor.method_27721();
    }

    @Override
    public void addToBuilder(ModConfigSpec.Builder builder, ValueCallback callback) {
        callback.accept(builder.comment("The text color. Must be enabled separately.",
                "Allowed Values: " + Stream.of(class_124.values())
                        .map(class_5251::method_27718)
                        .filter(Objects::nonNull)
                        .map(class_5251::method_27721)
                        .collect(Collectors.joining(", "))).define("text_color", this.color, o -> {
            return o instanceof String s && class_5251.method_27719(s).isSuccess();
        }), v -> this.color = v);
    }

    @Override
    public void afterConfigReload() {
        this.textColor = class_5251.method_27719(this.color).getOrThrow();
    }

    public class_2583 getStyle() {
        class_2583 style = class_2583.field_24360;
        if (this.colored) {
            style = style.method_27703(this.textColor);
        }

        if (this.bold != TriState.DEFAULT) {
            style = style.method_10982(this.bold.toBoolean(false));
        }

        if (this.strikethrough != TriState.DEFAULT) {
            style = style.method_36140(this.strikethrough.toBoolean(false));
        }

        if (this.underline != TriState.DEFAULT) {
            style = style.method_30938(this.underline.toBoolean(false));
        }

        if (this.italic != TriState.DEFAULT) {
            style = style.method_10978(this.italic.toBoolean(false));
        }

        return style;
    }
}
