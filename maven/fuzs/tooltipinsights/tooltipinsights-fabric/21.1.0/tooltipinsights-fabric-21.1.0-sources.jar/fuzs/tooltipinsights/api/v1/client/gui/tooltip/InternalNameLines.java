package fuzs.tooltipinsights.api.v1.client.gui.tooltip;

import fuzs.tooltipinsights.api.v1.config.AbstractClientConfig;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5321;

public abstract class InternalNameLines<T> extends TooltipLinesExtractor<T, AbstractClientConfig.TooltipComponents> {

    public InternalNameLines() {
        super(true);
    }

    @Override
    protected boolean isEnabled(AbstractClientConfig.TooltipComponents tooltipComponents) {
        return tooltipComponents.internalName;
    }

    @Override
    protected Stream<class_2561> getTooltipLines(T t) {
        class_5321<?> resourceKey = this.getResourceKey(t);
        return Stream.of(class_2561.method_43470(resourceKey.method_29177().toString()).method_27692(class_124.field_1063));
    }

    protected abstract class_5321<?> getResourceKey(T t);
}
