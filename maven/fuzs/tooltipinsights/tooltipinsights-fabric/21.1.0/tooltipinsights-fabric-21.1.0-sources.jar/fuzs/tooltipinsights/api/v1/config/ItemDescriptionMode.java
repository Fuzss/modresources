package fuzs.tooltipinsights.api.v1.config;

import fuzs.puzzleslib.api.util.v1.CommonHelper;
import fuzs.tooltipinsights.impl.TooltipInsights;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_7923;

public enum ItemDescriptionMode {
    DISABLED {
        @Override
        public boolean isActive() {
            return false;
        }
    },
    NEVER {
        @Override
        public boolean isActive() {
            return false;
        }
    },
    SHIFT {
        @Override
        public boolean isActive() {
            return CommonHelper.hasShiftDown();
        }

        @Override
        public void processTooltipLines(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
            tooltipLines.add(this.getLineIndex(itemStack, tooltipLines, tooltipFlag), VIEW_DESCRIPTIONS_COMPONENT);
        }

        private int getLineIndex(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
            int lineIndex = -1;

            if (!itemStack.method_7960() && tooltipFlag.method_8035()) {
                // add this just before the 'dev-only' tooltip lines
                class_2561 component = class_2561.method_43470(class_7923.field_41178.method_10221(itemStack.method_7909()).toString())
                        .method_27692(class_124.field_1063);
                // also this is probably the most reliable way instead of using fixes indices regarding mod interference
                lineIndex = tooltipLines.lastIndexOf(component);
            }

            if (lineIndex == -1) {
                return tooltipLines.size();
            } else {
                return lineIndex;
            }
        }
    },
    ALWAYS {
        @Override
        public boolean isActive() {
            return true;
        }
    };

    public static final class_2561 SHIFT_COMPONENT = class_2561.method_43471(class_156.method_646("gui",
            TooltipInsights.id("tooltip.shift"))).method_27692(class_124.field_1076);
    public static final class_2561 VIEW_DESCRIPTIONS_COMPONENT = class_2561.method_43469(class_156.method_646("gui",
            TooltipInsights.id("tooltip.view_descriptions")), SHIFT_COMPONENT).method_27692(class_124.field_1080);

    public abstract boolean isActive();

    public void processTooltipLines(class_1799 itemStack, List<class_2561> tooltipLines, class_1836 tooltipFlag) {
        // NO-OP
    }
}
