package fuzs.tooltipinsights.api.v1.client.gui.component;

import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_9331;

public abstract class TooltipComponentExtractor<T, C> {
    private final class_9331<C> dataComponentType;

    public TooltipComponentExtractor(class_9331<C> dataComponentType) {
        this.dataComponentType = dataComponentType;
    }

    protected abstract boolean isEnabled();

    protected abstract Stream<T> extractFromComponent(C dataComponent);

    public Stream<T> extractFromItemStack(class_1799 itemStack) {
        if (this.isEnabled() && itemStack.method_57826(this.dataComponentType)) {
            C dataComponent = itemStack.method_57824(this.dataComponentType);
            return this.extractFromComponent(dataComponent);
        } else {
            return Stream.empty();
        }
    }
}
