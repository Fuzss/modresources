package fuzs.tooltipinsights.impl.client;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.event.v1.gui.ItemTooltipCallback;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.DescriptionLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.InternalNameLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.ModNameLines;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.TooltipLinesExtractor;
import fuzs.tooltipinsights.api.v1.client.handler.TooltipDescriptionsHandler;
import fuzs.tooltipinsights.api.v1.config.AbstractClientConfig;
import fuzs.tooltipinsights.api.v1.config.ItemDescriptionMode;
import fuzs.tooltipinsights.impl.TooltipInsights;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_9334;

public class TooltipInsightsClient implements ClientModConstructor {

    @Override
    public void onConstructMod() {
        setupDevelopmentEnvironment();
    }

    private static void setupDevelopmentEnvironment() {
        if (!ModLoaderEnvironment.INSTANCE.isDevelopmentEnvironment(TooltipInsights.MOD_ID)) return;
        ItemTooltipCallback.EVENT.register(EventPhase.LAST, new TooltipDescriptionsHandler<class_1293>() {
            static final TooltipLinesExtractor<class_1293, AbstractClientConfig.TooltipComponents> DESCRIPTION = new DescriptionLines<>() {
                @Override
                protected String getDescriptionId(class_1293 mobEffect) {
                    return mobEffect.method_5586();
                }
            };
            static final TooltipLinesExtractor<class_1293, AbstractClientConfig.TooltipComponents> MOD_NAME = new ModNameLines<>() {
                @Override
                protected class_5321<?> getResourceKey(class_1293 mobEffect) {
                    return mobEffect.method_5579().method_40230().orElseThrow();
                }
            };
            static final TooltipLinesExtractor<class_1293, AbstractClientConfig.TooltipComponents> INTERNAL_NAME = new InternalNameLines<>() {
                @Override
                protected class_5321<?> getResourceKey(class_1293 mobEffect) {
                    return mobEffect.method_5579().method_40230().orElseThrow();
                }
            };
            static final List<TooltipLinesExtractor<class_1293, AbstractClientConfig.TooltipComponents>> ITEM_SUPPLIERS = ImmutableList.of(
                    DESCRIPTION,
                    MOD_NAME,
                    INTERNAL_NAME);

            @Override
            protected ItemDescriptionMode getItemDescriptionMode() {
                return ItemDescriptionMode.SHIFT;
            }

            @Override
            protected Map<String, class_1293> getByDescriptionId(class_1799 itemStack, class_7225.class_7874 registries) {
                // an item can contain the same effect multiple times, so make sure to include a merge function in our collect call
                return StreamSupport.stream(itemStack.method_57825(class_9334.field_49651, class_1844.field_49274)
                                .method_57397()
                                .spliterator(), false)
                        .collect(Collectors.toMap(class_1293::method_5586,
                                Function.identity(),
                                (class_1293 o1, class_1293 o2) -> o1));
            }

            @Override
            protected List<class_2561> getItemTooltipLines(class_1293 mobEffectInstance) {
                return TooltipLinesExtractor.getTooltipLines(ITEM_SUPPLIERS,
                        class_2561.method_43470(" \u25C6 "),
                        class_2583.field_24360.method_27706(class_124.field_1080),
                        mobEffectInstance,
                        class_156.method_654(new AbstractClientConfig.TooltipComponents(),
                                (AbstractClientConfig.TooltipComponents tooltipComponents) -> {
                                    tooltipComponents.modName = tooltipComponents.internalName = true;
                                }));
            }
        }::onItemTooltip);
    }
}
