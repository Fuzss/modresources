package fuzs.tooltipinsights.api.v1.client.handler;

import fuzs.puzzleslib.api.client.event.v1.entity.player.ClientPlayerNetworkEvents;
import fuzs.tooltipinsights.api.v1.client.gui.tooltip.DescriptionLines;
import fuzs.tooltipinsights.api.v1.config.ItemDescriptionMode;
import fuzs.tooltipinsights.impl.TooltipInsights;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.function.BiPredicate;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2378;
import net.minecraft.class_2535;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_636;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_746;

public abstract class TooltipDescriptionsHandler<T> {

    public void onItemTooltip(class_1799 itemStack, List<class_2561> tooltipLines, class_1792.class_9635 tooltipContext, @Nullable class_1657 player, class_1836 tooltipFlag) {
        this.modifyTooltip(itemStack, tooltipLines, tooltipContext.method_59527(), tooltipFlag);
    }

    public void onGatherTooltipComponents(class_310 minecraft, List<class_2561> tooltipLines) {
        this.modifyTooltip(class_1799.field_8037,
                tooltipLines,
                minecraft.method_1562().method_29091(),
                minecraft.field_1690.field_1827 ? class_1836.field_41071 : class_1836.field_41070);
    }

    private void modifyTooltip(class_1799 itemStack, List<class_2561> tooltipLines, class_7225.class_7874 registries, class_1836 tooltipFlag) {
        ItemDescriptionMode itemDescriptionMode = this.getItemDescriptionMode();

        if (itemDescriptionMode == ItemDescriptionMode.NEVER && !itemDescriptionMode.isActive()) {
            return;
        }

        Map<String, T> descriptionIds = this.getByDescriptionId(itemStack, registries);

        if (!descriptionIds.isEmpty()) {
            MutableBoolean mutableBoolean = new MutableBoolean(true);

            for (MutableInt mutableInt = new MutableInt();
                 mutableInt.intValue() < tooltipLines.size(); mutableInt.increment()) {

                modifyTranslatableContents(tooltipLines.get(mutableInt.intValue()),
                        UnaryOperator.identity(),
                        (class_2588 translatableContents, UnaryOperator<class_2561> componentReplacer) -> {

                            if (descriptionIds.containsKey(translatableContents.method_11022())) {
                                T t = descriptionIds.get(translatableContents.method_11022());
                                class_2561 component = this.getValueComponent(t);

                                if (component != null) {
                                    tooltipLines.set(mutableInt.intValue(), componentReplacer.apply(component));
                                }

                                if (itemDescriptionMode.isActive()) {
                                    List<class_2561> list = this.getItemTooltipLines(t);
                                    tooltipLines.addAll(mutableInt.intValue() + 1, list);
                                    mutableInt.add(list.size());
                                    return true;
                                } else if (mutableBoolean.isTrue()) {
                                    // make sure the view description line is only added when there will actually be a description
                                    mutableBoolean.setFalse();
                                    itemDescriptionMode.processTooltipLines(itemStack, tooltipLines, tooltipFlag);
                                    return true;
                                }
                            }

                            return false;
                        });
            }
        }
    }

    protected abstract ItemDescriptionMode getItemDescriptionMode();

    protected abstract Map<String, T> getByDescriptionId(class_1799 itemStack, class_7225.class_7874 registries);

    @Nullable
    protected class_2561 getValueComponent(T t) {
        return null;
    }

    protected abstract List<class_2561> getItemTooltipLines(T t);

    public static boolean modifyTranslatableContents(class_2561 component, UnaryOperator<class_2561> componentReplacer, BiPredicate<class_2588, UnaryOperator<class_2561>> contentsGatherer) {
        if (component.method_10851() instanceof class_2588 translatableContents) {
            if (contentsGatherer.test(translatableContents, componentReplacer)) {
                return true;
            } else {
                for (int i = 0; i < translatableContents.method_11023().length; i++) {
                    int index = i;

                    if (translatableContents.method_11023()[index] instanceof class_2561 componentArg) {
                        if (modifyTranslatableContents(componentArg, (class_2561 componentX) -> {
                            translatableContents.method_11023()[index] = componentX;
                            return componentReplacer.apply(component);
                        }, contentsGatherer)) {
                            return true;
                        }
                    }
                }
            }
        }

        for (int i = 0; i < component.method_10855().size(); i++) {
            int index = i;

            if (modifyTranslatableContents(component.method_10855().get(index), (class_2561 componentX) -> {
                component.method_10855().set(index, componentX);
                return componentReplacer.apply(component);
            }, contentsGatherer)) {
                return true;
            }
        }

        return false;
    }

    public static <T> void printMissingDescriptionWarnings(class_5321<? extends class_2378<? extends T>> registryKey, Function<class_6880.class_6883<T>, String> descriptionIdGetter) {
        ClientPlayerNetworkEvents.LOGGED_IN.register((class_746 player, class_636 multiPlayerGameMode, class_2535 connection) -> {
            player.method_56673().method_46762(registryKey).method_42017().forEach((class_6880.class_6883<T> holder) -> {
                String translationKey = descriptionIdGetter.apply(holder);
                if (DescriptionLines.getDescriptionTranslationKey(translationKey) == null) {
                    TooltipInsights.LOGGER.warn("Missing description for {}: {}",
                            holder.method_40237(),
                            translationKey + ".desc");
                }
            });
        });
    }
}
