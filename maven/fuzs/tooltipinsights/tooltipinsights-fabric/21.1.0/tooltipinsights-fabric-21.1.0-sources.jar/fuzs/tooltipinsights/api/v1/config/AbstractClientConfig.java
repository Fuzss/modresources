package fuzs.tooltipinsights.api.v1.config;

import fuzs.puzzleslib.api.config.v3.Config;
import fuzs.puzzleslib.api.config.v3.ConfigCore;
import fuzs.puzzleslib.api.util.v1.ComponentHelper;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;

public abstract class AbstractClientConfig implements ConfigCore {
    protected static final String FORMATTING_CODES_DESCRIPTION_LINK = "https://minecraft.wiki/w/Formatting_codes";

    public static abstract class StyledTooltips implements ConfigCore {
        @Config(description = {
                "Apply a fixed string before every description line.",
                "Supports formatting codes which will also apply to the description for setting custom text colors and styles.",
                FORMATTING_CODES_DESCRIPTION_LINK
        })
        String tooltipLineDecorations = ComponentHelper.getAsString(class_2561.method_43470(" \u25C6 ")
                .method_27692(class_124.field_1080));

        public class_2561 decorationComponent;
        public class_2583 decorationStyle;

        @Override
        public void afterConfigReload() {
            this.decorationComponent = ComponentHelper.getAsComponent(this.tooltipLineDecorations);
            this.decorationStyle = ComponentHelper.getDefaultStyle(this.tooltipLineDecorations);
        }
    }

    /**
     * TODO rename field to advancedTooltips and merge class into StyledTooltips
     */
    public static abstract class ItemTooltips extends StyledTooltips {
        @Config(description = "Add descriptions and other useful information to tooltips.")
        public ItemDescriptionMode itemDescriptions = ItemDescriptionMode.ALWAYS;
    }

    public static class TooltipComponents implements ConfigCore {
        @Config(description = "Add the description to tooltips.")
        public boolean valueDescription = true;
        @Config(description = "Add the name of the source mod to tooltips.")
        public boolean modName = false;
        @Config(description = "Add the internal id to tooltips.")
        public boolean internalName = false;
    }
}
