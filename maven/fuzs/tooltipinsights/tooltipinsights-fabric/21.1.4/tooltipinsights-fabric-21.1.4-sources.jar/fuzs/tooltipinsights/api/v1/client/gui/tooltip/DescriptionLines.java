package fuzs.tooltipinsights.api.v1.client.gui.tooltip;

import fuzs.puzzleslib.api.client.gui.v2.tooltip.ClientComponentSplitter;
import fuzs.puzzleslib.api.util.v1.ComponentHelper;
import fuzs.tooltipinsights.api.v1.config.TooltipComponentsConfig;
import org.jetbrains.annotations.Nullable;

import java.util.stream.Stream;
import net.minecraft.class_2477;
import net.minecraft.class_2561;

public abstract class DescriptionLines<T> extends TooltipLinesExtractor<T, TooltipComponentsConfig> {

    public DescriptionLines() {
        super(true);
    }

    @Override
    protected final boolean isEnabled(TooltipComponentsConfig tooltipComponents) {
        return tooltipComponents.valueDescription;
    }

    @Override
    public Stream<class_2561> getTooltipLines(T value, int maxWidth) {
        String descriptionKey = getDescriptionTranslationKey(this.getDescriptionId(value));
        if (descriptionKey != null) {
            return ClientComponentSplitter.splitTooltipLines(maxWidth, class_2561.method_43471(descriptionKey))
                    .map(ComponentHelper::getAsComponent);
        } else {
            return Stream.empty();
        }
    }

    public static @Nullable String getDescriptionTranslationKey(String translationKey) {
        if (class_2477.method_10517().method_4678(translationKey + ".desc")) {
            // our own format, similar to Enchantment Descriptions mod format
            return translationKey + ".desc";
        } else if (class_2477.method_10517().method_4678(translationKey + ".description")) {
            // Just Enough Effect Descriptions mod format
            return translationKey + ".description";
        } else if (class_2477.method_10517().method_4678("description." + translationKey)) {
            // Potion Descriptions mod format
            return "description." + translationKey;
        } else {
            return null;
        }
    }

    protected abstract String getDescriptionId(T value);
}
