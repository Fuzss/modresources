# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v26.3.2-mc26.3.x] - 2026-09-27

### Changed

- Collect possible names as `ComponentContents` not `Component`

## [v26.3.1-mc26.3.x] - 2026-09-26

### Changed

- Pass the original name component to `TooltipDescriptionsHandler::getNameComponent`

## [v26.3.0-mc26.3.x] - 2026-09-20

### Changed

- Update to Minecraft 26.3.x
