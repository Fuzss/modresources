package fuzs.tooltipinsights.common.api.v1.config;

import fuzs.puzzleslib.common.api.config.v3.Config;
import fuzs.puzzleslib.common.api.config.v3.ConfigCore;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;

public abstract class StyledTooltipsConfig<T extends TooltipComponentsConfig> implements ConfigCore {
    @Config(description = "Add descriptions and other useful information to tooltips.")
    public TooltipDescriptionMode tooltipDescriptions = TooltipDescriptionMode.ALWAYS;
    @Config(description = "Add a note on how to show descriptions when they are hidden.")
    public boolean tooltipDescriptionsHint = true;
    @Config(description = "Formatting for setting a text color and various styles for the description component.")
    final TextFormattingConfig descriptionFormatting = new TextFormattingConfig(TextColor.GRAY);
    @Config(description = "Apply a fixed string before every initial description line.")
    String descriptionDecoration = " \u25C6 ";

    public Style descriptionStyle;
    public Component descriptionDecorationComponent;

    @Override
    public void afterConfigReload() {
        this.descriptionStyle = this.descriptionFormatting.getStyle();
        this.descriptionDecorationComponent = Component.literal(this.descriptionDecoration);
    }

    public abstract T tooltipLines();
}
