package fuzs.tooltipinsights.neoforge.impl.client;

import fuzs.puzzleslib.common.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.common.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.neoforge.api.data.v3.core.DataProviderBuilder;
import fuzs.tooltipinsights.common.impl.TooltipInsights;
import fuzs.tooltipinsights.common.impl.client.TooltipInsightsClient;
import fuzs.tooltipinsights.common.impl.client.TooltipInsightsClientDevelopment;
import fuzs.tooltipinsights.common.impl.data.client.ModLanguageProvider;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;

@Mod(value = TooltipInsights.MOD_ID, dist = Dist.CLIENT)
public class TooltipInsightsNeoForgeClient {

    public TooltipInsightsNeoForgeClient() {
        ClientModConstructor.construct(TooltipInsights.MOD_ID, TooltipInsightsClient::new);
        if (ModLoaderEnvironment.INSTANCE.isDevelopmentEnvironmentWithoutDataGeneration(TooltipInsights.MOD_ID)) {
            ClientModConstructor.construct(TooltipInsights.id("client/development"),
                    TooltipInsightsClientDevelopment::new);
        }

        DataProviderBuilder.of(TooltipInsights.MOD_ID).addProvider(ModLanguageProvider::new);
    }
}
