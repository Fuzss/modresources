# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v21.1.2-1.21.1] - 2026-06-26

### Added

- Add a config option for controlling the maximum description width
- Add a config option controlling the tooltip hint for revealing descriptions

### Changed

- Refactor text style options, so they no longer rely on defining legacy chat formatting codes
- Rename some other config options

## [v21.1.1-1.21.1] - 2026-05-20

### Fixed

- Fix indent component style not being properly set to black

## [v21.1.0-1.21.1] - 2026-05-20

### Changed

- Update to Minecraft 1.21.1
