package fuzs.diagonalblocks.common.impl.handler;

import com.google.common.collect.BiMap;
import fuzs.diagonalblocks.common.api.v2.block.type.DiagonalBlockType;
import fuzs.diagonalblocks.common.impl.DiagonalBlocks;
import fuzs.diagonalblocks.common.impl.config.CommonConfig;
import fuzs.diagonalblocks.common.impl.config.ServerConfig;
import fuzs.puzzleslib.common.api.block.v1.BlockConversionHelper;
import fuzs.puzzleslib.common.api.event.v1.RegistryEntryAddedCallback;
import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Registry;
import net.minecraft.core.RegistryAccess;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.ReloadableServerResources;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LevelEvent;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.BlockHitResult;

import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

public class DiagonalBlockHandler {

    public static RegistryEntryAddedCallback<Block> onBlockAdded(DiagonalBlockType type) {
        return (Registry<Block> registry, Identifier id, Block entry, BiConsumer<Identifier, Supplier<Block>> registrar) -> {
            if (type.isTarget(id, entry)) {
                Identifier identifier = type.id(id.getNamespace() + "/" + id.getPath());
                registrar.accept(identifier, () -> {
                    return type.makeDiagonalBlock(id, entry);
                });
            }
        };
    }

    public static EventResultHolder<InteractionResult> onUseBlock(Player player, Level level, InteractionHand interactionHand, BlockHitResult hitResult) {
        if (!DiagonalBlocks.CONFIG.get(ServerConfig.class).swapBlocksByInteracting) {
            return EventResultHolder.pass();
        }

        // allow for toggling between diagonal and non-diagonal block variants via shift+right-clicking with empty hand
        if (player.isSecondaryUseActive() && player.getItemInHand(interactionHand).isEmpty()) {
            BlockPos blockPos = hitResult.getBlockPos();
            BlockState blockState = level.getBlockState(blockPos);
            for (DiagonalBlockType type : DiagonalBlockType.TYPES) {
                if (!type.supportsOriginalBlockState() && !blockState.is(type.getBlacklistTagKey())) {
                    Block newBlock;
                    Block block = blockState.getBlock();
                    if (type.getBlockConversions().containsKey(block)) {
                        newBlock = type.getBlockConversions().get(block);
                    } else if (type.getBlockConversions().containsValue(block)) {
                        newBlock = type.getBlockConversions().inverse().get(block);
                    } else {
                        newBlock = null;
                    }

                    if (newBlock != null) {
                        BlockState newBlockState = newBlock.withPropertiesOf(blockState);
                        newBlockState = Block.updateFromNeighbourShapes(newBlockState, level, blockPos);
                        level.setBlock(blockPos, newBlockState, 3);
                        level.neighborChanged(blockPos, newBlock, null);
                        level.gameEvent(GameEvent.BLOCK_CHANGE, blockPos, GameEvent.Context.of(player, newBlockState));
                        level.levelEvent(player, LevelEvent.PARTICLES_AND_SOUND_WAX_ON, blockPos, 0);
                        return EventResultHolder.interrupt(InteractionResult.SUCCESS);
                    }
                }
            }
        }

        return EventResultHolder.pass();
    }

    public static void onServerResourcesLoad(ReloadableServerResources serverResources, RegistryAccess registries) {
        onTagsUpdated(registries);
    }

    public static void onTagsUpdated(RegistryAccess registries) {
        if (DiagonalBlocks.CONFIG.get(CommonConfig.class).diagonalBlocksByDefault) {
            for (Map.Entry<ResourceKey<Item>, Item> entry : BuiltInRegistries.ITEM.entrySet()) {
                if (entry.getValue() instanceof BlockItem blockItem) {
                    Block block = blockItem.getBlock();
                    setItemForBlock(entry.getKey().identifier(), blockItem, block);
                    setBlockForItem(blockItem, block);
                }
            }
        }

        for (DiagonalBlockType type : DiagonalBlockType.TYPES) {
            type.getBlockConversions().forEach(BlockConversionHelper::copyBoundTags);
        }
    }

    private static void setItemForBlock(Identifier identifier, BlockItem blockItem, Block block) {
        for (DiagonalBlockType type : DiagonalBlockType.TYPES) {
            // item id should be fine to use for block items
            if (type.isTarget(identifier, block)) {
                BlockConversionHelper.setItemForBlock(type.getBlockConversions().get(block), blockItem);
                break;
            }
        }
    }

    private static void setBlockForItem(BlockItem blockItem, Block block) {
        for (DiagonalBlockType type : DiagonalBlockType.TYPES) {
            BiMap<Block, Block> conversions = type.getBlockConversions();
            Block baseBlock;
            Block diagonalBlock = conversions.get(block);
            if (diagonalBlock != null) {
                baseBlock = block;
            } else {
                baseBlock = conversions.inverse().get(block);
                if (baseBlock != null) {
                    diagonalBlock = block;
                } else {
                    continue;
                }
            }

            if (baseBlock.builtInRegistryHolder().is(type.getBlacklistTagKey())) {
                BlockConversionHelper.setBlockForItem(blockItem, baseBlock);
            } else {
                BlockConversionHelper.setBlockForItem(blockItem, diagonalBlock);
            }

            break;
        }
    }
}
