# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v26.1.2-mc26.1.x] - 2026-04-21

### Fixed

- Publish correct 26.1.x class tweaker file

## [v26.1.1-mc26.1.x] - 2026-04-15

### Fixed

- Fix Maven publication module metadata

## [v26.1.0-mc26.1.x] - 2026-04-14

### Changed

- Update to Minecraft 26.1.x
@