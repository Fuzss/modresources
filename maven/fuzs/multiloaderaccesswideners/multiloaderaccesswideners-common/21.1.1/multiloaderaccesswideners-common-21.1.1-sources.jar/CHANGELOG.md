# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v21.1.1-1.21.1] - 2025-12-10

### Changed

- Use Multiloader Convention Plugins v1.1

## [v21.1.0-1.21.1] - 2025-12-10

### Changed

- Update to Minecraft 1.21.1
