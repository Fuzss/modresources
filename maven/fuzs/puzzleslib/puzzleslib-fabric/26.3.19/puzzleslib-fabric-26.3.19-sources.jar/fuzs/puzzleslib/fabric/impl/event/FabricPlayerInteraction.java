package fuzs.puzzleslib.fabric.impl.event;

import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.common.api.network.v4.MessageSender;
import fuzs.puzzleslib.fabric.impl.core.FabricProxy;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;

public interface FabricPlayerInteraction {
    FabricPlayerInteraction USE_BLOCK = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(InteractionResult interactionResult) {
            return interactionResult != InteractionResult.SUCCESS;
        }

        @Override
        public void sendServerboundPacket(Player player, Level level, InteractionHand interactionHand, @Nullable Entity entity, @Nullable HitResult hitResult) {
            Objects.requireNonNull(hitResult, "hit result is null");
            FabricProxy.get()
                    .startClientPrediction(level,
                            (int id) -> new ServerboundUseItemOnPacket(interactionHand,
                                    (BlockHitResult) hitResult,
                                    id));
        }
    };
    FabricPlayerInteraction USE_ITEM = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(InteractionResult interactionResult) {
            return interactionResult != InteractionResult.SUCCESS;
        }

        @Override
        public void sendServerboundPacket(Player player, Level level, InteractionHand interactionHand, @Nullable Entity entity, @Nullable HitResult hitResult) {
            // send the interaction packet to the server with a new sequentially assigned id
            FabricProxy.get()
                    .startClientPrediction(level,
                            (int id) -> new ServerboundUseItemPacket(interactionHand,
                                    id,
                                    player.getYRot(),
                                    player.getXRot()));
        }
    };
    FabricPlayerInteraction USE_ENTITY = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(InteractionResult interactionResult) {
            return !interactionResult.consumesAction();
        }

        @Override
        public void sendServerboundPacket(Player player, Level level, InteractionHand interactionHand, @Nullable Entity entity, @Nullable HitResult hitResult) {
            Objects.requireNonNull(entity, "entity is null");
            Objects.requireNonNull(hitResult, "hit result is null");
            MessageSender.broadcast(new ServerboundInteractPacket(entity.getId(),
                    interactionHand,
                    hitResult.getLocation(),
                    player.isShiftKeyDown()));
        }
    };

    default InteractionResult getHandledInteractionResult(EventResultHolder<InteractionResult> eventResult, Player player, Level level, InteractionHand interactionHand, @Nullable Entity entity, @Nullable HitResult hitResult) {
        Optional<InteractionResult> optional = eventResult.getInterrupt();
        if (optional.isPresent()) {
            InteractionResult interactionResult = optional.get();
            if (level.isClientSide() && this.sendServerboundPacket(interactionResult)) {
                // vanilla always ensures the carried item has been sent before notifying the server of an interaction,
                // but Fabric API injects before that point, so replicate it here for parity with NeoForge
                FabricProxy.get().ensureHasSentCarriedItem();
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult,
                // as the Forge event runs after the server packet is sent
                this.sendServerboundPacket(player, level, interactionHand, entity, hitResult);
            }

            return this.finalizeInteraction(interactionResult, player, interactionHand);
        } else {
            return InteractionResult.PASS;
        }
    }

    boolean sendServerboundPacket(InteractionResult interactionResult);

    void sendServerboundPacket(Player player, Level level, InteractionHand interactionHand, @Nullable Entity entity, @Nullable HitResult hitResult);

    default InteractionResult finalizeInteraction(InteractionResult interactionResult, Player player, InteractionHand interactionHand) {
        // this is done for parity with Forge where InteractionResult#PASS can be cancelled,
        // while on Fabric it will mark the event as having done nothing
        // unfortunately this will prevent the off-hand from being processed (if fired for the main hand),
        // but it's the best we can do
        return interactionResult != InteractionResult.PASS ? interactionResult : InteractionResult.FAIL;
    }
}
