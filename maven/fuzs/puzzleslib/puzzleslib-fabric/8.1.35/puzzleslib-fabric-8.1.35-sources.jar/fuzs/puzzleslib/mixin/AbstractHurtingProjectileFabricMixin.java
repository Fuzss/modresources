package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricEntityEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1668;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1668.class)
abstract class AbstractHurtingProjectileFabricMixin extends class_1676 {
    @Unique
    @Nullable
    private class_239 puzzleslib$originalHitResult;

    public AbstractHurtingProjectileFabricMixin(class_1299<? extends class_1676> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "tick", at = @At(value = "LOAD", ordinal = 0), ordinal = 0)
    public class_239 tick$0(class_239 hitResult) {
        if (hitResult.method_17783() == class_239.class_240.field_1333) return hitResult;
        if (FabricEntityEvents.PROJECTILE_IMPACT.invoker().onProjectileImpact(this, hitResult).isInterrupt()) {
            this.puzzleslib$originalHitResult = hitResult;
            // just a dummy to prevent Projectile::onHit from being called
            // we don't implement this by overriding Projectile::onHit as this is an abstract class where Projectile::onHit will likely be overridden by subclasses
            return class_3965.method_17778(hitResult.method_17784(), class_2350.field_11043, class_2338.method_49638(hitResult.method_17784()));
        } else {
            this.puzzleslib$originalHitResult = null;
            return hitResult;
        }
    }

    @ModifyVariable(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/AbstractHurtingProjectile;checkInsideBlocks()V", shift = At.Shift.BEFORE), ordinal = 0)
    public class_239 tick$1(class_239 hitResult) {
        // reset this to original, don't want to mess with other mixins expecting this to be correct here
        if (this.puzzleslib$originalHitResult != null) hitResult = this.puzzleslib$originalHitResult;
        this.puzzleslib$originalHitResult = null;
        return hitResult;
    }
}
