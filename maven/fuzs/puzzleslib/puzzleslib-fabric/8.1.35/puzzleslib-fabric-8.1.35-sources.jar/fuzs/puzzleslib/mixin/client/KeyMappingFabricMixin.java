package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.screen.v2.KeyMappingActivationHelper;
import net.minecraft.class_304;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_304.class)
abstract class KeyMappingFabricMixin {

    @Inject(method = "same", at = @At("HEAD"), cancellable = true)
    public void same(class_304 keyMapping, CallbackInfoReturnable<Boolean> callback) {
        if (!KeyMappingActivationHelper.INSTANCE.hasConflictWith(class_304.class.cast(this), keyMapping)) callback.setReturnValue(false);
    }
}
