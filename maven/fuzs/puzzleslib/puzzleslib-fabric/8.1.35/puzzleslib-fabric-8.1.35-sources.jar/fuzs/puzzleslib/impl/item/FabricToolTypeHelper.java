package fuzs.puzzleslib.impl.item;

import fuzs.puzzleslib.api.item.v2.ToolTypeHelper;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.minecraft.class_1799;

public final class FabricToolTypeHelper implements ToolTypeHelper {

    @Override
    public boolean isShears(class_1799 stack) {
        return ToolTypeHelper.super.isShears(stack) || stack.method_31573(ConventionalItemTags.SHEARS);
    }

    @Override
    public boolean isShield(class_1799 stack) {
        return ToolTypeHelper.super.isShield(stack) || stack.method_31573(ConventionalItemTags.SHIELDS);
    }

    @Override
    public boolean isBow(class_1799 stack) {
        return ToolTypeHelper.super.isBow(stack) || stack.method_31573(ConventionalItemTags.BOWS);
    }

    @Override
    public boolean isTridentLike(class_1799 stack) {
        return ToolTypeHelper.super.isTridentLike(stack) || stack.method_31573(ConventionalItemTags.SPEARS);
    }
}
