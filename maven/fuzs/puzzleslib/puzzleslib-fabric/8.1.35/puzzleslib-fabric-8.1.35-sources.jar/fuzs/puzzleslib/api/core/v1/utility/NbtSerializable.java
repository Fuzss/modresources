package fuzs.puzzleslib.api.core.v1.utility;

import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

/**
 * A basic template for an object that is serializable to Minecraft's nbt format.
 */
public interface NbtSerializable {

    /**
     * Serialize the component to a {@link class_2487}.
     *
     * @param compoundTag tag to write to
     * @param registries  the registry access
     */
    void write(class_2487 compoundTag, class_7225.class_7874 registries);

    /**
     * Deserialize the component from a {@link class_2487}.
     *
     * @param compoundTag tag to read from
     * @param registries  the registry access
     */
    void read(class_2487 compoundTag, class_7225.class_7874 registries);

    /**
     * Encode the serializable instance to a {@link class_2487}.
     *
     * @param registries the registry access
     * @return a tag containing the serialized instance
     */
    default class_2487 toCompoundTag(class_7225.class_7874 registries) {
        class_2487 tag = new class_2487();
        this.write(tag, registries);
        return tag;
    }

    /**
     * Decode the serializable instance from a {@link class_2487}.
     *
     * @param factory    supplier for a new empty instance
     * @param registries the registry access
     * @param <T>        serializable instance type
     * @return a tag containing the serialized instance
     */
    static <T extends NbtSerializable> Function<class_2487, T> fromCompoundTag(Supplier<T> factory, class_7225.class_7874 registries) {
        return (class_2487 compoundTag) -> {
            T nbtSerializable = factory.get();
            nbtSerializable.read(compoundTag, registries);
            return nbtSerializable;
        };
    }
}
