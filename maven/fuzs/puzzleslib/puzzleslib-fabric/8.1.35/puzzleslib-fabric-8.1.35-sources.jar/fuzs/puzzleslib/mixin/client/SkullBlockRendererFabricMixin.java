package fuzs.puzzleslib.mixin.client;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.impl.client.event.SkullRendererRegistryImpl;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;
import net.minecraft.class_836;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_836.class)
abstract class SkullBlockRendererFabricMixin {

    @ModifyVariable(method = "createSkullRenderers", at = @At("STORE"))
    private static ImmutableMap.Builder<class_2484.class_2485, class_5598> puzzleslib$createSkullRenderers(ImmutableMap.Builder<class_2484.class_2485, class_5598> builder, class_5599 entityModelSet) {
        SkullRendererRegistryImpl.addAll(entityModelSet, builder);
        return builder;
    }
}
