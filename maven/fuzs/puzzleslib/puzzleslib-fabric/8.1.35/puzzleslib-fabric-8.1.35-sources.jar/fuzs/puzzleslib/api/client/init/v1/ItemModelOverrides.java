package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_1091;
import net.minecraft.class_1792;
import net.minecraft.class_811;

/**
 * Allows for registering model overrides for items that have a different model in {@link net.minecraft.class_918} depending on {@link class_811} like {@link net.minecraft.class_1802#field_8547} and {@link net.minecraft.class_1802#field_27070} in vanilla.
 */
@Deprecated(forRemoval = true)
public interface ItemModelOverrides {
    ItemModelOverrides INSTANCE = (class_1792 item, class_1091 itemModel, class_1091 itemModelOverride, class_811... defaultContexts) -> {
        // not so sure if turning this method default would result in a binary change when calling the method, so just leaving it like this until it is removed
        ItemModelDisplayOverrides.INSTANCE.register(itemModel, itemModelOverride, defaultContexts);
    };

    /**
     * Register an item model override for an item.
     *
     * @param item              the item to register overrides for
     * @param itemModel         the default item model location using the built-in item model template, usually used for the item's appearance in guis and when dropped on the ground
     * @param itemModelOverride the custom model, usually used for in-hand rendering
     * @param defaultContexts   item display contexts to keep the default <code>itemModel</code> for
     */
    void register(class_1792 item, class_1091 itemModel, class_1091 itemModelOverride, class_811... defaultContexts);
}
