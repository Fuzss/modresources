package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import net.minecraft.class_1352;
import net.minecraft.class_1387;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_6024;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1387.class)
public abstract class RunAroundLikeCrazyGoalFabricMixin extends class_1352 {
    @Shadow
    @Final
    private class_1496 horse;

    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/animal/horse/AbstractHorse;tameWithName(Lnet/minecraft/world/entity/player/Player;)Z"), cancellable = true)
    public void tick(CallbackInfo callback) {
        class_1657 player = (class_1657) this.horse.method_5685().get(0);
        if (FabricLivingEvents.ANIMAL_TAME.invoker().onAnimalTame(this.horse, player).isInterrupt()) {
            this.horse.method_6745(5);
            this.horse.method_5772();
            this.horse.method_6757();
            this.horse.method_37908().method_8421(this.horse, class_6024.field_30031);
            callback.cancel();
        }
    }
}
