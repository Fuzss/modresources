package fuzs.puzzleslib.mixin;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.impl.event.PotentialSpawnsList;
import fuzs.puzzleslib.mixin.accessor.WeightedRandomListFabricAccessor;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6011;
import net.minecraft.class_6012;
import net.minecraft.class_6880;

@Mixin(class_1948.class)
abstract class NaturalSpawnerFabricMixin {

    @Inject(method = "mobsAt", at = @At("TAIL"))
    private static void mobsAt(class_3218 level, class_5138 structureManager, class_2794 generator, class_1311 category, class_2338 pos, @Nullable class_6880<class_1959> biome, CallbackInfoReturnable<class_6012<class_5483.class_1964>> callback) {
        Object[] holder = new Object[1];
        class_6012<class_5483.class_1964> weightedList = callback.getReturnValue();
        List<class_5483.class_1964> mobs = new PotentialSpawnsList<>(() -> {
            return holder[0] != null ? (List<class_5483.class_1964>) holder[0] : weightedList.method_34994();
        }, spawnerData -> {
            List<class_5483.class_1964> spawnerDataList = (List<class_5483.class_1964>) holder[0];
            if (spawnerDataList == null) {
                holder[0] = spawnerDataList = new ArrayList<>(weightedList.method_34994());
            }
            return spawnerDataList.add(spawnerData);
        }, spawnerData -> {
            List<class_5483.class_1964> spawnerDataList = (List<class_5483.class_1964>) holder[0];
            if (spawnerDataList == null) {
                holder[0] = spawnerDataList = new ArrayList<>(weightedList.method_34994());
            }
            return spawnerDataList.remove(spawnerData);
        });
        FabricLevelEvents.GATHER_POTENTIAL_SPAWNS.invoker().onGatherPotentialSpawns(level, structureManager, generator, category, pos, mobs);
        // try not to replace the return value weighted list, instead change it in hopes of better compatibility with other mixins
        // no longer necessary when using Mixin Extras
        if (holder[0] != null) {
            List<class_5483.class_1964> spawnerDataList = (List<class_5483.class_1964>) holder[0];
            ((WeightedRandomListFabricAccessor<class_5483.class_1964>) weightedList).puzzleslib$setTotalWeight(class_6011.method_34984(spawnerDataList));
            ((WeightedRandomListFabricAccessor<class_5483.class_1964>) weightedList).puzzleslib$setItems(ImmutableList.copyOf(spawnerDataList));
        }
    }
}
