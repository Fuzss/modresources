package fuzs.puzzleslib.impl.capability.v2;

import fuzs.puzzleslib.api.capability.v2.data.SyncStrategy;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import java.util.function.BiConsumer;
import net.minecraft.class_3222;

public final class SyncStrategyImpl implements SyncStrategy {
    private final BiConsumer<?, class_3222> sender;

    public <T extends Record & ClientboundMessage<T>> SyncStrategyImpl(BiConsumer<T, class_3222> sender) {
        this.sender = sender;
    }

    @Override
    @SuppressWarnings("unchecked")
    public <T extends Record & ClientboundMessage<T>> void sendTo(T message, class_3222 player) {
        ((BiConsumer<T, class_3222>) this.sender).accept(message, player);
    }
}
