package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedInt;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import org.jetbrains.annotations.Nullable;

@FunctionalInterface
public interface LivingExperienceDropCallback {
    EventInvoker<LivingExperienceDropCallback> EVENT = EventInvoker.lookup(LivingExperienceDropCallback.class);

    /**
     * Called right before xp drops are spawned in the world. Allows for cancelling drops or changing the amount.
     *
     * @param entity the entity that died
     * @param attackingPlayer the player that killed <code>entity</code>
     * @param droppedExperience amount of xp dropped by vanilla, allows for setting a custom amount
     * @return {@link EventResult#INTERRUPT} to prevent any xp from dropping regardless of the value in <code>droppedExperience</code>,
     *         {@link EventResult#PASS} to drop the amount set in <code>droppedExperience</code>, potentially the original amount if it hasn't been changed
     */
    EventResult onLivingExperienceDrop(class_1309 entity, @Nullable class_1657 attackingPlayer, DefaultedInt droppedExperience);
}
