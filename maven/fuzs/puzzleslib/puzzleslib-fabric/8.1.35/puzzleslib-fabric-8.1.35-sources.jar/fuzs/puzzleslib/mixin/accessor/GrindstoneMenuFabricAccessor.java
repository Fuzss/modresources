package fuzs.puzzleslib.mixin.accessor;

import net.minecraft.class_1263;
import net.minecraft.class_3803;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3803.class)
public interface GrindstoneMenuFabricAccessor {

    @Accessor("repairSlots")
    class_1263 puzzleslib$getRepairSlots();
}
