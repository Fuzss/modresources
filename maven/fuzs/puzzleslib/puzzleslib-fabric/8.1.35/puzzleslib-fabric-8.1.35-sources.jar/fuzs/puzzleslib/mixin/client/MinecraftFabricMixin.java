package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.client.event.v1.FabricScreenEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_317;
import net.minecraft.class_418;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_757;

@Mixin(class_310.class)
public abstract class MinecraftFabricMixin {
    @Shadow
    @Final
    public class_757 gameRenderer;
    @Shadow
    private boolean pause;
    @Shadow
    private float pausePartialTick;
    @Shadow
    @Final
    private class_317 timer;
    @Shadow
    @Nullable
    public class_638 level;
    @Shadow
    @Nullable
    public class_746 player;
    @Shadow
    @Nullable
    public class_636 gameMode;
    @Shadow
    @Nullable
    public class_437 screen;
    @Unique
    private DefaultedValue<class_437> puzzleslib$newScreen;

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;render(FJZ)V", shift = At.Shift.BEFORE))
    private void runTick$0(boolean renderLevel, CallbackInfo callback) {
        FabricClientEvents.BEFORE_GAME_RENDER.invoker().onBeforeGameRender(class_310.class.cast(this), this.gameRenderer, this.pause ? this.pausePartialTick : this.timer.field_1970);
    }

    @Inject(method = "runTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;render(FJZ)V", shift = At.Shift.AFTER))
    private void runTick$1(boolean renderLevel, CallbackInfo callback) {
        FabricClientEvents.AFTER_GAME_RENDER.invoker().onAfterGameRender(class_310.class.cast(this), this.gameRenderer, this.pause ? this.pausePartialTick : this.timer.field_1970);
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    public void setScreen$0(@Nullable class_437 newScreen, CallbackInfo callback) {
        // we handle this callback at head to avoid having to block Screen#remove
        newScreen = this.puzzleslib$handleEmptyScreen(newScreen);
        this.puzzleslib$newScreen = DefaultedValue.fromValue(newScreen);
        EventResult result = FabricScreenEvents.SCREEN_OPENING.invoker().onScreenOpening(this.screen, this.puzzleslib$newScreen);
        if (result.isInterrupt() || this.puzzleslib$newScreen.getAsOptional().filter(screen -> screen == this.screen).isPresent()) callback.cancel();
    }

    @Unique
    @Nullable
    private class_437 puzzleslib$handleEmptyScreen(@Nullable class_437 newScreen) {
        // copy this vanilla functionality, it runs after the screen is removed, but we need it before that to potentially block the removal
        if (newScreen == null && this.level == null) {
            return new class_442();
        } else if (newScreen == null && this.player.method_29504()) {
            if (this.player.method_22419()) {
                return new class_418(null, this.level.method_28104().method_152());
            } else {
                this.player.method_7331();
            }
        }
        return newScreen;
    }

    @ModifyVariable(method = "setScreen", at = @At(value = "LOAD", ordinal = 0), slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;respawn()V")), ordinal = 0)
    public class_437 setScreen$1(@Nullable class_437 newScreen) {
        Objects.requireNonNull(this.puzzleslib$newScreen, "new screen is null");
        // problematic for our own title / death screen instances, in case event listeners depend on the exact reference
        // but probably better our implementation doesn't work perfectly than breaking other mods which would be hard to trace
        newScreen = this.puzzleslib$newScreen.getAsOptional().orElse(newScreen);
        this.puzzleslib$newScreen = null;
        return newScreen;
    }

    @Inject(method = "setLevel", at = @At("HEAD"))
    public void setLevel(class_638 clientLevel, CallbackInfo callback) {
        if (this.level == null) return;
        FabricClientEvents.UNLOAD_LEVEL.invoker().onLevelUnload(class_310.class.cast(this), this.level);
    }

    @Inject(method = "clearLevel(Lnet/minecraft/client/gui/screens/Screen;)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/GameRenderer;resetData()V", shift = At.Shift.AFTER))
    public void clearLevel(class_437 screen, CallbackInfo callback) {
        if (this.player != null && this.gameMode != null) {
            class_2535 connection = this.player.field_3944.method_48296();
            Objects.requireNonNull(connection, "connection is null");
            FabricClientEvents.PLAYER_LOGGED_OUT.invoker().onLoggedOut(this.player, this.gameMode, connection);
        }
        if (this.level != null) {
            FabricClientEvents.UNLOAD_LEVEL.invoker().onLevelUnload(class_310.class.cast(this), this.level);
        }
    }
}
