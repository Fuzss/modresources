package fuzs.puzzleslib.api.client.screen.v2;

import fuzs.puzzleslib.impl.client.core.ClientFactories;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_437;
import net.minecraft.class_465;

/**
 * A helper class for accessing encapsulated fields on a screen.
 * On Forge those are all exposed via added getter methods, but Fabric requires mixin accessors.
 */
public interface ScreenHelper {
    ScreenHelper INSTANCE = ClientFactories.INSTANCE.getScreenHelper();

    /**
     * @param screen screen instance
     * @return minecraft singleton
     */
    class_310 getMinecraft(class_437 screen);

    /**
     * @param screen screen instance
     * @return font renderer
     */
    class_327 getFont(class_437 screen);

    /**
     * @param screen container screen instance
     * @return width of container interface
     */
    int getImageWidth(class_465<?> screen);

    /**
     * @param screen container screen instance
     * @return height of container interface
     */
    int getImageHeight(class_465<?> screen);

    /**
     * @param screen container screen instance
     * @return left position of container interface
     */
    int getLeftPos(class_465<?> screen);

    /**
     * @param screen container screen instance
     * @return top position of container interface
     */
    int getTopPos(class_465<?> screen);

    /**
     * @param screen container screen instance
     * @return the slot the mouse is currently hovering (which an item tooltip is shown for and where the hovered slot overlay is drawn)
     */
    @Nullable class_1735 getHoveredSlot(class_465<?> screen);

    /**
     * @param screen screen instance
     * @return current mouse x position
     */
    default int getMouseX(class_437 screen) {
        Objects.requireNonNull(screen, "screen is null");
        return this.getMouseX(this.getMinecraft(screen));
    }

    /**
     * @param minecraft minecraft singleton
     * @return current mouse x position
     */
    default int getMouseX(class_310 minecraft) {
        Objects.requireNonNull(minecraft, "minecraft is null");
        return (int) (minecraft.field_1729.method_1603() * minecraft.method_22683().method_4486() / minecraft.method_22683().method_4480());
    }

    /**
     * @param screen screen instance
     * @return current mouse y position
     */
    default int getMouseY(class_437 screen) {
        Objects.requireNonNull(screen, "screen is null");
        return this.getMouseY(this.getMinecraft(screen));
    }

    /**
     * @param minecraft minecraft singleton
     * @return current mouse y position
     */
    default int getMouseY(class_310 minecraft) {
        Objects.requireNonNull(minecraft, "minecraft is null");
        return (int) (minecraft.field_1729.method_1604() * minecraft.method_22683().method_4502() / minecraft.method_22683().method_4507());
    }

    /**
     * Iterates of all slots owned by a container to find if any of them is hovered.
     *
     * @param screen the current container screen to source slots from
     * @param mouseX mouse x position
     * @param mouseY mouse y position
     * @return the active slot or null
     */
    @Nullable
    default class_1735 findSlot(class_465<?> screen, double mouseX, double mouseY) {
        for (class_1735 slot : screen.method_17577().field_7761) {
            if (slot.method_7682() && this.isHovering(screen, slot, mouseX, mouseY)) {
                return slot;
            }
        }
        return null;
    }

    /**
     * Checks if the mouse cursor is hovering over a given slot.
     *
     * @param screen the current container screen owning the slot
     * @param slot   the slot to check if hovered
     * @param mouseX mouse x position
     * @param mouseY mouse y position
     * @return is the mouse cursor hovering the slot
     */
    default boolean isHovering(class_465<?> screen, class_1735 slot, double mouseX, double mouseY) {
        mouseX -= this.getLeftPos(screen);
        mouseY -= this.getTopPos(screen);
        return this.isHovering(slot.field_7873 - 1, slot.field_7872 - 1, 18, 18, mouseX, mouseY);
    }

    /**
     * Checks if the mouse cursor is hovering a defined region.
     *
     * @param posX   the x-start of the hover area
     * @param posY   the y-start of the hover area
     * @param width  the width from x-start of the hover area
     * @param height the height from y-start of the hover area
     * @param mouseX mouse x position
     * @param mouseY mouse y position
     * @return is the mouse cursor hovering the defined region
     */
    default boolean isHovering(int posX, int posY, int width, int height, double mouseX, double mouseY) {
        return mouseX >= posX && mouseX < posX + width && mouseY >= posY && mouseY < posY + height;
    }
}
