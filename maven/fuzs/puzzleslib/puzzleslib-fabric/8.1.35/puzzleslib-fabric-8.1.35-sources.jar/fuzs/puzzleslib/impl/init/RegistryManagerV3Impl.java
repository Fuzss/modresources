package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.core.v1.ModLoader;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.init.v3.RegistryManager;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

public abstract class RegistryManagerV3Impl implements RegistryManager {
    protected final String modId;
    protected Set<ModLoader> allowedModLoaders = EnumSet.allOf(ModLoader.class);

    protected RegistryManagerV3Impl(String modId) {
        this.modId = modId;
    }

    @Override
    public class_2960 makeKey(String path) {
        if (StringUtils.isEmpty(path)) throw new IllegalArgumentException("path is invalid");
        return new class_2960(this.modId, path);
    }

    @Override
    public RegistryManager whenOn(ModLoader... allowedModLoaders) {
        Objects.checkIndex(0, allowedModLoaders.length);
        this.allowedModLoaders = EnumSet.copyOf(Arrays.asList(allowedModLoaders));
        return this;
    }

    @Override
    public final <T> class_6880.class_6883<T> register(final class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Objects.requireNonNull(supplier, "supplier is null");
        class_6880.class_6883<T> holder;
        if (!this.allowedModLoaders.contains(ModLoaderEnvironment.INSTANCE.getModLoader())) {
            holder = this.getHolder(registryKey, path);
        } else {
            holder = this._register(registryKey, path, supplier);
        }
        this.allowedModLoaders = EnumSet.allOf(ModLoader.class);
        return holder;
    }

    protected abstract <T> class_6880.class_6883<T> _register(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier);
}
