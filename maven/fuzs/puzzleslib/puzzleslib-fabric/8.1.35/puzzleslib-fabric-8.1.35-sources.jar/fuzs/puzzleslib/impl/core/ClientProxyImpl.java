package fuzs.puzzleslib.impl.core;

import java.util.Objects;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_634;

public interface ClientProxyImpl extends ProxyImpl {

    @Override
    default class_1657 getClientPlayer() {
        return class_310.method_1551().field_1724;
    }

    @Override
    default class_1937 getClientLevel() {
        return class_310.method_1551().field_1687;
    }

    @Override
    default class_634 getClientPacketListener() {
        class_634 connection = class_310.method_1551().method_1562();
        Objects.requireNonNull(connection, "client packet listener is null");
        return connection;
    }

    @Override
    default boolean hasControlDown() {
        return class_437.method_25441();
    }

    @Override
    default boolean hasShiftDown() {
        return class_437.method_25442();
    }

    @Override
    default boolean hasAltDown() {
        return class_437.method_25443();
    }

    @Override
    default class_2561 getKeyMappingComponent(String identifier) {
        return class_304.method_1419(identifier).get();
    }
}
