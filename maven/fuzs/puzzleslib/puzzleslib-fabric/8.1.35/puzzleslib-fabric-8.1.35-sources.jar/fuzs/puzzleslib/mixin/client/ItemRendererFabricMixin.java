package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.init.v1.ItemModelDisplayOverrides;
import fuzs.puzzleslib.impl.client.init.ItemDisplayOverridesImpl;
import net.minecraft.class_1087;
import net.minecraft.class_1799;
import net.minecraft.class_811;
import net.minecraft.class_918;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_918.class)
abstract class ItemRendererFabricMixin {

    @ModifyVariable(method = "render", at = @At(value = "LOAD", ordinal = 0), ordinal = 0, argsOnly = true)
    public class_1087 render(class_1087 bakedModel, class_1799 stack, class_811 itemDisplayContext) {
        return ((ItemDisplayOverridesImpl) ItemModelDisplayOverrides.INSTANCE).getItemModelDisplayOverride(bakedModel, itemDisplayContext);
    }
}
