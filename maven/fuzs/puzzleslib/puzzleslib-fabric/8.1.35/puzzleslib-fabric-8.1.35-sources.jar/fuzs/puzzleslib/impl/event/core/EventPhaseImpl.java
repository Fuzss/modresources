package fuzs.puzzleslib.impl.event.core;

import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;

public record EventPhaseImpl(class_2960 identifier, EventPhase parent, Ordering ordering) implements EventPhase {

    public void applyOrdering(BiConsumer<class_2960, class_2960> consumer) {
        this.ordering().apply(consumer, this.identifier(), this.parent().identifier());
    }

    public interface Ordering {
        Ordering BEFORE = (consumer, first, second) -> {
            consumer.accept(first, second);
        };
        Ordering AFTER = (consumer, first, second) -> {
            consumer.accept(second, first);
        };

        void apply(BiConsumer<class_2960, class_2960> consumer, class_2960 first, class_2960 second);
    }
}
