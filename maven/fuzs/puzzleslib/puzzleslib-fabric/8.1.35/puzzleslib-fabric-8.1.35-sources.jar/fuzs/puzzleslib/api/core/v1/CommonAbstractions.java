package fuzs.puzzleslib.api.core.v1;

import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_3288;
import net.minecraft.class_3730;
import net.minecraft.class_3908;
import net.minecraft.class_5425;
import net.minecraft.class_7699;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

/**
 * Useful methods for gameplay related things that require mod loader specific abstractions.
 */
public interface CommonAbstractions {
    CommonAbstractions INSTANCE = ServiceProviderHelper.load(CommonAbstractions.class);

    /**
     * Get the current game server which is captured to allow retrieval from anywhere.
     *
     * @return current game server, null when not in a world
     */
    MinecraftServer getMinecraftServer();

    /**
     * Opens a menu on both client and server.
     *
     * @param player       player to open menu for
     * @param menuProvider menu factory
     */
    default void openMenu(class_3222 player, class_3908 menuProvider) {
        this.openMenu(player, menuProvider, (class_3222 serverPlayer, class_2540 buf) -> {
        });
    }

    /**
     * Opens a menu on both client and server while also providing additional data.
     *
     * @param player                  player to open menu for
     * @param menuProvider            menu factory
     * @param screenOpeningDataWriter additional data added via {@link class_2540}
     */
    void openMenu(class_3222 player, class_3908 menuProvider, BiConsumer<class_3222, class_2540> screenOpeningDataWriter);

    /**
     * Is <code>entityType</code> considered a boss mob like {@link class_1299#field_6116} and {@link class_1299#field_6119} in vanilla.
     * <p>A common property of such entities usually is {@link class_1309#method_5822()} returns <code>false</code>.
     *
     * @param type the entity type
     * @return is it a boss mob
     */
    boolean isBossMob(class_1299<?> type);

    /**
     * Returns the enchanting power provided by a block. An enchanting power of 15 is required for level 30 enchants,
     * each bookshelf block provides exactly one enchanting power.
     *
     * @param state the block state at the given position
     * @param level the level
     * @param pos   the block position in the level
     * @return enchanting power, usually zero for blocks other than bookshelves
     */
    float getEnchantPowerBonus(class_2680 state, class_1937 level, class_2338 pos);

    /**
     * Returns if an entity can equip some form of item in a certain slot.
     *
     * @param stack  the stack to be equipped
     * @param slot   the slot the stack is trying to be equipped to
     * @param entity the entity trying to equip
     * @return is equipping this <code>stack</code> to <code>slot</code> allowed for <code>entity</code>
     */
    boolean canEquip(class_1799 stack, class_1304 slot, class_1297 entity);

    /**
     * Called before an entity drops loot for determining the level of {@link net.minecraft.class_1893#field_9110} to apply when generating drops.
     *
     * @param entity       the entity that has been killed
     * @param killerEntity another entity responsible for killing <code>entity</code>
     * @param damageSource the damage source <code>entity</code> has been killed by
     * @return the level of looting to apply when generating drops.
     */
    int getMobLootingLevel(class_1297 entity, @Nullable class_1297 killerEntity, @Nullable class_1282 damageSource);

    /**
     * Called when a <code>mobGriefing</code> game rule check is required instead of vanilla's <code>level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)</code>,
     * allowing for a dedicated Forge event to run.
     *
     * @param level  the level mob griefing is happening in
     * @param entity the entity responsible for triggering the game rule check
     * @return is mob griefing allows to happen
     */
    boolean getMobGriefingRule(class_1937 level, @Nullable class_1297 entity);

    /**
     * A trigger for running a Forge event for destroying an item.
     * <p>Ideally this should be migrated to the event api, to also allow for firing the event on Fabric. Until that happens this functions as a workaround.
     *
     * @param player          the player destroying the item
     * @param itemStack       the item stack before being destroyed
     * @param interactionHand the hand holding the destroyed stack
     */
    void onPlayerDestroyItem(class_1657 player, class_1799 itemStack, @Nullable class_1268 interactionHand);

    /**
     * Retrieves a {@link class_3730} from a {@link class_1308} if it has been set during {@link class_1308#method_5943(class_5425, class_1266, class_3730, class_1315, class_2487)}.
     * <p>Note that the spawn type is saved with the mob, so it persists across chunk and level reloads.
     *
     * @param mob the mob
     * @return the spawn type or null if none has been set
     */
    @Nullable class_3730 getMobSpawnType(class_1308 mob);

    /**
     * Creates a new {@link class_3288.class_7679} instance with additional parameters only supported on Forge.
     *
     * @param id          the pack identifier
     * @param description the pack description component
     * @param packVersion the pack version, ideally retrieved from {@link net.minecraft.class_6489#method_48017(class_3264)}
     * @param features    the feature flags provided by this pack
     * @param hidden      controls whether the pack is hidden from user-facing screens like the resource pack and data pack selection screens
     * @return the created pack info instance
     */
    class_3288.class_7679 createPackInfo(class_2960 id, class_2561 description, int packVersion, class_7699 features, boolean hidden);

    /**
     * Can the given enchanted be applied to an item stack via enchanting (in an enchanting table).
     *
     * @param enchantment the enchantment to check
     * @param itemStack   the item stack trying to receive the enchantment
     * @return is the application allowed
     */
    boolean canApplyAtEnchantingTable(class_1887 enchantment, class_1799 itemStack);

    /**
     * Can the given enchantment be applied to enchanted books.
     *
     * @param enchantment the enchantment to check
     * @return is the application allowed
     */
    boolean isAllowedOnBooks(class_1887 enchantment);
}
