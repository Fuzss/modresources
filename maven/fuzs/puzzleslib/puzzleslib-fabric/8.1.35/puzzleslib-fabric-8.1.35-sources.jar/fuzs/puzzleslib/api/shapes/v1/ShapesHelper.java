package fuzs.puzzleslib.api.shapes.v1;

import com.google.common.collect.Maps;
import org.joml.Quaternionf;
import org.joml.Vector3d;

import java.util.Collections;
import java.util.Map;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;

/**
 * A simple helper class for {@link class_265}, mainly used for applying rotations.
 */
public class ShapesHelper {

    /**
     * Returns a map with the provided {@link class_265} rotated in all six {@link class_2350}s.
     * <p>Note that the provided shape is assumed to be facing {@link class_2350#field_11036}, meaning providing {@link class_2350#field_11036} will return the original shape.
     *
     * @param voxelShape the voxel shape to rotate to
     * @return the rotated shape map
     */
    public static Map<class_2350, class_265> rotate(class_265 voxelShape) {
        Map<class_2350, class_265> shapes = Maps.newEnumMap(class_2350.class);
        for (class_2350 direction : class_2350.values()) {
            shapes.put(direction, rotate(direction, voxelShape));
        }
        return Collections.unmodifiableMap(shapes);
    }

    /**
     * Rotates a provided {@link class_265} depending on the provided {@link class_2350}.
     * <p>Note that the provided shape is assumed to be facing {@link class_2350#field_11036}, meaning providing {@link class_2350#field_11036} will return the original shape.
     * <p>Also for the algorithm to work the shape must be centered on the origin, this overload assumes this shape uses the default vanilla offset which is 0.5, 0.5, 0.5.
     *
     * @param direction  the direction to rotate to
     * @param voxelShape the voxel shape to rotate to
     * @return the rotated shape
     */
    public static class_265 rotate(class_2350 direction, class_265 voxelShape) {
        return rotate(direction, voxelShape, new Vector3d(0.5, 0.5, 0.5));
    }

    /**
     * Rotates a provided {@link class_265} depending on the provided {@link class_2350}.
     * <p>Note that the provided shape is assumed to be facing {@link class_2350#field_11036}, meaning providing {@link class_2350#field_11036} will return the original shape.
     * <p>Also for the algorithm to work the shape must be centered on the origin, if it is not already, the current offset must be provided, which is 0.5, 0.5, 0.5 for vanilla shapes.
     *
     * @param direction    the direction to rotate to
     * @param voxelShape   the voxel shape to rotate to
     * @param originOffset offset from the origin at 0, 0, 0, usually 0.5, 0.5, 0.5
     * @return the rotated shape
     */
    public static class_265 rotate(class_2350 direction, class_265 voxelShape, Vector3d originOffset) {
        class_265[] value = new class_265[]{class_259.method_1073()};
        Quaternionf rotation = direction.method_23224();
        voxelShape.method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
            Vector3d start = rotation.transform(new Vector3d(minX, minY, minZ).sub(originOffset)).add(originOffset);
            Vector3d end = rotation.transform(new Vector3d(maxX, maxY, maxZ).sub(originOffset)).add(originOffset);
            value[0] = class_259.method_1084(value[0], box(start.x, start.y, start.z, end.x, end.y, end.z));
        });
        return value[0];
    }

    /**
     * Constructs a new {@link class_265}, just like {@link class_259#method_1081(double, double, double, double, double, double)}, but in contrast properly sorts start and end coordinates automatically.
     *
     * @param startX start x coordinate
     * @param startY start y coordinate
     * @param startZ start z coordinate
     * @param endX   end x coordinate
     * @param endY   end y coordinate
     * @param endZ   end z coordinate
     * @return the new shape
     */
    public static class_265 box(double startX, double startY, double startZ, double endX, double endY, double endZ) {
        return class_259.method_1081(Math.min(startX, endX), Math.min(startY, endY), Math.min(startZ, endZ), Math.max(startX, endX), Math.max(startY, endY), Math.max(startZ, endZ));
    }
}
