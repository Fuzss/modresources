package fuzs.puzzleslib.impl.client.screen;

import fuzs.puzzleslib.api.client.screen.v2.ScreenHelper;
import fuzs.puzzleslib.mixin.client.accessor.AbstractContainerScreenFabricAccessor;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.class_1735;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * a helper class for accessing encapsulated fields on a screen
 * on Forge those are all exposed, but Fabric requires special accessors
 *
 * <p>for adding buttons, those are handled very different on both mod loaders:
 * on Forge add buttons during init event with appropriate helper methods
 * on Fabric adding is done via custom ButtonList
 */
public final class FabricScreenHelper implements ScreenHelper {

    @Override
    public class_310 getMinecraft(class_437 screen) {
        return Screens.getClient(screen);
    }

    @Override
    public class_327 getFont(class_437 screen) {
        return Screens.getTextRenderer(screen);
    }

    @Override
    public int getImageWidth(class_465<?> screen) {
        Objects.requireNonNull(screen, "screen is null");
        return ((AbstractContainerScreenFabricAccessor) screen).puzzleslib$getXSize();
    }

    @Override
    public int getImageHeight(class_465<?> screen) {
        Objects.requireNonNull(screen, "screen is null");
        return ((AbstractContainerScreenFabricAccessor) screen).puzzleslib$getYSize();
    }

    @Override
    public int getLeftPos(class_465<?> screen) {
        Objects.requireNonNull(screen, "screen is null");
        return ((AbstractContainerScreenFabricAccessor) screen).puzzleslib$getGuiLeft();
    }

    @Override
    public int getTopPos(class_465<?> screen) {
        Objects.requireNonNull(screen, "screen is null");
        return ((AbstractContainerScreenFabricAccessor) screen).puzzleslib$getGuiTop();
    }

    @Override
    public @Nullable class_1735 getHoveredSlot(class_465<?> screen) {
        Objects.requireNonNull(screen, "screen is null");
        return ((AbstractContainerScreenFabricAccessor) screen).puzzleslib$getSlotUnderMouse();
    }
}
