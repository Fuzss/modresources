package fuzs.puzzleslib.impl.client.event;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.client.event.v1.SkullRendererRegistry;
import fuzs.puzzleslib.api.client.init.v1.SkullRenderersFactory;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;

public final class SkullRendererRegistryImpl implements SkullRendererRegistry {
    private static final Set<SkullRenderersFactory> FACTORIES = Sets.newHashSet();

    @Override
    public void register(SkullRenderersFactory factory) {
        Objects.requireNonNull(factory, "factory is null");
        FACTORIES.add(factory);
    }

    public static void addAll(class_5599 entityModelSet, ImmutableMap.Builder<class_2484.class_2485, class_5598> builder) {
        for (SkullRenderersFactory factory : FACTORIES) {
            factory.createSkullRenderers(entityModelSet, builder::put);
        }
    }
}
