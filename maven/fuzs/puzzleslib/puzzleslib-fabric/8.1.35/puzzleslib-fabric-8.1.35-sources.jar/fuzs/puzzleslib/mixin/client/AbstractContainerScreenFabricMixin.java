package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricScreenEvents;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
abstract class AbstractContainerScreenFabricMixin extends class_437 {

    protected AbstractContainerScreenFabricMixin(class_2561 component) {
        super(component);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderBg(Lnet/minecraft/client/gui/GuiGraphics;FII)V", shift = At.Shift.AFTER))
    public void render$0(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks, CallbackInfo callback) {
        FabricScreenEvents.CONTAINER_SCREEN_BACKGROUND.invoker().onDrawBackground(class_465.class.cast(this), guiGraphics, mouseX, mouseY);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderLabels(Lnet/minecraft/client/gui/GuiGraphics;II)V", shift = At.Shift.AFTER))
    public void render$1(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks, CallbackInfo callback) {
        FabricScreenEvents.CONTAINER_SCREEN_FOREGROUND.invoker().onDrawForeground(class_465.class.cast(this), guiGraphics, mouseX, mouseY);
    }
}
