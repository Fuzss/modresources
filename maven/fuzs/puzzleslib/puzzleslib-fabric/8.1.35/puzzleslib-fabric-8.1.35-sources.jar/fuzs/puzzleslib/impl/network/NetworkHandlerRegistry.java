package fuzs.puzzleslib.impl.network;

import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.api.network.v3.NetworkHandlerV3;
import fuzs.puzzleslib.api.network.v3.PlayerSet;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_2382;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2792;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;

public interface NetworkHandlerRegistry extends NetworkHandlerV3 {

    @Deprecated
    @Override
    <T extends Record & ClientboundMessage<T>> class_2596<class_2602> toClientboundPacket(T message);

    @Deprecated
    @Override
    <T extends Record & ServerboundMessage<T>> class_2596<class_2792> toServerboundPacket(T message);

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendMessage(PlayerSet playerSet, T message) {
        NetworkHandlerV3.super.sendMessage(playerSet, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ServerboundMessage<T>> void sendToServer(T message) {
        NetworkHandlerV3.super.sendToServer(message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendTo(class_3222 player, T message) {
        NetworkHandlerV3.super.sendTo(player, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAll(MinecraftServer server, T message) {
        NetworkHandlerV3.super.sendToAll(server, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAll(MinecraftServer server, @Nullable class_3222 exclude, T message) {
        NetworkHandlerV3.super.sendToAll(server, exclude, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAll(Collection<class_3222> playerList, @Nullable class_3222 exclude, T message) {
        NetworkHandlerV3.super.sendToAll(playerList, exclude, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAll(class_3218 level, T message) {
        NetworkHandlerV3.super.sendToAll(level, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(class_2382 pos, class_3218 level, T message) {
        NetworkHandlerV3.super.sendToAllNear(pos, level, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(double posX, double posY, double posZ, class_3218 level, T message) {
        NetworkHandlerV3.super.sendToAllNear(posX, posY, posZ, level, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(@Nullable class_3222 exclude, double posX, double posY, double posZ, double distance, class_3218 level, T message) {
        NetworkHandlerV3.super.sendToAllNear(exclude, posX, posY, posZ, distance, level, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_2586 blockEntity, T message) {
        NetworkHandlerV3.super.sendToAllTracking(blockEntity, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_2818 chunk, T message) {
        NetworkHandlerV3.super.sendToAllTracking(chunk, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_3218 level, class_1923 chunkPos, T message) {
        NetworkHandlerV3.super.sendToAllTracking(level, chunkPos, message);
    }

    @Deprecated
    @Override
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_1297 entity, T message, boolean includeSelf) {
        NetworkHandlerV3.super.sendToAllTracking(entity, message, includeSelf);
    }
}
