package fuzs.puzzleslib.api.init.v2;

import fuzs.puzzleslib.impl.core.CommonFactories;
import net.minecraft.class_1792;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1856;

/**
 * A registry for adding new recipes valid for the brewing stand.
 * Vanilla methods are exposed on Fabric, require {@link class_1792} instead of {@link class_1856} though, while the implementation supports {@link class_1856}.
 * Forge uses a whole different system based on {@link class_1856}, which does not allow specifying {@link class_1842}s as vanilla does.
 */
public interface PotionBrewingRegistry {
    PotionBrewingRegistry INSTANCE = CommonFactories.INSTANCE.getPotionBrewingRegistry();

    /**
     * Register an item that can hold potions.
     * <p>We don't take an {@link class_1856} here as Fabric natively doesn't support that and there isn't really much point to it.
     *
     * @param container the potion container item
     */
    void registerPotionContainer(class_1812 container);

    /**
     * Register a brewing stand recipe that converts a potion item container to another form, the potion inside will stay the same.
     * E.g. in vanilla convert a normal potion to a splash potion by adding gunpowder.
     *
     * @param from the base potion container item
     * @param ingredient ingredient used for the conversion
     * @param to         the output potion container item
     */
    default void registerContainerRecipe(class_1812 from, class_1792 ingredient, class_1812 to) {
        this.registerContainerRecipe(from, class_1856.method_8091(ingredient), to);
    }

    /**
     * Register a brewing stand recipe that converts a potion item container to another form, the potion inside will stay the same.
     * E.g. in vanilla convert a normal potion to a splash potion by adding gunpowder.
     *
     * @param from the base potion container item
     * @param ingredient ingredient used for the conversion
     * @param to         the output potion container item
     */
    void registerContainerRecipe(class_1812 from, class_1856 ingredient, class_1812 to);

    /**
     * Register a brewing stand recipe that converts a potion to another potion, the potion item container will stay the same.
     * E.g. in vanilla convert a night vision potion to an invisibility potion by adding fermented spider eye.
     *
     * @param from the base potion container item
     * @param ingredient ingredient used for the conversion
     * @param to         the output potion container item
     */
    default void registerPotionRecipe(class_1842 from, class_1792 ingredient, class_1842 to) {
        this.registerPotionRecipe(from, class_1856.method_8091(ingredient), to);
    }

    /**
     * Register a brewing stand recipe that converts a potion to another potion, the potion item container will stay the same.
     * E.g. in vanilla convert a night vision potion to an invisibility potion by adding fermented spider eye.
     *
     * @param from the base potion container item
     * @param ingredient ingredient used for the conversion
     * @param to         the output potion container item
     */
    void registerPotionRecipe(class_1842 from, class_1856 ingredient, class_1842 to);
}
