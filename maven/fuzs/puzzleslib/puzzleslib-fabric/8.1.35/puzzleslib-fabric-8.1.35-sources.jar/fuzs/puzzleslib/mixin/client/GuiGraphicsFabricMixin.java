package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricScreenEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.impl.client.event.ItemDecoratorRegistryImpl;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@Mixin(class_332.class)
abstract class GuiGraphicsFabricMixin {

    @Inject(method = "renderItemDecorations(Lnet/minecraft/client/gui/Font;Lnet/minecraft/world/item/ItemStack;IILjava/lang/String;)V", at = @At("TAIL"))
    public void renderItemDecorations(class_327 font, class_1799 stack, int xPosition, int yPosition, @Nullable String text, CallbackInfo callback) {
        if (!stack.method_7960()) ItemDecoratorRegistryImpl.render(class_332.class.cast(this), font, stack, xPosition, yPosition);
    }

    @Inject(method = "renderTooltipInternal", at = @At("HEAD"), cancellable = true)
    private void renderTooltipInternal(class_327 font, List<class_5684> components, int mouseX, int mouseY, class_8000 clientTooltipPositioner, CallbackInfo callback) {
        if (components.isEmpty()) return;
        EventResult result = FabricScreenEvents.RENDER_TOOLTIP.invoker().onRenderTooltip(class_332.class.cast(this), mouseX, mouseY, this.guiWidth(), this.guiHeight(), font, components, clientTooltipPositioner);
        if (result.isInterrupt()) callback.cancel();
    }

    @Shadow
    public abstract int guiWidth();

    @Shadow
    public abstract int guiHeight();
}
