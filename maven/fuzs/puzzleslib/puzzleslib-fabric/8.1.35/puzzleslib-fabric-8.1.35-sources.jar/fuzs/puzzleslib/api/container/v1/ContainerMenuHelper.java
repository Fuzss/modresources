package fuzs.puzzleslib.api.container.v1;

import fuzs.puzzleslib.mixin.accessor.AbstractContainerMenuAccessor;
import fuzs.puzzleslib.mixin.accessor.SimpleContainerAccessor;
import net.minecraft.class_1263;
import net.minecraft.class_1265;
import net.minecraft.class_1277;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.jetbrains.annotations.Nullable;

/**
 * Small helper class related to working with implementations of {@link class_1703}.
 */
public final class ContainerMenuHelper {

    private ContainerMenuHelper() {
        // NO-OP
    }

    /**
     * Replace the container slot representing the currently selected hotbar slot with a non-interactive variant.
     * <p>
     * Useful for handheld container items such as bags while their menu is open.
     *
     * @param containerMenu the container menu
     */
    public static void setSelectedSlotLocked(class_1703 containerMenu) {
        for (int i = 0; i < containerMenu.field_7761.size(); i++) {
            class_1735 slot = containerMenu.field_7761.get(i);
            if (slot.field_7871 instanceof class_1661 inventory && inventory.field_7545 == slot.method_34266()) {
                NonInteractiveResultSlot newSlot = new NonInteractiveResultSlot(slot.field_7871,
                        slot.method_34266(),
                        slot.field_7873,
                        slot.field_7872) {
                    @Override
                    public boolean isFake() {
                        return false;
                    }
                };
                newSlot.field_7874 = slot.field_7874;
                containerMenu.field_7761.set(i, newSlot);
                break;
            }
        }
    }

    /**
     * Adds the player inventory slots to an {@link class_1703}.
     *
     * @param containerMenu menu to add slots to
     * @param inventory     player inventory instance
     * @param offsetY       vertical offset
     */
    public static void addInventorySlots(class_1703 containerMenu, class_1661 inventory, int offsetY) {
        addInventorySlots(containerMenu, inventory, 8, offsetY);
    }

    /**
     * Adds the player inventory slots to an {@link class_1703}.
     *
     * @param containerMenu menu to add slots to
     * @param inventory     player inventory instance
     * @param offsetX       horizontal offset
     * @param offsetY       vertical offset
     */
    public static void addInventorySlots(class_1703 containerMenu, class_1661 inventory, int offsetX, int offsetY) {
        final int slotSize = 18;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                ((AbstractContainerMenuAccessor) containerMenu).puzzleslib$callAddSlot(new class_1735(inventory,
                        j + i * 9 + 9,
                        offsetX + j * slotSize,
                        offsetY));
            }
            offsetY += slotSize;
        }
        offsetY += 4;
        for (int i = 0; i < 9; ++i) {
            ((AbstractContainerMenuAccessor) containerMenu).puzzleslib$callAddSlot(new class_1735(inventory,
                    i,
                    offsetX + i * slotSize,
                    offsetY));
        }
    }

    /**
     * Allows for creating a container backed by a list of items.
     * <p>
     * Useful for items that are stored on e.g. a block entity, but not accessible via a container, but should be
     * accessible via a menu implementation.
     * <p>
     * An example would be a slot for setting a filter item that is kept separate from the main container inventory.
     *
     * @param items    list of items
     * @param listener listener for changes to the item list
     * @return the created container
     */
    public static class_1277 createListBackedContainer(class_2371<class_1799> items, @Nullable class_1263 listener) {
        return createListBackedContainer(items, listener != null ? $ -> listener.method_5431() : null);
    }

    /**
     * Allows for creating a container backed by a list of items.
     * <p>
     * Useful for items that are stored on e.g. a block entity, but not accessible via a container, but should be
     * accessible via a menu implementation.
     * <p>
     * An example would be a slot for setting a filter item that is kept separate from the main container inventory.
     *
     * @param items    list of items
     * @param listener listener for changes to the item list
     * @return the created container
     */
    public static class_1277 createListBackedContainer(class_2371<class_1799> items, @Nullable class_1265 listener) {
        class_1277 simpleContainer = new class_1277();
        ((SimpleContainerAccessor) simpleContainer).puzzleslib$setSize(items.size());
        ((SimpleContainerAccessor) simpleContainer).puzzleslib$setItems(items);
        if (listener != null) {
            simpleContainer.method_5489(listener);
        }

        return simpleContainer;
    }

    /**
     * Writes contents from a list of items to a container.
     * <p>
     * Intended to be used with
     * {@link net.minecraft.class_2624#setItems(NonNullList)} to be able to keep
     * the internal items list final.
     *
     * @param from the source item list
     * @param to   the target container
     */
    public static void copyItemsIntoContainer(class_2371<class_1799> from, class_1263 to) {
        for (int i = 0; i < from.size(); i++) {
            if (i < to.method_5439()) {
                to.method_5447(i, from.get(i));
            }
        }
    }

    /**
     * Writes contents from a list of items to another list of items.
     * <p>
     * Intended to be used with
     * {@link net.minecraft.class_2624#setItems(NonNullList)} to be able to keep
     * the internal items list final.
     *
     * @param from the source item list
     * @param to   the target item list
     */
    public static void copyItemsIntoList(class_2371<class_1799> from, class_2371<class_1799> to) {
        for (int i = 0; i < from.size(); i++) {
            if (i < to.size()) {
                to.set(i, from.get(i));
            }
        }
    }
}
