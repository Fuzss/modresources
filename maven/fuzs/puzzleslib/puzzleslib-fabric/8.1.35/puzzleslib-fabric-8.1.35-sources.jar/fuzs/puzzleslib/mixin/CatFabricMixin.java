package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1321;
import net.minecraft.class_1451;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_6024;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1451.class)
abstract class CatFabricMixin extends class_1321 {

    protected CatFabricMixin(class_1299<? extends class_1321> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "mobInteract", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/animal/Cat;tame(Lnet/minecraft/world/entity/player/Player;)V"), cancellable = true)
    public void mobInteract(class_1657 player, class_1268 interactionHand, CallbackInfoReturnable<class_1269> callback) {
        if (FabricLivingEvents.ANIMAL_TAME.invoker().onAnimalTame(this, player).isInterrupt()) {
            this.method_37908().method_8421(this, class_6024.field_30031);
            this.method_5971();
            callback.setReturnValue(class_1269.field_21466);
        }
    }
}
