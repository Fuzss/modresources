package fuzs.puzzleslib.mixin.accessor;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2248.class)
public interface BlockAccessor {

    @Accessor("item")
    void puzzleslib$setItem(class_1792 item);
}
