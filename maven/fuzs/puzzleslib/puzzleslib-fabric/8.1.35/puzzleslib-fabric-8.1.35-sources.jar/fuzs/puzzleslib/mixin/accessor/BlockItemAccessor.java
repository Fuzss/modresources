package fuzs.puzzleslib.mixin.accessor;

import net.minecraft.class_1747;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1747.class)
public interface BlockItemAccessor {

    @Accessor("block")
    @Mutable
    void puzzleslib$setBlock(class_2248 block);
}
