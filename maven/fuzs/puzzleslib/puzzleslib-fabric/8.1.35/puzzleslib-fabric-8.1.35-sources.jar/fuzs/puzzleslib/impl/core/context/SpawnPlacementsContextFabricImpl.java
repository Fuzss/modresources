package fuzs.puzzleslib.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.SpawnPlacementsContext;
import java.util.Objects;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1317;
import net.minecraft.class_2902;

public final class SpawnPlacementsContextFabricImpl implements SpawnPlacementsContext {

    @Override
    public <T extends class_1308> void registerSpawnPlacement(class_1299<T> entityType, class_1317.class_1319 location, class_2902.class_2903 heightmap, class_1317.class_4306<T> spawnPredicate) {
        Objects.requireNonNull(entityType, "entity type is null");
        Objects.requireNonNull(location, "location is null");
        Objects.requireNonNull(heightmap, "heightmap is null");
        Objects.requireNonNull(spawnPredicate, "spawnPredicate is null");
        class_1317.method_20637(entityType, location, heightmap, spawnPredicate);
    }
}
