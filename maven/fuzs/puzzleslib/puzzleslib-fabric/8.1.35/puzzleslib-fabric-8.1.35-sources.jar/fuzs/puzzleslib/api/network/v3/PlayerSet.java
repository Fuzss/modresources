package fuzs.puzzleslib.api.network.v3;

import com.google.common.base.Preconditions;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2382;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * A distributor for client-bound packets.
 */
public interface PlayerSet {

    /**
     * Send a vanilla packet to clients.
     *
     * @param packet packet to send to clients
     */
    void broadcast(class_2596<?> packet);

    /**
     * Send message from server to no player.
     */
    static PlayerSet ofNone() {
        return (class_2596<?> packet) -> {
            // NO-OP
        };
    }

    /**
     * Send message from server to an entity.
     * <p>
     * When the entity is not a {@link class_3222} no message is sent.
     *
     * @param entity entity to send to
     */
    static PlayerSet ofEntity(class_1297 entity) {
        Objects.requireNonNull(entity, "entity is null");
        return entity instanceof class_3222 serverPlayer ? ofPlayer(serverPlayer) : ofNone();
    }

    /**
     * Send message from server to a player.
     *
     * @param serverPlayer player to send to
     */
    static PlayerSet ofPlayer(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return (class_2596<?> packet) -> {
            serverPlayer.field_13987.method_14364(packet);
        };
    }

    static PlayerSet ofOthers(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return (class_2596<?> packet) -> {
            serverPlayer.method_5682().method_3760().method_14571().forEach(currentServerPlayer -> {
                if (currentServerPlayer != serverPlayer) {
                    ofPlayer(currentServerPlayer).broadcast(packet);
                }
            });
        };
    }

    /**
     * Send message from server to all players on the server.
     *
     * @param minecraftServer server for retrieving the player list
     */
    static PlayerSet ofAll(MinecraftServer minecraftServer) {
        return (class_2596<?> packet) -> {
            minecraftServer.method_3760().method_14571().forEach(serverPlayer -> {
                ofPlayer(serverPlayer).broadcast(packet);
            });
        };
    }

    /**
     * Send message from server to all players in a level.
     *
     * @param serverLevel the level
     */
    static PlayerSet inLevel(class_3218 serverLevel) {
        Objects.requireNonNull(serverLevel, "server level is null");
        return (class_2596<?> packet) -> {
            for (class_3222 serverPlayer : serverLevel.method_18456()) {
                ofPlayer(serverPlayer).broadcast(packet);
            }
        };
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param position    source position
     * @param serverLevel the current level
     */
    static PlayerSet nearPosition(class_2382 position, class_3218 serverLevel) {
        Objects.requireNonNull(position, "position is null");
        return nearPosition(position.method_10263(), position.method_10264(), position.method_10260(), serverLevel);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param posX        source position x
     * @param posY        source position y
     * @param posZ        source position z
     * @param serverLevel the current level
     */
    static PlayerSet nearPosition(double posX, double posY, double posZ, class_3218 serverLevel) {
        return nearPosition(null, posX, posY, posZ, 64.0, serverLevel);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param serverPlayer exclude player having caused this event
     * @param posX         source position x
     * @param posY         source position y
     * @param posZ         source position z
     * @param distance     allowed distance from source to receive message
     * @param serverLevel  the current level
     */
    static PlayerSet nearPosition(@Nullable class_3222 serverPlayer, double posX, double posY, double posZ, double distance, class_3218 serverLevel) {
        Objects.requireNonNull(serverLevel, "server level is null");
        return (class_2596<?> packet) -> {
            serverLevel.method_8503()
                    .method_3760()
                    .method_14605(serverPlayer, posX, posY, posZ, distance, serverLevel.method_27983(), packet);
        };
    }

    /**
     * Send message from server to all players tracking a block entity at a certain block position.
     *
     * @param blockEntity the block entity a player must track to receive this message
     */
    static PlayerSet nearBlockEntity(class_2586 blockEntity) {
        Objects.requireNonNull(blockEntity, "block entity is null");
        class_1937 level = blockEntity.method_10997();
        Objects.requireNonNull(level, "block entity level is null");
        Preconditions.checkState(!level.field_9236, "block entity level is client level");
        return nearPosition(blockEntity.method_11016(), (class_3218) level);
    }

    /**
     * Send message from server to all players tracking a chunk.
     *
     * @param levelChunk the chunk a player must track to receive this message
     */
    static PlayerSet nearChunk(class_2818 levelChunk) {
        Objects.requireNonNull(levelChunk, "chunk is null");
        Preconditions.checkState(!levelChunk.method_12200().field_9236, "chunk level is client level");
        return nearChunk((class_3218) levelChunk.method_12200(), levelChunk.method_12004());
    }

    /**
     * Send message from server to all players tracking a chunk.
     *
     * @param serverLevel the level containing the chunk
     * @param chunkPos    the chunk pos a player must track to receive this message
     */
    static PlayerSet nearChunk(class_3218 serverLevel, class_1923 chunkPos) {
        Objects.requireNonNull(serverLevel, "server level is null");
        Objects.requireNonNull(chunkPos, "chunk pos is null");
        return (class_2596<?> packet) -> {
            serverLevel.method_14178().field_17254.method_17210(chunkPos, false).forEach(serverPlayer -> {
                ofPlayer(serverPlayer).broadcast(packet);
            });
        };
    }

    /**
     * Send message from server to all players tracking a given entity.
     * <p>
     * When the entity is a player it will receive the message as well, otherwise use {@link #nearPlayer(class_3222)}.
     *
     * @param entity the tracked entity
     */
    static PlayerSet nearEntity(class_1297 entity) {
        Objects.requireNonNull(entity, "entity is null");
        Preconditions.checkState(!entity.method_5770().field_9236, "entity level is client level");
        return (class_2596<?> packet) -> {
            ((class_3218) entity.method_5770()).method_14178().method_18751(entity, packet);
        };
    }

    /**
     * Send message from server to all other players tracking a given player.
     * <p>
     * The player will not receive the message, for that use {@link #nearEntity(class_1297)}.
     *
     * @param serverPlayer the tracked player
     */
    static PlayerSet nearPlayer(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return (class_2596<?> packet) -> {
            serverPlayer.method_51469().method_14178().method_18754(serverPlayer, packet);
        };
    }
}
