package fuzs.puzzleslib.mixin.accessor;

import net.minecraft.class_1703;
import net.minecraft.class_1735;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_1703.class)
public interface AbstractContainerMenuAccessor {

    @Invoker("addSlot")
    class_1735 puzzleslib$callAddSlot(class_1735 slot);
}
