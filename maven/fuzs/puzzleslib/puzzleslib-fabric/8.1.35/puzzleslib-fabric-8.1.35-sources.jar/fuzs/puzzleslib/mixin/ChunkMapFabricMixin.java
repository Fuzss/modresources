package fuzs.puzzleslib.mixin;

import com.mojang.datafixers.DataFixer;
import fuzs.puzzleslib.api.event.v1.FabricLevelEvents;
import org.apache.commons.lang3.mutable.MutableObject;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import net.minecraft.class_1923;
import net.minecraft.class_2672;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3898;
import net.minecraft.class_3977;

@Mixin(class_3898.class)
abstract class ChunkMapFabricMixin extends class_3977 {
    @Shadow
    @Final
    class_3218 level;

    public ChunkMapFabricMixin(Path regionFolder, DataFixer fixerUpper, boolean sync) {
        super(regionFolder, fixerUpper, sync);
    }

    @Inject(method = "updateChunkTracking", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/level/ServerPlayer;untrackChunk(Lnet/minecraft/world/level/ChunkPos;)V", shift = At.Shift.AFTER))
    protected void updateChunkTracking(class_3222 player, class_1923 chunkPos, MutableObject<class_2672> packetCache, boolean wasLoaded, boolean load, CallbackInfo callback) {
        FabricLevelEvents.UNWATCH_CHUNK.invoker().onChunkUnwatch(player, chunkPos, this.level);
    }

    @Inject(method = "playerLoadedChunk", at = @At("TAIL"))
    private void playerLoadedChunk(class_3222 player, MutableObject<class_2672> packetCache, class_2818 chunk, CallbackInfo callback) {
        FabricLevelEvents.WATCH_CHUNK.invoker().onChunkWatch(player, chunk, this.level);
    }
}
