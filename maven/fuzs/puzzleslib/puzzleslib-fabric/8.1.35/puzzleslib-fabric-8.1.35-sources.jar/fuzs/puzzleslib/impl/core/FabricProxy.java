package fuzs.puzzleslib.impl.core;

import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import java.util.function.Function;
import java.util.function.IntFunction;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2792;
import net.minecraft.class_2960;

public interface FabricProxy extends ProxyImpl {

    <T extends MessageV2<T>> void registerLegacyClientReceiver(class_2960 channelName, Function<class_2540, T> factory);

    <T extends MessageV2<T>> void registerLegacyServerReceiver(class_2960 channelName, Function<class_2540, T> factory);
    
    <T extends Record & ClientboundMessage<T>> void registerClientReceiver(class_2960 channelName, Function<class_2540, T> factory);

    <T extends Record & ServerboundMessage<T>> void registerServerReceiver(class_2960 channelName, Function<class_2540, T> factory);

    default boolean shouldStartDestroyBlock(class_2338 blockPos) {
        throw new RuntimeException("Should start destroy block accessed for wrong side!");
    }

    default void startClientPrediction(class_1937 level, IntFunction<class_2596<class_2792>> predictiveAction) {
        throw new RuntimeException("Start client prediction accessed for wrong side!");
    }
}
