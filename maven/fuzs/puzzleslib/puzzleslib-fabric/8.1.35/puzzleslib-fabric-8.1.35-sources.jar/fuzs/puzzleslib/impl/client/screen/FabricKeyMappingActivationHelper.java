package fuzs.puzzleslib.impl.client.screen;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import fuzs.puzzleslib.api.client.event.v1.InputEvents;
import fuzs.puzzleslib.api.client.screen.v2.KeyMappingActivationHelper;
import fuzs.puzzleslib.api.event.v1.LoadCompleteCallback;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.Map;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_6599;

public final class FabricKeyMappingActivationHelper implements KeyMappingActivationHelper {
    private static final Multimap<KeyActivationContext, class_304> KEY_MAPPINGS_BY_ACTIVATION = Multimaps.newListMultimap(Maps.newEnumMap(KeyMappingActivationHelper.KeyActivationContext.class), Lists::newArrayList);
    private static final Map<class_304, KeyActivationContext> KEY_MAPPINGS_TO_ACTIVATION = Maps.newIdentityHashMap();

    {
        LoadCompleteCallback.EVENT.register(() -> {
            // copied from Forge, all this does is stop the key bindings screen from yelling at you for setting incompatible keys,
            // this does not invoke any of our other behaviors for actually implementing activation contexts
            // this implementation relies on careful consideration when setting activation contexts for our own keys
            class_315 options = class_310.method_1551().field_1690;
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1894, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1913, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1881, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1849, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1903, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1832, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1867, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1886, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1890, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1907, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1845, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1824, KeyActivationContext.GAME);
            KEY_MAPPINGS_TO_ACTIVATION.put(options.field_1816, KeyActivationContext.GAME);
        });
        // this would probably be much safer as a mixin on KeyMapping, but this is the way it is for now...
        Map<class_304, class_3675.class_306> keys = Maps.newLinkedHashMap();
        InputEvents.BEFORE_KEY_ACTION.register(EventPhase.LAST, (key, scanCode, action, modifiers) -> {
            this.clearKeys(keys, keyMapping -> keyMapping.method_1417(key, scanCode), () -> class_3675.method_15985(key, scanCode));
            return EventResult.PASS;
        });
        InputEvents.AFTER_KEY_ACTION.register(EventPhase.FIRST, (key, scanCode, action, modifiers) -> {
            this.setOriginalKeys(keys);
        });
        InputEvents.BEFORE_MOUSE_ACTION.register(EventPhase.LAST, (button, action, modifiers) -> {
            this.clearKeys(keys, keyMapping -> keyMapping.method_1433(button), () -> class_3675.class_307.field_1672.method_1447(button));
            return EventResult.PASS;
        });
        InputEvents.AFTER_MOUSE_ACTION.register(EventPhase.FIRST, (button, action, modifiers) -> {
            this.setOriginalKeys(keys);
        });
    }

    public static void setKeyActivationContext(class_304 keyMapping, KeyActivationContext keyActivationContext) {
        KEY_MAPPINGS_BY_ACTIVATION.put(keyActivationContext, keyMapping);
        KEY_MAPPINGS_TO_ACTIVATION.put(keyMapping, keyActivationContext);
    }

    @Override
    public KeyActivationContext getKeyActivationContext(class_304 keyMapping) {
        return KEY_MAPPINGS_TO_ACTIVATION.getOrDefault(keyMapping, KeyActivationContext.UNIVERSAL);
    }

    private void clearKeys(Map<class_304, class_3675.class_306> keys, Predicate<class_304> filter, Supplier<class_3675.class_306> key) {
        // if after events are unable to run and the map isn't cleared, stop here to not mess everything up completely
        if (!keys.isEmpty()) return;
        class_437 screen = class_310.method_1551().field_1755;
        // key bindings screen needs all input, so just exclude that
        if (!(screen instanceof class_6599)) {
            KeyMappingActivationHelper.KeyActivationContext inactive = screen != null ? KeyMappingActivationHelper.KeyActivationContext.GAME : KeyMappingActivationHelper.KeyActivationContext.SCREEN;
            KEY_MAPPINGS_BY_ACTIVATION.get(inactive).forEach(keyMapping -> {
                if (filter.test(keyMapping)) {
                    // set key for mapping instance to unknown, so it doesn't run during screen processing
                    keys.put(keyMapping, key.get());
                    keyMapping.method_1422(class_3675.field_16237);
                }
            });
        }
    }

    private void setOriginalKeys(Map<class_304, class_3675.class_306> keys) {
        keys.forEach(class_304::method_1422);
        keys.keySet().forEach(keyMapping -> {
            // disable key states for mapping instances processed by client tick methods
            keyMapping.method_23481(false);
            while (keyMapping.method_1436()) {}
        });
        keys.clear();
    }
}
