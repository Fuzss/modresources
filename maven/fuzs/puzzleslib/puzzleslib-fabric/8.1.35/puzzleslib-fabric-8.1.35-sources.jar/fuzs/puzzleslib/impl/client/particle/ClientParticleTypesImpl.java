package fuzs.puzzleslib.impl.client.particle;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.client.particle.v1.ClientParticleTypes;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import net.minecraft.class_2394;
import net.minecraft.class_2960;
import net.minecraft.class_703;

public final class ClientParticleTypesImpl implements ClientParticleTypes {
    private final Map<String, ClientParticleTypesManager> clientParticleTypeManagers = Maps.newConcurrentMap();

    @Override
    public @Nullable class_703 createParticle(class_2960 identifier, class_2394 particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        ClientParticleTypesManager clientParticleTypesManager = this.clientParticleTypeManagers.get(identifier.method_12836());
        Objects.requireNonNull(clientParticleTypesManager, "client particle types manager is null");
        return clientParticleTypesManager.createParticle(identifier, particleData, x, y, z, xSpeed, ySpeed, zSpeed);
    }

    public ClientParticleTypesManager getParticleTypesManager(String modId) {
        return this.clientParticleTypeManagers.computeIfAbsent(modId, $ -> new ClientParticleTypesManager());
    }
}
