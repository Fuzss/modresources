package fuzs.puzzleslib.api.event.v1.server;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import java.util.function.Consumer;
import java.util.function.IntPredicate;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_60;

public final class LootTableLoadEvents {
    public static final EventInvoker<Replace> REPLACE = EventInvoker.lookup(Replace.class);
    public static final EventInvoker<Modify> MODIFY = EventInvoker.lookup(Modify.class);

    private LootTableLoadEvents() {

    }

    @FunctionalInterface
    public interface Replace {

        /**
         * Allows for replacing built-in {@link class_52}s on loading.
         * <p>To remove a loot table completely pass {@link class_52#field_948} to <code>lootTable</code>.
         * <p>The event does <b>NOT</b> fire for data pack-provided loot tables.
         *
         * @param identifier  the loot table id
         * @param table       the loot table that can be replaced
         */
        void onReplaceLootTable(class_2960 identifier, MutableValue<class_52> table);
    }

    @FunctionalInterface
    public interface Modify {

        /**
         * Allows changing of {@link class_55}s in a {@link class_52}.
         * <p>The event does <b>NOT</b> fire for data pack-provided loot tables.
         *
         * @param lootManager access to all loot tables
         * @param identifier  the loot table id
         * @param addPool     add a {@link class_55}
         * @param removePool  removes a pool at a given index, pools are indexed starting from 0;
         *                    returns if removing the pool was successful, which is the case when a pool at <code>index</code> has been found
         */
        void onModifyLootTable(class_60 lootManager, class_2960 identifier, Consumer<class_55> addPool, IntPredicate removePool);
    }
}
