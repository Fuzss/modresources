package fuzs.puzzleslib.impl.core;

import fuzs.puzzleslib.api.network.v3.ClientMessageListener;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import java.util.Collection;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;

public record ClientboundModListMessage(Collection<String> modList) implements ClientboundMessage<ClientboundModListMessage> {

    @Override
    public ClientMessageListener<ClientboundModListMessage> getHandler() {
        return new ClientMessageListener<>() {

            @Override
            public void handle(ClientboundModListMessage message, class_310 client, class_634 handler, class_746 player, class_638 level) {
                ModContext.acceptServersideMods(message.modList);
            }
        };
    }
}
