package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
abstract class ItemInHandRendererFabricMixin {

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void renderArmWithItem(class_742 abstractClientPlayer, float partialTick, float interpolatedPitch, class_1268 interactionHand, float swingProgress, class_1799 itemStack, float equipProgress, class_4587 poseStack, class_4597 multiBufferSource, int packedLight, CallbackInfo callback) {
        EventResult result = FabricClientEvents.RENDER_HAND.invoker().onRenderHand(abstractClientPlayer, interactionHand, itemStack, poseStack, multiBufferSource, packedLight, partialTick, interpolatedPitch, swingProgress, equipProgress);
        if (result.isInterrupt()) callback.cancel();
    }
}
