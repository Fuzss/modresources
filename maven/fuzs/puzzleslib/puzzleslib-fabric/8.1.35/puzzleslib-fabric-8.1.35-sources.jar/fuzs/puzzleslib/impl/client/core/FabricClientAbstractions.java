package fuzs.puzzleslib.impl.client.core;

import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import fuzs.puzzleslib.mixin.client.accessor.MinecraftFabricAccessor;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.class_1087;
import net.minecraft.class_1124;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

public final class FabricClientAbstractions implements ClientAbstractions {

    @Override
    public boolean isKeyActiveAndMatches(class_304 keyMapping, int keyCode, int scanCode) {
        return keyMapping.method_1417(keyCode, scanCode);
    }

    @Override
    public class_5684 createImageComponent(class_5632 imageComponent) {
        class_5684 component = TooltipComponentCallback.EVENT.invoker().getComponent(imageComponent);
        if (component != null) return component;
        return class_5684.method_32663(imageComponent);
    }

    @Override
    public class_1087 getBakedModel(class_2960 identifier) {
        return class_310.method_1551().method_1554().getModel(identifier);
    }

    @Override
    public class_1921 getRenderType(class_2248 block) {
        return class_4696.method_23679(block.method_9564());
    }

    @Override
    public void registerRenderType(class_2248 block, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putBlock(block, renderType);
    }

    @Override
    public void registerRenderType(class_3611 fluid, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putFluid(fluid, renderType);
    }

    @Override
    public float getPartialTick() {
        class_310 minecraft = class_310.method_1551();
        return minecraft.method_1493() ? ((MinecraftFabricAccessor) minecraft).puzzleslib$getPausePartialTick() : minecraft.method_1488();
    }

    @Override
    public class_1124 getSearchRegistry() {
        return ((MinecraftFabricAccessor) class_310.method_1551()).puzzleslib$getSearchRegistry();
    }
}
