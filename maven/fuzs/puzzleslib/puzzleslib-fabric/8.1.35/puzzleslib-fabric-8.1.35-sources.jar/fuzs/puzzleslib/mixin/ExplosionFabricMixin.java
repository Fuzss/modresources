package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLevelEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;

@Mixin(class_1927.class)
abstract class ExplosionFabricMixin {
    @Shadow
    @Final
    private class_1937 level;

    @ModifyVariable(method = "explode", at = @At("STORE"), ordinal = 0)
    public List<class_1297> explode(List<class_1297> entities) {
        FabricLevelEvents.EXPLOSION_DETONATE.invoker().onExplosionDetonate(this.level, class_1927.class.cast(this), this.getToBlow(), entities);
        return entities;
    }

    @Shadow
    public abstract List<class_2338> getToBlow();
}
