package fuzs.puzzleslib.mixin.client.accessor;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_5481;
import net.minecraft.class_7919;

@Mixin(class_7919.class)
public interface TooltipAccessor {

    @Accessor("cachedTooltip")
    void puzzleslib$setCachedTooltip(@Nullable List<class_5481> cachedTooltip);
}
