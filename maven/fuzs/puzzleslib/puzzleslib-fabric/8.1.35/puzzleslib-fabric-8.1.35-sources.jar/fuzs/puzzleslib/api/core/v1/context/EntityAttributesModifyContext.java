package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;

/**
 * registers modifications to attributes of already existing entities (not from our mod)
 */
@FunctionalInterface
public interface EntityAttributesModifyContext {

    /**
     * use this method for modifying attributes of existing entity types
     * this overrides/adds attributes individually as this is what is done on Forge
     *
     * @param entityType type of entity
     * @param attribute  attribute to override/add
     */
    default void registerAttributeModification(class_1299<? extends class_1309> entityType, class_1320 attribute) {
        this.registerAttributeModification(entityType, attribute, attribute.method_6169());
    }

    /**
     * use this method for modifying attributes of existing entity types
     * this overrides/adds attributes individually as this is what is done on Forge
     *
     * @param entityType     type of entity
     * @param attribute      attribute to override/add
     * @param attributeValue new value, possibly {@link class_1320#method_6169()}
     */
    void registerAttributeModification(class_1299<? extends class_1309> entityType, class_1320 attribute, double attributeValue);
}
