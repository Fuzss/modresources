package fuzs.puzzleslib.api.item.v2;

import fuzs.puzzleslib.impl.core.CommonFactories;
import net.minecraft.class_1743;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1787;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1810;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1829;
import net.minecraft.class_1835;
import net.minecraft.class_3489;
import net.minecraft.world.item.*;

/**
 * A small helper class for testing an item stack for a given tool type.
 * <p>Mainly exists for handling item tags across different mod loaders as well as Forge's <code>net.minecraftforge.common.ToolAction</code> feature.
 * <p>Inspired by <a href="https://github.com/ricksouth/serilum-mc-mod-sources/blob/main/sources/Collective/1.20.0/Common/src/main/java/com/natamus/collective/services/helpers/ToolFunctionsHelper.java">ToolFunctionsHelper.java</a> found in the <a href="https://github.com/ricksouth/serilum-mc-mod-sources/tree/main/sources/Collective">Collective</a> mod.
 */
public interface ToolTypeHelper {
    ToolTypeHelper INSTANCE = CommonFactories.INSTANCE.getToolTypeHelper();

    /**
     * Tests if an {@link class_1799} is a sword.
     *
     * @param stack the stack to test
     * @return is this stack a sword
     */
    default boolean isSword(class_1799 stack) {
        return stack.method_7909() instanceof class_1829 || stack.method_31573(class_3489.field_42611);
    }

    /**
     * Tests if an {@link class_1799} is an axe.
     *
     * @param stack the stack to test
     * @return is this stack an axe
     */
    default boolean isAxe(class_1799 stack) {
        return stack.method_7909() instanceof class_1743 || stack.method_31573(class_3489.field_42612);
    }

    /**
     * Tests if an {@link class_1799} is a hoe.
     *
     * @param stack the stack to test
     * @return is this stack a hoe
     */
    default boolean isHoe(class_1799 stack) {
        return stack.method_7909() instanceof class_1794 || stack.method_31573(class_3489.field_42613);
    }

    /**
     * Tests if an {@link class_1799} is a pickaxe.
     *
     * @param stack the stack to test
     * @return is this stack a pickaxe
     */
    default boolean isPickaxe(class_1799 stack) {
        return stack.method_7909() instanceof class_1810 || stack.method_31573(class_3489.field_42614);
    }

    /**
     * Tests if an {@link class_1799} is a shovel.
     *
     * @param stack the stack to test
     * @return is this stack a shovel
     */
    default boolean isShovel(class_1799 stack) {
        return stack.method_7909() instanceof class_1743 || stack.method_31573(class_3489.field_42615);
    }

    /**
     * Tests if an {@link class_1799} is a shears item.
     *
     * @param stack the stack to test
     * @return is this stack a shears item
     */
    default boolean isShears(class_1799 stack) {
        return stack.method_7909() instanceof class_1820;
    }

    /**
     * Tests if an {@link class_1799} is a shield.
     *
     * @param stack the stack to test
     * @return is this stack a shield
     */
    default boolean isShield(class_1799 stack) {
        return stack.method_7909() instanceof class_1819;
    }

    /**
     * Tests if an {@link class_1799} is a bow.
     *
     * @param stack the stack to test
     * @return is this stack a bow
     */
    default boolean isBow(class_1799 stack) {
        return stack.method_7909() instanceof class_1753;
    }

    /**
     * Tests if an {@link class_1799} is a crossbow.
     *
     * @param stack the stack to test
     * @return is this stack a crossbow
     */
    default boolean isCrossbow(class_1799 stack) {
        return stack.method_7909() instanceof class_1764;
    }

    /**
     * Tests if an {@link class_1799} is a fishing rod.
     *
     * @param stack the stack to test
     * @return is this stack a fishing rod
     */
    default boolean isFishingRod(class_1799 stack) {
        return stack.method_7909() instanceof class_1787;
    }

    /**
     * Tests if an {@link class_1799} is similar to a trident, like a spear.
     *
     * @param stack the stack to test
     * @return is this stack a trident
     */
    @Deprecated(forRemoval = true)
    default boolean isTrident(class_1799 stack) {
        return this.isTridentLike(stack);
    }

    /**
     * Tests if an {@link class_1799} is similar to a trident, like a spear.
     *
     * @param stack the stack to test
     * @return is this stack a trident
     */
    default boolean isTridentLike(class_1799 stack) {
        return stack.method_7909() instanceof class_1835;
    }

    /**
     * Tests if an {@link class_1799} is a weapon used for melee combat.
     *
     * @param stack the stack to test
     * @return is this stack a melee weapon
     */
    default boolean isMeleeWeapon(class_1799 stack) {
        return this.isSword(stack) || this.isAxe(stack) || this.isTridentLike(stack);
    }

    /**
     * Tests if an {@link class_1799} is a weapon used for ranged combat.
     *
     * @param stack the stack to test
     * @return is this stack a ranged weapon
     */
    default boolean isRangedWeapon(class_1799 stack) {
        return this.isBow(stack) || this.isCrossbow(stack) || this.isTridentLike(stack);
    }

    /**
     * Tests if an {@link class_1799} is a weapon.
     *
     * @param stack the stack to test
     * @return is this stack a weapon
     */
    default boolean isWeapon(class_1799 stack) {
        return this.isMeleeWeapon(stack) || this.isRangedWeapon(stack);
    }

    /**
     * Tests if an {@link class_1799} is a tool used for mining blocks.
     *
     * @param stack the stack to test
     * @return is this stack a mining tool
     */
    default boolean isMiningTool(class_1799 stack) {
        return this.isAxe(stack) || this.isHoe(stack) || this.isPickaxe(stack) || this.isShovel(stack);
    }

    /**
     * Tests if an {@link class_1799} is any sort of tool, mainly in the sense of {@link class_3489#field_42616}.
     *
     * @param stack the stack to test
     * @return is this stack a tool
     */
    default boolean isTool(class_1799 stack) {
        return this.isMiningTool(stack) || this.isMeleeWeapon(stack) || stack.method_31573(class_3489.field_42616);
    }
}
