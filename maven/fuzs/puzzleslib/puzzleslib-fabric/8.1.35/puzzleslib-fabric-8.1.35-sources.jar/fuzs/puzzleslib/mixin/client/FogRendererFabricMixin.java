package fuzs.puzzleslib.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_6854;
import net.minecraft.class_758;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_758.class)
abstract class FogRendererFabricMixin {
    @Shadow
    private static float fogRed;
    @Shadow
    private static float fogGreen;
    @Shadow
    private static float fogBlue;

    @Inject(method = "setupColor", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;clearColor(FFFF)V", ordinal = 1))
    private static void setupColor(class_4184 activeRenderInfo, float partialTicks, class_638 level, int renderDistanceChunks, float bossColorModifier, CallbackInfo callback) {
        class_310 minecraft = class_310.method_1551();
        MutableFloat red = MutableFloat.fromEvent(t -> fogRed = t, () -> fogRed);
        MutableFloat green = MutableFloat.fromEvent(t -> fogGreen = t, () -> fogGreen);
        MutableFloat blue = MutableFloat.fromEvent(t -> fogBlue = t, () -> fogBlue);
        FabricClientEvents.COMPUTE_FOG_COLOR.invoker().onComputeFogColor(minecraft.field_1773, activeRenderInfo, partialTicks, red, green, blue);
    }

    @Inject(method = "setupFog", at = @At("TAIL"), locals = LocalCapture.CAPTURE_FAILHARD)
    private static void setupFog(class_4184 camera, class_758.class_4596 fogMode, float farPlaneDistance, boolean bl, float f, CallbackInfo callback, class_5636 fogType) {
        class_310 minecraft = class_310.method_1551();
        MutableFloat fogStart = MutableFloat.fromEvent(RenderSystem::setShaderFogStart, RenderSystem::getShaderFogStart);
        MutableFloat fogEnd = MutableFloat.fromEvent(RenderSystem::setShaderFogEnd, RenderSystem::getShaderFogEnd);
        MutableValue<class_6854> fogShape = MutableValue.fromEvent(RenderSystem::setShaderFogShape, RenderSystem::getShaderFogShape);
        FabricClientEvents.RENDER_FOG.invoker().onRenderFog(minecraft.field_1773, camera, f, fogMode, fogType, fogStart, fogEnd, fogShape);
    }
}
