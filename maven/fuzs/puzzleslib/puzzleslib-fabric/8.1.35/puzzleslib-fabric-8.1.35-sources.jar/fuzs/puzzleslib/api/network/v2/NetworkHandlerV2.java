package fuzs.puzzleslib.api.network.v2;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.api.core.v1.Proxy;
import fuzs.puzzleslib.impl.core.ModContext;
import org.jetbrains.annotations.Nullable;

import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2792;
import net.minecraft.class_3215;
import net.minecraft.class_3222;
import net.minecraft.class_5321;

/**
 * handler for network communications of all puzzles lib mods
 */
public interface NetworkHandlerV2 {

    /**
     * Creates a new network handler.
     *
     * @param modId id for channel name
     * @return mod specific network handler with default channel
     */
    static NetworkHandlerV2 build(String modId) {
        return build(modId, null);
    }

    /**
     * Creates a new network handler.
     *
     * @param modId   id for channel name
     * @param context an internal id for this channel in case multiple are registered using the same mod id
     * @return mod specific network handler with default channel
     */
    static NetworkHandlerV2 build(String modId, @Nullable String context) {
        return build(modId, context, false, false);
    }

    /**
     * Creates a new network handler.
     *
     * @param modId                         id for channel name
     * @param clientAcceptsVanillaOrMissing are servers without this mod or vanilla compatible
     * @param serverAcceptsVanillaOrMissing are clients without this mod or vanilla compatible
     * @return mod specific network handler with configured channel
     */
    static NetworkHandlerV2 build(String modId, boolean clientAcceptsVanillaOrMissing, boolean serverAcceptsVanillaOrMissing) {
        return build(modId, null, clientAcceptsVanillaOrMissing, serverAcceptsVanillaOrMissing);
    }

    /**
     * Creates a new network handler.
     *
     * @param modId                         id for channel name
     * @param context                            an internal id for this channel in case multiple are registered using the same mod id
     * @param clientAcceptsVanillaOrMissing are servers without this mod or vanilla compatible
     * @param serverAcceptsVanillaOrMissing are clients without this mod or vanilla compatible
     * @return mod specific network handler with configured channel
     */
    static NetworkHandlerV2 build(String modId, @Nullable String context, boolean clientAcceptsVanillaOrMissing, boolean serverAcceptsVanillaOrMissing) {
        return ModContext.get(modId).getNetworkHandlerV2(context, clientAcceptsVanillaOrMissing, serverAcceptsVanillaOrMissing);
    }

    /**
     * register a message for a side
     *
     * @param clazz     message class type
     * @param supplier  supplier for message (called when receiving at executing end)
     *                  we use this additional supplier to avoid having to invoke the class via reflection
     *                  and so that a default constructor in every message cannot be forgotten
     * @param direction side this message is to be executed at
     * @param <T>       message implementation
     */
    @Deprecated(forRemoval = true)
    <T extends MessageV2<T>> void register(Class<? extends T> clazz, Supplier<T> supplier, MessageDirection direction);

    /**
     * Register a message that will be sent to clients.
     *
     * @param clazz message class type
     * @param <T>   message implementation
     */
    <T extends MessageV2<T>> NetworkHandlerV2 registerClientbound(Class<T> clazz);

    /**
     * Register a message that will be sent to servers.
     *
     * @param clazz message class type
     * @param <T>   message implementation
     */
    <T extends MessageV2<T>> NetworkHandlerV2 registerServerbound(Class<T> clazz);

    /**
     * creates a packet heading to the server side
     *
     * @param message message to create packet from
     * @return packet for message
     */
    class_2596<class_2792> toServerboundPacket(MessageV2<?> message);

    /**
     * creates a packet heading to the client side
     *
     * @param message message to create packet from
     * @return packet for message
     */
    class_2596<class_2602> toClientboundPacket(MessageV2<?> message);

    /**
     * send message from client to server
     *
     * @param message message to send
     */
    default void sendToServer(MessageV2<?> message) {
        Proxy.INSTANCE.getClientPacketListener().method_2883(this.toServerboundPacket(message));
    }

    /**
     * send message from server to client
     *
     * @param message message to send
     * @param player  client player to send to
     */
    default void sendTo(MessageV2<?> message, class_3222 player) {
        player.field_13987.method_14364(this.toClientboundPacket(message));
    }

    /**
     * send message from server to all clients
     *
     * @param message message to send
     */
    default void sendToAll(MessageV2<?> message) {
        CommonAbstractions.INSTANCE.getMinecraftServer().method_3760().method_14581(this.toClientboundPacket(message));
    }

    /**
     * send message from server to all clients except one
     *
     * @param message message to send
     * @param exclude client to exclude
     */
    default void sendToAllExcept(MessageV2<?> message, class_3222 exclude) {
        for (class_3222 player : CommonAbstractions.INSTANCE.getMinecraftServer().method_3760().method_14571()) {
            if (player != exclude) this.sendTo(message, player);
        }
    }

    /**
     * send message from server to all clients near given position
     *
     * @param message message to send
     * @param pos     source position
     * @param level   dimension key provider level
     */
    default void sendToAllNear(MessageV2<?> message, class_2338 pos, class_1937 level) {
        this.sendToAllNearExcept(message, null, pos.method_10263(), pos.method_10264(), pos.method_10260(), 64.0, level);
    }

    /**
     * send message from server to all clients near given position
     *
     * @param message  message to send
     * @param posX     source position x
     * @param posY     source position y
     * @param posZ     source position z
     * @param distance distance from source to receive message
     * @param level    dimension key provider level
     */
    default void sendToAllNear(MessageV2<?> message, double posX, double posY, double posZ, double distance, class_1937 level) {
        this.sendToAllNearExcept(message, null, posX, posY, posZ, 64.0, level);
    }

    /**
     * send message from server to all clients near given position
     *
     * @param message  message to send
     * @param exclude  exclude player having caused this event
     * @param posX     source position x
     * @param posY     source position y
     * @param posZ     source position z
     * @param distance distance from source to receive message
     * @param level    dimension key provider level
     */
    default void sendToAllNearExcept(MessageV2<?> message, @Nullable class_3222 exclude, double posX, double posY, double posZ, double distance, class_1937 level) {
        CommonAbstractions.INSTANCE.getMinecraftServer().method_3760().method_14605(exclude, posX, posY, posZ, distance, level.method_27983(), this.toClientboundPacket(message));
    }

    /**
     * send message from server to all clients tracking <code>entity</code>
     *
     * @param message message to send
     * @param entity  the tracked entity
     */
    default void sendToAllTracking(MessageV2<?> message, class_1297 entity) {
        ((class_3215) entity.method_5770().method_8398()).method_18754(entity, this.toClientboundPacket(message));
    }

    /**
     * send message from server to all clients tracking <code>entity</code> including the entity itself
     *
     * @param message message to send
     * @param entity  the tracked entity
     */
    default void sendToAllTrackingAndSelf(MessageV2<?> message, class_1297 entity) {
        ((class_3215) entity.method_5770().method_8398()).method_18751(entity, this.toClientboundPacket(message));
    }

    /**
     * send message from server to all clients in dimension
     *
     * @param message message to send
     * @param level   dimension key provider level
     */
    default void sendToDimension(MessageV2<?> message, class_1937 level) {
        this.sendToDimension(message, level.method_27983());
    }

    /**
     * send message from server to all clients in dimension
     *
     * @param message   message to send
     * @param dimension dimension to send message in
     */
    default void sendToDimension(MessageV2<?> message, class_5321<class_1937> dimension) {
        CommonAbstractions.INSTANCE.getMinecraftServer().method_3760().method_14589(this.toClientboundPacket(message), dimension);
    }
}
