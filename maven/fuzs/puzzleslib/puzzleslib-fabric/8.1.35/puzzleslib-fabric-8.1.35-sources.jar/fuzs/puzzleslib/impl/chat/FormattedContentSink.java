package fuzs.puzzleslib.impl.chat;

import com.google.common.collect.Lists;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3902;
import net.minecraft.class_5224;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public class FormattedContentSink implements class_5348.class_5246<class_3902>, class_5224 {
    private final List<Map.Entry<StringBuilder, class_2583>> builders = Lists.newArrayList(Map.entry(new StringBuilder(), class_2583.field_24360));
    @Nullable
    private class_2561 component;

    public FormattedContentSink(class_5348 formattedText) {
        if (formattedText instanceof class_2561) {
            this.component = ((class_2561) formattedText).method_27661();
        } else {
            formattedText.method_27658(this, class_2583.field_24360);
        }
    }

    public FormattedContentSink(class_5481 formattedCharSequence) {
        formattedCharSequence.accept(this);
    }

    @Override
    public Optional<class_3902> accept(class_2583 style, String string) {
        Map.Entry<StringBuilder, class_2583> entry = this.builders.get(this.builders.size() - 1);
        if (entry.getValue() == style) {
            entry.getKey().append(string);
        } else {
            this.builders.add(Map.entry(new StringBuilder(string), style));
        }
        return Optional.empty();
    }

    @Override
    public boolean accept(int width, class_2583 style, int codePoint) {
        this.accept(style, String.valueOf(Character.toChars(codePoint)));
        return true;
    }

    public class_2561 getComponent() {
        if (this.component == null) {
            class_5250 component = class_2561.method_43470(this.builders.get(0).getKey().toString()).method_10862(this.builders.get(0).getValue());
            for (int i = 1; i < this.builders.size(); i++) {
                Map.Entry<StringBuilder, class_2583> entry = this.builders.get(i);
                component.method_10852(class_2561.method_43470(entry.getKey().toString()).method_10862(entry.getValue()));
            }
            this.component = component;
        }
        return this.component;
    }
}
