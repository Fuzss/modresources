package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricEntityEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1665;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;

@Mixin(class_1665.class)
abstract class AbstractArrowFabricMixin extends class_1676 {
    @Unique
    private boolean puzzleslib$interruptHitEntity;

    public AbstractArrowFabricMixin(class_1299<? extends class_1676> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "tick", at = @At(value = "LOAD", ordinal = 0), ordinal = 0, slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;canHarmPlayer(Lnet/minecraft/world/entity/player/Player;)Z")))
    public class_239 tick$0(@Nullable class_239 hitResult) {
        if (this.isNoPhysics() || hitResult == null || hitResult.method_17783() == class_239.class_240.field_1333) return hitResult;
        if (FabricEntityEvents.PROJECTILE_IMPACT.invoker().onProjectileImpact(this, hitResult).isInterrupt()) {
            this.puzzleslib$interruptHitEntity = true;
            // null is desired here as the implementation doesn't check for HitResult$Type#MISS as most others
            // we don't implement this by overriding Projectile::onHit as this is an abstract class where Projectile::onHit will likely be overridden by subclasses
            return null;
        } else {
            this.puzzleslib$interruptHitEntity = false;
            return hitResult;
        }
    }

    @Shadow
    public abstract boolean isNoPhysics();

    @ModifyVariable(method = "tick", at = @At(value = "LOAD", ordinal = 0), ordinal = 0, slice = @Slice(from = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;canHarmPlayer(Lnet/minecraft/world/entity/player/Player;)Z")))
    public class_3966 tick$1(class_3966 hitResult) {
        if (this.puzzleslib$interruptHitEntity) {
            hitResult = null;
            this.puzzleslib$interruptHitEntity = false;
        }
        return hitResult;
    }
}
