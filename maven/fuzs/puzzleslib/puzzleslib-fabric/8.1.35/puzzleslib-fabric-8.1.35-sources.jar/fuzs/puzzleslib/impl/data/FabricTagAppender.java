package fuzs.puzzleslib.impl.data;

import fuzs.puzzleslib.api.data.v2.tags.AbstractTagAppender;
import net.fabricmc.fabric.impl.datagen.FabricTagBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_3497;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class FabricTagAppender<T> extends AbstractTagAppender<T> {
    private final List<class_3497> removeEntries = new ArrayList<>();

    public FabricTagAppender(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        super(tagBuilder, keyExtractor);
    }

    @SuppressWarnings("UnstableApiUsage")
    @Override
    public AbstractTagAppender<T> setReplace(boolean replace) {
        ((FabricTagBuilder) this.tagBuilder).fabric_setReplace(replace);
        return this;
    }

    @Override
    public AbstractTagAppender<T> remove(class_2960 resourceLocation) {
        // only fully supported on NeoForge
        this.removeEntries.add(class_3497.method_43937(resourceLocation));
        return this;
    }

    @Override
    public AbstractTagAppender<T> removeTag(class_2960 resourceLocation) {
        // only fully supported on NeoForge
        this.removeEntries.add(class_3497.method_43945(resourceLocation));
        return this;
    }

    @Override
    public List<String> asStringList() {
        List<String> list = new ArrayList<>();
        for (class_3497 tagEntry : this.tagBuilder.method_26782()) {
            list.add(tagEntry.toString());
        }
        for (class_3497 tagEntry : this.removeEntries) {
            list.add("!" + tagEntry);
        }
        return list;
    }
}
