package fuzs.puzzleslib.api.client.data.v2;

import com.google.gson.JsonObject;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v2.RegistryReference;
import org.jetbrains.annotations.ApiStatus;

import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_156;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1842;
import net.minecraft.class_1887;
import net.minecraft.class_1928;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3414;
import net.minecraft.class_3448;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public abstract class AbstractLanguageProvider implements class_2405 {
    protected final String languageCode;
    protected final String modId;
    protected final class_7784.class_7489 pathProvider;

    public AbstractLanguageProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput());
    }

    public AbstractLanguageProvider(String languageCode, DataProviderContext context) {
        this(languageCode, context.getModId(), context.getPackOutput());
    }

    public AbstractLanguageProvider(String modId, class_7784 packOutput) {
        this("en_us", modId, packOutput);
    }

    public AbstractLanguageProvider(String languageCode, String modId, class_7784 packOutput) {
        this.languageCode = languageCode;
        this.modId = modId;
        this.pathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "lang");
    }

    protected abstract void addTranslations(TranslationBuilder builder);

    @Override
    public CompletableFuture<?> method_10319(class_7403 writer) {
        JsonObject jsonObject = new JsonObject();
        this.addTranslations((String key, String value) -> {
            Objects.requireNonNull(key, "key is null");
            Objects.requireNonNull(value, "value is null");
            if (jsonObject.has(key)) {
                throw new IllegalStateException("Duplicate translation key found: " + key);
            } else {
                jsonObject.addProperty(key, value);
            }
        });
        return class_2405.method_10320(writer, jsonObject, this.pathProvider.method_44107(new class_2960(this.modId, this.languageCode)));
    }

    @Override
    public String method_10321() {
        return "Language (%s)".formatted(this.languageCode);
    }

    @ApiStatus.NonExtendable
    @FunctionalInterface
    public interface TranslationBuilder {

        void add(String key, String value);

        default void add(String key, String additionalKey, String value) {
            Objects.requireNonNull(additionalKey, "additional key is null");
            this.add(key + (additionalKey.isEmpty() ? "" : "." + additionalKey), value);
        }

        default void add(class_2960 identifier, String value) {
            this.add(identifier, "", value);
        }

        default void add(class_2960 identifier, String additionalKey, String value) {
            Objects.requireNonNull(identifier, "identifier is null");
            this.add(identifier.method_42094(), additionalKey, value);
        }

        default void add(String registry, RegistryReference<?> holder, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(holder, "holder is null");
            this.add(registry, holder.getResourceKey(), value);
        }

        default void add(String registry, class_6880.class_6883<?> holder, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(holder, "holder is null");
            this.add(registry, holder.method_40237(), value);
        }

        default void add(String registry, class_5321<?> resourceKey, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(resourceKey, "resource key is null");
            this.add(registry, resourceKey.method_29177(), value);
        }

        default void add(String registry, class_2960 resourceLocation, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(resourceLocation, "resource location is null");
            this.add(class_156.method_646(registry, resourceLocation), value);
        }

        default void add(class_2248 block, String value) {
            this.add(block, "", value);
        }

        default void add(class_2248 block, String additionalKey, String value) {
            Objects.requireNonNull(block, "block is null");
            this.add(block.method_9539(), additionalKey, value);
        }

        default void add(class_1792 item, String value) {
            this.add(item, "", value);
        }

        default void add(class_1792 item, String additionalKey, String value) {
            Objects.requireNonNull(item, "item is null");
            this.add(item.method_7876(), additionalKey, value);
        }

        default void add(class_1887 enchantment, String value) {
            this.add(enchantment, "", value);
        }

        default void add(class_1887 enchantment, String additionalKey, String value) {
            Objects.requireNonNull(enchantment, "enchantment is null");
            this.add(enchantment.method_8184(), additionalKey, value);
        }

        default void add(class_1291 mobEffect, String value) {
            this.add(mobEffect, "", value);
        }

        default void add(class_1291 mobEffect, String additionalKey, String value) {
            Objects.requireNonNull(mobEffect, "mob effect is null");
            this.add(mobEffect.method_5567(), additionalKey, value);
        }

        default void add(class_1299<?> entityType, String value) {
            this.add(entityType, "", value);
        }

        default void add(class_1299<?> entityType, String additionalKey, String value) {
            Objects.requireNonNull(entityType, "entity type is null");
            this.add(entityType.method_5882(), additionalKey, value);
        }

        default void add(class_1320 attribute, String value) {
            this.add(attribute, "", value);
        }

        default void add(class_1320 attribute, String additionalKey, String value) {
            Objects.requireNonNull(attribute, "attribute is null");
            this.add(attribute.method_26830(), additionalKey, value);
        }

        default void add(class_3448<?> statType, String value) {
            this.add(statType, "", value);
        }

        default void add(class_3448<?> statType, String additionalKey, String value) {
            Objects.requireNonNull(statType, "stat type is null");
            this.add(statType.method_14957(), additionalKey, value);
        }

        default void add(class_1928.class_4313<?> gameRule, String value) {
            this.add(gameRule, "", value);
        }

        default void addGameRuleDescription(class_1928.class_4313<?> gameRule, String value) {
            this.add(gameRule, "description", value);
        }

        default void add(class_1928.class_4313<?> gameRule, String additionalKey, String value) {
            Objects.requireNonNull(gameRule, "game rule is null");
            this.add(gameRule.method_27334(), additionalKey, value);
        }

        default void add(class_1842 potion, String value) {
            Objects.requireNonNull(potion, "potion is null");
            String potionName = potion.method_8051("");
            this.add("item.minecraft.tipped_arrow.effect." + potionName, "Arrow of " + value);
            this.add("item.minecraft.potion.effect." + potionName, "Potion of " + value);
            this.add("item.minecraft.splash_potion.effect." + potionName, "Splash Potion of " + value);
            this.add("item.minecraft.lingering_potion.effect." + potionName, "Lingering Potion of " + value);
        }

        default void add(class_3414 soundEvent, String value) {
            Objects.requireNonNull(soundEvent, "sound event is null");
            this.add("subtitles." + soundEvent.method_14833().method_12832(), value);
        }

        default void add(class_304 keyMapping, String value) {
            Objects.requireNonNull(keyMapping, "key mapping is null");
            this.add(keyMapping.method_1431(), value);
        }

        default void addCreativeModeTab(String modId, String value) {
            this.addCreativeModeTab(modId, "main", value);
        }

        default void addCreativeModeTab(String modId, String tabId, String value) {
            Objects.requireNonNull(modId, "mod id is null");
            Objects.requireNonNull(tabId, "tab id is null");
            this.addCreativeModeTab(new class_2960(modId, tabId), value);
        }

        default void addCreativeModeTab(class_2960 identifier, String value) {
            Objects.requireNonNull(identifier, "identifier is null");
            this.addCreativeModeTab(class_5321.method_29179(class_7924.field_44688, identifier), value);
        }

        default void addCreativeModeTab(class_5321<class_1761> resourceKey, String value) {
            Objects.requireNonNull(resourceKey, "resource key is null");
            this.add(class_7923.field_44687.method_29107(resourceKey), value);
        }

        default void add(class_1761 tab, String value) {
            Objects.requireNonNull(tab, "tab is null");
            this.add(tab.method_7737(), value);
        }

        default void add(class_2561 component, String value) {
            Objects.requireNonNull(component, "component is null");
            if (component.method_10851() instanceof class_2588 contents) {
                this.add(contents.method_11022(), value);
            } else {
                throw new UnsupportedOperationException("Unsupported component: " + component);
            }
        }

        default void addGenericDamageType(class_5321<class_8110> damageType, String value) {
            Objects.requireNonNull(damageType, "damage type is null");
            this.add("death.attack." + damageType.method_29177().method_12832(), value);
        }

        default void addPlayerDamageType(class_5321<class_8110> damageType, String value) {
            Objects.requireNonNull(damageType, "damage type is null");
            this.add("death.attack." + damageType.method_29177().method_12832() + ".player", value);
        }

        default void addItemDamageType(class_5321<class_8110> damageType, String value) {
            Objects.requireNonNull(damageType, "damage type is null");
            this.add("death.attack." + damageType.method_29177().method_12832() + ".item", value);
        }
    }
}
