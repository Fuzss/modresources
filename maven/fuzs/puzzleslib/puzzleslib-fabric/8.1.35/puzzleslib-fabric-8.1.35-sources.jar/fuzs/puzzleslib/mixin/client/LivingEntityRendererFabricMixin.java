package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
abstract class LivingEntityRendererFabricMixin<T extends class_1309, M extends class_583<T>> extends class_897<T> {

    protected LivingEntityRendererFabricMixin(class_5617.class_5618 context) {
        super(context);
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    public void render$0(T entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo callback) {
        EventResult result = FabricClientEvents.BEFORE_RENDER_LIVING.invoker().onBeforeRenderEntity(entity, class_922.class.cast(this), partialTicks, matrixStack, buffer, packedLight);
        if (result.isInterrupt()) callback.cancel();
    }

    @Inject(method = "render", at = @At("TAIL"))
    public void render$1(T entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo callback) {
        FabricClientEvents.AFTER_RENDER_LIVING.invoker().onAfterRenderEntity(entity, class_922.class.cast(this), partialTicks, matrixStack, buffer, packedLight);
    }
}
