package fuzs.puzzleslib.impl.client.init;

import fuzs.puzzleslib.api.client.init.v1.ModelLayerFactory;
import net.minecraft.class_2960;
import net.minecraft.class_5601;

public record ModelLayerFactoryImpl(String namespace) implements ModelLayerFactory {

    @Override
    public class_5601 register(String path) {
        return this.register(path, "main");
    }

    @Override
    public class_5601 register(String path, String layer) {
        return new class_5601(new class_2960(this.namespace, path), layer);
    }

    @Override
    public class_5601 registerInnerArmor(String path) {
        return this.register(path, "inner_armor");
    }

    @Override
    public class_5601 registerOuterArmor(String path) {
        return this.register(path, "outer_armor");
    }
}
