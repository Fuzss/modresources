package fuzs.puzzleslib.api.init.v2;

import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/**
 * Represents a lazy wrapper for registry object.
 * <p>Copied and adapted from <a href="https://github.com/jaredlll08/MultiLoader-Template/blob/1.18.2/examples/MultiLoader-Template-with-registration/Fabric/src/main/java/com/example/examplemod/FabricRegistrationFactory.java">FabricRegistrationFactory.java</a>
 *
 * @param <T> the type of the object
 */
public interface RegistryReference<T> {

    /**
     * Get access to the {@link class_2378} of the wrapped object
     *
     * @return the registry key of the registry this reference is part of
     */
    class_5321<? extends class_2378<? super T>> getRegistryKey();

    /**
     * Gets the {@link class_5321} of the registry of the object wrapped.
     *
     * @return the {@link class_5321} of the registry
     */
    class_5321<T> getResourceKey();

    /**
     * Gets the id of the object.
     *
     * @return the id of the object
     */
    class_2960 getResourceLocation();

    /**
     * Gets the object behind this wrapper. Calling this method too early
     * might result in crashes. Use {@link #isPresent()} to test if the wrapped object is available.
     *
     * @return the object behind this wrapper
     */
    T get();

    /**
     * Gets this object wrapped in a vanilla {@link class_6880}.
     *
     * @return the holder
     */
    class_6880<T> holder();

    /**
     * Test if the wrapped object is available.
     *
     * @return is available
     */
    boolean isPresent();

    /**
     * Test if the wrapped object is not yet available.
     *
     * @return is not available
     */
    default boolean isEmpty() {
        return !this.isPresent();
    }

    /**
     * creates a placeholder {@link RegistryReference} for game content that needs to be registered as a mod loader specific implementation
     *
     * @param registryKey       the registry
     * @param namespace         namespace of {@link class_2960}
     * @param path              path of {@link class_2960}
     * @param <T>               specific object type, is inferred from variable this is stored as
     * @return                  a placeholder reference implementation
     */
    static <T> RegistryReference<T> placeholder(class_5321<? extends class_2378<? super T>> registryKey, String namespace, String path) {
        return placeholder(registryKey, new class_2960(namespace, path));
    }

    /**
     * creates a placeholder {@link RegistryReference} for game content that needs to be registered as a mod loader specific implementation
     *
     * @param registryKey       the registry
     * @param resourceLocation  object name
     * @param <T>               specific object type, is inferred from variable this is stored as
     * @return                  a placeholder reference implementation
     */
    @SuppressWarnings("unchecked")
    static <T> RegistryReference<T> placeholder(class_5321<? extends class_2378<? super T>> registryKey, class_2960 resourceLocation) {
        class_2378<T> registry = (class_2378<T>) class_7923.field_41167.method_10223(registryKey.method_29177());
        if (registry == null) {
            throw new IllegalStateException(String.format("Unable to retrieve registry from key %s", registryKey));
        }
        class_5321<T> resourceKey = class_5321.method_29179((class_5321<? extends class_2378<T>>) registryKey, resourceLocation);
        return new RegistryReference<>() {
            @Nullable
            private T value;

            @Override
            public class_5321<? extends class_2378<? super T>> getRegistryKey() {
                return registryKey;
            }

            @Override
            public class_5321<T> getResourceKey() {
                return resourceKey;
            }

            @Override
            public class_2960 getResourceLocation() {
                return resourceLocation;
            }

            @Override
            public T get() {
                if (this.value == null) {
                    if (!registry.method_10250(resourceLocation)) {
                        throw new IllegalStateException(String.format("Unable to retrieve placeholder %s from registry %s", resourceLocation, registryKey));
                    }
                    this.value = registry.method_10223(resourceLocation);
                }
                return this.value;
            }

            @Override
            public class_6880<T> holder() {
                return registry.method_40290(this.getResourceKey());
            }

            @Override
            public boolean isPresent() {
                return this.value != null || registry.method_10250(resourceLocation);
            }
        };
    }
}
