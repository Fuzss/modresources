package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_897.class)
abstract class EntityRendererFabricMixin<T extends class_1297> {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    public void render(T entity, float entityYaw, float partialTick, class_4587 poseStack, class_4597 buffer, int packedLight, CallbackInfo callback) {
        DefaultedValue<class_2561> content = DefaultedValue.fromValue(entity.method_5476());
        EventResult result = FabricClientEvents.RENDER_NAME_TAG.invoker().onRenderNameTag(entity, content, class_897.class.cast(this), poseStack, buffer, packedLight, partialTick);
        if (result.isInterrupt()) {
            callback.cancel();
            if (!result.getAsBoolean()) return;
        } else if (content.getAsOptional().isEmpty()) {
            return;
        } else {
            callback.cancel();
            if (!this.shouldShowName(entity)) return;
        }
        this.renderNameTag(entity, content.get(), poseStack, buffer, packedLight);
    }

    @Shadow
    protected abstract boolean shouldShowName(T entity);

    @Shadow
    protected abstract void renderNameTag(T entity, class_2561 displayName, class_4587 matrixStack, class_4597 buffer, int packedLight);
}
