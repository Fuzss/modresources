package fuzs.puzzleslib.mixin.client.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import java.util.Map;
import net.minecraft.class_2248;
import net.minecraft.class_4910;
import net.minecraft.class_4946;

@Mixin(class_4910.class)
public interface BlockModelGeneratorsAccessor {

    @Accessor("nonOrientableTrapdoor")
    @Mutable
    void puzzleslib$setNonOrientableTrapdoor(List<class_2248> nonOrientableTrapdoor);

    @Accessor("texturedModels")
    @Mutable
    void puzzleslib$setTexturedModels(Map<class_2248, class_4946> texturedModels);

    @Accessor("nonOrientableTrapdoor")
    List<class_2248> puzzleslib$getNonOrientableTrapdoor();

    @Accessor("texturedModels")
    Map<class_2248, class_4946> puzzleslib$getTexturedModels();
}
