package fuzs.puzzleslib.impl.network;

import fuzs.puzzleslib.api.core.v1.ReflectionHelper;
import fuzs.puzzleslib.api.network.v2.MessageV2;
import java.lang.reflect.Constructor;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_156;
import net.minecraft.class_2540;

public final class NetworkHandlerImplHelper {

    private NetworkHandlerImplHelper() {

    }

    @SuppressWarnings("unchecked")
    static <T extends MessageV2<T>> Function<class_2540, T> getMessageDecoder(Class<T> clazz) {
        Supplier<T> supplier = () -> ReflectionHelper.newDefaultInstanceFactory(clazz).get().orElseThrow();
        return Stream.of(clazz.getConstructors())
                .filter(currentConstructor -> currentConstructor.getParameterCount() == 1)
                .filter(currentConstructor -> currentConstructor.getParameterTypes()[0] == class_2540.class)
                .findAny()
                .<Function<class_2540, T>>map(constructor -> buf -> ReflectionHelper.newInstance((Constructor<T>) constructor, buf).orElseThrow())
                .orElseGet(() -> getDirectMessageDecoder(supplier));
    }

    static <T extends MessageV2<T>> Function<class_2540, T> getDirectMessageDecoder(Supplier<T> supplier) {
        return buf -> class_156.method_654(supplier.get(), message -> message.read(buf));
    }
}
