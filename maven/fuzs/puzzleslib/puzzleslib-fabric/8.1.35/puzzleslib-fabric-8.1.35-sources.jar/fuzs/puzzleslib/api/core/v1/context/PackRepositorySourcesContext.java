package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_3285;

@FunctionalInterface
public interface PackRepositorySourcesContext {

    /**
     * Register additional {@link class_3285}s when a new {@link net.minecraft.class_3283} is created.
     * <p>Context can be used for registering both client (for resource packs) and server (for data packs) repository sources.
     *
     * @param repositorySources repository sources to add
     */
    void addRepositorySource(class_3285... repositorySources);
}
