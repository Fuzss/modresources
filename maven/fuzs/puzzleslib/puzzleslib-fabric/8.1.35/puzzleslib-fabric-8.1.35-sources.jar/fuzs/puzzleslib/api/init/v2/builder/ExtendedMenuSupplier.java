package fuzs.puzzleslib.api.init.v2.builder;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2540;

/**
 * a copy of MenuSupplier in {@link net.minecraft.class_3917} which is private,
 * but both Forge and Fabric use an access transformer to set the interface to public,
 * we basically wrap the interface to make it usable on common
 * @param <T> type of menu
 */
@FunctionalInterface
public interface ExtendedMenuSupplier<T extends class_1703> {

    /**
     * container menu factory method
     * @param containerId menu id
     * @param inventory player inventory
     * @param data additional data to be sent to client
     * @return the container menu
     */
    T create(int containerId, class_1661 inventory, class_2540 data);
}
