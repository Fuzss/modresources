package fuzs.puzzleslib.api.entity.v1;

import fuzs.puzzleslib.impl.PuzzlesLibMod;
import fuzs.puzzleslib.impl.entity.ClientboundAddEntityDataMessage;
import io.netty.buffer.Unpooled;
import net.minecraft.class_1297;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2604;

/**
 * An interface attached to {@link class_1297} to send additional data to clients when the entity is added to the client level.
 * <p>Using this interface requires overriding {@link class_1297#method_18002()} and returning {@link #getPacket(class_1297)}
 */
public interface AdditionalAddEntityData {

    /**
     * Create a custom packet to be returned from {@link class_1297#method_18002()}
     *
     * @param entity the entity to read data from
     * @param <T>    entity type
     * @return the vanilla packet to be sent
     */
    static <T extends class_1297 & AdditionalAddEntityData> class_2596<class_2602> getPacket(T entity) {
        class_2604 vanillaPacket = new class_2604(entity);
        class_2540 buf = new class_2540(Unpooled.buffer());
        entity.writeAdditionalAddEntityData(buf);
        return PuzzlesLibMod.NETWORK.toClientboundPacket(new ClientboundAddEntityDataMessage(vanillaPacket, buf));
    }

    /**
     * Write additional entity data to a buffer.
     *
     * @param buf byte buffer to write to
     */
    void writeAdditionalAddEntityData(class_2540 buf);

    /**
     * Read additional entity data from a buffer.
     *
     * @param buf byte buffer to read from
     */
    void readAdditionalAddEntityData(class_2540 buf);
}
