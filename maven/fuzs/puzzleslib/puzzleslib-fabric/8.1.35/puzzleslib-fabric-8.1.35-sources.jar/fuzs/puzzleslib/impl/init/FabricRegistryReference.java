package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.init.v2.RegistryReference;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

/**
 * implementation for Fabric
 * @param <T> type of the referenced object
 */
public class FabricRegistryReference<T> implements RegistryReference<T> {
    /**
     * the referenced value
     */
    private final T value;
    /**
     * the resource key in {@link #registry} for {@link #value}
     */
    private final class_5321<T> key;
    /**
     * the {@link class_2378} {@link #value} is registered to
     */
    private final class_2378<? super T> registry;

    /**
     * @param value             the referenced value
     * @param resourceLocation  resource location to create {@link class_5321} from
     * @param registry          the {@link class_2378} {@link #value} is registered to
     */
    @SuppressWarnings("unchecked")
    public FabricRegistryReference(T value, class_2960 resourceLocation, class_2378<? super T> registry) {
        this(value, (class_5321<T>) class_5321.method_29179(registry.method_30517(), resourceLocation), registry);
    }

    /**
     * @param value     the referenced value
     * @param key       the resource key in {@link #registry} for {@link #value}
     * @param registry  the {@link class_2378} {@link #value} is registered to
     */
    public FabricRegistryReference(T value, class_5321<T> key, class_2378<? super T> registry) {
        this.value = value;
        this.key = key;
        this.registry = registry;
    }

    @Override
    public class_5321<? extends class_2378<? super T>> getRegistryKey() {
        return this.registry.method_30517();
    }

    @Override
    public class_5321<T> getResourceKey() {
        return this.key;
    }

    @Override
    public class_2960 getResourceLocation() {
        return this.key.method_29177();
    }

    @Override
    public T get() {
        return this.value;
    }

    @SuppressWarnings("unchecked")
    @Override
    public class_6880<T> holder() {
        return ((class_2378<T>) this.registry).method_40290(this.key);
    }

    @Override
    public boolean isPresent() {
        return true;
    }
}
