package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_5362;

@Mixin(class_1937.class)
abstract class LevelFabricMixin {
    @Nullable
    @Unique
    private class_1927 puzzleslib$activeExplosion;

    @ModifyVariable(method = "explode(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;Lnet/minecraft/world/level/ExplosionDamageCalculator;DDDFZLnet/minecraft/world/level/Level$ExplosionInteraction;Z)Lnet/minecraft/world/level/Explosion;", at = @At("STORE"), ordinal = 0)
    public class_1927 explode$0(class_1927 explosion) {
        this.puzzleslib$activeExplosion = explosion;
        return explosion;
    }

    @Inject(method = "explode(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/damagesource/DamageSource;Lnet/minecraft/world/level/ExplosionDamageCalculator;DDDFZLnet/minecraft/world/level/Level$ExplosionInteraction;Z)Lnet/minecraft/world/level/Explosion;", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Explosion;explode()V"), cancellable = true)
    public void explode$1(@Nullable class_1297 source, @Nullable class_1282 damageSource, @Nullable class_5362 damageCalculator, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction, boolean spawnParticles, CallbackInfoReturnable<class_1927> callback) {
        Objects.requireNonNull(this.puzzleslib$activeExplosion, "active explosion is null");
        EventResult result = FabricLevelEvents.EXPLOSION_START.invoker().onExplosionStart(class_1937.class.cast(this), this.puzzleslib$activeExplosion);
        if (result.isInterrupt()) callback.setReturnValue(this.puzzleslib$activeExplosion);
        this.puzzleslib$activeExplosion = null;
    }
}
