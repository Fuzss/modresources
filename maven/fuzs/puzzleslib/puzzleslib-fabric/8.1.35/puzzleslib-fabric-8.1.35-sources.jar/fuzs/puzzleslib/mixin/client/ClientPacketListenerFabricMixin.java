package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;

@Mixin(class_634.class)
abstract class ClientPacketListenerFabricMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "handleLogin", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;resetPos()V", shift = At.Shift.AFTER))
    public void handleLogin(class_2678 packet, CallbackInfo callback) {
        Objects.requireNonNull(this.minecraft.field_1724, "player is null");
        Objects.requireNonNull(this.minecraft.field_1761, "game mode is null");
        Objects.requireNonNull(this.minecraft.method_1562(), "connection is null");
        Objects.requireNonNull(this.minecraft.method_1562().method_48296(), "connection is null");
        FabricClientEvents.PLAYER_LOGGED_IN.invoker().onLoggedIn(this.minecraft.field_1724, this.minecraft.field_1761, this.minecraft.method_1562().method_48296());
    }

    @ModifyVariable(method = "handleRespawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;addPlayer(ILnet/minecraft/client/player/AbstractClientPlayer;)V", shift = At.Shift.AFTER), ordinal = 0)
    public class_746 handleRespawn(class_746 oldPlayer) {
        Objects.requireNonNull(oldPlayer, "old player is null");
        Objects.requireNonNull(this.minecraft.field_1724, "new player is null");
        Objects.requireNonNull(this.minecraft.field_1761, "game mode is null");
        Objects.requireNonNull(this.minecraft.field_1724.field_3944, "connection is null");
        Objects.requireNonNull(this.minecraft.field_1724.field_3944.method_48296(), "connection is null");
        FabricClientEvents.PLAYER_COPY.invoker().onCopy(oldPlayer, this.minecraft.field_1724, this.minecraft.field_1761, this.minecraft.field_1724.field_3944.method_48296());
        return oldPlayer;
    }
}
