package fuzs.puzzleslib.mixin.client.accessor;

import net.minecraft.class_1735;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_465.class)
public interface AbstractContainerScreenFabricAccessor {

    @Accessor("imageWidth")
    int puzzleslib$getXSize();

    @Accessor("imageHeight")
    int puzzleslib$getYSize();

    @Accessor("leftPos")
    int puzzleslib$getGuiLeft();

    @Accessor("topPos")
    int puzzleslib$getGuiTop();

    @Accessor("hoveredSlot")
    class_1735 puzzleslib$getSlotUnderMouse();
}
