package fuzs.puzzleslib.impl.client.core;

import fuzs.puzzleslib.api.client.core.v1.context.DynamicModifyBakingResultContext;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_2960;

public record DynamicModifyBakingResultContextImpl(Map<class_2960, class_1087> models, class_1088 modelBakery) implements DynamicModifyBakingResultContext {

}
