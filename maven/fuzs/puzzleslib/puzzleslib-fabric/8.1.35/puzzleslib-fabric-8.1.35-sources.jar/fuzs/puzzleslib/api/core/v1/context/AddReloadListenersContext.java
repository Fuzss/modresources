package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_3302;
import net.minecraft.class_4013;
import net.minecraft.class_4080;

/**
 * Adds a listener to the client (resource packs) or server (data packs) resource manager to reload at the end of all resources.
 *
 * <p>The resource manager uses a list for keeping track, so it's pretty safe to assume it'll load after vanilla,
 * Fabric has a very limited way of setting some sort of resource dependencies,
 * but they don't work for most stuff and Forge doesn't have them anyway, so we skip that.
 */
@FunctionalInterface
public interface AddReloadListenersContext {

    /**
     * Register a {@link class_3302}.
     *
     * @param id             id for this listener
     * @param reloadListener the reload listener to add
     */
    void registerReloadListener(String id, class_3302 reloadListener);

    /**
     * Register a {@link class_4013}.
     * <p>Exists as a dedicated overload to remind me this is a thing, and you do not need to always use the full-blown {@link class_3302}.
     *
     * @param id             id for this listener
     * @param reloadListener the reload listener to add
     */
    default void registerReloadListener(String id, class_4013 reloadListener) {
        this.registerReloadListener(id, (class_3302) reloadListener);
    }

    /**
     * Register a {@link class_4080}.
     * <p>Exists as a dedicated overload to remind me this is a thing, and you do not need to always use the full-blown {@link class_3302}.
     *
     * @param id             id for this listener
     * @param reloadListener the reload listener to add
     */
    default <T> void registerReloadListener(String id, class_4080<T> reloadListener) {
        this.registerReloadListener(id, (class_3302) reloadListener);
    }
}
