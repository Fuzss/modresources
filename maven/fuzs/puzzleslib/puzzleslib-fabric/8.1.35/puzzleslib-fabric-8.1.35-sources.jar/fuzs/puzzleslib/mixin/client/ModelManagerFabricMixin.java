package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_3695;
import net.minecraft.class_4724;

@Mixin(class_1092.class)
abstract class ModelManagerFabricMixin {
    @Shadow
    private Map<class_2960, class_1087> bakedRegistry;

    @Inject(
            method = "loadModels",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/Map;forEach(Ljava/util/function/BiConsumer;)V",
                    shift = At.Shift.AFTER
            )
    )
    private void loadModels(class_3695 profilerFiller, Map<class_2960, class_4724.class_7774> atlasPreparations, class_1088 modelBakery, CallbackInfoReturnable<Object> callback) {
        FabricClientEvents.MODIFY_BAKING_RESULT.invoker()
                .onModifyBakingResult(modelBakery.method_4734(), () -> modelBakery);
    }

    @Inject(
            method = "apply",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/resources/model/ModelManager;missingModel:Lnet/minecraft/client/resources/model/BakedModel;",
                    shift = At.Shift.AFTER
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void apply(@Coerce Object reloadState, class_3695 profiler, CallbackInfo callback, class_1088 modelBakery) {
        FabricClientEvents.BAKING_COMPLETED.invoker()
                .onBakingCompleted(() -> class_1092.class.cast(this), this.bakedRegistry, () -> modelBakery);
        FabricClientEvents.COMPLETE_MODEL_LOADING.invoker()
                .onCompleteModelLoading(() -> class_1092.class.cast(this), () -> modelBakery);
    }
}