package fuzs.puzzleslib.api.network.v3.serialization;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;
import com.mojang.datafixers.util.Either;
import fuzs.puzzleslib.impl.network.serialization.RecordSerializer;
import org.jetbrains.annotations.ApiStatus;
import org.joml.Vector3f;

import java.lang.reflect.Array;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.*;
import java.util.function.Function;
import java.util.function.IntFunction;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1887;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2379;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2941;
import net.minecraft.class_2943;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_3850;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_3917;
import net.minecraft.class_3965;
import net.minecraft.class_4050;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Main class for storing {@link MessageSerializer} implementations.
 *
 * <p>This implementation is heavily inspired by and largely based upon <a href="https://github.com/wisp-forest/owo-lib">Owo Lib</a> by <a href="https://github.com/gliscowo">Glisco</a>.
 */
public final class MessageSerializers {
    private static final Map<Class<?>, MessageSerializer<?>> SERIALIZERS = Collections.synchronizedMap(Maps.newIdentityHashMap());
    private static final Map<Class<?>, Function<Type[], MessageSerializer<?>>> CONTAINER_PROVIDERS = Collections.synchronizedMap(Maps.newLinkedHashMap());

    private MessageSerializers() {

    }

    /**
     * Register a new {@link MessageSerializer} by providing a {@link net.minecraft.class_2540.class_7462} and a {@link net.minecraft.class_2540.class_7461},
     * similarly to vanilla's {@link class_2941}
     *
     * @param type type to serialize, inheritance is not supported
     * @param writer writer to byte buffer
     * @param reader reader from byte buffer
     * @param <T> data type
     */
    public static <T> void registerSerializer(Class<T> type, class_2540.class_7462<T> writer, class_2540.class_7461<T> reader) {
        registerSerializer(type, new MessageSerializerImpl<T>(writer, reader));
    }

    /**
     * Register a serializer for a data type handled by vanilla's registry system.
     *
     * @param type registry content type to serialize
     * @param resourceKey registry resource key
     * @param <T> data type
     */
    @SuppressWarnings("unchecked")
    public static <T> void registerSerializer(Class<? super T> type, class_5321<class_2378<T>> resourceKey) {
        class_2378<T> registry;
        if (class_7923.field_41167.method_10250(resourceKey.method_29177())) {
            registry = (class_2378<T>) class_7923.field_41167.method_10223(resourceKey.method_29177());
        } else {
            registry = null;
        }
        Objects.requireNonNull(registry, "Registry for key %s not found".formatted(resourceKey.method_29177()));
        registerSerializer((Class<T>) type, (friendlyByteBuf, t) -> {
            friendlyByteBuf.method_10804(registry.method_10206(t));
        }, friendlyByteBuf -> {
            return registry.method_10200(friendlyByteBuf.method_10816());
        });
    }

    private static <T> void registerSerializer(Class<T> type, MessageSerializer<T> value) {
        if (SERIALIZERS.put(type, value) != null) throw new IllegalStateException("Duplicate serializer registered for type %s".formatted(type));
    }

    private static <T> void registerSerializer(Class<T> type, class_2941<T> entityDataSerializer) {
        registerSerializer(type, entityDataSerializer::method_12715, entityDataSerializer::method_12716);
    }

    /**
     * Register a custom serializer for container types. Subclasses are supported, meaning e.g. any map implementation will be handled by a provider registered for {@link Map}.
     *
     * <p>All types extending collection are by default deserialized in a {@link LinkedHashSet}. To enable a specific collection type, a unique serializer must be registered.
     * This is already done for {@link List}s, which are deserialized as {@link ArrayList}.
     *
     * @param type container type
     * @param factory new empty collection provider (preferable with pre-configured size)
     * @param <T> container type
     */
    @SuppressWarnings("unchecked")
    public static <T> void registerContainerProvider(Class<T> type, Function<Type[], MessageSerializer<? extends T>> factory) {
        if (CONTAINER_PROVIDERS.put(type, (Function<Type[], MessageSerializer<?>>) (Function<?, ?>) factory) != null) throw new IllegalStateException("Duplicate collection provider registered for type %s".formatted(type));
    }

    /**
     * Find a serializer for a given type. Some serializers (for records, arrays, and enums) can be created dynamically.
     *
     * @param type serializable type
     * @param <T>  data type
     * @return serializer for this type
     */
    @SuppressWarnings("unchecked")
    public static <T> MessageSerializer<T> findByType(Class<T> type) {
        // don't use Map::computeIfAbsent on map, it will throw java.lang.ConcurrentModificationException as during the Map::computeIfAbsent for the main record type
        // more calls to MessageSerializers::getByType can happen when the record contains other records / enums / arrays as fields
        MessageSerializer<T> serializer = (MessageSerializer<T>) SERIALIZERS.get(type);
        if (serializer == null) {
            serializer = computeIfAbsent(type);
            SERIALIZERS.put(type, serializer);
        }
        return serializer;
    }

    @SuppressWarnings("unchecked")
    private static <T, E extends Enum<E>> MessageSerializer<T> computeIfAbsent(Class<T> clazz) {
        if (Record.class.isAssignableFrom(clazz)) {
            return (MessageSerializer<T>) RecordSerializer.createRecordSerializer((Class<? extends Record>) clazz);
        } else if (clazz.isArray()) {
            return (MessageSerializer<T>) createArraySerializer(clazz.getComponentType());
        } else if (clazz.isEnum()) {
            return (MessageSerializer<T>) createEnumSerializer((Class<E>) clazz);
        } else {
            throw new RuntimeException("Missing serializer for type %s".formatted(clazz));
        }
    }

    @ApiStatus.Internal
    public static MessageSerializer<?> findByGenericType(Type type) {

        if (type instanceof Class<?> clazz) {
            return findByType(clazz);
        }

        ParameterizedType parameterizedType = (ParameterizedType) type;
        Class<?> clazz = (Class<?>) parameterizedType.getRawType();
        Type[] typeArguments = parameterizedType.getActualTypeArguments();

        for (Map.Entry<Class<?>, Function<Type[], MessageSerializer<?>>> entry : CONTAINER_PROVIDERS.entrySet()) {
            if (entry.getKey().isAssignableFrom(clazz)) return entry.getValue().apply(typeArguments);
        }

        // fallback for collections, don't include in providers to allow for handling more concrete collection implementations
        if (Collection.class.isAssignableFrom(clazz)) {
            return createCollectionSerializer(typeArguments, Sets::newLinkedHashSetWithExpectedSize);
        }

        return findByType(clazz);
    }

    @SuppressWarnings("unchecked")
    private static <K, V> MessageSerializer<Map<K, V>> createMapSerializer(Type[] typeArguments) {
        MessageSerializer<K> keySerializer = findByType((Class<K>) typeArguments[0]);
        MessageSerializer<V> valueSerializer = findByType((Class<V>) typeArguments[1]);
        return new MessageSerializerImpl<>((friendlyByteBuf, o) -> {
            friendlyByteBuf.method_34063(o, keySerializer::write, valueSerializer::write);
        }, friendlyByteBuf -> {
            return friendlyByteBuf.method_34067(keySerializer::read, valueSerializer::read);
        });
    }

    @SuppressWarnings("unchecked")
    private static <T, C extends Collection<T>> MessageSerializer<C> createCollectionSerializer(Type[] typeArguments, IntFunction<C> factory) {
        MessageSerializer<T> serializer = findByType((Class<T>) typeArguments[0]);
        return new MessageSerializerImpl<>((friendlyByteBuf, o) -> {
            friendlyByteBuf.method_34062(o, serializer::write);
        }, friendlyByteBuf -> {
            return friendlyByteBuf.method_34068(factory, serializer::read);
        });
    }

    @SuppressWarnings("unchecked")
    private static <T> MessageSerializer<Optional<T>> createOptionalSerializer(Type[] typeArguments) {
        MessageSerializer<T> serializer = findByType((Class<T>) typeArguments[0]);
        return new MessageSerializerImpl<>((friendlyByteBuf, o) -> {
            friendlyByteBuf.method_37435(o, serializer::write);
        }, friendlyByteBuf -> {
            return friendlyByteBuf.method_37436(serializer::read);
        });
    }

    @SuppressWarnings("unchecked")
    private static <L, R> MessageSerializer<Either<L, R>> createEitherSerializer(Type[] typeArguments) {
        MessageSerializer<L> leftSerializer = findByType((Class<L>) typeArguments[0]);
        MessageSerializer<R> rightSerializer = findByType((Class<R>) typeArguments[1]);
        return new MessageSerializerImpl<>((friendlyByteBuf, o) -> {
            friendlyByteBuf.method_43619(o, leftSerializer::write, rightSerializer::write);
        }, friendlyByteBuf -> {
            return friendlyByteBuf.method_43622(leftSerializer::read, rightSerializer::read);
        });
    }

    @SuppressWarnings("unchecked")
    private static MessageSerializer<?> createArraySerializer(Class<?> clazz) {
        MessageSerializer<Object> serializer = (MessageSerializer<Object>) findByType(clazz);
        return new MessageSerializerImpl<>((buf, t) -> {
            final int length = Array.getLength(t);
            buf.method_10804(length);
            for (int i = 0; i < length; i++) {
                serializer.write(buf, Array.get(t, i));
            }
        }, buf -> {
            final int length = buf.method_10816();
            Object array = Array.newInstance(clazz, length);
            for (int i = 0; i < length; i++) {
                Array.set(array, i, serializer.read(buf));
            }
            return array;
        });
    }

    private static <E extends Enum<E>> MessageSerializer<E> createEnumSerializer(Class<E> clazz) {
        return new MessageSerializerImpl<>(class_2540::method_10817, buf -> buf.method_10818(clazz));
    }

    private record MessageSerializerImpl<T>(class_2540.class_7462<T> writer, class_2540.class_7461<T> reader) implements MessageSerializer<T> {

        @Override
        public void write(class_2540 buf, T instance) {
            this.writer.accept(buf, instance);
        }

        @Override
        public T read(class_2540 buf) {
            return this.reader.apply(buf);
        }
    }

    static {
        registerSerializer(boolean.class, class_2540::writeBoolean, class_2540::readBoolean);
        registerSerializer(Boolean.class, class_2540::writeBoolean, class_2540::readBoolean);
        registerSerializer(int.class, class_2540::method_10804, class_2540::method_10816);
        registerSerializer(Integer.class, class_2540::method_10804, class_2540::method_10816);
        registerSerializer(long.class, class_2540::method_10791, class_2540::method_10792);
        registerSerializer(Long.class, class_2540::method_10791, class_2540::method_10792);
        registerSerializer(float.class, class_2540::writeFloat, class_2540::readFloat);
        registerSerializer(Float.class, class_2540::writeFloat, class_2540::readFloat);
        registerSerializer(double.class, class_2540::writeDouble, class_2540::readDouble);
        registerSerializer(Double.class, class_2540::writeDouble, class_2540::readDouble);
        registerSerializer(byte.class, (class_2540.class_7462<Byte>) class_2540::writeByte, class_2540::readByte);
        registerSerializer(Byte.class, (class_2540.class_7462<Byte>) class_2540::writeByte, class_2540::readByte);
        registerSerializer(short.class, (class_2540.class_7462<Short>) class_2540::writeShort, class_2540::readShort);
        registerSerializer(Short.class, (class_2540.class_7462<Short>) class_2540::writeShort, class_2540::readShort);
        registerSerializer(char.class, (class_2540.class_7462<Character>) class_2540::writeChar, class_2540::readChar);
        registerSerializer(Character.class, (class_2540.class_7462<Character>) class_2540::writeChar, class_2540::readChar);

        registerSerializer(String.class, class_2943.field_13326);
        registerSerializer(Date.class, class_2540::method_10796, class_2540::method_10802);
        registerSerializer(Instant.class, class_2540::method_44115, class_2540::method_44118);
        registerSerializer(UUID.class, class_2540::method_10797, class_2540::method_10790);

        registerSerializer(class_2561.class, class_2943.field_13317);
        registerSerializer(class_1799.class, class_2943.field_13322);
        registerSerializer(class_2379.class, class_2943.field_13316);
        registerSerializer(class_2338.class, class_2943.field_13324);
        registerSerializer(class_2350.class, class_2943.field_13321);
        registerSerializer(class_2487.class, class_2943.field_13318);
        registerSerializer(class_2394.class, class_2943.field_13314);
        registerSerializer(class_3850.class, class_2943.field_17207);
        registerSerializer(class_4050.class, class_2943.field_18238);
        registerSerializer(class_1923.class, class_2540::method_36130, class_2540::method_36133);
        registerSerializer(class_2960.class, class_2540::method_10812, class_2540::method_10810);
        registerSerializer(class_3965.class, class_2540::method_17813, class_2540::method_17814);
        registerSerializer(BitSet.class, class_2540::method_33557, class_2540::method_33558);
        registerSerializer(GameProfile.class, class_2540::method_43616, class_2540::method_43623);

        registerSerializer(class_243.class, (friendlyByteBuf, vec3) -> {
            friendlyByteBuf.writeDouble(vec3.method_10216());
            friendlyByteBuf.writeDouble(vec3.method_10214());
            friendlyByteBuf.writeDouble(vec3.method_10215());
        }, friendlyByteBuf -> {
            return new class_243(friendlyByteBuf.readDouble(), friendlyByteBuf.readDouble(), friendlyByteBuf.readDouble());
        });
        registerSerializer(Vector3f.class, (friendlyByteBuf, vec3) -> {
            friendlyByteBuf.writeFloat(vec3.x());
            friendlyByteBuf.writeFloat(vec3.y());
            friendlyByteBuf.writeFloat(vec3.z());
        }, friendlyByteBuf -> {
            return new Vector3f(friendlyByteBuf.readFloat(), friendlyByteBuf.readFloat(), friendlyByteBuf.readFloat());
        });
        registerSerializer(class_2540.class, (buf, other) -> {
            buf.method_10804(other.readableBytes());
            buf.writeBytes(other);
            other.release();
        }, buf -> new class_2540(buf.readBytes(buf.method_10816())));

        registerSerializer(class_3414.class, class_7924.field_41225);
        registerSerializer(class_3611.class, class_7924.field_41270);
        registerSerializer(class_1291.class, class_7924.field_41208);
        registerSerializer(class_2248.class, class_7924.field_41254);
        registerSerializer(class_1887.class, class_7924.field_41265);
        registerSerializer(class_1299.class, class_7924.field_41266);
        registerSerializer(class_1792.class, class_7924.field_41197);
        registerSerializer(class_1842.class, class_7924.field_41215);
        registerSerializer(class_2396.class, class_7924.field_41210);
        registerSerializer(class_2591.class, class_7924.field_41255);
        registerSerializer(class_3917.class, class_7924.field_41207);
        registerSerializer(class_1320.class, class_7924.field_41251);
        registerSerializer(class_5712.class, class_7924.field_41273);
        registerSerializer(class_3854.class, class_7924.field_41235);
        registerSerializer(class_3852.class, class_7924.field_41234);
        registerSerializer(class_4158.class, class_7924.field_41212);

        registerContainerProvider(Map.class, MessageSerializers::createMapSerializer);
        registerContainerProvider(List.class, typeArguments -> createCollectionSerializer(typeArguments, Lists::newArrayListWithExpectedSize));
        registerContainerProvider(Optional.class, MessageSerializers::createOptionalSerializer);
        registerContainerProvider(Either.class, MessageSerializers::createEitherSerializer);
    }
}
