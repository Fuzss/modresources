package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricEntityEvents;
import fuzs.puzzleslib.impl.event.SpawnTypeMob;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5568;
import net.minecraft.class_5579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_5579.class)
abstract class PersistentEntitySectionManagerFabricMixin<T extends class_5568> {

    @Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
    private void addEntity(T entityAccess, boolean loadedFromDisk, CallbackInfoReturnable<Boolean> callback) {
        if (entityAccess instanceof class_1297 entity) {
            class_3730 spawnType = entity instanceof SpawnTypeMob mob ? mob.puzzleslib$getSpawnType() : null;
            if (FabricEntityEvents.ENTITY_LOAD.invoker().onEntityLoad(entity, (class_3218) entity.method_37908(), !loadedFromDisk ? spawnType : null).isInterrupt()) {
                if (entity instanceof class_1657) {
                    // we do not support players as it isn't as straight-forward to implement for the server player on Fabric
                    throw new UnsupportedOperationException("Cannot prevent player from spawning in!");
                } else {
                    callback.setReturnValue(false);
                }
            }
            if (FabricEntityEvents.ENTITY_LOAD_V2.invoker().onEntityLoad(entity, (class_3218) entity.method_37908()).isInterrupt()) {
                if (entity instanceof class_1657) {
                    // we do not support players as it isn't as straight-forward to implement for the server player on Fabric
                    throw new UnsupportedOperationException("Cannot prevent player from loading in!");
                } else {
                    callback.setReturnValue(false);
                    return;
                }
            }
            if (!loadedFromDisk) {
                if (FabricEntityEvents.ENTITY_SPAWN.invoker().onEntitySpawn(entity, (class_3218) entity.method_37908(), spawnType).isInterrupt()) {
                    if (entity instanceof class_1657) {
                        // we do not support players as it isn't as straight-forward to implement for the server player on Fabric
                        throw new UnsupportedOperationException("Cannot prevent player from spawning in!");
                    } else {
                        callback.setReturnValue(false);
                    }
                }
            }
        }
    }
}
