package fuzs.puzzleslib.api.resources.v1;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.io.InputStream;
import java.nio.file.Files;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_155;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3270;
import net.minecraft.class_3272;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_7367;
import net.minecraft.class_7662;
import net.minecraft.class_7699;

/**
 * A basic implementation of {@link class_3262} fit to be used for a built-in pack providing runtime generated assets.
 * <p>This pack automatically uses the mod's mod logo for the pack icon.
 */
public abstract class AbstractModPackResources implements class_3262 {
    /**
     * Path to the mod logo inside the mod jar to be used in place of <code>pack.png</code> for the pack icon.
     * <p>Defaults to <code>mod_logo.png</code>, path is separated using "/".
     */
    protected final String modLogoPath;
    /**
     * Id of this pack.
     * <p>Set internally using {@link #buildPack(class_3264, class_2960, Supplier, class_2561, class_2561, boolean, boolean, boolean, class_7699)}.
     */
    private class_2960 id;
    /**
     * The metadata for the <code>pack.mcmeta</code> section.
     * <p>Set internally using {@link #buildPack(class_3264, class_2960, Supplier, class_2561, class_2561, boolean, boolean, boolean, class_7699)}.
     */
    private class_7662 metadata;
    /**
     * The pack type for this pack.
     * <p>Set internally using {@link #buildPack(class_3264, class_2960, Supplier, class_2561, class_2561, boolean, boolean, boolean, class_7699)}.
     */
    private class_3264 packType;

    /**
     * Simple constructor with default file path parameter for the pack icon.
     */
    protected AbstractModPackResources() {
        this("mod_logo.png");
    }

    /**
     * Constructor with full control over the pack icon.
     */
    protected AbstractModPackResources(String modLogoPath) {
        Objects.requireNonNull(modLogoPath, "mod logo path is null");
        this.modLogoPath = modLogoPath;
    }

    @Nullable
    @Override
    public class_7367<InputStream> method_14410(String... elements) {
        String path = String.join("/", elements);
        if ("pack.png".equals(path)) {
            return ModLoaderEnvironment.INSTANCE.getModContainer(this.getNamespace())
                    .flatMap(container -> container.findResource(this.modLogoPath))
                    .<class_7367<InputStream>>map(modResource -> {
                        return () -> Files.newInputStream(modResource);
                    }).orElse(null);
        }
        return null;
    }

    @Nullable
    @Override
    public class_7367<InputStream> method_14405(class_3264 packType, class_2960 location) {
        return null;
    }

    @Override
    public void method_14408(class_3264 packType, String namespace, String path, class_7664 resourceOutput) {

    }

    @Override
    public Set<String> method_14406(class_3264 type) {
        Objects.requireNonNull(this.packType, "pack type is null");
        return this.packType == type ? Collections.singleton(this.getNamespace()) : Collections.emptySet();
    }

    @Nullable
    @Override
    public <T> T method_14407(class_3270<T> deserializer) {
        Objects.requireNonNull(this.metadata, "metadata is null");
        return this.metadata.method_45173(deserializer);
    }

    @Override
    public String method_14409() {
        return this.id.toString();
    }

    @Override
    public boolean method_45178() {
        return true;
    }

    @Override
    public void close() {

    }

    /**
     * @return the namespace from the internal id
     */
    protected final String getNamespace() {
        Objects.requireNonNull(this.id, "id is null");
        return this.id.method_12836();
    }

    /**
     * An internal setup helper intended for setting up {@link DynamicPackResources} after the id has been set.
     */
    @Deprecated(forRemoval = true)
    @ApiStatus.Internal
    void setup() {
        // NO-OP
    }

    @ApiStatus.Internal
    static class_3288 buildPack(class_3264 packType, class_2960 id, Supplier<AbstractModPackResources> factory, class_2561 title, class_2561 description, boolean required, boolean fixedPosition, boolean hidden, class_7699 features) {
        class_3272 metadataSection = new class_3272(description, class_155.method_16673().method_48017(packType));
        class_7662 metadata = class_7662.method_45174(class_3272.field_14202, metadataSection);
        class_3288.class_7679 info = CommonAbstractions.INSTANCE.createPackInfo(id, description, metadataSection.method_14424(), features, hidden);
        return class_3288.method_14456(id.toString(), title, required, $ -> {
            AbstractModPackResources packResources = factory.get();
            packResources.id = id;
            packResources.metadata = metadata;
            packResources.packType = packType;
            packResources.setup();
            return packResources;
        }, info, packType, class_3288.class_3289.field_14280, fixedPosition, class_5352.field_25348);
    }
}
