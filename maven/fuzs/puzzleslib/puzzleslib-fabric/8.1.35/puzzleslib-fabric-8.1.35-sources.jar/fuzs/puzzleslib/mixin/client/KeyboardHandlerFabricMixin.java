package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
abstract class KeyboardHandlerFabricMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    public void keyPress$0(long windowPointer, int key, int scanCode, int action, int modifiers, CallbackInfo callback) {
        if (windowPointer == this.minecraft.method_22683().method_4490()) {
            EventResult result = FabricClientEvents.BEFORE_KEY_ACTION.invoker().onBeforeKeyAction(key, scanCode, action, modifiers);
            if (result.isInterrupt()) callback.cancel();
        }
    }

    @Inject(method = "keyPress", at = @At("TAIL"), cancellable = true)
    public void keyPress$1(long windowPointer, int key, int scanCode, int action, int modifiers, CallbackInfo callback) {
        if (windowPointer == this.minecraft.method_22683().method_4490()) {
            FabricClientEvents.AFTER_KEY_ACTION.invoker().onAfterKeyAction(key, scanCode, action, modifiers);
        }
    }
}
