package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricEntityEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1299;
import net.minecraft.class_1536;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(class_1536.class)
abstract class FishingHookFabricMixin extends class_1676 {

    public FishingHookFabricMixin(class_1299<? extends class_1676> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "checkCollision", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/projectile/FishingHook;onHit(Lnet/minecraft/world/phys/HitResult;)V"), cancellable = true, locals = LocalCapture.CAPTURE_FAILHARD)
    private void checkCollision(CallbackInfo callback, class_239 hitResult) {
        // implement this in Projectile::onHit, it's unlikely a subclass will override this
        if (hitResult.method_17783() == class_239.class_240.field_1333) return;
        EventResult result = FabricEntityEvents.PROJECTILE_IMPACT.invoker().onProjectileImpact(this, hitResult);
        if (result.isInterrupt()) callback.cancel();
    }
}
