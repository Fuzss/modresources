package fuzs.puzzleslib.api.network.v3;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.Buildable;
import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.api.core.v1.Proxy;
import fuzs.puzzleslib.api.network.v3.serialization.MessageSerializer;
import fuzs.puzzleslib.api.network.v3.serialization.MessageSerializers;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.network.NetworkHandlerRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2382;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2792;
import net.minecraft.class_2818;
import net.minecraft.class_2941;
import net.minecraft.class_3215;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Type;
import java.util.*;
import java.util.function.Function;

/**
 * Handler for network communications between clients and a server.
 */
public interface NetworkHandlerV3 {

    /**
     * Creates a new network handler builder.
     *
     * @param modId id for channel name
     * @return builder for mod specific network handler with default channel
     */
    static Builder builder(String modId) {
        return NetworkHandlerV3.builder(modId, null);
    }

    /**
     * Creates a new network handler builder.
     *
     * @param modId   id for channel name
     * @param context an internal id for this channel in case multiple are registered using the same mod id
     * @return builder for mod specific network handler with default channel
     */
    static Builder builder(String modId, @Nullable String context) {
        return ModContext.get(modId).getNetworkHandlerV3$Builder(context);
    }

    /**
     * creates a packet heading to the client side
     *
     * @param message message to create packet from
     * @return packet for message
     */
    <T extends Record & ClientboundMessage<T>> class_2596<class_2602> toClientboundPacket(T message);

    /**
     * creates a packet heading to the server side
     *
     * @param message message to create packet from
     * @return packet for message
     */
    <T extends Record & ServerboundMessage<T>> class_2596<class_2792> toServerboundPacket(T message);

    /**
     * Send message from server to clients.
     *
     * @param playerSet players to send to
     * @param message   message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendMessage(PlayerSet playerSet, T message) {
        playerSet.broadcast(this.toClientboundPacket(message));
    }

    /**
     * Send message from client to server.
     *
     * @param message message to send
     */
    default <T extends Record & ServerboundMessage<T>> void sendToServer(T message) {
        class_634 clientPacketListener = Proxy.INSTANCE.getClientPacketListener();
        Objects.requireNonNull(clientPacketListener, "client packet listener is null");
        clientPacketListener.method_2883(this.toServerboundPacket(message));
    }

    /**
     * Send message from server to a player.
     *
     * @param player  player to send to
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendTo(class_3222 player, T message) {
        Objects.requireNonNull(player, "player is null");
        player.field_13987.method_14364(this.toClientboundPacket(message));
    }

    /**
     * Send message from server to all players.
     *
     * @param server  server for retrieving the player list
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAll(MinecraftServer server, T message) {
        this.sendToAll(server, null, message);
    }

    /**
     * Send message from server to all players except one player.
     *
     * @param server  server for retrieving the player list
     * @param exclude player to exclude
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAll(MinecraftServer server, @Nullable class_3222 exclude, T message) {
        Objects.requireNonNull(server, "server is null");
        this.sendToAll(server.method_3760().method_14571(), exclude, message);
    }

    /**
     * Send message from server to all players except one player.
     *
     * @param playerList all players to send the message to
     * @param exclude    player to exclude
     * @param message    message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAll(Collection<class_3222> playerList, @Nullable class_3222 exclude, T message) {
        Objects.requireNonNull(playerList, "player list is null");
        for (class_3222 player : playerList) {
            if (player != exclude) this.sendTo(player, message);
        }
    }

    /**
     * Send message from server to all players in a level.
     *
     * @param level   the level
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAll(class_3218 level, T message) {
        Objects.requireNonNull(level, "level is null");
        for (class_3222 player : level.method_18456()) {
            this.sendTo(player, message);
        }
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param pos     source position
     * @param level   the current level
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(class_2382 pos, class_3218 level, T message) {
        Objects.requireNonNull(pos, "pos is null");
        this.sendToAllNear(pos.method_10263(), pos.method_10264(), pos.method_10260(), level, message);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param posX    source position x
     * @param posY    source position y
     * @param posZ    source position z
     * @param level   the current level
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(double posX, double posY, double posZ, class_3218 level, T message) {
        this.sendToAllNear(null, posX, posY, posZ, 64.0, level, message);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param exclude  exclude player having caused this event
     * @param posX     source position x
     * @param posY     source position y
     * @param posZ     source position z
     * @param distance allowed distance from source to receive message
     * @param level    the current level
     * @param message  message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(@Nullable class_3222 exclude, double posX, double posY, double posZ, double distance, class_3218 level, T message) {
        Objects.requireNonNull(level, "level is null");
        level.method_8503()
                .method_3760()
                .method_14605(exclude, posX, posY, posZ, distance, level.method_27983(), this.toClientboundPacket(message));
    }

    /**
     * Send message from server to all players tracking a block entity at a certain block position.
     *
     * @param blockEntity the block entity a player must track to receive this message
     * @param message     message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_2586 blockEntity, T message) {
        Objects.requireNonNull(blockEntity, "block entity is null");
        class_1937 level = blockEntity.method_10997();
        Objects.requireNonNull(level, "block entity level is null");
        Preconditions.checkState(!level.field_9236, "block entity level is client level");
        this.sendToAllNear((class_2382) blockEntity.method_11016(), (class_3218) level, message);
    }

    /**
     * Send message from server to all players tracking a chunk.
     *
     * @param chunk   the chunk a player must track to receive this message
     * @param message message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_2818 chunk, T message) {
        Objects.requireNonNull(chunk, "chunk is null");
        Preconditions.checkState(!chunk.method_12200().field_9236, "chunk level is client level");
        this.sendToAllTracking((class_3218) chunk.method_12200(), chunk.method_12004(), message);
    }

    /**
     * Send message from server to all players tracking a chunk.
     *
     * @param level    the level containing the chunk
     * @param chunkPos the chunk pos a player must track to receive this message
     * @param message  message to send
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_3218 level, class_1923 chunkPos, T message) {
        Objects.requireNonNull(level, "level is null");
        Objects.requireNonNull(chunkPos, "chunk pos is null");
        List<class_3222> players = level.method_14178().field_17254.method_17210(chunkPos, false);
        this.sendToAll(players, null, message);
    }

    /**
     * Send message from server to all players tracking a given entity.
     *
     * @param entity      the tracked entity
     * @param message     message to send
     * @param includeSelf when the tracked entity is a player will they receive the message as well
     */
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_1297 entity, T message, boolean includeSelf) {
        Objects.requireNonNull(entity, "entity is null");
        Preconditions.checkState(!entity.method_5770().field_9236, "entity level is client level");
        class_3215 chunkSource = ((class_3218) entity.method_5770()).method_14178();
        if (includeSelf) {
            chunkSource.method_18751(entity, this.toClientboundPacket(message));
        } else {
            chunkSource.method_18754(entity, this.toClientboundPacket(message));
        }
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAll(T message) {
        this.sendToAll(CommonAbstractions.INSTANCE.getMinecraftServer(), message);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAll(@Nullable class_3222 exclude, T message) {
        this.sendToAll(CommonAbstractions.INSTANCE.getMinecraftServer(), exclude, message);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(class_2338 pos, class_1937 level, T message) {
        Objects.requireNonNull(level, "level is null");
        Preconditions.checkState(!level.field_9236, "level is client level");
        this.sendToAllNear((class_2382) pos, (class_3218) level, message);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAllNear(double posX, double posY, double posZ, double distance, class_1937 level, T message) {
        Objects.requireNonNull(level, "level is null");
        Preconditions.checkState(!level.field_9236, "level is client level");
        this.sendToAllNear(posX, posY, posZ, (class_3218) level, message);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAllNearExcept(@Nullable class_3222 exclude, double posX, double posY, double posZ, double distance, class_1937 level, T message) {
        Objects.requireNonNull(level, "level is null");
        Preconditions.checkState(!level.field_9236, "level is client level");
        this.sendToAllNear(exclude, posX, posY, posZ, distance, (class_3218) level, message);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAllTracking(class_1297 entity, T message) {
        this.sendToAllTracking(entity, message, false);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToAllTrackingAndSelf(class_1297 entity, T message) {
        this.sendToAllTracking(entity, message, true);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToDimension(class_1937 level, T message) {
        Objects.requireNonNull(level, "level is null");
        Preconditions.checkState(!level.field_9236, "level is client level");
        this.sendToAll((class_3218) level, message);
    }

    @Deprecated(forRemoval = true)
    default <T extends Record & ClientboundMessage<T>> void sendToDimension(class_5321<class_1937> resourceKey, T message) {
        Objects.requireNonNull(resourceKey, "resource key is null");
        class_3218 level = CommonAbstractions.INSTANCE.getMinecraftServer().method_3847(resourceKey);
        Objects.requireNonNull(level, "level is null");
        this.sendToAll(level, message);
    }

    /**
     * A builder for a network handler, allows for registering messages.
     */
    interface Builder extends NetworkHandlerRegistry, Buildable {

        /**
         * Register a new {@link MessageSerializer} by providing a {@link net.minecraft.class_2540.class_7462}
         * and a {@link net.minecraft.class_2540.class_7461}, similarly to vanilla's
         * {@link class_2941}
         *
         * @param type   type to serialize, inheritance is not supported
         * @param writer writer to byte buffer
         * @param reader reader from byte buffer
         * @param <T>    data type
         * @return this builder instance
         */
        default <T> Builder registerSerializer(Class<T> type, class_2540.class_7462<T> writer, class_2540.class_7461<T> reader) {
            MessageSerializers.registerSerializer(type, writer, reader);
            return this;
        }

        /**
         * Register a serializer for a data type handled by vanilla's registry system.
         *
         * @param type        registry content type to serialize
         * @param resourceKey registry resource key
         * @param <T>         data type
         * @return this builder instance
         */
        default <T> Builder registerSerializer(Class<? super T> type, class_5321<class_2378<T>> resourceKey) {
            MessageSerializers.registerSerializer(type, resourceKey);
            return this;
        }

        /**
         * Register a custom serializer for container types. Subclasses are supported, meaning e.g. any map
         * implementation will be handled by a provider registered for {@link Map}.
         *
         * <p>All types extending collection are by default deserialized in a {@link LinkedHashSet}. To enable a
         * specific collection type, a unique serializer must be registered.
         * This is already done for {@link List}s, which are deserialized as {@link ArrayList}.
         *
         * @param type    container type
         * @param factory new empty collection provider (preferable with pre-configured size)
         * @param <T>     container type
         * @return this builder instance
         */
        default <T> Builder registerContainerProvider(Class<T> type, Function<Type[], MessageSerializer<? extends T>> factory) {
            MessageSerializers.registerContainerProvider(type, factory);
            return this;
        }

        /**
         * Register a message that will be sent to clients.
         *
         * @param clazz message class type
         * @param <T>   message implementation
         * @return this builder instance
         */
        <T extends Record & ClientboundMessage<T>> Builder registerClientbound(Class<T> clazz);

        /**
         * Register a message that will be sent to servers.
         *
         * @param clazz message class type
         * @param <T>   message implementation
         * @return this builder instance
         */
        <T extends Record & ServerboundMessage<T>> Builder registerServerbound(Class<T> clazz);

        /**
         * Are servers without this mod or vanilla servers compatible.
         *
         * <p>Only supported on Forge right now.
         *
         * @return this builder instance
         */
        Builder clientAcceptsVanillaOrMissing();

        /**
         * Are clients without this mod or vanilla clients compatible.
         *
         * <p>Only supported on Forge right now.
         *
         * @return this builder instance
         */
        Builder serverAcceptsVanillaOrMissing();

        /**
         * Are clients and servers without this mod or vanilla clients and servers compatible.
         *
         * <p>Only supported on Forge right now.
         *
         * @return this builder instance
         */
        default Builder allAcceptVanillaOrMissing() {
            return this.clientAcceptsVanillaOrMissing().serverAcceptsVanillaOrMissing();
        }
    }
}
