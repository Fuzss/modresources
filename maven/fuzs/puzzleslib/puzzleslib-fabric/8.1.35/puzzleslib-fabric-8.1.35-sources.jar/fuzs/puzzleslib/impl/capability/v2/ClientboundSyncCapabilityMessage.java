package fuzs.puzzleslib.impl.capability.v2;

import fuzs.puzzleslib.api.capability.v2.CapabilityController;
import fuzs.puzzleslib.api.network.v3.ClientMessageListener;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;

public record ClientboundSyncCapabilityMessage(class_2960 id, int holderId, class_2487 tag) implements ClientboundMessage<ClientboundSyncCapabilityMessage> {

    public ClientboundSyncCapabilityMessage(class_2960 id, class_1297 holder, class_2487 tag) {
        this(id, holder.method_5628(), tag);
    }

    @Override
    public ClientMessageListener<ClientboundSyncCapabilityMessage> getHandler() {
        return new ClientMessageListener<>() {

            @Override
            public void handle(ClientboundSyncCapabilityMessage message, class_310 client, class_634 handler, class_746 player, class_638 level) {
                class_1297 holder = level.method_8469(message.holderId);
                if (holder != null) {
                    CapabilityController.retrieve(message.id).orThrow(holder).read(message.tag);
                }
            }
        };
    }
}