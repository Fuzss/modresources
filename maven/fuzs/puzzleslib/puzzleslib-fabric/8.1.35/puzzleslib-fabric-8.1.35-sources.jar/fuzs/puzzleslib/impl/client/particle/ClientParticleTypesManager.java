package fuzs.puzzleslib.impl.client.particle;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.core.v1.ContentRegistrationFlags;
import fuzs.puzzleslib.impl.PuzzlesLib;
import net.minecraft.class_1047;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_156;
import net.minecraft.class_2394;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3518;
import net.minecraft.class_3695;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_4089;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_703;
import net.minecraft.class_707;
import net.minecraft.class_7654;
import net.minecraft.class_7766;
import net.minecraft.client.particle.*;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.Reader;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

public final class ClientParticleTypesManager implements class_3302 {
    private static final class_7654 PARTICLE_LISTER = class_7654.method_45114("particles");
    private static final class_2960 PARTICLES_ATLAS_INFO = new class_2960("particles");

    private final Map<class_2960, class_707<?>> providers = Maps.newHashMap();
    private final Map<class_2960, MutableSpriteSet> spriteSets = Maps.newHashMap();
    private final class_310 minecraft = class_310.method_1551();
    private boolean hasBeenReloaded;

    public <T extends class_2394> void register(class_2960 identifier, class_707<T> particleFactory) {
        this.providers.put(identifier, particleFactory);
    }

    public <T extends class_2394> void register(class_2960 identifier, class_707.class_8187<T> sprite) {
        this.register(identifier, (class_4002 spriteSet) -> {
            return (T particleOptions, class_638 clientLevel, double x, double y, double z, double xd, double yd, double zd) -> {
                class_4003 textureSheetParticle = sprite.createParticle(particleOptions, clientLevel, x, y, z, xd, yd, zd);
                if (textureSheetParticle != null) textureSheetParticle.method_18140(spriteSet);
                return textureSheetParticle;
            };
        });
    }

    public <T extends class_2394> void register(class_2960 identifier, class_702.class_4091<T> particleMetaFactory) {
        MutableSpriteSet mutableSpriteSet = new MutableSpriteSet();
        this.spriteSets.put(identifier, mutableSpriteSet);
        this.providers.put(identifier, particleMetaFactory.create(mutableSpriteSet));
    }

    @Nullable
    public class_703 createParticle(class_2960 identifier, class_2394 particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        class_703 particle = this.makeParticle(identifier, particleData, x, y, z, xSpeed, ySpeed, zSpeed);
        if (particle != null) {
            this.minecraft.field_1713.method_3058(particle);
            return particle;
        } else {
            return null;
        }
    }

    @SuppressWarnings("unchecked")
    @Nullable
    private <T extends class_2394> class_703 makeParticle(class_2960 identifier, T particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        if (!this.hasBeenReloaded) ContentRegistrationFlags.throwForFlag(ContentRegistrationFlags.CLIENT_PARTICLE_TYPES);
        class_707<T> particleProvider = (class_707<T>) this.providers.get(identifier);
        return particleProvider == null ? null : particleProvider.method_3090(particleData, this.minecraft.field_1687, x, y, z, xSpeed, ySpeed, zSpeed);
    }

    @Override
    public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
        this.hasBeenReloaded = false;
        record ParticleDefinition(class_2960 id, Optional<List<class_2960>> sprites) {
        }
        CompletableFuture<List<ParticleDefinition>> completablefuture = CompletableFuture.supplyAsync(() -> {
            return PARTICLE_LISTER.method_45113(resourceManager);
        }, backgroundExecutor).thenCompose((resourceMap) -> {
            List<CompletableFuture<ParticleDefinition>> list = new ArrayList<>(resourceMap.size());
            resourceMap.forEach((p_247903_, p_247904_) -> {
                class_2960 resourcelocation = PARTICLE_LISTER.method_45115(p_247903_);
                list.add(CompletableFuture.supplyAsync(() -> {
                    return new ParticleDefinition(resourcelocation, this.loadParticleDescription(resourcelocation, p_247904_));
                }, backgroundExecutor));
            });
            return class_156.method_33791(list);
        });
        class_1059 textureAtlas = (class_1059) class_310.method_1551().method_1531().method_34590(class_1059.field_17898, class_1047.method_4540());
        CompletableFuture<class_7766.class_7767> completablefuture1 = class_7766.method_45837(textureAtlas).method_47661(resourceManager, PARTICLES_ATLAS_INFO, 0, backgroundExecutor).thenCompose(class_7766.class_7767::method_45845);
        return CompletableFuture.allOf(completablefuture1, completablefuture).thenCompose(preparationBarrier::method_18352).thenAcceptAsync($ -> {
//                    this.clearParticles();
            reloadProfiler.method_16065();
            reloadProfiler.method_15396("upload");
            class_7766.class_7767 spriteloader$preparations = completablefuture1.join();
            textureAtlas.method_45848(spriteloader$preparations);
            reloadProfiler.method_15405("bindSpriteSets");
            Set<class_2960> set = new HashSet<>();
            class_1058 textureatlassprite = spriteloader$preparations.comp_1043();
            completablefuture.join().forEach((particleDefinition) -> {
                Optional<List<class_2960>> optional = particleDefinition.sprites();
                if (!optional.isEmpty()) {
                    List<class_1058> list = new ArrayList<>();

                    for(class_2960 resourcelocation : optional.get()) {
                        class_1058 textureatlassprite1 = spriteloader$preparations.comp_1044().get(resourcelocation);
                        if (textureatlassprite1 == null) {
                            set.add(resourcelocation);
                            list.add(textureatlassprite);
                        } else {
                            list.add(textureatlassprite1);
                        }
                    }

                    if (list.isEmpty()) {
                        list.add(textureatlassprite);
                    }

                    this.spriteSets.get(particleDefinition.id()).rebind(list);
                }
            });
            if (!set.isEmpty()) {
                PuzzlesLib.LOGGER.warn("Missing particle sprites: {}", set.stream().sorted().map(class_2960::toString).collect(Collectors.joining(",")));
            }

            reloadProfiler.method_15407();
            reloadProfiler.method_16066();
            this.hasBeenReloaded = true;
        }, gameExecutor);
    }

    private Optional<List<class_2960>> loadParticleDescription(class_2960 registryName, class_3298 resource) {
        if (!this.spriteSets.containsKey(registryName)) {
//            LOGGER.debug("Redundant texture list for particle: {}", registryName);
            return Optional.empty();
        } else {
            try {
                Reader reader = resource.method_43039();

                Optional<List<class_2960>> optional;
                try {
                    class_4089 particleDescription = class_4089.method_18828(class_3518.method_15255(reader));
                    optional = Optional.of(particleDescription.method_18826());
                } catch (Throwable throwable) {
                    try {
                        reader.close();
                    } catch (Throwable throwable1) {
                        throwable.addSuppressed(throwable1);
                    }

                    throw throwable;
                }

                reader.close();

                return optional;
            } catch (IOException e) {
                throw new IllegalStateException("Failed to load description for particle " + registryName, e);
            }
        }
    }

    private static class MutableSpriteSet implements class_4002 {
        private List<class_1058> sprites;

        @Override
        public class_1058 method_18138(int age, int lifetime) {
            return this.sprites.get(age * (this.sprites.size() - 1) / lifetime);
        }

        @Override
        public class_1058 method_18139(class_5819 random) {
            return this.sprites.get(random.method_43048(this.sprites.size()));
        }

        public void rebind(List<class_1058> sprites) {
            this.sprites = ImmutableList.copyOf(sprites);
        }
    }
}
