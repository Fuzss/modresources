package fuzs.puzzleslib.impl.item;

import com.google.gson.JsonObject;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_3955;
import net.minecraft.class_7923;
import net.minecraft.class_8566;
import net.minecraft.world.item.crafting.*;

import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Supplier;

public interface CopyTagRecipe {
    /**
     * The shaped recipe serializer id that is used during registration.
     */
    String SHAPED_RECIPE_SERIALIZER_ID = "copy_tag_shaped_recipe";
    /**
     * The shapeless recipe serializer id that is used during registration.
     */
    String SHAPELESS_RECIPE_SERIALIZER_ID = "copy_tag_shapeless_recipe";

    /**
     * Finds the mod-specific {@link class_1865} in the registry.
     * <p>{@link fuzs.puzzleslib.api.core.v1.ContentRegistrationFlags#COPY_TAG_RECIPES} must be enabled so the serializer is registered.
     *
     * @param modId              the mod id to find the serializer for
     * @param recipeSerializerId the serializer string id, either {@link #SHAPED_RECIPE_SERIALIZER_ID} or {@link #SHAPELESS_RECIPE_SERIALIZER_ID}
     * @return the serializer
     */
    static class_1865<?> getModSerializer(String modId, String recipeSerializerId) {
        class_1865<?> recipeSerializer = class_7923.field_41189.method_10223(new class_2960(modId, recipeSerializerId));
        Objects.requireNonNull(recipeSerializer, "%s serializer for %s is null".formatted(recipeSerializerId, modId));
        return recipeSerializer;
    }

    static void registerSerializers(BiConsumer<String, Supplier<class_1865<?>>> registrar) {
        registrar.accept(SHAPED_RECIPE_SERIALIZER_ID, () -> new Serializer<>(new class_1869.class_1870(), CopyTagShapedRecipe::new));
        registrar.accept(SHAPELESS_RECIPE_SERIALIZER_ID, () -> new Serializer<>(new class_1867.class_1868(), CopyTagShapelessRecipe::new));
    }

    class_1856 getCopyTagSource();

    default void tryCopyTagToResult(class_1799 result, class_8566 craftingContainer) {
        for (int i = 0; i < craftingContainer.method_5439(); i++) {
            class_1799 itemStack = craftingContainer.method_5438(i);
            if (this.getCopyTagSource().method_8093(itemStack) && itemStack.method_7985()) {
                result.method_7980(itemStack.method_7969().method_10553());
                return;
            }
        }
    }

    record Serializer<T extends class_3955, S extends class_3955 & CopyTagRecipe>(
            class_1865<T> serializer, BiFunction<T, class_1856, S> factory) implements class_1865<S> {

        @Override
        public S method_8121(class_2960 recipeId, JsonObject serializedRecipe) {
            T recipe = this.serializer.method_8121(recipeId, serializedRecipe);
            class_1856 ingredient = class_1856.method_52177(class_3518.method_52226(serializedRecipe, "copy_from"));
            return this.factory.apply(recipe, ingredient);
        }

        @Override
        public S method_8122(class_2960 recipeId, class_2540 buffer) {
            T recipe = this.serializer.method_8122(recipeId, buffer);
            class_1856 ingredient = class_1856.method_8086(buffer);
            return this.factory.apply(recipe, ingredient);
        }

        @Override
        public void toNetwork(class_2540 buffer, S recipe) {
            this.serializer.method_8124(buffer, (T) recipe);
            recipe.getCopyTagSource().method_8088(buffer);
        }
    }
}
