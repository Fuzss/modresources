package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_2199;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import net.minecraft.world.inventory.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;

@Mixin(class_1706.class)
abstract class AnvilMenuFabricMixin extends class_4861 {
    @Shadow
    private int repairItemCountCost;
    @Shadow
    private String itemName;
    @Shadow
    @Final
    private class_3915 cost;
    @Unique
    private MutableFloat puzzleslib$breakChance;

    public AnvilMenuFabricMixin(@Nullable class_3917<?> menuType, int i, class_1661 inventory, class_3914 containerLevelAccess) {
        super(menuType, i, inventory, containerLevelAccess);
    }

    @Inject(method = "onTake", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/Container;setItem(ILnet/minecraft/world/item/ItemStack;)V"), slice = @Slice(to = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getCount()I")))
    protected void onTake$0(class_1657 player, class_1799 itemStack, CallbackInfo callback) {
        this.puzzleslib$breakChance = MutableFloat.fromValue(0.12F);
        FabricPlayerEvents.ANVIL_REPAIR.invoker().onAnvilRepair(player, this.field_22480.method_5438(0), this.field_22480.method_5438(1), itemStack, this.puzzleslib$breakChance);
    }

    @Inject(method = "onTake", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/inventory/DataSlot;set(I)V", shift = At.Shift.AFTER), cancellable = true)
    protected void onTake$1(class_1657 player, class_1799 itemStack, CallbackInfo callback) {
        // just copy this part from vanilla, not in the mood to mixin into this lambda
        this.field_22481.method_17393((level, blockPos) -> {
            class_2680 blockState = level.method_8320(blockPos);
            Objects.requireNonNull(this.puzzleslib$breakChance, "break chance is null");
            float breakChance = this.puzzleslib$breakChance.getAsFloat();
            this.puzzleslib$breakChance = null;
            if (!player.method_31549().field_7477 && blockState.method_26164(class_3481.field_15486) && player.method_6051().method_43057() < breakChance) {
                class_2680 blockState2 = class_2199.method_9346(blockState);
                if (blockState2 == null) {
                    level.method_8650(blockPos, false);
                    level.method_20290(1029, blockPos, 0);
                } else {
                    level.method_8652(blockPos, blockState2, 2);
                    level.method_20290(1030, blockPos, 0);
                }
            } else {
                level.method_20290(1030, blockPos, 0);
            }

        });
        // always cancel vanilla, we handle everything
        callback.cancel();
    }

    @Inject(method = "createResult", at = @At("HEAD"), cancellable = true)
    public void createResult(CallbackInfo callback) {
        class_1799 leftInput = this.field_22480.method_5438(0);
        if (leftInput.method_7960()) return;
        class_1799 rightInput = this.field_22480.method_5438(1);
        MutableValue<class_1799> output = MutableValue.fromValue(class_1799.field_8037);
        MutableInt enchantmentCost = MutableInt.fromValue(leftInput.method_7928() + rightInput.method_7928());
        MutableInt materialCost = MutableInt.fromValue(0);
        EventResult result = FabricPlayerEvents.ANVIL_UPDATE.invoker().onAnvilUpdate(leftInput, rightInput, output, this.itemName, enchantmentCost, materialCost, this.field_22482);
        if (result.isPass()) return;
        callback.cancel();
        if (!result.getAsBoolean()) return;
        this.field_22479.method_5447(0, output.get());
        this.cost.method_17404(enchantmentCost.getAsInt());
        this.repairItemCountCost = materialCost.getAsInt();
    }
}
