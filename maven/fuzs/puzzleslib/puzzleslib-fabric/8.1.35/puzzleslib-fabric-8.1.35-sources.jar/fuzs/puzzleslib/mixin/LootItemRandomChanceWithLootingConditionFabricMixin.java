package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_181;
import net.minecraft.class_225;
import net.minecraft.class_47;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_225.class)
public abstract class LootItemRandomChanceWithLootingConditionFabricMixin {

    @ModifyVariable(method = "test", at = @At("STORE"), ordinal = 0)
    public int test(int lootingLevel, class_47 lootContext) {
        class_1297 target = lootContext.method_296(class_181.field_1226);
        if (!(target instanceof class_1309 livingEntity)) return lootingLevel;
        class_1282 damageSource = lootContext.method_296(class_181.field_1231);
        MutableInt mutableLootingLevel = MutableInt.fromValue(lootingLevel);
        FabricLivingEvents.LOOTING_LEVEL.invoker().onLootingLevel(livingEntity, damageSource, mutableLootingLevel);
        return mutableLootingLevel.getAsInt();
    }
}
