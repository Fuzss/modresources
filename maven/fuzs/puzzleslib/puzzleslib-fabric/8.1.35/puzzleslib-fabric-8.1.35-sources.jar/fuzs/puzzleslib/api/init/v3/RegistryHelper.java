package fuzs.puzzleslib.api.init.v3;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.util.Objects;
import java.util.Optional;

/**
 * A helper class for Minecraft's registries.
 */
public final class RegistryHelper {

    private RegistryHelper() {

    }

    /**
     * Finds a registry for the provided {@link class_5321},
     * with dynamic registries only being supported when a game server is already running.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    public static <T> class_2378<T> findRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        return findRegistry(registryKey, false);
    }

    /**
     * Finds a built-in registry for the provided {@link class_5321}.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    public static <T> class_2378<T> findBuiltInRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        return findRegistry(registryKey, true);
    }

    /**
     * Finds a registry for the provided {@link class_5321},
     * with dynamic registries only being supported when a game server is already running.
     *
     * @param registryKey the registry key
     * @param onlyBuiltIn only search in {@link class_7923#field_41167}
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    @SuppressWarnings("unchecked")
    private static <T> class_2378<T> findRegistry(class_5321<? extends class_2378<? super T>> registryKey, boolean onlyBuiltIn) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Optional<class_2378<T>> registry = Optional.empty();
        if (!onlyBuiltIn) {
            MinecraftServer minecraftServer = CommonAbstractions.INSTANCE.getMinecraftServer();
            if (minecraftServer != null) {
                registry = minecraftServer.method_30611().method_33310((class_5321<class_2378<T>>) registryKey);
            }
        }
        if (registry.isEmpty()) {
            registry = ((class_2378<class_2378<T>>) class_7923.field_41167).method_31189((class_5321<class_2378<T>>) registryKey);
        }
        return registry.orElseThrow(() -> {
            return new IllegalArgumentException("Registry for key %s not found".formatted(registryKey));
        });
    }

    /**
     * Retrieves the {@link class_5321} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the resource key for this game object
     */
    public static <T> Optional<class_5321<T>> getResourceKey(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return findRegistry(registryKey).method_29113(object);
    }

    /**
     * Retrieves the {@link class_5321} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the resource key for this game object
     */
    public static <T> class_5321<T> getResourceKeyOrThrow(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return getResourceKey(registryKey, object).orElseThrow(() -> {
            return new IllegalStateException("Missing object in " + registryKey + ": " + object);
        });
    }

    /**
     * Retrieves the {@link class_6880.class_6883} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the holder reference for this game object
     */
    public static <T> Optional<class_6880.class_6883<T>> getHolder(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        class_2378<T> registry = findRegistry(registryKey);
        return registry.method_29113(object).flatMap(registry::method_40264);
    }

    /**
     * Retrieves the {@link class_6880.class_6883} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the holder reference for this game object
     */
    public static <T> class_6880.class_6883<T> getHolderOrThrow(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return getHolder(registryKey, object).orElseThrow(() -> {
            return new IllegalStateException("Missing object in " + registryKey + ": " + object);
        });
    }

    /**
     * Retrieves the {@link class_6880} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the holder for this game object
     */
    public static <T> class_6880<T> wrapAsHolder(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return findRegistry(registryKey).method_47983(object);
    }

    /**
     * Checks if a certain tag contains a given value.
     * <p>Some game objects such as blocks, items and entity types do not require this approach as they hold a reference to their registry holder.
     *
     * @param tagKey the tag key
     * @param object the game object to check the tag key for
     * @param <T>    tag and game object type
     * @return is the game object contained in the tag
     */
    @SuppressWarnings({"unchecked", "deprecation"})
    public static <T> boolean is(class_6862<T> tagKey, T object) {
        if (object instanceof class_2248 block) {
            return block.method_40142().method_40220((class_6862<class_2248>) tagKey);
        } else if (object instanceof class_1792 item) {
            return item.method_40131().method_40220((class_6862<class_1792>) tagKey);
        } else if (object instanceof class_1299<?> entityType) {
            return entityType.method_40124().method_40220((class_6862<class_1299<?>>) tagKey);
        } else if (object instanceof class_5712 gameEvent) {
            return gameEvent.method_40157().method_40220((class_6862<class_5712>) tagKey);
        } else if (object instanceof class_3611 fluid) {
            return fluid.method_40178().method_40220((class_6862<class_3611>) tagKey);
        }
        class_2378<T> registry = findRegistry(tagKey.comp_326());
        return tagKey.method_41007(registry.method_30517()) && registry.method_47983(object).method_40220(tagKey);
    }
}
