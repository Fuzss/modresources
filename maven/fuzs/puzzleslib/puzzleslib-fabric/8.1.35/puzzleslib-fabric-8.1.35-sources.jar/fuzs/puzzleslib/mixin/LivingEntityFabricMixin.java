package fuzs.puzzleslib.mixin;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.*;
import fuzs.puzzleslib.impl.PuzzlesLib;
import fuzs.puzzleslib.impl.event.CapturedDropsEntity;
import fuzs.puzzleslib.impl.event.EventImplHelper;
import fuzs.puzzleslib.impl.event.FabricEventImplHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

@Mixin(class_1309.class)
abstract class LivingEntityFabricMixin extends class_1297 {
    @Unique
    private final ThreadLocal<class_1799> puzzleslib$originalUseItem = new ThreadLocal<>();
    @Shadow
    protected class_1799 useItem;
    @Shadow
    protected int useItemRemaining;
    @Shadow
    @Nullable
    protected class_1657 lastHurtByPlayer;
    @Shadow
    protected int lastHurtByPlayerTime;
    @Shadow
    @Final
    private Map<class_1291, class_1293> activeEffects;
    @Unique
    private MutableInt puzzleslib$lootingLevel;
    @Unique
    private DefaultedFloat puzzleslib$damageAmount;
    @Unique
    private float puzzleslib$hurtAmount;
    @Unique
    private DefaultedFloat puzzleslib$fallDistance;
    @Unique
    private DefaultedFloat puzzleslib$damageMultiplier;
    @Unique
    private DefaultedDouble puzzleslib$strength;
    @Unique
    private DefaultedDouble puzzleslib$ratioX;
    @Unique
    private DefaultedDouble puzzleslib$ratioZ;

    public LivingEntityFabricMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    public void tick(CallbackInfo callback) {
        if (FabricLivingEvents.LIVING_TICK.invoker().onLivingTick(class_1309.class.cast(this)).isInterrupt())
            callback.cancel();
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    public void die(class_1282 damageSource, CallbackInfo callback) {
        EventResult result = FabricLivingEvents.LIVING_DEATH.invoker().onLivingDeath(class_1309.class.cast(this), damageSource);
        if (result.isInterrupt()) callback.cancel();
    }

    @Inject(method = "startUsingItem", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/LivingEntity;useItemRemaining:I", shift = At.Shift.AFTER), cancellable = true)
    public void startUsingItem(class_1268 hand, CallbackInfo callback) {
        // this injects after the field is already updated, so it is fine to use instead of ItemStack::getUseDuration
        DefaultedInt useItemRemaining = DefaultedInt.fromValue(this.useItemRemaining);
        EventResult result = FabricLivingEvents.USE_ITEM_START.invoker().onUseItemStart(class_1309.class.cast(this), this.useItem, useItemRemaining);
        if (result.isInterrupt()) {
            this.useItem = class_1799.field_8037;
            this.useItemRemaining = 0;
            callback.cancel();
        } else {
            this.useItemRemaining = useItemRemaining.getAsOptionalInt().orElse(this.useItemRemaining);
        }
    }

    @Inject(method = "updateUsingItem", at = @At("HEAD"), cancellable = true)
    protected void updateUsingItem(class_1799 usingItem, CallbackInfo callback) {
        if (!usingItem.method_7960()) {
            DefaultedInt remainingUseDuration = DefaultedInt.fromValue(this.getUseItemRemainingTicks());
            EventResult result = FabricLivingEvents.USE_ITEM_TICK.invoker().onUseItemTick(class_1309.class.cast(this), usingItem, remainingUseDuration);
            // --this.useItemRemaining == 0 runs at the end of this method, when 0 is set increase by one again so that LivingEntity::completeUsingItem does run
            remainingUseDuration.getAsOptionalInt().ifPresent(t -> this.useItemRemaining = t == 0 ? 1 : t);
            if (result.isInterrupt()) {
                // this copies LivingEntity::updateUsingItem without calling ItemStack::onUseTick
                if (this.shouldTriggerItemUseEffects()) {
                    this.triggerItemUseEffects(usingItem, 5);
                }
                if (--this.useItemRemaining == 0 && !this.method_37908().field_9236 && !usingItem.method_7967()) {
                    this.completeUsingItem();
                }
                callback.cancel();
            }
        }
    }

    @Shadow
    public abstract int getUseItemRemainingTicks();

    @Shadow
    private boolean shouldTriggerItemUseEffects() {
        throw new RuntimeException();
    }

    @Shadow
    protected abstract void triggerItemUseEffects(class_1799 stack, int amount);

    @Shadow
    protected abstract void completeUsingItem();

    @Shadow
    private void updatingUsingItem() {
        throw new RuntimeException();
    }

    @Inject(method = "completeUsingItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;", shift = At.Shift.BEFORE))
    protected void completeUsingItem(CallbackInfo callback) {
        this.puzzleslib$originalUseItem.set(this.useItem.method_7972());
    }

    @ModifyVariable(method = "completeUsingItem", at = @At("STORE"), ordinal = 0)
    protected class_1799 completeUsingItem(class_1799 useItem) {
        Objects.requireNonNull(this.puzzleslib$originalUseItem.get(), "use item copy is null");
        DefaultedValue<class_1799> stack = DefaultedValue.fromValue(useItem);
        FabricLivingEvents.USE_ITEM_FINISH.invoker().onUseItemFinish(class_1309.class.cast(this), stack, this.useItemRemaining, this.puzzleslib$originalUseItem.get());
        useItem = stack.getAsOptional().orElse(useItem);
        this.puzzleslib$originalUseItem.remove();
        return useItem;
    }

    @Shadow
    public abstract void stopUsingItem();

    @Inject(method = "releaseUsingItem", at = @At("HEAD"), cancellable = true)
    public void releaseUsingItem(CallbackInfo callback) {
        if (!this.useItem.method_7960()) {
            if (FabricLivingEvents.USE_ITEM_STOP.invoker().onUseItemStop(class_1309.class.cast(this), this.useItem, this.useItemRemaining).isPass())
                return;
            if (this.useItem.method_7967()) {
                this.updatingUsingItem();
            }
            this.stopUsingItem();
            callback.cancel();
        }
    }

    @ModifyVariable(method = "dropAllDeathLoot", at = @At("STORE"), ordinal = 0)
    protected int dropAllDeathLoot$0(int lootingLevel, class_1282 damageSource) {
        // we do not have access to the local lootingLevel variable at TAIL later where it is needed for invoking LivingDropsCallback
        // (the local capture seems to fail due to the way the local lootingLevel variable is initialised)
        // so instead capture the value after our LootingLevelCallback has run, potentially missing out on changes applied by other mixins
        this.puzzleslib$lootingLevel = FabricEventImplHelper.onLootingLevel(class_1309.class.cast(this), damageSource, lootingLevel);
        return this.puzzleslib$lootingLevel.getAsInt();
    }

    @Inject(method = "dropAllDeathLoot", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/LivingEntity;lastHurtByPlayerTime:I", shift = At.Shift.BEFORE))
    protected void dropAllDeathLoot$1(class_1282 damageSource, CallbackInfo callback) {
        ((CapturedDropsEntity) this).puzzleslib$acceptCapturedDrops(Lists.newArrayList());
    }

    @Inject(method = "dropAllDeathLoot", at = @At("TAIL"))
    protected void dropAllDeathLoot$2(class_1282 damageSource, CallbackInfo callback) {
        if (!FabricEventImplHelper.tryOnLivingDrops(class_1309.class.cast(this), damageSource, this.lastHurtByPlayerTime, () -> this.puzzleslib$lootingLevel)) {
            PuzzlesLib.LOGGER.warn("Unable to invoke LivingDropsCallback for entity {}: Drops is null", this.method_5477().getString());
        }
        this.puzzleslib$lootingLevel = null;
    }

    @Inject(method = "die", at = @At("TAIL"))
    public void die$1(class_1282 damageSource, CallbackInfo callback) {
        // this is a safety precaution, in case LivingEntity::dropAllDeathLoot does not reach TAIL and therefore doesn't spawn the captured drops (another mixin might cancel the method mid-way)
        // this should work rather fine, as LivingEntity::dropAllDeathLoot is basically exclusively called from LivingEntity::die,
        // and spawning captured drops in LivingEntity::dropAllDeathLoot only rarely has a conflict if any at all
        FabricEventImplHelper.tryOnLivingDrops(class_1309.class.cast(this), damageSource, this.lastHurtByPlayerTime, () -> {
            int lootingLevel = damageSource.method_5529() instanceof class_1657 player ? class_1890.method_8226(player) : 0;
            return FabricEventImplHelper.onLootingLevel(class_1309.class.cast(this), damageSource, lootingLevel);
        });
    }

    @Inject(method = "dropExperience", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ExperienceOrb;award(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;I)V"), cancellable = true)
    protected void dropExperience(CallbackInfo callback) {
        DefaultedInt experienceReward = DefaultedInt.fromValue(this.getExperienceReward());
        EventResult result = FabricLivingEvents.EXPERIENCE_DROP.invoker().onLivingExperienceDrop(class_1309.class.cast(this), this.lastHurtByPlayer, experienceReward);
        if (result.isInterrupt()) {
            callback.cancel();
        } else {
            experienceReward.getAsOptionalInt().ifPresent(value -> {
                class_1303.method_31493((class_3218) this.method_37908(), this.method_19538(), value);
                callback.cancel();
            });
        }
    }

    @Shadow
    protected abstract int getExperienceReward();

    @Inject(method = "actuallyHurt", at = @At("HEAD"), cancellable = true)
    protected void actuallyHurt(class_1282 damageSource, float damageAmount, CallbackInfo callback) {
        if (!this.method_5679(damageSource)) {
            this.puzzleslib$damageAmount = DefaultedFloat.fromValue(damageAmount);
            if (FabricLivingEvents.LIVING_HURT.invoker().onLivingHurt(class_1309.class.cast(this), damageSource, this.puzzleslib$damageAmount).isInterrupt()) {
                callback.cancel();
            }
        }
    }

    @ModifyVariable(method = "actuallyHurt", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    protected float actuallyHurt(float damageAmount, class_1282 damageSource) {
        if (!this.method_5679(damageSource)) {
            Objects.requireNonNull(this.puzzleslib$damageAmount, "damage amount is null");
            damageAmount = this.puzzleslib$damageAmount.getAsOptionalFloat().orElse(damageAmount);
            this.puzzleslib$damageAmount = null;
        }
        return damageAmount;
    }

    @Shadow
    public abstract boolean isDamageSourceBlocked(class_1282 damageSource);

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    public void hurt(class_1282 source, float amount, CallbackInfoReturnable<Boolean> callback) {
        if (class_1657.class.isInstance(this)) return;
        EventResult result = FabricLivingEvents.LIVING_ATTACK.invoker().onLivingAttack(class_1309.class.cast(this), source, amount);
        if (result.isInterrupt()) callback.setReturnValue(false);
    }

    @ModifyVariable(method = "hurt", at = @At(value = "LOAD", ordinal = 1), ordinal = 0)
    public float hurt$0(float amount, class_1282 source) {
        // hook in before any blocking checks are done, there is no good way to cancel the block after this
        // check everything again, it shouldn't affect anything
        if (amount > 0.0F && this.isDamageSourceBlocked(source)) {
            this.puzzleslib$hurtAmount = amount;
            DefaultedFloat blockedDamage = DefaultedFloat.fromValue(amount);
            EventResult result = FabricLivingEvents.SHIELD_BLOCK.invoker().onShieldBlock(class_1309.class.cast(this), source, blockedDamage);
            // prevent vanilla shield logic from running when the callback was cancelled, the original damage amount is restored from puzzleslib$hurtAmount later
            if (result.isInterrupt()) return 0.0F;
            // reduce by blocked amount
            this.puzzleslib$hurtAmount -= blockedDamage.getAsFloat();
            // return the amount blocked by the shield
            return blockedDamage.getAsFloat();
        }
        return amount;
    }

    @ModifyVariable(method = "hurt", at = @At(value = "FIELD", target = "Lnet/minecraft/world/entity/LivingEntity;walkAnimation:Lnet/minecraft/world/entity/WalkAnimationState;", shift = At.Shift.BEFORE), ordinal = 0)
    public float hurt$1(float amount, class_1282 source) {
        // this is only present if the damage source could be blocked
        if (this.puzzleslib$hurtAmount != 0.0F) {
            // restore original amount when the shield blocking callback was cancelled
            amount = this.puzzleslib$hurtAmount;
            this.puzzleslib$hurtAmount = 0.0F;
        }
        return amount;
    }

    @Inject(method = "causeFallDamage", at = @At("HEAD"), cancellable = true)
    public void causeFallDamage$0(float distance, float damageMultiplier, class_1282 damageSource, CallbackInfoReturnable<Boolean> callback) {
        this.puzzleslib$fallDistance = DefaultedFloat.fromValue(distance);
        this.puzzleslib$damageMultiplier = DefaultedFloat.fromValue(damageMultiplier);
        if (FabricLivingEvents.LIVING_FALL.invoker().onLivingFall(class_1309.class.cast(this), this.puzzleslib$fallDistance, this.puzzleslib$damageMultiplier).isInterrupt()) {
            callback.setReturnValue(false);
        }
    }

    @ModifyVariable(method = "causeFallDamage", at = @At(value = "HEAD"), ordinal = 0, argsOnly = true)
    public float causeFallDamage$1(float fallDistance) {
        Objects.requireNonNull(this.puzzleslib$fallDistance, "fall distance is null");
        fallDistance = this.puzzleslib$fallDistance.getAsOptionalFloat().orElse(fallDistance);
        this.puzzleslib$fallDistance = null;
        return fallDistance;
    }

    @ModifyVariable(method = "causeFallDamage", at = @At(value = "HEAD"), ordinal = 1, argsOnly = true)
    public float causeFallDamage$2(float damageMultiplier) {
        Objects.requireNonNull(this.puzzleslib$damageMultiplier, "damage multiplier is null");
        damageMultiplier = this.puzzleslib$damageMultiplier.getAsOptionalFloat().orElse(damageMultiplier);
        this.puzzleslib$damageMultiplier = null;
        return damageMultiplier;
    }

    @Inject(method = "knockback", at = @At("HEAD"), cancellable = true)
    public void knockback$0(double strength, double ratioX, double ratioZ, CallbackInfo callback) {
        this.puzzleslib$strength = DefaultedDouble.fromValue(strength);
        this.puzzleslib$ratioX = DefaultedDouble.fromValue(ratioX);
        this.puzzleslib$ratioZ = DefaultedDouble.fromValue(ratioZ);
        if (FabricLivingEvents.LIVING_KNOCK_BACK.invoker().onLivingKnockBack(class_1309.class.cast(this), this.puzzleslib$strength, this.puzzleslib$ratioX, this.puzzleslib$ratioZ).isInterrupt()) {
            callback.cancel();
        }
    }

    @ModifyVariable(method = "knockback", at = @At(value = "HEAD"), ordinal = 0, argsOnly = true)
    public double knockback$1(double strength) {
        Objects.requireNonNull(this.puzzleslib$strength, "strength is null");
        strength = this.puzzleslib$strength.getAsOptionalDouble().orElse(strength);
        this.puzzleslib$strength = null;
        return strength;
    }

    @ModifyVariable(method = "knockback", at = @At(value = "HEAD"), ordinal = 1, argsOnly = true)
    public double knockback$2(double ratioX) {
        Objects.requireNonNull(this.puzzleslib$ratioX, "ratio x is null");
        ratioX = this.puzzleslib$ratioX.getAsOptionalDouble().orElse(ratioX);
        this.puzzleslib$ratioX = null;
        return ratioX;
    }

    @ModifyVariable(method = "knockback", at = @At(value = "HEAD"), ordinal = 2, argsOnly = true)
    public double knockback$3(double ratioZ) {
        Objects.requireNonNull(this.puzzleslib$ratioZ, "ratio z is null");
        ratioZ = this.puzzleslib$ratioZ.getAsOptionalDouble().orElse(ratioZ);
        this.puzzleslib$ratioZ = null;
        return ratioZ;
    }

    @ModifyVariable(method = "addEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)Z", at = @At("STORE"), ordinal = 1)
    public class_1293 addEffect(@Nullable class_1293 oldEffectInstance, class_1293 effectInstance, @Nullable class_1297 entity) {
        FabricLivingEvents.MOB_EFFECT_APPLY.invoker().onMobEffectApply(class_1309.class.cast(this), effectInstance, oldEffectInstance, entity);
        return oldEffectInstance;
    }

    @Inject(method = "canBeAffected", at = @At("HEAD"), cancellable = true)
    public void canBeAffected(class_1293 effectInstance, CallbackInfoReturnable<Boolean> callback) {
        // Forge also adds this patch to spiders, but let's just say no one wants to remove poison immunity from them
        // Forge is incomplete anyway, with mobs are not affected by this event when checking for the wither effect
        EventResult result = FabricLivingEvents.MOB_EFFECT_AFFECTS.invoker().onMobEffectAffects(class_1309.class.cast(this), effectInstance);
        if (result.isInterrupt()) callback.setReturnValue(result.getAsBoolean());
    }

    @Inject(method = "removeEffect", at = @At("HEAD"), cancellable = true)
    public void removeEffect(class_1291 effect, CallbackInfoReturnable<Boolean> callback) {
        EventResult result = FabricLivingEvents.MOB_EFFECT_REMOVE.invoker().onMobEffectRemove(class_1309.class.cast(this), this.getEffect(effect));
        if (result.isInterrupt()) callback.setReturnValue(false);
    }

    @Shadow
    @Nullable
    public abstract class_1293 getEffect(class_1291 effect);

    @Inject(method = "removeEffect", at = @At("HEAD"))
    public void removeAllEffects(CallbackInfoReturnable<Boolean> callback) {
        if (this.method_37908().field_9236) return;
        Set<class_1293> activeEffectsToKeep = Sets.newIdentityHashSet();
        for (class_1293 mobEffectInstance : this.activeEffects.values()) {
            EventResult result = FabricLivingEvents.MOB_EFFECT_REMOVE.invoker().onMobEffectRemove(class_1309.class.cast(this), mobEffectInstance);
            if (result.isInterrupt()) activeEffectsToKeep.add(mobEffectInstance);
        }
        if (!activeEffectsToKeep.isEmpty()) {
            Iterator<class_1293> iterator = this.activeEffects.values().iterator();
            boolean flag;
            for (flag = false; iterator.hasNext(); flag = true) {
                class_1293 effect = iterator.next();
                this.onEffectRemoved(effect);
                iterator.remove();
            }
            callback.setReturnValue(flag);
        }
    }

    @Shadow
    protected abstract void onEffectRemoved(class_1293 effectInstance);

    @ModifyVariable(method = "tickEffects", at = @At(value = "INVOKE", target = "Ljava/util/Iterator;remove()V"), ordinal = 0)
    protected class_1293 tickEffects(class_1293 mobEffectInstance) {
        FabricLivingEvents.MOB_EFFECT_EXPIRE.invoker().onMobEffectExpire(class_1309.class.cast(this), mobEffectInstance);
        return mobEffectInstance;
    }

    @Inject(method = "jumpFromGround", at = @At("TAIL"))
    protected void jumpFromGround(CallbackInfo callback) {
        EventImplHelper.onLivingJump(FabricLivingEvents.LIVING_JUMP.invoker(), class_1309.class.cast(this));
    }

    @ModifyVariable(method = "getVisibilityPercent", at = @At(value = "TAIL", shift = At.Shift.BEFORE), ordinal = 0)
    public double getVisibilityPercent(double value, @Nullable class_1297 lookingEntity) {
        DefaultedDouble visibilityPercentage = DefaultedDouble.fromValue(value);
        FabricLivingEvents.LIVING_VISIBILITY.invoker().onLivingVisibility(class_1309.class.cast(this), lookingEntity, visibilityPercentage);
        return visibilityPercentage.getAsOptionalDouble().stream().map(t -> Math.max(t, 0.0)).findAny().orElse(value);
    }

    @Inject(method = "collectEquipmentChanges", at = @At(value = "INVOKE", target = "Ljava/util/Map;put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;"), locals = LocalCapture.CAPTURE_FAILHARD)
    private void collectEquipmentChanges(CallbackInfoReturnable<Map<class_1304, class_1799>> callback, Map<class_1304, class_1799> map, class_1304[] values, int $0, int $1, class_1304 equipmentSlot, class_1799 oldItemStack, class_1799 newItemStack) {
        FabricLivingEvents.LIVING_EQUIPMENT_CHANGE.invoker().onLivingEquipmentChange(class_1309.class.cast(this), equipmentSlot, oldItemStack, newItemStack);
    }
}
