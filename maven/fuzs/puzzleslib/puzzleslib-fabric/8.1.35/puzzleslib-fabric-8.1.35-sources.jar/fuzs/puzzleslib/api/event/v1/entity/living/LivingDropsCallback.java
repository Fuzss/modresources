package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1542;

public interface LivingDropsCallback {
    EventInvoker<LivingDropsCallback> EVENT = EventInvoker.lookup(LivingDropsCallback.class);

    /**
     * Called right before drops from a killed entity are spawned in the world.
     * <p>This event is fired whenever an Entity dies and drops items in {@link class_1309#method_6078(class_1282)}.
     * <p><code>drops</code> can be modified to change the loot that is dropped.
     *
     * @param entity       the entity that has been killed
     * @param source       damage source that killed the entity
     * @param drops        all drops, including equipment, so not just drops from the entity's loot table; this can be modified
     * @param lootingLevel looting level of killer weapon
     * @param recentlyHit  does this count as a player kill, meaning <code>lastHurtByPlayerTime</code> in {@link class_1309} is not zero
     * @return {@link EventResult#INTERRUPT} to prevent any drops from spawning,
     * {@link EventResult#PASS} to allow drops to be spawned in the world; will have the same result as {@link EventResult#INTERRUPT} if <code>drops</code> is empty
     */
    EventResult onLivingDrops(class_1309 entity, class_1282 source, Collection<class_1542> drops, int lootingLevel, boolean recentlyHit);
}
