package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import net.minecraft.class_1657;
import net.minecraft.class_1799;

@FunctionalInterface
public interface AnvilRepairCallback {
    EventInvoker<AnvilRepairCallback> EVENT = EventInvoker.lookup(AnvilRepairCallback.class);

    /**
     * Called when the player takes the output item from an anvil, used to determine the chance by which the anvil will break down one stage.
     *
     * @param player      the player interacting with the anvil
     * @param leftInput   left input item stack
     * @param rightInput  right input item stack
     * @param output      the output stack the player is about to take
     * @param breakChance chance for the anvil to break down one stage
     */
    void onAnvilRepair(class_1657 player, class_1799 leftInput, class_1799 rightInput, class_1799 output, MutableFloat breakChance);
}
