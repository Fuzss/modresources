package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.init.v2.PotionBrewingRegistry;
import net.fabricmc.fabric.api.registry.FabricBrewingRecipeRegistry;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1856;
import java.util.Objects;

public final class PotionBrewingRegistryFabric implements PotionBrewingRegistry {

    @Override
    public void registerContainerRecipe(class_1812 from, class_1856 ingredient, class_1812 to) {
        Objects.requireNonNull(from, "from item is null");
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(to, "to item is null");
        FabricBrewingRecipeRegistry.registerItemRecipe(from, ingredient, to);
    }

    @Override
    public void registerPotionContainer(class_1812 container) {
        Objects.requireNonNull(container, "container item is null");
        class_1845.method_8080(container);
    }

    @Override
    public void registerPotionRecipe(class_1842 from, class_1856 ingredient, class_1842 to) {
        Objects.requireNonNull(from, "from potion is null");
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(to, "to potion is null");
        FabricBrewingRecipeRegistry.registerPotionRecipe(from, ingredient, to);
    }
}
