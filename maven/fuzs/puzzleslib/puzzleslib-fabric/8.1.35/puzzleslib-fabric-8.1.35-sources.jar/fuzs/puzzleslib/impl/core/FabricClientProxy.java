package fuzs.puzzleslib.impl.core;

import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.mixin.client.accessor.MultiPlayerGameModeFabricAccessor;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2596;
import net.minecraft.class_2792;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.IntFunction;

public class FabricClientProxy extends FabricServerProxy implements ClientProxyImpl {

    @Override
    public <T extends MessageV2<T>> void registerLegacyClientReceiver(class_2960 channelName, Function<class_2540, T> factory) {
        ClientPlayNetworking.registerGlobalReceiver(channelName, (class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) -> {
            T message = factory.apply(buf);
            client.execute(() -> message.makeHandler().handle(message, client.field_1724, client));
        });
    }

    @Override
    public <T extends Record & ClientboundMessage<T>> void registerClientReceiver(class_2960 channelName, Function<class_2540, T> factory) {
        ClientPlayNetworking.registerGlobalReceiver(channelName, (class_310 client, class_634 handler, class_2540 buf, PacketSender responseSender) -> {
            T message = factory.apply(buf);
            client.execute(() -> {
                class_746 player = client.field_1724;
                Objects.requireNonNull(player, "player is null");
                message.getHandler().handle(message, client, handler, player, client.field_1687);
            });
        });
    }

    @Override
    public boolean shouldStartDestroyBlock(class_2338 blockPos) {
        MultiPlayerGameModeFabricAccessor gameMode = (MultiPlayerGameModeFabricAccessor) class_310.method_1551().field_1761;
        return !gameMode.puzzleslib$getIsDestroying() || !gameMode.puzzleslib$callSameDestroyTarget(blockPos);
    }

    @Override
    public void startClientPrediction(class_1937 level, IntFunction<class_2596<class_2792>> predictiveAction) {
        ((MultiPlayerGameModeFabricAccessor) class_310.method_1551().field_1761).puzzleslib$callStartPrediction((class_638) level, predictiveAction::apply);
    }
}
