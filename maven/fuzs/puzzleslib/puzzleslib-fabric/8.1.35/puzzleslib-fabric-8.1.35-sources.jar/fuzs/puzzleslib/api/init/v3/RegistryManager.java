package fuzs.puzzleslib.api.init.v3;

import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.core.v1.ModLoader;
import fuzs.puzzleslib.api.init.v2.builder.ExtendedMenuSupplier;
import fuzs.puzzleslib.impl.core.ModContext;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1703;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1842;
import net.minecraft.class_1860;
import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6880;
import net.minecraft.class_7701;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/**
 * Handles registering to game registries. Registration is performed instantly on Fabric and is deferred on Forge.
 */
public interface RegistryManager {

    /**
     * Creates a new registry manager for <code>modId</code> or returns an existing one.
     *
     * @param modId namespace used for registration
     * @return mod specific registry manager
     */
    static RegistryManager from(String modId) {
        return ModContext.get(modId).getRegistryManagerV3();
    }

    /**
     * Creates a new {@link class_5321} for a provided registry from the given <code>path</code>.
     *
     * @param registryKey key for registry to create {@link class_5321} for
     * @param path        path for new entry
     * @param <T>         registry type
     * @return {@link class_5321} for <code>path</code>
     */
    @SuppressWarnings("unchecked")
    default <T> class_5321<T> makeResourceKey(class_5321<? extends class_2378<? super T>> registryKey, String path) {
        return class_5321.method_29179((class_5321<class_2378<T>>) registryKey, this.makeKey(path));
    }

    /**
     * @param path path for location
     * @return resource location for set namespace
     */
    class_2960 makeKey(String path);

    /**
     * allows for registering content in the common project for only a few mod loaders
     *
     * @param allowedModLoaders the mod loaders to register on, every mod loader not registered to should handle this in the loader specific subproject
     * @return this manager as a builder
     */
    RegistryManager whenOn(ModLoader... allowedModLoaders);

    /**
     * allows for registering content in the common project for only a few mod loaders
     *
     * @param forbiddenModLoaders the mod loaders to not register on
     * @return this manager as a builder
     */
    default RegistryManager whenNotOn(ModLoader... forbiddenModLoaders) {
        Objects.checkIndex(0, forbiddenModLoaders.length);
        return this.whenOn(EnumSet.complementOf(Sets.newEnumSet(Arrays.asList(forbiddenModLoaders), ModLoader.class)).toArray(ModLoader[]::new));
    }

    /**
     * Creates a placeholder registry reference.
     *
     * @param registryKey key for registry to register to
     * @param path        path for new entry
     * @param <T>         registry type
     * @return new placeholder registry object
     */
    <T> class_6880.class_6883<T> getHolder(class_5321<? extends class_2378<? super T>> registryKey, String path);

    /**
     * register any type of registry entry with a path
     *
     * @param registryKey key for registry to register to
     * @param path        path for new entry
     * @param supplier    supplier for entry to register
     * @param <T>         registry type
     * @return new registry object
     */
    <T> class_6880.class_6883<T> register(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier);

    /**
     * register block entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @return new registry object
     */
    default class_6880.class_6883<class_2248> registerBlock(String path, Supplier<class_2248> entry) {
        return this.register(class_7924.field_41254, path, entry);
    }

    /**
     * register item entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @return new registry object
     */
    default class_6880.class_6883<class_1792> registerItem(String path, Supplier<class_1792> entry) {
        return this.register(class_7924.field_41197, path, entry);
    }

    /**
     * Registers a block item for a given block.
     *
     * @param blockReference reference for block to register item variant for
     * @return registry object for the new block item
     */
    default class_6880.class_6883<class_1792> registerBlockItem(class_6880.class_6883<class_2248> blockReference) {
        return this.registerBlockItem(blockReference, new class_1792.class_1793());
    }

    /**
     * Registers a block item for a given block.
     *
     * @param blockReference reference for block to register item variant for
     * @param itemProperties properties for item
     * @return registry object for the new block item
     */
    default class_6880.class_6883<class_1792> registerBlockItem(class_6880.class_6883<class_2248> blockReference, class_1792.class_1793 itemProperties) {
        return this.registerItem(blockReference.method_40237().method_29177().method_12832(), () -> new class_1747(blockReference.comp_349(), itemProperties));
    }

    /**
     * Registers a spawn egg item for a given entity type.
     *
     * @param entityTypeReference reference for the entity type to register a spawn egg for
     * @param backgroundColor     background color of the spawn egg item
     * @param highlightColor      spots color pf the spawn egg item
     * @return registry reference for the new spawn egg item
     */
    default class_6880.class_6883<class_1792> registerSpawnEggItem(class_6880.class_6883<? extends class_1299<? extends class_1308>> entityTypeReference, int backgroundColor, int highlightColor) {
        return this.registerSpawnEggItem(entityTypeReference, backgroundColor, highlightColor, new class_1792.class_1793());
    }

    /**
     * Registers a spawn egg item for a given entity type.
     *
     * @param entityTypeReference reference for the entity type to register a spawn egg for
     * @param backgroundColor     background color of the spawn egg item
     * @param highlightColor      spots color pf the spawn egg item
     * @param itemProperties      properties for the item
     * @return registry reference for the new spawn egg item
     */
    class_6880.class_6883<class_1792> registerSpawnEggItem(class_6880.class_6883<? extends class_1299<? extends class_1308>> entityTypeReference, int backgroundColor, int highlightColor, class_1792.class_1793 itemProperties);

    /**
     * register fluid entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @return new registry object
     */
    default class_6880.class_6883<class_3611> registerFluid(String path, Supplier<class_3611> entry) {
        return this.register(class_7924.field_41270, path, entry);
    }

    /**
     * register mob effect entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @return new registry object
     */
    default class_6880.class_6883<class_1291> registerMobEffect(String path, Supplier<class_1291> entry) {
        return this.register(class_7924.field_41208, path, entry);
    }

    /**
     * register sound event entry with a path
     *
     * @param path path for new entry
     * @return new registry object
     */
    default class_6880.class_6883<class_3414> registerSoundEvent(String path) {
        return this.register(class_7924.field_41225, path, () -> class_3414.method_47908(this.makeKey(path)));
    }

    /**
     * register potion entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @return new registry object
     */
    default class_6880.class_6883<class_1842> registerPotion(String path, Supplier<class_1842> entry) {
        return this.register(class_7924.field_41215, path, entry);
    }

    /**
     * register enchantment entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @return new registry object
     */
    default class_6880.class_6883<class_1887> registerEnchantment(String path, Supplier<class_1887> entry) {
        return this.register(class_7924.field_41265, path, entry);
    }

    /**
     * register entity type entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @param <T>   entity type parameter
     * @return new registry object
     */
    @SuppressWarnings("unchecked")
    default <T extends class_1297> class_6880.class_6883<class_1299<T>> registerEntityType(String path, Supplier<class_1299.class_1300<T>> entry) {
        return this.register((class_5321<class_2378<class_1299<T>>>) (class_5321<?>) class_7924.field_41266, path, () -> entry.get().method_5905(path));
    }

    /**
     * register tile entity type entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @param <T>   block entity type parameter
     * @return new registry object
     */
    @SuppressWarnings("unchecked")
    default <T extends class_2586> class_6880.class_6883<class_2591<T>> registerBlockEntityType(String path, Supplier<class_2591.class_2592<T>> entry) {
        return this.register((class_5321<class_2378<class_2591<T>>>) (class_5321<?>) class_7924.field_41255, path, () -> entry.get().method_11034(null));
    }

    /**
     * register container type entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @param <T>   container menu type parameter
     * @return new registry object
     */
    @SuppressWarnings("unchecked")
    default <T extends class_1703> class_6880.class_6883<class_3917<T>> registerMenuType(String path, Supplier<class_3917.class_3918<T>> entry) {
        return this.register((class_5321<class_2378<class_3917<T>>>) (class_5321<?>) class_7924.field_41207, path, () -> new class_3917<>(entry.get(), class_7701.field_40183));
    }

    /**
     * register container type entry with a path
     *
     * @param path  path for new entry
     * @param entry supplier for entry to register
     * @param <T>   container menu type
     * @return new registry object
     */
    <T extends class_1703> class_6880.class_6883<class_3917<T>> registerExtendedMenuType(String path, Supplier<ExtendedMenuSupplier<T>> entry);

    /**
     * Creates and registers a new poi type entry.
     *
     * @param path  path for new entry
     * @param block block valid for this poi type
     * @return new registry object
     */
    default class_6880.class_6883<class_4158> registerPoiType(String path, Supplier<class_2248> block) {
        return this.registerPoiType(path, () -> ImmutableSet.copyOf(block.get().method_9595().method_11662()), 0, 1);
    }

    /**
     * Creates and registers a new poi type entry.
     *
     * @param path           path for new entry
     * @param matchingStates blocks states valid for this poi type
     * @param maxTickets     max amount of accessor tickets
     * @param validRange     distance to search for this poi type
     * @return new registry object
     */
    class_6880.class_6883<class_4158> registerPoiType(String path, Supplier<Set<class_2680>> matchingStates, int maxTickets, int validRange);

    /**
     * register a new type of recipe
     *
     * @param path path for new entry
     * @param <T>  recipe type
     * @return new registry object
     */
    default <T extends class_1860<?>> class_6880.class_6883<class_3956<T>> registerRecipeType(String path) {
        return this.register(class_7924.field_41217, path, () -> new class_3956<>() {
            private final String id = RegistryManager.this.makeKey(path).toString();

            @Override
            public String toString() {
                return this.id;
            }
        });
    }

    /**
     * register a new game event that can be listened to
     *
     * @param path               path for new entry
     * @param notificationRadius range in blocks in which this event will be listened to
     * @return new registry object
     */
    default class_6880.class_6883<class_5712> registerGameEvent(String path, int notificationRadius) {
        return this.register(class_7924.field_41273, path, () -> new class_5712(path, notificationRadius));
    }

    /**
     * Register a new simple particle type.
     *
     * @param path path for new entry
     * @return new registry object
     */
    default class_6880.class_6883<class_2400> registerParticleType(String path) {
        return this.register(class_7924.field_41210, path, () -> new class_2400(false));
    }

    /**
     * Creates a new {@link class_5321} for a {@link class_8110}.
     *
     * @param path path for new resource key
     * @return new {@link class_5321}
     */
    default class_5321<class_8110> registerDamageType(String path) {
        return this.makeResourceKey(class_7924.field_42534, path);
    }
}
