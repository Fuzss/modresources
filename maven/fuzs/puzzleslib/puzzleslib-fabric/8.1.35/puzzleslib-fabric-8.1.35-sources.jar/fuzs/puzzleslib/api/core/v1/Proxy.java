package fuzs.puzzleslib.api.core.v1;

import fuzs.puzzleslib.impl.core.ProxyImpl;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_634;
import net.minecraft.server.MinecraftServer;

/**
 * proxy base class for client and server implementations
 * mainly used for handling content not present on a physical server
 */
public interface Proxy {
    Proxy INSTANCE = ProxyImpl.INSTANCE;

    /**
     * @return client player from Minecraft singleton when on physical client, otherwise null
     */
    class_1657 getClientPlayer();

    /**
     * @return client level from Minecraft singleton when on physical client, otherwise null
     */
    class_1937 getClientLevel();

    /**
     * @return the connection to the server on physical client, otherwise null
     */
    class_634 getClientPacketListener();

    /**
     * @return current game server, null when not in a world
     *
     * @deprecated moved to {@link CommonAbstractions#getMinecraftServer()}
     */
    @Deprecated(forRemoval = true)
    default MinecraftServer getGameServer() {
        return CommonAbstractions.INSTANCE.getMinecraftServer();
    }

    /**
     * Used to check if the control key (command on Mac) is pressed, useful for item tooltips.
     * <p>Always returns <code>false</code> on the server side.
     */
    boolean hasControlDown();

    /**
     * Used to check if the shift key is pressed, useful for item tooltips.
     * <p>Always returns <code>false</code> on the server side.
     *
     * @return is the shift key pressed
     */
    boolean hasShiftDown();

    /**
     * Used to check if the alt key is pressed, useful for item tooltips.
     * <p>Always returns <code>false</code> on the server side.
     *
     * @return is the alt key pressed
     */
    boolean hasAltDown();

    /**
     * Retrieves the name of the currently set key for a <code>net.minecraft.client.KeyMapping</code>.
     * <p>Returns an empty component on the server-side.
     *
     * @param identifier the key identifier from <code>net.minecraft.client.KeyMapping#getName</code>
     * @return the component or an empty component
     */
    class_2561 getKeyMappingComponent(String identifier);
}
