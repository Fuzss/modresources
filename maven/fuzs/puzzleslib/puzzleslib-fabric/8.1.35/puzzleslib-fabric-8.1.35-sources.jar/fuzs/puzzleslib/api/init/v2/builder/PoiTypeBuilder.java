package fuzs.puzzleslib.api.init.v2.builder;

import com.google.common.collect.ImmutableSet;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.minecraft.class_2248;
import net.minecraft.class_2680;

/**
 * we need our own builder instead of passing parameters directly and then handling the builder part in mod loader specific code
 * as we cannot reference arguments directly (the blocks) on Forge,
 * we need to use a {@link java.util.function.Supplier} together with this builder instead
 *
 * @param ticketCount    max amounts of tickets
 * @param searchDistance distance to search for this poi type
 * @param blocks         blocks states valid for this poi type
 *
 * @deprecated replaced with new methods in {@link fuzs.puzzleslib.api.init.v2.RegistryManager}
 */
@Deprecated(forRemoval = true)
public record PoiTypeBuilder(int ticketCount, int searchDistance, Iterable<class_2680> blocks) {

    /**
     * @param ticketCount    max amounts of tickets
     * @param searchDistance distance to search for this poi type
     * @param blocks         blocks valid for this poi type
     */
    private PoiTypeBuilder(int ticketCount, int searchDistance, class_2248... blocks) {
        this(ticketCount, searchDistance, Stream.of(blocks)
                .mapMulti((class_2248 block, Consumer<class_2680> mapper) -> block.method_9595().method_11662().forEach(mapper))
                .collect(ImmutableSet.toImmutableSet()));
    }

    /**
     * @param ticketCount    max amounts of tickets
     * @param searchDistance distance to search for this poi type
     * @param blocks         blocks states valid for this poi type
     * @return   builder instance
     */
    public static PoiTypeBuilder of(int ticketCount, int searchDistance, Iterable<class_2680> blocks) {
        return new PoiTypeBuilder(ticketCount, searchDistance, blocks);
    }

    /**
     * @param ticketCount    max amounts of tickets
     * @param searchDistance distance to search for this poi type
     * @param blocks         blocks valid for this poi type
     * @return   builder instance
     */
    public static PoiTypeBuilder of(int ticketCount, int searchDistance, class_2248... blocks) {
        return new PoiTypeBuilder(ticketCount, searchDistance, blocks);
    }
}
