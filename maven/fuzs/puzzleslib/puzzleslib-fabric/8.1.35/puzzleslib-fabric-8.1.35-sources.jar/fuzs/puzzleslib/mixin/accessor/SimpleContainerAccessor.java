package fuzs.puzzleslib.mixin.accessor;

import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1277.class)
public interface SimpleContainerAccessor {

    @Accessor("size")
    @Mutable
    void puzzleslib$setSize(int size);

    @Accessor("items")
    @Mutable
    void puzzleslib$setItems(class_2371<class_1799> items);
}
