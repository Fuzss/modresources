package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLevelEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2344;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2344.class)
abstract class FarmBlockFabricMixin extends class_2248 {

    public FarmBlockFabricMixin(class_2251 properties) {
        super(properties);
    }

    @Inject(method = "fallOn", at = @At("HEAD"), cancellable = true)
    public void fallOn(class_1937 level, class_2680 blockState, class_2338 blockPos, class_1297 entity, float fallDistance, CallbackInfo callback) {
        if (FabricLevelEvents.FARMLAND_TRAMPLE.invoker().onFarmlandTrample(level, blockPos, class_2246.field_10566.method_9564(), fallDistance, entity).isInterrupt()) {
            super.method_9554(level, blockState, blockPos, entity, fallDistance);
            callback.cancel();
        }
    }
}
