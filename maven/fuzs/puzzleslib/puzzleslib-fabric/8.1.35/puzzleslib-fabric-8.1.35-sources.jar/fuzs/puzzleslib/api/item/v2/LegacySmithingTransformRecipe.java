package fuzs.puzzleslib.api.item.v2;

import com.google.gson.JsonObject;
import net.minecraft.class_1799;
import net.minecraft.class_1852;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1937;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3518;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_7923;
import net.minecraft.class_8060;
import net.minecraft.class_8566;
import net.minecraft.world.item.crafting.*;
import java.util.Objects;

/**
 * A simplified version on {@link class_8060} that allows for upgrading gear without the need for a smithing template, just like the old smithing used to work.
 * <p>Intended for simply netherite upgrades in mods that shouldn't necessarily be as expensive to consume a full netherite upgrade smithing template.
 */
@Deprecated(forRemoval = true)
public class LegacySmithingTransformRecipe extends class_1852 {
    /**
     * The recipe serializer id that is used during registration.
     */
    public static final String RECIPE_SERIALIZER_ID = "legacy_smithing_transform";

    private final class_1856 base;
    private final class_1856 addition;
    private final class_1799 result;

    /**
     * @param id       the recipe id, the namespace is also used for retrieving the corresponding serializer as every mod using this recipe type must register their own serializer
     * @param category one of the category tabs in the client-side recipe book
     * @param base     the base item for the smithing upgrade, like diamond armor and tools in vanilla
     * @param addition the upgrade item, usually a netherite ingot in vanilla
     * @param result   the result item from the smithing upgrade, like netherite armor and tools in vanilla
     */
    public LegacySmithingTransformRecipe(class_2960 id, class_7710 category, class_1856 base, class_1856 addition, class_1799 result) {
        super(id, category);
        this.base = base;
        this.addition = addition;
        this.result = result;
    }

    /**
     * Finds the mod-specific {@link class_1865} in the registry.
     * <p>{@link fuzs.puzzleslib.api.core.v1.ContentRegistrationFlags#LEGACY_SMITHING} must be enabled so the serializer is registered.
     *
     * @param modId the mod id to find the serializer for
     * @return the serializer
     */
    public static class_1865<?> getModSerializer(String modId) {
        class_1865<?> recipeSerializer = class_7923.field_41189.method_10223(new class_2960(modId, RECIPE_SERIALIZER_ID));
        Objects.requireNonNull(recipeSerializer, "legacy smithing transform recipe serializer for %s is null".formatted(modId));
        return recipeSerializer;
    }

    @Override
    public boolean matches(class_8566 container, class_1937 level) {
        int baseItemCount = 0;
        int additionItemCount = 0;

        for (int k = 0; k < container.method_5439(); ++k) {
            class_1799 itemStack = container.method_5438(k);
            if (!itemStack.method_7960()) {
                if (this.base.method_8093(itemStack)) {
                    ++baseItemCount;
                } else if (this.addition.method_8093(itemStack)) {
                    ++additionItemCount;
                } else {
                    return false;
                }

                if (additionItemCount > 1 || baseItemCount > 1) {
                    return false;
                }
            }
        }

        return baseItemCount == 1 && additionItemCount == 1;
    }

    @Override
    public class_1799 assemble(class_8566 container, class_5455 registryAccess) {
        class_1799 result = this.result.method_7972();
        for (int i = 0; i < container.method_5439(); i++) {
            class_1799 itemStack = container.method_5438(i);
            if (this.base.method_8093(itemStack)) {
                class_2487 compoundTag = itemStack.method_7969();
                if (compoundTag != null) {
                    result.method_7980(compoundTag.method_10553());
                }
                return result;
            }
        }
        return result;
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 2;
    }

    @Override
    public class_1799 method_8110(class_5455 registryAccess) {
        return this.result;
    }

    @Override
    public class_2371<class_1856> method_8117() {
        class_2371<class_1856> nonNullList = class_2371.method_10211();
        nonNullList.add(this.base);
        nonNullList.add(this.addition);
        return nonNullList;
    }

    @Override
    public boolean method_8118() {
        return false;
    }

    @Override
    public class_1865<?> method_8119() {
        return getModSerializer(this.method_8114().method_12836());
    }

    /**
     * The custom serializer used for <code>legacy_smithing_transform</code>, simply does not serialize any template item, as it is set to empty which would fail during serialization.
     */
    public static class Serializer implements class_1865<LegacySmithingTransformRecipe> {

        @Override
        public LegacySmithingTransformRecipe method_8121(class_2960 resourceLocation, JsonObject jsonObject) {
            class_7710 craftingBookCategory = class_7710.field_40252.method_47920(class_3518.method_15253(jsonObject, "category", null), class_7710.field_40251);
            class_1856 base = class_1856.method_52177(class_3518.method_15296(jsonObject, "base"));
            class_1856 addition = class_1856.method_52177(class_3518.method_15296(jsonObject, "addition"));
            class_1799 result = class_1869.method_35228(class_3518.method_15296(jsonObject, "result"));
            return new LegacySmithingTransformRecipe(resourceLocation, craftingBookCategory, base, addition, result);
        }

        @Override
        public LegacySmithingTransformRecipe method_8122(class_2960 resourceLocation, class_2540 friendlyByteBuf) {
            class_7710 craftingBookCategory = friendlyByteBuf.method_10818(class_7710.class);
            class_1856 base = class_1856.method_8086(friendlyByteBuf);
            class_1856 addition = class_1856.method_8086(friendlyByteBuf);
            class_1799 result = friendlyByteBuf.method_10819();
            return new LegacySmithingTransformRecipe(resourceLocation, craftingBookCategory, base, addition, result);
        }

        @Override
        public void toNetwork(class_2540 friendlyByteBuf, LegacySmithingTransformRecipe smithingTransformRecipe) {
            friendlyByteBuf.method_10817(smithingTransformRecipe.method_45441());
            smithingTransformRecipe.base.method_8088(friendlyByteBuf);
            smithingTransformRecipe.addition.method_8088(friendlyByteBuf);
            friendlyByteBuf.method_10793(smithingTransformRecipe.result);
        }
    }
}
