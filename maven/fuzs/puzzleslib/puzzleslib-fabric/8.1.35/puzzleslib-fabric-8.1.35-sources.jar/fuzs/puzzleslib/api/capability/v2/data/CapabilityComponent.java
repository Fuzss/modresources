package fuzs.puzzleslib.api.capability.v2.data;

import net.minecraft.class_2487;

/**
 * same functionality as INBTSerializable (Forge) or ComponentV3 (Fabric) for providing common read and write methods
 */
public interface CapabilityComponent {

    /**
     * @param tag tag to write to
     */
    default void write(class_2487 tag) {

    }

    /**
     * @param tag tag to read from
     */
    default void read(class_2487 tag) {
        
    }

    /**
     * @return this capability serialized to {@link class_2487}
     */
    default class_2487 toCompoundTag() {
        class_2487 tag = new class_2487();
        this.write(tag);
        return tag;
    }
}
