package fuzs.puzzleslib.mixin.accessor;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

@Mixin(class_3283.class)
public interface PackRepositoryFabricAccessor {

    @Accessor("sources")
    Set<class_3285> puzzleslib$getSources();

    @Accessor("sources")
    @Mutable
    void puzzleslib$setSources(Set<class_3285> sources);
}
