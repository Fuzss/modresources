package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2874;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3695;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_761;

@Mixin(class_638.class)
abstract class ClientLevelFabricMixin extends class_1937 {
    @Unique
    private final ThreadLocal<DefaultedValue<class_6880<class_3414>>> puzzleslib$sound = new ThreadLocal<>();
    @Unique
    private final ThreadLocal<DefaultedValue<class_3419>> puzzleslib$source = new ThreadLocal<>();
    @Unique
    private final ThreadLocal<DefaultedFloat> puzzleslib$volume = new ThreadLocal<>();
    @Unique
    private final ThreadLocal<DefaultedFloat> puzzleslib$pitch = new ThreadLocal<>();

    protected ClientLevelFabricMixin(class_5269 writableLevelData, class_5321<class_1937> resourceKey, class_5455 registryAccess, class_6880<class_2874> holder, Supplier<class_3695> supplier, boolean bl, boolean bl2, long l, int i) {
        super(writableLevelData, resourceKey, registryAccess, holder, supplier, bl, bl2, l, i);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    public void init(class_634 clientPacketListener, class_638.class_5271 clientLevelData, class_5321<class_1937> resourceKey, class_6880<class_2874> holder, int i, int j, Supplier<class_3695> supplier, class_761 levelRenderer, boolean bl, long l, CallbackInfo callback) {
        FabricClientEvents.LOAD_LEVEL.invoker().onLevelLoad(class_310.method_1551(), class_638.class.cast(this));
    }

    @Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
    private void addEntity(int entityId, class_1297 entityToSpawn, CallbackInfo callback) {
        if (FabricClientEvents.ENTITY_LOAD.invoker().onEntityLoad(entityToSpawn, class_638.class.cast(this)).isInterrupt()) {
            if (entityToSpawn instanceof class_1657) {
                // we do not support players as it isn't as straight-forward to implement for the server event on Fabric
                throw new UnsupportedOperationException("Cannot prevent player from spawning in!");
            } else {
                callback.cancel();
            }
        }
    }

    @Inject(method = "playSeededSound(Lnet/minecraft/world/entity/player/Player;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V", at = @At("HEAD"), cancellable = true)
    public void playSeededSound$0(@Nullable class_1657 player, double x, double y, double z, class_6880<class_3414> soundEvent, class_3419 source, float volume, float pitch, long seed, CallbackInfo callback) {
        this.puzzleslib$sound.set(DefaultedValue.fromValue(soundEvent));
        this.puzzleslib$source.set(DefaultedValue.fromValue(source));
        this.puzzleslib$volume.set(DefaultedFloat.fromValue(volume));
        this.puzzleslib$pitch.set(DefaultedFloat.fromValue(pitch));
        EventResult result = FabricLevelEvents.PLAY_LEVEL_SOUND_AT_POSITION.invoker().onPlaySoundAtPosition(this, new class_243(x, y, z), this.puzzleslib$sound.get(), this.puzzleslib$source.get(), this.puzzleslib$volume.get(), this.puzzleslib$pitch.get());
        if (result.isInterrupt() || this.puzzleslib$sound.get().get() == null) callback.cancel();
    }

    @Inject(method = "playSeededSound(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V", at = @At("HEAD"), cancellable = true)
    public void playSeededSound$0(@Nullable class_1657 player, class_1297 entity, class_6880<class_3414> soundEvent, class_3419 source, float volume, float pitch, long seed, CallbackInfo callback) {
        this.puzzleslib$sound.set(DefaultedValue.fromValue(soundEvent));
        this.puzzleslib$source.set(DefaultedValue.fromValue(source));
        this.puzzleslib$volume.set(DefaultedFloat.fromValue(volume));
        this.puzzleslib$pitch.set(DefaultedFloat.fromValue(pitch));
        EventResult result = FabricLevelEvents.PLAY_LEVEL_SOUND_AT_ENTITY.invoker().onPlaySoundAtEntity(this, entity, this.puzzleslib$sound.get(), this.puzzleslib$source.get(), this.puzzleslib$volume.get(), this.puzzleslib$pitch.get());
        if (result.isInterrupt() || this.puzzleslib$sound.get().get() == null) callback.cancel();
    }

    @ModifyVariable(method = {"playSeededSound(Lnet/minecraft/world/entity/player/Player;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V", "playSeededSound(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V"}, at = @At("HEAD"), ordinal = 0)
    public class_6880<class_3414> playSeededSound$1(class_6880<class_3414> soundEvent) {
        Objects.requireNonNull(this.puzzleslib$sound.get(), "sound is null");
        soundEvent = this.puzzleslib$sound.get().getAsOptional().orElse(soundEvent);
        this.puzzleslib$sound.remove();
        return soundEvent;
    }

    @ModifyVariable(method = {"playSeededSound(Lnet/minecraft/world/entity/player/Player;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V", "playSeededSound(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V"}, at = @At("HEAD"), ordinal = 0)
    public class_3419 playSeededSound$2(class_3419 soundSource) {
        Objects.requireNonNull(this.puzzleslib$source.get(), "source is null");
        soundSource = this.puzzleslib$source.get().getAsOptional().orElse(soundSource);
        this.puzzleslib$source.remove();
        return soundSource;
    }

    @ModifyVariable(method = {"playSeededSound(Lnet/minecraft/world/entity/player/Player;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V", "playSeededSound(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V"}, at = @At("HEAD"), ordinal = 0)
    public float playSeededSound$3(float volume) {
        Objects.requireNonNull(this.puzzleslib$volume.get(), "sound is null");
        volume = this.puzzleslib$volume.get().getAsOptionalFloat().orElse(volume);
        this.puzzleslib$volume.remove();
        return volume;
    }

    @ModifyVariable(method = {"playSeededSound(Lnet/minecraft/world/entity/player/Player;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V", "playSeededSound(Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V"}, at = @At("HEAD"), ordinal = 1)
    public float playSeededSound$4(float pitch) {
        Objects.requireNonNull(this.puzzleslib$pitch.get(), "pitch is null");
        pitch = this.puzzleslib$pitch.get().getAsOptionalFloat().orElse(pitch);
        this.puzzleslib$pitch.remove();
        return pitch;
    }
}
