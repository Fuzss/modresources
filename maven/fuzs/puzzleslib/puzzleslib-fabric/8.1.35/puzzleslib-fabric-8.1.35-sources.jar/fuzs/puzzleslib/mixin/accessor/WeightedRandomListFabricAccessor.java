package fuzs.puzzleslib.mixin.accessor;

import com.google.common.collect.ImmutableList;
import net.minecraft.class_6008;
import net.minecraft.class_6012;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_6012.class)
public interface WeightedRandomListFabricAccessor<E extends class_6008> {

    @Accessor("totalWeight")
    @Mutable
    void puzzleslib$setTotalWeight(int totalWeight);

    @Accessor("items")
    @Mutable
    void puzzleslib$setItems(ImmutableList<E> items);
}
