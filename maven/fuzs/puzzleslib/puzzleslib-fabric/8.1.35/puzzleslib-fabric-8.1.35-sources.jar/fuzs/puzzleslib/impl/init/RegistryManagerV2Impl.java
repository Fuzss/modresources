package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.core.v1.ModLoader;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.init.v2.RegistryManager;
import fuzs.puzzleslib.api.init.v2.RegistryReference;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public abstract class RegistryManagerV2Impl implements RegistryManager {
    protected final String modId;
    protected Set<ModLoader> allowedModLoaders = EnumSet.allOf(ModLoader.class);

    protected RegistryManagerV2Impl(String modId) {
        this.modId = modId;
    }

    @Override
    public class_2960 makeKey(String path) {
        if (StringUtils.isEmpty(path)) throw new IllegalArgumentException("path is invalid");
        return new class_2960(this.modId, path);
    }

    @Override
    public RegistryManager whenOn(ModLoader... allowedModLoaders) {
        Objects.checkIndex(0, allowedModLoaders.length);
        this.allowedModLoaders = EnumSet.copyOf(Arrays.asList(allowedModLoaders));
        return this;
    }

    @Override
    public final <T> RegistryReference<T> register(final class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier) {
        RegistryReference<T> registryReference;
        if (!this.allowedModLoaders.contains(ModLoaderEnvironment.INSTANCE.getModLoader())) {
            registryReference = this.placeholder(registryKey, path);
        } else {
            registryReference = this.actuallyRegister(registryKey, path, supplier);
        }
        this.allowedModLoaders = EnumSet.allOf(ModLoader.class);
        return registryReference;
    }

    protected abstract  <T> RegistryReference<T> actuallyRegister(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier);
}
