package fuzs.puzzleslib.api.client.core.v1;

import fuzs.puzzleslib.api.client.core.v1.context.ClientTooltipComponentsContext;
import fuzs.puzzleslib.api.core.v1.ServiceProviderHelper;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_1124;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import net.minecraft.class_5481;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

/**
 * useful methods for client related things that require mod loader specific abstractions
 */
public interface ClientAbstractions {
    /**
     * instance of the client factories SPI
     */
    ClientAbstractions INSTANCE = ServiceProviderHelper.load(ClientAbstractions.class);

    /**
     * checks if a <code>keyMapping</code> is active (=pressed), Forge replaces this everywhere, so we need an abstraction
     *
     * @param keyMapping the key mapping to check if pressed
     * @param keyCode    current key code
     * @param scanCode   scan code
     * @return is <code>keyMapping</code> active
     */
    boolean isKeyActiveAndMatches(class_304 keyMapping, int keyCode, int scanCode);

    /**
     * Converts an image {@link class_5632} into the appropriate client-side component.
     * <p>{@link class_5684}s must first be registered in {@link ClientModConstructor#onRegisterClientTooltipComponents(ClientTooltipComponentsContext)},
     * otherwise {@link IllegalArgumentException} will be thrown.
     * <p>For simple text based components directly use {@link class_5684#method_32662(class_5481)} instead.
     *
     * @param imageComponent the un-sided {@link class_5632} to convert
     * @return the client tooltip components representation
     */
    class_5684 createImageComponent(class_5632 imageComponent);

    /**
     * Retrieves a model from the {@link class_1092}, allows for using {@link class_2960} instead of {@link net.minecraft.class_1091}.
     *
     * @param identifier model identifier
     * @return the model, possibly the missing model
     */
    class_1087 getBakedModel(class_2960 identifier);

    /**
     * Retrieves a model from the {@link class_1092}, allows for using {@link class_2960} instead of {@link net.minecraft.class_1091}.
     *
     * @param modelManager the model manager instance for retrieving the model
     * @param identifier   model identifier
     * @return the model, possibly the missing model
     */
    @Deprecated(forRemoval = true)
    default class_1087 getBakedModel(class_1092 modelManager, class_2960 identifier) {
        return this.getBakedModel(identifier);
    }

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for a block.
     * <p>When not render type is registered {@link class_1921#method_23577()} is returned.
     *
     * @param block the block to get the render type for
     * @return the render type
     */
    class_1921 getRenderType(class_2248 block);

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for a fluid.
     * <p>When not render type is registered {@link class_1921#method_23577()} is returned.
     *
     * @param fluid the fluid to get the render type for
     * @return the render type
     */
    default class_1921 getRenderType(class_3611 fluid) {
        return class_4696.method_23680(fluid.method_15785());
    }

    /**
     * Allows for registering a {@link class_1921} for a block.
     * <p>When not render type is registered {@link class_1921#method_23577()} is used.
     *
     * @param block      the block to register the render type for
     * @param renderType the render type
     */
    void registerRenderType(class_2248 block, class_1921 renderType);

    /**
     * Allows for registering a {@link class_1921} for a fluid.
     * <p>When not render type is registered {@link class_1921#method_23577()} is used.
     *
     * @param fluid      the fluid to register the render type for
     * @param renderType the render type
     */
    void registerRenderType(class_3611 fluid, class_1921 renderType);

    /**
     * Get the current partial tick time.
     * <p>This is different from {@link class_310#method_1488()} in that the correct value is returned when the game is paused in {@link class_310#method_1493()}.
     *
     * @return current partial tick time
     */
    float getPartialTick();

    /**
     * Get the current partial tick time.
     * <p>This is different from {@link class_310#method_1488()} in that the correct value is returned when the game is paused in {@link class_310#method_1493()}.
     *
     * @param minecraft minecraft singleton instance
     * @return current partial tick time
     */
    @Deprecated(forRemoval = true)
    default float getPartialTick(class_310 minecraft) {
        return this.getPartialTick();
    }

    /**
     * Get the search registry for registering a new search tree via {@link class_1124#method_4801(class_1124.class_1125, class_1124.class_7456)}.
     *
     * @return the search registry
     */
    class_1124 getSearchRegistry();

    /**
     * Get the search registry for registering a new search tree via {@link class_1124#method_4801(class_1124.class_1125, class_1124.class_7456)}.
     *
     * @param minecraft minecraft singleton instance
     * @return the search registry
     */
    @Deprecated(forRemoval = true)
    default class_1124 getSearchRegistry(class_310 minecraft) {
        return this.getSearchRegistry();
    }
}
