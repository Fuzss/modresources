package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.impl.core.FabricAbstractions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.stream.Stream;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_5369;
import net.minecraft.class_5375;

@Mixin(class_5375.class)
abstract class PackSelectionScreenFabricMixin extends class_437 {

    protected PackSelectionScreenFabricMixin(class_2561 title) {
        super(title);
    }

    @ModifyVariable(method = "updateList", at = @At("LOAD"), argsOnly = true)
    private Stream<class_5369.class_5371> updateList(Stream<class_5369.class_5371> models) {
        return models.filter(entry -> ((FabricAbstractions) CommonAbstractions.INSTANCE).notHidden(entry.method_48276()));
    }
}
