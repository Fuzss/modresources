package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricEntityEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1299;
import net.minecraft.class_1671;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_1671.class)
abstract class FireworkRocketEntityFabricMixin extends class_1676 {

    public FireworkRocketEntityFabricMixin(class_1299<? extends class_1676> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Override
    public void method_7488(class_239 hitResult) {
        // implement this in Projectile::onHit, it's unlikely a subclass will override this
        if (hitResult.method_17783() != class_239.class_240.field_1333) {
            EventResult result = FabricEntityEvents.PROJECTILE_IMPACT.invoker().onProjectileImpact(this, hitResult);
            if (result.isInterrupt()) return;
        }
        super.method_7488(hitResult);
    }
}
