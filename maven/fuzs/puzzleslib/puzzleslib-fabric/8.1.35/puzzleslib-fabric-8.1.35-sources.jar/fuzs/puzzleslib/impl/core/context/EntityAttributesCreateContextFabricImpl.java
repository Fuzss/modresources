package fuzs.puzzleslib.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.EntityAttributesCreateContext;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_5132;
import net.minecraft.class_5135;

public final class EntityAttributesCreateContextFabricImpl implements EntityAttributesCreateContext {

    @Override
    public void registerEntityAttributes(class_1299<? extends class_1309> entityType, class_5132.class_5133 builder) {
        // this is not allowed on Forge, use the separate method which mirrors the Forge implementation
        if (class_5135.method_26875(entityType)) {
            throw new IllegalStateException("Duplicate DefaultAttributes entry: " + entityType);
        }
        FabricDefaultAttributeRegistry.register(entityType, builder);
    }
}
