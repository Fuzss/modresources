package fuzs.puzzleslib.impl.core;

import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.core.v1.Proxy;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_634;

public interface ProxyImpl extends Proxy {
    ProxyImpl INSTANCE = ModLoaderEnvironment.INSTANCE.isClient() ? CommonFactories.INSTANCE.getClientProxy() : CommonFactories.INSTANCE.getServerProxy();

    @Override
    default class_1657 getClientPlayer() {
        throw new RuntimeException("Client player accessed for wrong side!");
    }

    @Override
    default class_1937 getClientLevel() {
        throw new RuntimeException("Client level accessed for wrong side!");
    }

    @Override
    default class_634 getClientPacketListener() {
        throw new RuntimeException("Client connection accessed for wrong side!");
    }

    @Override
    default boolean hasControlDown() {
        return false;
    }

    @Override
    default boolean hasShiftDown() {
        return false;
    }

    @Override
    default boolean hasAltDown() {
        return false;
    }

    @Override
    default class_2561 getKeyMappingComponent(String identifier) {
        throw new RuntimeException("Key mapping component accessed for wrong side!");
    }
}
