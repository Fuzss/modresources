package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.BiFunction;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_5617;
import net.minecraft.class_583;

/**
 * register additional {@link class_3887}s for a living entity, supports players like any other entity
 */
@FunctionalInterface
public interface LivingEntityRenderLayersContext {


    /**
     * register the additional layer
     *
     * @param entityType entity type to register for
     * @param factory    the new layer factory
     * @param <E>        the entity type
     * @param <T>        entity type used for the model, should only really be different for players
     * @param <M>        the entity model
     */
    <E extends class_1309, T extends E, M extends class_583<T>> void registerRenderLayer(class_1299<E> entityType, BiFunction<class_3883<T, M>, class_5617.class_5618, class_3887<T, M>> factory);
}
