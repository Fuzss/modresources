package fuzs.puzzleslib.api.client.screen.v2;

import fuzs.puzzleslib.mixin.client.accessor.TooltipAccessor;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_5244;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_7919;

/**
 * A small helper class for creating new instances of {@link class_7919} from multiple {@link net.minecraft.class_2561}s instead of just a single one,
 * as is the case in the vanilla implementation.
 */
public final class ScreenTooltipFactory {

    private ScreenTooltipFactory() {

    }

    /**
     * Create a new tooltip instance from multiple lines of text.
     *
     * @param font       the font instance
     * @param components components to split and build the tooltip from
     * @return the tooltip instance
     *
     * @deprecated migrate to {@link #create(class_5348...)}
     */
    @Deprecated(forRemoval = true)
    public static class_7919 create(class_327 font, class_5348... components) {
        return create(components);
    }

    /**
     * Create a new tooltip instance from multiple lines of text.
     *
     * @param components components to split and build the tooltip from
     * @return the tooltip instance
     */
    public static class_7919 create(class_5348... components) {
        return create(Arrays.asList(components));
    }

    /**
     * Create a new tooltip instance from multiple lines of text.
     *
     * @param font       the font instance
     * @param components components to split and build the tooltip from
     * @return the tooltip instance
     *
     * @deprecated migrate to {@link #create(List)}
     */
    @Deprecated(forRemoval = true)
    public static class_7919 create(class_327 font, List<? extends class_5348> components) {
        return create(components);
    }

    /**
     * Create a new tooltip instance from multiple lines of text.
     *
     * @param components components to split and build the tooltip from
     * @return the tooltip instance
     */
    public static class_7919 create(List<? extends class_5348> components) {
        class_327 font = class_310.method_1551().field_1772;
        List<class_5481> lines = components.stream()
                .flatMap(t -> {
                    List<class_5481> list = font.method_1728(t, 170);
                    // empty components yield an empty list
                    // since empty lines are desired on tooltips make sure they don't go missing
                    if (list.isEmpty()) list = List.of(class_5481.field_26385);
                    return list.stream();
                })
                .collect(Collectors.toList());
        return createTooltip(lines);
    }

    /**
     * Create a new tooltip instance from already split lines of text.
     *
     * @param lines the split lines to build the tooltip from
     * @return the tooltip instance
     */
    public static class_7919 createTooltip(List<class_5481> lines) {
        class_7919 tooltip = class_7919.method_47408(class_5244.field_39003, null);
        ((TooltipAccessor) tooltip).puzzleslib$setCachedTooltip(lines);
        return tooltip;
    }
}
