package fuzs.puzzleslib.impl.entity;

import fuzs.puzzleslib.impl.PuzzlesLib;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2540;
import net.minecraft.class_2604;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;
import fuzs.puzzleslib.api.entity.v1.AdditionalAddEntityData;
import fuzs.puzzleslib.api.network.v3.ClientMessageListener;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;

public record ClientboundAddEntityDataMessage(class_2604 vanillaPacket, class_2540 additionalData) implements ClientboundMessage<ClientboundAddEntityDataMessage> {

    @Override
    public ClientMessageListener<ClientboundAddEntityDataMessage> getHandler() {
        return new ClientMessageListener<>() {

            @Override
            public void handle(ClientboundAddEntityDataMessage message, class_310 client, class_634 handler, class_746 player, class_638 level) {
                try {
                    class_2604 packet = message.vanillaPacket();
                    handler.method_11112(packet);
                    class_1297 entity = level.method_8469(packet.method_11167());
                    if (entity instanceof AdditionalAddEntityData) {
                        ((AdditionalAddEntityData) entity).readAdditionalAddEntityData(message.additionalData());
                    } else {
                        class_1299<?> entitytype = packet.method_11169();
                        PuzzlesLib.LOGGER.warn("Skipping additional add entity data for entity with id {}", entitytype);
                    }
                } finally {
                    message.additionalData().release();
                }
            }
        };
    }
}
