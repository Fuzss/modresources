package fuzs.puzzleslib.impl.core;

import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents;
import fuzs.puzzleslib.impl.event.SpawnTypeMob;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalEntityTypeTags;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3288;
import net.minecraft.class_3481;
import net.minecraft.class_3730;
import net.minecraft.class_3908;
import net.minecraft.class_7699;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.Set;
import java.util.function.BiConsumer;

public final class FabricAbstractions implements CommonAbstractions, EventHandlerProvider {
    private final Set<String> hiddenPacks = Sets.newConcurrentHashSet();
    private MinecraftServer gameServer;

    @Override
    public void registerHandlers() {
        // registers for game server starting and stopping, so we can keep an instance of the server here so that
        // {@link FabricNetworkHandler} can be implemented much more similarly to Forge
        ServerLifecycleEvents.STARTING.register(EventPhase.FIRST, server -> this.gameServer = server);
        ServerLifecycleEvents.STOPPED.register(EventPhase.LAST, server -> this.gameServer = null);
    }

    @Override
    public MinecraftServer getMinecraftServer() {
        return this.gameServer;
    }

    @Override
    public void openMenu(class_3222 player, class_3908 menuProvider, BiConsumer<class_3222, class_2540> screenOpeningDataWriter) {
        player.method_17355(new ExtendedScreenHandlerFactory() {

            @Override
            public void writeScreenOpeningData(class_3222 player, class_2540 buf) {
                screenOpeningDataWriter.accept(player, buf);
            }

            @Override
            public class_2561 method_5476() {
                return menuProvider.method_5476();
            }

            @Nullable
            @Override
            public class_1703 createMenu(int i, class_1661 inventory, class_1657 player) {
                return menuProvider.createMenu(i, inventory, player);
            }
        });
    }

    @Override
    public boolean isBossMob(class_1299<?> type) {
        return type.method_20210(ConventionalEntityTypeTags.BOSSES);
    }

    @Override
    public float getEnchantPowerBonus(class_2680 state, class_1937 level, class_2338 pos) {
        return state.method_26164(class_3481.field_44472) ? 1.0F : 0.0F;
    }

    @Override
    public boolean canEquip(class_1799 stack, class_1304 slot, class_1297 entity) {
        return slot == class_1308.method_32326(stack);
    }

    @Override
    public int getMobLootingLevel(class_1297 entity, @Nullable class_1297 killerEntity, @Nullable class_1282 damageSource) {
        return killerEntity instanceof class_1309 livingEntity ? class_1890.method_8226(livingEntity) : 0;
    }

    @Override
    public boolean getMobGriefingRule(class_1937 level, @Nullable class_1297 entity) {
        return level.method_8450().method_8355(class_1928.field_19388);
    }

    @Override
    public void onPlayerDestroyItem(class_1657 player, class_1799 itemStack, @Nullable class_1268 interactionHand) {

    }

    @Override
    public @Nullable class_3730 getMobSpawnType(class_1308 mob) {
        return ((SpawnTypeMob) mob).puzzleslib$getSpawnType();
    }

    @Override
    public class_3288.class_7679 createPackInfo(class_2960 id, class_2561 description, int packVersion, class_7699 features, boolean hidden) {
        if (hidden) this.hiddenPacks.add(id.toString());
        return new class_3288.class_7679(description, packVersion, features);
    }

    public boolean notHidden(String id) {
        return !this.hiddenPacks.contains(id);
    }

    @Override
    public boolean canApplyAtEnchantingTable(class_1887 enchantment, class_1799 itemStack) {
        return enchantment.field_9083.method_8177(itemStack.method_7909());
    }

    @Override
    public boolean isAllowedOnBooks(class_1887 enchantment) {
        return true;
    }
}
