package fuzs.puzzleslib.api.data.v2;

import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.RegistryHelper;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2466;
import net.minecraft.class_2467;
import net.minecraft.class_2469;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_5746;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7805;
import net.minecraft.class_7889;
import net.minecraft.data.tags.*;
import java.util.concurrent.CompletableFuture;

public final class AbstractTagProvider {

    public abstract static class Blocks extends class_2466 implements TagProviderExtension<class_2248, class_7889.class_7890<class_2248>> {

        public Blocks(DataProviderContext context) {
            this(context.getModId(), context.getPackOutput(), context.getLookupProvider());
        }

        public Blocks(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, lookupProvider);
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Override
        public class_5321<? extends class_2378<class_2248>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_7890<class_2248> method_10512(class_6862<class_2248> tagKey) {
            return super.method_46827(tagKey);
        }
    }

    public abstract static class Fluids extends class_2469 implements TagProviderExtension<class_3611, class_7889.class_7890<class_3611>> {

        public Fluids(DataProviderContext context) {
            this(context.getPackOutput(), context.getLookupProvider());
        }

        public Fluids(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, lookupProvider);
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Override
        public class_5321<? extends class_2378<class_3611>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_7890<class_3611> method_10512(class_6862<class_3611> tagKey) {
            return super.method_46827(tagKey);
        }
    }

    public abstract static class Items extends class_7805 implements TagProviderExtension<class_1792, class_7889.class_7890<class_1792>> {

        public Items(DataProviderContext context) {
            this(context.getPackOutput(), context.getLookupProvider());
        }

        public Items(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            this(packOutput, lookupProvider, CompletableFuture.completedFuture(null));
        }

        public Items(DataProviderContext context, CompletableFuture<class_8211<class_2248>> blockTagsProvider) {
            this(context.getPackOutput(), context.getLookupProvider(), blockTagsProvider);
        }

        public Items(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider, CompletableFuture<class_8211<class_2248>> blockTagsProvider) {
            super(packOutput, lookupProvider, blockTagsProvider);
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Deprecated
        @Override
        protected void method_46218(class_6862<class_2248> blockTagKey, class_6862<class_1792> itemTagKey) {
            throw new UnsupportedOperationException();
        }

        @Override
        public class_5321<? extends class_2378<class_1792>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_7890<class_1792> method_10512(class_6862<class_1792> tagKey) {
            return super.method_46827(tagKey);
        }
    }

    public abstract static class EntityTypes extends class_2467 implements TagProviderExtension<class_1299<?>, class_7889.class_7890<class_1299<?>>> {

        public EntityTypes(DataProviderContext context) {
            this(context.getPackOutput(), context.getLookupProvider());
        }

        public EntityTypes(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, lookupProvider);
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Override
        public class_5321<? extends class_2378<class_1299<?>>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_7890<class_1299<?>> method_10512(class_6862<class_1299<?>> tagKey) {
            return super.method_46827(tagKey);
        }
    }

    public abstract static class GameEvents extends class_5746 implements TagProviderExtension<class_5712, class_7889.class_7890<class_5712>> {

        public GameEvents(DataProviderContext context) {
            this(context.getPackOutput(), context.getLookupProvider());
        }

        public GameEvents(class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, lookupProvider);
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Override
        public class_5321<? extends class_2378<class_5712>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_7890<class_5712> method_10512(class_6862<class_5712> tagKey) {
            return super.method_46827(tagKey);
        }
    }

    public abstract static class Simple<T> extends class_2474<T> implements TagProviderExtension<T, class_2474.class_5124<T>> {

        public Simple(class_5321<? extends class_2378<T>> registryKey, DataProviderContext context) {
            this(registryKey, context.getPackOutput(), context.getLookupProvider());
        }

        public Simple(class_5321<? extends class_2378<T>> registryKey, class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, registryKey, lookupProvider);
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Override
        public class_5321<? extends class_2378<T>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_2474.class_5124<T> method_10512(class_6862<T> tagKey) {
            return super.method_10512(tagKey);
        }
    }

    public abstract static class Intrinsic<T> extends class_7889<T> implements TagProviderExtension<T, class_7889.class_7890<T>> {

        public Intrinsic(class_5321<? extends class_2378<T>> registryKey, DataProviderContext context) {
            this(registryKey, context.getPackOutput(), context.getLookupProvider());
        }

        public Intrinsic(class_5321<? extends class_2378<T>> registryKey, class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
            super(packOutput, registryKey, lookupProvider, object -> {
                return RegistryHelper.getResourceKeyOrThrow(registryKey, object);
            });
        }

        @Override
        protected abstract void method_10514(class_7225.class_7874 provider);

        @Override
        public class_5321<? extends class_2378<T>> registryKey() {
            return this.field_40957;
        }

        @Override
        public class_7890<T> method_10512(class_6862<T> tagKey) {
            return super.method_46827(tagKey);
        }
    }

    public interface TagProviderExtension<T, A extends class_2474.class_5124<T>> {

        class_5321<? extends class_2378<T>> registryKey();

        A tag(class_6862<T> tagKey);

        default A tag(String identifier) {
            return this.tag(new class_2960(identifier));
        }

        default A tag(class_2960 identifier) {
            return this.tag(class_6862.method_40092(this.registryKey(), identifier));
        }
    }
}
