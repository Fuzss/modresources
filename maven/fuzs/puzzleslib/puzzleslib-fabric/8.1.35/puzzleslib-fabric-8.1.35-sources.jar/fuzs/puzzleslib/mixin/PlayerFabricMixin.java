package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2680;

@Mixin(class_1657.class)
abstract class PlayerFabricMixin extends class_1309 {
    @Unique
    private DefaultedFloat puzzleslib$damageAmount;

    protected PlayerFabricMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    public void tick$0(CallbackInfo callback) {
        FabricPlayerEvents.PLAYER_TICK_START.invoker().onStartPlayerTick(class_1657.class.cast(this));
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void tick$1(CallbackInfo callback) {
        FabricPlayerEvents.PLAYER_TICK_END.invoker().onEndPlayerTick(class_1657.class.cast(this));
    }

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    public void hurt(class_1282 source, float amount, CallbackInfoReturnable<Boolean> callback) {
        EventResult result = FabricLivingEvents.LIVING_ATTACK.invoker().onLivingAttack(this, source, amount);
        if (result.isInterrupt()) callback.setReturnValue(false);
    }

    @Inject(
            method = "drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;",
            at = @At("TAIL"),
            cancellable = true
    )
    public void drop(class_1799 itemStack, boolean throwRandomly, boolean retainOwnership, CallbackInfoReturnable<class_1542> callback) {
        class_1542 itemEntity = callback.getReturnValue();
        if (itemEntity != null &&
                FabricPlayerEvents.ITEM_TOSS.invoker().onItemToss(itemEntity, class_1657.class.cast(this)).isInterrupt()) {
            callback.setReturnValue(null);
        }
    }

    @ModifyVariable(
            method = "getDestroySpeed",
            at = @At(value = "LOAD", ordinal = 1),
            ordinal = 0,
            slice = @Slice(
                    from = @At(
                            value = "INVOKE",
                            target = "Lnet/minecraft/world/entity/player/Player;onGround()Z"
                    )
            )
    )
    public float getDestroySpeed(float destroySpeed, class_2680 state) {
        // don't use inject and capture callback return value, it is likely for another mod to inject here and only one will be able to override the return value
        DefaultedFloat breakSpeed = DefaultedFloat.fromValue(destroySpeed);
        if (FabricPlayerEvents.BREAK_SPEED.invoker()
                .onBreakSpeed(class_1657.class.cast(this), state, breakSpeed)
                .isInterrupt()) {
            breakSpeed.accept(-1.0F);
        }
        return breakSpeed.getAsOptionalFloat().orElse(destroySpeed);
    }

    @Inject(
            method = "die", at = @At(
            "HEAD"
    ), cancellable = true
    )
    public void die(class_1282 damageSource, CallbackInfo callback) {
        // this will fire twice for players, since the die method calls super on LivingEntity, where this is hooked in again
        // Forge has it implemented like this, so let's leave it for now for parity
        // can't easily filter out the second call on Forge unfortunately
        EventResult result = FabricLivingEvents.LIVING_DEATH.invoker().onLivingDeath(this, damageSource);
        if (result.isInterrupt()) callback.cancel();
    }

    @Inject(method = "actuallyHurt", at = @At("HEAD"), cancellable = true)
    protected void actuallyHurt(class_1282 damageSource, float damageAmount, CallbackInfo callback) {
        if (!this.method_5679(damageSource)) {
            this.puzzleslib$damageAmount = DefaultedFloat.fromValue(damageAmount);
            if (FabricLivingEvents.LIVING_HURT.invoker()
                    .onLivingHurt(class_1309.class.cast(this), damageSource, this.puzzleslib$damageAmount)
                    .isInterrupt()) {
                callback.cancel();
            }
        }
    }

    @ModifyVariable(method = "actuallyHurt", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    protected float actuallyHurt(float damageAmount, class_1282 damageSource) {
        if (!this.method_5679(damageSource)) {
            Objects.requireNonNull(this.puzzleslib$damageAmount, "damage amount is null");
            damageAmount = this.puzzleslib$damageAmount.getAsOptionalFloat().orElse(damageAmount);
            this.puzzleslib$damageAmount = null;
        }
        return damageAmount;
    }
}
