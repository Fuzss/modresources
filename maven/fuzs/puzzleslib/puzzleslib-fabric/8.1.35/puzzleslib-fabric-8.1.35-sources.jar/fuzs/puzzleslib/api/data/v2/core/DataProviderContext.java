package fuzs.puzzleslib.api.data.v2.core;

import com.google.common.base.Suppliers;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_2405;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7887;

/**
 * A context class for providing instances required by a {@link class_2405}.
 * <p>Very similar to Forge's <code>net.minecraftforge.data.event.GatherDataEvent</code>.
 */
public class DataProviderContext {
    /**
     * The generating mod id.
     */
    private final String modId;
    /**
     * The pack output instance.
     */
    private final class_7784 packOutput;
    /**
     * Registry lookup provider.
     */
    private final Supplier<CompletableFuture<class_7225.class_7874>> lookupProvider;

    /**
     * @param modId          the generating mod id
     * @param packOutput     the pack output instance
     * @param lookupProvider registry lookup provider
     */
    public DataProviderContext(String modId, class_7784 packOutput, Supplier<CompletableFuture<class_7225.class_7874>> lookupProvider) {
        this.modId = modId;
        this.packOutput = packOutput;
        this.lookupProvider = lookupProvider;
    }

    /**
     * Creates a dummy-like context instance useful for runtime generation in conjunction with {@link fuzs.puzzleslib.api.resources.v1.DynamicPackResources}.
     *
     * @param modId the generating mod id
     * @return new context instance
     */
    public static DataProviderContext fromModId(String modId) {
        return new DataProviderContext(modId, new class_7784(Path.of("")), Suppliers.memoize(() -> CompletableFuture.supplyAsync(class_7887::method_46817, class_156.method_18349())));
    }

    /**
     * @return the generating mod id
     */
    public String getModId() {
        return this.modId;
    }

    /**
     * @return the pack output instance
     */
    public class_7784 getPackOutput() {
        return this.packOutput;
    }

    /**
     * @return registry lookup provider
     */
    public CompletableFuture<class_7225.class_7874> getLookupProvider() {
        return this.lookupProvider.get();
    }

    /**
     * A simple shortcut for a data provider factory requiring an instance of this context, helps with complaints about parametrized varargs.
     */
    @FunctionalInterface
    public interface Factory extends Function<DataProviderContext, class_2405> {

    }
}
