package fuzs.puzzleslib.api.event.v1.entity;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1266;
import net.minecraft.class_1297;
import net.minecraft.class_1315;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.jetbrains.annotations.Nullable;

public final class ServerEntityLevelEvents {
    @Deprecated(forRemoval = true)
    public static final EventInvoker<Load> LOAD = EventInvoker.lookup(Load.class);
    public static final EventInvoker<LoadV2> LOAD_V2 = EventInvoker.lookup(LoadV2.class);
    public static final EventInvoker<Spawn> SPAWN = EventInvoker.lookup(Spawn.class);
    public static final EventInvoker<Remove> REMOVE = EventInvoker.lookup(Remove.class);

    private ServerEntityLevelEvents() {

    }

    @Deprecated(forRemoval = true)
    @FunctionalInterface
    public interface Load {

        /**
         * Fired when an entity is added to the level on the server.
         *
         * <p>In case the entity was added because it has just been spawned in the level (as opposed to being loaded from saved data),
         * instances of {@link net.minecraft.class_1308} will additionally provide the {@link class_3730},
         * which essentially allows for preventing certain types of spawns.
         *
         * @param entity    the entity that is being loaded
         * @param level     the level the entity is loaded in
         * @param spawnType if a {@link net.minecraft.class_1308} was just spawned this provides the spawn type
         * @return {@link EventResult#INTERRUPT} to prevent the entity from being added to the level (on Fabric the entity will instead just immediately be removed again),
         * {@link EventResult#PASS} for the entity to be added normally
         */
        EventResult onEntityLoad(class_1297 entity, class_3218 level, @Nullable class_3730 spawnType);
    }

    @FunctionalInterface
    public interface LoadV2 {

        /**
         * Fired when an entity is added to the level on the server, either when being loaded from chunk storage or when just having been spawned in.
         *
         * @param entity         the entity that is being loaded
         * @param level          the level the entity is loaded in
         * @return {@link EventResult#INTERRUPT} to prevent the entity from being added to the level, effectively discarding it,
         * {@link EventResult#PASS} for the entity to be added normally
         */
        EventResult onEntityLoad(class_1297 entity, class_3218 level);
    }

    @FunctionalInterface
    public interface Spawn {

        /**
         * Fired when an entity is added to the level on the server when it has just been spawned in.
         *
         * @param entity         the entity that is being spawned
         * @param level          the level the entity is spawned in
         * @param spawnType      this provides the spawn type which has been captured in {@link net.minecraft.class_1308#method_5943(class_5425, class_1266, class_3730, class_1315, class_2487)} if it has been called, otherwise <code>null</code>
         * @return {@link EventResult#INTERRUPT} to prevent the entity from being added to the level, effectively discarding it,
         * {@link EventResult#PASS} for the entity to be added normally
         */
        EventResult onEntitySpawn(class_1297 entity, class_3218 level, @Nullable class_3730 spawnType);
    }

    @FunctionalInterface
    public interface Remove {

        /**
         * Fired when an entity is removed from the level on the server.
         *
         * @param entity the entity that is being unloaded
         * @param level  the level the entity is unloaded in
         */
        void onEntityRemove(class_1297 entity, class_3218 level);
    }
}
