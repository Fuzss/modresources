package fuzs.puzzleslib.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.BuiltinModelItemRendererContext;
import fuzs.puzzleslib.api.client.init.v1.DynamicBuiltinItemRenderer;
import fuzs.puzzleslib.api.core.v1.resources.ForwardingReloadListenerHelper;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_4013;
import net.minecraft.class_7923;
import java.util.List;
import java.util.Objects;

public record BuiltinModelItemRendererContextFabricImpl(String modId, List<class_4013> dynamicRenderers) implements BuiltinModelItemRendererContext {

    @Override
    public void registerItemRenderer(DynamicBuiltinItemRenderer renderer, class_1935... items) {
        Objects.requireNonNull(renderer, "renderer is null");
        Objects.requireNonNull(items, "items is null");
        Preconditions.checkPositionIndex(1, items.length, "items is empty");
        for (class_1935 item : items) {
            Objects.requireNonNull(item, "item is null");
            BuiltinItemRendererRegistry.INSTANCE.register(item, renderer::renderByItem);
        }
        // store this to enable listening to resource reloads
        String itemName = class_7923.field_41178.method_10221(items[0].method_8389()).method_12832();
        class_2960 identifier = new class_2960(this.modId, itemName + "_built_in_model_renderer");
        this.dynamicRenderers.add(ForwardingReloadListenerHelper.fromResourceManagerReloadListener(identifier, renderer));
    }
}
