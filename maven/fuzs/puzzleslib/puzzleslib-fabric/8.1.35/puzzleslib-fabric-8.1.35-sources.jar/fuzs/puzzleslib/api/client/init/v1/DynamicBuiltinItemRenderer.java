package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_1799;
import net.minecraft.class_3300;
import net.minecraft.class_4013;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

/**
 * Provides {@link net.minecraft.class_756#method_3166} as a functional interface.
 * <p>TODO separate ResourceManagerReloadListener and change up {@link fuzs.puzzleslib.api.client.core.v1.context.BuiltinModelItemRendererContext} with a separate method, rename to 'BuiltIn' and use {@link ReloadingBuiltInItemRenderer}
 */
@FunctionalInterface
public interface DynamicBuiltinItemRenderer extends class_4013 {

    /**
     * Renders an item stack.
     * <p>Kindly copied from Fabric Api :)
     *
     * @param stack             the rendered item stack
     * @param mode              the model transformation mode
     * @param matrices          the matrix stack
     * @param vertexConsumers   the vertex consumer provider
     * @param light             packed lightmap coordinates
     * @param overlay           the overlay UV passed to {@link net.minecraft.class_4588#method_22922}
     */
    void renderByItem(class_1799 stack, class_811 mode, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay);

    @Override
    default void method_14491(class_3300 resourceManager) {

    }
}
