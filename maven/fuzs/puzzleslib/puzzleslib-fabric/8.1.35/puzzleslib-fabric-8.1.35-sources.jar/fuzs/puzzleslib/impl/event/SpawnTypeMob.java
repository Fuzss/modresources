package fuzs.puzzleslib.impl.event;

import net.minecraft.class_3730;

public interface SpawnTypeMob {

    class_3730 puzzleslib$getSpawnType();
}
