package fuzs.puzzleslib.api.chat.v1;

import fuzs.puzzleslib.impl.chat.FormattedContentSink;
import net.minecraft.class_2561;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/**
 * A helper class for converting various text representations used by vanilla to {@link class_2561}.
 * <p>Useful for text instances returned from {@link net.minecraft.class_5225} and {@link class_2561#method_30937()}.
 */
public class ComponentHelper {

    /**
     * Converts an instance of {@link class_5348} to a {@link class_2561}.
     *
     * @param formattedText the text to convert
     * @return the new component
     */
    public static class_2561 toComponent(class_5348 formattedText) {
        return new FormattedContentSink(formattedText).getComponent();
    }

    /**
     * Converts an instance of {@link class_5481} to a {@link class_2561}.
     *
     * @param formattedCharSequence the text to convert
     * @return the new component
     */
    public static class_2561 toComponent(class_5481 formattedCharSequence) {
        return new FormattedContentSink(formattedCharSequence).getComponent();
    }
}
