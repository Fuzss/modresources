package fuzs.puzzleslib.impl.client.event;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.client.event.v1.*;
import fuzs.puzzleslib.api.core.v1.resources.FabricReloadListener;
import fuzs.puzzleslib.api.event.v1.LoadCompleteCallback;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.impl.PuzzlesLib;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelResolver;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockApplyCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockGatherCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourceReloadListenerKeys;
import net.minecraft.class_1041;
import net.minecraft.class_1086;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.client.resources.model.*;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;

import static fuzs.puzzleslib.api.event.v1.core.FabricEventInvokerRegistry.INSTANCE;

@SuppressWarnings("unchecked")
public final class FabricClientEventInvokers {
    // a custom item stack used for identity matching to be able to cancel our pick block event
    private static final class_1799 INTERRUPT_PICK_ITEM_STACK = new class_1799(class_1802.field_20391);
    private static final MutableInt MODEL_LOADING_LISTENERS = new MutableInt();

    static {
        ClientPickBlockApplyCallback.EVENT.register((class_1657 player, class_239 result, class_1799 stack) -> {
            // match via reference identity so this can only be our dummy stack
            return stack == INTERRUPT_PICK_ITEM_STACK ? class_1799.field_8037 : stack;
        });
    }

    public static void registerLoadingHandlers() {
        INSTANCE.register(LoadCompleteCallback.class, ClientLifecycleEvents.CLIENT_STARTED, callback -> {
            return (class_310 minecraft) -> {
                callback.onLoadComplete();
            };
        });
        INSTANCE.register(ModelEvents.ModifyUnbakedModel.class, (ModelEvents.ModifyUnbakedModel callback, @Nullable Object o) -> {
            ModelLoadingPlugin.register(pluginContext -> {
                Map<class_2960, class_1100> additionalModels = Maps.newHashMap();
                pluginContext.modifyModelBeforeBake().register(ModelModifier.OVERRIDE_PHASE, (class_1100 model, ModelModifier.BeforeBake.Context context) -> {
                    // no need to include additional models in the model getter like on Forge, this is done automatically on Fabric via the model resolving callback
                    EventResultHolder<class_1100> result = callback.onModifyUnbakedModel(context.id(), () -> model, context.loader()::method_4726, (class_2960 resourceLocation, class_1100 unbakedModel) -> {
                        // the Fabric callback for adding additional models does not work with model resource locations
                        if (resourceLocation instanceof class_1091) {
                            throw new IllegalArgumentException("model resource location is not supported");
                        } else {
                            additionalModels.put(resourceLocation, unbakedModel);
                        }
                    });
                    return result.getInterrupt().orElse(model);
                });
                pluginContext.resolveModel().register((ModelResolver.Context context) -> {
                    return additionalModels.get(context.id());
                });
            });
        });
        INSTANCE.register(ModelEvents.ModifyBakedModel.class, (ModelEvents.ModifyBakedModel callback, @Nullable Object o) -> {
            ModelLoadingPlugin.register(pluginContext -> {
                pluginContext.modifyModelAfterBake().register(ModelModifier.OVERRIDE_PHASE, (@Nullable class_1087 model, ModelModifier.AfterBake.Context context) -> {
                    if (model != null) {
                        Map<class_2960, class_1087> models = context.loader().method_4734();
                        EventResultHolder<class_1087> result = callback.onModifyBakedModel(context.id(), () -> model, context::baker, (class_2960 resourceLocation) -> {
                            return models.containsKey(resourceLocation) ? models.get(resourceLocation) : context.baker().method_45873(resourceLocation, class_1086.field_5350);
                        }, models::putIfAbsent);
                        return result.getInterrupt().orElse(model);
                    } else {
                        return null;
                    }
                });
            });
        });
        INSTANCE.register(ModelEvents.AdditionalBakedModel.class, (ModelEvents.AdditionalBakedModel callback, @Nullable Object o) -> {
            ModelLoadingPlugin.register(pluginContext -> {
                pluginContext.modifyModelAfterBake().register((@Nullable class_1087 model, ModelModifier.AfterBake.Context context) -> {
                    // all we want is access to the top level baked models map to be able to insert our own models
                    // since the missing model is guaranteed to be baked at some point hijack the event to get to the map
                    if (context.id().equals(class_1088.field_5374)) {
                        Map<class_2960, class_1087> models = context.loader().method_4734();
                        // using the baker from the context will print the wrong model for missing textures (missing model), but that's how it is
                        callback.onAdditionalBakedModel(models::putIfAbsent, (class_2960 resourceLocation) -> {
                            return models.containsKey(resourceLocation) ? models.get(resourceLocation) : context.baker().method_45873(resourceLocation, class_1086.field_5350);
                        }, context::baker);
                    }
                    return model;
                });
            });
        });
        INSTANCE.register(ModelEvents.AfterModelLoading.class, (ModelEvents.AfterModelLoading callback, @Nullable Object o) -> {
            class_2960 resourceLocation = PuzzlesLib.id("after_model_loading/" + MODEL_LOADING_LISTENERS.incrementAndGet());
            ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(new FabricReloadListener(resourceLocation, resourceManager -> {
                class_310 minecraft = class_310.method_1551();
                callback.onAfterModelLoading(minecraft::method_1554);
            }, ResourceReloadListenerKeys.MODELS));
        });
    }

    public static void registerEventHandlers() {
        INSTANCE.register(ClientTickEvents.Start.class, net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK, callback -> {
            return callback::onStartClientTick;
        });
        INSTANCE.register(ClientTickEvents.End.class, net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK, callback -> {
            return callback::onEndClientTick;
        });
        INSTANCE.register(RenderGuiCallback.class, HudRenderCallback.EVENT, callback -> {
            return (class_332 matrixStack, float tickDelta) -> {
                class_310 minecraft = class_310.method_1551();
                class_1041 window = minecraft.method_22683();
                callback.onRenderGui(minecraft, matrixStack, tickDelta, window.method_4486(), window.method_4502());
            };
        });
        INSTANCE.register(ItemTooltipCallback.class, net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT, callback -> {
            return (class_1799 stack, class_1836 context, List<class_2561> lines) -> {
                callback.onItemTooltip(stack, class_310.method_1551().field_1724, lines, context);
            };
        });
        INSTANCE.register(RenderNameTagCallback.class, FabricClientEvents.RENDER_NAME_TAG);
        INSTANCE.register(ContainerScreenEvents.Background.class, FabricScreenEvents.CONTAINER_SCREEN_BACKGROUND);
        INSTANCE.register(ContainerScreenEvents.Foreground.class, FabricScreenEvents.CONTAINER_SCREEN_FOREGROUND);
        INSTANCE.register(InventoryMobEffectsCallback.class, FabricScreenEvents.INVENTORY_MOB_EFFECTS);
        INSTANCE.register(ScreenOpeningCallback.class, FabricScreenEvents.SCREEN_OPENING);
        INSTANCE.register(ComputeFovModifierCallback.class, FabricClientEvents.COMPUTE_FOV_MODIFIER);
        INSTANCE.register(ScreenEvents.BeforeInit.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT, callback -> {
            return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                callback.onBeforeInit(minecraft, screen, scaledWidth, scaledHeight, Collections.unmodifiableList(Screens.getButtons(screen)));
            };
        });
        INSTANCE.register(ScreenEvents.AfterInit.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT, callback -> {
            return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                List<class_339> widgets = Screens.getButtons(screen);
                callback.onAfterInit(minecraft, screen, scaledWidth, scaledHeight, Collections.unmodifiableList(widgets), widgets::add, widgets::remove);
            };
        });
        INSTANCE.register(ScreenEvents.BeforeInitV2.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT, (callback, context) -> {
            Objects.requireNonNull(context, "context is null");
            return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                if (!((Class<?>) context).isInstance(screen)) return;
                callback.onBeforeInit(minecraft, screen, scaledWidth, scaledHeight, Collections.unmodifiableList(Screens.getButtons(screen)));
            };
        });
        INSTANCE.register(ScreenEvents.AfterInitV2.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT, (callback, context) -> {
            Objects.requireNonNull(context, "context is null");
            return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                if (!((Class<?>) context).isInstance(screen)) return;
                List<class_339> widgets = Screens.getButtons(screen);
                ScreenEvents.ConsumingOperator<class_339> addWidget = new ScreenEvents.ConsumingOperator<>(widgets::add);
                ScreenEvents.ConsumingOperator<class_339> removeWidget = new ScreenEvents.ConsumingOperator<>(widgets::remove);
                callback.onAfterInit(minecraft, screen, scaledWidth, scaledHeight, Collections.unmodifiableList(widgets), addWidget, removeWidget);
            };
        });
        registerScreenEvent(ScreenEvents.Remove.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.Remove.class, callback -> {
            return callback::onRemove;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::remove);
        registerScreenEvent(ScreenEvents.BeforeRender.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BeforeRender.class, callback -> {
            return callback::onBeforeRender;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::beforeRender);
        registerScreenEvent(ScreenEvents.AfterRender.class, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterRender.class, callback -> {
            return callback::onAfterRender;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterRender);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseClick.class, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseClick.class, callback -> {
            return (screen, mouseX, mouseY, button) -> {
                return callback.onBeforeMouseClick(screen, mouseX, mouseY, button).isPass();
            };
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseClick);
        registerScreenEvent(ScreenMouseEvents.AfterMouseClick.class, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseClick.class, callback -> {
            return callback::onAfterMouseClick;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseClick);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseRelease.class, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseRelease.class, callback -> {
            return (screen, mouseX, mouseY, button) -> {
                return callback.onBeforeMouseRelease(screen, mouseX, mouseY, button).isPass();
            };
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseRelease);
        registerScreenEvent(ScreenMouseEvents.AfterMouseRelease.class, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseRelease.class, callback -> {
            return callback::onAfterMouseRelease;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseRelease);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseScroll.class, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseScroll.class, callback -> {
            return (class_437 screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount) -> {
                return callback.onBeforeMouseScroll(screen, mouseX, mouseY, horizontalAmount, verticalAmount).isPass();
            };
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseScroll);
        registerScreenEvent(ScreenMouseEvents.AfterMouseScroll.class, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseScroll.class, callback -> {
            return callback::onAfterMouseScroll;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseScroll);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseDrag.class, ExtraScreenMouseEvents.AllowMouseDrag.class, callback -> {
            return (class_437 screen, double mouseX, double mouseY, int button, double dragX, double dragY) -> {
                return callback.onBeforeMouseDrag(screen, mouseX, mouseY, button, dragX, dragY).isPass();
            };
        }, ExtraScreenMouseEvents::allowMouseDrag);
        registerScreenEvent(ScreenMouseEvents.AfterMouseDrag.class, ExtraScreenMouseEvents.AfterMouseDrag.class, callback -> {
            return callback::onAfterMouseDrag;
        }, ExtraScreenMouseEvents::afterMouseDrag);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyPress.class, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyPress.class, callback -> {
            return (class_437 screen, int key, int scancode, int modifiers) -> {
                return callback.onBeforeKeyPress(screen, key, scancode, modifiers).isPass();
            };
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyPress.class, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyPress.class, callback -> {
            return callback::onAfterKeyPress;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyRelease.class, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyRelease.class, callback -> {
            return (class_437 screen, int key, int scancode, int modifiers) -> {
                return callback.onBeforeKeyRelease(screen, key, scancode, modifiers).isPass();
            };
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyRelease);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyRelease.class, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyRelease.class, callback -> {
            return callback::onAfterKeyRelease;
        }, net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyRelease);
        INSTANCE.register(RenderGuiElementEvents.Before.class, (context, applyToInvoker, removeInvoker) -> {
            Objects.requireNonNull(context, "context is null");
            applyToInvoker.accept(FabricClientEvents.beforeRenderGuiElement(((RenderGuiElementEvents.GuiOverlay) context).id()));
        });
        INSTANCE.register(RenderGuiElementEvents.After.class, (context, applyToInvoker, removeInvoker) -> {
            Objects.requireNonNull(context, "context is null");
            applyToInvoker.accept(FabricClientEvents.afterRenderGuiElement(((RenderGuiElementEvents.GuiOverlay) context).id()));
        });
        INSTANCE.register(CustomizeChatPanelCallback.class, FabricClientEvents.CUSTOMIZE_CHAT_PANEL);
        INSTANCE.register(ClientEntityLevelEvents.Load.class, FabricClientEvents.ENTITY_LOAD);
        INSTANCE.register(ClientEntityLevelEvents.Unload.class, ClientEntityEvents.ENTITY_UNLOAD, callback -> {
            return callback::onEntityUnload;
        });
        INSTANCE.register(InputEvents.BeforeMouseAction.class, FabricClientEvents.BEFORE_MOUSE_ACTION);
        INSTANCE.register(InputEvents.AfterMouseAction.class, FabricClientEvents.AFTER_MOUSE_ACTION);
        INSTANCE.register(InputEvents.BeforeMouseScroll.class, FabricClientEvents.BEFORE_MOUSE_SCROLL);
        INSTANCE.register(InputEvents.AfterMouseScroll.class, FabricClientEvents.AFTER_MOUSE_SCROLL);
        INSTANCE.register(InputEvents.BeforeKeyAction.class, FabricClientEvents.BEFORE_KEY_ACTION);
        INSTANCE.register(InputEvents.AfterKeyAction.class, FabricClientEvents.AFTER_KEY_ACTION);
        INSTANCE.register(RenderLivingEvents.Before.class, FabricClientEvents.BEFORE_RENDER_LIVING);
        INSTANCE.register(RenderLivingEvents.After.class, FabricClientEvents.AFTER_RENDER_LIVING);
        INSTANCE.register(RenderPlayerEvents.Before.class, FabricClientEvents.BEFORE_RENDER_PLAYER);
        INSTANCE.register(RenderPlayerEvents.After.class, FabricClientEvents.AFTER_RENDER_PLAYER);
        INSTANCE.register(RenderHandCallback.class, FabricClientEvents.RENDER_HAND);
        INSTANCE.register(ComputeCameraAnglesCallback.class, FabricClientEvents.COMPUTE_CAMERA_ANGLES);
        INSTANCE.register(ClientLevelTickEvents.Start.class, net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_WORLD_TICK, callback -> {
            return (class_638 world) -> {
                callback.onStartLevelTick(class_310.method_1551(), world);
            };
        });
        INSTANCE.register(ClientLevelTickEvents.End.class, net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_WORLD_TICK, callback -> {
            return (class_638 world) -> {
                callback.onEndLevelTick(class_310.method_1551(), world);
            };
        });
        INSTANCE.register(ClientChunkEvents.Load.class, net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_LOAD, callback -> {
            return callback::onChunkLoad;
        });
        INSTANCE.register(ClientChunkEvents.Unload.class, net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_UNLOAD, callback -> {
            return callback::onChunkUnload;
        });
        INSTANCE.register(ClientPlayerEvents.LoggedIn.class, FabricClientEvents.PLAYER_LOGGED_IN);
        INSTANCE.register(ClientPlayerEvents.LoggedOut.class, FabricClientEvents.PLAYER_LOGGED_OUT);
        INSTANCE.register(ClientPlayerEvents.Copy.class, FabricClientEvents.PLAYER_COPY);
        INSTANCE.register(InteractionInputEvents.Attack.class, ClientPreAttackCallback.EVENT, callback -> {
            return (class_310 minecraft, class_746 player, int clickCount) -> {
                if (minecraft.field_1771 <= 0 && minecraft.field_1765 != null) {
                    if (clickCount != 0) {
                        if (!player.method_3144()) {
                            class_1799 itemInHand = player.method_5998(class_1268.field_5808);
                            if (itemInHand.method_45435(minecraft.field_1687.method_45162())) {
                                return callback.onAttackInteraction(minecraft, player).isInterrupt();
                            }
                        }
                    } else {
                        if (!player.method_6115() && minecraft.field_1765.method_17783() == class_239.class_240.field_1332) {
                            if (!minecraft.field_1687.method_22347(((class_3965) minecraft.field_1765).method_17777())) {
                                return callback.onAttackInteraction(minecraft, player).isInterrupt();
                            }
                        }
                    }
                }
                return false;
            };
        });
        INSTANCE.register(InteractionInputEvents.AttackV2.class, ClientPreAttackCallback.EVENT, callback -> {
            return (class_310 minecraft, class_746 player, int clickCount) -> {
                if (minecraft.field_1771 <= 0 && minecraft.field_1765 != null) {
                    if (clickCount != 0) {
                        if (!player.method_3144()) {
                            class_1799 itemInHand = player.method_5998(class_1268.field_5808);
                            if (itemInHand.method_45435(minecraft.field_1687.method_45162())) {
                                return callback.onAttackInteraction(minecraft, player, minecraft.field_1765).isInterrupt();
                            }
                        }
                    } else {
                        if (!player.method_6115() && minecraft.field_1765.method_17783() == class_239.class_240.field_1332) {
                            if (!minecraft.field_1687.method_22347(((class_3965) minecraft.field_1765).method_17777())) {
                                return callback.onAttackInteraction(minecraft, player, minecraft.field_1765).isInterrupt();
                            }
                        }
                    }
                }
                return false;
            };
        });
        INSTANCE.register(InteractionInputEvents.Use.class, UseBlockCallback.EVENT, (callback, context) -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_3965 hitResult) -> {
                // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                if (!level.field_9236) return class_1269.field_5811;
                class_310 minecraft = class_310.method_1551();
                EventResult result = callback.onUseInteraction(minecraft, (class_746) player, hand, minecraft.field_1765);
                // when interrupted cancel the interaction without the server being notified
                return result.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
            };
        }, EventPhase::early, true);
        INSTANCE.register(InteractionInputEvents.Use.class, UseEntityCallback.EVENT, (callback, context) -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) -> {
                // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                if (!level.field_9236) return class_1269.field_5811;
                class_310 minecraft = class_310.method_1551();
                EventResult result = callback.onUseInteraction(minecraft, (class_746) player, hand, minecraft.field_1765);
                // when interrupted cancel the interaction without the server being notified
                return result.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
            };
        }, EventPhase::early, true);
        INSTANCE.register(InteractionInputEvents.Use.class, UseItemCallback.EVENT, (callback, context) -> {
            return (class_1657 player, class_1937 level, class_1268 hand) -> {
                // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                if (!level.field_9236) return class_1271.method_22430(class_1799.field_8037);
                class_310 minecraft = class_310.method_1551();
                EventResult result = callback.onUseInteraction(minecraft, (class_746) player, hand, minecraft.field_1765);
                // when interrupted cancel the interaction without the server being notified
                return result.isInterrupt() ? class_1271.method_22431(class_1799.field_8037) : class_1271.method_22430(class_1799.field_8037);
            };
        }, EventPhase::early, true);
        INSTANCE.register(InteractionInputEvents.Pick.class, ClientPickBlockGatherCallback.EVENT, callback -> {
            return (class_1657 player, class_239 hitResult) -> {
                // add in more checks that also run on Forge
                if (hitResult != null && hitResult.method_17783() != class_239.class_240.field_1333) {
                    class_310 minecraft = class_310.method_1551();
                    EventResult result = callback.onPickInteraction(minecraft, (class_746) player, hitResult);
                    // this uses a second event to filter out this custom item stack again to be able to cancel the interaction
                    // otherwise just returning empty will do nothing and let the behavior continue
                    return result.isInterrupt() ? INTERRUPT_PICK_ITEM_STACK : class_1799.field_8037;
                }
                return class_1799.field_8037;
            };
        });
        INSTANCE.register(ClientLevelEvents.Load.class, FabricClientEvents.LOAD_LEVEL);
        INSTANCE.register(ClientLevelEvents.Unload.class, FabricClientEvents.UNLOAD_LEVEL);
        INSTANCE.register(MovementInputUpdateCallback.class, FabricClientEvents.MOVEMENT_INPUT_UPDATE);
        INSTANCE.register(ModelEvents.ModifyBakingResult.class, FabricClientEvents.MODIFY_BAKING_RESULT);
        INSTANCE.register(ModelEvents.BakingCompleted.class, FabricClientEvents.BAKING_COMPLETED);
        INSTANCE.register(ModelEvents.CompleteModelLoading.class, FabricClientEvents.COMPLETE_MODEL_LOADING);
        INSTANCE.register(RenderBlockOverlayCallback.class, FabricClientEvents.RENDER_BLOCK_OVERLAY);
        INSTANCE.register(FogEvents.Render.class, FabricClientEvents.RENDER_FOG);
        INSTANCE.register(FogEvents.ComputeColor.class, FabricClientEvents.COMPUTE_FOG_COLOR);
        INSTANCE.register(ScreenTooltipEvents.Render.class, FabricScreenEvents.RENDER_TOOLTIP);
        INSTANCE.register(RenderHighlightCallback.class, WorldRenderEvents.BEFORE_BLOCK_OUTLINE, callback -> {
            return (WorldRenderContext context, @Nullable class_239 hitResult) -> {
                if (hitResult == null || hitResult.method_17783() == class_239.class_240.field_1333 || hitResult.method_17783() == class_239.class_240.field_1332 && !context.blockOutlines()) return true;
                class_310 minecraft = class_310.method_1551();
                if (!(minecraft.method_1560() instanceof class_1657) || minecraft.field_1690.field_1842) return true;
                EventResult result = callback.onRenderHighlight(context.worldRenderer(), context.camera(), context.gameRenderer(), hitResult, context.tickDelta(), context.matrixStack(), context.consumers(), context.world());
                return result.isPass();
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterTerrain.class, WorldRenderEvents.BEFORE_ENTITIES, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterTerrain(context.worldRenderer(), context.camera(), context.gameRenderer(), context.tickDelta(), context.matrixStack(), context.projectionMatrix(), context.frustum(), context.world());
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterEntities.class, WorldRenderEvents.AFTER_ENTITIES, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterEntities(context.worldRenderer(), context.camera(), context.gameRenderer(), context.tickDelta(), context.matrixStack(), context.projectionMatrix(), context.frustum(), context.world());
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterTranslucent.class, WorldRenderEvents.AFTER_TRANSLUCENT, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterTranslucent(context.worldRenderer(), context.camera(), context.gameRenderer(), context.tickDelta(), context.matrixStack(), context.projectionMatrix(), context.frustum(), context.world());
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterLevel.class, WorldRenderEvents.END, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterLevel(context.worldRenderer(), context.camera(), context.gameRenderer(), context.tickDelta(), context.matrixStack(), context.projectionMatrix(), context.frustum(), context.world());
            };
        });
        INSTANCE.register(GameRenderEvents.Before.class, FabricClientEvents.BEFORE_GAME_RENDER);
        INSTANCE.register(GameRenderEvents.After.class, FabricClientEvents.AFTER_GAME_RENDER);
        INSTANCE.register(AddToastCallback.class, FabricClientEvents.ADD_TOAST);
        INSTANCE.register(GatherDebugTextEvents.Left.class, FabricClientEvents.GATHER_LEFT_DEBUG_TEXT);
        INSTANCE.register(GatherDebugTextEvents.Right.class, FabricClientEvents.GATHER_RIGHT_DEBUG_TEXT);
    }

    private static <T, E> void registerScreenEvent(Class<T> clazz, Class<E> eventType, Function<T, E> converter, Function<class_437, Event<E>> eventGetter) {
        INSTANCE.register(clazz, eventType, converter, (Object context, Consumer<Event<E>> applyToInvoker, Consumer<Event<E>> removeInvoker) -> {
            // we need to keep our own event invokers during the whole pre-init phase to guarantee phase ordering is applied correctly,
            // since this is managed in the event invokers and there seems to be no way to handle it with just the Fabric event
            // (since the Fabric event doesn't allow for retrieving already applied event phase orders),
            // so we register all screen events during pre-init, which allows post-init to already clear our internal map again
            net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT.register((class_310 client, class_437 screen, int scaledWidth, int scaledHeight) -> {
                if (((Class<?>) context).isInstance(screen)) applyToInvoker.accept(eventGetter.apply(screen));
            });
            net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((class_310 client, class_437 screen, int scaledWidth, int scaledHeight) -> {
                if (((Class<?>) context).isInstance(screen)) removeInvoker.accept(eventGetter.apply(screen));
            });
        });
    }
}
