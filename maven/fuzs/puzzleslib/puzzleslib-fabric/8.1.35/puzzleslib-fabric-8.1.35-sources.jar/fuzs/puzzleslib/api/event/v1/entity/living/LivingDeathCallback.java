package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingDeathCallback {
    EventInvoker<LivingDeathCallback> EVENT = EventInvoker.lookup(LivingDeathCallback.class);

    /**
     * Fires whenever a living entity dies, allows for preventing the death.
     * <p>Note that on Fabric this runs before the totem of undying check,
     * so may want to special case that depending on loader and include an additional check.
     *
     * @param entity the entity that has been killed
     * @param source the {@link class_1282} <code>entity</code> has been killed by
     * @return {@link EventResult#INTERRUPT} to prevent the death from happening, the entity will stay alive,
     * {@link EventResult#PASS} to allow vanilla logic to continue executing
     */
    EventResult onLivingDeath(class_1309 entity, class_1282 source);
}
