package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.impl.client.event.EntitySpectatorShaderRegistryImpl;
import fuzs.puzzleslib.mixin.client.accessor.CameraFabricAccessor;
import net.minecraft.class_1297;
import net.minecraft.class_279;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
abstract class GameRendererFabricMixin {
    @Shadow
    @Final
    private class_4184 mainCamera;
    @Shadow
    @Nullable
    private class_279 postEffect;

    @Inject(method = "checkEntityPostEffect", at = @At("TAIL"))
    public void checkEntityPostEffect(@Nullable class_1297 entity, CallbackInfo callback) {
        if (this.postEffect == null && entity != null) {
            EntitySpectatorShaderRegistryImpl.getEntityShader(entity).ifPresent(this::loadEffect);
        }
    }

    @Shadow
    private void loadEffect(class_2960 resourceLocation) {
        throw new RuntimeException();
    }

    @Inject(method = "renderLevel", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/Camera;setup(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/world/entity/Entity;ZZF)V", shift = At.Shift.AFTER))
    public void renderLevel(float partialTicks, long finishTimeNano, class_4587 matrixStack, CallbackInfo callback) {
        MutableFloat pitch = MutableFloat.fromEvent(((CameraFabricAccessor) this.mainCamera)::puzzleslib$setXRot, this.mainCamera::method_19329);
        MutableFloat yaw = MutableFloat.fromEvent(((CameraFabricAccessor) this.mainCamera)::puzzleslib$setYRot, this.mainCamera::method_19330);
        DefaultedFloat roll = DefaultedFloat.fromValue(0.0F);
        FabricClientEvents.COMPUTE_CAMERA_ANGLES.invoker().onComputeCameraAngles(class_757.class.cast(this), this.mainCamera, partialTicks, pitch, yaw, roll);
        roll.getAsOptionalFloat().ifPresent(f -> matrixStack.method_22907(class_7833.field_40718.rotationDegrees(f)));
    }
}
