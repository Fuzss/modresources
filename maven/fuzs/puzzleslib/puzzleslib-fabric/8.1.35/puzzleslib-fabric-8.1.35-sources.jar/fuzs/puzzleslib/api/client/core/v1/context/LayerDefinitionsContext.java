package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.Supplier;
import net.minecraft.class_5601;
import net.minecraft.class_5607;

/**
 * register layer definitions for entity models
 */
@FunctionalInterface
public interface LayerDefinitionsContext {

    /**
     * registers a new layer definition (used for entity model parts)
     *
     * @param layerLocation model location
     * @param supplier      layer definition supplier
     */
    void registerLayerDefinition(class_5601 layerLocation, Supplier<class_5607> supplier);
}
