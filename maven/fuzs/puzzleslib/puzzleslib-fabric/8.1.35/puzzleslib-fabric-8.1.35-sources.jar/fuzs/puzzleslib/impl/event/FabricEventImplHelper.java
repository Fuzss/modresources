package fuzs.puzzleslib.impl.event;

import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedInt;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import java.util.Collection;
import java.util.Objects;
import java.util.OptionalInt;
import java.util.function.Supplier;
import net.minecraft.class_1282;
import net.minecraft.class_1292;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_243;

public final class FabricEventImplHelper {

    private FabricEventImplHelper() {

    }

    public static MutableInt onLootingLevel(class_1309 entity, class_1282 damageSource, int lootingLevel) {
        MutableInt mutableInt = MutableInt.fromValue(lootingLevel);
        FabricLivingEvents.LOOTING_LEVEL.invoker().onLootingLevel(entity, damageSource, mutableInt);
        return mutableInt;
    }

    public static boolean tryOnLivingDrops(class_1309 entity, class_1282 damageSource, int lastHurtByPlayerTime, Supplier<MutableInt> supplier) {
        Collection<class_1542> capturedDrops = ((CapturedDropsEntity) entity).puzzleslib$acceptCapturedDrops(null);
        if (capturedDrops != null) {
            MutableInt lootingLevel = supplier.get();
            Objects.requireNonNull(lootingLevel, "looting level is null");
            EventResult result = FabricLivingEvents.LIVING_DROPS.invoker().onLivingDrops(entity, damageSource, capturedDrops, lootingLevel.getAsInt(), lastHurtByPlayerTime > 0);
            if (result.isPass()) capturedDrops.forEach(itemEntity -> entity.method_37908().method_8649(itemEntity));
            return true;
        } else {
            return false;
        }
    }

    public static void tickAirSupply(class_1309 entity, int originalAirSupply, boolean canRefillAir, boolean tryDrown) {
        boolean canLoseAir = !entity.method_6094() && !class_1292.method_5574(entity) && (!(entity instanceof class_1657) || !((class_1657) entity).method_31549().field_7480);
        tickAirSupply(entity, originalAirSupply, canRefillAir, canLoseAir, tryDrown);
    }

    public static void tickAirSupply(class_1309 entity, int originalAirSupply, boolean canRefillAir, boolean canLoseAir, boolean tryDrown) {
        DefaultedInt airAmount = DefaultedInt.fromValue(entity.method_5669() - originalAirSupply);
        EventResult result = FabricLivingEvents.LIVING_BREATHE.invoker().onLivingBreathe(entity, airAmount, canRefillAir, canLoseAir);
        if (result.isInterrupt()) {
            entity.method_5855(originalAirSupply);
        } else {
            OptionalInt optional = airAmount.getAsOptionalInt();
            if (optional.isPresent()) {
                entity.method_5855(Math.min(originalAirSupply + optional.getAsInt(), entity.method_5748()));
            }
        }
        if (tryDrown) tryDrownEntity(entity);
    }

    private static void tryDrownEntity(class_1309 entity) {
        if (entity.method_5669() > 0) return;
        boolean isDrowning = entity.method_5669() <= -20;
        EventResult result = FabricLivingEvents.LIVING_DROWN.invoker().onLivingDrown(entity, entity.method_5669(), isDrowning);
        if (result.isInterrupt()) isDrowning = result.getAsBoolean();
        if (isDrowning) {
            entity.method_5855(0);
            class_243 deltaMovement = entity.method_18798();
            for (int i = 0; i < 8; ++i) {
                double offsetX = entity.method_6051().method_43058() - entity.method_6051().method_43058();
                double offsetY = entity.method_6051().method_43058() - entity.method_6051().method_43058();
                double offsetZ = entity.method_6051().method_43058() - entity.method_6051().method_43058();
                entity.method_37908().method_8406(class_2398.field_11247, entity.method_23317() + offsetX, entity.method_23318() + offsetY, entity.method_23321() + offsetZ, deltaMovement.field_1352, deltaMovement.field_1351, deltaMovement.field_1350);
            }
            entity.method_5643(entity.method_48923().method_48824(), 2.0F);
        }
    }
}
