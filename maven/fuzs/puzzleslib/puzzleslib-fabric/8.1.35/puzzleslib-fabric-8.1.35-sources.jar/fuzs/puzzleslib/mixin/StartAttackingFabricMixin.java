package fuzs.puzzleslib.mixin;

import com.mojang.datafixers.kinds.Const;
import com.mojang.datafixers.kinds.OptionalBox;
import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_3218;
import net.minecraft.class_3902;
import net.minecraft.class_4824;
import net.minecraft.class_7906;

@Mixin(class_4824.class)
abstract class StartAttackingFabricMixin {
    @Unique
    private static boolean puzzleslib$cancelLivingChangeTarget;

    @ModifyVariable(method = "lambda$create$1(Ljava/util/function/Predicate;Ljava/util/function/Function;Lnet/minecraft/world/entity/ai/behavior/declarative/MemoryAccessor;Lnet/minecraft/world/entity/ai/behavior/declarative/MemoryAccessor;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/Mob;J)Z", at = @At(value = "LOAD", ordinal = 1), ordinal = 0)
    private static <E extends class_1308> class_1309 lambda$create$1$0(class_1309 entity, Predicate<E> canAttack, Function<E, Optional<? extends class_1309>> targetFinder, class_7906<Const.Mu<class_3902>, class_1309> memoryAccessor, class_7906<OptionalBox.Mu, Long> memoryAccessor2, class_3218 level, class_1308 mob, long l) {
        DefaultedValue<class_1309> target = DefaultedValue.fromValue(entity);
        puzzleslib$cancelLivingChangeTarget = FabricLivingEvents.LIVING_CHANGE_TARGET.invoker().onLivingChangeTarget(mob, target).isInterrupt();
        return target.getAsOptional().orElse(entity);
    }

    @Inject(method = "lambda$create$1(Ljava/util/function/Predicate;Ljava/util/function/Function;Lnet/minecraft/world/entity/ai/behavior/declarative/MemoryAccessor;Lnet/minecraft/world/entity/ai/behavior/declarative/MemoryAccessor;Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/Mob;J)Z", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/ai/behavior/declarative/MemoryAccessor;set(Ljava/lang/Object;)V"), cancellable = true)
    private static <E extends class_1308> void lambda$create$1$1(Predicate<E> canAttack, Function<E, Optional<? extends class_1309>> targetFinder, class_7906<Const.Mu<class_3902>, class_1309> memoryAccessor, class_7906<OptionalBox.Mu, Long> memoryAccessor2, class_3218 level, class_1308 mob, long l, CallbackInfoReturnable<Boolean> callback) {
        if (puzzleslib$cancelLivingChangeTarget) {
            puzzleslib$cancelLivingChangeTarget = false;
            callback.setReturnValue(false);
        }
    }
}
