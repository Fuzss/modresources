package fuzs.puzzleslib.mixin.client.accessor;

import net.minecraft.class_2338;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_7204;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_636.class)
public interface MultiPlayerGameModeFabricAccessor {

    @Accessor("isDestroying")
    boolean puzzleslib$getIsDestroying();

    @Accessor("isDestroying")
    void puzzleslib$setIsDestroying(boolean isDestroying);

    @Invoker("sameDestroyTarget")
    boolean puzzleslib$callSameDestroyTarget(class_2338 pos);

    @Invoker("startPrediction")
    void puzzleslib$callStartPrediction(class_638 clientLevel, class_7204 predictiveAction);
}
