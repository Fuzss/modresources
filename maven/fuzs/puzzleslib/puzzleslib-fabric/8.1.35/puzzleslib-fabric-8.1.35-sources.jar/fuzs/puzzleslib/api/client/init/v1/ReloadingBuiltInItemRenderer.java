package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_3300;
import net.minecraft.class_4013;

public abstract class ReloadingBuiltInItemRenderer implements DynamicBuiltinItemRenderer, class_4013 {

    @Override
    public abstract void method_14491(class_3300 resourceManager);
}
