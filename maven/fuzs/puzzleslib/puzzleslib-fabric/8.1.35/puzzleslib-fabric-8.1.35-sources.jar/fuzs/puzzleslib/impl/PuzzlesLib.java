package fuzs.puzzleslib.impl;

import net.minecraft.class_2960;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PuzzlesLib {
    public static final String MOD_ID = "puzzleslib";
    public static final String MOD_NAME = "Puzzles Lib";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_NAME);

    public static class_2960 id(String path) {
        return new class_2960(MOD_ID, path);
    }
}
