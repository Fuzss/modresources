package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.init.v2.RegistryReference;
import fuzs.puzzleslib.api.init.v2.builder.ExtendedMenuSupplier;
import fuzs.puzzleslib.api.init.v2.builder.PoiTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

public final class FabricRegistryManagerV2 extends RegistryManagerV2Impl {

    public FabricRegistryManagerV2(String modId) {
        super(modId);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected <T> RegistryReference<T> actuallyRegister(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier) {
        T value = supplier.get();
        Objects.requireNonNull(value, "value is null");
        class_2378<? super T> registry = (class_2378<? super T>) class_7923.field_41167.method_10223(registryKey.method_29177());
        Objects.requireNonNull(registry, "registry %s is null".formatted(registryKey));
        class_2960 key = this.makeKey(path);
        // PointOfInterestHelper also registers the poi type, so skip this call for that scenario
        if (!registryKey.equals(class_7924.field_41212)) class_2378.method_10230(registry, key, value);
        return new FabricRegistryReference<>(value, key, registry);
    }

    @Override
    public RegistryReference<class_1792> registerSpawnEggItem(RegistryReference<? extends class_1299<? extends class_1308>> entityTypeReference, int backgroundColor, int highlightColor, class_1792.class_1793 itemProperties) {
        return this.registerItem(entityTypeReference.getResourceLocation().method_12832() + "_spawn_egg", () -> new class_1826(entityTypeReference.get(), backgroundColor, highlightColor, itemProperties));
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T extends class_1703> RegistryReference<class_3917<T>> registerExtendedMenuType(String path, Supplier<ExtendedMenuSupplier<T>> entry) {
        return this.register((class_5321<class_2378<class_3917<T>>>) (class_5321<?>) class_7924.field_41207, path, () -> new ExtendedScreenHandlerType<>(entry.get()::create));
    }

    @Override
    public RegistryReference<class_4158> registerPoiTypeBuilder(String path, Supplier<PoiTypeBuilder> entry) {
        PoiTypeBuilder poiTypeBuilder = entry.get();
        Supplier<class_4158> supplier = () -> PointOfInterestHelper.register(this.makeKey(path), poiTypeBuilder.ticketCount(), poiTypeBuilder.searchDistance(), poiTypeBuilder.blocks());
        return this.register(class_7924.field_41212, path, supplier);
    }

    @Override
    public RegistryReference<class_4158> registerPoiType(String path, Supplier<Set<class_2680>> matchingStates, int maxTickets, int validRange) {
        return this.register(class_7924.field_41212, path, () -> PointOfInterestHelper.register(this.makeKey(path), maxTickets, validRange, matchingStates.get()));
    }
}
