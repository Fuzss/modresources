package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricScreenEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedBoolean;
import fuzs.puzzleslib.api.event.v1.data.DefaultedInt;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.Objects;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_465;
import net.minecraft.class_485;

@Mixin(class_485.class)
abstract class EffectRenderingInventoryScreenFabricMixin<T extends class_1703> extends class_465<T> {
    @Unique
    private DefaultedBoolean puzzleslib$smallWidgets;
    @Unique
    private DefaultedInt puzzleslib$horizontalOffset;

    public EffectRenderingInventoryScreenFabricMixin(T abstractContainerMenu, class_1661 inventory, class_2561 component) {
        super(abstractContainerMenu, inventory, component);
    }

    @ModifyVariable(method = "renderEffects", at = @At(value = "INVOKE", target = "Ljava/util/Collection;size()I", ordinal = 0), ordinal = 0)
    private boolean renderEffects$0(boolean fullSize) {
        this.puzzleslib$smallWidgets = DefaultedBoolean.fromValue(!fullSize);
        return fullSize;
    }

    @ModifyVariable(method = "renderEffects", at = @At(value = "INVOKE", target = "Ljava/util/Collection;size()I", ordinal = 0), ordinal = 2)
    private int renderEffects$1(int horizontalOffset) {
        this.puzzleslib$horizontalOffset = DefaultedInt.fromValue(horizontalOffset);
        return horizontalOffset;
    }

    @Inject(method = "renderEffects", at = @At(value = "INVOKE", target = "Ljava/util/Collection;size()I", ordinal = 0), cancellable = true)
    private void renderEffects$2(class_332 guiGraphics, int mouseX, int mouseY, CallbackInfo callback) {
        int i = this.field_2776 + this.field_2792 + 2;
        int j = this.field_22789 - i;
        Objects.requireNonNull(this.puzzleslib$smallWidgets, "full size rendering is null");
        Objects.requireNonNull(this.puzzleslib$horizontalOffset, "horizontal offset is null");
        EventResult result = FabricScreenEvents.INVENTORY_MOB_EFFECTS.invoker().onInventoryMobEffects(this, j, this.puzzleslib$smallWidgets, this.puzzleslib$horizontalOffset);
        if (result.isInterrupt()) {
            this.puzzleslib$smallWidgets = null;
            this.puzzleslib$horizontalOffset = null;
            callback.cancel();
        }
    }

    @ModifyVariable(method = "renderEffects", at = @At(value = "INVOKE", target = "Ljava/util/Collection;size()I", ordinal = 0), ordinal = 0)
    private boolean renderEffects$3(boolean fullSize) {
        Objects.requireNonNull(this.puzzleslib$smallWidgets, "full size rendering is null");
        fullSize = this.puzzleslib$smallWidgets.getAsOptionalBoolean().map(t -> !t).orElse(fullSize);
        this.puzzleslib$smallWidgets = null;
        return fullSize;
    }

    @ModifyVariable(method = "renderEffects", at = @At(value = "INVOKE", target = "Ljava/util/Collection;size()I", ordinal = 0), ordinal = 2)
    private int renderEffects$4(int horizontalOffset) {
        Objects.requireNonNull(this.puzzleslib$horizontalOffset, "horizontal offset is null");
        horizontalOffset = this.puzzleslib$horizontalOffset.getAsOptionalInt().orElse(horizontalOffset);
        this.puzzleslib$horizontalOffset = null;
        return horizontalOffset;
    }
}
