package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_2960;

/**
 * Context for modifying baked models right after they've been reloaded.
 * <p>Fired when the resource manager is reloading models and models have been baked, but before they are passed on for caching.
 *
 * @deprecated migrate to {@link fuzs.puzzleslib.api.client.event.v1.ModelEvents.ModifyBakingResult}
 */
@Deprecated(forRemoval = true)
public interface DynamicModifyBakingResultContext {

    /**
     * @return all baked models for modifying
     */
    Map<class_2960, class_1087> models();

    /**
     * @return the bakery
     */
    class_1088 modelBakery();
}
