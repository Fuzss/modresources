package fuzs.puzzleslib.impl.client.event;

import fuzs.puzzleslib.api.client.event.v1.ResourcePackFinderRegistry;
import fuzs.puzzleslib.impl.event.DataPackFinderRegistryImpl;
import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

public final class ResourcePackFinderRegistryImpl implements ResourcePackFinderRegistry {

    @Override
    public void register(class_3285 repositorySource) {
        Objects.requireNonNull(repositorySource, "repository source is null");
        class_3283 resourcePackRepository = class_310.method_1551().method_1520();
        DataPackFinderRegistryImpl.addRepositorySource(resourcePackRepository, repositorySource);
    }
}
