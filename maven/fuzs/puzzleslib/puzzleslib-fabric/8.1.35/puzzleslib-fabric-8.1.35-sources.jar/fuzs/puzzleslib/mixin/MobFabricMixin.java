package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import fuzs.puzzleslib.impl.PuzzlesLib;
import fuzs.puzzleslib.impl.event.SpawnTypeMob;
import net.minecraft.class_1266;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
abstract class MobFabricMixin extends class_1309 implements SpawnTypeMob {
    @Shadow
    @Nullable
    private class_1309 target;
    @Unique
    @Nullable
    private class_3730 puzzleslib$spawnType;

    protected MobFabricMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "finalizeSpawn", at = @At("TAIL"))
    public void finalizeSpawn(class_5425 level, class_1266 difficulty, class_3730 reason, @Nullable class_1315 spawnData, @Nullable class_2487 dataTag, CallbackInfoReturnable<class_1315> callback) {
        this.puzzleslib$spawnType = reason;
    }

    @Override
    @Nullable
    public final class_3730 puzzleslib$getSpawnType() {
        return this.puzzleslib$spawnType;
    }

    @ModifyVariable(method = "setTarget", at = @At("HEAD"), ordinal = 0)
    public class_1309 setTarget(@Nullable class_1309 entity) {
        DefaultedValue<class_1309> target = DefaultedValue.fromValue(entity);
        EventResult result = FabricLivingEvents.LIVING_CHANGE_TARGET.invoker().onLivingChangeTarget(this, target);
        return result.isInterrupt() ? this.target : target.getAsOptional().orElse(entity);
    }

    @Inject(method = "checkDespawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;getNearestPlayer(Lnet/minecraft/world/entity/Entity;D)Lnet/minecraft/world/entity/player/Player;", shift = At.Shift.BEFORE), cancellable = true)
    public void checkDespawn(CallbackInfo callback) {
        EventResult result = FabricLivingEvents.CHECK_MOB_DESPAWN.invoker().onCheckMobDespawn(class_1308.class.cast(this), (class_3218) this.method_37908());
        if (result.isInterrupt()) {
            if (result.getAsBoolean()) {
                this.method_31472();
            } else {
                this.field_6278 = 0;
            }
            callback.cancel();
        }
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    public void addAdditionalSaveData(class_2487 compound, CallbackInfo callback) {
        if (this.puzzleslib$spawnType != null) {
            String key = PuzzlesLib.id("spawn_type").toString();
            compound.method_10582(key, this.puzzleslib$spawnType.name());
        }
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    public void readAdditionalSaveData(class_2487 compound, CallbackInfo callback) {
        String key = PuzzlesLib.id("spawn_type").toString();
        if (compound.method_10545(key)) {
            try {
                this.puzzleslib$spawnType = class_3730.valueOf(compound.method_10558(key));
            } catch (Exception ex) {
                compound.method_10551(key);
            }
        }
    }
}
