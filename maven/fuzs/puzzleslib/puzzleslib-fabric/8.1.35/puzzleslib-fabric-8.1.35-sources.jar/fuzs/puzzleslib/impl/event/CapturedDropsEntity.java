package fuzs.puzzleslib.impl.event;

import java.util.Collection;
import net.minecraft.class_1542;

public interface CapturedDropsEntity {

    Collection<class_1542> puzzleslib$acceptCapturedDrops(Collection<class_1542> capturedDrops);
}
