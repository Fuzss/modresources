package fuzs.puzzleslib.api.event.v1.entity.living;

import com.google.common.collect.Multimap;
import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1304;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1799;

@FunctionalInterface
public interface ItemAttributeModifiersCallback {
    EventInvoker<ItemAttributeModifiersCallback> EVENT = EventInvoker.lookup(ItemAttributeModifiersCallback.class);

    /**
     * Runs after attribute modifiers have been built for an {@link class_1799} in a specific {@link class_1304}, allows for modifying those attributes.
     *
     * @param stack              the stack item attribute modifiers are being generated for
     * @param equipmentSlot      the equipment slot <code>stack</code> is currently placed in, most attributes will only apply for a specific slot, like armor points
     * @param attributeModifiers a modifiable attribute modifiers map
     */
    void onItemAttributeModifiers(class_1799 stack, class_1304 equipmentSlot, Multimap<class_1320, class_1322> attributeModifiers);
}
