package fuzs.puzzleslib.mixin.client.accessor;

import net.minecraft.class_4184;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4184.class)
public interface CameraFabricAccessor {

    @Accessor("xRot")
    void puzzleslib$setXRot(float xRot);

    @Accessor("yRot")
    void puzzleslib$setYRot(float yRot);
}
