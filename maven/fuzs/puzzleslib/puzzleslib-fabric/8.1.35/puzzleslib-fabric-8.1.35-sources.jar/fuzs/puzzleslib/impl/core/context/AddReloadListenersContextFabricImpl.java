package fuzs.puzzleslib.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.AddReloadListenersContext;
import fuzs.puzzleslib.api.core.v1.resources.FabricReloadListener;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3302;
import java.util.Objects;

public record AddReloadListenersContextFabricImpl(class_3264 packType, String modId) implements AddReloadListenersContext {

    @Override
    public void registerReloadListener(String id, class_3302 reloadListener) {
        Objects.requireNonNull(id, "reload listener id is null");
        Objects.requireNonNull(reloadListener, "reload listener is null");
        class_2960 identifier = new class_2960(this.modId, id);
        ResourceManagerHelper.get(this.packType).registerReloadListener(new FabricReloadListener(identifier, reloadListener));
    }
}
