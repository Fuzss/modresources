package fuzs.puzzleslib.api.item.v2;

import com.google.common.base.Suppliers;
import fuzs.puzzleslib.impl.item.ArmorMaterialImpl;
import fuzs.puzzleslib.impl.item.TierImpl;
import java.util.function.Supplier;
import net.minecraft.class_1741;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

/**
 * A class containing factory methods for default {@link class_1832} and {@link class_1741} implementations.
 */
public final class ItemEquipmentFactories {

    private ItemEquipmentFactories() {

    }

    /**
     * Creates a new {@link class_1832}.
     *
     * @param miningLevel       the mining level of the tier, wood / gold is 0, stone is 1, iron is 2, diamond is 3, netherite is 4
     * @param itemDurability    tool durability for this tier
     * @param miningSpeed       speed for mining blocks, wood is 2, gold is 12, stone is 4, iron is 6, diamond is 8, netherite is 9
     * @param attackDamageBonus attack damage bonus for added on top of base item damage; this mostly depends on the specific item, as the base value is different for each one since Minecraft 1.9
     * @param enchantability    enchantment value, wood is 15, gold is 22, stone is 5, iron is 14, diamond is 14, netherite is 15
     * @param repairIngredient  the repair material used in an anvil for restoring item durability
     * @return the new {@link class_1832}
     */
    public static class_1832 registerTier(int miningLevel, int itemDurability, float miningSpeed, float attackDamageBonus, int enchantability, Supplier<class_1856> repairIngredient) {
        return new TierImpl(miningLevel, itemDurability, miningSpeed, attackDamageBonus, enchantability, Suppliers.memoize(repairIngredient::get));
    }

    /**
     * Creates a new {@link class_1741}.
     *
     * @param name                 name of this material, used for the texture location
     * @param repairIngredient     the repair material used in an anvil for restoring item durability
     * @return the new {@link class_1741}
     */
    public static class_1741 registerArmorMaterial(class_2960 name, Supplier<class_1856> repairIngredient) {
        return registerArmorMaterial(name, 0, new int[]{1, 1, 1, 1}, 0, repairIngredient);
    }

    /**
     * Creates a new {@link class_1741}.
     *
     * @param name                 name of this material, used for the texture location
     * @param durabilityMultiplier multiplier for internal base durability per slot type
     * @param protectionAmounts    protection value for each slot type, order is boots, leggings, chest plate, helmet
     * @param enchantability       enchantment value, leather is 15, gold is 25, chain is 12, iron is 9, diamond is 10, turtle is 9, netherite is 15
     * @param repairIngredient     the repair material used in an anvil for restoring item durability
     * @return the new {@link class_1741}
     */
    public static class_1741 registerArmorMaterial(class_2960 name, int durabilityMultiplier, int[] protectionAmounts, int enchantability, Supplier<class_1856> repairIngredient) {
        return registerArmorMaterial(name, durabilityMultiplier, protectionAmounts, enchantability, () -> class_3417.field_14883, 0, 0, repairIngredient);
    }

    /**
     * Creates a new {@link class_1741}.
     *
     * @param name                 name of this material, used for the texture location
     * @param durabilityMultiplier multiplier for internal base durability per slot type
     * @param protectionAmounts    protection value for each slot type, order is boots, leggings, chest plate, helmet
     * @param enchantability       enchantment value, leather is 15, gold is 25, chain is 12, iron is 9, diamond is 10, turtle is 9, netherite is 15
     * @param equipSound           the sound played when putting a piece of armor into the dedicated equipment slot
     * @param toughness            armor toughness value for all slot types of this armor set
     * @param knockbackResistance  knockback resistance value for all slot types of this armor set
     * @param repairIngredient     the repair material used in an anvil for restoring item durability
     * @return the new {@link class_1741}
     */
    public static class_1741 registerArmorMaterial(class_2960 name, int durabilityMultiplier, int[] protectionAmounts, int enchantability, Supplier<class_3414> equipSound, float toughness, float knockbackResistance, Supplier<class_1856> repairIngredient) {
        return new ArmorMaterialImpl(name.toString(), durabilityMultiplier, protectionAmounts, enchantability, Suppliers.memoize(equipSound::get), toughness, knockbackResistance, Suppliers.memoize(repairIngredient::get));
    }
}
