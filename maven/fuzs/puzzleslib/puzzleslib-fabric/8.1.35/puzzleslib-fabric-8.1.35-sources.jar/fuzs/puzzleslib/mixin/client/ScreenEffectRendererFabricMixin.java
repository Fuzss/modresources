package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4603;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_4603.class)
abstract class ScreenEffectRendererFabricMixin {

    @ModifyVariable(method = "renderScreenEffect", at = @At("STORE"))
    private static @Nullable class_2680 renderScreenEffect(@Nullable class_2680 blockState, class_310 minecraft, class_4587 poseStack) {
        EventResult result = FabricClientEvents.RENDER_BLOCK_OVERLAY.invoker().onRenderBlockOverlay(minecraft.field_1724, poseStack, blockState);
        return result.isInterrupt() ? null : blockState;
    }

    @Inject(method = "renderWater", at = @At("HEAD"), cancellable = true)
    private static void renderWater(class_310 minecraft, class_4587 poseStack, CallbackInfo callback) {
        EventResult result = FabricClientEvents.RENDER_BLOCK_OVERLAY.invoker().onRenderBlockOverlay(minecraft.field_1724, poseStack, class_2246.field_10382.method_9564());
        if (result.isInterrupt()) callback.cancel();
    }

    @Inject(method = "renderFire", at = @At("HEAD"), cancellable = true)
    private static void renderFire(class_310 minecraft, class_4587 poseStack, CallbackInfo callback) {
        EventResult result = FabricClientEvents.RENDER_BLOCK_OVERLAY.invoker().onRenderBlockOverlay(minecraft.field_1724, poseStack, class_2246.field_10036.method_9564());
        if (result.isInterrupt()) callback.cancel();
    }
}
