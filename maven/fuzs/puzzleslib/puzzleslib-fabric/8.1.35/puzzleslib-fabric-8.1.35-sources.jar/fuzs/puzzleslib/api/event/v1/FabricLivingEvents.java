package fuzs.puzzleslib.api.event.v1;

import fuzs.puzzleslib.api.event.v1.core.FabricEventFactory;
import fuzs.puzzleslib.api.event.v1.entity.living.*;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

/**
 * Events originally found on Forge in the <code>net.minecraftforge.event.entity.living</code> package.
 */
public final class FabricLivingEvents {
    /**
     * Called right before xp drops are spawned in the world. Allows for cancelling drops or changing the amount.
     */
    public static final Event<LivingExperienceDropCallback> EXPERIENCE_DROP = FabricEventFactory.createResult(LivingExperienceDropCallback.class);
    /**
     * Called right at the beginning of {@link class_1309#method_5747}, allows the method to be cancelled to prevent fall damage.
     * <p>Can also be used to modify the distance the entity has fallen used for damage calculation, as well as the damage multiplier defined by the block the entity is falling on to.
     */
    public static final Event<LivingFallCallback> LIVING_FALL = FabricEventFactory.createResult(LivingFallCallback.class);
    /**
     * Called just before a {@link class_1309} drops all its loot for determining the level
     * of {@link net.minecraft.class_1893#field_9110} that should be applied to the drops.
     */
    public static final Event<LootingLevelCallback> LOOTING_LEVEL = FabricEventFactory.create(LootingLevelCallback.class);
    /**
     * Called right before drops from a killed entity are spawned in the world.
     * <p>This event is fired whenever an Entity dies and drops items in {@link class_1309#method_6078(class_1282)}.
     */
    public static final Event<LivingDropsCallback> LIVING_DROPS = FabricEventFactory.createResult(LivingDropsCallback.class);
    /**
     * Called at the beginning of {@link class_1309#method_5773()}, allows cancelling ticking the entity.
     */
    public static final Event<LivingEvents.Tick> LIVING_TICK = FabricEventFactory.createResult(LivingEvents.Tick.class);
    /**
     * Called right before any reduction on damage due to e.g. armor are done, cancelling prevents any damage / armor durability being taken.
     */
    public static final Event<LivingHurtCallback> LIVING_HURT = FabricEventFactory.createResult(LivingHurtCallback.class);
    /**
     * Fired when an item starts being used in {@link class_1309#method_6019(class_1268)}.
     */
    public static final Event<UseItemEvents.Start> USE_ITEM_START = FabricEventFactory.createResult(UseItemEvents.Start.class);
    /**
     * Fired every tick an entity is using an item.
     */
    public static final Event<UseItemEvents.Tick> USE_ITEM_TICK = FabricEventFactory.createResult(UseItemEvents.Tick.class);
    /**
     * Fired when an item is stopped being used without being finished, meaning {@link net.minecraft.class_1792#method_7881(class_1799)} has not been reached.
     */
    public static final Event<UseItemEvents.Stop> USE_ITEM_STOP = FabricEventFactory.createResult(UseItemEvents.Stop.class);
    /**
     * Fired when an item is finished being used, meaning {@link net.minecraft.class_1792#method_7881(class_1799)} has run out.
     */
    public static final Event<UseItemEvents.Finish> USE_ITEM_FINISH = FabricEventFactory.create(UseItemEvents.Finish.class);
    /**
     * Called right before damage from an incoming attack is negated via blocking using a shield.
     */
    public static final Event<ShieldBlockCallback> SHIELD_BLOCK = FabricEventFactory.createResult(ShieldBlockCallback.class);
    /**
     * Fires whenever a living entity dies, allows for preventing the death.
     */
    public static final Event<LivingDeathCallback> LIVING_DEATH = FabricEventFactory.createResult(LivingDeathCallback.class);
    /**
     * Called when a child is created from breeding two parents, allows for replacing the child or for preventing any offspring from being spawned.
     */
    public static final Event<BabyEntitySpawnCallback> BABY_ENTITY_SPAWN = FabricEventFactory.createResult(BabyEntitySpawnCallback.class);
    /**
     * Called when a player is about to tame an animal, allows for preventing taming.
     */
    public static final Event<AnimalTameCallback> ANIMAL_TAME = FabricEventFactory.createResult(AnimalTameCallback.class);
    /**
     * Fires when a {@link class_1309} is attacked, allows for cancelling that attack.
     */
    public static final Event<LivingAttackCallback> LIVING_ATTACK = FabricEventFactory.createResult(LivingAttackCallback.class);
    /**
     * Called before an entity is knocked-back in {@link class_1309#method_6005(double, double, double)}, allows for preventing the knock-back.
     */
    public static final Event<LivingKnockBackCallback> LIVING_KNOCK_BACK = FabricEventFactory.createResult(LivingKnockBackCallback.class);
    /**
     * Called when the game checks whether a new {@link class_1293} can be applied to a {@link class_1309} in {@link class_1309#method_6049(class_1293)}.
     */
    public static final Event<MobEffectEvents.Affects> MOB_EFFECT_AFFECTS = FabricEventFactory.createResult(MobEffectEvents.Affects.class);
    /**
     * Called when a new {@link class_1293} is added to a {@link class_1309} in {@link class_1309#method_37222(class_1293, class_1297)}.
     */
    public static final Event<MobEffectEvents.Apply> MOB_EFFECT_APPLY = FabricEventFactory.create(MobEffectEvents.Apply.class);
    /**
     * Called when a {@link class_1293} is removed from a {@link class_1309} in {@link class_1309#method_6016(class_1291)}.
     */
    public static final Event<MobEffectEvents.Remove> MOB_EFFECT_REMOVE = FabricEventFactory.createResult(MobEffectEvents.Remove.class);
    /**
     * Called when a {@link class_1293} is removed from a {@link class_1309} in <code>net.minecraft.world.entity.LivingEntity#tickEffects</code> due to the instance duration having run out.
     */
    public static final Event<MobEffectEvents.Expire> MOB_EFFECT_EXPIRE = FabricEventFactory.create(MobEffectEvents.Expire.class);
    /**
     * Called when an entity is jumping, allows for modifying the jump height as well as preventing the jump.
     */
    public static final Event<LivingEvents.Jump> LIVING_JUMP = FabricEventFactory.createResult(LivingEvents.Jump.class);
    /**
     * Called in {@link class_1309#method_18390(class_1297)} when an entity is trying to be targeted by another entity for applying a given percentage to the looking entity's original visibility range.
     */
    public static final Event<LivingEvents.Visibility> LIVING_VISIBILITY = FabricEventFactory.create(LivingEvents.Visibility.class);
    /**
     * Called when a {@link net.minecraft.class_1308} sets a new target.
     */
    public static final Event<LivingChangeTargetCallback> LIVING_CHANGE_TARGET = FabricEventFactory.createResult(LivingChangeTargetCallback.class);
    /**
     * Fires inside of {@link class_1308#method_5982()} to help determine if the {@link class_1308} should despawn.
     */
    public static final Event<CheckMobDespawnCallback> CHECK_MOB_DESPAWN = FabricEventFactory.createResult(CheckMobDespawnCallback.class);
    /**
     * Runs when the game updates an entity's air supply depending on if the entity can currently breathe or not.
     */
    public static final Event<LivingEvents.Breathe> LIVING_BREATHE = FabricEventFactory.createResult(LivingEvents.Breathe.class);
    /**
     * Runs before the game checks if an entity that is submerged should be damaged from drowning.
     */
    public static final Event<LivingEvents.Drown> LIVING_DROWN = FabricEventFactory.createResult(LivingEvents.Drown.class);
    /**
     * Fires whenever equipment changes are detected on an entity in {@link class_1309#method_30129()} from {@link class_1309#method_5773()}.
     */
    public static final Event<LivingEquipmentChangeCallback> LIVING_EQUIPMENT_CHANGE = FabricEventFactory.create(LivingEquipmentChangeCallback.class);

    private FabricLivingEvents() {

    }
}
