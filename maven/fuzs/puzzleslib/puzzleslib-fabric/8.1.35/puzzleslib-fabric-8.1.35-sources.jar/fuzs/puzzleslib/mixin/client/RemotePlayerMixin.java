package fuzs.puzzleslib.mixin.client;

import com.mojang.authlib.GameProfile;
import fuzs.puzzleslib.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1282;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_745.class)
abstract class RemotePlayerMixin extends class_742 {

    public RemotePlayerMixin(class_638 clientLevel, GameProfile gameProfile) {
        super(clientLevel, gameProfile);
    }

    @Inject(method = "hurt", at = @At("HEAD"), cancellable = true)
    public void hurt(class_1282 source, float amount, CallbackInfoReturnable<Boolean> callback) {
        EventResult result = FabricLivingEvents.LIVING_ATTACK.invoker().onLivingAttack(this, source, amount);
        if (result.isInterrupt()) callback.setReturnValue(false);
    }
}
