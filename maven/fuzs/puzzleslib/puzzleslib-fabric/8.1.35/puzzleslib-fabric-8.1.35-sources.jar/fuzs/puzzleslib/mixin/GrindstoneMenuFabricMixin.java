package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.impl.event.EventImplHelper;
import fuzs.puzzleslib.impl.event.GrindstoneXpHolder;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_3803;
import net.minecraft.class_3917;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3803.class)
abstract class GrindstoneMenuFabricMixin extends class_1703 implements GrindstoneXpHolder {
    @Shadow
    @Final
    private class_1263 resultSlots;
    @Shadow
    @Final
    class_1263 repairSlots;
    @Unique
    private int puzzleslib$xp = -1;

    protected GrindstoneMenuFabricMixin(@Nullable class_3917<?> menuType, int containerId) {
        super(menuType, containerId);
    }

    @Inject(method = "createResult", at = @At("HEAD"), cancellable = true)
    private void createResult(CallbackInfo callback) {
        class_1799 topInput = this.repairSlots.method_5438(0);
        class_1799 bottomInput = this.repairSlots.method_5438(1);
        MutableValue<class_1799> output = MutableValue.fromValue(class_1799.field_8037);
        MutableInt experienceReward = MutableInt.fromValue(this.puzzleslib$xp);
        class_1657 player = EventImplHelper.getPlayerFromContainerMenu(this).orElseThrow(NullPointerException::new);
        EventResult result = FabricPlayerEvents.GRINDSTONE_UPDATE.invoker().onGrindstoneUpdate(topInput, bottomInput, output, experienceReward, player);
        if (result.isInterrupt()) {
            if (result.getAsBoolean()) {
                this.resultSlots.method_5447(0, output.get());
                this.puzzleslib$xp = experienceReward.getAsInt();
                this.method_7623();
            } else {
                this.resultSlots.method_5447(0, class_1799.field_8037);
                this.puzzleslib$xp = -1;
            }
            callback.cancel();
        } else {
            this.puzzleslib$xp = -1;
        }
    }

    @Override
    public int puzzleslib$getXp() {
        return this.puzzleslib$xp;
    }
}
