package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import java.util.Map;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1092;
import net.minecraft.class_2960;

/**
 * Context for retrieving baked models from the model manager after they've been reloaded.
 * <p>Fired after the resource manager has reloaded models. Does not allow for modifying the models map, for that use {@link DynamicModifyBakingResultContext}.
 *
 * @deprecated migrate to {@link fuzs.puzzleslib.api.client.event.v1.ModelEvents.BakingCompleted}
 */
@Deprecated(forRemoval = true)
public interface DynamicBakingCompletedContext {

    /**
     * @return model manager instance
     */
    class_1092 modelManager();

    /**
     * @return all baked models, the collection is read-only
     */
    Map<class_2960, class_1087> models();

    /**
     * @return the bakery
     */
    class_1088 modelBakery();

    /**
     * Retrieves a model from the {@link #modelManager}, allows for using {@link class_2960} instead of {@link net.minecraft.class_1091}.
     *
     * @param identifier model identifier
     * @return the model, possibly empty model instance
     */
    default class_1087 getModel(class_2960 identifier) {
        return ClientAbstractions.INSTANCE.getBakedModel(identifier);
    }
}
