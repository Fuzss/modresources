package fuzs.puzzleslib.api.network.v3;

import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;

/**
 * Server-side handler for messages received by the server.
 * <p>This is implemented as an anonymous class, to force implementations to be a class as well, to prevent issues concerning loading server-only classes on a client.
 */
public abstract class ServerMessageListener<T extends Record> {

    /**
     * Called to handle the given message.
     *
     * @param message message to handle
     * @param server  minecraft server instance
     * @param handler handler for vanilla packets
     * @param player  server player entity
     * @param level   the current level of <code>player</code>
     */
    public abstract void handle(T message, MinecraftServer server, class_3244 handler, class_3222 player, class_3218 level);
}
