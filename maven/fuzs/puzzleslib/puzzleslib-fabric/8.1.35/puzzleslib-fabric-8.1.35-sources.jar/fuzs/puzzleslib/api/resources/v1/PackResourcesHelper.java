package fuzs.puzzleslib.api.resources.v1;

import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3285;
import net.minecraft.class_7699;

/**
 * This class provides some simple helper methods for constructing simple {@link net.minecraft.class_3262} implementation for either the client or server.
 */
public final class PackResourcesHelper {

    private PackResourcesHelper() {

    }

    /**
     * Creates a new resource pack repository source (for the client).
     * <p>Can be added via {@link fuzs.puzzleslib.api.client.core.v1.ClientModConstructor#onAddResourcePackFinders(PackRepositorySourcesContext)}.
     *
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param title         the title of this pack shown in the pack selection screen
     * @param description   the description for this pack shown in the pack selection screen
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be moved to the left side; this is used for the vanilla resource pack
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @return the {@link class_3285} to be added to the {@link net.minecraft.class_3283}
     */
    @Deprecated(forRemoval = true)
    public static class_3285 buildClientPack(Supplier<AbstractModPackResources> factory, String id, class_2561 title, class_2561 description, boolean required, boolean fixedPosition) {
        return buildClientPack(new class_2960(id, "main"), factory, title, description, required, fixedPosition, false);
    }

    /**
     * Creates a new resource pack repository source (for the client).
     * <p>Can be added via {@link fuzs.puzzleslib.api.client.core.v1.ClientModConstructor#onAddResourcePackFinders(PackRepositorySourcesContext)}.
     *
     * @param id      id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory {@link net.minecraft.class_3262} implementation supplier
     * @param hidden  controls whether the pack is hidden from user-facing screens like the resource pack and data pack selection screens
     * @return the {@link class_3285} to be added to the {@link net.minecraft.class_3283}
     */
    public static class_3285 buildClientPack(class_2960 id, Supplier<AbstractModPackResources> factory, boolean hidden) {
        return buildClientPack(id, factory, class_2561.method_43470("Generated Resource Pack"), class_2561.method_43470("Dynamic Resources (" + id.method_12836() + ")"), true, hidden, hidden);
    }

    /**
     * Creates a new resource pack repository source (for the client).
     * <p>Can be added via {@link fuzs.puzzleslib.api.client.core.v1.ClientModConstructor#onAddResourcePackFinders(PackRepositorySourcesContext)}.
     *
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param title         the title of this pack shown in the pack selection screen
     * @param description   the description for this pack shown in the pack selection screen
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be moved to the left side; this is used for the vanilla resource pack
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden        controls whether the pack is hidden from user-facing screens like the resource pack and data pack selection screens
     * @return the {@link class_3285} to be added to the {@link net.minecraft.class_3283}
     */
    public static class_3285 buildClientPack(class_2960 id, Supplier<AbstractModPackResources> factory, class_2561 title, class_2561 description, boolean required, boolean fixedPosition, boolean hidden) {
        return consumer -> {
            consumer.accept(AbstractModPackResources.buildPack(class_3264.field_14188, id, factory, title, description, required, fixedPosition, hidden, class_7699.method_45397()));
        };
    }

    /**
     * Creates a new data pack repository source (for the server).
     * <p>Can be added via {@link fuzs.puzzleslib.api.core.v1.ModConstructor#onAddDataPackFinders(PackRepositorySourcesContext)}.
     *
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param title         the title of this pack shown in the pack selection screen
     * @param description   the description for this pack shown in the pack selection screen
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be moved to the left side; this is used for the vanilla resource pack
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @return the {@link class_3285} to be added to the {@link net.minecraft.class_3283}
     */
    @Deprecated(forRemoval = true)
    public static class_3285 buildServerPack(Supplier<AbstractModPackResources> factory, String id, class_2561 title, class_2561 description, boolean required, boolean fixedPosition) {
        return buildServerPack(new class_2960(id, "main"), factory, title, description, required, fixedPosition, false);
    }

    /**
     * Creates a new hidden data pack repository source (for the server).
     * <p>Can be added via {@link fuzs.puzzleslib.api.core.v1.ModConstructor#onAddDataPackFinders(PackRepositorySourcesContext)}.
     *
     * @param id      id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory {@link net.minecraft.class_3262} implementation supplier
     * @param hidden  controls whether the pack is hidden from user-facing screens like the resource pack and data pack selection screens
     * @return the {@link class_3285} to be added to the {@link net.minecraft.class_3283}
     */
    public static class_3285 buildServerPack(class_2960 id, Supplier<AbstractModPackResources> factory, boolean hidden) {
        return buildServerPack(id, factory, class_2561.method_43470("Generated Data Pack"), class_2561.method_43470("Dynamic Resources (" + id.method_12836() + ")"), true, hidden, hidden);
    }

    /**
     * Creates a new data pack repository source (for the server).
     * <p>Can be added via {@link fuzs.puzzleslib.api.core.v1.ModConstructor#onAddDataPackFinders(PackRepositorySourcesContext)}.
     *
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param title         the title of this pack shown in the pack selection screen
     * @param description   the description for this pack shown in the pack selection screen
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be moved to the left side; this is used for the vanilla resource pack
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden        controls whether the pack is hidden from user-facing screens like the resource pack and data pack selection screens, only available on Forge
     * @return the {@link class_3285} to be added to the {@link net.minecraft.class_3283}
     */
    public static class_3285 buildServerPack(class_2960 id, Supplier<AbstractModPackResources> factory, class_2561 title, class_2561 description, boolean required, boolean fixedPosition, boolean hidden) {
        return consumer -> {
            consumer.accept(AbstractModPackResources.buildPack(class_3264.field_14190, id, factory, title, description, required, fixedPosition, hidden, class_7699.method_45397()));
        };
    }
}
