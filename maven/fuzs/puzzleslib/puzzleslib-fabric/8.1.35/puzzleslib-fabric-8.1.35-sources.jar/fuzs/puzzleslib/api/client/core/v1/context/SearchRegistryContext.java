package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import java.util.Objects;
import net.minecraft.class_1124;

/**
 * Register a search tree to {@link class_1124}.
 *
 * @deprecated replaced with direct access to the search registry via {@link ClientAbstractions#getSearchRegistry()}
 */
@Deprecated(forRemoval = true)
public interface SearchRegistryContext {

    /**
     * Register a search tree to {@link class_1124}.
     *
     * @param searchRegistryKey the search tree token
     * @param treeBuilder       builder supplier for search tree
     * @param <T>               type to be searched for
     */
    default <T> void registerSearchTree(class_1124.class_1125<T> searchRegistryKey, class_1124.class_7456<T> treeBuilder) {
        Objects.requireNonNull(searchRegistryKey, "search registry key is null");
        Objects.requireNonNull(treeBuilder, "tree builder is null");
        class_1124 searchRegistry = ClientAbstractions.INSTANCE.getSearchRegistry();
        Objects.requireNonNull(searchRegistry, "search tree manager is null");
        searchRegistry.method_4801(searchRegistryKey, treeBuilder);
    }
}
