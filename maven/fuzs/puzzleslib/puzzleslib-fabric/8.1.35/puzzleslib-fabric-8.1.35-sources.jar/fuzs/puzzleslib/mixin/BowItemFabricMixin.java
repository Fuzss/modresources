package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.api.event.v1.data.DefaultedInt;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Objects;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;

@Mixin(class_1753.class)
abstract class BowItemFabricMixin extends class_1811 {
    // accessed on both render and server threads, and since we remove it again after charge has been set to local variable this is necessary
    @Unique
    private final ThreadLocal<DefaultedInt> puzzleslib$charge = new ThreadLocal<>();

    public BowItemFabricMixin(class_1793 properties) {
        super(properties);
    }

    @Inject(method = "releaseUsing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;isEmpty()Z", ordinal = 0, shift = At.Shift.BEFORE), cancellable = true, locals = LocalCapture.CAPTURE_FAILEXCEPTION)
    public void releaseUsing(class_1799 stack, class_1937 level, class_1309 livingEntity, int timeCharged, CallbackInfo callback, class_1657 player, boolean hasInfiniteAmmo, class_1799 projectileStack) {
        this.puzzleslib$charge.set(DefaultedInt.fromValue(this.method_7881(stack) - timeCharged));
        if (FabricPlayerEvents.ARROW_LOOSE.invoker().onArrowLoose(player, stack, level, this.puzzleslib$charge.get(), !projectileStack.method_7960() || hasInfiniteAmmo).isInterrupt()) {
            callback.cancel();
        }
    }

    @ModifyVariable(method = "releaseUsing", at = @At("STORE"), ordinal = 1)
    public int releaseUsing(int charge) {
        Objects.requireNonNull(this.puzzleslib$charge.get(), "charge is null");
        charge = this.puzzleslib$charge.get().getAsOptionalInt().orElse(charge);
        this.puzzleslib$charge.remove();
        return charge;
    }
}
