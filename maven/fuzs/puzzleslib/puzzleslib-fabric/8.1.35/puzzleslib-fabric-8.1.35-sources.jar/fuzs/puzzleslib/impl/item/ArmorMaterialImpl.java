package fuzs.puzzleslib.impl.item;


import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1856;
import net.minecraft.class_3414;

public record ArmorMaterialImpl(String name, int durabilityMultiplier, int[] protectionAmounts,
                                int enchantability, Supplier<class_3414> equipSound, float toughness,
                                float knockbackResistance,
                                Supplier<class_1856> repairIngredient) implements class_1741 {
    private static final int[] BASE_DURABILITY = new int[]{13, 15, 16, 11};

    @Override
    public int method_48402(class_1738.class_8051 slot) {
        return BASE_DURABILITY[slot.method_48399().method_5927()] * this.durabilityMultiplier;
    }

    @Override
    public int method_48403(class_1738.class_8051 type) {
        return this.protectionAmounts[type.method_48399().method_5927()];
    }

    @Override
    public int method_7699() {
        return this.enchantability;
    }

    @Override
    public class_3414 method_7698() {
        return this.equipSound.get();
    }

    @Override
    public class_1856 method_7695() {
        return this.repairIngredient.get();
    }

    @Override
    public String method_7694() {
        return this.name;
    }

    @Override
    public float method_7700() {
        return this.toughness;
    }

    @Override
    public float method_24355() {
        return this.knockbackResistance;
    }
}
