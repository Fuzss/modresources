package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1317;
import net.minecraft.class_2902;

/**
 * register a default spawn placement for entities
 */
@FunctionalInterface
public interface SpawnPlacementsContext {

    /**
     * registers a spawning behavior for an <code>entityType</code>
     *
     * @param entityType     the entity type
     * @param location       type of spawn placement, probably {@link class_1317.class_1319#field_6317}
     * @param heightmap      heightmap type, probably {@link class_2902.class_2903#field_13203}
     * @param spawnPredicate custom spawn predicate for mob
     * @param <T>            type of entity
     */
    <T extends class_1308> void registerSpawnPlacement(class_1299<T> entityType, class_1317.class_1319 location, class_2902.class_2903 heightmap, class_1317.class_4306<T> spawnPredicate);
}
