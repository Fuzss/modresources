package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3468;

@Mixin(class_1542.class)
abstract class ItemEntityFabricMixin extends class_1297 {
    @Shadow
    private int pickupDelay;
    @Shadow
    @Nullable
    private UUID target;
    @Unique
    private class_1799 puzzleslib$originalItem = class_1799.field_8037;

    public ItemEntityFabricMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "playerTouch", at = @At("HEAD"), cancellable = true)
    public void playerTouch$0(class_1657 player, CallbackInfo callback) {
        if (!this.method_37908().field_9236) {
            if (this.pickupDelay > 0) {
                this.puzzleslib$originalItem = this.getItem().method_7972();
                return;
            }
            class_1799 itemStack = this.getItem();
            class_1792 item = itemStack.method_7909();
            int i = itemStack.method_7947();
            EventResult result = FabricPlayerEvents.ITEM_TOUCH.invoker().onItemTouch(player, class_1542.class.cast(this));
            if (!result.isInterrupt()) {
                this.puzzleslib$originalItem = this.getItem().method_7972();
                return;
            } else {
                callback.cancel();
                if (!result.getAsBoolean()) {
                    return;
                }
            }
            if (this.pickupDelay == 0 && (this.target == null || this.target.equals(player.method_5667()))) {
                FabricPlayerEvents.ITEM_PICKUP.invoker().onItemPickup(player, class_1542.class.cast(this), itemStack.method_7972());
                player.method_6103(this, i);
                if (itemStack.method_7960()) {
                    this.method_31472();
                    itemStack.method_7939(i);
                }

                player.method_7342(class_3468.field_15392.method_14956(item), i);
                player.method_29499(class_1542.class.cast(this));
            }
        }
    }

    @Inject(method = "playerTouch", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;take(Lnet/minecraft/world/entity/Entity;I)V"))
    public void playerTouch$1(class_1657 player, CallbackInfo callback) {
        if (this.puzzleslib$originalItem.method_7960()) return;
        class_1799 copy = this.puzzleslib$originalItem;
        copy.method_7939(copy.method_7947() - this.getItem().method_7947());
        FabricPlayerEvents.ITEM_PICKUP.invoker().onItemPickup(player, class_1542.class.cast(this), copy);
        this.puzzleslib$originalItem = class_1799.field_8037;
    }

    @Shadow
    public abstract class_1799 getItem();
}
