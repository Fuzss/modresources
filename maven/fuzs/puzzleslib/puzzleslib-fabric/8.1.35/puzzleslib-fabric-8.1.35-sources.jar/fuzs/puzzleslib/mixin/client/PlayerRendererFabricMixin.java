package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1007.class)
abstract class PlayerRendererFabricMixin extends class_922<class_742, class_591<class_742>> {

    public PlayerRendererFabricMixin(class_5617.class_5618 context, class_591<class_742> entityModel, float f) {
        super(context, entityModel, f);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/entity/player/PlayerRenderer;setModelProperties(Lnet/minecraft/client/player/AbstractClientPlayer;)V", shift = At.Shift.AFTER), cancellable = true)
    public void render$0(class_742 entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo callback) {
        EventResult result = FabricClientEvents.BEFORE_RENDER_PLAYER.invoker().onBeforeRenderPlayer(entity, class_1007.class.cast(this), partialTicks, matrixStack, buffer, packedLight);
        if (result.isInterrupt()) callback.cancel();
    }

    @Inject(method = "render", at = @At("TAIL"))
    public void render$1(class_742 entity, float entityYaw, float partialTicks, class_4587 matrixStack, class_4597 buffer, int packedLight, CallbackInfo callback) {
        FabricClientEvents.AFTER_RENDER_PLAYER.invoker().onAfterRenderPlayer(entity, class_1007.class.cast(this), partialTicks, matrixStack, buffer, packedLight);
    }
}
