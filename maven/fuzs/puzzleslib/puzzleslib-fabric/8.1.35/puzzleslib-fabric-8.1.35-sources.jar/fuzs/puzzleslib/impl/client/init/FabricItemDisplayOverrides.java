package fuzs.puzzleslib.impl.client.init;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.client.event.v1.FabricClientEvents;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_811;

public final class FabricItemDisplayOverrides extends ItemDisplayOverridesImpl {
    @Nullable
    private Map<class_1087, Map<class_811, class_1087>> overrideModels;

    {
        FabricClientEvents.COMPLETE_MODEL_LOADING.register(
                (Supplier<class_1092> modelManager, Supplier<class_1088> modelBakery) -> {
                    this.overrideModels = Maps.newIdentityHashMap();
                    for (Map.Entry<class_1091, Map<class_811, class_1091>> overrideEntry : this.overrideLocations.entrySet()) {
                        class_1087 itemModel = modelManager.get().method_4742(overrideEntry.getKey());
                        Objects.requireNonNull(itemModel, "item model is null");
                        this.overrideModels.put(itemModel, overrideEntry.getValue()
                                .entrySet()
                                .stream()
                                .collect(Maps.toImmutableEnumMap(Map.Entry::getKey,
                                        (Map.Entry<class_811, class_1091> entry) -> {
                                            class_1087 itemModelOverride = modelManager.get()
                                                    .method_4742(entry.getValue());
                                            Objects.requireNonNull(itemModelOverride, "item model override is null");
                                            return itemModelOverride;
                                        }
                                )));
                    }
                });
    }

    @Override
    public class_1087 getItemModelDisplayOverride(class_1087 itemModel, class_811 itemDisplayContext) {
        // if this class was only loaded by the item renderer mixin because no overrides have been registered by any mod this will still be null
        if (this.overrideModels == null) return itemModel;
        Map<class_811, class_1087> overrides = this.overrideModels.get(itemModel);
        return overrides != null ? overrides.getOrDefault(itemDisplayContext, itemModel) : itemModel;
    }
}
