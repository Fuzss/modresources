package fuzs.puzzleslib.api.item.v2.crafting;

import fuzs.puzzleslib.impl.core.CommonFactories;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_2487;

/**
 * A helper class for obtaining platform specific {@link class_1856} implementations.
 * <p>Note that when using those ingredients in recipes not all ingredients might serialize to a vanilla-compatible format,
 * meaning they will not be readable on other mod loaders as well.
 */
public interface CombinedIngredients {
    CombinedIngredients INSTANCE = CommonFactories.INSTANCE.getCombinedIngredients();

    /**
     * Creates an ingredient that matches when its sub-ingredients all match.
     *
     * @param ingredients the sub-ingredients
     * @return the compound ingredient
     */
    class_1856 all(class_1856... ingredients);

    /**
     * Creates an ingredient that matches when any of its sub-ingredients matches.
     *
     * @param ingredients the sub-ingredients
     * @return the compound ingredient
     */
    class_1856 any(class_1856... ingredients);

    /**
     * Creates an ingredient that matches if its base ingredient matches, and its subtracted ingredient <strong>does not</strong> match.
     *
     * @param ingredient the ingredient that must match
     * @param subtracted the ingredient that cannot match
     * @return the compound ingredient
     */
    class_1856 difference(class_1856 ingredient, class_1856 subtracted);

    /**
     * Creates an ingredient that matches the passed template item and nbt.
     *
     * <p>In strict mode, passing a {@code null} {@code nbt} is allowed, and will only match stacks with {@code null} NBT.
     * In partial mode, passing a {@code null} {@code nbt} is <strong>not</strong> allowed, as it would always match.
     *
     * @param item   the item to match
     * @param nbt    the item stack tag to match
     * @param strict when <code>true</code> the exact NBT must match, when <code>false</code> the ingredient NBT must be a subset of the stack NBT
     * @return the compound ingredient
     */
    default class_1856 nbt(class_1935 item, @Nullable class_2487 nbt, boolean strict) {
        Objects.requireNonNull(item, "item is null");
        if (!strict) Objects.requireNonNull(nbt, "nbt is null");
        class_1799 stack = new class_1799(item);
        stack.method_7980(nbt);
        return this.nbt(stack, strict);
    }

    /**
     * Creates an ingredient that matches the passed template stack, including NBT. Note that the count of the stack is ignored.
     *
     * <p>In strict mode, passing an {@link class_1799} where {@link class_1799#method_7969()} is {@code null} is allowed, and will only match stacks with {@code null} NBT.
     * In partial mode, passing an {@link class_1799} where {@link class_1799#method_7969()} is {@code null} is <strong>not</strong> allowed, as it would always match.
     *
     * @param stack  the item stack to construct an ingredient from
     * @param strict when <code>true</code> the exact NBT must match, when <code>false</code> the ingredient NBT must be a subset of the stack NBT
     * @return the compound ingredient
     */
    class_1856 nbt(class_1799 stack, boolean strict);
}
