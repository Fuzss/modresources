package fuzs.puzzleslib.impl.item;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_5455;
import net.minecraft.class_8566;

public class CopyTagShapelessRecipe extends class_1867 implements CopyTagRecipe {
    private final class_1856 copyFrom;

    public CopyTagShapelessRecipe(class_1867 other, class_1856 copyFrom) {
        super(other.method_8114(), other.method_8112(), other.method_45441(), other.method_8110(class_5455.field_40585), other.method_8117());
        this.copyFrom = copyFrom;
    }

    @Override
    public class_1799 method_17729(class_8566 craftingContainer, class_5455 registryAccess) {
        class_1799 itemStack = super.method_17729(craftingContainer, registryAccess);
        CopyTagRecipe.super.tryCopyTagToResult(itemStack, craftingContainer);
        return itemStack;
    }

    @Override
    public class_1865<?> method_8119() {
        return CopyTagRecipe.getModSerializer(this.method_8114().method_12836(), CopyTagRecipe.SHAPELESS_RECIPE_SERIALIZER_ID);
    }

    @Override
    public class_1856 getCopyTagSource() {
        return this.copyFrom;
    }
}
