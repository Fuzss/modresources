package fuzs.puzzleslib.api.container.v1;

import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

@Deprecated
public class NonInteractiveResultSlot extends class_1735 {
    public NonInteractiveResultSlot(class_1263 container, int i, int j, int k) {
        super(container, i, j, k);
    }

    @Override
    public void method_7670(class_1799 oldStack, class_1799 newStack) {
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return false;
    }

    @Override
    public Optional<class_1799> method_34264(int count, int decrement, class_1657 player) {
        return Optional.empty();
    }

    @Override
    public class_1799 method_32753(int count, int decrement, class_1657 player) {
        return class_1799.field_8037;
    }

    @Override
    public class_1799 method_32756(class_1799 stack) {
        return stack;
    }

    @Override
    public class_1799 method_32755(class_1799 stack, int increment) {
        return this.method_32756(stack);
    }

    @Override
    public boolean method_32754(class_1657 player) {
        return false;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return false;
    }

    @Override
    public class_1799 method_7671(int amount) {
        return class_1799.field_8037;
    }

    @Override
    public void method_7667(class_1657 player, class_1799 stack) {
    }

    @Override
    public boolean method_51306() {
        return false;
    }

    public boolean isFake() {
        return true;
    }
}
