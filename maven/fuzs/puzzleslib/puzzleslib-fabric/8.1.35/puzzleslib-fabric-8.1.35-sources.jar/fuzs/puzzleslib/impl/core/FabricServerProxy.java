package fuzs.puzzleslib.impl.core;

import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;
import java.util.function.Function;

public class FabricServerProxy implements FabricProxy {

    @Override
    public <T extends MessageV2<T>> void registerLegacyClientReceiver(class_2960 channelName, Function<class_2540, T> factory) {

    }

    @Override
    public <T extends MessageV2<T>> void registerLegacyServerReceiver(class_2960 channelName, Function<class_2540, T> factory) {
        ServerPlayNetworking.registerGlobalReceiver(channelName, (MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) -> {
            T message = factory.apply(buf);
            server.execute(() -> message.makeHandler().handle(message, player, server));
        });
    }

    @Override
    public <T extends Record & ClientboundMessage<T>> void registerClientReceiver(class_2960 channelName, Function<class_2540, T> factory) {

    }

    @Override
    public <T extends Record & ServerboundMessage<T>> void registerServerReceiver(class_2960 channelName, Function<class_2540, T> factory) {
        ServerPlayNetworking.registerGlobalReceiver(channelName, (MinecraftServer server, class_3222 player, class_3244 handler, class_2540 buf, PacketSender responseSender) -> {
            T message = factory.apply(buf);
            server.execute(() -> message.getHandler().handle(message, server, handler, player, player.method_51469()));
        });
    }
}
