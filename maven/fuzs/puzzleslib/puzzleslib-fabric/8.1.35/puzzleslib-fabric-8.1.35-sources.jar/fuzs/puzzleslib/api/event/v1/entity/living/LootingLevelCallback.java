package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import org.jetbrains.annotations.Nullable;

@FunctionalInterface
public interface LootingLevelCallback {
    EventInvoker<LootingLevelCallback> EVENT = EventInvoker.lookup(LootingLevelCallback.class);

    /**
     * Called just before a {@link class_1309} drops all its loot for determining the level
     * of {@link net.minecraft.class_1893#field_9110} that should be applied to the drops.
     *
     * @param entity the entity that is about to drop all its loot
     * @param damageSource the {@link class_1282} that causes <code>entity</code> to drop its loot
     * @param lootingLevel the current looting level
     */
    void onLootingLevel(class_1309 entity, @Nullable class_1282 damageSource, MutableInt lootingLevel);
}
