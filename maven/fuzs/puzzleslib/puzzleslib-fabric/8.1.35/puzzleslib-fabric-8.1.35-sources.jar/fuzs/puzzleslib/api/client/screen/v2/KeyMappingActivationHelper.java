package fuzs.puzzleslib.api.client.screen.v2;

import fuzs.puzzleslib.impl.client.core.ClientFactories;
import net.minecraft.class_304;
import net.minecraft.class_310;

/**
 * A small helper class for retrieving the registered {@link KeyActivationContext} for a {@link class_304}.
 */
public interface KeyMappingActivationHelper {
    KeyMappingActivationHelper INSTANCE = ClientFactories.INSTANCE.getKeyMappingActivationHelper();

    /**
     * Retrieve the registered {@link KeyActivationContext} for a {@link class_304}, will default to {@link KeyActivationContext#UNIVERSAL}.
     *
     * @param keyMapping the key mapping
     * @return an activation context for key mappings
     */
    KeyActivationContext getKeyActivationContext(class_304 keyMapping);

    /**
     * Tests if two key mappings can coexist without interfering with each other.
     *
     * @param keyMapping one key mapping
     * @param other the other key mapping
     * @return can both key mappings coexist without interfering with each other
     */
    default boolean hasConflictWith(class_304 keyMapping, class_304 other) {
        return this.getKeyActivationContext(keyMapping).hasConflictWith(this.getKeyActivationContext(other));
    }

    /**
     * An activation context for key mappings, allowing to restrict key mappings in regard to a screen being open or not.
     */
    enum KeyActivationContext {
        /**
         * A key mapping that is always processed, no matter of whether a screen is open or not.
         */
        UNIVERSAL,
        /**
         * A key mapping that is processed when the game is running without a screen being open in {@link net.minecraft.class_310#field_1755}.
         * <p>These keys are usually processed in {@link class_310#method_1574()} and corresponding events.
         */
        GAME,
        /**
         * A key mapping that is processed when a screen is open in {@link class_310#field_1755}
         * <p>These keys are usually processed in {@link net.minecraft.class_437#method_25404(int, int, int)} and {@link net.minecraft.class_437#method_25402(double, double, int)}.
         */
        SCREEN;

        /**
         * Tests if this activation context is incompatible with another one.
         *
         * @param other the other activation context
         * @return is the given activation context incompatible with this one
         */
        public boolean hasConflictWith(KeyActivationContext other) {
            return this == UNIVERSAL || other == UNIVERSAL || this == other;
        }
    }
}
