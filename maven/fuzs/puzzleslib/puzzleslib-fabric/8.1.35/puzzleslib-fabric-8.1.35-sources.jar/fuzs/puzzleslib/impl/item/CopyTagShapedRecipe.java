package fuzs.puzzleslib.impl.item;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_5455;
import net.minecraft.class_8566;

public class CopyTagShapedRecipe extends class_1869 implements CopyTagRecipe {
    private final class_1856 copyFrom;

    public CopyTagShapedRecipe(class_1869 shapedRecipe, class_1856 copyFrom) {
        super(shapedRecipe.method_8114(), shapedRecipe.method_8112(), shapedRecipe.method_45441(), shapedRecipe.method_8150(), shapedRecipe.method_8158(), shapedRecipe.method_8117(), shapedRecipe.method_8110(class_5455.field_40585), shapedRecipe.method_49188());
        this.copyFrom = copyFrom;
    }

    @Override
    public class_1799 method_17727(class_8566 craftingContainer, class_5455 registryAccess) {
        class_1799 itemStack = super.method_17727(craftingContainer, registryAccess);
        CopyTagRecipe.super.tryCopyTagToResult(itemStack, craftingContainer);
        return itemStack;
    }

    @Override
    public class_1865<?> method_8119() {
        return CopyTagRecipe.getModSerializer(this.method_8114().method_12836(), CopyTagRecipe.SHAPED_RECIPE_SERIALIZER_ID);
    }

    @Override
    public class_1856 getCopyTagSource() {
        return this.copyFrom;
    }
}
