package fuzs.puzzleslib.api.data.v2;

import com.google.common.collect.Sets;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2405;
import net.minecraft.class_2444;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;

public abstract class AbstractRecipeProvider extends class_2446 {
    private final String modId;

    public AbstractRecipeProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput());
    }

    public AbstractRecipeProvider(String modId, class_7784 packOutput) {
        super(packOutput);
        this.modId = modId;
    }

    @Nullable
    private static <T> JsonElement searchAndReplaceValue(@Nullable JsonElement jsonElement, T searchFor, T replaceWith) {
        Objects.requireNonNull(searchFor, "search for is null");
        Objects.requireNonNull(replaceWith, "replace with is null");
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            if (jsonElement.isJsonPrimitive()) {
                JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
                if (jsonPrimitive.isNumber()) {
                    if (searchFor.equals(jsonPrimitive.getAsNumber())) {
                        return new JsonPrimitive((Number) replaceWith);
                    }
                } else if (jsonPrimitive.isBoolean()) {
                    if (searchFor.equals(jsonPrimitive.getAsBoolean())) {
                        return new JsonPrimitive((Boolean) replaceWith);
                    }
                } else if (jsonPrimitive.isString()) {
                    if (searchFor.toString().equals(jsonPrimitive.getAsString())) {
                        return new JsonPrimitive(replaceWith.toString());
                    }
                }
                return jsonElement;
            } else if (jsonElement.isJsonArray()) {
                JsonArray jsonArray = jsonElement.getAsJsonArray();
                for (int i = 0; i < jsonArray.size(); i++) {
                    jsonArray.set(i, searchAndReplaceValue(jsonArray.get(i), searchFor, replaceWith));
                }
            } else if (jsonElement.isJsonObject()) {
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                    entry.setValue(searchAndReplaceValue(entry.getValue(), searchFor, replaceWith));
                }
            }
        }
        return jsonElement;
    }

    protected static String getHasName(class_1935 item, class_1935... items) {
        return "has_" + Stream.concat(Stream.of(item), Stream.of(items)).map(class_2446::method_33716).collect(Collectors.joining("_and_"));
    }

    protected static class_2066.class_2068 has(class_1935 item, class_1935... items) {
        return method_10423(class_2073.class_2074.method_8973().method_8977(Stream.concat(Stream.of(item), Stream.of(items)).toArray(class_1935[]::new)).method_8976());
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 output) {
        Set<class_2960> set = Sets.newHashSet();
        List<CompletableFuture<?>> list = new ArrayList<>();
        this.method_10419((finishedRecipe) -> {
            class_2960 id = new class_2960(this.modId, finishedRecipe.method_10417().method_12832());
            if (!set.add(id)) {
                throw new IllegalStateException("Duplicate recipe " + id);
            } else {
                list.add(class_2405.method_10320(output, finishedRecipe.method_17799(), this.field_39378.method_44107(id)));
                JsonElement jsonElement = finishedRecipe.method_10415();
                if (jsonElement != null) {
                    jsonElement = searchAndReplaceValue(jsonElement, finishedRecipe.method_10417(), id);
                    class_2960 advancementId = new class_2960(this.modId, finishedRecipe.method_10418().method_12832());
                    list.add(class_2405.method_10320(output, jsonElement, this.field_39379.method_44107(advancementId)));
                }
            }
        });
        return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
    }

    @Override
    public final void method_10419(Consumer<class_2444> exporter) {
        this.addRecipes(exporter);
    }

    public abstract void addRecipes(Consumer<class_2444> exporter);
}
