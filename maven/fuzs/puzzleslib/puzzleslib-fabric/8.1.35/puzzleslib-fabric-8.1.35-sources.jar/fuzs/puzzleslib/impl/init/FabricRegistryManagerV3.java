package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.init.v2.builder.ExtendedMenuSupplier;
import fuzs.puzzleslib.api.init.v3.RegistryHelper;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_3917;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

public final class FabricRegistryManagerV3 extends RegistryManagerV3Impl {

    public FabricRegistryManagerV3(String modId) {
        super(modId);
    }

    @Override
    public <T> class_6880.class_6883<T> getHolder(class_5321<? extends class_2378<? super T>> registryKey, String path) {
        class_2378<T> registry = RegistryHelper.findBuiltInRegistry(registryKey);
        class_5321<T> resourceKey = this.makeResourceKey(registryKey, path);
        class_6880.class_6883<T> holder = registry.method_40264(resourceKey).orElseThrow();
        if (!holder.method_40227()) {
            T value = registry.method_29107(resourceKey);
            Objects.requireNonNull(value, "value is null");
            // bind the value immediately, so we can use it, Forge does this, too
            holder.method_45918(value);
        }
        return holder;
    }

    @Override
    protected <T> class_6880.class_6883<T> _register(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier) {
        T value = supplier.get();
        Objects.requireNonNull(value, "value is null");
        class_6880.class_6883<T> holder;
        // PointOfInterestHelper also registers the poi type, so skip this call for that scenario
        if (!registryKey.equals(class_7924.field_41212)) {
            holder = class_2378.method_47985(RegistryHelper.findBuiltInRegistry(registryKey), this.makeKey(path), value);
        } else {
            holder = this.getHolder(registryKey, path);
        }
        // bind the value immediately, so we can use it, Forge does this, too
        if (!holder.method_40227()) holder.method_45918(value);
        return holder;
    }

    @Override
    public class_6880.class_6883<class_1792> registerSpawnEggItem(class_6880.class_6883<? extends class_1299<? extends class_1308>> entityTypeReference, int backgroundColor, int highlightColor, class_1792.class_1793 itemProperties) {
        return this.registerItem(entityTypeReference.method_40237().method_29177().method_12832() + "_spawn_egg", () -> new class_1826(entityTypeReference.comp_349(), backgroundColor, highlightColor, itemProperties));
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T extends class_1703> class_6880.class_6883<class_3917<T>> registerExtendedMenuType(String path, Supplier<ExtendedMenuSupplier<T>> entry) {
        return this.register((class_5321<class_2378<class_3917<T>>>) (class_5321<?>) class_7924.field_41207, path, () -> new ExtendedScreenHandlerType<>(entry.get()::create));
    }

    @Override
    public class_6880.class_6883<class_4158> registerPoiType(String path, Supplier<Set<class_2680>> matchingStates, int maxTickets, int validRange) {
        return this.register(class_7924.field_41212, path, () -> PointOfInterestHelper.register(this.makeKey(path), maxTickets, validRange, matchingStates.get()));
    }
}
