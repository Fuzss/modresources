package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import fuzs.puzzleslib.impl.event.GrindstoneXpHolder;
import fuzs.puzzleslib.mixin.accessor.GrindstoneMenuFabricAccessor;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.lang.reflect.Field;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3803;

@Mixin(targets = "net.minecraft.world.inventory.GrindstoneMenu$4")
abstract class GrindstoneMenu$ResultSlotFabricMixin extends class_1735 {
    @Shadow(aliases = "field_16780")
    @Final
    private class_3803 this$0;
    @Nullable
    @Unique
    private DefaultedValue<class_1799> puzzleslib$topInput;
    @Nullable
    @Unique
    private DefaultedValue<class_1799> puzzleslib$bottomInput;

    public ResultSlotFabricMixin(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }

    @Inject(method = "onTake", at = @At("HEAD"), cancellable = true)
    public void onTake$0(class_1657 player, class_1799 stack, CallbackInfo callback) {
        class_1263 repairSlots = ((GrindstoneMenuFabricAccessor) this.this$0).puzzleslib$getRepairSlots();
        DefaultedValue<class_1799> topInput = this.puzzleslib$topInput = DefaultedValue.fromValue(repairSlots.method_5438(0));
        DefaultedValue<class_1799> bottomInput = this.puzzleslib$bottomInput = DefaultedValue.fromValue(repairSlots.method_5438(1));
        FabricPlayerEvents.GRINDSTONE_USE.invoker().onGrindstoneUse(topInput, bottomInput, player);
    }

    @Inject(method = "onTake", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/inventory/ContainerLevelAccess;execute(Ljava/util/function/BiConsumer;)V", shift = At.Shift.AFTER), cancellable = true)
    public void onTake$1(class_1657 player, class_1799 stack, CallbackInfo callback) {
        Objects.requireNonNull(this.puzzleslib$topInput, "top input is null");
        Objects.requireNonNull(this.puzzleslib$bottomInput, "bottom input is null");
        Optional<class_1799> topInput = this.puzzleslib$topInput.getAsOptional();
        Optional<class_1799> bottomInput = this.puzzleslib$bottomInput.getAsOptional();
        this.puzzleslib$topInput = this.puzzleslib$bottomInput = null;
        if (topInput.isPresent() || bottomInput.isPresent()) {
            class_1263 repairSlots = ((GrindstoneMenuFabricAccessor) this.this$0).puzzleslib$getRepairSlots();
            repairSlots.method_5447(0, topInput.orElse(class_1799.field_8037));
            repairSlots.method_5447(1, bottomInput.orElse(class_1799.field_8037));
            callback.cancel();
        }
    }

    @Inject(method = "getExperienceAmount", at = @At("HEAD"), cancellable = true)
    private void getExperienceAmount(class_1937 level, CallbackInfoReturnable<Integer> callback) {
        int xp = ((GrindstoneXpHolder) this.this$0).puzzleslib$getXp();
        if (xp != -1) callback.setReturnValue(xp);
    }
}
