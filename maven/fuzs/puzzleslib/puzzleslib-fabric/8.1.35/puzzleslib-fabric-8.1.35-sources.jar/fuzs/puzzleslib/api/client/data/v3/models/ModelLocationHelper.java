package fuzs.puzzleslib.api.client.data.v3.models;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4941;
import net.minecraft.class_4944;
import net.minecraft.class_7923;

public final class ModelLocationHelper {
    public static final String BLOCK_PATH = "block";
    public static final String ITEM_PATH = "item";

    private ModelLocationHelper() {
        // NO-OP
    }

    public static class_2960 getBlockModel(class_2248 block) {
        return class_4941.method_25842(block);
    }

    public static class_2960 getBlockModel(class_2248 block, String suffix) {
        return class_4941.method_25843(block, suffix);
    }

    public static class_2960 getBlockModel(class_2960 resourceLocation) {
        return resourceLocation.method_45138(BLOCK_PATH + "/");
    }

    public static class_2960 getBlockModel(class_2960 resourceLocation, String suffix) {
        return getBlockModel(resourceLocation).method_48331(suffix);
    }

    public static class_2960 getBlockTexture(class_2248 block) {
        return class_4944.method_25860(block);
    }

    public static class_2960 getBlockTexture(class_2248 block, String suffix) {
        return class_4944.method_25866(block, suffix);
    }

    public static class_2960 getBlockTexture(class_2960 resourceLocation) {
        return resourceLocation.method_45138(BLOCK_PATH + "/");
    }

    public static class_2960 getBlockTexture(class_2960 resourceLocation, String suffix) {
        return getBlockTexture(resourceLocation).method_48331(suffix);
    }

    public static class_2960 getBlockLocation(class_2248 block) {
        return class_7923.field_41175.method_10221(block);
    }

    public static class_2960 getBlockLocation(class_2248 block, String suffix) {
        return getBlockLocation(block).method_48331(suffix);
    }

    public static String getBlockName(class_2248 block) {
        return getBlockLocation(block).method_12832();
    }

    public static class_2960 getItemModel(class_1792 item) {
        return class_4941.method_25840(item);
    }

    public static class_2960 getItemModel(class_1792 item, String suffix) {
        return class_4941.method_25841(item, suffix);
    }

    public static class_2960 getItemModel(class_2960 resourceLocation) {
        return resourceLocation.method_45138(ITEM_PATH + "/");
    }

    public static class_2960 getItemModel(class_2960 resourceLocation, String suffix) {
        return getItemModel(resourceLocation).method_48331(suffix);
    }

    public static class_2960 getItemTexture(class_1792 item) {
        return class_4944.method_25876(item);
    }

    public static class_2960 getItemTexture(class_1792 item, String suffix) {
        return class_4944.method_25863(item, suffix);
    }

    public static class_2960 getItemTexture(class_2960 resourceLocation) {
        return resourceLocation.method_45138(ITEM_PATH + "/");
    }

    public static class_2960 getItemTexture(class_2960 resourceLocation, String suffix) {
        return getItemTexture(resourceLocation).method_48331(suffix);
    }

    public static class_2960 getItemLocation(class_1792 item) {
        return class_7923.field_41178.method_10221(item);
    }

    public static class_2960 getItemLocation(class_1792 item, String suffix) {
        return getItemLocation(item).method_48331(suffix);
    }

    public static String getItemName(class_1792 item) {
        return getItemLocation(item).method_12832();
    }
}
