package fuzs.puzzleslib.mixin.client.accessor;

import net.minecraft.class_1124;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_310.class)
public interface MinecraftFabricAccessor {

    @Accessor("pausePartialTick")
    float puzzleslib$getPausePartialTick();

    @Accessor("searchRegistry")
    class_1124 puzzleslib$getSearchRegistry();
}
