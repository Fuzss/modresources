package fuzs.puzzleslib.impl.event;

import com.google.common.collect.MapMaker;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.core.v1.Proxy;
import fuzs.puzzleslib.api.event.v1.*;
import fuzs.puzzleslib.api.event.v1.core.*;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import fuzs.puzzleslib.api.event.v1.entity.EntityRidingEvents;
import fuzs.puzzleslib.api.event.v1.entity.ProjectileImpactCallback;
import fuzs.puzzleslib.api.event.v1.entity.ServerEntityLevelEvents;
import fuzs.puzzleslib.api.event.v1.entity.living.*;
import fuzs.puzzleslib.api.event.v1.entity.player.*;
import fuzs.puzzleslib.api.event.v1.level.*;
import fuzs.puzzleslib.api.event.v1.server.*;
import fuzs.puzzleslib.api.init.v3.RegistryHelper;
import fuzs.puzzleslib.impl.client.event.FabricClientEventInvokers;
import fuzs.puzzleslib.impl.core.FabricProxy;
import fuzs.puzzleslib.impl.event.core.EventInvokerImpl;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.lifecycle.v1.CommonLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.fabricmc.fabric.api.event.player.*;
import net.fabricmc.fabric.api.event.registry.RegistryEntryAddedCallback;
import net.fabricmc.fabric.api.item.v1.ModifyItemAttributeModifiersCallback;
import net.fabricmc.fabric.api.loot.v2.LootTableEvents;
import net.fabricmc.fabric.api.loot.v2.LootTableSource;
import net.fabricmc.fabric.api.networking.v1.EntityTrackingEvents;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3300;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_60;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public final class FabricEventInvokerRegistryImpl implements FabricEventInvokerRegistry {

    public static void registerLoadingHandlers() {
        INSTANCE.register(fuzs.puzzleslib.api.event.v1.RegistryEntryAddedCallback.class, FabricEventInvokerRegistryImpl::onRegistryEntryAdded);
        // this runs before server starting on dedicated servers
        INSTANCE.register(TagsUpdatedCallback.class, CommonLifecycleEvents.TAGS_LOADED, (TagsUpdatedCallback callback) -> {
            return callback::onTagsUpdated;
        });
        // run this early as we also use it for load complete when other events are registered and
        // this would be missed as it's registered while the callback is being invoked on dedicated servers
        INSTANCE.register(fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents.ServerStarting.class, ServerLifecycleEvents.SERVER_STARTING, (fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents.ServerStarting callback) -> {
            return callback::onServerStarting;
        });
        if (ModLoaderEnvironment.INSTANCE.isClient()) {
            FabricClientEventInvokers.registerLoadingHandlers();
        } else {
            // the Fabric callback runs for integrated servers, too, but this is manually limited to dedicated servers via the wrapping condition
            // this is also really late compared to Forge, so possibly move it to net.minecraft.server.Main::main,
            // somewhere after calling Util::startTimerHackThread where server mod loading has just completed and where the Forge hook is placed
            INSTANCE.register(LoadCompleteCallback.class, ServerLifecycleEvents.SERVER_STARTING, callback -> {
                return (MinecraftServer server) -> {
                    callback.onLoadComplete();
                };
            });
        }
    }

    @SuppressWarnings("unchecked")
    private static <T> void onRegistryEntryAdded(fuzs.puzzleslib.api.event.v1.RegistryEntryAddedCallback<T> callback, @Nullable Object context) {
        Objects.requireNonNull(context, "context is null");
        class_5321<? extends class_2378<T>> resourceKey = (class_5321<? extends class_2378<T>>) context;
        class_2378<T> registry = RegistryHelper.findBuiltInRegistry(resourceKey);
        BiConsumer<class_2960, Supplier<T>> registrar = (class_2960 resourceLocation, Supplier<T> supplier) -> {
            class_2378.method_10230(registry, resourceLocation, supplier.get());
        };
        RegistryEntryAddedCallback.event(registry).register((int rawId, class_2960 id, T object) -> {
            callback.onRegistryEntryAdded(registry, id, object, registrar);
        });
        // do not register directly to prevent ConcurrentModificationException
        Map<class_2960, Supplier<T>> toRegister = Maps.newLinkedHashMap();
        for (Map.Entry<class_5321<T>, T> entry : registry.method_29722()) {
            callback.onRegistryEntryAdded(registry, entry.getKey().method_29177(), entry.getValue(), toRegister::put);
        }
        toRegister.forEach(registrar);
    }

    public static void registerEventHandlers() {
        INSTANCE.register(PlayerInteractEvents.UseBlock.class, UseBlockCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_3965 hitResult) -> {
                class_1269 result = callback.onUseBlock(player, level, hand, hitResult).getInterrupt().orElse(class_1269.field_5811);
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (the Forge event runs after the server packet is sent)
                if (level.field_9236 && result != class_1269.field_5812 && result != class_1269.field_5811) {
                    ((FabricProxy) Proxy.INSTANCE).startClientPrediction(level, id -> new class_2885(hand, hitResult, id));
                }
                return result;
            };
        });
        INSTANCE.register(PlayerInteractEvents.AttackBlock.class, AttackBlockCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_2338 pos, class_2350 direction) -> {
                class_1269 interactionResult;
                if (!level.field_9236 || player.method_7337() || ((FabricProxy) Proxy.INSTANCE).shouldStartDestroyBlock(pos)) {
                    EventResultHolder<class_1269> result = callback.onAttackBlock(player, level, hand, pos, direction);
                    // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (achieved by returning InteractionResult#SUCCESS) since the Forge event runs after the server packet is sent
                    // returning InteractionResult#SUCCESS will return true from MultiPlayerGameMode::continueDestroyBlock which will spawn breaking particles and make the player arm swing
                    interactionResult = result.isInterrupt() ? class_1269.field_5812 : class_1269.field_5811;
                } else {
                    interactionResult = class_1269.field_5811;
                }
                return interactionResult;
            };
        });
        INSTANCE.register(PlayerInteractEvents.AttackBlockV2.class, AttackBlockCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_2338 pos, class_2350 direction) -> {
                class_1269 interactionResult;
                if (!level.field_9236 || player.method_7337() || ((FabricProxy) Proxy.INSTANCE).shouldStartDestroyBlock(pos)) {
                    EventResult result = callback.onAttackBlock(player, level, hand, pos, direction);
                    // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (achieved by returning InteractionResult#SUCCESS) since the Forge event runs after the server packet is sent
                    // returning InteractionResult#SUCCESS will return true from MultiPlayerGameMode::continueDestroyBlock which will spawn breaking particles and make the player arm swing
                    interactionResult = result.isInterrupt() ? class_1269.field_5812 : class_1269.field_5811;
                } else {
                    interactionResult = class_1269.field_5811;
                }
                return interactionResult;
            };
        });
        INSTANCE.register(PlayerInteractEvents.UseItem.class, UseItemCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand) -> {
                // parity with Forge, result item stack does not matter for Fabric implementation when result is pass
                if (player.method_7325()) {
                    return class_1271.method_22430(class_1799.field_8037);
                } else if (player.method_7357().method_7904(player.method_5998(hand).method_7909())) {
                    return class_1271.method_22430(class_1799.field_8037);
                }
                class_1271<class_1799> holder = callback.onUseItem(player, level, hand).getInterrupt().orElse(class_1271.method_22430(class_1799.field_8037));
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (the Forge event runs after the server packet is sent)
                // the Fabric implementation already takes care of SUCCESS and PASS ignored (arbitrarily enforced on Forge)
                if (level.field_9236 && holder.method_5467() != class_1269.field_5812 && holder.method_5467() != class_1269.field_5811) {
                    // send the move packet like vanilla to ensure the position+view vectors are accurate
                    Proxy.INSTANCE.getClientPacketListener().method_2883(new class_2828.class_2830(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455(), player.method_24828()));
                    // send interaction packet to the server with a new sequentially assigned id
                    ((FabricProxy) Proxy.INSTANCE).startClientPrediction(level, id -> new class_2886(hand, id));
                }
                return holder;
            };
        });
        INSTANCE.register(PlayerInteractEvents.UseItemV2.class, UseItemCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand) -> {
                // parity with Forge, result item stack does not matter for Fabric implementation when result is pass
                if (player.method_7325()) {
                    return class_1271.method_22430(class_1799.field_8037);
                } else if (player.method_7357().method_7904(player.method_5998(hand).method_7909())) {
                    return class_1271.method_22430(class_1799.field_8037);
                }
                class_1269 result = callback.onUseItem(player, level, hand).getInterrupt().orElse(class_1269.field_5811);
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (the Forge event runs after the server packet is sent)
                // the Fabric implementation already takes care of SUCCESS and PASS ignored (arbitrarily enforced on Forge)
                if (level.field_9236 && result != class_1269.field_5812 && result != class_1269.field_5811) {
                    // send the move packet like vanilla to ensure the position+view vectors are accurate
                    Proxy.INSTANCE.getClientPacketListener().method_2883(new class_2828.class_2830(player.method_23317(), player.method_23318(), player.method_23321(), player.method_36454(), player.method_36455(), player.method_24828()));
                    // send interaction packet to the server with a new sequentially assigned id
                    ((FabricProxy) Proxy.INSTANCE).startClientPrediction(level, id -> new class_2886(hand, id));
                }
                return new class_1271<>(result, class_1799.field_8037);
            };
        });
        INSTANCE.register(PlayerInteractEvents.UseEntity.class, UseEntityCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) -> {
                // Fabric handles two possible cases in one event, here we separate them again
                if (hitResult != null) return class_1269.field_5811;
                class_1269 result = callback.onUseEntity(player, level, hand, entity).getInterrupt().orElse(class_1269.field_5811);
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (the Forge event runs after the server packet is sent)
                if (level.field_9236 && result == class_1269.field_5814) {
                    Proxy.INSTANCE.getClientPacketListener().method_2883(class_2824.method_34207(entity, player.method_5715(), hand));
                }
                return result;
            };
        });
        INSTANCE.register(PlayerInteractEvents.UseEntityAt.class, UseEntityCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) -> {
                // Fabric handles two possible cases in one event, here we separate them again
                if (hitResult == null) return class_1269.field_5811;
                class_1269 result = callback.onUseEntityAt(player, level, hand, entity, hitResult.method_17784()).getInterrupt().orElse(class_1269.field_5811);
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult (the Forge event runs after the server packet is sent)
                if (level.field_9236 && result == class_1269.field_5814) {
                    Proxy.INSTANCE.getClientPacketListener().method_2883(class_2824.method_34208(entity, player.method_5715(), hand, hitResult.method_17784()));
                }
                return result;
            };
        });
        INSTANCE.register(PlayerInteractEvents.AttackEntity.class, AttackEntityCallback.EVENT, callback -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) -> {
                EventResult result = callback.onAttackEntity(player, level, hand, entity);
                // this isn't a proper item use callback (seen with the server-side and Forge implementations), so the return looks a little odd
                // we return InteractionResult#SUCCESS so the packet is sent to the server either way so the server may handle this on its own as Forge does
                return result.isInterrupt() ? class_1269.field_5812 : class_1269.field_5811;
            };
        });
        INSTANCE.register(PlayerXpEvents.PickupXp.class, FabricPlayerEvents.PICKUP_XP);
        INSTANCE.register(BonemealCallback.class, FabricPlayerEvents.BONEMEAL);
        INSTANCE.register(LivingExperienceDropCallback.class, FabricLivingEvents.EXPERIENCE_DROP);
        INSTANCE.register(BlockEvents.Break.class, PlayerBlockBreakEvents.BEFORE, callback -> {
            return (class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity) -> {
                EventResult result = callback.onBreakBlock((class_3218) level, pos, state, player, player.method_6047());
                return result.isPass();
            };
        });
        INSTANCE.register(BlockEvents.DropExperience.class, FabricLevelEvents.DROP_BLOCK_EXPERIENCE);
        INSTANCE.register(BlockEvents.FarmlandTrample.class, FabricLevelEvents.FARMLAND_TRAMPLE);
        INSTANCE.register(PlayerTickEvents.Start.class, FabricPlayerEvents.PLAYER_TICK_START);
        INSTANCE.register(PlayerTickEvents.End.class, FabricPlayerEvents.PLAYER_TICK_END);
        INSTANCE.register(LivingFallCallback.class, FabricLivingEvents.LIVING_FALL);
        INSTANCE.register(RegisterCommandsCallback.class, CommandRegistrationCallback.EVENT, callback -> {
            return callback::onRegisterCommands;
        });
        INSTANCE.register(LootTableLoadEvents.Replace.class, LootTableEvents.REPLACE, callback -> {
            return (class_3300 resourceManager, class_60 lootManager, class_2960 id, class_52 original, LootTableSource source) -> {
                // keep this the same as Forge where editing data pack specified loot tables is not supported
                if (source == LootTableSource.DATA_PACK) return null;
                DefaultedValue<class_52> lootTable = DefaultedValue.fromValue(original);
                callback.onReplaceLootTable(id, lootTable);
                // returning null will prompt no change
                return lootTable.getAsOptional().orElse(null);
            };
        });
        INSTANCE.register(LootTableLoadEvents.Modify.class, LootTableEvents.MODIFY, callback -> {
            return (class_3300 resourceManager, class_60 lootManager, class_2960 id, class_52.class_53 tableBuilder, LootTableSource source) -> {
                // don't filter on source, with our custom event on Forge we can also support non-built-in loot tables
                callback.onModifyLootTable(lootManager, id, tableBuilder::pool, index -> {
                    MutableInt currentIndex = new MutableInt();
                    MutableBoolean result = new MutableBoolean();
                    tableBuilder.modifyPools(builder -> {
                        if (index == currentIndex.getAndIncrement()) {
                            // there is no way in Fabric Api to remove loot pools, but this seems to work for disabling at least
                            builder.method_352(class_44.method_32448(0.0F));
                            builder.method_35509(class_44.method_32448(0.0F));
                            result.setTrue();
                        }
                    });
                    return result.booleanValue();
                });
            };
        });
        INSTANCE.register(AnvilRepairCallback.class, FabricPlayerEvents.ANVIL_REPAIR);
        INSTANCE.register(ItemTouchCallback.class, FabricPlayerEvents.ITEM_TOUCH);
        INSTANCE.register(PlayerEvents.ItemPickup.class, FabricPlayerEvents.ITEM_PICKUP);
        INSTANCE.register(LootingLevelCallback.class, FabricLivingEvents.LOOTING_LEVEL);
        INSTANCE.register(AnvilUpdateCallback.class, FabricPlayerEvents.ANVIL_UPDATE);
        INSTANCE.register(LivingDropsCallback.class, FabricLivingEvents.LIVING_DROPS);
        INSTANCE.register(LivingEvents.Tick.class, FabricLivingEvents.LIVING_TICK);
        INSTANCE.register(ArrowLooseCallback.class, FabricPlayerEvents.ARROW_LOOSE);
        INSTANCE.register(LivingHurtCallback.class, FabricLivingEvents.LIVING_HURT);
        INSTANCE.register(UseItemEvents.Start.class, FabricLivingEvents.USE_ITEM_START);
        INSTANCE.register(UseItemEvents.Tick.class, FabricLivingEvents.USE_ITEM_TICK);
        INSTANCE.register(UseItemEvents.Stop.class, FabricLivingEvents.USE_ITEM_STOP);
        INSTANCE.register(UseItemEvents.Finish.class, FabricLivingEvents.USE_ITEM_FINISH);
        INSTANCE.register(ShieldBlockCallback.class, FabricLivingEvents.SHIELD_BLOCK);
        INSTANCE.register(ExplosionEvents.Start.class, FabricLevelEvents.EXPLOSION_START);
        INSTANCE.register(ExplosionEvents.Detonate.class, FabricLevelEvents.EXPLOSION_DETONATE);
        INSTANCE.register(SyncDataPackContentsCallback.class, ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS, callback -> {
            return callback::onSyncDataPackContents;
        });
        INSTANCE.register(fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents.ServerStarted.class, ServerLifecycleEvents.SERVER_STARTED, callback -> {
            return callback::onServerStarted;
        });
        INSTANCE.register(fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents.ServerStopping.class, ServerLifecycleEvents.SERVER_STOPPING, callback -> {
            return callback::onServerStopping;
        });
        INSTANCE.register(fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents.ServerStopped.class, ServerLifecycleEvents.SERVER_STOPPED, callback -> {
            return callback::onServerStopped;
        });
        INSTANCE.register(PlayLevelSoundEvents.AtPosition.class, FabricLevelEvents.PLAY_LEVEL_SOUND_AT_POSITION);
        INSTANCE.register(PlayLevelSoundEvents.AtEntity.class, FabricLevelEvents.PLAY_LEVEL_SOUND_AT_ENTITY);
        INSTANCE.register(ServerEntityLevelEvents.Load.class, FabricEntityEvents.ENTITY_LOAD);
        INSTANCE.register(ServerEntityLevelEvents.LoadV2.class, FabricEntityEvents.ENTITY_LOAD_V2);
        INSTANCE.register(ServerEntityLevelEvents.Spawn.class, FabricEntityEvents.ENTITY_SPAWN);
        INSTANCE.register(ServerEntityLevelEvents.Remove.class, ServerEntityEvents.ENTITY_UNLOAD, callback -> {
            return callback::onEntityRemove;
        });
        // do not use ServerLivingEntityEvents#ALLOW_DEATH from Fabric Api as it only runs server-side
        INSTANCE.register(LivingDeathCallback.class, FabricLivingEvents.LIVING_DEATH);
        INSTANCE.register(PlayerEvents.StartTracking.class, EntityTrackingEvents.START_TRACKING, callback -> {
            return callback::onStartTracking;
        });
        INSTANCE.register(PlayerEvents.StopTracking.class, EntityTrackingEvents.STOP_TRACKING, callback -> {
            return callback::onStopTracking;
        });
        INSTANCE.register(PlayerEvents.LoggedIn.class, ServerPlayConnectionEvents.JOIN, callback -> {
            return (class_3244 handler, PacketSender sender, MinecraftServer server) -> {
                callback.onLoggedIn(handler.method_32311());
            };
        });
        INSTANCE.register(PlayerEvents.LoggedOut.class, ServerPlayConnectionEvents.DISCONNECT, callback -> {
            return (class_3244 handler, MinecraftServer server) -> {
                callback.onLoggedOut(handler.method_32311());
            };
        });
        INSTANCE.register(PlayerEvents.AfterChangeDimension.class, ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD, callback -> {
            return callback::onAfterChangeDimension;
        });
        INSTANCE.register(BabyEntitySpawnCallback.class, FabricLivingEvents.BABY_ENTITY_SPAWN);
        INSTANCE.register(AnimalTameCallback.class, FabricLivingEvents.ANIMAL_TAME);
        INSTANCE.register(LivingAttackCallback.class, FabricLivingEvents.LIVING_ATTACK);
        INSTANCE.register(PlayerEvents.Copy.class, ServerPlayerEvents.COPY_FROM, callback -> {
            return callback::onCopy;
        });
        INSTANCE.register(PlayerEvents.Respawn.class, ServerPlayerEvents.AFTER_RESPAWN, callback -> {
            return (class_3222 oldPlayer, class_3222 newPlayer, boolean alive) -> {
                callback.onRespawn(newPlayer, alive);
            };
        });
        INSTANCE.register(ServerTickEvents.Start.class, net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.START_SERVER_TICK, callback -> {
            return callback::onStartServerTick;
        });
        INSTANCE.register(ServerTickEvents.End.class, net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_SERVER_TICK, callback -> {
            return callback::onEndServerTick;
        });
        INSTANCE.register(ServerLevelTickEvents.Start.class, net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.START_WORLD_TICK, callback -> {
            return (class_3218 level) -> {
                callback.onStartLevelTick(level.method_8503(), level);
            };
        });
        INSTANCE.register(ServerLevelTickEvents.End.class, net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents.END_WORLD_TICK, callback -> {
            return (class_3218 level) -> {
                callback.onEndLevelTick(level.method_8503(), level);
            };
        });
        INSTANCE.register(ServerLevelEvents.Load.class, ServerWorldEvents.LOAD, callback -> {
            return callback::onLevelLoad;
        });
        INSTANCE.register(ServerLevelEvents.Unload.class, ServerWorldEvents.UNLOAD, callback -> {
            return callback::onLevelUnload;
        });
        INSTANCE.register(ServerChunkEvents.Load.class, net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents.CHUNK_LOAD, callback -> {
            return callback::onChunkLoad;
        });
        INSTANCE.register(ServerChunkEvents.Unload.class, net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents.CHUNK_UNLOAD, callback -> {
            return callback::onChunkUnload;
        });
        INSTANCE.register(ItemTossCallback.class, FabricPlayerEvents.ITEM_TOSS);
        INSTANCE.register(LivingKnockBackCallback.class, FabricLivingEvents.LIVING_KNOCK_BACK);
        INSTANCE.register(ItemAttributeModifiersCallback.class, ModifyItemAttributeModifiersCallback.EVENT, callback -> {
            return callback::onItemAttributeModifiers;
        });
        INSTANCE.register(ProjectileImpactCallback.class, FabricEntityEvents.PROJECTILE_IMPACT);
        INSTANCE.register(PlayerEvents.BreakSpeed.class, FabricPlayerEvents.BREAK_SPEED);
        INSTANCE.register(MobEffectEvents.Affects.class, FabricLivingEvents.MOB_EFFECT_AFFECTS);
        INSTANCE.register(MobEffectEvents.Apply.class, FabricLivingEvents.MOB_EFFECT_APPLY);
        INSTANCE.register(MobEffectEvents.Remove.class, FabricLivingEvents.MOB_EFFECT_REMOVE);
        INSTANCE.register(MobEffectEvents.Expire.class, FabricLivingEvents.MOB_EFFECT_EXPIRE);
        INSTANCE.register(LivingEvents.Jump.class, FabricLivingEvents.LIVING_JUMP);
        INSTANCE.register(LivingEvents.Visibility.class, FabricLivingEvents.LIVING_VISIBILITY);
        INSTANCE.register(LivingChangeTargetCallback.class, FabricLivingEvents.LIVING_CHANGE_TARGET);
        INSTANCE.register(CheckMobDespawnCallback.class, FabricLivingEvents.CHECK_MOB_DESPAWN);
        INSTANCE.register(GatherPotentialSpawnsCallback.class, FabricLevelEvents.GATHER_POTENTIAL_SPAWNS);
        INSTANCE.register(EntityRidingEvents.Start.class, FabricEntityEvents.ENTITY_START_RIDING);
        INSTANCE.register(EntityRidingEvents.Stop.class, FabricEntityEvents.ENTITY_STOP_RIDING);
        INSTANCE.register(GrindstoneEvents.Update.class, FabricPlayerEvents.GRINDSTONE_UPDATE);
        INSTANCE.register(GrindstoneEvents.Use.class, FabricPlayerEvents.GRINDSTONE_USE);
        // both are currently disabled due to a mod incompatibility, they are implemented in Thin Air only, where they are needed
        INSTANCE.register(LivingEvents.Breathe.class, FabricLivingEvents.LIVING_BREATHE);
        INSTANCE.register(LivingEvents.Drown.class, FabricLivingEvents.LIVING_DROWN);
        INSTANCE.register(ServerChunkEvents.Watch.class, FabricLevelEvents.WATCH_CHUNK);
        INSTANCE.register(ServerChunkEvents.Unwatch.class, FabricLevelEvents.UNWATCH_CHUNK);
        INSTANCE.register(LivingEquipmentChangeCallback.class, FabricLivingEvents.LIVING_EQUIPMENT_CHANGE);
        INSTANCE.register(LivingConversionCallback.class, ServerLivingEntityEvents.MOB_CONVERSION, (LivingConversionCallback callback) -> {
            return (class_1308 previous, class_1308 converted, boolean keepEquipment) -> {
                callback.onLivingConversion(previous, converted);
            };
        });
        if (ModLoaderEnvironment.INSTANCE.isClient()) {
            FabricClientEventInvokers.registerEventHandlers();
        }
    }

    @Override
    public <T, E> void register(Class<T> clazz, Event<E> event, FabricEventContextConverter<T, E> converter, UnaryOperator<EventPhase> eventPhaseConverter, boolean joinInvokers) {
        Objects.requireNonNull(clazz, "type is null");
        Objects.requireNonNull(event, "event is null");
        Objects.requireNonNull(converter, "converter is null");
        EventInvokerImpl.register(clazz, new FabricEventInvoker<>(event, converter, eventPhaseConverter), joinInvokers);
    }

    @Override
    public <T, E> void register(Class<T> clazz, Class<E> eventType, Function<T, E> converter, FabricEventContextConsumer<E> consumer, UnaryOperator<EventPhase> eventPhaseConverter, boolean joinInvokers) {
        Objects.requireNonNull(clazz, "type is null");
        Objects.requireNonNull(eventType, "event type is null");
        Objects.requireNonNull(converter, "converter is null");
        Objects.requireNonNull(consumer, "consumer is null");
        EventInvokerImpl.register(clazz, new FabricForwardingEventInvoker<>((T callback, @Nullable Object context) -> converter.apply(callback), consumer, eventPhaseConverter), joinInvokers);
    }

    private record FabricEventInvoker<T, E>(Event<E> event, FabricEventContextConverter<T, E> converter, UnaryOperator<EventPhase> eventPhaseConverter, Set<EventPhase> knownEventPhases) implements EventInvoker<T>, EventInvokerImpl.EventInvokerLike<T> {

        public FabricEventInvoker(Event<E> event, FabricEventContextConverter<T, E> converter, UnaryOperator<EventPhase> eventPhaseConverter) {
            this(event, converter, eventPhaseConverter, Collections.synchronizedSet(Sets.newIdentityHashSet()));
        }

        @Override
        public EventInvoker<T> asEventInvoker(@Nullable Object context) {
            return context != null ? (EventPhase phase, T callback) -> {
                this.register(phase, callback, context);
            } : this;
        }

        @Override
        public void register(EventPhase phase, T callback) {
            this.register(phase, callback, null);
        }

        private void register(EventPhase phase, T callback, @Nullable Object context) {
            Objects.requireNonNull(phase, "phase is null");
            Objects.requireNonNull(callback, "callback is null");
            phase = this.eventPhaseConverter.apply(phase);
            // this is the default phase
            if (phase.parent() == null) {
                this.event.register(this.converter.apply(callback, context));
            } else {
                // make sure phase has consumer phase ordering, we keep track of phases we have already added an ordering for in this event in #knownEventPhases
                this.testEventPhase(phase);
                this.event.register(phase.identifier(), this.converter.apply(callback, context));
            }
        }

        private void testEventPhase(EventPhase phase) {
            Stack<EventPhase> stack = new Stack<>();
            // find the first parent we already know (probably default)
            while (phase.parent() != null && !this.knownEventPhases.contains(phase)) {
                stack.push(phase);
                phase = phase.parent();
            }
            // add consumer phase ordering for all parents in reverse order until we reach the phase we want to add
            while (!stack.isEmpty()) {
                phase = stack.pop();
                phase.applyOrdering(this.event::addPhaseOrdering);
                this.knownEventPhases.add(phase);
            }
        }
    }

    private record FabricForwardingEventInvoker<T, E>(Function<Event<E>, EventInvoker<T>> factory, FabricEventContextConsumer<E> consumer, Map<Event<E>, EventInvoker<T>> events) implements EventInvokerImpl.EventInvokerLike<T> {

        public FabricForwardingEventInvoker(FabricEventContextConverter<T, E> converter, FabricEventContextConsumer<E> consumer, UnaryOperator<EventPhase> eventPhaseConverter) {
            this(event -> new FabricEventInvoker<>(event, converter, eventPhaseConverter), consumer, new MapMaker().weakKeys().concurrencyLevel(1).makeMap());
        }

        @Override
        public EventInvoker<T> asEventInvoker(@NotNull Object context) {
            Objects.requireNonNull(context, "context is null");
            // keeping track of events and corresponding invoker is not so important since there is only ever one event per context anyway which is guaranteed by the underlying implementation
            // but for managing event phases it becomes necessary to use our FabricEventInvoker to keep track
            return (EventPhase phase, T callback) -> {
                this.consumer.accept(context, event -> {
                    this.events.computeIfAbsent(event, this.factory).register(phase, callback);
                }, this.events::remove);
            };
        }
    }
}
