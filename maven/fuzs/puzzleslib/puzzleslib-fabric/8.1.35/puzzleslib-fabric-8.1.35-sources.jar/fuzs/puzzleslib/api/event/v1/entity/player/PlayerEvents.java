package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class PlayerEvents {
    public static final EventInvoker<BreakSpeed> BREAK_SPEED = EventInvoker.lookup(BreakSpeed.class);
    public static final EventInvoker<Copy> COPY = EventInvoker.lookup(Copy.class);
    public static final EventInvoker<Respawn> RESPAWN = EventInvoker.lookup(Respawn.class);
    public static final EventInvoker<StartTracking> START_TRACKING = EventInvoker.lookup(StartTracking.class);
    public static final EventInvoker<StopTracking> STOP_TRACKING = EventInvoker.lookup(StopTracking.class);
    public static final EventInvoker<LoggedIn> LOGGED_IN = EventInvoker.lookup(LoggedIn.class);
    public static final EventInvoker<LoggedOut> LOGGED_OUT = EventInvoker.lookup(LoggedOut.class);
    public static final EventInvoker<AfterChangeDimension> AFTER_CHANGE_DIMENSION = EventInvoker.lookup(AfterChangeDimension.class);
    public static final EventInvoker<ItemPickup> ITEM_PICKUP = EventInvoker.lookup(ItemPickup.class);

    private PlayerEvents() {

    }

    @FunctionalInterface
    public interface BreakSpeed {

        /**
         * Called when the player attempts to harvest a block in {@link class_1657#method_7351(class_2680)}.
         *
         * @param player     the player breaking <code>state</code>
         * @param state      the block state being broken
         * @param breakSpeed the speed at which the block is broken, usually a value around 1.0
         * @return {@link EventResult#INTERRUPT} to prevent the block from breaking, effectively setting the break speed to -1.0,
         * {@link EventResult#PASS} to allow the block to be broken at the defined break speed
         */
        EventResult onBreakSpeed(class_1657 player, class_2680 state, DefaultedFloat breakSpeed);
    }

    @FunctionalInterface
    public interface Copy {

        /**
         * Called when player data is copied to a new player.
         *
         * @param oldPlayer the old player
         * @param newPlayer the new player
         * @param alive     whether the copy was made when returning from the End dimension, otherwise caused by the old player having died
         */
        void onCopy(class_3222 oldPlayer, class_3222 newPlayer, boolean alive);
    }

    @FunctionalInterface
    public interface Respawn {

        /**
         * Called after player a has been respawned.
         *
         * @param player the player
         * @param alive  whether the copy was made when returning from the End dimension, otherwise caused by the old player having died
         */
        void onRespawn(class_3222 player, boolean alive);
    }

    @FunctionalInterface
    public interface StartTracking {

        /**
         * Called before an entity starts getting tracked by a player, meaning the player receives updates about the entity like its motion.
         *
         * @param trackedEntity the entity that will be tracked
         * @param player        the player that will track the entity
         */
        void onStartTracking(class_1297 trackedEntity, class_3222 player);
    }

    @FunctionalInterface
    public interface StopTracking {

        /**
         * Called after an entity stops getting tracked by a player.
         *
         * @param trackedEntity the entity that is no longer being tracked
         * @param player        the player that is no longer tracking the entity
         */
        void onStopTracking(class_1297 trackedEntity, class_3222 player);
    }

    @FunctionalInterface
    public interface LoggedIn {

        /**
         * Called when a player joins the server and is added to the {@link net.minecraft.class_3324}.
         *
         * @param player the player logging in
         */
        void onLoggedIn(class_3222 player);
    }

    @FunctionalInterface
    public interface LoggedOut {

        /**
         * Called when a player disconnects from the server and is removed from the {@link net.minecraft.class_3324}.
         *
         * @param player the player logging out
         */
        void onLoggedOut(class_3222 player);
    }

    @FunctionalInterface
    public interface AfterChangeDimension {

        /**
         * Called after a player has been moved to different world.
         *
         * @param player the player
         * @param from   the original world the player was in
         * @param to     the new world the player was moved to
         */
        void onAfterChangeDimension(class_3222 player, class_3218 from, class_3218 to);
    }

    @FunctionalInterface
    public interface ItemPickup {

        /**
         * Called when the player picks up an {@link class_1542} from the ground after the {@link class_1799} has been added to the player inventory.
         * <p>This events main purpose is to notify that the item pickup has happened.
         *
         * @param player     the player that touched <code>itemEntity</code>, picking up <code>stack</code> in the process
         * @param itemEntity the {@link class_1542} that was touched
         * @param stack      a stack copy containing the amount that was added to the player inventory, usually the full stack from <code>itemEntity</code>,
         *                   but can also be an empty stack in case the item pick-up was forced without considering the player inventory via {@link ItemTouchCallback}
         */
        void onItemPickup(class_1657 player, class_1542 itemEntity, class_1799 stack);
    }
}
