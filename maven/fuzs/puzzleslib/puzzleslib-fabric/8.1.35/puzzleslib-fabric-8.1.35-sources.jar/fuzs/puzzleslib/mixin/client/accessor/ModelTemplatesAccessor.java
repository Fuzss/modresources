package fuzs.puzzleslib.mixin.client.accessor;

import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4945;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_4943.class)
public interface ModelTemplatesAccessor {

    @Invoker("createItem")
    static class_4942 puzzleslib$callCreateItem(String itemModelLocation, class_4945... requiredSlots) {
        throw new RuntimeException();
    }
}
