package fuzs.puzzleslib.impl.item;

import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;

public record TierImpl(int miningLevel, int itemDurability, float miningSpeed, float attackDamage, int enchantability, Supplier<class_1856> repairIngredient) implements class_1832 {

    @Override
    public int method_8025() {
        return this.itemDurability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public int method_8024() {
        return this.miningLevel;
    }

    @Override
    public int method_8026() {
        return this.enchantability;
    }

    @Override
    public class_1856 method_8023() {
        return this.repairIngredient.get();
    }
}
