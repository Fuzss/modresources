package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.particle.v1.ClientParticleTypes;
import fuzs.puzzleslib.impl.client.particle.ClientParticleTypesImpl;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2960;
import net.minecraft.class_702;
import net.minecraft.class_707;

/**
 * Register a particle provider for a particle type.
 */
public interface ParticleProvidersContext {

    /**
     * Register a client-side factory for a particle type.
     *
     * @param particleType     common particle type
     * @param particleProvider particle factory
     * @param <T>              type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707<T> particleProvider);

    /**
     * Register a client-side factory for a particle type.
     *
     * @param particleType     common particle type
     * @param particleProvider particle factory
     * @param <T>              type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707.class_8187<T> particleProvider);

    /**
     * Register a client-side sprite based factory for a particle type.
     *
     * @param particleType    common particle type
     * @param particleFactory particle factory
     * @param <T>             type of particle
     * @deprecated renamed to {@link #registerParticleProvider(class_2396, class_702.class_4091)}
     */
    @Deprecated(forRemoval = true)
    default <T extends class_2394> void registerParticleFactory(class_2396<T> particleType, class_702.class_4091<T> particleFactory) {
        this.registerParticleProvider(particleType, particleFactory);
    }

    /**
     * Register a client-side sprite based factory for a particle type.
     *
     * @param particleType    common particle type
     * @param particleFactory particle factory
     * @param <T>             type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_702.class_4091<T> particleFactory);

    /**
     * Register a client-side factory for a particle type that has not been registered in common and will not be present on dedicated servers.
     * <p>Intended for client-only mods to allow for custom particles, which would otherwise be unavailable on dedicated servers if registered normally due to registry sync (at least on Forge).
     *
     * @param identifier       client particle type identifier
     * @param particleProvider particle factory
     * @param <T>              type of particle
     */
    default <T extends class_2394> void registerClientParticleProvider(class_2960 identifier, class_707<T> particleProvider) {
        ((ClientParticleTypesImpl) ClientParticleTypes.INSTANCE).getParticleTypesManager(identifier.method_12836()).register(identifier, particleProvider);
    }

    /**
     * Register a client-side factory for a particle type that has not been registered in common and will not be present on dedicated servers.
     * <p>Intended for client-only mods to allow for custom particles, which would otherwise be unavailable on dedicated servers if registered normally due to registry sync (at least on Forge).
     *
     * @param identifier       client particle type identifier
     * @param particleProvider particle factory
     * @param <T>              type of particle
     */
    default <T extends class_2394> void registerClientParticleProvider(class_2960 identifier, class_707.class_8187<T> particleProvider) {
        ((ClientParticleTypesImpl) ClientParticleTypes.INSTANCE).getParticleTypesManager(identifier.method_12836()).register(identifier, particleProvider);
    }

    /**
     * Register a client-side sprite based factory for a particle type that has not been registered in common and will not be present on dedicated servers.
     * <p>Intended for client-only mods to allow for custom particles, which would otherwise be unavailable on dedicated servers if registered normally due to registry sync (at least on Forge).
     *
     * @param identifier      client particle type identifier
     * @param particleFactory particle factory
     * @param <T>             type of particle
     */
    default <T extends class_2394> void registerClientParticleProvider(class_2960 identifier, class_702.class_4091<T> particleFactory) {
        ((ClientParticleTypesImpl) ClientParticleTypes.INSTANCE).getParticleTypesManager(identifier.method_12836()).register(identifier, particleFactory);
    }
}
