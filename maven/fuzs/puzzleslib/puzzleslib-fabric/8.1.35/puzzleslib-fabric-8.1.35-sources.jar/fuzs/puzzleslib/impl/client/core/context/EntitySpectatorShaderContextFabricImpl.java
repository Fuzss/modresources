package fuzs.puzzleslib.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.EntitySpectatorShaderContext;
import fuzs.puzzleslib.api.client.event.v1.EntitySpectatorShaderRegistry;
import java.util.Objects;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public final class EntitySpectatorShaderContextFabricImpl implements EntitySpectatorShaderContext {

    @Override
    public void registerSpectatorShader(class_2960 shaderLocation, class_1299<?>... entityTypes) {
        Objects.requireNonNull(shaderLocation, "shader location is null");
        Objects.requireNonNull(entityTypes, "entity types is null");
        Preconditions.checkPositionIndex(1, entityTypes.length, "entity types is empty");
        for (class_1299<?> entityType : entityTypes) {
            Objects.requireNonNull(entityType, "entity type is null");
            EntitySpectatorShaderRegistry.INSTANCE.register(entityType, shaderLocation);
        }
    }
}
