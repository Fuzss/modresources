package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.init.v1.BuiltinItemRenderer;
import fuzs.puzzleslib.api.client.init.v1.ReloadingBuiltInItemRenderer;
import fuzs.puzzleslib.api.client.renderer.v1.special.SpecialModelRenderer;
import fuzs.puzzleslib.impl.client.renderer.SpecialBuiltInItemRenderer;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1935;

/**
 * Register a custom renderer for an item.
 */
public interface BuiltinModelItemRendererContext {

    /**
     * Register a {@link BuiltinItemRenderer} for an item.
     *
     * @param item     the item
     * @param renderer the custom implementation of
     *                 {@link net.minecraft.class_756}
     */
    void registerItemRenderer(class_1792 item, BuiltinItemRenderer renderer);

    @Deprecated
    default void registerItemRenderer(BuiltinItemRenderer renderer, class_1935... items) {
        Objects.requireNonNull(items, "items is null");
        for (class_1935 item : items) {
            this.registerItemRenderer(item.method_8389(), renderer);
        }
    }

    /**
     * Register a {@link ReloadingBuiltInItemRenderer} for an item.
     *
     * @param item     the item
     * @param renderer the custom implementation of
     *                 {@link net.minecraft.class_756}
     */
    void registerItemRenderer(class_1792 item, ReloadingBuiltInItemRenderer renderer);

    @Deprecated
    default void registerItemRenderer(ReloadingBuiltInItemRenderer renderer, class_1935... items) {
        Objects.requireNonNull(items, "items is null");
        for (class_1935 item : items) {
            this.registerItemRenderer(item.method_8389(), renderer);
        }
    }

    /**
     * Register a {@link SpecialModelRenderer.Unbaked} for an item.
     *
     * @param item     the item
     * @param renderer the special model renderer
     */
    default void registerItemRenderer(class_1792 item, SpecialModelRenderer.Unbaked<?> specialModelRenderer) {
        this.registerItemRenderer(item, new SpecialBuiltInItemRenderer<>(specialModelRenderer));
    }
}
