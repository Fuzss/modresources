package fuzs.puzzleslib.api.biome.v1;

import org.apache.commons.lang3.math.Fraction;

import java.util.Objects;
import java.util.Optional;
import java.util.function.IntUnaryOperator;
import java.util.function.ToIntFunction;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;

/**
 * A builder for configuring mob spawner data in biome spawn settings.
 */
public final class SpawnerDataBuilder {
    private final MobSpawnSettingsContext context;
    private final class_1299<?> entityType;
    private IntUnaryOperator weightMapper = IntUnaryOperator.identity();
    private ToIntFunction<class_5483.class_1964> minCountMapper = (class_5483.class_1964 spawnerData) -> {
        return spawnerData.field_9388;
    };
    private ToIntFunction<class_5483.class_1964> maxCountMapper = (class_5483.class_1964 spawnerData) -> {
        return spawnerData.field_9387;
    };

    private SpawnerDataBuilder(MobSpawnSettingsContext context, class_1299<?> entityType) {
        Objects.requireNonNull(context, "context is null");
        Objects.requireNonNull(entityType, "entity type is null");
        this.context = context;
        this.entityType = entityType;
    }

    /**
     * Creates a new spawner data builder.
     *
     * @param context    context for mob spawn settings
     * @param entityType the entity type to configure spawning for
     * @return the builder
     */
    public static SpawnerDataBuilder create(MobSpawnSettingsContext context, class_1299<?> entityType) {
        return new SpawnerDataBuilder(context, entityType);
    }

    /**
     * @param weight spawn weight for the entity
     * @return the builder
     */
    public SpawnerDataBuilder setWeight(int weight) {
        return this.setWeight((int oldWeight) -> weight);
    }

    /**
     * @param weight fractional spawn weight for the entity
     * @return the builder
     */
    public SpawnerDataBuilder setWeight(Fraction weight) {
        Objects.requireNonNull(weight, "weight is null");
        return this.setWeight((int oldWeight) -> weight.multiplyBy(Fraction.getFraction(oldWeight, 1)).intValue());
    }

    /**
     * @param weight custom weight mapping function
     * @return the builder
     */
    public SpawnerDataBuilder setWeight(IntUnaryOperator weight) {
        Objects.requireNonNull(weight, "weight is null");
        this.weightMapper = (int oldWeight) -> Math.max(1, weight.applyAsInt(oldWeight));
        return this;
    }

    /**
     * @param minCount minimum spawn count
     * @return the builder
     */
    public SpawnerDataBuilder setMinCount(int minCount) {
        return this.setMinCount((class_5483.class_1964 spawnerData) -> minCount);
    }

    /**
     * @param minCount fractional minimum spawn count
     * @return the builder
     */
    public SpawnerDataBuilder setMinCount(Fraction minCount) {
        Objects.requireNonNull(minCount, "min count is null");
        return this.setMinCount((class_5483.class_1964 spawnerData) -> minCount.multiplyBy(Fraction.getFraction(
                spawnerData.field_9388,
                1)).intValue());
    }

    /**
     * @param minCount custom minimum count mapping function
     * @return the builder
     */
    public SpawnerDataBuilder setMinCount(ToIntFunction<class_5483.class_1964> minCount) {
        Objects.requireNonNull(minCount, "min count is null");
        this.minCountMapper = (class_5483.class_1964 spawnerData) -> Math.max(1,
                minCount.applyAsInt(spawnerData));
        return this;
    }

    /**
     * @param maxCount maximum spawn count
     * @return the builder
     */
    public SpawnerDataBuilder setMaxCount(int maxCount) {
        return this.setMaxCount((class_5483.class_1964 spawnerData) -> maxCount);
    }

    /**
     * @param maxCount fractional maximum spawn count
     * @return the builder
     */
    public SpawnerDataBuilder setMaxCount(Fraction maxCount) {
        Objects.requireNonNull(maxCount, "max count is null");
        return this.setMaxCount((class_5483.class_1964 spawnerData) -> maxCount.multiplyBy(Fraction.getFraction(
                spawnerData.field_9387,
                1)).intValue());
    }

    /**
     * @param maxCount custom maximum count mapping function
     * @return the builder
     */
    public SpawnerDataBuilder setMaxCount(ToIntFunction<class_5483.class_1964> maxCount) {
        Objects.requireNonNull(maxCount, "max count is null");
        this.maxCountMapper = (class_5483.class_1964 spawnerData) -> Math.max(1,
                maxCount.applyAsInt(spawnerData));
        return this;
    }

    /**
     * Applies spawner data to the specified entity type.
     *
     * @param entityType the entity type to apply spawner data to
     */
    public void apply(class_1299<?> entityType) {
        for (class_1311 category : this.context.getMobCategoriesWithSpawns()) {
            this.getSpawnerDataForType(this.context, category, this.entityType)
                    .ifPresent((class_5483.class_1964 data) -> {
                        int weight = this.weightMapper.applyAsInt(data.method_34979().method_34976());
                        int minCount = this.minCountMapper.applyAsInt(data);
                        int maxCount = this.maxCountMapper.applyAsInt(data);
                        this.context.addSpawn(category,
                                new class_5483.class_1964(entityType,
                                        weight,
                                        Math.min(minCount, maxCount),
                                        maxCount));
                    });
            class_5483.class_5265 cost = this.context.getSpawnCost(entityType);
            if (cost != null) {
                // Just add this with the same values as the vanilla mob.
                // The spawn data weight is what matters most.
                this.context.setSpawnCost(entityType, cost.comp_1307(), cost.comp_1308());
            }
        }
    }

    private Optional<class_5483.class_1964> getSpawnerDataForType(MobSpawnSettingsContext context, class_1311 mobCategory, class_1299<?> entityType) {
        return context.getSpawnerData(mobCategory)
                .stream()
                .filter((class_5483.class_1964 data) -> data.field_9389 == entityType)
                .findAny();
    }
}
