package fuzs.puzzleslib.fabric.impl.core;

import fuzs.puzzleslib.api.capability.v3.CapabilityController;
import fuzs.puzzleslib.fabric.impl.capability.FabricCapabilityController;
import fuzs.puzzleslib.fabric.impl.config.FabricConfigHolderImpl;
import fuzs.puzzleslib.fabric.impl.init.FabricRegistryManager;
import fuzs.puzzleslib.fabric.impl.network.FabricNetworkHandler;
import fuzs.puzzleslib.impl.config.ConfigHolderImpl;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.init.RegistryManagerImpl;
import fuzs.puzzleslib.impl.network.NetworkHandlerRegistryImpl;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_634;
import net.minecraft.class_8709;
import net.minecraft.class_8710;
import java.util.Objects;

public final class FabricModContext extends ModContext {

    public FabricModContext(String modId) {
        super(modId);
    }

    @Override
    protected void setupHandshakePayload(String modId, class_8710.class_9154<class_8709> payloadType) {
        PayloadTypeRegistry.playC2S().register(payloadType, class_8709.field_48654);
        PayloadTypeRegistry.playS2C().register(payloadType, class_8709.field_48654);
        FabricProxy.get().setupHandshakePayload(payloadType);
    }

    @Override
    protected boolean isPresentServerside(class_8710.class_9154<class_8709> payloadType) {
        class_634 clientPacketListener = class_310.method_1551().method_1562();
        return clientPacketListener != null && ClientPlayNetworking.canSend(payloadType);
    }

    @Override
    protected boolean isPresentClientside(class_8710.class_9154<class_8709> payloadType, class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return ServerPlayNetworking.canSend(serverPlayer.field_13987, payloadType);
    }

    @Override
    protected NetworkHandlerRegistryImpl createNetworkHandler(String modId) {
        return new FabricNetworkHandler(modId);
    }

    @Override
    protected ConfigHolderImpl createConfigHolder(String modId) {
        return new FabricConfigHolderImpl(modId);
    }

    @Override
    protected RegistryManagerImpl createRegistryManager(String modId) {
        return new FabricRegistryManager(modId);
    }

    @Override
    protected CapabilityController createCapabilityController(String modId) {
        return new FabricCapabilityController(modId);
    }
}
