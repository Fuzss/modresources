package fuzs.puzzleslib.api.client.gui.v2.components;

import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4265;

/**
 * Backported from Minecraft 26.2.
 */
public abstract class UpdatedContainerObjectSelectionList<E extends class_4265.class_4266<E>> extends class_4265<E> {

    public UpdatedContainerObjectSelectionList(class_310 minecraft, int width, int height, int y, int itemHeight) {
        super(minecraft, width, height, y, itemHeight);
    }

    @Override
    protected final void method_25320(class_332 guiGraphics, int mouseX, int mouseY) {
        this.extractScrollbar(guiGraphics, mouseX, mouseY);
    }

    protected abstract void extractScrollbar(class_332 guiGraphics, int mouseX, int mouseY);

    @Override
    protected final boolean method_57717() {
        return false;
    }

    @Override
    protected final void method_25318(double mouseX, double mouseY, int button) {
        this.updateScrolling(mouseX, mouseY, button);
    }

    public boolean updateScrolling(double mouseX, double mouseY, int button) {
        this.field_22750 = this.scrollable() && this.method_25351(button) && this.isOverScrollbar(mouseX, mouseY);
        return this.field_22750;
    }

    protected boolean isOverScrollbar(double mouseX, double mouseY) {
        return mouseX >= this.method_25329() && mouseX < (this.method_25329() + 6);
    }

    @Override
    public final int method_25331() {
        return this.maxScrollAmount();
    }

    public int maxScrollAmount() {
        return Math.max(0, this.contentHeight() - this.field_22759);
    }

    protected boolean scrollable() {
        return this.maxScrollAmount() > 0;
    }

    @Override
    protected final int method_25317() {
        return this.contentHeight();
    }

    protected int contentHeight() {
        return super.method_25317() + 4;
    }

    @Override
    protected final int method_25329() {
        return this.scrollBarX();
    }

    protected int scrollBarX() {
        return super.method_25329();
    }

    /**
     * @see net.minecraft.class_350#method_48579(class_332, int, int, float)
     */
    public int scrollBarY() {
        return this.maxScrollAmount() == 0 ? this.method_46427() : Math.max(this.method_46427(),
                (int) this.scrollAmount() * (this.field_22759 - this.scrollerHeight()) / this.maxScrollAmount()
                        + this.method_46427());
    }

    public abstract int scrollbarWidth();

    protected abstract int scrollerWidth();

    protected abstract int scrollerHeight();

    @Override
    public final double method_25341() {
        return this.scrollAmount();
    }

    public double scrollAmount() {
        return super.method_25341();
    }
}
