package fuzs.puzzleslib.api.resources.v1;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import org.slf4j.Logger;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4080;
import net.minecraft.class_5321;
import net.minecraft.class_7225;
import net.minecraft.class_7654;
import net.minecraft.class_7924;

/**
 * Copied from Minecraft 26.2.
 */
public abstract class SimpleJsonResourceReloadListener<T> extends class_4080<Map<class_2960, T>> {
    private static final Logger LOGGER = LogUtils.getLogger();
    private final DynamicOps<JsonElement> ops;
    private final Codec<T> codec;
    private final class_7654 lister;

    protected SimpleJsonResourceReloadListener(class_7225.class_7874 registries, Codec<T> codec, class_5321<? extends class_2378<T>> registryKey) {
        this(registries.method_57093(JsonOps.INSTANCE),
                codec,
                class_7654.method_45114(class_7924.method_60915(registryKey)));
    }

    protected SimpleJsonResourceReloadListener(Codec<T> codec, class_7654 lister) {
        this(JsonOps.INSTANCE, codec, lister);
    }

    private SimpleJsonResourceReloadListener(DynamicOps<JsonElement> ops, Codec<T> codec, class_7654 lister) {
        this.ops = ops;
        this.codec = codec;
        this.lister = lister;
    }

    protected Map<class_2960, T> method_18789(class_3300 manager, class_3695 profiler) {
        Map<class_2960, T> result = new HashMap();
        scanDirectory(manager, this.lister, this.ops, this.codec, result);
        return result;
    }

    public static <T> void scanDirectory(class_3300 manager, class_5321<? extends class_2378<T>> registryKey, DynamicOps<JsonElement> ops, Codec<T> codec, Map<class_2960, T> result) {
        scanDirectory(manager, class_7654.method_45114(class_7924.method_60915(registryKey)), ops, codec, result);
    }

    public static <T> void scanDirectory(class_3300 manager, class_7654 lister, DynamicOps<JsonElement> ops, Codec<T> codec, Map<class_2960, T> result) {
        for (Map.Entry<class_2960, class_3298> entry : lister.method_45113(manager).entrySet()) {
            class_2960 location = entry.getKey();
            class_2960 id = lister.method_45115(location);

            try (Reader reader = entry.getValue().method_43039()) {
                codec.parse(ops, JsonParser.parseReader(reader)).ifSuccess((parsed) -> {
                    if (result.putIfAbsent(id, parsed) != null) {
                        throw new IllegalStateException("Duplicate data file ignored with ID " + id);
                    }
                }).ifError((error) -> LOGGER.error("Couldn't parse data file '{}' from '{}': {}", id, location, error));
            } catch (IllegalArgumentException | IOException | JsonParseException e) {
                LOGGER.error("Couldn't parse data file '{}' from '{}'", id, location, e);
            }
        }
    }
}
