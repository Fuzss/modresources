package fuzs.puzzleslib.api.client.renderer.v1.model;

import com.google.gson.JsonObject;
import fuzs.puzzleslib.impl.PuzzlesLib;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_1100;
import net.minecraft.class_156;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_3518;
import net.minecraft.class_3694;
import net.minecraft.class_773;
import net.minecraft.class_7923;
import net.minecraft.class_793;
import net.minecraft.class_9824;
import net.minecraft.client.resources.model.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.io.Reader;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public final class ModelLoadingHelper {

    private ModelLoadingHelper() {
        // NO-OP
    }

    @ApiStatus.Experimental
    public static Map<class_2680, class_1100> loadBlockState(class_3300 resourceManager, class_2248 block) {
        return loadBlockState(resourceManager, block, class_156.method_18349()).join();
    }

    public static CompletableFuture<Map<class_2680, class_1100>> loadBlockState(class_3300 resourceManager, class_2248 block, Executor executor) {
        return loadBlockState(resourceManager,
                class_7923.field_41175.method_10221(block),
                block.method_9595(),
                executor);
    }

    @ApiStatus.Experimental
    public static Map<class_2680, class_1100> loadBlockState(class_3300 resourceManager, class_2960 blockId, class_2689<class_2248, class_2680> stateDefinition) {
        return loadBlockState(resourceManager, blockId, stateDefinition, class_156.method_18349()).join();
    }

    public static CompletableFuture<Map<class_2680, class_1100>> loadBlockState(class_3300 resourceManager, class_2960 blockId, class_2689<class_2248, class_2680> stateDefinition, Executor executor) {
        return loadBlockState(resourceManager, blockId, blockId, stateDefinition, executor);
    }

    public static CompletableFuture<Map<class_2680, class_1100>> loadBlockState(class_3300 resourceManager, class_2960 sourceBlockId, class_2960 blockId, class_2689<class_2248, class_2680> stateDefinition, Executor executor) {
        return loadBlockState(resourceManager,
                sourceBlockId,
                executor).thenCompose((List<class_9824.class_7777> loadedBlockModelDefinitions) -> {
            return loadBlockState(loadedBlockModelDefinitions, blockId, stateDefinition, executor);
        });
    }

    /**
     * @see class_1092#method_45896(class_3300, Executor)
     */
    public static CompletableFuture<List<class_9824.class_7777>> loadBlockState(class_3300 resourceManager, class_2960 blockId, Executor executor) {
        return CompletableFuture.supplyAsync(() -> resourceManager.method_14489(class_9824.field_52260.method_45112(
                blockId)), executor).thenApply((List<class_3298> resourceStack) -> {
            List<class_9824.class_7777> blockModelDefinitions = new ArrayList<>(resourceStack.size());

            for (class_3298 resource : resourceStack) {
                try (Reader reader = resource.method_43039()) {
                    JsonObject jsonObject = class_3518.method_15255(reader);
                    blockModelDefinitions.add(new class_9824.class_7777(resource.method_14480(),
                            jsonObject));
                } catch (Exception exception) {
                    PuzzlesLib.LOGGER.error("Failed to load blockstate definition {} from pack {}",
                            blockId,
                            resource.method_14480(),
                            exception);
                }
            }

            return blockModelDefinitions;
        });
    }

    /**
     * @see class_9824#method_61053(class_2960, class_2689)
     */
    public static CompletableFuture<Map<class_2680, class_1100>> loadBlockState(List<class_9824.class_7777> loadedBlockModelDefinitions, class_2960 blockId, class_2689<class_2248, class_2680> stateDefinition, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                Map<class_2960, List<class_9824.class_7777>> blockStateResources = Collections.singletonMap(
                        class_9824.field_52260.method_45112(blockId),
                        loadedBlockModelDefinitions);
                Map<class_2680, class_1100> discoveredModelOutput = new HashMap<>();
                Map<class_1091, class_2680> blockStateIds = new HashMap<>();
                for (class_2680 blockState : stateDefinition.method_11662()) {
                    blockStateIds.put(class_773.method_3336(blockId, blockState), blockState);
                }

                new class_9824(blockStateResources,
                        class_3694.field_16280,
                        missingModel(),
                        class_310.method_1551().method_1505(),
                        (class_1091 modelId, class_1100 model) -> {
                            class_2680 blockState = blockStateIds.get(modelId);
                            Objects.requireNonNull(blockState, "block state is null");
                            discoveredModelOutput.put(blockState, model);
                        }).method_61053(blockId, stateDefinition);
                return discoveredModelOutput;
            } catch (Exception exception) {
                PuzzlesLib.LOGGER.error("Failed to load blockstate definition {}", blockId, exception);
                return null;
            }
        }, executor);
    }

    @ApiStatus.Experimental
    public static @Nullable class_793 loadBlockModel(class_3300 resourceManager, class_2960 modelId) {
        return loadBlockModel(resourceManager, modelId, class_156.method_18349()).join();
    }

    /**
     * @see class_1092#method_45881(class_3300, Executor)
     */
    public static CompletableFuture<@Nullable class_793> loadBlockModel(class_3300 resourceManager, class_2960 modelId, Executor executor) {
        // The model id is already processed by the call site, so it must not be passed through ModelBakery.MODEL_LISTER#idToFile again.
        return CompletableFuture.supplyAsync(() -> resourceManager.method_14486(modelId), executor)
                .thenApply((Optional<class_3298> optional) -> {
                    return optional.<class_793>map((class_3298 resource) -> {
                        try (Reader reader = resource.method_43039()) {
                            return class_793.method_3437(reader);
                        } catch (Exception exception) {
                            PuzzlesLib.LOGGER.error("Failed to load model {}", modelId, exception);
                            return null;
                        }
                    }).orElse(null);
                });
    }

    /**
     * @see class_1088#method_4718(class_2960)
     */
    public static class_1100 missingModel() {
        class_793 model = class_793.method_3430(class_1088.field_5371);
        model.field_4252 = class_1088.field_5374.toString();
        return model;
    }
}
