package fuzs.puzzleslib.api.client.input.v1;

import net.minecraft.class_156;

/**
 * Copied from Minecraft 26.2.
 */
public class InputQuirks {
    private static final boolean ON_OSX = class_156.method_668() == class_156.class_158.field_1137;
    public static final boolean REPLACE_CTRL_KEY_WITH_CMD_KEY = ON_OSX;
    public static final int EDIT_SHORTCUT_KEY_MODIFIER = REPLACE_CTRL_KEY_WITH_CMD_KEY ? 8 : 2;
    public static final boolean SIMULATE_RIGHT_CLICK_WITH_LONG_LEFT_CLICK = ON_OSX;
    public static final boolean RESTORE_KEY_STATE_AFTER_MOUSE_GRAB = !ON_OSX;
}
