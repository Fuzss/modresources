package fuzs.puzzleslib.api.client.gui.v2;

import fuzs.puzzleslib.impl.client.gui.SingleTextureAtlasSprite;
import net.minecraft.class_1058;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4597;
import net.minecraft.class_5481;
import net.minecraft.class_8658;
import net.minecraft.class_8690;
import org.joml.Matrix4f;

/**
 * A helper class for extending the functionality of {@link class_332}. Especially useful for drawing
 * {@link class_1058 TextureAtlasSprites} with a different {@link class_8690} than is defined by the
 * resource pack.
 */
public final class GuiGraphicsHelper {

    private GuiGraphicsHelper() {
        // NO-OP
    }

    /**
     * Draws a string with a background, similar to the experience level on the gui.
     *
     * @param guiGraphics     the gui graphics instance
     * @param font            the font instance
     * @param component       the component to draw
     * @param posX            the x-position
     * @param posY            the y-position
     * @param color           the text color
     * @param backgroundColor the background text color
     * @see class_332#method_27535(class_327, class_2561, int, int, int)
     * @see class_327#method_37296(class_5481, float, float, int, int, Matrix4f, class_4597,
     *         int)
     */
    public static void prepare8xTextOutline(class_332 guiGraphics, class_327 font, class_2561 component, int posX, int posY, int color, int backgroundColor) {
        for (int i = -1; i <= 1; i++) {
            for (int j = -1; j <= 1; j++) {
                if (i != 0 || j != 0) {
                    guiGraphics.method_51439(font, component, posX + i, posY + j, backgroundColor, false);
                }
            }
        }

        guiGraphics.method_51439(font, component, posX, posY, color, false);
    }

    /**
     * Draws a rectangular border frame, the inside of the shape is left untouched.
     *
     * @param guiGraphics the gui graphics instance
     * @param posX        the x-position
     * @param posY        the y-position
     * @param width       the rectangle width
     * @param height      the rectangle height
     * @param borderSize  the width of the border on all sides, goes inwards
     * @param color       the color to fill with
     */
    public static void fillFrame(class_332 guiGraphics, int posX, int posY, int width, int height, int borderSize, int color) {
        fillFrameArea(guiGraphics, posX, posY, posX + width, posY + height, borderSize, color);
    }

    /**
     * Draws a rectangular border frame, the inside of the shape is left untouched.
     *
     * @param guiGraphics the gui graphics instance
     * @param minX        the start x-position
     * @param minY        the start y-position
     * @param maxX        the end x-position
     * @param maxY        the end y-position
     * @param borderSize  the width of the border on all sides, goes inwards
     * @param color       the color to fill with
     */
    public static void fillFrameArea(class_332 guiGraphics, int minX, int minY, int maxX, int maxY, int borderSize, int color) {
        // top
        guiGraphics.method_25294(minX, minY, maxX, minY + borderSize, color);
        // bottom
        guiGraphics.method_25294(minX, maxY - borderSize, maxX, maxY, color);
        // left
        guiGraphics.method_25294(minX, minY + borderSize, minX + borderSize, maxY - borderSize, color);
        // right
        guiGraphics.method_25294(maxX - borderSize, minY + borderSize, maxX, maxY - borderSize, color);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param identifier   the texture sheet identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderSize   the border width &amp; height on the sides of the sprite, for drawing the frame
     * @param spriteWidth  the sprite texture width
     * @param spriteHeight the sprite texture height
     * @param uOffset      the sprite u-offset on the texture sheet
     * @param vOffset      the sprite v-offset on the texture sheet
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 identifier, int x, int y, int width, int height, int borderSize, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        blitNineSliced(guiGraphics,
                identifier,
                x,
                y,
                width,
                height,
                borderSize,
                borderSize,
                spriteWidth,
                spriteHeight,
                uOffset,
                vOffset);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param identifier   the texture sheet identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderWidth  the border width on the sides of the sprite, for drawing the frame
     * @param borderHeight the border height on the sides of the sprite, for drawing the frame
     * @param spriteWidth  the sprite texture width
     * @param spriteHeight the sprite texture height
     * @param uOffset      the sprite u-offset on the texture sheet
     * @param vOffset      the sprite v-offset on the texture sheet
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 identifier, int x, int y, int width, int height, int borderWidth, int borderHeight, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        blitNineSliced(guiGraphics,
                identifier,
                x,
                y,
                width,
                height,
                borderWidth,
                borderHeight,
                borderWidth,
                borderHeight,
                spriteWidth,
                spriteHeight,
                uOffset,
                vOffset);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param identifier   the texture sheet identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderLeft   the border width on the left side of the sprite, for drawing the frame
     * @param borderTop    the border height on the top side of the sprite, for drawing the frame
     * @param borderRight  the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth  the sprite texture width
     * @param spriteHeight the sprite texture height
     * @param uOffset      the sprite u-offset on the texture sheet
     * @param vOffset      the sprite v-offset on the texture sheet
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 identifier, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        blitNineSliced(guiGraphics,
                identifier,
                x,
                y,
                width,
                height,
                borderLeft,
                borderTop,
                borderRight,
                borderBottom,
                spriteWidth,
                spriteHeight,
                uOffset,
                vOffset,
                -1);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param identifier   the texture sheet identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderLeft   the border width on the left side of the sprite, for drawing the frame
     * @param borderTop    the border height on the top side of the sprite, for drawing the frame
     * @param borderRight  the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth  the sprite texture width
     * @param spriteHeight the sprite texture height
     * @param uOffset      the sprite u-offset on the texture sheet
     * @param vOffset      the sprite v-offset on the texture sheet
     * @param color        the vertex color, usually {@code -1}
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 identifier, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int color) {
        blitNineSliced(guiGraphics,
                identifier,
                x,
                y,
                width,
                height,
                borderLeft,
                borderTop,
                borderRight,
                borderBottom,
                spriteWidth,
                spriteHeight,
                uOffset,
                vOffset,
                256,
                256,
                color);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics   the gui graphics instance
     * @param identifier    the texture sheet identifier
     * @param x             the x-position on the screen
     * @param y             the y-position on the screen
     * @param width         the width to draw
     * @param height        the height to draw
     * @param borderLeft    the border width on the left side of the sprite, for drawing the frame
     * @param borderTop     the border height on the top side of the sprite, for drawing the frame
     * @param borderRight   the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom  the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth   the sprite texture width
     * @param spriteHeight  the sprite texture height
     * @param uOffset       the sprite u-offset on the texture sheet
     * @param vOffset       the sprite v-offset on the texture sheet
     * @param textureWidth  the texture sheet width
     * @param textureHeight the texture sheet height
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 identifier, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int textureWidth, int textureHeight) {
        blitNineSliced(guiGraphics,
                identifier,
                x,
                y,
                width,
                height,
                borderLeft,
                borderTop,
                borderRight,
                borderBottom,
                spriteWidth,
                spriteHeight,
                uOffset,
                vOffset,
                textureWidth,
                textureHeight,
                -1);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics   the gui graphics instance
     * @param identifier    the texture sheet identifier
     * @param x             the x-position on the screen
     * @param y             the y-position on the screen
     * @param width         the width to draw
     * @param height        the height to draw
     * @param borderLeft    the border width on the left side of the sprite, for drawing the frame
     * @param borderTop     the border height on the top side of the sprite, for drawing the frame
     * @param borderRight   the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom  the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth   the sprite texture width
     * @param spriteHeight  the sprite texture height
     * @param uOffset       the sprite u-offset on the texture sheet
     * @param vOffset       the sprite v-offset on the texture sheet
     * @param textureWidth  the texture sheet width
     * @param textureHeight the texture sheet height
     * @param color         the vertex color, usually {@code -1}
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 identifier, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int textureWidth, int textureHeight, int color) {
        SingleTextureAtlasSprite textureAtlasSprite = new SingleTextureAtlasSprite(identifier,
                spriteWidth,
                spriteHeight,
                uOffset,
                vOffset,
                textureWidth,
                textureHeight);
        class_8690.class_8691 nineSlice = new class_8690.class_8691(spriteWidth,
                spriteHeight,
                new class_8690.class_8691.class_8692(borderLeft, borderTop, borderRight, borderBottom));
        guiGraphics.method_52713(textureAtlasSprite, nineSlice, x, y, 0, width, height);
    }

    /**
     * Allows for manually drawing any sprite using nine-sliced mode.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics the gui graphics instance
     * @param sprite      the sprite identifier
     * @param x           the x-position on the screen
     * @param y           the y-position on the screen
     * @param width       the width to draw
     * @param height      the height to draw
     * @param borderSize  the border width &amp; height on the sides of the sprite, for drawing the frame
     */
    public static void blitNineSlicedSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int borderSize) {
        blitNineSlicedSprite(guiGraphics,
                sprite,
                x,
                y,
                width,
                height,
                borderSize,
                borderSize,
                borderSize,
                borderSize,
                -1);
    }

    /**
     * Allows for manually drawing any sprite using nine-sliced mode.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderLeft   the border width on the left side of the sprite, for drawing the frame
     * @param borderTop    the border height on the top side of the sprite, for drawing the frame
     * @param borderRight  the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom the border height on the bottom side of the sprite, for drawing the frame
     */
    public static void blitNineSlicedSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom) {
        blitNineSlicedSprite(guiGraphics,
                sprite,
                x,
                y,
                width,
                height,
                borderLeft,
                borderTop,
                borderRight,
                borderBottom,
                -1);
    }

    /**
     * Allows for manually drawing any sprite using nine-sliced mode.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderLeft   the border width on the left side of the sprite, for drawing the frame
     * @param borderTop    the border height on the top side of the sprite, for drawing the frame
     * @param borderRight  the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom the border height on the bottom side of the sprite, for drawing the frame
     * @param color        the vertex color, usually {@code -1}
     */
    public static void blitNineSlicedSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int color) {
        class_8658 guiSprites = class_310.method_1551().method_52699();
        class_1058 textureAtlasSprite = guiSprites.method_18667(sprite);
        class_8690.class_8691 nineSlice = new class_8690.class_8691(textureAtlasSprite.method_45851().method_45807(),
                textureAtlasSprite.method_45851().method_45815(),
                new class_8690.class_8691.class_8692(borderLeft, borderTop, borderRight, borderBottom));
        guiGraphics.method_52713(textureAtlasSprite, nineSlice, x, y, 0, width, height);
    }

    /**
     * Manually draws a sprite using tile mode. Width &amp; height portions outside the texture dimensions are filled by
     * repeating the original texture.
     * <p>
     * Most sprites by default use the stretch mode, which squeezes them into the provided width &amp; height.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param spriteWidth  the sprite texture file width
     * @param spriteHeight the sprite texture file height
     */
    public static void blitTiledSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int spriteWidth, int spriteHeight) {
        blitTiledSprite(guiGraphics, sprite, x, y, width, height, spriteWidth, spriteHeight, -1);
    }

    /**
     * Manually draws a sprite using tile mode. Width &amp; height portions outside the texture dimensions are filled by
     * repeating the original texture.
     * <p>
     * Most sprites by default use the stretch mode, which squeezes them into the provided width &amp; height.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param spriteWidth  the sprite texture file width
     * @param spriteHeight the sprite texture file height
     * @param color        the vertex color, usually {@code -1}
     */
    public static void blitTiledSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int spriteWidth, int spriteHeight, int color) {
        blitTiledSprite(guiGraphics, sprite, x, y, width, height, spriteWidth, spriteHeight, 0, 0, color);
    }

    /**
     * Manually draws a sprite using tile mode. Width &amp; height portions outside the texture dimensions are filled by
     * repeating the original texture.
     * <p>
     * Most sprites by default use the stretch mode, which squeezes them into the provided width &amp; height.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite identifier
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param spriteWidth  the sprite texture file width
     * @param spriteHeight the sprite texture file height
     * @param uOffset      the sprite u-offset on the texture sheet
     * @param vOffset      the sprite v-offset on the texture sheet
     * @param color        the vertex color, usually {@code -1}
     */
    public static void blitTiledSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int color) {
        class_8658 guiSprites = class_310.method_1551().method_52699();
        class_1058 textureAtlasSprite = guiSprites.method_18667(sprite);
        guiGraphics.method_52712(textureAtlasSprite,
                x,
                y,
                0,
                width,
                height,
                uOffset,
                vOffset,
                spriteWidth,
                spriteHeight,
                spriteWidth,
                spriteHeight);
    }
}
