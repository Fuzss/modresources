package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.ParticleProvidersContext;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_702;
import net.minecraft.class_707;
import java.util.Objects;

public final class ParticleProvidersContextFabricImpl implements ParticleProvidersContext {

    @Override
    public <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707<T> particleProvider) {
        Objects.requireNonNull(particleType, "particle type is null");
        Objects.requireNonNull(particleProvider, "particle provider is null");
        ParticleFactoryRegistry.getInstance().register(particleType, particleProvider);
    }

    @Override
    public <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707.class_8187<T> particleProvider) {
        Objects.requireNonNull(particleType, "particle type is null");
        Objects.requireNonNull(particleProvider, "particle provider is null");
        this.registerParticleProvider(particleType, (class_4002 spriteSet) -> {
            return (T particleOptions, class_638 clientLevel, double x, double y, double z, double xd, double yd, double zd) -> {
                class_4003 particle = particleProvider.createParticle(particleOptions,
                        clientLevel,
                        x,
                        y,
                        z,
                        xd,
                        yd,
                        zd);
                if (particle != null) {
                    particle.method_18140(spriteSet);
                }

                return particle;
            };
        });
    }

    @Override
    public <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_702.class_4091<T> particleFactory) {
        Objects.requireNonNull(particleType, "particle type is null");
        Objects.requireNonNull(particleFactory, "particle provider factory is null");
        ParticleFactoryRegistry.getInstance().register(particleType, particleFactory::create);
    }
}
