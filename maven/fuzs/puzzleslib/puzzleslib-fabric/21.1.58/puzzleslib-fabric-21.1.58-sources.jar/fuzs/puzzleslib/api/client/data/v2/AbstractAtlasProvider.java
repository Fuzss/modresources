package fuzs.puzzleslib.api.client.data.v2;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.data.v2.models.MaterialMapper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.UnaryOperator;
import net.minecraft.class_1092;
import net.minecraft.class_1741;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_4915;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7948;
import net.minecraft.class_7952;
import net.minecraft.class_7954;
import net.minecraft.class_7955;
import net.minecraft.class_8056;
import net.minecraft.class_8057;
import net.minecraft.class_8066;

public abstract class AbstractAtlasProvider implements class_2405 {
    /**
     * Copied from Minecraft 26.2.
     */
    public static final class_2960 TRIM_PALETTE_KEY = class_2960.method_60656(
            "trims/color_palettes/trim_palette");
    /**
     * Copied from Minecraft 26.2.
     */
    public static final List<class_5321<class_8056>> VANILLA_PATTERNS = List.of(class_8057.field_42016,
            class_8057.field_42017,
            class_8057.field_42018,
            class_8057.field_42019,
            class_8057.field_42020,
            class_8057.field_42021,
            class_8057.field_42022,
            class_8057.field_42023,
            class_8057.field_42024,
            class_8057.field_42025,
            class_8057.field_42026,
            class_8057.field_43221,
            class_8057.field_43222,
            class_8057.field_43223,
            class_8057.field_43224,
            class_8057.field_43225,
            class_8057.field_49827,
            class_8057.field_49828);

    private final Map<class_2960, List<class_7948>> values = new LinkedHashMap<>();
    private final class_7784.class_7489 pathProvider;

    public AbstractAtlasProvider(DataProviderContext context) {
        this(context.getPackOutput());
    }

    public AbstractAtlasProvider(class_7784 packOutput) {
        this.pathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "atlases");
    }

    public static class_7948 forMaterial(class_4730 material) {
        return new class_7955(material.method_24147(), Optional.empty());
    }

    public static class_7948 forMapper(MaterialMapper mapper) {
        return new class_7954(mapper.prefix(), mapper.prefix() + "/");
    }

    public static List<class_7948> simpleMapper(MaterialMapper mapper) {
        return List.of(forMapper(mapper));
    }

    public static List<class_7948> noPrefixMapper(String path) {
        return List.of(new class_7954(path, ""));
    }

    public static TrimPatternBuilder armorTrims() {
        return new TrimPatternBuilder();
    }

    public static TrimPatternBuilder armorTrimPatterns() {
        return armorTrims().addVanillaLayers().addVanillaPermutations();
    }

    public static TrimPatternBuilder armorTrimPermutations() {
        return armorTrims().addVanillaPatterns().addVanillaLayers();
    }

    @Override
    public final CompletableFuture<?> method_10319(class_7403 output) {
        this.addAtlases();
        return CompletableFuture.allOf(this.values.entrySet()
                .stream()
                .map((Map.Entry<class_2960, List<class_7948>> entry) -> {
                    return this.storeAtlas(output, entry.getKey(), entry.getValue());
                })
                .toArray(CompletableFuture[]::new));
    }

    public final CompletableFuture<?> storeAtlas(class_7403 output, class_2960 atlasId, List<class_7948> sources) {
        return class_2405.method_53496(output,
                class_5455.field_40585,
                class_7952.field_41397,
                sources,
                this.pathProvider.method_44107(atlasId));
    }

    public abstract void addAtlases();

    protected void addMaterial(class_4730 material) {
        this.add(class_1092.field_40574.get(material.method_24144()), forMaterial(material));
    }

    protected void add(class_2960 id, class_7948... spriteSources) {
        this.add(id, Arrays.asList(spriteSources));
    }

    protected void add(class_2960 id, List<class_7948> spriteSources) {
        this.values.computeIfAbsent(id, (class_2960 location) -> new ArrayList<>()).addAll(spriteSources);
    }

    @Override
    public String method_10321() {
        return "Atlas Definitions";
    }

    public static class TrimPatternBuilder {
        private final List<class_5321<class_8056>> patterns = new ArrayList<>();
        private final List<UnaryOperator<String>> layers = new ArrayList<>();
        private final Map<String, class_2960> permutations = new TreeMap<>();
        private class_2960 palette = TRIM_PALETTE_KEY;
        private @Nullable String namespaceOverride;

        TrimPatternBuilder() {
            // NO-OP
        }

        public TrimPatternBuilder addPattern(class_5321<class_8056> pattern) {
            this.patterns.add(pattern);
            return this;
        }

        public TrimPatternBuilder addPatterns(List<class_5321<class_8056>> patterns) {
            this.patterns.addAll(patterns);
            return this;
        }

        public TrimPatternBuilder addVanillaPatterns() {
            return this.addPatterns(VANILLA_PATTERNS);
        }

        public TrimPatternBuilder addLayer(UnaryOperator<String> layer) {
            this.layers.add(layer);
            return this;
        }

        public TrimPatternBuilder addLayers(List<UnaryOperator<String>> layers) {
            this.layers.addAll(layers);
            return this;
        }

        public TrimPatternBuilder addVanillaLayers() {
            return this.addLayer((String name) -> "trims/models/armor/" + name)
                    .addLayer((String name) -> "trims/models/armor/" + name + "_leggings");
        }

        public TrimPatternBuilder addPermutation(class_4915.class_8072 data) {
            data.comp_1239().values().forEach(this::addPermutation);
            return this.addPermutation(data.comp_1219());
        }

        public TrimPatternBuilder addPermutations(List<class_4915.class_8072> data) {
            data.forEach(this::addPermutation);
            return this;
        }

        public TrimPatternBuilder addPermutation(String asset) {
            Objects.requireNonNull(this.namespaceOverride, "namespace is null");
            return this.addPermutation(class_2960.method_60655(this.namespaceOverride, asset));
        }

        public TrimPatternBuilder addPermutation(class_2960 base, Map<class_6880<class_1741>, class_2960> overrides) {
            overrides.values().forEach(this::addPermutation);
            return this.addPermutation(base);
        }

        public TrimPatternBuilder addPermutation(class_2960 asset) {
            this.permutations.put(asset.method_12832(), asset.method_45138("trims/color_palettes/"));
            return this;
        }

        public TrimPatternBuilder addPermutation(String suffix, class_2960 palette) {
            this.permutations.put(suffix, palette);
            return this;
        }

        public TrimPatternBuilder addPermutations(Map<String, class_2960> permutations) {
            this.permutations.putAll(permutations);
            return this;
        }

        public TrimPatternBuilder addVanillaPermutations() {
            return this.setNamespaceOverride(class_2960.field_33381)
                    .addPermutations(class_4915.field_42087)
                    .setNamespaceOverride(null);
        }

        public TrimPatternBuilder setPalette(class_2960 palette) {
            Objects.requireNonNull(palette, "palette is null");
            this.palette = palette;
            return this;
        }

        public TrimPatternBuilder setNamespaceOverride(@Nullable String namespaceOverride) {
            this.namespaceOverride = namespaceOverride;
            return this;
        }

        public List<class_7948> build() {
            Preconditions.checkArgument(!this.patterns.isEmpty(), "patterns is empty");
            Preconditions.checkArgument(!this.layers.isEmpty(), "layers is empty");
            Preconditions.checkArgument(!this.permutations.isEmpty(), "permutations is empty");
            List<class_2960> textures = patternTextures(this.patterns, this.layers);
            return List.of(new class_8066(textures, this.palette, this.permutations));
        }

        private static List<class_2960> patternTextures(List<class_5321<class_8056>> patterns, List<UnaryOperator<String>> layers) {
            List<class_2960> result = new ArrayList<>(patterns.size() * layers.size());
            for (class_5321<class_8056> vanillaPattern : patterns) {
                class_2960 assetId = vanillaPattern.method_29177();
                for (UnaryOperator<String> humanoidLayer : layers) {
                    result.add(assetId.method_45134(humanoidLayer));
                }
            }

            return result;
        }
    }
}
