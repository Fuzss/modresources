package fuzs.puzzleslib.api.client.core.v1;

import fuzs.puzzleslib.api.client.core.v1.context.*;
import fuzs.puzzleslib.api.core.v1.BaseModConstructor;
import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import fuzs.puzzleslib.impl.core.context.ModConstructorImpl;
import java.util.function.Supplier;
import net.minecraft.class_1100;
import net.minecraft.class_1792;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_322;
import net.minecraft.class_326;
import net.minecraft.class_3611;
import net.minecraft.class_3887;
import net.minecraft.class_5601;

/**
 * A base class for a mods main client class, contains a bunch of methods for registering various client content and
 * components.
 */
public interface ClientModConstructor extends BaseModConstructor {

    /**
     * Construct the {@link ClientModConstructor} instance to begin client-side initialization of a mod.
     *
     * @param modId                  the mod id
     * @param modConstructorSupplier the mod instance for the setup
     */
    static void construct(String modId, Supplier<ClientModConstructor> modConstructorSupplier) {
        construct(class_2960.method_60655(modId, "client"), modConstructorSupplier);
    }

    /**
     * Construct the {@link ClientModConstructor} instance to begin client-side initialization of a mod.
     *
     * @param resourceLocation       the identifier for the provided mod instance
     * @param modConstructorSupplier the mod instance for the setup
     */
    static void construct(class_2960 resourceLocation, Supplier<ClientModConstructor> modConstructorSupplier) {
        ModConstructorImpl.construct(resourceLocation,
                modConstructorSupplier,
                ClientProxyImpl.get()::getClientModConstructorImpl);
    }

    /**
     * Runs when the mod is first constructed, on the client only really used for registering event callbacks.
     */
    default void onConstructMod() {
        // NO-OP
    }

    /**
     * Runs after content has been registered, so it's safe to use here.
     * <p>
     * Used to set various values and settings for already registered content.
     */
    default void onClientSetup() {
        // NO-OP
    }

    /**
     * @param context add a renderer to an entity
     */
    default void onRegisterEntityRenderers(EntityRenderersContext context) {
        // NO-OP
    }

    /**
     * @param context add a renderer to a block entity
     */
    default void onRegisterBlockEntityRenderers(BlockEntityRenderersContext context) {
        // NO-OP
    }

    /**
     * @param context add a client tooltip component to a common tooltip component
     */
    default void onRegisterClientTooltipComponents(ClientTooltipComponentsContext context) {
        // NO-OP
    }

    /**
     * @param context add particle providers for a particle type
     */
    default void onRegisterParticleProviders(ParticleProvidersContext context) {
        // NO-OP
    }

    /**
     * @param context register a screen for a menu type
     */
    default void onRegisterMenuScreens(MenuScreensContext context) {
        // NO-OP
    }

    /**
     * @param context add a layer definition for a {@link class_5601}
     */
    default void onRegisterLayerDefinitions(LayerDefinitionsContext context) {
        // NO-OP
    }

    /**
     * @param context register a resolver responsible for mapping each {@link class_2680} of a block to an
     *                {@link class_1100}
     */
    default void onRegisterBlockStateResolver(BlockStateResolverContext context) {
        // NO-OP
    }

    /**
     * @param context add external models to be loaded
     */
    default void onRegisterAdditionalModels(AdditionalModelsContext context) {
        // NO-OP
    }

    /**
     * @param context register model predicates for custom item models
     */
    default void onRegisterItemModelProperties(ItemModelPropertiesContext context) {
        // NO-OP
    }

    /**
     * @param context register a custom inventory renderer for an item belonging to a block entity
     */
    default void onRegisterBuiltinModelItemRenderers(BuiltinModelItemRendererContext context) {
        // NO-OP
    }

    /**
     * @param context register additional renders to run after stack count and durability have been drawn for an item
     *                stack
     */
    default void onRegisterItemDecorations(ItemDecorationContext context) {
        // NO-OP
    }

    /**
     * @param context register a custom shader that is applied when spectating a certain entity type
     */
    default void onRegisterEntitySpectatorShaders(EntitySpectatorShaderContext context) {
        // NO-OP
    }

    /**
     * @param context register models for custom {@link net.minecraft.class_2484.class_2485}
     *                implementations
     */
    default void onRegisterSkullRenderers(SkullRenderersContext context) {
        // NO-OP
    }

    /**
     * @param context register additional {@link class_3887}s for a living entity
     */
    @Deprecated
    default void onRegisterLivingEntityRenderLayers(LivingEntityRenderLayersContext context) {
        // NO-OP
    }

    /**
     * @param context register a {@link class_304} so it can be saved to and loaded from game options
     */
    default void onRegisterKeyMappings(KeyMappingsContext context) {
        // NO-OP
    }

    /**
     * @param context register custom {@link class_1921}s for blocks
     */
    default void onRegisterBlockRenderTypes(RenderTypesContext<class_2248> context) {
        // NO-OP
    }

    /**
     * @param context register custom {@link class_1921}s for fluids
     */
    default void onRegisterFluidRenderTypes(RenderTypesContext<class_3611> context) {
        // NO-OP
    }

    /**
     * @param context register custom block color providers
     */
    default void onRegisterBlockColorProviders(ColorProvidersContext<class_2248, class_322> context) {
        // NO-OP
    }

    /**
     * @param context register custom item color providers
     */
    default void onRegisterItemColorProviders(ColorProvidersContext<class_1792, class_326> context) {
        // NO-OP
    }

    /**
     * @param context register additional resource pack sources
     */
    default void onAddResourcePackFinders(PackRepositorySourcesContext context) {
        // NO-OP
    }

    /**
     * @param context register new resource pack provided shaders
     */
    default void onRegisterCoreShaders(CoreShadersContext context) {
        // NO-OP
    }

    /**
     * @param context register new render buffers to {@link net.minecraft.class_4599}
     */
    default void onRegisterRenderBuffers(RenderBuffersContext context) {
        // NO-OP
    }
}
