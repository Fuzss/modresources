package fuzs.puzzleslib.api.client.input.v1;

import net.minecraft.class_3544;

/**
 * Copied from Minecraft 26.2.
 */
public record CharacterEvent(int codepoint) {
    public String codepointAsString() {
        return Character.toString(this.codepoint);
    }

    public boolean isAllowedChatCharacter() {
        return class_3544.method_57175((char) this.codepoint);
    }
}
