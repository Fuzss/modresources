package fuzs.puzzleslib.api.data.v3;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.nio.file.Path;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;

/**
 * Copied from Minecraft 26.2.
 */
public interface DataProvider {
    static <T> CompletableFuture<?> saveAll(class_7403 cache, Codec<T> codec, class_7784.class_7489 pathProvider, Map<class_2960, T> entries) {
        Objects.requireNonNull(pathProvider);
        return saveAll(cache, codec, pathProvider::method_44107, entries);
    }

    static <T, E> CompletableFuture<?> saveAll(class_7403 cache, Codec<E> codec, Function<T, Path> pathGetter, Map<T, E> contents) {
        return saveAll(cache, (E e) -> codec.encodeStart(JsonOps.INSTANCE, e).getOrThrow(), pathGetter, contents);
    }

    static <T, E> CompletableFuture<?> saveAll(class_7403 cache, Function<E, JsonElement> serializer, Function<T, Path> pathGetter, Map<T, E> contents) {
        return CompletableFuture.allOf(contents.entrySet().stream().map((Map.Entry<T, E> entry) -> {
            Path path = pathGetter.apply(entry.getKey());
            JsonElement json = serializer.apply(entry.getValue());
            return net.minecraft.class_2405.method_10320(cache, json, path);
        }).toArray(CompletableFuture[]::new));
    }

    static <T> CompletableFuture<?> saveStable(class_7403 cache, class_7225.class_7874 registries, Codec<T> codec, T value, Path path) {
        class_6903<JsonElement> ops = registries.method_57093(JsonOps.INSTANCE);
        return saveStable(cache, ops, codec, value, path);
    }

    static <T> CompletableFuture<?> saveStable(class_7403 cache, Codec<T> codec, T value, Path path) {
        return saveStable(cache, JsonOps.INSTANCE, codec, value, path);
    }

    private static <T> CompletableFuture<?> saveStable(class_7403 cache, DynamicOps<JsonElement> ops, Codec<T> codec, T value, Path path) {
        JsonElement json = codec.encodeStart(ops, value).getOrThrow();
        return net.minecraft.class_2405.method_10320(cache, json, path);
    }
}
