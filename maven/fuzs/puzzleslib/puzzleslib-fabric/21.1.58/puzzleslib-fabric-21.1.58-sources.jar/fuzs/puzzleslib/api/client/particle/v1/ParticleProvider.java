package fuzs.puzzleslib.api.client.particle.v1;

import net.minecraft.class_2394;
import net.minecraft.class_4003;
import net.minecraft.class_5819;
import net.minecraft.class_638;
import net.minecraft.class_703;
import org.jetbrains.annotations.Nullable;

/**
 * Copied from Minecraft 26.2.
 */
@FunctionalInterface
public interface ParticleProvider<T extends class_2394> extends net.minecraft.class_707<T> {
    @Nullable class_703 createParticle(T options, class_638 level, double x, double y, double z, double xAux, double yAux, double zAux, class_5819 random);

    @Override
    @Nullable
    default class_703 method_3090(T options, class_638 level, double x, double y, double z, double xAux, double yAux, double zAux) {
        return this.createParticle(options, level, x, y, z, xAux, yAux, zAux, class_5819.method_43047());
    }

    @FunctionalInterface
    interface Sprite<T extends class_2394> extends net.minecraft.class_707.class_8187<T> {
        @Nullable class_4003 createParticle(T options, class_638 level, double x, double y, double z, double xAux, double yAux, double zAux, class_5819 random);

        @Override
        @Nullable
        default class_4003 createParticle(T options, class_638 level, double x, double y, double z, double xAux, double yAux, double zAux) {
            return this.createParticle(options, level, x, y, z, xAux, yAux, zAux, class_5819.method_43047());
        }
    }
}
