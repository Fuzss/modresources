package fuzs.puzzleslib.fabric.impl.client.core;

import fuzs.forgeconfigapiport.fabric.api.v5.client.ConfigScreenFactoryRegistry;
import fuzs.puzzleslib.common.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.common.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.common.api.client.renderer.v2.model.MutableBakedQuad;
import fuzs.puzzleslib.common.api.core.v1.context.PayloadTypesContext;
import fuzs.puzzleslib.common.impl.client.core.proxy.ClientProxyImpl;
import fuzs.puzzleslib.common.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import fuzs.puzzleslib.fabric.impl.client.config.FabricConfigurationScreen;
import fuzs.puzzleslib.fabric.impl.client.core.context.GuiLayersContextFabricImpl;
import fuzs.puzzleslib.fabric.impl.client.event.FabricClientEventInvokers;
import fuzs.puzzleslib.fabric.impl.client.key.FabricKeyMappingHelper;
import fuzs.puzzleslib.fabric.impl.core.FabricCommonProxy;
import fuzs.puzzleslib.fabric.impl.core.context.PayloadTypesContextFabricImpl;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.ClientTooltipComponentCallback;
import net.fabricmc.fabric.api.client.rendering.v1.FabricRenderState;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudStatusBarHeightRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipPositioner;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.multiplayer.*;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.BlockPos;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.custom.BrandPayload;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.game.ServerGamePacketListener;
import net.minecraft.resources.Identifier;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.IntFunction;

public class FabricClientProxy extends FabricCommonProxy implements ClientProxyImpl {
    private final Map<ContextKey<?>, RenderStateDataKey<?>> entityRenderStateKeys = new IdentityHashMap<>();

    @Override
    public void registerAllLoadingHandlers() {
        super.registerAllLoadingHandlers();
        FabricClientEventInvokers.registerLoadingHandlers();
    }

    @Override
    public void registerAllEventHandlers() {
        super.registerAllEventHandlers();
        FabricClientEventInvokers.registerEventHandlers();
    }

    @Override
    public boolean hasChannel(PacketListener packetListener, CustomPacketPayload.Type<?> type) {
        if (super.hasChannel(packetListener, type)) {
            return true;
        } else if (packetListener instanceof ClientConfigurationPacketListenerImpl) {
            return ClientConfigurationNetworking.canSend(type);
        } else if (packetListener instanceof ClientPacketListener) {
            return ClientPlayNetworking.canSend(type);
        } else {
            return false;
        }
    }

    @Override
    public Connection getConnection(PacketListener packetListener) {
        return packetListener instanceof ClientCommonPacketListenerImpl clientPacketListener ?
                clientPacketListener.connection : super.getConnection(packetListener);
    }

    @Override
    public PayloadTypesContext createPayloadTypesContext(String modId) {
        return new PayloadTypesContextFabricImpl.ClientImpl(modId);
    }

    @Override
    public void setupHandshakePayload(CustomPacketPayload.Type<BrandPayload> payloadType) {
        super.setupHandshakePayload(payloadType);
        ClientPlayNetworking.registerGlobalReceiver(payloadType,
                (BrandPayload payload, ClientPlayNetworking.Context context) -> {
                    // NO-OP
                });
    }

    @Override
    public boolean shouldStartDestroyBlock(BlockPos blockPos) {
        MultiPlayerGameMode gameMode = Minecraft.getInstance().gameMode;
        Objects.requireNonNull(gameMode, "game mode is null");
        return !gameMode.isDestroying() || !gameMode.sameDestroyTarget(blockPos);
    }

    @Override
    public void startClientPrediction(Level level, IntFunction<Packet<ServerGamePacketListener>> predictiveAction) {
        MultiPlayerGameMode gameMode = Minecraft.getInstance().gameMode;
        Objects.requireNonNull(gameMode, "game mode is null");
        gameMode.startPrediction((ClientLevel) level, predictiveAction::apply);
    }

    @Override
    public ModConstructorImpl<ClientModConstructor> getClientModConstructorImpl() {
        return new FabricClientModConstructor();
    }

    @Override
    public KeyMappingHelper getKeyMappingActivationHelper() {
        return new FabricKeyMappingHelper();
    }

    @Override
    public <T> @Nullable T getRenderStateData(Object state, ContextKey<T> key) {
        return ((FabricRenderState) state).getData(this.getRenderStateDataKey(key));
    }

    @Override
    public <T> void setRenderStateData(Object state, ContextKey<T> key, @Nullable T value) {
        ((FabricRenderState) state).setData(this.getRenderStateDataKey(key), value);
    }

    @SuppressWarnings("unchecked")
    private <T> RenderStateDataKey<T> getRenderStateDataKey(ContextKey<T> key) {
        return (RenderStateDataKey<T>) this.entityRenderStateKeys.computeIfAbsent(key,
                (ContextKey<?> absentKey) -> RenderStateDataKey.create(absentKey::toString));
    }

    @Override
    public boolean isKeyActiveAndMatches(KeyMapping keyMapping, KeyEvent keyEvent) {
        return keyMapping.matches(keyEvent);
    }

    @Override
    public ClientTooltipComponent createImageComponent(TooltipComponent imageComponent) {
        ClientTooltipComponent component = ClientTooltipComponentCallback.EVENT.invoker()
                .getClientComponent(imageComponent);
        return Objects.requireNonNullElseGet(component, () -> ClientTooltipComponent.create(imageComponent));
    }

    @Override
    public boolean onRenderTooltip(GuiGraphicsExtractor guiGraphics, Font font, int mouseX, int mouseY, List<ClientTooltipComponent> components, ClientTooltipPositioner positioner) {
        return FabricGuiEvents.RENDER_TOOLTIP.invoker()
                .onRenderTooltip(guiGraphics, font, mouseX, mouseY, components, positioner)
                .isInterrupt();
    }

    @Override
    public MutableBakedQuad getMutableBakedQuad(BakedQuad bakedQuad) {
        return new MutableBakedQuad(bakedQuad);
    }

    @Override
    public boolean isEffectVisibleInInventory(MobEffectInstance mobEffect) {
        return true;
    }

    @Override
    public boolean isEffectVisibleInGui(MobEffectInstance mobEffect) {
        return true;
    }

    @Override
    public void registerConfigurationScreen(String modId, String... otherModIds) {
        ConfigScreenFactoryRegistry.INSTANCE.register(modId, (String string, Screen screen) -> {
            return new FabricConfigurationScreen(string, screen, otherModIds);
        });
    }

    @Override
    public int getLeftStatusBarHeight(Identifier layerId) {
        return this.getStatusBarHeight(layerId);
    }

    @Override
    public int getRightStatusBarHeight(Identifier layerId) {
        return this.getStatusBarHeight(layerId);
    }

    private int getStatusBarHeight(Identifier layerId) {
        // Fabric now returns the top height for a layer, while NeoForge provides the bottom height.
        // We need to streamline the behavior on Fabric, as only here the height of the layer can be provided.
        Identifier updatedLayerId = GuiLayersContextFabricImpl.getVanillaGuiLayer(layerId);
        int layerHeight = HudStatusBarHeightRegistry.getElementHeight(updatedLayerId);
        int hudHeight = HudStatusBarHeightRegistry.getHeight(updatedLayerId);
        return hudHeight - layerHeight;
    }
}
