package fuzs.puzzleslib.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import fuzs.puzzleslib.api.client.renderer.v1.RenderTypeHelper;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_3611;

public final class FluidRenderTypesContextImpl implements RenderTypesContext<class_3611> {

    @Override
    public void registerRenderType(class_3611 fluid, class_1921 renderType) {
        Objects.requireNonNull(fluid, "fluid is null");
        Objects.requireNonNull(renderType, "render type is null");
        RenderTypeHelper.registerRenderType(fluid, renderType);
    }

    @Override
    public class_1921 getRenderType(class_3611 object) {
        return ClientAbstractions.INSTANCE.getRenderType(object);
    }
}
