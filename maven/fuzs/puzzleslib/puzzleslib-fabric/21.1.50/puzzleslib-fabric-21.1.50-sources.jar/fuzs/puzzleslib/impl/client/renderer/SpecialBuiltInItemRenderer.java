package fuzs.puzzleslib.impl.client.renderer;

import fuzs.puzzleslib.api.client.init.v1.ReloadingBuiltInItemRenderer;
import fuzs.puzzleslib.api.client.renderer.v1.special.SpecialModelRenderer;
import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

public class SpecialBuiltInItemRenderer<T> implements ReloadingBuiltInItemRenderer {
    private final SpecialModelRenderer.Unbaked<T> unbaked;
    private SpecialModelRenderer<T> modelRenderer;

    public SpecialBuiltInItemRenderer(SpecialModelRenderer.Unbaked<T> unbaked) {
        this.unbaked = unbaked;
    }

    @Override
    public void renderByItem(class_1799 itemStack, class_811 context, class_4587 poseStack, class_4597 bufferSource, int lightCoords, int overlayCoords) {
        Objects.requireNonNull(this.modelRenderer, "model renderer is null");
        this.modelRenderer.render(this.modelRenderer.extractArgument(itemStack),
                poseStack,
                bufferSource,
                lightCoords,
                overlayCoords,
                itemStack.method_7958());
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        this.modelRenderer = this.unbaked.bake(class_310.method_1551().method_31974());
    }
}
