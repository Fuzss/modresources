package fuzs.puzzleslib.impl.client.init;

import com.google.common.collect.ImmutableMap;
import com.mojang.datafixers.util.Pair;
import java.util.function.Function;
import net.minecraft.class_1690;
import net.minecraft.class_4595;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_630;
import net.minecraft.class_881;

/**
 * Copied from Minecraft 26.1.
 */
public class TypedBoatRenderer extends class_881 {

    public TypedBoatRenderer(class_5617.class_5618 context, class_5601 modelId, Function<class_630, class_4595<class_1690>> modelFactory) {
        super(context, false);
        this.field_27758 = ImmutableMap.of(class_1690.class_1692.field_7727, Pair.of(modelId.method_35743().method_45134((String path) -> {
            return "textures/entity/" + path + ".png";
        }), modelFactory.apply(context.method_32167(modelId))));
    }
}
