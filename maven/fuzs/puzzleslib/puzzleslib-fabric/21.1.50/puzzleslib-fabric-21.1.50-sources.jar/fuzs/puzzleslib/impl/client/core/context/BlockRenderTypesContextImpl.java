package fuzs.puzzleslib.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import fuzs.puzzleslib.api.client.renderer.v1.RenderTypeHelper;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_2248;

public final class BlockRenderTypesContextImpl implements RenderTypesContext<class_2248> {

    @Override
    public void registerRenderType(class_2248 block, class_1921 renderType) {
        Objects.requireNonNull(block, "block is null");
        Objects.requireNonNull(renderType, "render type is null");
        RenderTypeHelper.registerRenderType(block, renderType);
    }

    @Override
    public class_1921 getRenderType(class_2248 object) {
        return ClientAbstractions.INSTANCE.getRenderType(object);
    }
}
