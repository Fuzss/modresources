package fuzs.puzzleslib.impl.core.proxy;

import fuzs.puzzleslib.api.core.v1.Proxy;
import fuzs.puzzleslib.api.event.v1.LoadCompleteCallback;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.event.core.EventInvokerImpl;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1887;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_3495;
import net.minecraft.class_3908;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import net.minecraft.class_9129;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;
import java.util.function.Consumer;

public interface ProxyImpl extends SidedProxy, FactoriesProxy, NetworkingProxy, EntityProxy {

    static ProxyImpl get() {
        return (ProxyImpl) Proxy.INSTANCE;
    }

    @MustBeInvokedByOverriders
    default void registerEventHandlers() {
        LoadCompleteCallback.EVENT.register(() -> {
            ModContext.forEach(ModContext::runAfterConstruction);
            EventInvokerImpl.initialize();
        });
    }

    MinecraftServer getMinecraftServer();

    <T> void openMenu(class_1657 player, class_3908 menuProvider, T data);

    @Deprecated
    void openMenu(class_3222 serverPlayer, class_3908 menuProvider, BiConsumer<class_3222, class_9129> dataWriter);

    class_3288.class_7679 createPackInfo(class_2960 resourceLocation, class_2561 descriptionComponent, class_3281 packCompatibility, class_7699 featureFlagSet, boolean hidden);

    class_2583 getRarityStyle(class_1814 rarity);

    void onPlayerDestroyItem(class_1657 player, class_1799 originalItemStack, @Nullable class_1268 interactionHand);

    void forEachPool(class_52.class_53 lootTable, Consumer<? super class_55.class_56> lootPoolConsumer);

    float getEnchantPowerBonus(class_2680 blockState, class_1937 level, class_2338 blockPos);

    boolean canApplyAtEnchantingTable(class_6880<class_1887> enchantment, class_1799 itemStack);

    void setTagBuilderReplace(class_3495 builder, boolean isReplace);

    @Deprecated
    boolean onExplosionStart(class_1937 level, class_1927 explosion);
}
