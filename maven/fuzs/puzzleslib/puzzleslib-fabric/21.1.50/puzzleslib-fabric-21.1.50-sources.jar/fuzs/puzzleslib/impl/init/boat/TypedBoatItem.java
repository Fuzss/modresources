package fuzs.puzzleslib.impl.init.boat;

import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1749;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3218;

/**
 * Copied from Minecraft 26.1.
 */
public class TypedBoatItem extends class_1749 {
    private final class_1299<? extends class_1690> entityType;

    public TypedBoatItem(class_1299<? extends class_1690> entityType, class_1793 properties) {
        super(false, class_1690.class_1692.field_7727, properties);
        this.entityType = entityType;
    }

    @Override
    protected class_1690 method_42296(class_1937 level, class_239 hitResult, class_1799 itemStack, class_1657 player) {
        class_243 vec3 = hitResult.method_17784();
        class_1690 boat = this.entityType.method_5883(level);
        if (boat != null) {
            boat.method_30634(vec3.field_1352, vec3.field_1351, vec3.field_1350);
        }

        if (level instanceof class_3218 serverLevel) {
            class_1299.method_48009(serverLevel, itemStack, player).accept(boat);
        }

        return boat;
    }
}
