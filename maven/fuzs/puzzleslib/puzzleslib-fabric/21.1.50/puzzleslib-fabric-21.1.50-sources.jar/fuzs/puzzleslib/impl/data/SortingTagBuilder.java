package fuzs.puzzleslib.impl.data;

import java.util.Comparator;
import java.util.List;
import net.minecraft.class_3495;
import net.minecraft.class_3497;

/**
 * A {@link class_3495} that sorts its entries upon building to yield consistent results when constructed from
 * dynamically added data pack registry entries.
 */
public class SortingTagBuilder extends class_3495 {

    @Override
    public List<class_3497> method_26782() {
        // Sorting by id only is enough, as there are no duplicates allowed.
        return super.method_26782().stream().sorted(Comparator.comparing((class_3497 tagEntry) -> tagEntry.field_15584)).toList();
    }
}
