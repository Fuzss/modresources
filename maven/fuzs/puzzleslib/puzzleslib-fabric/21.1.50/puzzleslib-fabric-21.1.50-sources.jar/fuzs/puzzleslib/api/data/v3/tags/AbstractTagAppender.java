package fuzs.puzzleslib.api.data.v3.tags;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_3497;
import net.minecraft.class_5321;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_6880;

public abstract class AbstractTagAppender<T> extends class_2474.class_5124<T> {
    protected final class_3495 tagBuilder;
    @Nullable
    private final Function<T, class_5321<T>> keyExtractor;

    public AbstractTagAppender(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        super(tagBuilder);
        this.tagBuilder = tagBuilder;
        this.keyExtractor = keyExtractor;
    }

    @Deprecated
    @Override
    public AbstractTagAppender<T> method_46835(class_5321<T> key) {
        return this.addKey(key);
    }

    @Deprecated
    @Override
    public AbstractTagAppender<T> method_40565(class_5321<T>... keys) {
        return this.addKey(keys);
    }

    public AbstractTagAppender<T> add(class_2960 id) {
        this.tagBuilder.method_26784(id);
        return this;
    }

    public AbstractTagAppender<T> add(class_2960... ids) {
        for (class_2960 id : ids) {
            this.add(id);
        }

        return this;
    }

    public AbstractTagAppender<T> addKey(class_5321<? extends T> key) {
        return this.add(key.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addKey(class_5321<? extends T>... keys) {
        for (class_5321<? extends T> key : keys) {
            this.addKey(key);
        }

        return this;
    }

    public AbstractTagAppender<T> add(T value) {
        return this.addKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> add(T... values) {
        for (T value : values) {
            this.add(value);
        }

        return this;
    }

    public AbstractTagAppender<T> add(class_6880.class_6883<? extends T> holder) {
        return this.addKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> add(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.add(holder);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptional(String id) {
        return this.method_35922(class_2960.method_60654(id));
    }

    public AbstractTagAppender<T> addOptional(String... ids) {
        for (String id : ids) {
            this.addOptional(id);
        }

        return this;
    }

    public AbstractTagAppender<T> method_35922(class_2960 id) {
        this.tagBuilder.method_34891(id);
        return this;
    }

    public AbstractTagAppender<T> addOptional(class_2960... ids) {
        for (class_2960 id : ids) {
            this.add(id);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptionalKey(class_5321<? extends T> key) {
        return this.method_35922(key.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptionalKey(class_5321<? extends T>... keys) {
        for (class_5321<? extends T> key : keys) {
            this.addOptionalKey(key);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptional(T value) {
        return this.addOptionalKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptional(T... values) {
        for (T value : values) {
            this.addOptional(value);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptional(class_6880.class_6883<? extends T> holder) {
        return this.addOptionalKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptional(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.addOptional(holder);
        }

        return this;
    }

    public AbstractTagAppender<T> addTag(class_2960 id) {
        this.tagBuilder.method_26787(id);
        return this;
    }

    public AbstractTagAppender<T> addTag(class_2960... ids) {
        for (class_2960 id : ids) {
            this.addTag(id);
        }

        return this;
    }

    @Override
    public AbstractTagAppender<T> method_26792(class_6862<T> tag) {
        return this.addTag(tag.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addTag(class_6862<T>... tags) {
        for (class_6862<T> tag : tags) {
            this.method_26792(tag);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(String id) {
        return this.method_35923(class_2960.method_60654(id));
    }

    public AbstractTagAppender<T> addOptionalTag(String... ids) {
        for (String id : ids) {
            this.addOptionalTag(id);
        }

        return this;
    }

    public AbstractTagAppender<T> method_35923(class_2960 id) {
        this.tagBuilder.method_34892(id);
        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_2960... ids) {
        for (class_2960 id : ids) {
            this.method_35923(id);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_6862<T> tag) {
        return this.method_35923(tag.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptionalTag(class_6862<T>... tags) {
        for (class_6862<T> tag : tags) {
            this.addOptionalTag(tag);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> remove(class_2960 id);

    public AbstractTagAppender<T> remove(class_2960... ids) {
        for (class_2960 id : ids) {
            this.remove(id);
        }

        return this;
    }

    public AbstractTagAppender<T> removeKey(class_5321<? extends T> key) {
        return this.remove(key.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeKey(class_5321<? extends T>... keys) {
        for (class_5321<? extends T> key : keys) {
            this.removeKey(key);
        }

        return this;
    }

    public AbstractTagAppender<T> remove(T value) {
        return this.removeKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> remove(T... values) {
        for (T value : values) {
            this.remove(value);
        }

        return this;
    }

    public AbstractTagAppender<T> remove(class_6880.class_6883<? extends T> holder) {
        return this.removeKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> remove(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.remove(holder);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptional(String id) {
        return this.removeOptional(class_2960.method_60654(id));
    }

    public AbstractTagAppender<T> removeOptional(String... ids) {
        for (String id : ids) {
            this.removeOptional(id);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> removeOptional(class_2960 id);

    public AbstractTagAppender<T> removeOptional(class_2960... ids) {
        for (class_2960 id : ids) {
            this.removeOptional(id);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptionalKey(class_5321<? extends T> key) {
        return this.removeOptional(key.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptionalKey(class_5321<? extends T>... keys) {
        for (class_5321<? extends T> key : keys) {
            this.removeOptionalKey(key);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptional(T value) {
        return this.removeOptionalKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptional(T... values) {
        for (T value : values) {
            this.removeOptional(value);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptional(class_6880.class_6883<? extends T> holder) {
        return this.removeOptionalKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptional(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.removeOptional(holder);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> removeTag(class_2960 id);

    public AbstractTagAppender<T> removeTag(class_2960... ids) {
        for (class_2960 id : ids) {
            this.removeTag(id);
        }

        return this;
    }

    public AbstractTagAppender<T> removeTag(class_6862<T> tag) {
        return this.removeTag(tag.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeTag(class_6862<T>... tags) {
        for (class_6862<T> tag : tags) {
            this.removeTag(tag);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptionalTag(String id) {
        return this.removeOptionalTag(class_2960.method_60654(id));
    }

    public AbstractTagAppender<T> removeOptionalTag(String... ids) {
        for (String id : ids) {
            this.removeOptionalTag(id);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> removeOptionalTag(class_2960 id);

    public AbstractTagAppender<T> removeOptionalTag(class_2960... ids) {
        for (class_2960 id : ids) {
            this.removeOptionalTag(id);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptionalTag(class_6862<T> tag) {
        return this.removeOptionalTag(tag.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptionalTag(class_6862<T>... tags) {
        for (class_6862<T> tag : tags) {
            this.removeOptionalTag(tag);
        }

        return this;
    }

    private Function<T, class_5321<T>> keyExtractor() {
        Objects.requireNonNull(this.keyExtractor, "key extractor is null");
        return this.keyExtractor;
    }

    public abstract List<String> asStringList();

    /**
     * Do not use the vanilla method, there is an issue with the ModernFix mod overwriting it.
     *
     * @see class_3497#method_43936()
     */
    protected final String elementOrTag(class_3497 entry) {
        return new class_5699.class_7476(entry.field_15584, entry.field_39267).toString();
    }
}
