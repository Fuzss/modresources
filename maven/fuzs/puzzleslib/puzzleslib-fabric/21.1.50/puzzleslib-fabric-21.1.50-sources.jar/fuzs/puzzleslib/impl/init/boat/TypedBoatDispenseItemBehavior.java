package fuzs.puzzleslib.impl.init.boat;

import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1799;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3486;

/**
 * Copied from Minecraft 26.1.
 */
public class TypedBoatDispenseItemBehavior extends class_2347 {
    private final class_2347 defaultDispenseItemBehavior = new class_2347();
    private final class_1299<? extends class_1690> type;

    public TypedBoatDispenseItemBehavior(class_1299<? extends class_1690> type) {
        this.type = type;
    }

    @Override
    public class_1799 method_10135(class_2342 source, class_1799 dispensed) {
        class_2350 direction = source.comp_1969().method_11654(class_2315.field_10918);
        class_3218 level = source.comp_1967();
        class_243 center = source.method_53906();
        double justOutsideDispenser = (double) 0.5625F + (double) this.type.method_17685() / (double) 2.0F;
        double spawnX = center.method_10216() + (double) direction.method_10148() * justOutsideDispenser;
        double spawnY = center.method_10214() + (double) ((float) direction.method_10164() * 1.125F);
        double spawnZ = center.method_10215() + (double) direction.method_10165() * justOutsideDispenser;
        class_2338 frontPos = source.comp_1968().method_10093(direction);
        double yOffset;
        if (level.method_8316(frontPos).method_15767(class_3486.field_15517)) {
            yOffset = 1.0F;
        } else {
            if (!level.method_8320(frontPos).method_26215() || !level.method_8316(frontPos.method_10074()).method_15767(class_3486.field_15517)) {
                return this.defaultDispenseItemBehavior.dispense(source, dispensed);
            }

            yOffset = 0.0F;
        }

        class_1690 boat = this.type.method_5883(level);
        if (boat != null) {
            boat.method_30634(spawnX, spawnY + yOffset, spawnZ);
            class_1299.method_48009(level, dispensed, null).accept(boat);
            boat.method_36456(direction.method_10144());
            level.method_8649(boat);
            dispensed.method_7934(1);
        }

        return dispensed;
    }

    @Override
    protected void method_10136(class_2342 source) {
        source.comp_1967().method_20290(1000, source.comp_1968(), 0);
    }
}
