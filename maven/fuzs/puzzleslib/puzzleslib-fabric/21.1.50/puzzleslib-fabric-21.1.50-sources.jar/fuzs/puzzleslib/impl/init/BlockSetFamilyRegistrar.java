package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import fuzs.puzzleslib.api.init.v3.registry.RegistryManager;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_4719;
import net.minecraft.class_5794;
import net.minecraft.class_6880;
import net.minecraft.class_8177;

public final class BlockSetFamilyRegistrar implements BlockSetFamily, BlockSetFamily.Writable, BlockSetFamily.Context {
    private final Map<BlockSetVariant, class_6880.class_6883<class_2248>> blockVariants = new LinkedHashMap<>();
    private final Map<BlockSetVariant, class_6880.class_6883<class_1792>> itemVariants = new LinkedHashMap<>();
    private final Map<BlockSetVariant, class_6880.class_6883<class_1299<?>>> entityVariants = new LinkedHashMap<>();
    private final RegistryManager registries;
    private final class_6880.class_6883<class_2248> baseBlock;
    private final String basePath;
    private final class_8177 blockSetType;
    private final class_4719 woodType;
    private Consumer<class_5794.class_5795> blockFamilyConsumer = Function.identity()::apply;

    public BlockSetFamilyRegistrar(RegistryManager registries, class_6880.class_6883<class_2248> baseBlock, String basePath, class_8177 blockSetType, class_4719 woodType) {
        this.registries = registries;
        this.baseBlock = baseBlock;
        this.basePath = basePath;
        this.blockSetType = blockSetType;
        this.woodType = woodType;
    }

    @Override
    public class_6880.class_6883<class_2248> getBaseBlock() {
        return this.baseBlock;
    }

    @Override
    public class_8177 getBlockSetType() {
        return this.blockSetType;
    }

    @Override
    public class_4719 getWoodType() {
        return this.woodType;
    }

    @Override
    public class_5794 getBlockFamily() {
        class_5794.class_5795 blockFamily = new class_5794.class_5795(this.getBaseBlock().comp_349());
        this.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> holder) -> {
            if (variant instanceof VanillaBlockSetVariant vanillaVariant) {
                vanillaVariant.variantBuilder.accept(blockFamily, holder.comp_349());
            }
        });

        if (this.getBlockVariants().containsKey(BlockSetVariant.SIGN) && this.getBlockVariants()
                .containsKey(BlockSetVariant.WALL_SIGN)) {
            blockFamily.method_33483(this.getBlock(BlockSetVariant.SIGN).comp_349(),
                    this.getBlock(BlockSetVariant.WALL_SIGN).comp_349());
        }

        this.blockFamilyConsumer.accept(blockFamily);
        return blockFamily.method_33481();
    }

    @Override
    public Map<BlockSetVariant, class_6880.class_6883<class_2248>> getBlockVariants() {
        return Collections.unmodifiableMap(this.blockVariants);
    }

    @Override
    public Map<BlockSetVariant, class_6880.class_6883<class_1792>> getItemVariants() {
        return Collections.unmodifiableMap(this.itemVariants);
    }

    @Override
    public Map<BlockSetVariant, class_6880.class_6883<class_1299<?>>> getEntityVariants() {
        return Collections.unmodifiableMap(this.entityVariants);
    }

    @Override
    public String getName(UnaryOperator<String> name) {
        return name.apply(this.basePath);
    }

    @Override
    public RegistryManager getRegistries() {
        return this.registries;
    }

    @Override
    public void registerBlock(BlockSetVariant variant, class_6880.class_6883<class_2248> holder) {
        Objects.requireNonNull(holder, "holder is null");
        if (this.blockVariants.put(variant, holder) != null) {
            throw new IllegalStateException(variant + " already present");
        }
    }

    @Override
    public void registerItem(BlockSetVariant variant, class_6880.class_6883<class_1792> holder) {
        Objects.requireNonNull(holder, "holder is null");
        if (this.itemVariants.put(variant, holder) != null) {
            throw new IllegalStateException(variant + " already present");
        }
    }

    @Override
    public void registerEntityType(BlockSetVariant variant, class_6880.class_6883<class_1299<?>> holder) {
        Objects.requireNonNull(holder, "holder is null");
        if (this.entityVariants.put(variant, holder) != null) {
            throw new IllegalStateException(variant + " already present");
        }
    }

    @Override
    public Writable generateFor(BlockSetVariant variant) {
        variant.generateFor(this);
        return this;
    }

    @Override
    public Writable configureBlockFamily(Consumer<class_5794.class_5795> blockFamilyConsumer) {
        Objects.requireNonNull(blockFamilyConsumer, "consumer is null");
        this.blockFamilyConsumer = blockFamilyConsumer;
        return this;
    }
}
