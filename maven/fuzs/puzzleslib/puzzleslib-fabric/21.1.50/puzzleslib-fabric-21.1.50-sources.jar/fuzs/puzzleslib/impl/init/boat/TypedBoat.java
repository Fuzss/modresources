package fuzs.puzzleslib.impl.init.boat;

import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1690;
import net.minecraft.class_1792;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3486;

/**
 * Copied from Minecraft 26.1.
 */
public class TypedBoat extends class_1690 {
    private final Supplier<class_1792> dropItem;

    public TypedBoat(class_1299<? extends class_1690> entityType, class_1937 level, Supplier<class_1792> dropItem) {
        super(entityType, level);
        this.dropItem = dropItem;
    }

    @Override
    public class_1792 method_7557() {
        return this.dropItem.get();
    }

    @Override
    protected void method_5623(double y, boolean onGround, class_2680 state, class_2338 pos) {
        // Boats no longer drop planks and sticks when crashed, which at this point was only ever possible due to a rare bug.
        // The remaining code for boats that caused them to be destroyed like in pre-1.9 has been removed.
        // Prior to this point, falling from very specific heights would destroy the boat and damage the rider.
        this.field_7696 = this.method_18798().field_1351;
        if (!this.method_5765()) {
            if (onGround) {
                this.method_38785();
            } else if (!this.method_37908().method_8316(this.method_24515().method_10074()).method_15767(class_3486.field_15517) && y < 0.0) {
                this.field_6017 -= (float) y;
            }
        }
    }

    @Override
    protected void method_5652(class_2487 compound) {
        super.method_5652(compound);
        compound.method_10551("Type");
    }

    @Override
    protected void method_5749(class_2487 compound) {
        compound.method_10551("Type");
        super.method_5749(compound);

    }

    @Override
    public void method_47884(class_1692 variant) {
        // NO-OP
    }

    @Override
    public class_1692 method_47827() {
        return class_1692.field_7727;
    }
}
