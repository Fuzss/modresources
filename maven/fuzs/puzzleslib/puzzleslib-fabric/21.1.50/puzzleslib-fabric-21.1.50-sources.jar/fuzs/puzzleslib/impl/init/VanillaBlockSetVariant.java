package fuzs.puzzleslib.impl.init;

import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import java.util.Objects;
import java.util.function.BiConsumer;
import net.minecraft.class_4970;
import net.minecraft.class_5794;

public abstract class VanillaBlockSetVariant implements BlockSetVariant {
    private final class_5794.class_5796 variant;
    final BiConsumer<class_5794.class_5795, net.minecraft.class_2248> variantBuilder;

    public VanillaBlockSetVariant(class_5794.class_5796 variant, BiConsumer<class_5794.class_5795, net.minecraft.class_2248> variantBuilder) {
        this.variant = variant;
        this.variantBuilder = variantBuilder;
    }

    @Override
    public class_5794.class_5796 toVanilla() {
        return this.variant;
    }

    @Override
    public String toString() {
        return "Vanilla[" + this.method_15434() + "]";
    }

    @Override
    public String method_15434() {
        return this.variant.method_33498();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        } else if (!(obj instanceof BlockSetVariant variant)) {
            return false;
        } else {
            return Objects.equals(this.method_15434(), variant.method_15434());
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.method_15434());
    }

    public static class Direct extends VanillaBlockSetVariant {

        public Direct(class_5794.class_5796 variant, BiConsumer<class_5794.class_5795, net.minecraft.class_2248> variantBuilder) {
            super(variant, variantBuilder);
        }

        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerSimpleBlock(context.getNameWithPrefix(this.method_15434()), () -> {
                                return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349());
                            }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    }
}
