package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3701;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_3701.class)
abstract class OcelotFabricMixin extends class_1429 {

    protected OcelotFabricMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyExpressionValue(method = "mobInteract",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/RandomSource;nextInt(I)I"))
    public int mobInteract(int intValue, class_1657 player, class_1268 interactionHand) {
        return FabricEventImplHelper.onAnimalTame(this, player, intValue);
    }
}
