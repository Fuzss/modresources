package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.ParticleProvidersContext;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.particle.v1.ParticleRendererRegistry;
import net.minecraft.class_11938;
import net.minecraft.class_11939;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_3999;
import net.minecraft.class_702;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;
import java.util.Objects;
import java.util.function.Function;

public final class ParticleProvidersContextFabricImpl implements ParticleProvidersContext {

    @Override
    public <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707<T> particleProvider) {
        Objects.requireNonNull(particleType, "particle type is null");
        Objects.requireNonNull(particleProvider, "particle provider is null");
        ParticleFactoryRegistry.getInstance().register(particleType, particleProvider);
    }

    @Override
    public <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_11939.class_4091<T> particleFactory) {
        Objects.requireNonNull(particleType, "particle type is null");
        Objects.requireNonNull(particleFactory, "particle provider factory is null");
        ParticleFactoryRegistry.getInstance().register(particleType, particleFactory::create);
    }

    @Override
    public void registerParticleRenderType(class_3999 particleRenderType, Function<class_702, class_11938<?>> particleGroupFactory) {
        Objects.requireNonNull(particleRenderType, "particle render type is null");
        Objects.requireNonNull(particleGroupFactory, "particle group factory is null");
        ParticleRendererRegistry.register(particleRenderType, particleGroupFactory);
    }
}
