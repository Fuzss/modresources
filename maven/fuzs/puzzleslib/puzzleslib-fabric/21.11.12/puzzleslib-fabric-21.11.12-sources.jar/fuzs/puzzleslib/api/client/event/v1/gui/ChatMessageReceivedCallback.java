package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_7471;
import org.jspecify.annotations.Nullable;

@FunctionalInterface
public interface ChatMessageReceivedCallback {
    EventInvoker<ChatMessageReceivedCallback> EVENT = EventInvoker.lookup(ChatMessageReceivedCallback.class);

    /**
     * Runs in {@link net.minecraft.class_7594} when a new chat message is about to be added
     * to the client chat. Allows for filtering out or adjusting received messages.
     * <p>
     * Does not directly distinguish between system, player, and unsigned chat message types, although non-system chat
     * messages will usually have a {@link class_2556.class_7602} and for player messages an additional
     * {@link class_7471} component associated with them. Also, player messages can never be set as an overlay.
     * <p>
     * Note that some client-side messages such as messages originating from debug actions via {@code F3} are directly
     * forwarded to {@link net.minecraft.class_338} and therefore are not passed through this
     * event.
     *
     * @param chatMessage       the message component
     * @param chatTypeBound     the chat message information, used for decoration
     * @param playerChatMessage the player signing information
     * @param isOverlay         is this added above the hotbar instead of to the chat
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the message from being added to the client chat</li>
     *         <li>{@link EventResult#PASS PASS} to allow the message to be added</li>
     *         </ul>
     */
    EventResult onChatMessageReceived(MutableValue<class_2561> chatMessage, class_2556.@Nullable class_7602 chatTypeBound, @Nullable class_7471 playerChatMessage, boolean isOverlay);
}
