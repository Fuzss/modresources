package fuzs.puzzleslib.api.client.init.v1;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import java.util.Objects;
import net.minecraft.class_4719;

/**
 * A helper class containing wood type related methods for the client.
 */
public final class ClientWoodTypeRegistry {

    private ClientWoodTypeRegistry() {
        // NO-OP
    }

    /**
     * Registers a {@link class_4719} to the {@link net.minecraft.class_4722} class for creating sign
     * materials.
     * <p>
     * Note that underlying maps are not concurrent, so this must be called from synchronized code.
     *
     * @param woodType the wood type
     */
    public static void registerWoodType(class_4719 woodType) {
        Objects.requireNonNull(woodType, "wood type is null");
        ClientProxyImpl.get().registerWoodType(woodType);
    }
}
