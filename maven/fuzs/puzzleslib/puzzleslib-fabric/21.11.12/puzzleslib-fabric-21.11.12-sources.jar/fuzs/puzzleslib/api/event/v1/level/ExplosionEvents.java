package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_9892;

public final class ExplosionEvents {
    public static final EventInvoker<Start> START = EventInvoker.lookup(Start.class);
    public static final EventInvoker<Detonate> DETONATE = EventInvoker.lookup(Detonate.class);

    private ExplosionEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Start {

        /**
         * Called just before an {@link class_1927} is about to be executed for a level, allows for preventing that
         * explosion.
         *
         * @param serverLevel the level the explosion is happening in
         * @param explosion   the explosion that is about to start
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} prevents to explosion from happening</li>
         *         <li>{@link EventResult#PASS PASS} allows the explosion to continue forward</li>
         *         </ul>
         */
        EventResult onExplosionStart(class_3218 serverLevel, class_9892 explosion);
    }

    @FunctionalInterface
    public interface Detonate {

        /**
         * Called just before entities affected by an ongoing explosion are processed, meaning before they are hurt and
         * knocked back.
         *
         * @param serverLevel      the level the explosion is happening in
         * @param explosion        the explosion that is about to detonate
         * @param affectedBlocks   the block positions affected by this explosion, modify the list to change the effects
         *                         on entities
         * @param affectedEntities the entities affected by this explosion, modify the list to change the effects on
         *                         entities
         */
        void onExplosionDetonate(class_3218 serverLevel, class_9892 explosion, List<class_2338> affectedBlocks, List<class_1297> affectedEntities);
    }
}
