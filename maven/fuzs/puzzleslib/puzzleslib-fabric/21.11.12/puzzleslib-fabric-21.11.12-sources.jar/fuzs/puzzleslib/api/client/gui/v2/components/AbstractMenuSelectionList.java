package fuzs.puzzleslib.api.client.gui.v2.components;

import fuzs.puzzleslib.api.client.gui.v2.ScreenHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_11875;
import net.minecraft.class_11876;
import net.minecraft.class_11909;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4265;
import net.minecraft.class_6379;
import net.minecraft.class_8666;

/**
 * A selection list implementation that can be used as part of a screen anywhere, without having to cover the whole
 * screen width.
 * <p>
 * Also, the scroll bar is mostly handled separately and is placed outside the bounds of the actual list.
 */
public class AbstractMenuSelectionList<E extends AbstractMenuSelectionList.Entry<E>> extends class_4265<E> {
    public static final class_8666 SCROLLER_SPRITES = new class_8666(class_2960.method_60656(
            "container/creative_inventory/scroller"),
            class_2960.method_60656("container/creative_inventory/scroller_disabled"),
            class_2960.method_60656("container/creative_inventory/scroller"));
    private static final int SCROLLER_WIDTH = 12;
    private static final int SCROLLER_HEIGHT = 15;

    private final int scrollbarOffset;

    public AbstractMenuSelectionList(class_310 minecraft, int x, int y, int width, int height, int itemHeight, int scrollbarOffset) {
        super(minecraft, width, height, y, itemHeight);
        this.scrollbarOffset = scrollbarOffset;
        this.method_46421(x);
    }

    @Override
    public int addEntry(E entry) {
        return super.method_25321(entry);
    }

    @Override
    public void method_25339() {
        super.method_25339();
    }

    @Override
    public int method_25322() {
        return this.method_25368();
    }

    @Override
    protected void method_44396(class_332 guiGraphics, int mouseX, int mouseY) {
        if (this.method_44392()) {
            int posX = this.method_65507();
            double scrollAmount = this.scrollbarUsable() ? this.method_44387() / this.method_44390() : 0;
            int posY = this.method_46427() + (int) (scrollAmount * (this.method_25364() - this.method_44394()));
            class_2960 identifier = SCROLLER_SPRITES.method_52729(this.scrollbarUsable(), false);
            guiGraphics.method_52706(class_10799.field_56883,
                    identifier,
                    posX,
                    posY,
                    this.scrollerWidth(),
                    this.method_44394());
            if (this.method_74038(mouseX, mouseY)) {
                guiGraphics.method_74037(this.requestedCursorType());
            }
        }
    }

    protected class_11875 requestedCursorType() {
        if (this.scrollbarUsable()) {
            return this.field_39498 ? class_11876.field_62456 : class_11876.field_62455;
        } else {
            return class_11876.field_62459;
        }
    }

    @Override
    protected boolean method_44392() {
        return true;
    }

    protected boolean scrollbarUsable() {
        return this.method_44390() > 0;
    }

    @Override
    protected void method_57713(class_332 guiGraphics) {
        // NO-OP
    }

    @Override
    protected void method_57715(class_332 guiGraphics) {
        // NO-OP
    }

    @Override
    protected int method_73376() {
        return this.method_46427();
    }

    @Override
    protected int method_44395() {
        return super.method_44395() - 4;
    }

    protected int scrollerWidth() {
        return SCROLLER_WIDTH;
    }

    @Override
    protected int method_44394() {
        return SCROLLER_HEIGHT;
    }

    @Override
    protected int method_65507() {
        return this.method_31383() + this.scrollbarOffset;
    }

    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean doubleClick) {
        if (this.method_65505(mouseButtonEvent) && this.field_39498) {
            this.setMouseButtonScrollAmount(mouseButtonEvent);
            return true;
        } else {
            return super.method_25402(mouseButtonEvent, doubleClick);
        }
    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double dragX, double dragY) {
        if (this.field_39498) {
            this.setMouseButtonScrollAmount(mouseButtonEvent);
            return true;
        } else {
            return super.method_25403(mouseButtonEvent, dragX, dragY);
        }
    }

    protected void setMouseButtonScrollAmount(class_11909 mouseButtonEvent) {
        double scrollOffset = (mouseButtonEvent.comp_4799() - this.method_46427() - this.method_44394() / 2.0) / (this.method_25364()
                - this.method_44394());
        this.method_44382(class_3532.method_15350(scrollOffset, 0.0, 1.0) * this.method_44390());
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return super.method_25405(mouseX, mouseY) || this.method_74038(mouseX, mouseY);
    }

    @Override
    protected boolean method_74038(double mouseX, double mouseY) {
        return ScreenHelper.isHovering(this.method_65507(),
                this.method_46427(),
                this.scrollerWidth(),
                this.method_25364(),
                mouseX,
                mouseY);
    }

    @Override
    protected void renderSelection(class_332 guiGraphics, E entry, int innerColor) {
        // NO-OP
    }

    @Override
    public int method_25342() {
        return this.method_46426();
    }

    @Override
    public int method_25337(int index) {
        return super.method_25337(index) - 4;
    }

    public static class Entry<E extends Entry<E>> extends class_4265.class_4266<E> {
        private final List<class_339> children = new ArrayList<>();

        @Override
        public int method_73380() {
            return this.method_46426();
        }

        @Override
        public int method_73382() {
            return this.method_46427();
        }

        @Override
        public int method_73384() {
            return this.method_25364();
        }

        @Override
        public int method_73387() {
            return this.method_25368();
        }

        public <T extends class_339> T addRenderableWidget(T widget) {
            this.children.add(widget);
            return widget;
        }

        @Override
        public void method_25343(class_332 guiGraphics, int mouseX, int mouseY, boolean isHovering, float partialTick) {
            for (class_339 abstractWidget : this.children) {
                abstractWidget.method_46419(this.method_73382());
                abstractWidget.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public List<? extends class_364> method_25396() {
            return this.children;
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return this.children;
        }
    }
}
