package fuzs.puzzleslib.api.init.v3.family;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.api.core.v1.context.GameplayContentContext;
import fuzs.puzzleslib.api.init.v3.registry.RegistryManager;
import fuzs.puzzleslib.impl.init.BlockSetFamilyRegistrar;
import org.joml.Vector2i;
import org.joml.Vector2ic;

import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import net.minecraft.class_10255;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2315;
import net.minecraft.class_2357;
import net.minecraft.class_2591;
import net.minecraft.class_2967;
import net.minecraft.class_4719;
import net.minecraft.class_5794;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_8177;

public interface BlockSetFamily {
    /**
     * @see #registerFor(BiConsumer, Map)
     */
    Map<BlockSetVariant, class_6880<class_2591<?>>> VARIANT_BLOCK_ENTITY_TYPE = ImmutableMap.of(BlockSetVariant.SIGN,
            class_7923.field_41181.method_47983(class_2591.field_11911),
            BlockSetVariant.WALL_SIGN,
            class_7923.field_41181.method_47983(class_2591.field_11911),
            BlockSetVariant.HANGING_SIGN,
            class_7923.field_41181.method_47983(class_2591.field_40330),
            BlockSetVariant.WALL_HANGING_SIGN,
            class_7923.field_41181.method_47983(class_2591.field_40330),
            BlockSetVariant.SHELF,
            class_7923.field_41181.method_47983(class_2591.field_61437));
    /**
     * @see #registerFor(GameplayContentContext, Map)
     */
    Map<BlockSetVariant, Vector2ic> VARIANT_WOODEN_FLAMMABLE = ImmutableMap.of(BlockSetVariant.STAIRS,
            new Vector2i(5, 20),
            BlockSetVariant.SLAB,
            new Vector2i(5, 20),
            BlockSetVariant.FENCE,
            new Vector2i(5, 20),
            BlockSetVariant.FENCE_GATE,
            new Vector2i(5, 20),
            BlockSetVariant.SHELF,
            new Vector2i(30, 20));
    /**
     * @see #registerFor(Map)
     */
    @SuppressWarnings("unchecked")
    Map<BlockSetVariant, Function<class_6880<class_1299<?>>, class_2357>> VARIANT_DISPENSE_BEHAVIOR = ImmutableMap.of(
            BlockSetVariant.BOAT,
            (class_6880<class_1299<?>> holder) -> {
                return new class_2967((class_1299<? extends class_10255>) holder.comp_349());
            },
            BlockSetVariant.CHEST_BOAT,
            (class_6880<class_1299<?>> holder) -> {
                return new class_2967((class_1299<? extends class_10255>) holder.comp_349());
            });

    static Writable base(RegistryManager registries, class_6880.class_6883<class_2248> baseBlock, String basePath) {
        class_8177 blockSetType = new class_8177(registries.makeKey(basePath).toString());
        class_4719 woodType = new class_4719(registries.makeKey(basePath).toString(), blockSetType);
        return new BlockSetFamilyRegistrar(registries, baseBlock, basePath, blockSetType, woodType);
    }

    static Writable any(RegistryManager registries, class_6880.class_6883<class_2248> baseBlock, String basePath) {
        return base(registries, baseBlock, basePath).generateFor(BlockSetVariant.STAIRS)
                .generateFor(BlockSetVariant.SLAB)
                .generateFor(BlockSetVariant.WALL);
    }

    static Writable metal(RegistryManager registries, class_6880.class_6883<class_2248> baseBlock, String basePath) {
        return base(registries, baseBlock, basePath).generateFor(BlockSetVariant.STAIRS)
                .generateFor(BlockSetVariant.SLAB)
                .generateFor(BlockSetVariant.DOOR)
                .generateFor(BlockSetVariant.TRAPDOOR)
                .generateFor(BlockSetVariant.PRESSURE_PLATE);
    }

    static Writable wooden(RegistryManager registries, class_6880.class_6883<class_2248> baseBlock, String basePath) {
        return base(registries, baseBlock, basePath).configureBlockFamily((class_5794.class_5795 blockFamily) -> {
                    blockFamily.method_33484("wooden").method_33487("has_planks");
                })
                .generateFor(BlockSetVariant.STAIRS)
                .generateFor(BlockSetVariant.SLAB)
                .generateFor(BlockSetVariant.FENCE)
                .generateFor(BlockSetVariant.FENCE_GATE)
                .generateFor(BlockSetVariant.DOOR)
                .generateFor(BlockSetVariant.TRAPDOOR)
                .generateFor(BlockSetVariant.PRESSURE_PLATE)
                .generateFor(BlockSetVariant.BUTTON)
                .generateFor(BlockSetVariant.SIGN)
                .generateFor(BlockSetVariant.HANGING_SIGN)
                .generateFor(BlockSetVariant.SHELF)
                .generateFor(BlockSetVariant.BOAT)
                .generateFor(BlockSetVariant.CHEST_BOAT);
    }

    class_6880.class_6883<class_2248> getBaseBlock();

    class_8177 getBlockSetType();

    class_4719 getWoodType();

    class_5794 getBlockFamily();

    Map<BlockSetVariant, class_6880.class_6883<class_2248>> getBlockVariants();

    Map<BlockSetVariant, class_6880.class_6883<class_1792>> getItemVariants();

    Map<BlockSetVariant, class_6880.class_6883<class_1299<?>>> getEntityVariants();

    default class_6880.class_6883<class_2248> getBlock(BlockSetVariant variant) {
        return this.getBlockVariants().get(variant);
    }

    default class_6880.class_6883<class_1792> getItem(BlockSetVariant variant) {
        return this.getItemVariants().get(variant);
    }

    default class_6880.class_6883<class_1299<?>> getEntityType(BlockSetVariant variant) {
        return this.getEntityVariants().get(variant);
    }

    default void register() {
        class_8177.method_49233(this.getBlockSetType());
        class_4719.method_24027(this.getWoodType());
    }

    default void registerFor(BiConsumer<class_2591<?>, class_2248> consumer, Map<BlockSetVariant, class_6880<class_2591<?>>> variants) {
        this.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> holder) -> {
            class_6880<class_2591<?>> blockEntity = variants.get(variant);
            if (blockEntity != null) {
                consumer.accept(blockEntity.comp_349(), holder.comp_349());
            }
        });
    }

    default void registerFor(GameplayContentContext context, Map<BlockSetVariant, Vector2ic> variants) {
        this.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> holder) -> {
            Vector2ic flammable = variants.get(variant);
            if (flammable != null) {
                context.registerFlammable(holder, flammable.x(), flammable.y());
            }
        });
    }

    default void registerFor(Map<BlockSetVariant, Function<class_6880<class_1299<?>>, class_2357>> variants) {
        this.getEntityVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_1299<?>> holder) -> {
            Function<class_6880<class_1299<?>>, class_2357> behaviorFactory = variants.get(variant);
            if (behaviorFactory != null) {
                class_2315.method_10009(this.getItem(variant).comp_349(), behaviorFactory.apply(holder));
            }
        });
    }

    interface Writable extends BlockSetFamily {
        Writable generateFor(BlockSetVariant variant);

        Writable configureBlockFamily(Consumer<class_5794.class_5795> blockFamilyConsumer);
    }

    interface Context extends BlockSetFamily {
        String getName(UnaryOperator<String> name);

        default String getNameWithPrefix(String prefix) {
            return this.getName((String string) -> prefix + "_" + string);
        }

        default String getNameWithSuffix(String suffix) {
            return this.getName((String string) -> string + "_" + suffix);
        }

        RegistryManager getRegistries();

        void registerBlock(BlockSetVariant variant, class_6880.class_6883<class_2248> holder);

        void registerItem(BlockSetVariant variant, class_6880.class_6883<class_1792> holder);

        void registerEntityType(BlockSetVariant variant, class_6880.class_6883<class_1299<?>> holder);
    }
}
