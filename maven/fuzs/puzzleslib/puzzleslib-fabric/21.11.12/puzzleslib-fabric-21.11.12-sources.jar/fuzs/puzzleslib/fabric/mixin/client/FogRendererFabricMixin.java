package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import net.minecraft.class_11400;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_7285;
import net.minecraft.class_758;
import net.minecraft.class_9779;
import org.joml.Vector4f;
import org.jspecify.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_758.class)
abstract class FogRendererFabricMixin {

    @ModifyReturnValue(method = "computeFogColor", at = @At("TAIL"))
    private static Vector4f computeFogColor(Vector4f vector4f, class_4184 camera, float partialTick, class_638 level, int renderDistanceChunks, float darkenWorldAmount) {
        // this could also be an injection at tail, but that does not stack with other injectors
        class_310 minecraft = class_310.method_1551();
        MutableFloat red = MutableFloat.fromEvent((Float x) -> vector4f.x = x, vector4f::x);
        MutableFloat green = MutableFloat.fromEvent((Float y) -> vector4f.y = y, vector4f::y);
        MutableFloat blue = MutableFloat.fromEvent((Float z) -> vector4f.z = z, vector4f::z);
        FabricRendererEvents.FOG_COLOR.invoker().onComputeFogColor(camera, partialTick, red, green, blue);
        return vector4f;
    }

    @Inject(method = "setupFog",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/fog/environment/FogEnvironment;setupFog(Lnet/minecraft/client/renderer/fog/FogData;Lnet/minecraft/client/Camera;Lnet/minecraft/client/multiplayer/ClientLevel;FLnet/minecraft/client/DeltaTracker;)V"))
    public void setupFog(CallbackInfoReturnable<Vector4f> callback, @Local class_11400 fogEnvironment, @Share(
            "fogEnvironment") LocalRef<class_11400> fogEnvironmentRef) {
        fogEnvironmentRef.set(fogEnvironment);
    }

    @Inject(method = "setupFog",
            at = @At(value = "FIELD",
                    target = "Lnet/minecraft/client/renderer/fog/FogData;renderDistanceEnd:F",
                    opcode = Opcodes.PUTFIELD,
                    shift = At.Shift.AFTER))
    public void setupFog(class_4184 camera, int renderDistance, class_9779 deltaTracker, float darkenWorldAmount, class_638 clientLevel, CallbackInfoReturnable<Vector4f> callback, @Local class_5636 fogType, @Local class_7285 fogData, @Share(
            "fogEnvironment") LocalRef<@Nullable class_11400> fogEnvironmentRef) {
        FabricRendererEvents.SETUP_FOG.invoker()
                .onSetupFog(camera,
                        deltaTracker.method_60637(false),
                        fogEnvironmentRef.get(),
                        fogType,
                        fogData);
    }
}
