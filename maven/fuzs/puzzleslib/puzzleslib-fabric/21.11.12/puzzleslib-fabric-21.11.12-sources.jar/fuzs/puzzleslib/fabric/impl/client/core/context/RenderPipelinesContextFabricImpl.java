package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import fuzs.puzzleslib.api.client.core.v1.context.RenderPipelinesContext;
import java.util.Objects;
import net.minecraft.class_10799;

public final class RenderPipelinesContextFabricImpl implements RenderPipelinesContext {

    @Override
    public void registerRenderPipeline(RenderPipeline renderPipeline) {
        Objects.requireNonNull(renderPipeline, "render pipeline is null");
        class_10799.method_67887(renderPipeline);
    }
}
