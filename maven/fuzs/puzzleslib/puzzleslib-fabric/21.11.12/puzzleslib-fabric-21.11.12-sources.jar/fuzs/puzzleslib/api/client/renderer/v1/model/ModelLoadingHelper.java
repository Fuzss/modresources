package fuzs.puzzleslib.api.client.renderer.v1.model;

import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.mojang.serialization.JsonOps;
import fuzs.puzzleslib.impl.PuzzlesLib;
import net.minecraft.class_10096;
import net.minecraft.class_10097;
import net.minecraft.class_10526;
import net.minecraft.class_10819;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1092;
import net.minecraft.class_1100;
import net.minecraft.class_156;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_7775;
import net.minecraft.class_790;
import net.minecraft.class_7923;
import net.minecraft.class_793;
import net.minecraft.class_9824;
import net.minecraft.client.resources.model.*;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public final class ModelLoadingHelper {

    private ModelLoadingHelper() {
        // NO-OP
    }

    @ApiStatus.Experimental
    public static class_9824.class_10095 loadBlockState(class_3300 resourceManager, class_2248 block) {
        return loadBlockState(resourceManager, block, class_156.method_18349()).join();
    }

    public static CompletableFuture<class_9824.class_10095> loadBlockState(class_3300 resourceManager, class_2248 block, Executor executor) {
        return loadBlockState(resourceManager,
                class_7923.field_41175.method_10221(block),
                block.method_9595(),
                executor);
    }

    @ApiStatus.Experimental
    public static class_9824.class_10095 loadBlockState(class_3300 resourceManager, class_2960 identifier, class_2689<class_2248, class_2680> stateDefinition) {
        return loadBlockState(resourceManager, identifier, stateDefinition, class_156.method_18349()).join();
    }

    public static CompletableFuture<class_9824.class_10095> loadBlockState(class_3300 resourceManager, class_2960 identifier, class_2689<class_2248, class_2680> stateDefinition, Executor executor) {
        return loadBlockState(resourceManager, identifier, identifier, stateDefinition, executor);
    }

    public static CompletableFuture<class_9824.class_10095> loadBlockState(class_3300 resourceManager, class_2960 oldIdentifier, class_2960 newIdentifier, class_2689<class_2248, class_2680> stateDefinition, Executor executor) {
        return loadBlockState(resourceManager,
                oldIdentifier,
                executor).thenCompose((List<class_9824.class_10094> loadedBlockModelDefinitions) -> {
            return loadBlockState(loadedBlockModelDefinitions, newIdentifier, stateDefinition, executor);
        });
    }

    /**
     * Similar to {@link class_9824#method_65718(class_3300, Executor)}.
     */
    public static CompletableFuture<List<class_9824.class_10094>> loadBlockState(class_3300 resourceManager, class_2960 identifier, Executor executor) {
        return CompletableFuture.supplyAsync(() -> resourceManager.method_14489(class_9824.field_55458.method_45112(
                identifier)), executor).thenApply((List<class_3298> resourceStack) -> {
            List<class_9824.class_10094> blockModelDefinitions = new ArrayList<>(resourceStack.size());

            for (class_3298 resource : resourceStack) {
                try (Reader reader = resource.method_43039()) {
                    JsonElement jsonElement = JsonParser.parseReader(reader);
                    class_790 blockModelDefinition = class_790.field_56928.parse(JsonOps.INSTANCE,
                            jsonElement).getOrThrow(JsonParseException::new);
                    blockModelDefinitions.add(new class_9824.class_10094(resource.method_14480(),
                            blockModelDefinition));
                } catch (Exception exception) {
                    PuzzlesLib.LOGGER.error("Failed to load blockstate definition {} from pack {}",
                            identifier,
                            resource.method_14480(),
                            exception);
                }
            }

            return blockModelDefinitions;
        });
    }

    /**
     * Similar to {@link class_9824#method_65718(class_3300, Executor)}.
     */
    public static CompletableFuture<class_9824.class_10095> loadBlockState(List<class_9824.class_10094> loadedBlockModelDefinitions, class_2960 identifier, class_2689<class_2248, class_2680> stateDefinition, Executor executor) {
        return CompletableFuture.supplyAsync(() -> {
            try {
                return class_9824.method_62627(identifier,
                        stateDefinition,
                        loadedBlockModelDefinitions);
            } catch (Exception exception) {
                PuzzlesLib.LOGGER.error("Failed to load blockstate definition {}", identifier, exception);
                return null;
            }
        }, executor);
    }

    @ApiStatus.Experimental
    public static @Nullable class_1100 loadBlockModel(class_3300 resourceManager, class_2960 identifier) {
        return loadBlockModel(resourceManager, identifier, class_156.method_18349()).join();
    }

    /**
     * Similar to {@link class_1092#method_45881(class_3300, Executor)}.
     */
    public static CompletableFuture<@Nullable class_1100> loadBlockModel(class_3300 resourceManager, class_2960 identifier, Executor executor) {
        return CompletableFuture.supplyAsync(() -> resourceManager.method_14486(class_1092.field_53676.method_45112(
                identifier)), executor).thenApply((Optional<class_3298> optional) -> {
            return optional.<class_1100>map((class_3298 resource) -> {
                try (Reader reader = resource.method_43039()) {
                    return class_793.method_3437(reader);
                } catch (Exception exception) {
                    PuzzlesLib.LOGGER.error("Failed to load model {}", identifier, exception);
                    return null;
                }
            }).orElse(null);
        });
    }

    public static class_1087.class_9979 missingModel() {
        return new class_1087.class_9979() {
            @Override
            public class_1087 method_65542(class_2680 blockState, class_7775 modelBaker) {
                class_1100 unbakedModel = class_10096.method_62629();
                // just use this, so we do not have to deal with the internal resolved model implementation
                class_10819 resolvedModel = new class_10097(Collections.emptyMap(), unbakedModel).method_68022();
                return class_1088.class_10812.method_68021(resolvedModel, modelBaker.method_65732(), modelBaker.method_76674()).comp_3771();
            }

            @Override
            public Object method_62332(class_2680 state) {
                return this;
            }

            @Override
            public void method_62326(class_10526.class_10103 resolver) {
                // NO-OP
            }
        };
    }
}
