package fuzs.puzzleslib.api.resources.v1;

import com.google.common.base.Stopwatch;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.hash.HashCode;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.data.v2.core.RegistriesDataProvider;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.jspecify.annotations.Nullable;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_4239;
import net.minecraft.class_7367;

/**
 * A pack resources implementation that is able to dynamically generate contents based on provided
 * {@link net.minecraft.class_2405 DataProviders}.
 */
public class DynamicPackResources extends AbstractModPackResources {
    /**
     * Helper map for quickly turning a pack type directory back into the {@link class_3264}.
     */
    public static final Map<String, class_3264> PATHS_FOR_TYPE = Arrays.stream(class_3264.values())
            .collect(ImmutableMap.toImmutableMap(class_3264::method_14413, Function.identity()));

    /**
     * The {@link net.minecraft.class_2405} factories used by this pack resources instances.
     */
    protected final DataProviderContext.Factory[] factories;
    /**
     * A map containing all generated files stored by {@link class_3264} and path (in form of a {@link class_2960}).
     */
    private Map<class_3264, Map<class_2960, class_7367<InputStream>>> paths;

    /**
     * @param factories the {@link net.minecraft.class_2405} factories used by this pack resources instances
     */
    protected DynamicPackResources(DataProviderContext.Factory... factories) {
        this.factories = factories;
    }

    /**
     * Creates a new dynamic pack resources supplier from privded factories.
     *
     * @param factories data provider factories that execute for dynamically providing all resources when this instance
     *                  is created
     * @return pack resources supplier
     */
    public static Supplier<AbstractModPackResources> create(DataProviderContext.Factory... factories) {
        return () -> new DynamicPackResources(factories);
    }

    /**
     * Runs all the supplied {@link net.minecraft.class_2405}s, but instead of writing the generated files to
     * disk collects the input streams stored by {@link class_3264} and path (in form of a {@link class_2960}).
     *
     * @param modId     the mod id namespace required for the data provider context
     * @param factories the data provider factories
     * @return map containing all generated files
     */
    public static Map<class_3264, Map<class_2960, class_7367<InputStream>>> generatePathsFromProviders(String modId, DataProviderContext.Factory... factories) {
        try {
            Stopwatch stopwatch = Stopwatch.createStarted();
            // start with a map for each type, as data generation below runs on a thread pool,
            // they will override each other when creating the maps
            Map<class_3264, Map<class_2960, class_7367<InputStream>>> paths = Arrays.stream(class_3264.values())
                    .collect(Collectors.toMap(Function.identity(), (class_3264 packType) -> new ConcurrentHashMap<>()));
            DataProviderContext context = DataProviderContext.ofPath(modId);
            for (DataProviderContext.Factory factory : factories) {
                class_2405 dataProvider = factory.apply(context);
                if (dataProvider instanceof RegistriesDataProvider registriesDataProvider) {
                    context = context.withRegistries(registriesDataProvider.getRegistries());
                }
                dataProvider.method_10319((Path filePath, byte[] data, HashCode hashCode) -> {
                    // good times with Windows...
                    List<String> strings = class_4239.method_46346(filePath.normalize()
                            .toString()
                            .replace(File.separator, "/")).result().filter(list -> list.size() >= 2).orElse(null);
                    if (strings != null) {
                        class_3264 packType = PATHS_FOR_TYPE.get(strings.getFirst());
                        Objects.requireNonNull(packType,
                                () -> "pack type for directory %s is null".formatted(strings.getFirst()));
                        String path = strings.stream().skip(2).collect(Collectors.joining("/"));
                        class_2960 identifier = class_2960.method_43902(strings.get(1), path);
                        if (identifier != null) {
                            paths.get(packType).put(identifier, () -> new ByteArrayInputStream(data));
                        }
                    }
                }).join();
            }
            Iterator<Map.Entry<class_3264, Map<class_2960, class_7367<InputStream>>>> iterator = paths.entrySet()
                    .iterator();
            while (iterator.hasNext()) {
                Map.Entry<class_3264, Map<class_2960, class_7367<InputStream>>> entry = iterator.next();
                if (!entry.getValue().isEmpty()) {
                    entry.setValue(ImmutableMap.copyOf(entry.getValue()));
                } else {
                    iterator.remove();
                }
            }
            PuzzlesLib.LOGGER.info("Data generation for dynamic pack resources provided by '{}' took {}ms",
                    modId,
                    stopwatch.stop().elapsed().toMillis());
            return Maps.immutableEnumMap(paths);
        } catch (Throwable throwable) {
            PuzzlesLib.LOGGER.warn("Unable to complete data generation for dynamic pack resources provided by '{}'",
                    modId,
                    throwable);
            return Collections.emptyMap();
        }
    }

    protected Map<class_2960, class_7367<InputStream>> getPathsForType(class_3264 packType) {
        Map<class_3264, Map<class_2960, class_7367<InputStream>>> paths = this.paths;
        if (paths == null) {
            paths = this.paths = this.generatePathsFromProviders();
        }
        return paths.getOrDefault(packType, Collections.emptyMap());
    }

    protected Map<class_3264, Map<class_2960, class_7367<InputStream>>> generatePathsFromProviders() {
        return generatePathsFromProviders(this.getNamespace(), this.factories);
    }

    @Nullable @Override
    public class_7367<InputStream> method_14405(class_3264 packType, class_2960 location) {
        return this.getPathsForType(packType).get(location);
    }

    @Override
    public void method_14408(class_3264 packType, String namespace, String path, class_7664 resourceOutput) {
        this.getPathsForType(packType)
                .entrySet()
                .stream()
                .filter((Map.Entry<class_2960, class_7367<InputStream>> entry) -> {
                    return entry.getKey().method_12836().equals(namespace) && entry.getKey().method_12832().startsWith(path);
                })
                .forEach((Map.Entry<class_2960, class_7367<InputStream>> entry) -> {
                    resourceOutput.accept(entry.getKey(), entry.getValue());
                });
    }

    @Override
    public Set<String> method_14406(class_3264 packType) {
        return this.getPathsForType(packType)
                .keySet()
                .stream()
                .map(class_2960::method_12836)
                .collect(Collectors.toSet());
    }
}
