package fuzs.puzzleslib.api.biome.v1;

import org.jspecify.annotations.NonNull;

import java.util.Optional;
import net.minecraft.class_4763;

/**
 * The modification context for the biomes effects.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically
 * <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext$GenerationSettingsContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification
 * system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
public interface SpecialEffectsContext {

    /**
     * @see class_4763#comp_5169()
     * @see class_4763.class_4764#method_24395(int)
     */
    void setWaterColor(int waterColor);

    /**
     * @see class_4763#comp_5169()
     * @see class_4763.class_4764#method_24395(int)
     */
    int getWaterColor();

    /**
     * @see class_4763#comp_5170()
     * @see class_4763.class_4764#method_30821(int)
     */
    void setFoliageColorOverride(Optional<Integer> foliageColorOverride);

    /**
     * @see class_4763#comp_5170()
     * @see class_4763.class_4764#method_30821(int)
     */
    Optional<Integer> getFoliageColorOverride();

    /**
     * @see class_4763#comp_5170()
     * @see class_4763.class_4764#method_30821(int)
     */
    default void setFoliageColorOverride(int foliageColorOverride) {
        this.setFoliageColorOverride(Optional.of(foliageColorOverride));
    }

    /**
     * @see class_4763#comp_5170()
     * @see class_4763.class_4764#method_30821(int)
     */
    default void clearFoliageColorOverride() {
        this.setFoliageColorOverride(Optional.empty());
    }

    /**
     * @see class_4763#comp_5171()
     * @see class_4763.class_4764#method_68149(int)
     */
    void setDryFoliageColorOverride(Optional<Integer> dryFoliageColorOverride);

    /**
     * @see class_4763#comp_5171()
     * @see class_4763.class_4764#method_68149(int)
     */
    Optional<Integer> getDryFoliageColorOverride();

    /**
     * @see class_4763#comp_5171()
     * @see class_4763.class_4764#method_68149(int)
     */
    default void setDryFoliageColorOverride(int dryFoliageColorOverride) {
        this.setDryFoliageColorOverride(Optional.of(dryFoliageColorOverride));
    }

    /**
     * @see class_4763#comp_5171()
     * @see class_4763.class_4764#method_68149(int)
     */
    default void clearDryFoliageColorOverride() {
        this.setDryFoliageColorOverride(Optional.empty());
    }

    /**
     * @see class_4763#comp_5172()
     * @see class_4763.class_4764#method_30822(int)
     */
    void setGrassColorOverride(Optional<Integer> grassColorOverride);

    /**
     * @see class_4763#comp_5172()
     * @see class_4763.class_4764#method_30822(int)
     */
    Optional<Integer> getGrassColorOverride();

    /**
     * @see class_4763#comp_5172()
     * @see class_4763.class_4764#method_30822(int)
     */
    default void setGrassColorOverride(int grassColorOverride) {
        this.setGrassColorOverride(Optional.of(grassColorOverride));
    }

    /**
     * @see class_4763#comp_5172()
     * @see class_4763.class_4764#method_30822(int)
     */
    default void clearGrassColorOverride() {
        this.setGrassColorOverride(Optional.empty());
    }

    /**
     * @see class_4763#comp_5173()
     * @see class_4763.class_4764#method_30818(class_4763.class_5486)
     */
    void setGrassColorModifier(class_4763.@NonNull class_5486 grassColorModifier);

    /**
     * @see class_4763#comp_5173()
     * @see class_4763.class_4764#method_30818(class_4763.class_5486)
     */
    class_4763.class_5486 getGrassColorModifier();
}
