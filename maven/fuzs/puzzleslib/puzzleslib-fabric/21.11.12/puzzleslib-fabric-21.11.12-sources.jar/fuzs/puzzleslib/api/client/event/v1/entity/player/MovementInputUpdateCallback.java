package fuzs.puzzleslib.api.client.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_744;
import net.minecraft.class_746;

@FunctionalInterface
public interface MovementInputUpdateCallback {
    EventInvoker<MovementInputUpdateCallback> EVENT = EventInvoker.lookup(MovementInputUpdateCallback.class);

    /**
     * Called after the {@link class_744} has ticked for the {@link class_746}.
     *
     * @param player the local player instance
     * @param input  the input instance for that player
     */
    void onMovementInputUpdate(class_746 player, class_744 input);
}
