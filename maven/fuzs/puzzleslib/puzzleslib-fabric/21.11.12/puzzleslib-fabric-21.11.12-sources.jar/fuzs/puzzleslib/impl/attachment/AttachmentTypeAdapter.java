package fuzs.puzzleslib.impl.attachment;

import net.minecraft.class_2960;
import org.jspecify.annotations.Nullable;

public interface AttachmentTypeAdapter<T, V> {

    class_2960 identifier();

    boolean hasData(T holder);

    @Nullable V getData(T holder);

    void setData(T holder, V value);

    void removeData(T holder);
}
