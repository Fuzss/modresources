package fuzs.puzzleslib.api.client.data.v2;

import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.class_10718;
import net.minecraft.class_11697;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7948;

public abstract class AbstractAtlasProvider extends class_10718 {
    private final Map<class_2960, class_11697.class_11698> atlasByTexture = class_11697.field_61862.stream()
            .collect(Collectors.toMap(class_11697.class_11698::comp_4553, Function.identity()));
    private final Map<class_2960, List<class_7948>> values = new LinkedHashMap<>();

    public AbstractAtlasProvider(DataProviderContext context) {
        this(context.getPackOutput());
    }

    public AbstractAtlasProvider(class_7784 packOutput) {
        super(packOutput);
    }

    @Override
    public final CompletableFuture<?> method_10319(class_7403 output) {
        this.addAtlases();
        return CompletableFuture.allOf(this.values.entrySet()
                .stream()
                .map((Map.Entry<class_2960, List<class_7948>> entry) -> {
                    return this.method_67252(output, entry.getKey(), entry.getValue());
                })
                .toArray(CompletableFuture[]::new));
    }

    public abstract void addAtlases();

    protected void addMaterial(class_4730 material) {
        this.add(this.atlasByTexture.get(material.method_24144()).comp_4554(), method_67250(material));
    }

    protected void add(class_2960 identifier, class_7948... spriteSources) {
        this.add(identifier, Arrays.asList(spriteSources));
    }

    protected void add(class_2960 identifier, List<class_7948> spriteSources) {
        this.values.computeIfAbsent(identifier, (class_2960 identifierX) -> new ArrayList<>())
                .addAll(spriteSources);
    }
}
