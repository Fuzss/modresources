package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import net.minecraft.class_1296;
import net.minecraft.class_1341;
import net.minecraft.class_1429;
import net.minecraft.class_4019;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(targets = "net.minecraft.world.entity.animal.fox.Fox$FoxBreedGoal")
abstract class FoxBreedGoalFabricMixin extends class_1341 {

    public FoxBreedGoalFabricMixin(class_1429 animal, double d) {
        super(animal, d);
    }

    @ModifyVariable(method = "breed", at = @At("STORE"))
    protected class_4019 breed(class_4019 fox) {
        MutableValue<class_1296> child = MutableValue.fromValue(fox);
        if (FabricLivingEvents.BABY_ENTITY_SPAWN.invoker()
                .onBabyEntitySpawn(this.field_6404, this.field_6406, child)
                .isInterrupt()) {
            this.field_6404.method_5614(6000);
            this.field_6406.method_5614(6000);
            this.field_6404.method_6477();
            this.field_6406.method_6477();
            return null;
        } else {
            return (class_4019) child.get();
        }
    }
}
