package fuzs.puzzleslib.api.data.v2;

import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.resources.v1.PackResourcesHelper;
import net.minecraft.class_2561;
import net.minecraft.class_3264;
import net.minecraft.class_3272;
import net.minecraft.class_3797;
import net.minecraft.class_7784;
import net.minecraft.class_7796;

public final class ModPackMetadataProvider extends class_7796 {

    public ModPackMetadataProvider(DataProviderContext context) {
        this(class_3264.field_14190, context);
    }

    public ModPackMetadataProvider(class_3264 packType, DataProviderContext context) {
        this(packType, context.getModId(), context.getPackOutput());
    }

    public ModPackMetadataProvider(String modId, class_7784 packOutput) {
        this(class_3264.field_14190, modId, packOutput);
    }

    public ModPackMetadataProvider(class_3264 packType, String modId, class_7784 packOutput) {
        super(packOutput);
        class_2561 component = PackResourcesHelper.getPackDescription(modId);
        this.method_46185(class_3272.method_72356(packType),
                new class_3272(component, class_3797.field_25319.method_70592(packType).method_72318()));
    }
}
