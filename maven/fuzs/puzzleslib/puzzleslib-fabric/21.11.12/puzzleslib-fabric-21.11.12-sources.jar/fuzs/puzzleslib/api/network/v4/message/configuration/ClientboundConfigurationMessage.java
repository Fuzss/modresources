package fuzs.puzzleslib.api.network.v4.message.configuration;

import fuzs.puzzleslib.api.network.v4.NetworkingHelper;
import fuzs.puzzleslib.api.network.v4.message.Message;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_8674;
import net.minecraft.class_8705;

/**
 * Template for a message sent by the server and received by a client during the configuration phase.
 */
public interface ClientboundConfigurationMessage extends Message<ClientboundConfigurationMessage.Context> {

    @Override
    default class_2596<class_8705> toPacket() {
        return NetworkingHelper.toClientboundPacket(this);
    }

    /**
     * The context provided in {@link #getListener()}.
     */
    interface Context extends Message.Context<class_8674> {

        /**
         * @return the client
         */
        class_310 client();
    }
}
