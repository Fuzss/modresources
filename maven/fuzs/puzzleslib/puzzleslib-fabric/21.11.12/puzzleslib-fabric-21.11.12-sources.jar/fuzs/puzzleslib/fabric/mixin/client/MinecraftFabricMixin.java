package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientLevelEvents;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientPlayerEvents;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLifecycleEvents;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_239;
import net.minecraft.class_2535;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_9779;

@Mixin(class_310.class)
abstract class MinecraftFabricMixin {
    @Shadow
    @Final
    public class_757 gameRenderer;
    @Shadow
    @Final
    private class_9779.class_9781 deltaTracker;
    @Shadow
    @Nullable public class_638 level;
    @Shadow
    @Nullable public class_746 player;
    @Shadow
    @Nullable public class_636 gameMode;
    @Shadow
    @Nullable public class_239 hitResult;
    @Shadow
    @Nullable public class_437 screen;

    @Inject(method = "<init>",
            at = @At(value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/systems/RenderSystem;getBackendDescription()Ljava/lang/String;",
                    shift = At.Shift.AFTER,
                    remap = false))
    public void init(CallbackInfo callback) {
        // run after Fabric Data Generation Api for same behavior as Forge where load complete does not run
        // during data generation (not that we use Fabric's data generation, but ¯\_(ツ)_/¯)
        FabricLifecycleEvents.LOAD_COMPLETE.invoker().onLoadComplete();
    }

    @Inject(method = "runTick",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V"))
    private void runTick$0(boolean renderLevel, CallbackInfo callback) {
        FabricRendererEvents.BEFORE_GAME_RENDER.invoker()
                .onBeforeGameRender(class_310.class.cast(this), this.gameRenderer, this.deltaTracker);
    }

    @Inject(method = "runTick",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/GameRenderer;render(Lnet/minecraft/client/DeltaTracker;Z)V",
                    shift = At.Shift.AFTER))
    private void runTick$1(boolean renderLevel, CallbackInfo callback) {
        FabricRendererEvents.AFTER_GAME_RENDER.invoker()
                .onAfterGameRender(class_310.class.cast(this), this.gameRenderer, this.deltaTracker);
    }

    @ModifyVariable(method = "setScreen",
            at = @At(value = "LOAD", ordinal = 0),
            slice = @Slice(from = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/player/LocalPlayer;respawn()V")),
            ordinal = 0,
            argsOnly = true)
    public class_437 setScreen(@Nullable class_437 newScreen) {
        // this implementation does not allow for cancelling a new screen being set,
        // due to vanilla's Screen::remove call happening before the new screen is properly computed (in regard to title &amp; death screens),
        // making the implementation difficult
        return FabricGuiEvents.SCREEN_OPENING.invoker()
                .onScreenOpening(this.screen, newScreen)
                .getInterrupt()
                .orElse(newScreen);
    }

    @Inject(method = "setLevel", at = @At("HEAD"))
    public void setLevel(class_638 clientLevel, CallbackInfo callback) {
        if (this.level != null) {
            FabricClientLevelEvents.UNLOAD_LEVEL.invoker().onLevelUnload(class_310.class.cast(this), this.level);
        }
    }

    @Inject(method = "disconnect(Lnet/minecraft/client/gui/screens/Screen;ZZ)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/GameRenderer;resetData()V",
                    shift = At.Shift.AFTER))
    public void disconnect(class_437 screen, boolean keepResourcePacks, boolean stopSoundManager, CallbackInfo callback) {
        if (this.player != null && this.gameMode != null) {
            class_2535 connection = this.player.field_3944.method_48296();
            Objects.requireNonNull(connection, "connection is null");
            FabricClientPlayerEvents.PLAYER_LEAVE.invoker().onPlayerLeave(this.player, this.gameMode, connection);
        }

        if (this.level != null) {
            FabricClientLevelEvents.UNLOAD_LEVEL.invoker().onLevelUnload(class_310.class.cast(this), this.level);
        }
    }

    @Inject(method = "pickBlock", at = @At("HEAD"), cancellable = true)
    private void pickBlock(CallbackInfo callback) {
        if (this.hitResult != null && this.hitResult.method_17783() != class_239.class_240.field_1333) {
            EventResult result = FabricClientPlayerEvents.PICK_INTERACTION_INPUT.invoker()
                    .onPickInteraction(class_310.class.cast(this), this.player, this.hitResult);
            if (result.isInterrupt()) {
                callback.cancel();
            }
        }
    }
}
