package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.UUID;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3468;

@Mixin(class_1542.class)
abstract class ItemEntityFabricMixin extends class_1297 {
    @Shadow
    private int pickupDelay;
    @Shadow
    @Nullable private UUID target;

    public ItemEntityFabricMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "playerTouch", at = @At("HEAD"), cancellable = true)
    public void playerTouch$0(class_1657 player, CallbackInfo callback, @Share("originalItemStack") LocalRef<class_1799> originalItemStack) {
        if (!this.method_73183().method_8608()) {
            originalItemStack.set(class_1799.field_8037);
            if (this.pickupDelay > 0) {
                originalItemStack.set(this.getItem().method_7972());
                return;
            }
            class_1799 itemStack = this.getItem();
            class_1792 item = itemStack.method_7909();
            int count = itemStack.method_7947();
            EventResult result = FabricPlayerEvents.ITEM_TOUCH.invoker()
                    .onItemTouch(player, class_1542.class.cast(this));
            if (!result.isInterrupt()) {
                originalItemStack.set(this.getItem().method_7972());
                return;
            } else {
                callback.cancel();
                if (!result.getAsBoolean()) {
                    return;
                }
            }
            if (this.pickupDelay == 0 && (this.target == null || this.target.equals(player.method_5667()))) {
                FabricPlayerEvents.ITEM_PICKUP.invoker()
                        .onItemPickup(player, class_1542.class.cast(this), itemStack.method_7972());
                player.method_6103(this, count);
                if (itemStack.method_7960()) {
                    this.method_31472();
                    itemStack.method_7939(count);
                }

                player.method_7342(class_3468.field_15392.method_14956(item), count);
                player.method_29499(class_1542.class.cast(this));
            }
        }
    }

    @Inject(method = "playerTouch",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/player/Player;take(Lnet/minecraft/world/entity/Entity;I)V"))
    public void playerTouch$1(class_1657 player, CallbackInfo callback, @Share("originalItemStack") LocalRef<class_1799> originalItemStack) {
        class_1799 itemStack = originalItemStack.get();
        if (!itemStack.method_7960()) {
            itemStack.method_7939(itemStack.method_7947() - this.getItem().method_7947());
            FabricPlayerEvents.ITEM_PICKUP.invoker().onItemPickup(player, class_1542.class.cast(this), itemStack);
        }
    }

    @Shadow
    public abstract class_1799 getItem();
}
