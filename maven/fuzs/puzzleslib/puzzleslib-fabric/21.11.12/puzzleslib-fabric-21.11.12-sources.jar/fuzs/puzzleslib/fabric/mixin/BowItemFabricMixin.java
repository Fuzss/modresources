package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import fuzs.puzzleslib.impl.event.data.DefaultedInt;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1753;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1753.class)
abstract class BowItemFabricMixin extends class_1811 {

    public BowItemFabricMixin(class_1793 properties) {
        super(properties);
    }

    @ModifyVariable(method = "releaseUsing", at = @At("STORE"), ordinal = 1)
    public int releaseUsing(int chargeValue, class_1799 bow, class_1937 level, class_1309 livingEntity, int timeCharged, @Local(
            ordinal = 1
    ) class_1799 ammo) {
        DefaultedInt charge = DefaultedInt.fromValue(this.method_7881(bow, livingEntity) - timeCharged);
        if (FabricPlayerEvents.ARROW_LOOSE.invoker()
                .onArrowLoose((class_1657) livingEntity, bow, level, charge, !ammo.method_7960())
                .isInterrupt()) {
            // returning zero will effectively cancel the method as it won't process for a charge too low
            return 0;
        } else {
            return charge.getAsOptionalInt().orElse(chargeValue);
        }
    }
}
