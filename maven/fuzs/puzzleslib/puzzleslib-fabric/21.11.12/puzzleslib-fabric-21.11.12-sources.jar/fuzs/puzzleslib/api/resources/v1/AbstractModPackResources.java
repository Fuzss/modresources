package fuzs.puzzleslib.api.resources.v1;

import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.impl.resources.ModPackResourcesSupplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3281;
import net.minecraft.class_3285;
import net.minecraft.class_3288;
import net.minecraft.class_5352;
import net.minecraft.class_7367;
import net.minecraft.class_7662;
import net.minecraft.class_7677;
import net.minecraft.class_7699;
import net.minecraft.class_9224;
import net.minecraft.class_9225;
import net.minecraft.server.packs.*;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

/**
 * A basic implementation of {@link class_3262} fit to be used for a built-in pack providing runtime generated
 * assets.
 * <p>This pack automatically uses the mod's mod logo for the pack icon.
 */
public class AbstractModPackResources implements class_3262 {
    /**
     * Path to the mod logo inside the mod jar to be used in place of <code>pack.png</code> for the pack icon.
     * <p>Defaults to <code>mod_logo.png</code>, path is separated using "/".
     */
    protected final String modLogoPath;
    /**
     * The pack type for this pack, set internally during construction.
     */
    @Nullable private class_3264 packType;
    /**
     * Location info of this pack, set internally during construction.
     */
    @Nullable private class_9224 info;
    /**
     * The metadata for the <code>pack.mcmeta</code> section, set internally during construction.
     */
    @Nullable private class_7662 metadata;

    /**
     * Simple constructor with default file path parameter for the pack icon.
     */
    public AbstractModPackResources() {
        this("mod_logo.png");
    }

    /**
     * Constructor with full control over the pack icon.
     */
    public AbstractModPackResources(String modLogoPath) {
        Objects.requireNonNull(modLogoPath, "mod logo path is null");
        this.modLogoPath = modLogoPath;
    }

    @Nullable @Override
    public class_7367<InputStream> method_14410(String... elements) {
        String path = String.join("/", elements);
        if ("pack.png".equals(path)) {
            return ModLoaderEnvironment.INSTANCE.getModContainer(this.getNamespace())
                    .flatMap(container -> container.findResource(this.modLogoPath))
                    .<class_7367<InputStream>>map(modResource -> {
                        return () -> Files.newInputStream(modResource);
                    })
                    .orElse(null);
        }

        return null;
    }

    @Nullable @Override
    public class_7367<InputStream> method_14405(class_3264 packType, class_2960 location) {
        return null;
    }

    @Override
    public void method_14408(class_3264 packType, String namespace, String path, class_7664 resourceOutput) {
        // NO-OP
    }

    @Override
    public Set<String> method_14406(class_3264 type) {
        Objects.requireNonNull(this.packType, "pack type is null");
        return this.packType == type ? Collections.singleton(this.getNamespace()) : Collections.emptySet();
    }

    @Override
    public @Nullable <T> T method_14407(class_7677<T> type) throws IOException {
        Objects.requireNonNull(this.metadata, "metadata is null");
        return this.metadata.method_45173(type);
    }

    @Override
    public class_9224 method_56926() {
        Objects.requireNonNull(this.info, "info is null");
        return this.info;
    }

    @Override
    public void close() {
        // NO-OP
    }

    /**
     * @return the namespace from the internal id
     */
    public String getNamespace() {
        return class_2960.method_60654(this.method_14409()).method_12836();
    }

    /**
     * A helper method intended for setting up a pack with e.g. dynamically generated resources.
     * <p>
     * Runs after the id has been set.
     */
    @ApiStatus.OverrideOnly
    protected void setup() {
        // NO-OP
    }

    /**
     * Creates a new pack for registering a repository source.
     *
     * @param packType             type marking this pack as containing data or resource pack resources
     * @param identifier     id for the pack, used for internal references and is stored in
     *                             <code>options.txt</code>
     * @param factory              {@link net.minecraft.class_3262} implementation supplier
     * @param titleComponent       the title of this pack shown in the pack selection screen
     * @param descriptionComponent the description for this pack shown in the pack selection screen
     * @param required             a required pack cannot be disabled, like in the pack selection screen the pack cannot
     *                             be moved to the left side; this is used for the vanilla resource pack
     * @param position             insertion end in the pack list, new packs are usually inserted at the top above
     *                             vanilla
     * @param fixedPosition        a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden               controls whether the pack is hidden from user-facing screens like the resource pack
     *                             and data pack selection screens, only available on Forge
     * @param featureFlagSet       {@link net.minecraft.class_7701} enabled through this pack
     * @return the pack to be used for creating a {@link class_3285}
     */
    public static class_3288 buildPack(class_3264 packType, class_2960 identifier, Supplier<AbstractModPackResources> factory, class_2561 titleComponent, class_2561 descriptionComponent, boolean required, class_3288.class_3289 position, boolean fixedPosition, boolean hidden, class_7699 featureFlagSet) {
        class_9224 info = new class_9224(identifier.toString(),
                titleComponent,
                class_5352.field_25348,
                Optional.empty());
        class_3288.class_7680 resourcesSupplier = ModPackResourcesSupplier.create(packType,
                info,
                createSupplier(factory),
                descriptionComponent);
        class_3288.class_7679 metadata = PackResourcesHelper.createPackInfo(identifier,
                descriptionComponent,
                class_3281.field_14224,
                featureFlagSet,
                hidden);
        class_9225 config = new class_9225(required, position, fixedPosition);
        return new class_3288(info, resourcesSupplier, metadata, config);
    }

    private static ModPackResourcesSupplier.PackResourcesSupplier<AbstractModPackResources> createSupplier(Supplier<AbstractModPackResources> factory) {
        return (class_3264 packType, class_9224 info, class_7662 metadata) -> {
            AbstractModPackResources packResources = factory.get();
            packResources.info = info;
            packResources.metadata = metadata;
            packResources.packType = packType;
            packResources.setup();
            return packResources;
        };
    }
}
