package fuzs.puzzleslib.impl.attachment;

import fuzs.puzzleslib.api.network.v4.message.MessageListener;
import fuzs.puzzleslib.api.network.v4.message.play.ClientboundPlayMessage;
import io.netty.buffer.ByteBuf;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundEntityDataAttachmentMessage<V>(AttachmentTypeAdapter<class_1297, V> attachmentType,
                                                        class_9154<ClientboundEntityDataAttachmentMessage<V>> payloadType,
                                                        int entityId,
                                                        Optional<V> value) implements ClientboundPlayMessage {

    public static <V> class_9139<? super class_9129, ClientboundEntityDataAttachmentMessage<V>> streamCodec(AttachmentTypeAdapter<class_1297, V> attachmentType, class_9154<ClientboundEntityDataAttachmentMessage<V>> payloadType, class_9139<? super class_9129, V> valueStreamCodec) {
        return class_9139.method_56435(class_9135.field_48550,
                ClientboundEntityDataAttachmentMessage::entityId,
                class_9135.method_56382((class_9139<ByteBuf, V>) valueStreamCodec),
                ClientboundEntityDataAttachmentMessage::value,
                (Integer entityId, Optional<V> value) -> {
                    return new ClientboundEntityDataAttachmentMessage<>(attachmentType, payloadType, entityId, value);
                });
    }

    @Override
    public class_9154<ClientboundEntityDataAttachmentMessage<V>> method_56479() {
        return this.payloadType;
    }

    @Override
    public MessageListener<fuzs.puzzleslib.api.network.v4.message.play.ClientboundPlayMessage.Context> getListener() {
        return new MessageListener<>() {
            @Override
            public void accept(fuzs.puzzleslib.api.network.v4.message.play.ClientboundPlayMessage.Context context) {
                class_1297 entity = context.level().method_8469(ClientboundEntityDataAttachmentMessage.this.entityId());
                if (entity != null) {
                    if (ClientboundEntityDataAttachmentMessage.this.value().isPresent()) {
                        ClientboundEntityDataAttachmentMessage.this.attachmentType()
                                .setData(entity, ClientboundEntityDataAttachmentMessage.this.value().get());
                    } else {
                        ClientboundEntityDataAttachmentMessage.this.attachmentType().removeData(entity);
                    }
                }
            }
        };
    }
}
