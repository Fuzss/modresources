package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableDouble;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import org.jspecify.annotations.Nullable;

@FunctionalInterface
public interface CalculateLivingVisibilityCallback {
    EventInvoker<CalculateLivingVisibilityCallback> EVENT = EventInvoker.lookup(CalculateLivingVisibilityCallback.class);

    /**
     * Called in {@link class_1309#method_18390(class_1297)} when an entity is trying to be targeted by another
     * entity for applying a given percentage to the looking entity's original visibility range.
     *
     * @param livingEntity         the entity trying to be targeted
     * @param lookingEntity        the looking entity that is trying to target the other entity
     * @param visibilityPercentage the visibility percentage multiplied with the looking entity's targeting range
     */
    void onCalculateLivingVisibility(class_1309 livingEntity, @Nullable class_1297 lookingEntity, MutableDouble visibilityPercentage);
}
