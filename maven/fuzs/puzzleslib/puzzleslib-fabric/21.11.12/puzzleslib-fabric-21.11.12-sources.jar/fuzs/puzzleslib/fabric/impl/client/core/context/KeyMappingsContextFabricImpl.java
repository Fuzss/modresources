package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.client.core.v1.context.KeyMappingsContext;
import fuzs.puzzleslib.api.client.key.v1.KeyActivationContext;
import fuzs.puzzleslib.api.client.key.v1.KeyActivationHandler;
import fuzs.puzzleslib.fabric.impl.client.key.ActivationContextKeyMapping;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.class_11908;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_6599;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;

public final class KeyMappingsContextFabricImpl implements KeyMappingsContext {
    private final Set<class_304.class_11900> keyCategories = Sets.newIdentityHashSet();

    @Override
    public void registerKeyMapping(class_304 keyMapping, KeyActivationHandler activationHandler) {
        Objects.requireNonNull(keyMapping, "key mapping is null");
        Objects.requireNonNull(activationHandler, "activation handler is null");
        KeyBindingHelper.registerKeyBinding(keyMapping);
        KeyActivationContext context = activationHandler.getActivationContext();
        ((ActivationContextKeyMapping) keyMapping).puzzleslib$setKeyActivationContext(context);
        this.registerKeyCategoryIfNecessary(keyMapping);
        this.registerKeyActivationHandles(keyMapping, activationHandler);
    }

    private void registerKeyCategoryIfNecessary(class_304 keyMapping) {
        Objects.requireNonNull(keyMapping.method_1423(), "key category is null");
        Objects.requireNonNull(keyMapping.method_1423().comp_4879(), "key category id is null");
        if (this.keyCategories.add(keyMapping.method_1423())) {
            class_304.class_11900.method_74698(keyMapping.method_1423().comp_4879());
        }
    }

    private void registerKeyActivationHandles(class_304 keyMapping, KeyActivationHandler activationHandler) {
        if (activationHandler.gameHandler() != null) {
            ClientTickEvents.START_CLIENT_TICK.register((class_310 minecraft) -> {
                if (minecraft.field_1724 != null) {
                    while (keyMapping.method_1436()) {
                        activationHandler.gameHandler().accept(minecraft);
                    }
                }
            });
        }

        Consumer<class_437> screenConsumer = (Consumer<class_437>) activationHandler.screenHandler();
        if (screenConsumer != null) {
            ScreenEvents.BEFORE_INIT.register((class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                if (activationHandler.screenType().isInstance(screen)) {
                    ScreenKeyboardEvents.allowKeyPress(screen).register((class_437 currentScreen, class_11908 keyEvent) -> {
                        if (!(minecraft.field_1755 instanceof class_6599) && keyMapping.method_1417(keyEvent)) {
                            screenConsumer.accept(currentScreen);
                            return false;
                        } else {
                            return true;
                        }
                    });
                }
            });
        }
    }
}
