package fuzs.puzzleslib.api.network.v4.message;

import fuzs.puzzleslib.api.network.v4.NetworkingHelper;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_8710;

/**
 * Network message template providing a handler that runs when the message is received.
 *
 * @param <T> the message listener context
 */
public interface Message<T extends Message.Context<?>> extends class_8710 {

    @Override
    default class_9154<?> method_56479() {
        return NetworkingHelper.getPayloadType(this.getClass());
    }

    /**
     * Create a vanilla packet from the message.
     *
     * @return the packet
     */
    class_2596<?> toPacket();

    /**
     * Create a handler for the message, accepting a corresponding {@link Context}.
     *
     * @return the handler instance
     */
    MessageListener<T> getListener();

    /**
     * The context provided in {@link #getListener()}.
     */
    interface Context<T extends class_2547> {

        /**
         * @return the packet listener
         */
        T packetListener();

        /**
         * Send a reply to the sender.
         *
         * @param payload the payload to return to the sender
         */
        void reply(class_8710 payload);

        /**
         * Disconnect the client when receiving the message is unsuccessful.
         *
         * @param component the message shown on the disconnection screen
         */
        void disconnect(class_2561 component);
    }
}
