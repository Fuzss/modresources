package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_310;
import net.minecraft.class_757;
import net.minecraft.class_9779;

public final class GameRenderEvents {
    public static final EventInvoker<Before> BEFORE = EventInvoker.lookup(Before.class);
    public static final EventInvoker<After> AFTER = EventInvoker.lookup(After.class);

    private GameRenderEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Before {

        /**
         * Fires before the game and level are rendered in {@link class_757#method_3192(class_9779, boolean)}.
         *
         * @param minecraft    the minecraft singleton
         * @param gameRenderer the game renderer
         * @param deltaTracker the delta tracker for retrieving partial tick time
         */
        void onBeforeGameRender(class_310 minecraft, class_757 gameRenderer, class_9779 deltaTracker);
    }

    @FunctionalInterface
    public interface After {

        /**
         * Fires after the game and level are rendered in {@link class_757#method_3192(class_9779, boolean)}.
         *
         * @param minecraft    the minecraft singleton
         * @param gameRenderer the game renderer
         * @param deltaTracker the delta tracker for retrieving partial tick time
         */
        void onAfterGameRender(class_310 minecraft, class_757 gameRenderer, class_9779 deltaTracker);
    }
}
