package fuzs.puzzleslib.fabric.impl.biome;

import com.google.common.collect.ImmutableSet;
import fuzs.puzzleslib.api.biome.v1.MobSpawnSettingsContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;
import net.minecraft.class_6010;
import net.minecraft.class_7923;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Set;
import java.util.function.BiPredicate;

public record MobSpawnSettingsContextFabric(class_5483 mobSpawnSettings,
                                            BiomeModificationContext.SpawnSettingsContext context) implements MobSpawnSettingsContext {

    @Override
    public void setCreatureGenerationProbability(float probability) {
        this.context.setCreatureSpawnProbability(probability);
    }

    @Override
    public void addSpawn(class_1311 mobCategory, int weight, class_5483.class_1964 spawnerData) {
        this.context.addSpawn(mobCategory, spawnerData, weight);
    }

    @Override
    public boolean removeSpawns(BiPredicate<class_1311, class_5483.class_1964> filter) {
        return this.context.removeSpawns(filter);
    }

    @Override
    public void setSpawnCost(class_1299<?> entityType, double energyBudget, double charge) {
        this.context.setSpawnCost(entityType, charge, energyBudget);
    }

    @Override
    public boolean clearSpawnCost(class_1299<?> entityType) {
        if (this.getSpawnCost(entityType) != null) {
            this.context.clearSpawnCost(entityType);
            return true;
        } else {
            return false;
        }
    }

    @Override
    public List<class_6010<class_5483.class_1964>> getSpawnerData(class_1311 mobCategory) {
        return this.context.getSpawnEntries(mobCategory);
    }

    @Override
    public Set<class_1299<?>> getEntityTypesWithSpawnCost() {
        return class_7923.field_41177.method_10220()
                .filter((class_1299<?> entityType) -> this.getSpawnCost(entityType) != null)
                .collect(ImmutableSet.toImmutableSet());
    }

    @Override
    public class_5483.@Nullable class_5265 getSpawnCost(class_1299<?> entityType) {
        return this.mobSpawnSettings.method_31003(entityType);
    }

    @Override
    public float getCreatureGenerationProbability() {
        return this.mobSpawnSettings.method_31002();
    }
}
