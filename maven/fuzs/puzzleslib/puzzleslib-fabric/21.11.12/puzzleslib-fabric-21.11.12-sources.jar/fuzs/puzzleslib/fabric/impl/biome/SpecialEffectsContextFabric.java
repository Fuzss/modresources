package fuzs.puzzleslib.fabric.impl.biome;

import fuzs.puzzleslib.api.biome.v1.SpecialEffectsContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.class_4763;
import org.jspecify.annotations.NonNull;

import java.util.Objects;
import java.util.Optional;

public record SpecialEffectsContextFabric(class_4763 specialEffects,
                                          BiomeModificationContext.EffectsContext context) implements SpecialEffectsContext {

    @Override
    public void setWaterColor(int waterColor) {
        this.context.setWaterColor(waterColor);
    }

    @Override
    public int getWaterColor() {
        return this.specialEffects.comp_5169();
    }

    @Override
    public void setFoliageColorOverride(Optional<Integer> foliageColorOverride) {
        this.context.setFoliageColor(foliageColorOverride);
    }

    @Override
    public Optional<Integer> getFoliageColorOverride() {
        return this.specialEffects.comp_5170();
    }

    @Override
    public void setDryFoliageColorOverride(Optional<Integer> dryFoliageColorOverride) {
        this.context.setDryFoliageColor(dryFoliageColorOverride);
    }

    @Override
    public Optional<Integer> getDryFoliageColorOverride() {
        return this.specialEffects.comp_5171();
    }

    @Override
    public void setGrassColorOverride(Optional<Integer> grassColorOverride) {
        this.context.setGrassColor(grassColorOverride);
    }

    @Override
    public Optional<Integer> getGrassColorOverride() {
        return this.specialEffects.comp_5172();
    }

    @Override
    public void setGrassColorModifier(class_4763.@NonNull class_5486 grassColorModifier) {
        Objects.requireNonNull(grassColorModifier, "grass color modifier is null");
        this.context.setGrassColorModifier(grassColorModifier);
    }

    @Override
    public class_4763.class_5486 getGrassColorModifier() {
        return this.specialEffects.comp_5173();
    }
}
