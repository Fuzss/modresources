package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.fabric.impl.event.GrindstoneExperienceHolder;
import fuzs.puzzleslib.impl.event.EventImplHelper;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.OptionalInt;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_3803;
import net.minecraft.class_3917;

@Mixin(class_3803.class)
abstract class GrindstoneMenuFabricMixin extends class_1703 implements GrindstoneExperienceHolder {
    @Shadow
    @Final
    class_1263 repairSlots;
    @Unique private OptionalInt puzzleslib$experiencePointReward = OptionalInt.empty();

    protected GrindstoneMenuFabricMixin(@Nullable class_3917<?> menuType, int containerId) {
        super(menuType, containerId);
    }

    @ModifyExpressionValue(
            method = "createResult", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/inventory/GrindstoneMenu;computeResult(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)Lnet/minecraft/world/item/ItemStack;"
    )
    )
    private class_1799 createResult(class_1799 itemStack) {
        class_1657 player = EventImplHelper.getPlayerFromContainerMenu(this);
        if (player != null) {
            class_1799 primaryItemStack = this.repairSlots.method_5438(0);
            class_1799 secondaryItemStack = this.repairSlots.method_5438(1);
            MutableValue<class_1799> outputItemStack = MutableValue.fromValue(itemStack);
            MutableInt experiencePointReward = MutableInt.fromEvent((int i) -> this.puzzleslib$experiencePointReward = OptionalInt.of(
                    i), () -> 0);
            EventResult eventResult = FabricPlayerEvents.CREATE_GRINDSTONE_RESULT.invoker()
                    .onCreateGrindstoneResult(player,
                            primaryItemStack,
                            secondaryItemStack,
                            outputItemStack,
                            experiencePointReward);
            if (eventResult.isInterrupt()) {
                this.puzzleslib$experiencePointReward = OptionalInt.empty();
                return class_1799.field_8037;
            } else {
                return outputItemStack.get();
            }
        } else {
            return itemStack;
        }
    }

    @Override
    public OptionalInt puzzleslib$getExperiencePointReward() {
        return this.puzzleslib$experiencePointReward;
    }
}
