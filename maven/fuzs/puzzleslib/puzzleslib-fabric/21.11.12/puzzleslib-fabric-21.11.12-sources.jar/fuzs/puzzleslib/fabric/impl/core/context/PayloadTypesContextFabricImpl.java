package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.network.v4.message.Message;
import fuzs.puzzleslib.api.network.v4.message.configuration.ClientboundConfigurationMessage;
import fuzs.puzzleslib.api.network.v4.message.configuration.ServerboundConfigurationMessage;
import fuzs.puzzleslib.api.network.v4.message.play.ClientboundPlayMessage;
import fuzs.puzzleslib.api.network.v4.message.play.ServerboundPlayMessage;
import fuzs.puzzleslib.fabric.impl.network.MessageContextFabricImpl;
import fuzs.puzzleslib.impl.core.context.PayloadTypesContextImpl;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

public abstract class PayloadTypesContextFabricImpl extends PayloadTypesContextImpl {

    PayloadTypesContextFabricImpl(String modId) {
        super(modId);
    }

    @Override
    public <T extends ServerboundPlayMessage> void playToServer(Class<T> clazz, class_9139<? super class_9129, T> streamCodec) {
        this.playToServer(this.registerPayloadType(clazz), streamCodec, clazz::getSimpleName);
    }

    @Override
    public <T extends ServerboundConfigurationMessage> void configurationToServer(Class<T> clazz, class_9139<? super class_2540, T> streamCodec) {
        this.configurationToServer(this.registerPayloadType(clazz), streamCodec, clazz::getSimpleName);
    }

    @Override
    public <T extends ServerboundPlayMessage> void playToServer(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec) {
        this.playToServer(payloadType, streamCodec, payloadType.comp_2242()::toString);
    }

    @Override
    public <T extends ServerboundConfigurationMessage> void configurationToServer(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec) {
        this.configurationToServer(payloadType, streamCodec, payloadType.comp_2242()::toString);
    }

    @Override
    public void optional() {
        // NO-OP
    }

    <T extends ServerboundPlayMessage> void playToServer(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec, Supplier<String> payloadContextSupplier) {
        this.register(payloadType,
                streamCodec,
                PayloadTypeRegistry.playC2S(),
                (class_8710.class_9154<T> type, BiConsumer<T, ServerPlayNetworking.Context> consumer) -> {
                    ServerPlayNetworking.registerGlobalReceiver(type, consumer::accept);
                },
                MessageContextFabricImpl.ServerboundPlay::new,
                payloadContextSupplier);
    }

    <T extends ServerboundConfigurationMessage> void configurationToServer(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec, Supplier<String> payloadContextSupplier) {
        this.register(payloadType,
                streamCodec,
                PayloadTypeRegistry.configurationC2S(),
                (class_8710.class_9154<T> type, BiConsumer<T, ServerConfigurationNetworking.Context> consumer) -> {
                    ServerConfigurationNetworking.registerGlobalReceiver(type, consumer::accept);
                },
                MessageContextFabricImpl.ServerboundConfiguration::new,
                payloadContextSupplier);
    }

    <B extends class_2540, T extends Message<C2>, C2 extends Message.Context<?>, C1> void register(class_8710.class_9154<T> payloadType, class_9139<? super B, T> streamCodec, PayloadTypeRegistry<B> registrar, PayloadRegistrar<T, C1> receiverRegistrar, Function<C1, C2> contextFactory, Supplier<String> payloadContextSupplier) {
        registrar.register(payloadType, streamCodec);
        receiverRegistrar.apply(payloadType, (T payload, C1 context) -> {
            C2 c2 = contextFactory.apply(context);
            try {
                payload.getListener().accept(c2);
            } catch (Throwable throwable) {
                this.disconnectExceptionally(payloadContextSupplier.get()).accept(throwable, c2::disconnect);
            }
        });
    }

    @FunctionalInterface
    interface PayloadRegistrar<T extends class_8710, C> {

        void apply(class_8710.class_9154<T> type, BiConsumer<T, C> consumer);
    }

    public static class ServerImpl extends PayloadTypesContextFabricImpl {

        public ServerImpl(String modId) {
            super(modId);
        }

        @Override
        public <T extends ClientboundPlayMessage> void playToClient(Class<T> clazz, class_9139<? super class_9129, T> streamCodec) {
            this.registerWithoutReceiver(this.registerPayloadType(clazz), streamCodec, PayloadTypeRegistry.playS2C());
        }

        @Override
        public <T extends ClientboundConfigurationMessage> void configurationToClient(Class<T> clazz, class_9139<? super class_2540, T> streamCodec) {
            this.registerWithoutReceiver(this.registerPayloadType(clazz),
                    streamCodec,
                    PayloadTypeRegistry.configurationS2C());
        }

        @Override
        public <T extends ClientboundPlayMessage> void playToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec) {
            this.registerWithoutReceiver(payloadType, streamCodec, PayloadTypeRegistry.playS2C());
        }

        @Override
        public <T extends ClientboundConfigurationMessage> void configurationToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec) {
            this.registerWithoutReceiver(payloadType, streamCodec, PayloadTypeRegistry.configurationS2C());
        }

        <B extends class_2540, T extends Message<C>, C extends Message.Context<?>> void registerWithoutReceiver(class_8710.class_9154<T> payloadType, class_9139<? super B, T> streamCodec, PayloadTypeRegistry<B> registrar) {
            this.register(payloadType,
                    streamCodec,
                    registrar,
                    (class_8710.class_9154<T> type, BiConsumer<T, Object> consumer) -> {
                        // NO-OP
                    },
                    (Object o) -> null,
                    () -> "");
        }
    }

    public static class ClientImpl extends PayloadTypesContextFabricImpl {

        public ClientImpl(String modId) {
            super(modId);
        }

        @Override
        public <T extends ClientboundPlayMessage> void playToClient(Class<T> clazz, class_9139<? super class_9129, T> streamCodec) {
            this.playToClient(this.registerPayloadType(clazz), streamCodec, clazz::getSimpleName);
        }

        @Override
        public <T extends ClientboundConfigurationMessage> void configurationToClient(Class<T> clazz, class_9139<? super class_2540, T> streamCodec) {
            this.configurationToClient(this.registerPayloadType(clazz), streamCodec, clazz::getSimpleName);
        }

        @Override
        public <T extends ClientboundPlayMessage> void playToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec) {
            this.playToClient(payloadType, streamCodec, payloadType.comp_2242()::toString);
        }

        @Override
        public <T extends ClientboundConfigurationMessage> void configurationToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec) {
            this.configurationToClient(payloadType, streamCodec, payloadType.comp_2242()::toString);
        }

        <T extends ClientboundPlayMessage> void playToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec, Supplier<String> payloadContextSupplier) {
            this.register(payloadType,
                    streamCodec,
                    PayloadTypeRegistry.playS2C(),
                    (class_8710.class_9154<T> type, BiConsumer<T, ClientPlayNetworking.Context> consumer) -> {
                        ClientPlayNetworking.registerGlobalReceiver(type, consumer::accept);
                    },
                    MessageContextFabricImpl.ClientboundPlay::new,
                    payloadContextSupplier);
        }

        <T extends ClientboundConfigurationMessage> void configurationToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec, Supplier<String> payloadContextSupplier) {
            this.register(payloadType,
                    streamCodec,
                    PayloadTypeRegistry.configurationS2C(),
                    (class_8710.class_9154<T> type, BiConsumer<T, ClientConfigurationNetworking.Context> consumer) -> {
                        ClientConfigurationNetworking.registerGlobalReceiver(type, consumer::accept);
                    },
                    MessageContextFabricImpl.ClientboundConfiguration::new,
                    payloadContextSupplier);
        }
    }
}
