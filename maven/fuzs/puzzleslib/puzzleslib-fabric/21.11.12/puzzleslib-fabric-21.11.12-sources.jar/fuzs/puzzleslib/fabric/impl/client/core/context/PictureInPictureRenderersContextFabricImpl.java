package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.PictureInPictureRenderersContext;
import net.fabricmc.fabric.api.client.rendering.v1.SpecialGuiElementRegistry;
import net.minecraft.class_11239;
import net.minecraft.class_11256;
import net.minecraft.class_4597;
import java.util.Objects;
import java.util.function.Function;

public final class PictureInPictureRenderersContextFabricImpl implements PictureInPictureRenderersContext {

    @Override
    public <T extends class_11256> void registerPictureInPictureRenderer(Class<T> renderStateClazz, Function<class_4597.class_4598, class_11239<T>> pictureInPictureRendererFactory) {
        Objects.requireNonNull(renderStateClazz, "class is null");
        Objects.requireNonNull(pictureInPictureRendererFactory, "factory is null");
        SpecialGuiElementRegistry.register((SpecialGuiElementRegistry.Context context) -> {
            return pictureInPictureRendererFactory.apply(context.vertexConsumers());
        });
    }
}
