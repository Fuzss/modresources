package fuzs.puzzleslib.api.client.data.v2.models;

import net.minecraft.class_10410;
import net.minecraft.class_10411;
import net.minecraft.class_10439;
import net.minecraft.class_10502;
import net.minecraft.class_10515;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2484;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.client.data.models.model.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

public final class ItemModelGenerationHelper {
    public static final class_4942 HORN = ModelTemplateHelper.createItemModelTemplate(class_2960.method_60656(
            "goat_horn"), class_4945.field_23006);
    public static final class_4942 TOOTING_HORN = ModelTemplateHelper.createItemModelTemplate(class_2960.method_60656(
            "tooting_goat_horn"), class_4945.field_23006);
    public static final class_4942 SHIELD_MODEL_TEMPLATE = ModelTemplateHelper.createItemModelTemplate(class_2960.method_60656(
            "shield"), class_4945.field_23012);
    public static final class_4942 SHIELD_BLOCKING_MODEL_TEMPLATE = ModelTemplateHelper.createItemModelTemplate(
            class_2960.method_60656("shield_blocking"),
            class_4945.field_23012);

    private ItemModelGenerationHelper() {
        // NO-OP
    }

    public static void generateFlatItem(class_1792 item, class_4942 modelTemplate, class_4915 itemModelGenerators) {
        itemModelGenerators.field_55245.method_75343(item,
                class_10410.method_65481(createFlatItemModel(item, modelTemplate, itemModelGenerators.field_55246)));
    }

    public static class_2960 createFlatItemModel(class_1792 item, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return createFlatItemModel(item, item, modelTemplate, modelOutput);
    }

    public static void generateFlatItem(class_1792 item, class_1792 layerItem, class_4942 modelTemplate, class_4915 itemModelGenerators) {
        itemModelGenerators.field_55245.method_75343(item,
                class_10410.method_65481(createFlatItemModel(item,
                        layerItem,
                        modelTemplate,
                        itemModelGenerators.field_55246)));
    }

    public static class_2960 createFlatItemModel(class_1792 item, class_1792 layerItem, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return createFlatItemModel(item, ModelLocationHelper.getItemModel(layerItem), modelTemplate, modelOutput);
    }

    public static void generateFlatItem(class_1792 item, class_2960 layer0Location, class_4942 modelTemplate, class_4915 itemModelGenerators) {
        itemModelGenerators.field_55245.method_75343(item,
                class_10410.method_65481(createFlatItemModel(item,
                        layer0Location,
                        modelTemplate,
                        itemModelGenerators.field_55246)));
    }

    public static class_2960 createFlatItemModel(class_1792 item, class_2960 layer0Location, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return createFlatItemModel(ModelLocationHelper.getItemModel(item), layer0Location, modelTemplate, modelOutput);
    }

    public static class_2960 createFlatItemModel(class_2960 identifier, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return createFlatItemModel(identifier, identifier, modelTemplate, modelOutput);
    }

    public static class_2960 createFlatItemModel(class_2960 identifier, class_2960 layer0Location, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return modelTemplate.method_25852(identifier, class_4944.method_25895(layer0Location), modelOutput);
    }

    public static void generateLayeredItem(class_1792 item, class_2960 layer0Location, class_2960 layer1Location, class_4942 modelTemplate, class_4915 itemModelGenerators) {
        itemModelGenerators.field_55245.method_75343(item,
                class_10410.method_65481(createLayeredItemModel(item,
                        layer0Location,
                        layer1Location,
                        modelTemplate,
                        itemModelGenerators.field_55246)));
    }

    public static class_2960 createLayeredItemModel(class_1792 item, class_2960 layer0Location, class_2960 layer1Location, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return createLayeredItemModel(ModelLocationHelper.getItemModel(item),
                layer0Location,
                layer1Location,
                modelTemplate,
                modelOutput);
    }

    public static class_2960 createLayeredItemModel(class_2960 identifier, class_2960 layer0Location, class_2960 layer1Location, class_4942 modelTemplate, BiConsumer<class_2960, class_10411> modelOutput) {
        return modelTemplate.method_25852(identifier, class_4944.method_48529(layer0Location, layer1Location), modelOutput);
    }

    /**
     * @see class_4915#method_65446(class_1792)
     */
    public static void generateBow(class_1792 item, class_4915 itemModelGenerators) {
        itemModelGenerators.method_65434(item, class_4943.field_55255);
        itemModelGenerators.method_65446(item);
    }

    /**
     * @see class_4915#method_65451(class_1792)
     */
    public static void generateHorn(class_1792 item, class_4915 itemModelGenerators) {
        class_10439.class_10441 baseModel = class_10410.method_65481(itemModelGenerators.method_65434(item, HORN));
        class_10439.class_10441 tootingModel = class_10410.method_65481(createFlatItemModel(ModelLocationHelper.getItemModel(
                item,
                "_tooting"), ModelLocationHelper.getItemModel(item), TOOTING_HORN, itemModelGenerators.field_55246));
        itemModelGenerators.method_65436(item, class_10410.method_65479(), tootingModel, baseModel);
    }

    /**
     * @see class_4910#method_65406(class_2248, class_2248, class_2484.class_2485, class_2960)
     */
    public static void generateHead(class_2248 headBlock, class_2248 wallHeadBlock, class_2484.class_2485 type, class_4910 blockModelGenerators) {
        blockModelGenerators.method_65406(headBlock,
                wallHeadBlock,
                type,
                class_4941.method_25845("template_skull"));
    }

    /**
     * @see class_4915#method_65452(class_1792)
     */
    public static void generateShield(class_1792 item, class_2248 particleBlock, Supplier<class_10515.class_10516> specialModelSupplier, class_4915 itemModelGenerators) {
        class_2960 baseModel = SHIELD_MODEL_TEMPLATE.method_25852(ModelLocationHelper.getItemModel(item),
                class_4944.method_25901(particleBlock),
                itemModelGenerators.field_55246);
        class_2960 blockingModel = SHIELD_BLOCKING_MODEL_TEMPLATE.method_25852(ModelLocationHelper.getItemModel(item,
                "_blocking"), class_4944.method_25901(particleBlock), itemModelGenerators.field_55246);
        class_10439.class_10441 unbaked = class_10410.method_65482(baseModel, specialModelSupplier.get());
        class_10439.class_10441 unbaked2 = class_10410.method_65482(blockingModel, specialModelSupplier.get());
        itemModelGenerators.method_65436(item, class_10410.method_65479(), unbaked2, unbaked);
    }

    /**
     * @see class_4910#method_65404(class_2248, class_2248, class_2960, boolean)
     */
    public static void generateChest(class_2248 chestBlock, class_2248 particleBlock, class_2960 itemTexture, boolean useGiftTexture, Function<class_2960, class_10515.class_10516> unbakedRendererFactory, class_4910 blockModelGenerators) {
        blockModelGenerators.method_65403(chestBlock, particleBlock);
        class_1792 item = chestBlock.method_8389();
        class_2960 identifier = class_4943.field_55252.method_48525(item,
                class_4944.method_25901(particleBlock),
                blockModelGenerators.field_22831);
        class_10439.class_10441 itemModel = class_10410.method_65482(identifier,
                unbakedRendererFactory.apply(itemTexture));
        if (useGiftTexture) {
            class_10439.class_10441 unbaked2 = class_10410.method_65482(identifier,
                    new class_10502.class_10503(class_10502.field_55429));
            blockModelGenerators.field_55238.method_75343(item, class_10410.method_65808(unbaked2, itemModel));
        } else {
            blockModelGenerators.field_55238.method_75343(item, itemModel);
        }
    }
}
