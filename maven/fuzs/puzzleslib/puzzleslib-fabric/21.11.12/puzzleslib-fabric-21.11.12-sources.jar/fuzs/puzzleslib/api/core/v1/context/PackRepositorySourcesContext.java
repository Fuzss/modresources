package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3285;

/**
 * Register custom and built-in data &amp; resource packs.
 */
public interface PackRepositorySourcesContext {

    /**
     * Register an additional {@link class_3285} when a new
     * {@link net.minecraft.class_3283} is created.
     * <p>
     * Context can be used for registering both client (for resource packs) and server (for data packs) repository
     * sources.
     *
     * @param repositorySource the repository source to add
     */
    void registerRepositorySource(class_3285 repositorySource);

    /**
     * Register a built-in pack bundled with the mod.
     * <ul>
     *     <li>Data pack path: {@code data/<modId>/datapacks/<path>}</li>
     *     <li>Resource pack path: {@code assets/<modId>/resourcepacks/<path>}</li>
     * </ul>
     *
     * @param identifier       the name of the pack in the {@code resources} directory
     * @param displayName            the name component for the created pack
     * @param shouldAddAutomatically is this pack always enabled and cannot be turned off
     */
    void registerBuiltInPack(class_2960 identifier, class_2561 displayName, boolean shouldAddAutomatically);
}
