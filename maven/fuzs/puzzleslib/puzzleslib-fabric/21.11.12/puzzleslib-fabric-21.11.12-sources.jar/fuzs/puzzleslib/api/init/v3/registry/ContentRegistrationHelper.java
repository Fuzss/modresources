package fuzs.puzzleslib.api.init.v3.registry;

import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.event.v1.CommonSetupCallback;
import fuzs.puzzleslib.impl.item.CustomTransmuteRecipe;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_173;
import net.minecraft.class_176;
import net.minecraft.class_1865;
import net.minecraft.class_2484;
import net.minecraft.class_2960;
import net.minecraft.class_7924;

/**
 * Contains methods for registering various gameplay content.
 */
public final class ContentRegistrationHelper {

    private ContentRegistrationHelper() {
        // NO-OP
    }

    /**
     * Registers mod-specific recipe serializers for custom transmute recipes.
     *
     * @param registryManager the registry manager instance
     */
    public static void registerTransmuteRecipeSerializers(RegistryManager registryManager) {
        CustomTransmuteRecipe.registerSerializers((String string, Supplier<class_1865<?>> recipeSerializerSupplier) -> {
            registryManager.register(class_7924.field_41216, string, recipeSerializerSupplier);
        });
    }

    /**
     * Registers a new skull block type.
     *
     * @param identifier the name used for the skull block type
     * @return the skull block type
     */
    public static class_2484.class_2485 registerSkullBlockType(class_2960 identifier) {
        String string = identifier.toString();
        class_2484.class_2485 skullBlockType = () -> string;
        CommonSetupCallback.EVENT.register(() -> {
            class_2484.class_2485.field_46442.put(skullBlockType.method_15434(), skullBlockType);
        });
        return skullBlockType;
    }

    /**
     * Creates and registers a new {@link class_176}.
     *
     * @param identifier the identifier for the registry
     * @param builderConsumer  the consumer for configuring the builder
     * @return the created context key set
     */
    public static class_176 registerContextKeySet(class_2960 identifier, Consumer<class_176.class_177> builderConsumer) {
        class_176.class_177 builder = new class_176.class_177();
        builderConsumer.accept(builder);
        class_176 contextKeySet = builder.method_782();
        if (ModLoaderEnvironment.INSTANCE.isDataGeneration()) {
            // run this immediately, as the common setup does not run during data generation, but we need this for generating loot tables
            // this can only ever run in a development environment where no other mods conflicting here will be present
            registerContextKeySet(identifier, contextKeySet);
        } else {
            // delay this, as the underlying registry map is not concurrent, possibly leading to issues with other mods on NeoForge
            CommonSetupCallback.EVENT.register(() -> {
                registerContextKeySet(identifier, contextKeySet);
            });
        }

        return contextKeySet;
    }

    private static void registerContextKeySet(class_2960 identifier, class_176 contextKeySet) {
        if (class_173.field_1178.put(identifier, contextKeySet) != null) {
            throw new IllegalStateException("Loot context key set " + identifier + " is already registered");
        }
    }
}
