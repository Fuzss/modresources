package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_2960;
import net.minecraft.class_3302;
import net.minecraft.class_4013;
import net.minecraft.class_4080;
import net.minecraft.class_5350;
import net.minecraft.class_7225;

/**
 * Adds listeners to the server (data packs) resource manager to reload together with other resources.
 */
public interface DataPackReloadListenersContext {
    /**
     * The {@link net.minecraft.class_1863} reload listener.
     */
    class_2960 RECIPES = class_2960.method_60656("recipes");
    /**
     * The {@link net.minecraft.class_5349} reload listener.
     */
    class_2960 FUNCTIONS = class_2960.method_60656("functions");
    /**
     * The {@link net.minecraft.class_2989} reload listener.
     */
    class_2960 ADVANCEMENTS = class_2960.method_60656("advancements");

    /**
     * Register a {@link class_3302}.
     *
     * @param identifier            the reload listener identifier
     * @param reloadListenerFactory the reload listener factory
     */
    void registerReloadListener(class_2960 identifier, PreparableReloadListenerFactory reloadListenerFactory);

    /**
     * Register a {@link class_3302}.
     *
     * @param identifier            the reload listener identifier
     * @param otherIdentifier       the other reload listener identifier, either for the new listener or for the
     *                              existing vanilla listener
     * @param reloadListenerFactory the reload listener factory
     */
    void registerReloadListener(class_2960 identifier, class_2960 otherIdentifier, PreparableReloadListenerFactory reloadListenerFactory);

    /**
     * Register a {@link class_4013}.
     *
     * @param identifier            the reload listener identifier
     * @param reloadListenerFactory the reload listener factory
     */
    default void registerReloadListener(class_2960 identifier, ResourceManagerReloadListenerFactory reloadListenerFactory) {
        this.registerReloadListener(identifier, (PreparableReloadListenerFactory) reloadListenerFactory::apply);
    }

    /**
     * Register a {@link class_4013}.
     *
     * @param identifier            the reload listener identifier, either for the new listener or for the existing
     *                              vanilla listener
     * @param otherIdentifier       the other reload listener identifier, either for the new listener or for the
     *                              existing vanilla listener
     * @param reloadListenerFactory the reload listener factory
     */
    default void registerReloadListener(class_2960 identifier, class_2960 otherIdentifier, ResourceManagerReloadListenerFactory reloadListenerFactory) {
        this.registerReloadListener(identifier,
                otherIdentifier,
                (PreparableReloadListenerFactory) reloadListenerFactory::apply);
    }

    /**
     * Register a {@link class_4080}.
     *
     * @param identifier            the reload listener identifier, either for the new listener or for the existing
     *                              vanilla listener
     * @param reloadListenerFactory the reload listener factory
     */
    default <T> void registerReloadListener(class_2960 identifier, SimplePreparableReloadListenerFactory<T> reloadListenerFactory) {
        this.registerReloadListener(identifier, (PreparableReloadListenerFactory) reloadListenerFactory::apply);
    }

    /**
     * Register a {@link class_4080}.
     *
     * @param identifier            the reload listener identifier, either for the new listener or for the existing
     *                              vanilla listener
     * @param otherIdentifier       the other reload listener identifier, either for the new listener or for the
     *                              existing vanilla listener
     * @param reloadListenerFactory the reload listener factory
     */
    default <T> void registerReloadListener(class_2960 identifier, class_2960 otherIdentifier, SimplePreparableReloadListenerFactory<T> reloadListenerFactory) {
        this.registerReloadListener(identifier,
                otherIdentifier,
                (PreparableReloadListenerFactory) reloadListenerFactory::apply);
    }

    @FunctionalInterface
    interface PreparableReloadListenerFactory {
        class_3302 apply(class_5350 serverResources, class_7225.class_7874 lookupWithUpdatedTags);
    }

    @FunctionalInterface
    interface ResourceManagerReloadListenerFactory {
        class_4013 apply(class_5350 serverResources, class_7225.class_7874 lookupWithUpdatedTags);
    }

    @FunctionalInterface
    interface SimplePreparableReloadListenerFactory<T> {
        class_4080<T> apply(class_5350 serverResources, class_7225.class_7874 lookupWithUpdatedTags);
    }
}
