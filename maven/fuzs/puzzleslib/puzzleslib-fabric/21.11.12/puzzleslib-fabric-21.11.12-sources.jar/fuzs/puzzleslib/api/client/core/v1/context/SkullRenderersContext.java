package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.Function;
import net.minecraft.class_2484;
import net.minecraft.class_2960;
import net.minecraft.class_5598;
import net.minecraft.class_5599;

/**
 * Register models for custom {@link net.minecraft.class_2484.class_2485} implementations.
 */
public interface SkullRenderersContext {

    /**
     * @param skullBlockType    the skull block type
     * @param textureLocation   the texture location, usually for the corresponding entity
     * @param skullModelFactory the skull model factory
     */
    void registerSkullRenderer(class_2484.class_2485 skullBlockType, class_2960 textureLocation, Function<class_5599, class_5598> skullModelFactory);
}
