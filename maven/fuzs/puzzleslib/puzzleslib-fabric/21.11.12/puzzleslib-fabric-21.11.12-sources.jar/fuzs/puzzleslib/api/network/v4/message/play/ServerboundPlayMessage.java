package fuzs.puzzleslib.api.network.v4.message.play;

import fuzs.puzzleslib.api.network.v4.NetworkingHelper;
import fuzs.puzzleslib.api.network.v4.message.Message;
import net.minecraft.class_2596;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_8706;
import net.minecraft.server.MinecraftServer;

/**
 * Template for a message sent by the client and received by the server during the play phase.
 */
public interface ServerboundPlayMessage extends Message<ServerboundPlayMessage.Context> {

    @Override
    default class_2596<class_8706> toPacket() {
        return NetworkingHelper.toServerboundPacket(this);
    }

    /**
     * The context provided in {@link #getListener()}.
     */
    interface Context extends Message.Context<class_3244> {

        /**
         * @return the server
         */
        MinecraftServer server();

        /**
         * @return the player
         */
        class_3222 player();

        /**
         * @return the level
         */
        class_3218 level();
    }
}
