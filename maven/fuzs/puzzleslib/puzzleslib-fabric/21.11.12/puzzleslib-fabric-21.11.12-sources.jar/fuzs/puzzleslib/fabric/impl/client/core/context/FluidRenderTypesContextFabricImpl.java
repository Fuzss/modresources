package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import java.util.Objects;

public final class FluidRenderTypesContextFabricImpl implements RenderTypesContext<class_3611> {

    @Override
    public void registerChunkRenderType(class_3611 fluid, class_11515 chunkSectionLayer) {
        Objects.requireNonNull(fluid, "fluid is null");
        Objects.requireNonNull(chunkSectionLayer, "chunk section layer is null");
        BlockRenderLayerMap.putFluid(fluid, chunkSectionLayer);
    }

    @Override
    public class_11515 getChunkRenderType(class_3611 fluid) {
        Objects.requireNonNull(fluid, "fluid is null");
        return class_4696.method_23680(fluid.method_15785());
    }
}
