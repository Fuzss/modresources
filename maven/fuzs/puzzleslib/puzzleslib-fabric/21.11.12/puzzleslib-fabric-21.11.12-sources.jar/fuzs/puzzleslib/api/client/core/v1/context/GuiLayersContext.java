package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.ToIntFunction;
import java.util.function.UnaryOperator;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Register new {@link Layer Layers} to be drawn as part of the {@link net.minecraft.class_329}.
 */
public interface GuiLayersContext {
    /**
     * The layer for rendering camera-related overlays like pumpkin blur.
     */
    class_2960 CAMERA_OVERLAYS = class_2960.method_60656("camera_overlays");
    /**
     * The layer for rendering the crosshair.
     */
    class_2960 CROSSHAIR = class_2960.method_60656("crosshair");
    /**
     * The layer for rendering the hotbar.
     */
    class_2960 HOTBAR = class_2960.method_60656("hotbar");
    /**
     * The layer for rendering the info bars, like the experience bar, the locator bar, or the jump meter (e.g. for
     * horses).
     */
    class_2960 INFO_BAR = class_2960.method_60656("info_bar");
    /**
     * The layer for rendering the player's health hearts.
     */
    class_2960 PLAYER_HEALTH = class_2960.method_60656("player_health");
    /**
     * The layer for rendering the player's armor level.
     */
    class_2960 ARMOR_LEVEL = class_2960.method_60656("armor_level");
    /**
     * The layer for rendering the player's food level.
     */
    class_2960 FOOD_LEVEL = class_2960.method_60656("food_level");
    /**
     * The layer for rendering the health of the player's vehicle.
     */
    class_2960 VEHICLE_HEALTH = class_2960.method_60656("vehicle_health");
    /**
     * The layer for rendering the player's air level when submerged.
     */
    class_2960 AIR_LEVEL = class_2960.method_60656("air_level");
    /**
     * The layer for rendering the name of the selected item.
     */
    class_2960 HELD_ITEM_TOOLTIP = class_2960.method_60656("held_item_tooltip");
    /**
     * The layer for rendering the player's experience level number.
     */
    class_2960 EXPERIENCE_LEVEL = class_2960.method_60656("experience_level");
    /**
     * The layer for rendering the selected spectator menu action.
     */
    class_2960 SPECTATOR_TOOLTIP = class_2960.method_60656("spectator_tooltip");
    /**
     * The layer for rendering status effect icons.
     */
    class_2960 STATUS_EFFECTS = class_2960.method_60656("status_effects");
    /**
     * The layer for rendering boss bars.
     */
    class_2960 BOSS_BAR = class_2960.method_60656("boss_bar");
    /**
     * The layer for rendering the sleep overlay.
     */
    class_2960 SLEEP_OVERLAY = class_2960.method_60656("sleep_overlay");
    /**
     * The layer for rendering the demo mode timer.
     */
    class_2960 DEMO_TIMER = class_2960.method_60656("demo_timer");
    /**
     * The layer for rendering the scoreboard.
     */
    class_2960 SCOREBOARD = class_2960.method_60656("scoreboard");
    /**
     * The layer for rendering overlay messages (e.g., action bar text).
     */
    class_2960 OVERLAY_MESSAGE = class_2960.method_60656("overlay_message");
    /**
     * The layer for rendering titles and subtitles.
     */
    class_2960 TITLE = class_2960.method_60656("title");
    /**
     * The layer for rendering the chat interface.
     */
    class_2960 CHAT = class_2960.method_60656("chat");
    /**
     * The layer for rendering the player list (tab menu).
     */
    class_2960 PLAYER_LIST = class_2960.method_60656("player_list");
    /**
     * The layer for rendering subtitles.
     */
    class_2960 SUBTITLES = class_2960.method_60656("subtitles");

    /**
     * Register a new gui layer rendered after all existing layers.
     *
     * @param identifier the gui layer identifier
     * @param guiLayer         the gui layer
     */
    void registerGuiLayer(class_2960 identifier, Layer guiLayer);

    /**
     * Register a new gui layer rendered before or after an existing vanilla gui layer.
     * <p>
     * The ordering depends on the order in which both identifier arguments are passed.
     *
     * @param identifier the gui layer identifier, either for the new layer or for the existing vanilla
     *                         layer
     * @param otherIdentifier  the other gui layer identifier, either for the new layer or for the existing
     *                         vanilla layer
     * @param guiLayer         the gui layer
     */
    void registerGuiLayer(class_2960 identifier, class_2960 otherIdentifier, Layer guiLayer);

    /**
     * Replace an existing vanilla gui layer. Replacing custom layers is not supported.
     *
     * @param identifier the vanilla gui layer identifier
     * @param guiLayerFactory  the gui layer factory, receiving the existing layer
     */
    void replaceGuiLayer(class_2960 identifier, UnaryOperator<Layer> guiLayerFactory);

    /**
     * Register an additional height provider for a status bar layer rendered on the left side above the hotbar.
     * <p>
     * This is required for proper vertical positioning of the layer together with all other registered status bars.
     * <p>
     * To retrieve the render height for a status bar during rendering of the layer use
     * {@link fuzs.puzzleslib.api.client.gui.v2.ScreenHelper#getLeftStatusBarHeight(class_2960)}.
     *
     * @param identifier the gui layer identifier
     * @param heightProvider   the status bar height provider
     */
    void addLeftStatusBarHeightProvider(class_2960 identifier, ToIntFunction<class_1657> heightProvider);

    /**
     * Register an additional height provider for a status bar layer rendered on the right side above the hotbar.
     * <p>
     * This is required for proper vertical positioning of the layer together with all other registered status bars.
     * <p>
     * To retrieve the render height for a status bar during rendering of the layer use
     * {@link fuzs.puzzleslib.api.client.gui.v2.ScreenHelper#getRightStatusBarHeight(class_2960)}.
     *
     * @param identifier the gui layer identifier
     * @param heightProvider   the status bar height provider
     */
    void addRightStatusBarHeightProvider(class_2960 identifier, ToIntFunction<class_1657> heightProvider);

    @FunctionalInterface
    interface Layer {

        /**
         * Renders the gui layer.
         *
         * @param guiGraphics  the gui graphics
         * @param deltaTracker the delta tracker
         */
        void render(class_332 guiGraphics, class_9779 deltaTracker);
    }
}
