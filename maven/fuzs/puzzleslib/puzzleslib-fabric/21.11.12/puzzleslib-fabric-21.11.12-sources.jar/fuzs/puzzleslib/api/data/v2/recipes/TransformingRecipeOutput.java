package fuzs.puzzleslib.api.data.v2.recipes;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import org.jspecify.annotations.Nullable;

import java.util.function.UnaryOperator;
import net.minecraft.class_161;
import net.minecraft.class_1860;
import net.minecraft.class_5321;
import net.minecraft.class_8779;
import net.minecraft.class_8790;

/**
 * Allows for using vanilla recipe builders with custom recipe implementations based on vanilla recipe types.
 */
public interface TransformingRecipeOutput extends class_8790 {

    static class_8790 transformed(class_8790 recipeOutput, UnaryOperator<class_1860<?>> operator) {
        return ProxyImpl.get().getTransformingRecipeOutput(recipeOutput, operator);
    }

    class_8790 recipeOutput();

    UnaryOperator<class_1860<?>> operator();

    @Override
    default void method_53819(class_5321<class_1860<?>> key, class_1860<?> recipe, @Nullable class_8779 advancement) {
        this.recipeOutput().method_53819(key, this.operator().apply(recipe), advancement);
    }

    @Override
    default class_161.class_162 method_53818() {
        return this.recipeOutput().method_53818();
    }

    @Override
    default void method_62738() {
        this.recipeOutput().method_62738();
    }
}
