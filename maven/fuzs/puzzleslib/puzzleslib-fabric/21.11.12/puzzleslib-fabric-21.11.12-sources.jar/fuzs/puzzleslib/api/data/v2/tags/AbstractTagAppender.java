package fuzs.puzzleslib.api.data.v2.tags;

import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_11389;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;

public abstract class AbstractTagAppender<T> implements class_11389<T, T> {
    protected final class_3495 tagBuilder;
    @Nullable private final Function<T, class_5321<T>> keyExtractor;

    public AbstractTagAppender(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        this.tagBuilder = tagBuilder;
        this.keyExtractor = keyExtractor;
    }

    public abstract AbstractTagAppender<T> setReplace(boolean replace);

    public AbstractTagAppender<T> setReplace() {
        return this.setReplace(true);
    }

    public AbstractTagAppender<T> add(class_2960 identifier) {
        this.tagBuilder.method_26784(identifier);
        return this;
    }

    public AbstractTagAppender<T> add(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.add(identifier);
        }

        return this;
    }

    public AbstractTagAppender<T> addKey(class_5321<? extends T> resourceKey) {
        return this.add(resourceKey.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addKey(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.addKey(resourceKey);
        }

        return this;
    }

    @Override
    public AbstractTagAppender<T> method_71554(T value) {
        return this.addKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    @Override
    public final AbstractTagAppender<T> method_71558(T... values) {
        for (T value : values) {
            this.method_71554(value);
        }

        return this;
    }

    public AbstractTagAppender<T> add(class_6880.class_6883<? extends T> holder) {
        return this.addKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> add(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.add(holder);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptional(String string) {
        return this.addOptional(class_2960.method_60654(string));
    }

    public AbstractTagAppender<T> addOptional(String... strings) {
        for (String string : strings) {
            this.addOptional(string);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptional(class_2960 identifier) {
        this.tagBuilder.method_34891(identifier);
        return this;
    }

    public AbstractTagAppender<T> addOptional(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.add(identifier);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptionalKey(class_5321<? extends T> resourceKey) {
        return this.addOptional(resourceKey.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptionalKey(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.addOptionalKey(resourceKey);
        }

        return this;
    }

    @Override
    public AbstractTagAppender<T> method_71560(T value) {
        return this.addOptionalKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptional(T... values) {
        for (T value : values) {
            this.method_71560(value);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptional(class_6880.class_6883<? extends T> holder) {
        return this.addOptionalKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptional(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.addOptional(holder);
        }

        return this;
    }

    public AbstractTagAppender<T> addTag(class_2960 identifier) {
        this.tagBuilder.method_26787(identifier);
        return this;
    }

    public AbstractTagAppender<T> addTag(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.addTag(identifier);
        }

        return this;
    }

    @Override
    public AbstractTagAppender<T> method_71553(class_6862<T> tagKey) {
        return this.addTag(tagKey.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addTag(class_6862<T>... tagKeys) {
        for (class_6862<T> tagKey : tagKeys) {
            this.method_71553(tagKey);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(String string) {
        return this.addOptionalTag(class_2960.method_60654(string));
    }

    public AbstractTagAppender<T> addOptionalTag(String... strings) {
        for (String string : strings) {
            this.addOptionalTag(string);
        }

        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_2960 identifier) {
        this.tagBuilder.method_34892(identifier);
        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.addOptionalTag(identifier);
        }

        return this;
    }

    @Override
    public AbstractTagAppender<T> method_71559(class_6862<T> tagKey) {
        return this.addOptionalTag(tagKey.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> addOptionalTag(class_6862<T>... tagKeys) {
        for (class_6862<T> tagKey : tagKeys) {
            this.method_71559(tagKey);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> remove(class_2960 identifier);

    public AbstractTagAppender<T> remove(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.remove(identifier);
        }

        return this;
    }

    public AbstractTagAppender<T> removeKey(class_5321<? extends T> resourceKey) {
        return this.remove(resourceKey.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeKey(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.removeKey(resourceKey);
        }

        return this;
    }

    public AbstractTagAppender<T> remove(T value) {
        return this.removeKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> remove(T... values) {
        for (T value : values) {
            this.remove(value);
        }

        return this;
    }

    public AbstractTagAppender<T> remove(class_6880.class_6883<? extends T> holder) {
        return this.removeKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> remove(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.remove(holder);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptional(String string) {
        return this.removeOptional(class_2960.method_60654(string));
    }

    public AbstractTagAppender<T> removeOptional(String... strings) {
        for (String string : strings) {
            this.removeOptional(string);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> removeOptional(class_2960 identifier);

    public AbstractTagAppender<T> removeOptional(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.removeOptional(identifier);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptionalKey(class_5321<? extends T> resourceKey) {
        return this.removeOptional(resourceKey.method_29177());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptionalKey(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.removeOptionalKey(resourceKey);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptional(T value) {
        return this.removeOptionalKey(this.keyExtractor().apply(value));
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptional(T... values) {
        for (T value : values) {
            this.removeOptional(value);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptional(class_6880.class_6883<? extends T> holder) {
        return this.removeOptionalKey(holder.method_40237());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeOptional(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.removeOptional(holder);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> removeTag(class_2960 identifier);

    public AbstractTagAppender<T> removeTag(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.removeTag(identifier);
        }

        return this;
    }

    public AbstractTagAppender<T> removeTag(class_6862<T> tagKey) {
        return this.removeTag(tagKey.comp_327());
    }

    public AbstractTagAppender<T> removeOptionalTag(String string) {
        return this.removeOptionalTag(class_2960.method_60654(string));
    }

    public AbstractTagAppender<T> removeOptionalTag(String... strings) {
        for (String string : strings) {
            this.removeOptionalTag(string);
        }

        return this;
    }

    public abstract AbstractTagAppender<T> removeOptionalTag(class_2960 identifier);

    public AbstractTagAppender<T> removeOptionalTag(class_2960... identifiers) {
        for (class_2960 identifier : identifiers) {
            this.removeOptionalTag(identifier);
        }

        return this;
    }

    public AbstractTagAppender<T> removeOptionalTag(class_6862<T> tagKey) {
        return this.removeTag(tagKey.comp_327());
    }

    @SafeVarargs
    public final AbstractTagAppender<T> removeTag(class_6862<T>... tagKeys) {
        for (class_6862<T> tagKey : tagKeys) {
            this.removeOptionalTag(tagKey);
        }

        return this;
    }

    private Function<T, class_5321<T>> keyExtractor() {
        Objects.requireNonNull(this.keyExtractor, "key extractor is null");
        return this.keyExtractor;
    }

    public abstract List<String> asStringList();
}
