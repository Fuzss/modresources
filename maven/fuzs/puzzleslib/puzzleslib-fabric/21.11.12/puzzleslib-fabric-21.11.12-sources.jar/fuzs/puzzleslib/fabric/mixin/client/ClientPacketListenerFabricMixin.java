package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientPlayerEvents;
import net.minecraft.class_2535;
import net.minecraft.class_2678;
import net.minecraft.class_2724;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_746;
import net.minecraft.class_8673;
import net.minecraft.class_8675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
abstract class ClientPacketListenerFabricMixin extends class_8673 {

    protected ClientPacketListenerFabricMixin(class_310 minecraft, class_2535 connection, class_8675 commonListenerCookie) {
        super(minecraft, connection, commonListenerCookie);
    }

    @Inject(
            method = "handleLogin", at = @At(
            value = "INVOKE", target = "Lnet/minecraft/client/player/LocalPlayer;resetPos()V", shift = At.Shift.AFTER
    )
    )
    public void handleLogin(class_2678 packet, CallbackInfo callback) {
        FabricClientPlayerEvents.PLAYER_JOIN.invoker().onPlayerJoin(this.field_45588.field_1724, this.field_45588.field_1761,
                this.field_45588.method_1562().method_48296()
        );
    }

    @Inject(
            method = "handleRespawn", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/multiplayer/ClientLevel;addEntity(Lnet/minecraft/world/entity/Entity;)V"
    )
    )
    public void handleRespawn(class_2724 packet, CallbackInfo callback, @Local(ordinal = 0) class_746 oldPlayer) {
        FabricClientPlayerEvents.PLAYER_COPY.invoker().onCopy(oldPlayer, this.field_45588.field_1724, this.field_45588.field_1761,
                this.field_45588.field_1724.field_3944.method_48296()
        );
    }
}
