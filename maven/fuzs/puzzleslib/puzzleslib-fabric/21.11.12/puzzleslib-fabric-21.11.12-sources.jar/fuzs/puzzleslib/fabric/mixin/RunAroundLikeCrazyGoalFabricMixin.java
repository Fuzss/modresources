package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import net.minecraft.class_1352;
import net.minecraft.class_1387;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Slice;

@Mixin(class_1387.class)
abstract class RunAroundLikeCrazyGoalFabricMixin extends class_1352 {
    @Shadow
    @Final
    private class_1496 horse;

    @ModifyExpressionValue(method = "tick",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/RandomSource;nextInt(I)I"),
            slice = @Slice(from = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/entity/animal/equine/AbstractHorse;getMaxTemper()I")))
    public int tick(int intValue, @Local class_1657 player) {
        int horseTemper = this.horse.method_6729();
        return FabricEventImplHelper.onAnimalTame(this.horse, player, intValue, horseTemper, intValue < horseTemper);
    }
}
