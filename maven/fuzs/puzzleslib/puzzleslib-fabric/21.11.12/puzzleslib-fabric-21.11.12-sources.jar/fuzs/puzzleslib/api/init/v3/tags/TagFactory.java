package fuzs.puzzleslib.api.init.v3.tags;

import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/**
 * A simple helper class for creating new {@link class_6862} instances with a set namespace.
 */
@FunctionalInterface
public interface TagFactory {
    /**
     * A built-in factory for the <code>minecraft</code> namespace.
     */
    TagFactory MINECRAFT = make("minecraft");
    /**
     * A built-in factory for the <code>common</code> namespace.
     */
    TagFactory COMMON = make("c");
    /**
     * A built-in factory for the <code>fabric</code> namespace.
     */
    TagFactory FABRIC = make("fabric");
    /**
     * A built-in factory for the <code>neoforge</code> namespace.
     */
    TagFactory NEOFORGE = make("neoforge");

    /**
     * Construct a new factory instance backed by a provided namespace.
     *
     * @param modId the namespace
     * @return new factory instance
     */
    static TagFactory make(String modId) {
        return () -> modId;
    }

    /**
     * @return the mod id
     */
    String modId();

    /**
     * Creates a new {@link class_6862} for any type of registry from a given path.
     *
     * @param registryKey key for registry to create key from
     * @param path        path for new tag key
     * @param <T>         registry type
     * @return new tag key
     */
    default <T> class_6862<T> registerTagKey(class_5321<? extends class_2378<T>> registryKey, String path) {
        return class_6862.method_40092(registryKey, class_2960.method_60655(this.modId(), path));
    }

    /**
     * Creates a new {@link class_6862} for blocks.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_2248> registerBlockTag(String path) {
        return this.registerTagKey(class_7924.field_41254, path);
    }

    /**
     * Creates a new {@link class_6862} for items.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_1792> registerItemTag(String path) {
        return this.registerTagKey(class_7924.field_41197, path);
    }

    /**
     * Creates a new {@link class_6862} for fluids.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_3611> registerFluidTag(String path) {
        return this.registerTagKey(class_7924.field_41270, path);
    }

    /**
     * Creates a new {@link class_6862} for entity types.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_1299<?>> registerEntityTypeTag(String path) {
        return this.registerTagKey(class_7924.field_41266, path);
    }

    /**
     * Creates a new {@link class_6862} for enchantments.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_1887> registerEnchantmentTag(String path) {
        return this.registerTagKey(class_7924.field_41265, path);
    }

    /**
     * Creates a new {@link class_6862} for biomes.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_1959> registerBiomeTag(String path) {
        return this.registerTagKey(class_7924.field_41236, path);
    }

    /**
     * Creates a new {@link class_6862} for game events.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_5712> registerGameEventTag(String path) {
        return this.registerTagKey(class_7924.field_41273, path);
    }

    /**
     * Creates a new {@link class_6862} for damage types.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    default class_6862<class_8110> registerDamageTypeTag(String path) {
        return this.registerTagKey(class_7924.field_42534, path);
    }
}
