package fuzs.puzzleslib.fabric.mixin;

import com.mojang.datafixers.DataFixer;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import net.minecraft.class_1923;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3898;
import net.minecraft.class_3977;
import net.minecraft.class_4284;
import net.minecraft.class_9240;

@Mixin(class_3898.class)
abstract class ChunkMapFabricMixin extends class_3977 {
    @Shadow
    @Final
    class_3218 level;

    public ChunkMapFabricMixin(class_9240 info, Path folder, DataFixer fixerUpper, boolean sync, class_4284 dataFixType) {
        super(info, folder, fixerUpper, sync, dataFixType);
    }

    @Inject(method = "dropChunk", at = @At("HEAD"))
    private static void dropChunk(class_3222 player, class_1923 chunkPos, CallbackInfo callback) {
        FabricLevelEvents.UNWATCH_CHUNK.invoker().onChunkUnwatch(player, chunkPos, player.method_51469());
    }
}
