package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_4970;

@Mixin(class_2248.class)
abstract class BlockFabricMixin extends class_4970 {
    @Unique @Nullable private int[] puzzleslib$capturedExperience;

    public BlockFabricMixin(class_2251 properties) {
        super(properties);
    }

    @Inject(method = "playerDestroy", at = @At("HEAD"))
    public void playerDestroy$0(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 itemInHand, CallbackInfo callback) {
        if (level instanceof class_3218) {
            this.puzzleslib$capturedExperience = new int[1];
        }
    }

    @Inject(method = "playerDestroy", at = @At("TAIL"))
    public void playerDestroy$1(class_1937 level, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 itemInHand, CallbackInfo callback) {
        if (!(level instanceof class_3218 serverLevel)) return;
        if (!(player instanceof class_3222 serverPlayer)) return;
        int[] capturedExperience = this.puzzleslib$capturedExperience;
        this.puzzleslib$capturedExperience = null;
        Objects.requireNonNull(capturedExperience, "captured experience is null");
        MutableInt experienceToDrop = MutableInt.fromValue(capturedExperience[0]);
        FabricLevelEvents.DROP_BLOCK_EXPERIENCE.invoker()
                .onDropExperience(serverLevel, pos, state, serverPlayer, itemInHand, experienceToDrop);
        if (experienceToDrop.getAsInt() > 0) {
            this.popExperience(serverLevel, pos, experienceToDrop.getAsInt());
        }
    }

    @Shadow
    protected abstract void popExperience(class_3218 level, class_2338 pos, int amount);

    @ModifyVariable(method = "tryDropExperience", at = @At("STORE"), ordinal = 0)
    protected int tryDropExperience(int i, class_3218 level, class_2338 pos, class_1799 itemInHand) {
        int[] capturedExperience = this.puzzleslib$capturedExperience;
        if (capturedExperience != null) {
            capturedExperience[0] += i;
            // method will do nothing when zero is returned
            return 0;
        } else {
            return i;
        }
    }
}
