package fuzs.puzzleslib.api.client.data.v2;

import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import net.minecraft.class_10186;
import net.minecraft.class_10206;
import net.minecraft.class_10394;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7403;
import net.minecraft.class_7784;

public abstract class AbstractEquipmentProvider extends class_10206 {

    public AbstractEquipmentProvider(DataProviderContext context) {
        this(context.getPackOutput());
    }

    public AbstractEquipmentProvider(class_7784 packOutput) {
        super(packOutput);
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 cachedOutput) {
        Map<class_5321<class_10394>, class_10186> values = new LinkedHashMap<>();
        this.addEquipmentAssets((class_5321<class_10394> resourceKey, class_10186 equipmentClientInfo) -> {
            if (values.putIfAbsent(resourceKey, equipmentClientInfo) != null) {
                throw new IllegalStateException("Tried to register equipment asset twice for id: " + resourceKey);
            }
        });

        return class_2405.method_65771(cachedOutput, class_10186.field_54120, this.field_54202::method_65773, values);
    }

    public abstract void addEquipmentAssets(BiConsumer<class_5321<class_10394>, class_10186> equipmentAssetConsumer);

    /**
     * @see class_10206#method_65423(String)
     */
    public static class_10186 onlyHumanoid(class_2960 identifier) {
        return class_10186.method_63994().method_63998(identifier).method_63997();
    }

    /**
     * @see class_10206#method_65425(String)
     */
    public static class_10186 humanoidAndHorse(class_2960 identifier) {
        return class_10186.method_63994()
                .method_63998(identifier)
                .method_64001(class_10186.class_10190.field_54129,
                        class_10186.class_10189.method_64005(identifier, false))
                .method_63997();
    }

    public static class_10186 simple(class_10186.class_10190 layerType, class_2960 identifier) {
        return class_10186.method_63994().method_64001(layerType, new class_10186.class_10189(identifier)).method_63997();
    }
}
