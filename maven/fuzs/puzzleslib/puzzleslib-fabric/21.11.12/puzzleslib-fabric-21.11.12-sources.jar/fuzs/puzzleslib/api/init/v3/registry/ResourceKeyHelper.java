package fuzs.puzzleslib.api.init.v3.registry;

import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * A utility class for creating {@link class_2561 Components} from {@link class_5321 ResourceKeys}.
 */
public final class ResourceKeyHelper {

    private ResourceKeyHelper() {
        // NO-OP
    }

    /**
     * Useful for name components for various data pack registry entries.
     *
     * @param resourceKey the resource key
     * @return the component
     */
    public static class_5250 getComponent(class_5321<?> resourceKey) {
        return class_2561.method_43471(getTranslationKey(resourceKey));
    }

    /**
     * Useful for name components for various data pack registry entries.
     *
     * @param registryKey      the registry key
     * @param identifier the identifier
     * @return the component
     */
    public static class_5250 getComponent(class_5321<? extends class_2378<?>> registryKey, class_2960 identifier) {
        return class_2561.method_43471(getTranslationKey(registryKey, identifier));
    }

    /**
     * @param resourceKey the resource key
     * @return the translation key
     */
    public static String getTranslationKey(class_5321<?> resourceKey) {
        return getTranslationKey(resourceKey.method_58273(), resourceKey.method_29177());
    }

    /**
     * @param registryKey      the registry key
     * @param identifier the identifier
     * @return the translation key
     */
    public static String getTranslationKey(class_5321<? extends class_2378<?>> registryKey, class_2960 identifier) {
        return class_156.method_646(class_7924.method_60915(registryKey), identifier);
    }

    /**
     * Useful for attribute names from enchantment resource keys.
     *
     * @param resourceKey the resource key
     * @return the identifier
     */
    public static class_2960 getIdentifier(class_5321<?> resourceKey) {
        return getIdentifier(resourceKey.method_58273(), resourceKey.method_29177());
    }

    /**
     * Useful for attribute names from enchantment resource keys.
     *
     * @param registryKey      the registry key
     * @param identifier the identifier
     * @return the identifier
     */
    public static class_2960 getIdentifier(class_5321<? extends class_2378<?>> registryKey, class_2960 identifier) {
        return identifier.method_45138(class_7924.method_60915(registryKey) + ".");
    }
}
