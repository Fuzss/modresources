package fuzs.puzzleslib.api.client.packs.v1;

import org.lwjgl.stb.STBImage;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;
import java.nio.channels.WritableByteChannel;
import net.minecraft.class_1011;

/**
 * A helper class containing legacy {@link class_1011} methods.
 */
public final class NativeImageHelper {

    private NativeImageHelper() {
        // NO-OP
    }

    /**
     * Writes the native image data to a byte array.
     *
     * @param nativeImage the native image
     * @return the native image data as byte array
     *
     * @throws IOException thrown when writing fails
     */
    public static byte[] asByteArray(class_1011 nativeImage) throws IOException {
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(); WritableByteChannel writableByteChannel = Channels.newChannel(byteArrayOutputStream)) {
            if (!nativeImage.method_24032(writableByteChannel)) {
                throw new IOException("Could not write image to byte array: " + STBImage.stbi_failure_reason());
            } else {
                return byteArrayOutputStream.toByteArray();
            }
        }
    }
}
