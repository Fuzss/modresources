package fuzs.puzzleslib.api.client.data.v2.models;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4941;
import net.minecraft.class_4944;
import net.minecraft.class_7923;

/**
 * A utility for managing model and texture locations for blocks and items.
 */
public final class ModelLocationHelper {
    /**
     * The block model / texture path prefix.
     */
    public static final String BLOCK_PATH = "block";
    /**
     * The item model / texture path prefix.
     */
    public static final String ITEM_PATH = "item";

    private ModelLocationHelper() {
        // NO-OP
    }

    /**
     * @param block the block
     * @return the default block model location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockModel(class_2248 block) {
        return class_4941.method_25842(block);
    }

    /**
     * @param block  the block
     * @param suffix the block model suffix
     * @return the block model location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockModel(class_2248 block, String suffix) {
        return class_4941.method_25843(block, suffix);
    }

    /**
     * @param identifier the block location
     * @return the default block model location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockModel(class_2960 identifier) {
        return identifier.method_45138(BLOCK_PATH + "/");
    }

    /**
     * @param identifier the block location
     * @param suffix           the block model suffix
     * @return the block model location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockModel(class_2960 identifier, String suffix) {
        return getBlockModel(identifier).method_48331(suffix);
    }

    /**
     * @param block the block
     * @return the default block texture location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockTexture(class_2248 block) {
        return class_4944.method_25860(block);
    }

    /**
     * @param block  the block
     * @param suffix the block texture suffix
     * @return the block texture location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockTexture(class_2248 block, String suffix) {
        return class_4944.method_25866(block, suffix);
    }

    /**
     * @param identifier the block location
     * @return the default block texture location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockTexture(class_2960 identifier) {
        return identifier.method_45138(BLOCK_PATH + "/");
    }

    /**
     * @param identifier the block location
     * @param suffix           the block texture suffix
     * @return the block texture location, prefixed with {@link #BLOCK_PATH}
     */
    public static class_2960 getBlockTexture(class_2960 identifier, String suffix) {
        return getBlockTexture(identifier).method_48331(suffix);
    }

    /**
     * @param block the block
     * @return the block registry key
     */
    public static class_2960 getBlockLocation(class_2248 block) {
        return class_7923.field_41175.method_10221(block);
    }

    /**
     * @param block  the block
     * @param suffix the block key suffix
     * @return the block registry key
     */
    public static class_2960 getBlockLocation(class_2248 block, String suffix) {
        return getBlockLocation(block).method_48331(suffix);
    }

    /**
     * @param block the block
     * @return the block registry key name
     */
    public static String getBlockName(class_2248 block) {
        return getBlockLocation(block).method_12832();
    }

    /**
     * @param item the item
     * @return the default item model location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemModel(class_1792 item) {
        return class_4941.method_25840(item);
    }

    /**
     * @param item   the item
     * @param suffix the item model suffix
     * @return the item model location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemModel(class_1792 item, String suffix) {
        return class_4941.method_25841(item, suffix);
    }

    /**
     * @param identifier the item location
     * @return the default item model location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemModel(class_2960 identifier) {
        return identifier.method_45138(ITEM_PATH + "/");
    }

    /**
     * @param identifier the item location
     * @param suffix           the item model suffix
     * @return the item model location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemModel(class_2960 identifier, String suffix) {
        return getItemModel(identifier).method_48331(suffix);
    }

    /**
     * @param item the item
     * @return the default item texture location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemTexture(class_1792 item) {
        return class_4944.method_25876(item);
    }

    /**
     * @param item   the item
     * @param suffix the item texture suffix
     * @return the item texture location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemTexture(class_1792 item, String suffix) {
        return class_4944.method_25863(item, suffix);
    }

    /**
     * @param identifier the item location
     * @return the default item texture location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemTexture(class_2960 identifier) {
        return identifier.method_45138(ITEM_PATH + "/");
    }

    /**
     * @param identifier the item location
     * @param suffix           the item texture suffix
     * @return the item texture location, prefixed with {@link #ITEM_PATH}
     */
    public static class_2960 getItemTexture(class_2960 identifier, String suffix) {
        return getItemTexture(identifier).method_48331(suffix);
    }

    /**
     * @param item the item
     * @return the item registry key
     */
    public static class_2960 getItemLocation(class_1792 item) {
        return class_7923.field_41178.method_10221(item);
    }

    /**
     * @param item   the item
     * @param suffix the item key suffix
     * @return the item registry key
     */
    public static class_2960 getItemLocation(class_1792 item, String suffix) {
        return getItemLocation(item).method_48331(suffix);
    }

    /**
     * @param item the item
     * @return the item registry key name
     */
    public static String getItemName(class_1792 item) {
        return getItemLocation(item).method_12832();
    }
}
