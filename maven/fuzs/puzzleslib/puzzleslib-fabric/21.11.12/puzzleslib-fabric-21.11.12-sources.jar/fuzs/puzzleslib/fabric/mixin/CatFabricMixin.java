package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import net.minecraft.class_1299;
import net.minecraft.class_1321;
import net.minecraft.class_1451;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1451.class)
abstract class CatFabricMixin extends class_1321 {

    protected CatFabricMixin(class_1299<? extends class_1321> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyExpressionValue(method = "tryToTame",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/util/RandomSource;nextInt(I)I"))
    public int tryToTame(int intValue, class_1657 player) {
        return FabricEventImplHelper.onAnimalTame(this, player, intValue);
    }
}
