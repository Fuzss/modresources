package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.impl.core.context.DataPackSourcesContextFabricImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;
import net.minecraft.class_3286;

@Mixin(class_3283.class)
abstract class PackRepositoryFabricMixin {
    @Shadow
    public Set<class_3285> sources;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void init(class_3285[] repositorySources, CallbackInfo callback) {
        // same implementation as Fabric Api to hook into server pack repository whenever a new one is created,
        // client resource packs can be handled much simpler since the repository is only ever created once
        for (class_3285 repositorySource : this.sources) {
            if (repositorySource instanceof class_3286) {
                DataPackSourcesContextFabricImpl.addAll(class_3283.class.cast(this));
                return;
            }
        }
    }
}
