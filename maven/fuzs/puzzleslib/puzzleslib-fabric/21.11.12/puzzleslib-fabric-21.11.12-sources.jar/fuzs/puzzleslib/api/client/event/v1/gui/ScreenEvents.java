package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_437;

@SuppressWarnings("unchecked")
public final class ScreenEvents {

    private ScreenEvents() {
        // NO-OP
    }

    public static <T extends class_437> EventInvoker<BeforeInit<T>> beforeInit(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeInit<T>>) (Class<?>) BeforeInit.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterInit<T>> afterInit(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterInit<T>>) (Class<?>) AfterInit.class, screen);
    }

    public static <T extends class_437> EventInvoker<Remove<T>> remove(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<Remove<T>>) (Class<?>) Remove.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeRender<T>> beforeRender(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeRender<T>>) (Class<?>) BeforeRender.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterBackground<T>> afterBackground(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterBackground<T>>) (Class<?>) AfterBackground.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterRender<T>> afterRender(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterRender<T>>) (Class<?>) AfterRender.class, screen);
    }

    @FunctionalInterface
    public interface BeforeInit<T extends class_437> {

        /**
         * Called before widgets on a {@link class_437} are cleared and rebuilt by calling {@link class_437#method_25426()}, usually
         * triggered by the screen opening or being resized.
         * <p>
         * As opposed to Forge, this callback cannot be cancelled, and therefore also does not allow for manipulating
         * widgets, as those will be cleared anyway.
         * <p>
         * TODO remove Minecraft argument, the field on the screen is now final
         *
         * @param minecraft    the minecraft singleton instance
         * @param screen       the screen that is rebuilding widgets
         * @param screenWidth  width of the window
         * @param screenHeight height of the window
         * @param widgets      all old widgets on the screen provided as a read-only list, those will be cleared
         */
        void onBeforeInit(class_310 minecraft, T screen, int screenWidth, int screenHeight, List<class_339> widgets);
    }

    @FunctionalInterface
    public interface AfterInit<T extends class_437> {

        /**
         * Called after widgets on a {@link class_437} have been cleared and rebuilt by calling {@link class_437#method_25426()},
         * usually triggered by the screen opening or being resized.
         * <p>
         * This callback allows for manipulating widgets on the screen, allowing for both additions and removals, as
         * well as modifications to existing widgets.
         * <p>
         * TODO remove Minecraft argument, the field on the screen is now final
         *
         * @param minecraft    the minecraft singleton instance
         * @param screen       the screen that is rebuilding widgets
         * @param screenWidth  width of the window
         * @param screenHeight height of the window
         * @param widgets      all widgets on the screen provided as a read-only list
         * @param addWidget    a consumer for adding a new widget
         * @param removeWidget a consumer for removing an existing widget
         */
        void onAfterInit(class_310 minecraft, T screen, int screenWidth, int screenHeight, List<class_339> widgets, UnaryOperator<class_339> addWidget, Consumer<class_339> removeWidget);
    }

    @FunctionalInterface
    public interface Remove<T extends class_437> {

        /**
         * Runs before a screen is removed in {@link class_437#method_25432()}.
         *
         * @param screen the currently displayed screen
         */
        void onRemove(T screen);
    }

    @FunctionalInterface
    public interface BeforeRender<T extends class_437> {

        /**
         * Runs before a screen is rendered in {@link class_437#method_25394(class_332, int, int, float)}.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onBeforeRender(T screen, class_332 guiGraphics, int mouseX, int mouseY, float partialTick);
    }

    @FunctionalInterface
    public interface AfterBackground<T extends class_437> {

        /**
         * Runs after a screen background is rendered in {@link class_437#method_25420(class_332, int, int, float)}.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onAfterBackground(T screen, class_332 guiGraphics, int mouseX, int mouseY, float partialTick);
    }

    @FunctionalInterface
    public interface AfterRender<T extends class_437> {

        /**
         * Runs after a screen is rendered in {@link class_437#method_25394(class_332, int, int, float)}.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onAfterRender(T screen, class_332 guiGraphics, int mouseX, int mouseY, float partialTick);
    }
}
