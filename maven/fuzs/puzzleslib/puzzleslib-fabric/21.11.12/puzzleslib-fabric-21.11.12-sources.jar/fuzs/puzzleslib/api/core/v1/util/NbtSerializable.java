package fuzs.puzzleslib.api.core.v1.util;

import com.mojang.serialization.Codec;
import fuzs.puzzleslib.impl.core.NbtSerializableCodec;
import java.util.function.Supplier;
import net.minecraft.class_2487;
import net.minecraft.class_7225;

/**
 * A basic template for an object that is serializable to Minecraft's nbt format.
 */
public interface NbtSerializable {

    /**
     * A codec adapter for {@link NbtSerializable}.
     *
     * @param factory the nbt serializable factory
     * @param <T>     the nbt serializable type
     */
    static <T extends NbtSerializable> Codec<T> codec(Supplier<T> factory) {
        return new NbtSerializableCodec<>(factory);
    }

    /**
     * Serialise the component to a {@link class_2487}.
     *
     * @param compoundTag tag to write to
     * @param registries  the registry access
     */
    void write(class_2487 compoundTag, class_7225.class_7874 registries);

    /**
     * Deserialise the component from a {@link class_2487}.
     *
     * @param compoundTag tag to read from
     * @param registries  the registry access
     */
    void read(class_2487 compoundTag, class_7225.class_7874 registries);

    /**
     * Encode the serialisable instance to a {@link class_2487}.
     *
     * @param registries the registry access
     * @return a tag containing the serialized instance
     */
    default class_2487 toCompoundTag(class_7225.class_7874 registries) {
        class_2487 tag = new class_2487();
        this.write(tag, registries);
        return tag;
    }
}
