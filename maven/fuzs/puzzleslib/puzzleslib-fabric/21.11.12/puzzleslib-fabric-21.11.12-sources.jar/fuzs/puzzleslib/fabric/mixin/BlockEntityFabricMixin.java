package fuzs.puzzleslib.fabric.mixin;

import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2586.class)
abstract class BlockEntityFabricMixin {

    @Inject(method = "isValidBlockState", at = @At("HEAD"), cancellable = true)
    public void isValidBlockState(class_2680 blockState, CallbackInfoReturnable<Boolean> callback) {
        // allow 1.21.1 mods to work without any code changes
        if (this.getType().method_20526(blockState)) {
            callback.setReturnValue(true);
        }
    }

    @Shadow
    public abstract class_2591<?> getType();
}
