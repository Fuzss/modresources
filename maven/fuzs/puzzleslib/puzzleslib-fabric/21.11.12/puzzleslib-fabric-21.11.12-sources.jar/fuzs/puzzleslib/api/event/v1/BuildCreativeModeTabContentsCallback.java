package fuzs.puzzleslib.api.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_5321;

@FunctionalInterface
public interface BuildCreativeModeTabContentsCallback {

    static EventInvoker<BuildCreativeModeTabContentsCallback> buildCreativeModeTabContents(class_5321<class_1761> resourceKey) {
        Objects.requireNonNull(resourceKey, "resource key is null");
        return EventInvoker.lookup(BuildCreativeModeTabContentsCallback.class, resourceKey);
    }

    /**
     * Called every time an existing creative mode tab is rebuilt. Allows for adding new display items, removals are not
     * supported.
     * <p>
     * For creating brand-new creative mode tabs see
     * {@link fuzs.puzzleslib.api.init.v3.registry.RegistryManager#registerCreativeModeTab(String, Supplier,
     * class_1761.class_7914, boolean)}.
     *
     * @param creativeModeTab       the creative mode tab instance
     * @param itemDisplayParameters the item display parameters
     * @param output                the display items consumer
     */
    void onBuildCreativeModeTabContents(class_1761 creativeModeTab, class_1761.class_8128 itemDisplayParameters, class_1761.class_7704 output);
}
