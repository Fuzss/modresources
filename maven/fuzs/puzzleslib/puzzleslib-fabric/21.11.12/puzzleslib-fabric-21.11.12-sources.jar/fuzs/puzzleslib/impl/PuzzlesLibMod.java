package fuzs.puzzleslib.impl;

import fuzs.puzzleslib.api.core.v1.ModConstructor;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_2960;

/**
 * This has been separated from {@link PuzzlesLib} to prevent issues with static initialization when accessing constants
 * in {@link PuzzlesLib} early.
 */
public class PuzzlesLibMod extends PuzzlesLib implements ModConstructor {

    @Override
    public void onConstructMod() {
        ProxyImpl.get().registerEventHandlers();
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
