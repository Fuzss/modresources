package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_11701;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_746;

@FunctionalInterface
public interface RenderBlockOverlayCallback {
    EventInvoker<RenderBlockOverlayCallback> EVENT = EventInvoker.lookup(RenderBlockOverlayCallback.class);

    /**
     * Called before a block overlay is rendered on the screen. In vanilla this is the case for:
     * <ul>
     *     <li>the flame overlay on the screen bottom while the player is burning</li>
     *     <li>the water overlay while the player is diving in water</li>
     *     <li>any solid block when the player is inside it and the vision is obstructed</li>
     * </ul>
     *
     * @param player       the local client player the overlay is rendering for
     * @param poseStack    the current pose stack
     * @param bufferSource the buffer source
     * @param blockState   the block state the overlay originates from, will be {@link class_2248#method_9564()} for
     *                     fire and water overlays
     * @param materialSet  the material set
     * @return <ul>
     *              <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the overlay from rendering</li>
     *              <li>{@link EventResult#PASS PASS} to allow the overlay to render</li>
     *         </ul>
     */
    EventResult onRenderBlockOverlay(class_746 player, class_4587 poseStack, class_4597 bufferSource, class_2680 blockState, class_11701 materialSet);
}
