package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_310;

public final class ClientTickEvents {
    public static final EventInvoker<Start> START = EventInvoker.lookup(Start.class);
    public static final EventInvoker<End> END = EventInvoker.lookup(End.class);

    private ClientTickEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Start {

        /**
         * Fires at the beginning of {@link class_310#method_1574()}.
         *
         * @param minecraft the minecraft singleton instance
         */
        void onStartClientTick(class_310 minecraft);
    }

    @FunctionalInterface
    public interface End {

        /**
         * Fires at the end of {@link class_310#method_1574()}.
         *
         * @param minecraft the minecraft singleton instance
         */
        void onEndClientTick(class_310 minecraft);
    }
}
