package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

@FunctionalInterface
public interface PickProjectileCallback {
    EventInvoker<PickProjectileCallback> EVENT = EventInvoker.lookup(PickProjectileCallback.class);

    /**
     * Fired when an entity attempts to find a valid projectile via {@link class_1309#method_18808(class_1799)}.
     *
     * @param livingEntity        the living entity
     * @param weaponItemStack     the ranged weapon item stack
     * @param projectileItemStack the ammo item stack, possibly empty
     */
    void onPickProjectile(class_1309 livingEntity, class_1799 weaponItemStack, MutableValue<class_1799> projectileItemStack);
}
