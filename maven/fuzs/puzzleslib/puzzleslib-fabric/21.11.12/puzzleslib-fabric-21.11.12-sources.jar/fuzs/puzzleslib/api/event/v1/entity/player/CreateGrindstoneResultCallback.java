package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import java.util.function.IntConsumer;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3803;

@FunctionalInterface
public interface CreateGrindstoneResultCallback {
    EventInvoker<CreateGrindstoneResultCallback> EVENT = EventInvoker.lookup(CreateGrindstoneResultCallback.class);

    /**
     * Called after a result item is created from the two input slots in a grindstone via
     * {@link class_3803#method_16695()}.
     *
     * @param player                the player using the grindstone
     * @param primaryItemStack      the item stack placed in the left input slot
     * @param secondaryItemStack    the item stack placed in the right input slot
     * @param outputItemStack       the item computed by vanilla for the result slot
     * @param experiencePointReward the experience points to gain from this operation
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent vanilla logic from running, the output item stack will not be updated</li>
     *         <li>{@link EventResult#PASS PASS} to set a custom result from the specified output item stack</li>
     *         </ul>
     */
    EventResult onCreateGrindstoneResult(class_1657 player, class_1799 primaryItemStack, class_1799 secondaryItemStack, MutableValue<class_1799> outputItemStack, IntConsumer experiencePointReward);
}
