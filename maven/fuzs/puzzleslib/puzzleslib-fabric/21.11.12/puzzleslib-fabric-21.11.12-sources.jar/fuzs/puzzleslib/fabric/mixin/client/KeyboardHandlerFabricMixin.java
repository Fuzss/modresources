package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientEvents;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
abstract class KeyboardHandlerFabricMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Inject(method = "keyPress", at = @At("HEAD"), cancellable = true)
    public void keyPress(long windowPointer, int action, class_11908 keyEvent, CallbackInfo callback) {
        if (windowPointer == this.minecraft.method_22683().method_4490()) {
            EventResult result = FabricClientEvents.KEY_PRESS.invoker().onKeyPress(keyEvent, action);
            if (result.isInterrupt()) callback.cancel();
        }
    }
}
