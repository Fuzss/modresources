package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.Function;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

/**
 * Register a client-side tooltip component factory for creating a renderer from a {@link class_5632}.
 */
public interface ClientTooltipComponentsContext {

    /**
     * Register a {@link class_5684}.
     *
     * @param tooltipComponentClazz         the common {@link class_5632} class
     * @param clientTooltipComponentFactory the factory for creating {@link class_5684} from the common
     *                                      component
     * @param <T>                           the type of common component
     */
    <T extends class_5632> void registerClientTooltipComponent(Class<T> tooltipComponentClazz, Function<? super T, ? extends class_5684> clientTooltipComponentFactory);
}
