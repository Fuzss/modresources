package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.ClientTooltipComponentsContext;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import java.util.Objects;
import java.util.function.Function;

public final class ClientTooltipComponentsContextFabricImpl implements ClientTooltipComponentsContext {

    @SuppressWarnings("unchecked")
    @Override
    public <T extends class_5632> void registerClientTooltipComponent(Class<T> tooltipComponentClazz, Function<? super T, ? extends class_5684> clientTooltipComponentFactory) {
        Objects.requireNonNull(tooltipComponentClazz, "tooltip component type is null");
        Objects.requireNonNull(clientTooltipComponentFactory, "tooltip component factory is null");
        TooltipComponentCallback.EVENT.register((class_5632 data) -> {
            if (data.getClass() == tooltipComponentClazz) return clientTooltipComponentFactory.apply((T) data);
            return null;
        });
    }
}
