package fuzs.puzzleslib.fabric.mixin.client;

import com.google.common.base.Preconditions;
import com.llamalad7.mixinextras.sugar.Cancellable;
import com.mojang.authlib.GameProfile;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientPlayerEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_742;
import net.minecraft.class_744;
import net.minecraft.class_746;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_746.class)
abstract class LocalPlayerFabricMixin extends class_742 {
    @Shadow
    public class_744 input;

    public LocalPlayerFabricMixin(class_638 clientLevel, GameProfile gameProfile) {
        super(clientLevel, gameProfile);
    }

    @Inject(
            method = "aiStep", at = @At(
            value = "INVOKE", target = "Lnet/minecraft/client/player/ClientInput;tick()V", shift = At.Shift.AFTER
    )
    )
    public void aiStep(CallbackInfo callback) {
        FabricClientPlayerEvents.MOVEMENT_INPUT_UPDATE.invoker()
                .onMovementInputUpdate(class_746.class.cast(this), this.input);
    }

    @ModifyArgs(
            method = "playSound(Lnet/minecraft/sounds/SoundEvent;FF)V", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/level/Level;playLocalSound(DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FFZ)V"
    )
    )
    public void playSound(Args args, @Cancellable CallbackInfo callback) {
        Preconditions.checkArgument(args.get(3) instanceof class_3414, "sound event is wrong type");
        EventResult eventResult = FabricEventImplHelper.onPlaySound((MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch) -> {
                    return FabricLevelEvents.PLAY_SOUND_AT_ENTITY.invoker()
                            .onPlaySoundAtEntity(this.method_73183(), this, soundEvent, soundSource, soundVolume, soundPitch);
                }, args, MutableValue.fromEvent((class_6880<class_3414> holder) -> args.set(3, holder.comp_349()),
                        () -> class_7923.field_41172.method_47983(args.get(3))), 4,
                5,
                6);
        if (eventResult.isInterrupt()) callback.cancel();
    }
}
