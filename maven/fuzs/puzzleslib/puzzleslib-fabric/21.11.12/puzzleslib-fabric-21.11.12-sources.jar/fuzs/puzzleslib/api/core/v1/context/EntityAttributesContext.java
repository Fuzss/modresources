package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_5132;
import net.minecraft.class_6880;

/**
 * Register attributes for entities.
 */
public interface EntityAttributesContext {

    /**
     * Register attributes for a new entity type.
     *
     * @param entityType        the entity type
     * @param attributesBuilder the attribute supplier builder
     */
    void registerAttributes(class_1299<? extends class_1309> entityType, class_5132.class_5133 attributesBuilder);

    /**
     * Modify attributes of an existing entity type with the value from {@link class_1320#method_6169()}.
     *
     * @param entityType the entity type
     * @param attribute  the attribute to override or add
     */
    default void registerAttribute(class_1299<? extends class_1309> entityType, class_6880<class_1320> attribute) {
        this.registerAttribute(entityType, attribute, attribute.comp_349().method_6169());
    }

    /**
     * Modify attributes of an existing entity type.
     *
     * @param entityType     the entity type
     * @param attribute      the attribute to override or add
     * @param attributeValue the default value
     */
    void registerAttribute(class_1299<? extends class_1309> entityType, class_6880<class_1320> attribute, double attributeValue);
}
