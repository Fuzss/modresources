package fuzs.puzzleslib.fabric.mixin;

import com.google.common.base.Preconditions;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Cancellable;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricEntityEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import net.minecraft.class_11749;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2874;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5362;
import net.minecraft.class_5455;
import net.minecraft.class_6012;
import net.minecraft.class_6880;
import net.minecraft.class_9892;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_3218.class)
abstract class ServerLevelFabricMixin extends class_1937 {

    protected ServerLevelFabricMixin(class_5269 writableLevelData, class_5321<class_1937> resourceKey, class_5455 registryAccess, class_6880<class_2874> holder, boolean bl, boolean bl2, long l, int i) {
        super(writableLevelData, resourceKey, registryAccess, holder, bl, bl2, l, i);
    }

    @WrapWithCondition(method = "tickNonPassenger",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V"))
    public boolean tickNonPassenger(class_1297 entity, @Share("isEntityTickCancelled") LocalBooleanRef isEntityTickCancelled) {
        // avoid using @WrapOperation, so we are not blamed for any overhead from running the entity tick
        EventResult eventResult = FabricEntityEvents.ENTITY_TICK_START.invoker().onStartEntityTick(entity);
        isEntityTickCancelled.set(eventResult.isInterrupt());
        return eventResult.isPass();
    }

    @Inject(method = "tickNonPassenger",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V", shift = At.Shift.AFTER))
    public void tickNonPassenger(class_1297 entity, CallbackInfo callback, @Share("isEntityTickCancelled") LocalBooleanRef isEntityTickCancelled) {
        if (!isEntityTickCancelled.get()) {
            FabricEntityEvents.ENTITY_TICK_END.invoker().onEndEntityTick(entity);
        }
    }

    @Inject(method = "explode",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/ServerExplosion;explode()I"),
            cancellable = true)
    public void explode(@Nullable class_1297 entity, @Nullable class_1282 damageSource, @Nullable class_5362 explosionDamageCalculator, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction, class_2394 smallExplosionParticles, class_2394 largeExplosionParticles, class_6012<class_11749> explosionParticles, class_6880<class_3414> explosionSound, CallbackInfo callback, @Local class_9892 explosion) {
        EventResult eventResult = FabricLevelEvents.EXPLOSION_START.invoker()
                .onExplosionStart(class_3218.class.cast(this), explosion);
        if (eventResult.isInterrupt()) callback.cancel();
    }

    @ModifyArgs(method = "playSeededSound(Lnet/minecraft/world/entity/Entity;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/network/protocol/game/ClientboundSoundPacket;<init>(Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;DDDFFJ)V"))
    public void playSeededSound$0(Args args, @Cancellable CallbackInfo callback) {
        Preconditions.checkArgument(args.get(0) instanceof class_6880<?>, "sound event is wrong type");
        EventResult eventResult = FabricEventImplHelper.onPlaySound((soundEvent, soundSource, soundVolume, soundPitch) -> {
                    return FabricLevelEvents.PLAY_SOUND_AT_POSITION.invoker()
                            .onPlaySoundAtPosition(this,
                                    new class_243(args.get(2), args.get(3), args.get(4)),
                                    soundEvent,
                                    soundSource,
                                    soundVolume,
                                    soundPitch);
                },
                args,
                MutableValue.fromEvent((class_6880<class_3414> holder) -> args.set(0, holder), () -> args.get(0)),
                1,
                5,
                6);
        if (eventResult.isInterrupt()) callback.cancel();
    }

    @ModifyArgs(method = "playSeededSound(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/network/protocol/game/ClientboundSoundEntityPacket;<init>(Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;Lnet/minecraft/world/entity/Entity;FFJ)V"))
    public void playSeededSound$1(Args args, @Cancellable CallbackInfo callback) {
        Preconditions.checkArgument(args.get(0) instanceof class_6880<?>, "sound event is wrong type");
        EventResult eventResult = FabricEventImplHelper.onPlaySound((MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch) -> {
                    return FabricLevelEvents.PLAY_SOUND_AT_ENTITY.invoker()
                            .onPlaySoundAtEntity(this, args.get(2), soundEvent, soundSource, soundVolume, soundPitch);
                },
                args,
                MutableValue.fromEvent((class_6880<class_3414> holder) -> args.set(0, holder), () -> args.get(0)),
                1,
                3,
                4);
        if (eventResult.isInterrupt()) callback.cancel();
    }
}
