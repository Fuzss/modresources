package fuzs.puzzleslib.api.util.v1;

import net.minecraft.class_3532;
import net.minecraft.class_9848;

/**
 * Helper class for packing and unpacking hsv color components to and from an integer.
 *
 * @see class_9848
 */
public final class HSV {

    private HSV() {
        // NO-OP
    }

    /**
     * @param color the packed color
     * @return the unpacked hue component
     */
    public static int hue(int color) {
        return color >> 16 & 0xFF;
    }

    /**
     * @param color the packed color
     * @return the unpacked saturation component
     */
    public static int saturation(int color) {
        return color >> 8 & 0xFF;
    }

    /**
     * @param color the packed color
     * @return the unpacked value / brightness component
     */
    public static int value(int color) {
        return color & 0xFF;
    }

    /**
     * @param hue        the unpacked hue component
     * @param saturation the unpacked saturation component
     * @param value      the unpacked value / brightness component
     * @return the packed color
     */
    public static int color(int hue, int saturation, int value) {
        return hue << 16 | saturation << 8 | value;
    }

    /**
     * @param hue        the unpacked hue component
     * @param saturation the unpacked saturation component
     * @param value      the unpacked value / brightness component
     * @return the packed color
     */
    public static int colorFromFloat(float hue, float saturation, float value) {
        return color(class_9848.method_61326(hue), class_9848.method_61326(saturation), class_9848.method_61326(value));
    }

    /**
     * @param color the packed color
     * @return the unpacked hue component
     */
    public static float hueFloat(int color) {
        return class_9848.method_61336(hue(color));
    }

    /**
     * @param color the packed color
     * @return the unpacked saturation component
     */
    public static float saturationFloat(int color) {
        return class_9848.method_61336(saturation(color));
    }

    /**
     * @param color the packed color
     * @return the unpacked value / brightness component
     */
    public static float valueFloat(int color) {
        return class_9848.method_61336(value(color));
    }

    /**
     * @param color the packed rgb color
     * @return the packed hsv color
     */
    public static int rgbToHsv(int color) {
        return rgbToHsv(class_9848.method_65101(color), class_9848.method_65102(color), class_9848.method_65103(color));
    }

    /**
     * @param red   the unpacked red component
     * @param green the unpacked green component
     * @param blue  the unpacked blue component
     * @return the packed hsv color
     *
     * @author ChatGPT
     */
    public static int rgbToHsv(float red, float green, float blue) {
        // Find max and min values among R, G, B
        float max = Math.max(red, Math.max(green, blue));
        float min = Math.min(red, Math.min(green, blue));
        float delta = max - min;
        // Calculate Hue (H), scaled to [0,1]
        float hue = 0.0F;
        if (delta != 0.0F) {
            if (max == red) {
                hue = (green - blue) / delta % 6.0F;
            } else if (max == green) {
                hue = (blue - red) / delta + 2.0F;
            } else {
                hue = (red - green) / delta + 4.0F;
            }
            hue = hue / 6.0F; // Convert range from [0,360] to [0,1]
            if (hue < 0.0F) hue += 1.0F; // Ensure hue is non-negative
        }
        // Calculate Saturation (S)
        float saturation = max == 0.0F ? 0.0F : delta / max;
        // Calculate Value (V) - Also called Brightness (B)
        float value = max;
        // Return the HSV values as an array
        return colorFromFloat(hue, saturation, value);
    }

    /**
     * @param color the packed hsv color
     * @return the packed rgb color
     */
    public static int hsvToRgb(int color) {
        return hsvToRgb(hueFloat(color), saturationFloat(color), valueFloat(color));
    }

    /**
     * @param hue        the unpacked hue component
     * @param saturation the unpacked saturation component
     * @param value      the unpacked value / brightness component
     * @return the packed rgb color
     */
    public static int hsvToRgb(float hue, float saturation, float value) {
        return class_3532.method_15369(hue, saturation, value);
    }
}
