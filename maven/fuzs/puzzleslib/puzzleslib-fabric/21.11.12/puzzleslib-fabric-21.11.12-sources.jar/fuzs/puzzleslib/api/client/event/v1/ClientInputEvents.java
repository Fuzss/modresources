package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.client.event.v1.gui.ScreenKeyboardEvents;
import fuzs.puzzleslib.api.client.event.v1.gui.ScreenMouseEvents;
import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_11908;
import net.minecraft.class_11910;
import net.minecraft.class_3675;

/**
 * Very similar to {@link ScreenMouseEvents} and {@link ScreenKeyboardEvents}, but fires when no screen is open to
 * handle input events in the {@link net.minecraft.class_329}.
 */
public final class ClientInputEvents {
    public static final EventInvoker<MouseClick> MOUSE_CLICK = EventInvoker.lookup(MouseClick.class);
    public static final EventInvoker<MouseScroll> MOUSE_SCROLL = EventInvoker.lookup(MouseScroll.class);
    public static final EventInvoker<KeyPress> KEY_PRESS = EventInvoker.lookup(KeyPress.class);

    private ClientInputEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface MouseClick {

        /**
         * Called before a mouse button is clicked or released without a screen being open.
         *
         * @param mouseButtonInfo the mouse button info; for bundled values see
         *                        {@link net.minecraft.class_3675}
         * @param action          the mouse button action; see {@link class_3675#field_31998},
         *                        {@link class_3675#field_31997}, {@link class_3675#field_31999}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the event as handled, it will not be passed to other listeners and vanilla behavior will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onMouseClick(class_11910 mouseButtonInfo, int action);
    }

    @FunctionalInterface
    public interface MouseScroll {

        /**
         * Called before a mouse has scrolled without a screen being open.
         *
         * @param leftDown         is the left mouse button pressed
         * @param middleDown       is the middle mouse button pressed
         * @param rightDown        is the right mouse button pressed
         * @param horizontalAmount the horizontal scroll amount
         * @param verticalAmount   the vertical scroll amount
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the event as handled, it will not be passed to other listeners and vanilla behavior will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onMouseScroll(boolean leftDown, boolean middleDown, boolean rightDown, double horizontalAmount, double verticalAmount);
    }

    @FunctionalInterface
    public interface KeyPress {

        /**
         * Called before a key press, release or repeat action is handled.
         * <p>
         * Note that on NeoForge due to the native implementation of this event cancelling a key press is not
         * supported.
         *
         * @param keyEvent the key event; for bundled values see {@link net.minecraft.class_3675}
         * @param action   the mouse button action; see {@link class_3675#field_31998}, {@link class_3675#field_31997},
         *                 {@link class_3675#field_31999}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the event as handled, it will not be passed to other listeners and vanilla behavior will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onKeyPress(class_11908 keyEvent, int action);
    }
}
