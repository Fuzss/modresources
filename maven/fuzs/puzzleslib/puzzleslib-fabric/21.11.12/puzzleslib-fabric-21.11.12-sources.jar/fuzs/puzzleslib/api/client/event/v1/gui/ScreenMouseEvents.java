package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.Objects;
import net.minecraft.class_11909;
import net.minecraft.class_437;

@SuppressWarnings("unchecked")
public final class ScreenMouseEvents {

    private ScreenMouseEvents() {
        // NO-OP
    }

    public static <T extends class_437> EventInvoker<BeforeMouseClick<T>> beforeMouseClick(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseClick<T>>) (Class<?>) BeforeMouseClick.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseClick<T>> afterMouseClick(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseClick<T>>) (Class<?>) AfterMouseClick.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeMouseRelease<T>> beforeMouseRelease(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseRelease<T>>) (Class<?>) BeforeMouseRelease.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseRelease<T>> afterMouseRelease(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseRelease<T>>) (Class<?>) AfterMouseRelease.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeMouseScroll<T>> beforeMouseScroll(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseScroll<T>>) (Class<?>) BeforeMouseScroll.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseScroll<T>> afterMouseScroll(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseScroll<T>>) (Class<?>) AfterMouseScroll.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeMouseDrag<T>> beforeMouseDrag(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseDrag<T>>) (Class<?>) BeforeMouseDrag.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseDrag<T>> afterMouseDrag(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseDrag<T>>) (Class<?>) AfterMouseDrag.class, screen);
    }

    @FunctionalInterface
    public interface BeforeMouseClick<T extends class_437> {

        /**
         * Called before a mouse button is pressed on a screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseButtonEvent the mouse button event; for bundled values see
         *                         {@link net.minecraft.class_3675}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the click event as handled, it will not be passed to other listeners and vanilla behaviour will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeMouseClick(T screen, class_11909 mouseButtonEvent);
    }

    @FunctionalInterface
    public interface AfterMouseClick<T extends class_437> {

        /**
         * Called after a mouse button is pressed on a screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseButtonEvent the mouse button event; for bundled values see
         *                         {@link net.minecraft.class_3675}
         */
        void onAfterMouseClick(T screen, class_11909 mouseButtonEvent);
    }

    @FunctionalInterface
    public interface BeforeMouseRelease<T extends class_437> {

        /**
         * Called before a mouse click has released on a screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseButtonEvent the mouse button event; for bundled values see
         *                         {@link net.minecraft.class_3675}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the release event as handled, it will not be passed to other listeners and vanilla behavior will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeMouseRelease(T screen, class_11909 mouseButtonEvent);
    }

    @FunctionalInterface
    public interface AfterMouseRelease<T extends class_437> {

        /**
         * Called after a mouse click has released on a screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseButtonEvent the mouse button event; for bundled values see
         *                         {@link net.minecraft.class_3675}
         */
        void onAfterMouseRelease(T screen, class_11909 mouseButtonEvent);
    }

    @FunctionalInterface
    public interface BeforeMouseScroll<T extends class_437> {

        /**
         * Called before a mouse has scrolled on a screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseX           the x-position of the mouse cursor
         * @param mouseY           the y-position of the mouse cursor
         * @param horizontalAmount the horizontal scroll amount
         * @param verticalAmount   the vertical scroll amount
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the scroll event as handled, it will not be passed to other listeners and vanilla behavior will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeMouseScroll(T screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount);
    }

    @FunctionalInterface
    public interface AfterMouseScroll<T extends class_437> {

        /**
         * Called after a mouse has scrolled on a screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseX           the x-position of the mouse cursor
         * @param mouseY           the y-position of the mouse cursor
         * @param horizontalAmount the horizontal scroll amount
         * @param verticalAmount   the vertical scroll amount
         */
        void onAfterMouseScroll(T screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount);
    }

    @FunctionalInterface
    public interface BeforeMouseDrag<T extends class_437> {

        /**
         * Called before a mouse is dragged on screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseButtonEvent the mouse button event; for bundled values see
         *                         {@link net.minecraft.class_3675}
         * @param dragX            the horizontal amount the cursor has been dragged since the last drag event
         * @param dragY            the vertical amount the cursor has been dragged since the last drag event
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the drag event as handled, it will not be passed to other listeners and vanilla behaviour will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeMouseDrag(T screen, class_11909 mouseButtonEvent, double dragX, double dragY);
    }

    @FunctionalInterface
    public interface AfterMouseDrag<T extends class_437> {

        /**
         * Called after a mouse is dragged on screen.
         *
         * @param screen           the currently displayed screen
         * @param mouseButtonEvent the mouse button event; for bundled values see
         *                         {@link net.minecraft.class_3675}
         * @param dragX            the horizontal amount the cursor has been dragged since the last drag event
         * @param dragY            the vertical amount the cursor has been dragged since the last drag event
         */
        void onAfterMouseDrag(T screen, class_11909 mouseButtonEvent, double dragX, double dragY);
    }
}
