package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_10151;
import net.minecraft.class_10201;
import net.minecraft.class_1060;
import net.minecraft.class_1069;
import net.minecraft.class_1070;
import net.minecraft.class_1076;
import net.minecraft.class_10831;
import net.minecraft.class_1092;
import net.minecraft.class_11327;
import net.minecraft.class_1144;
import net.minecraft.class_11697;
import net.minecraft.class_11939;
import net.minecraft.class_2960;
import net.minecraft.class_3302;
import net.minecraft.class_378;
import net.minecraft.class_4008;
import net.minecraft.class_4013;
import net.minecraft.class_4080;
import net.minecraft.class_5407;
import net.minecraft.class_6877;
import net.minecraft.class_761;
import net.minecraft.class_776;
import net.minecraft.class_824;
import net.minecraft.class_898;
import net.minecraft.class_9955;
import net.minecraft.client.resources.*;

/**
 * Adds listeners to the client (resource packs) resource manager to reload together with other resources.
 */
public interface ResourcePackReloadListenersContext {
    /**
     * The {@link class_1076} reload listener.
     */
    class_2960 LANGUAGES = class_2960.method_60656("languages");
    /**
     * The {@link class_1060} reload listener.
     */
    class_2960 TEXTURES = class_2960.method_60656("textures");
    /**
     * The {@link class_10151} reload listener.
     */
    class_2960 SHADERS = class_2960.method_60656("shaders");
    /**
     * The {@link class_1144} reload listener.
     */
    class_2960 SOUNDS = class_2960.method_60656("sounds");
    /**
     * The {@link class_4008} reload listener.
     */
    class_2960 SPLASH_TEXTS = class_2960.method_60656("splash_texts");
    /**
     * The {@link class_11697} reload listener.
     */
    class_2960 ATLASES = class_2960.method_60656("atlases");
    /**
     * The {@link class_378} reload listener.
     */
    class_2960 FONTS = class_2960.method_60656("fonts");
    /**
     * The {@link class_1069} reload listener.
     */
    class_2960 GRASS_COLORMAP = class_2960.method_60656("grass_colormap");
    /**
     * The {@link class_1070} reload listener.
     */
    class_2960 FOLIAGE_COLORMAP = class_2960.method_60656("foliage_colormap");
    /**
     * The {@link class_10831} reload listener.
     */
    class_2960 DRY_FOLIAGE_COLORMAP = class_2960.method_60656("dry_foliage_colormap");
    /**
     * The {@link class_1092} reload listener.
     */
    class_2960 MODELS = class_2960.method_60656("models");
    /**
     * The {@link class_10201} reload listener.
     */
    class_2960 EQUIPMENT_ASSETS = class_2960.method_60656("equipment_assets");
    /**
     * The {@link class_776} reload listener.
     */
    class_2960 BLOCK_RENDERER = class_2960.method_60656("block_renderer");
    /**
     * The {@link class_898} reload listener.
     */
    class_2960 ENTITY_RENDERER = class_2960.method_60656("entity_renderer");
    /**
     * The {@link class_824} reload listener.
     */
    class_2960 BLOCK_ENTITY_RENDERER = class_2960.method_60656("block_entity_renderer");
    /**
     * The {@link class_11939} reload listener.
     */
    class_2960 PARTICLE_RESOURCES = class_2960.method_60656("particle_resources");
    /**
     * The {@link class_11327} reload listener.
     */
    class_2960 WAYPOINT_STYLES = class_2960.method_60656("waypoint_styles");
    /**
     * The {@link class_761} reload listener.
     */
    class_2960 LEVEL_RENDERER = class_2960.method_60656("level_renderer");
    /**
     * The {@link class_9955} reload listener.
     */
    class_2960 CLOUD_RENDERER = class_2960.method_60656("cloud_renderer");
    /**
     * The {@link class_5407} reload listener.
     */
    class_2960 GPU_WARNLIST = class_2960.method_60656("gpu_warnlist");
    /**
     * The {@link class_6877} reload listener.
     */
    class_2960 REGIONAL_COMPLIANCES = class_2960.method_60656("regional_compliances");

    /**
     * Register a {@link class_3302}.
     *
     * @param identifier the reload listener identifier
     * @param reloadListener   the reload listener to add
     */
    void registerReloadListener(class_2960 identifier, class_3302 reloadListener);

    /**
     * Register a {@link class_3302}.
     *
     * @param identifier the reload listener identifier
     * @param otherIdentifier  the other reload listener identifier, either for the new listener or for the
     *                         existing vanilla listener
     * @param reloadListener   the reload listener to add
     */
    void registerReloadListener(class_2960 identifier, class_2960 otherIdentifier, class_3302 reloadListener);

    /**
     * Register a {@link class_4013}.
     *
     * @param identifier the reload listener identifier
     * @param reloadListener   the reload listener to add
     */
    default void registerReloadListener(class_2960 identifier, class_4013 reloadListener) {
        this.registerReloadListener(identifier, (class_3302) reloadListener);
    }

    /**
     * Register a {@link class_4013}.
     *
     * @param identifier the reload listener identifier, either for the new listener or for the existing
     *                         vanilla listener
     * @param otherIdentifier  the other reload listener identifier, either for the new listener or for the
     *                         existing vanilla listener
     * @param reloadListener   the reload listener to add
     */
    default void registerReloadListener(class_2960 identifier, class_2960 otherIdentifier, class_4013 reloadListener) {
        this.registerReloadListener(identifier, otherIdentifier, (class_3302) reloadListener);
    }

    /**
     * Register a {@link class_4080}.
     *
     * @param identifier the reload listener identifier, either for the new listener or for the existing
     *                         vanilla listener
     * @param reloadListener   the reload listener to add
     */
    default <T> void registerReloadListener(class_2960 identifier, class_4080<T> reloadListener) {
        this.registerReloadListener(identifier, (class_3302) reloadListener);
    }

    /**
     * Register a {@link class_4080}.
     *
     * @param identifier the reload listener identifier, either for the new listener or for the existing
     *                         vanilla listener
     * @param otherIdentifier  the other reload listener identifier, either for the new listener or for the
     *                         existing vanilla listener
     * @param reloadListener   the reload listener to add
     */
    default <T> void registerReloadListener(class_2960 identifier, class_2960 otherIdentifier, class_4080<T> reloadListener) {
        this.registerReloadListener(identifier, otherIdentifier, (class_3302) reloadListener);
    }
}
