package fuzs.puzzleslib.impl.content;

import fuzs.puzzleslib.api.core.v1.ModConstructor;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.objectweb.asm.Type;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.class_1294;
import net.minecraft.class_1928;
import net.minecraft.class_2960;

public class PuzzlesLibDevelopment extends PuzzlesLib implements ModConstructor {

    @Override
    public void onConstructMod() {
        CommandOverrides.registerEventHandlers();
    }

    @Override
    public void onCommonSetup() {
        initializeGameRules();
        initializeCommands();
    }

    private static void initializeCommands() {
        CommandOverrides.registerServerCommand("time set 4000", false);
        CommandOverrides.registerPlayerCommand("op @s", true);
        CommandOverrides.registerEffectCommand(class_1294.field_5925);
        CommandOverrides.registerEffectCommand(class_1294.field_5907);
        CommandOverrides.registerEffectCommand(class_1294.field_5918);
        CommandOverrides.registerEffectCommand(class_1294.field_5910);
        CommandOverrides.registerEffectCommand(class_1294.field_5923);
    }

    private static void initializeGameRules() {
        class_1928.field_19396.field_64173 = Boolean.FALSE;
        class_1928.field_19396.field_64173 = Boolean.FALSE;
        class_1928.field_19406.field_64173 = Boolean.FALSE;
        class_1928.field_19389.field_64173 = true;
        class_1928.field_56559.field_64173 = 0;
        class_1928.field_19388.field_64173 = Boolean.FALSE;
        class_1928.field_20637.field_64173 = Boolean.FALSE;
        class_1928.field_21831.field_64173 = Boolean.FALSE;
        class_1928.field_21832.field_64173 = Boolean.FALSE;
        class_1928.field_42474.field_64173 = Boolean.FALSE;
        class_1928.field_19405.field_64173 = 0;
        class_1928.field_46794.field_64173 = 1;
        class_1928.field_19394.field_64173 = Boolean.FALSE;
    }

    public static void printClazzComponentsWithoutAccess(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!Modifier.isPublic(field.getModifiers()) && !field.isSynthetic()) {
                LOGGER.info("transitive-accessible\tfield\t{}\t{}\t{}",
                        Type.getInternalName(field.getDeclaringClass()),
                        field.getName(),
                        Type.getDescriptor(field.getType()));
            }
        }

        for (Method method : clazz.getDeclaredMethods()) {
            if (!Modifier.isPublic(method.getModifiers()) && !method.isSynthetic()) {
                LOGGER.info("transitive-accessible\tmethod\t{}\t{}\t{}",
                        Type.getInternalName(method.getDeclaringClass()),
                        method.getName(),
                        Type.getMethodDescriptor(method));
            }
        }
    }

    public static class_2960 id(String path) {
        return class_2960.method_60655(MOD_ID, path);
    }
}
