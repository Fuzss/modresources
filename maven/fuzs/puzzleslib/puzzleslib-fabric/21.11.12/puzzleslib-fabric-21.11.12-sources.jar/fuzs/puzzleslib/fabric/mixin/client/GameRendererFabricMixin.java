package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import fuzs.puzzleslib.fabric.impl.client.core.context.EntitySpectatorShadersContextFabricImpl;
import fuzs.puzzleslib.impl.event.data.DefaultedFloat;
import net.minecraft.class_1297;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_757.class)
abstract class GameRendererFabricMixin {
    @Shadow
    @Final
    private class_4184 mainCamera;
    @Shadow
    @Nullable private class_2960 postEffectId;

    @Inject(method = "checkEntityPostEffect", at = @At("TAIL"))
    public void checkEntityPostEffect(@Nullable class_1297 entity, CallbackInfo callback) {
        // vanilla has set no effect, implements the same behaviour as NeoForge
        if (this.postEffectId == null) {
            EntitySpectatorShadersContextFabricImpl.getEntityShader(entity).ifPresent(this::setPostEffect);
        }
    }

    @Shadow
    protected abstract void setPostEffect(class_2960 identifier);

    @ModifyReturnValue(method = "getFov", at = @At("TAIL"))
    private float getFov(float fieldOfViewValue, class_4184 camera, float partialTicks, boolean useFOVSetting) {
        DefaultedFloat fieldOfView = DefaultedFloat.fromValue(fieldOfViewValue);
        FabricRendererEvents.COMPUTE_FIELD_OF_VIEW.invoker()
                .onComputeFieldOfView(class_757.class.cast(this), this.mainCamera, partialTicks, fieldOfView);
        return fieldOfView.getAsOptionalFloat().orElse(fieldOfViewValue);
    }
}
