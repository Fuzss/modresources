package fuzs.puzzleslib.api.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9285;

@FunctionalInterface
public interface ComputeItemAttributeModifiersCallback {
    EventInvoker<ComputeItemAttributeModifiersCallback> EVENT = EventInvoker.lookup(
            ComputeItemAttributeModifiersCallback.class);

    /**
     * Called when {@link class_9285} are being queried for an {@link class_1799}.
     *
     * @param item                   the item attribute modifiers are being queried for
     * @param itemAttributeModifiers the item attribute modifiers
     */
    void onComputeItemAttributeModifiers(class_1792 item, List<class_9285.class_9287> itemAttributeModifiers);
}
