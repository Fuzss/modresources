package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_6880;

public final class PlaySoundEvents {
    public static final EventInvoker<AtPosition> AT_POSITION = EventInvoker.lookup(AtPosition.class);
    public static final EventInvoker<AtEntity> AT_ENTITY = EventInvoker.lookup(AtEntity.class);

    private PlaySoundEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface AtPosition {

        /**
         * Called when a sound event is played at a specific position in a level.
         *
         * @param level       the current level
         * @param position    the position the sound is to be played at
         * @param soundEvent  the sound event
         * @param soundSource the sound source
         * @param soundVolume the sound volume
         * @param soundPitch  the sound pitch
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the sound from playing</li>
         *         <li>{@link EventResult#PASS PASS} to allow the sound to play normally</li>
         *         </ul>
         */
        EventResult onPlaySoundAtPosition(class_1937 level, class_243 position, MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch);
    }

    @FunctionalInterface
    public interface AtEntity {

        /**
         * Called when a sound event is played from a specific entity.
         *
         * @param level       the current level
         * @param entity      the entity the sound is playing from
         * @param soundEvent  the sound event
         * @param soundSource the sound source
         * @param soundVolume the sound volume
         * @param soundPitch  the sound pitch
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the sound from playing</li>
         *         <li>{@link EventResult#PASS PASS} to allow the sound to play normally</li>
         *         </ul>
         */
        EventResult onPlaySoundAtEntity(class_1937 level, class_1297 entity, MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch);
    }
}
