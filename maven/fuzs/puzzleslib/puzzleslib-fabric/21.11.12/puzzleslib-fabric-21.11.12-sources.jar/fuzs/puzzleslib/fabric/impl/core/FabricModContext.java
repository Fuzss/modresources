package fuzs.puzzleslib.fabric.impl.core;

import fuzs.puzzleslib.fabric.impl.config.FabricConfigHolderImpl;
import fuzs.puzzleslib.fabric.impl.init.FabricRegistryManager;
import fuzs.puzzleslib.impl.config.ConfigHolderImpl;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.init.RegistryManagerImpl;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_310;
import net.minecraft.class_3222;
import net.minecraft.class_634;
import net.minecraft.class_8709;
import java.util.Objects;

public final class FabricModContext extends ModContext {

    public FabricModContext(String modId) {
        super(modId);
        PayloadTypeRegistry.playC2S().register(this.payloadType, class_8709.field_48654);
        PayloadTypeRegistry.playS2C().register(this.payloadType, class_8709.field_48654);
        FabricProxy.get().setupHandshakePayload(this.payloadType);
    }

    @Override
    public boolean isPresentServerside() {
        class_634 clientPacketListener = class_310.method_1551().method_1562();
        return clientPacketListener != null && ClientPlayNetworking.canSend(this.payloadType);
    }

    @Override
    public boolean isPresentClientside(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return ServerPlayNetworking.canSend(serverPlayer.field_13987, this.payloadType);
    }

    @Override
    protected ConfigHolderImpl createConfigHolder(String modId) {
        return new FabricConfigHolderImpl(modId);
    }

    @Override
    protected RegistryManagerImpl createRegistryManager(String modId) {
        return new FabricRegistryManager(modId);
    }
}
