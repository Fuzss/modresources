package fuzs.puzzleslib.api.client.gui.v2.tooltip;

import com.mojang.blaze3d.systems.RenderSystem;
import fuzs.puzzleslib.api.util.v1.ComponentHelper;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1078;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/**
 * A small helper class for splitting instance of {@link class_5348}. Useful for splitting tooltip components.
 */
public final class ClientComponentSplitter {

    private ClientComponentSplitter() {
        // NO-OP
    }

    /**
     * Split formatted text instances.
     *
     * @param tooltipLines the lines for building the tooltip
     * @return the split components
     */
    public static List<class_2561> splitTooltipComponents(class_5348... tooltipLines) {
        return splitTooltipLines(tooltipLines).map(ComponentHelper::getAsComponent).toList();
    }

    /**
     * Split formatted text instances.
     *
     * @param tooltipLines the lines for building the tooltip
     * @return the split components
     */
    public static List<class_2561> splitTooltipComponents(List<? extends class_5348> tooltipLines) {
        return splitTooltipLines(tooltipLines).map(ComponentHelper::getAsComponent).toList();
    }

    /**
     * Split formatted text instances.
     *
     * @param tooltipLines the lines for building the tooltip
     * @return the stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(class_5348... tooltipLines) {
        return splitTooltipLines(Arrays.asList(tooltipLines));
    }

    /**
     * Split formatted text instances.
     *
     * @param tooltipLines the lines for building the tooltip
     * @return the stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(List<? extends class_5348> tooltipLines) {
        return splitTooltipLines(170, tooltipLines);
    }

    /**
     * Split formatted text instances according to a max width.
     *
     * @param maxWidth     the maximum text width for the line splitter
     * @param tooltipLines the lines for building the tooltip
     * @return the stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(int maxWidth, class_5348... tooltipLines) {
        return splitTooltipLines(maxWidth, Arrays.asList(tooltipLines));
    }

    /**
     * Split formatted text instances according to a max width.
     *
     * @param maxWidth     the maximum text width for the line splitter
     * @param tooltipLines the lines for building the tooltip
     * @return the stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(int maxWidth, List<? extends class_5348> tooltipLines) {
        return tooltipLines.stream().flatMap((class_5348 formattedText) -> {
            List<class_5481> lines;
            // this uses some font texture and throws if not on the render thread, like some worker or networking
            if (RenderSystem.isOnRenderThread()) {
                lines = class_310.method_1551().field_1772.method_1728(formattedText, maxWidth);
            } else {
                lines = class_2477.method_10517().method_30933(Collections.singletonList(formattedText));
            }

            if (lines.isEmpty()) {
                // empty components yield an empty list
                // since empty lines are desired on tooltips make sure they don't go missing
                return Stream.of(class_5481.field_26385);
            } else {
                return lines.stream();
            }
        });
    }

    /**
     * Process formatted text instances into char sequences.
     *
     * @param tooltipLines the lines for building the tooltip
     * @return the stream of char sequences
     */
    public static Stream<class_5481> processTooltipLines(class_5348... tooltipLines) {
        return processTooltipLines(Arrays.asList(tooltipLines));
    }

    /**
     * Process formatted text instances into char sequences.
     *
     * @param tooltipLines the lines for building the tooltip
     * @return the stream of char sequences
     */
    public static Stream<class_5481> processTooltipLines(List<? extends class_5348> tooltipLines) {
        return tooltipLines.stream().map((class_5348 formattedText) -> {
            return class_1078.method_10517().method_30934(formattedText);
        });
    }
}
