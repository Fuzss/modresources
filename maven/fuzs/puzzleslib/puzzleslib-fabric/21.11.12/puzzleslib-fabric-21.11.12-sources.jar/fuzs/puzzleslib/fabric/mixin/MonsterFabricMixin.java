package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import fuzs.puzzleslib.impl.event.data.DefaultedValue;
import net.minecraft.class_1299;
import net.minecraft.class_1314;
import net.minecraft.class_1588;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1588.class)
abstract class MonsterFabricMixin extends class_1314 {

    protected MonsterFabricMixin(class_1299<? extends class_1314> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyReturnValue(method = "getProjectile", at = @At("RETURN"))
    public class_1799 getProjectile(class_1799 projectileItemStack, class_1799 weaponItemStack) {
        if (weaponItemStack.method_7909() instanceof class_1811) {
            DefaultedValue<class_1799> projectileItemStackValue = DefaultedValue.fromValue(projectileItemStack);
            FabricLivingEvents.PICK_PROJECTILE.invoker()
                    .onPickProjectile(this, weaponItemStack, projectileItemStackValue);
            return projectileItemStackValue.getAsOptional().orElse(projectileItemStack);
        } else {
            return projectileItemStack;
        }
    }
}
