package fuzs.puzzleslib.impl.container;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public interface SlotsProvider {

    static SlotsProvider of(class_1263 container) {
        return new SlotsProvider() {
            @Override
            public int getContainerSize() {
                return container.method_5439();
            }

            @Override
            public class_1799 getItem(int slot) {
                return container.method_5438(slot);
            }

            @Override
            public void setItem(int slot, class_1799 itemStack) {
                container.method_5447(slot, itemStack);
            }

            @Override
            public void clearContent() {
                container.method_5448();
            }
        };
    }

    static SlotsProvider of(class_2371<class_1799> items) {
        return new SlotsProvider() {
            @Override
            public int getContainerSize() {
                return items.size();
            }

            @Override
            public class_1799 getItem(int slot) {
                return items.get(slot);
            }

            @Override
            public void setItem(int slot, class_1799 itemStack) {
                items.set(slot, itemStack);
            }

            @Override
            public void clearContent() {
                items.clear();
            }
        };
    }

    int getContainerSize();

    class_1799 getItem(int slot);

    void setItem(int slot, class_1799 itemStack);

    void clearContent();
}
