package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import net.minecraft.class_1087;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3300;

/**
 * Register a resolver responsible for mapping each {@link class_2680} of a block to an
 * {@link class_1087.class_9979}.
 * <p>
 * Replaces the vanilla {@code JSON} files found in {@code assets/<namespace>/blockstates/}.
 */
public interface BlockStateResolverContext {

    /**
     * @param block              the block to resolve block states for
     * @param blockStateConsumer the consumer resolving block states to individual unbaked block state models
     */
    void registerBlockStateResolver(class_2248 block, Consumer<BiConsumer<class_2680, class_1087.class_9979>> blockStateConsumer);

    /**
     * @param block              the block to resolve block states for
     * @param resourceLoader     the resource provider for asynchronously loaded data
     * @param blockStateConsumer the consumer resolving block states to individual unbaked block state models
     * @param <T>                the loaded data type
     */
    <T> void registerBlockStateResolver(class_2248 block, BiFunction<class_3300, Executor, CompletableFuture<T>> resourceLoader, BiConsumer<T, BiConsumer<class_2680, class_1087.class_9979>> blockStateConsumer);
}
