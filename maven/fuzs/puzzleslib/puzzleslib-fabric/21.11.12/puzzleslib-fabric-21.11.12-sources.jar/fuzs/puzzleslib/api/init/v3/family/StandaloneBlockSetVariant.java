package fuzs.puzzleslib.api.init.v3.family;

import org.jspecify.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_5794;

public abstract class StandaloneBlockSetVariant implements BlockSetVariant {
    private final String name;

    public StandaloneBlockSetVariant(String name) {
        this.name = name;
    }

    public StandaloneBlockSetVariant(class_5794.class_5796 variant) {
        this(variant.method_33498());
    }

    @Override
    public class_5794.@Nullable class_5796 toVanilla() {
        return null;
    }

    @Override
    public String toString() {
        return "Standalone[" + this.method_15434() + "]";
    }

    @Override
    public String method_15434() {
        return this.name;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        } else if (!(obj instanceof BlockSetVariant variant)) {
            return false;
        } else {
            return Objects.equals(this.method_15434(), variant.method_15434());
        }
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.method_15434());
    }
}
