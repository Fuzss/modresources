package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.client.renderer.v1.RenderStateExtraData;
import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;

/**
 * TODO rename to ExtractEntityRenderStateCallback
 */
@FunctionalInterface
public interface ExtractRenderStateCallback {
    EventInvoker<ExtractRenderStateCallback> EVENT = EventInvoker.lookup(ExtractRenderStateCallback.class);

    /**
     * Called during {@link class_897#method_62354(class_1297, class_10017, float)}, for setting up the
     * render state of an entity for future rendering.
     * <p>
     * Use methods found in {@link RenderStateExtraData} for attaching custom render state data.
     *
     * @param entity      the entity
     * @param renderState the entity render state
     * @param partialTick the partial tick
     */
    void onExtractRenderState(class_1297 entity, class_10017 renderState, float partialTick);
}
