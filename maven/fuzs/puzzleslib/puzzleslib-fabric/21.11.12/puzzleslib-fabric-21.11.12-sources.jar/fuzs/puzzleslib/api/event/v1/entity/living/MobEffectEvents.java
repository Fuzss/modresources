package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_6880;
import org.jspecify.annotations.Nullable;

public final class MobEffectEvents {
    public static final EventInvoker<Affects> AFFECTS = EventInvoker.lookup(Affects.class);
    public static final EventInvoker<Apply> APPLY = EventInvoker.lookup(Apply.class);
    public static final EventInvoker<Remove> REMOVE = EventInvoker.lookup(Remove.class);
    public static final EventInvoker<Expire> EXPIRE = EventInvoker.lookup(Expire.class);

    private MobEffectEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Affects {

        /**
         * Called when the game checks whether a new {@link class_1293} can be applied to a {@link class_1309}
         * in {@link class_1309#method_6049(class_1293)}.
         * <p>
         * This is used for mobs such as spiders to make them immune to
         * {@link net.minecraft.class_1294#field_5899}, or wither mobs to make them immune to the
         * {@link net.minecraft.class_1294#field_5920} effect.
         *
         * @param livingEntity the entity the check is run for
         * @param mobEffect    the effect instance to check
         * @return <ul>
         *         <li>{@link EventResult#ALLOW ALLOW} to allow this effect to be applied to the entity</li>
         *         <li>{@link EventResult#DENY DENY} to prevent this effect from being applied to the entity</li>
         *         <li>{@link EventResult#PASS PASS} to let vanilla logic handle this case</li>
         *         </ul>
         */
        EventResult onMobEffectAffects(class_1309 livingEntity, class_1293 mobEffect);
    }

    @FunctionalInterface
    public interface Apply {

        /**
         * Called when a new {@link class_1293} is added to a {@link class_1309} in
         * {@link class_1309#method_37222(class_1293, class_1297)}.
         * <p>
         * If another effect with the same {@link net.minecraft.class_1291} is already present, the existing
         * effect instance will be updated.
         *
         * @param livingEntity the living entity the effect instance is added to
         * @param newMobEffect the effect instance being added
         * @param oldMobEffect the potentially already existing effect instance with the same mob effect type
         * @param sourceEntity the potential other entity responsible for inflicting this new effect
         */
        void onMobEffectApply(class_1309 livingEntity, class_1293 newMobEffect, @Nullable class_1293 oldMobEffect, @Nullable class_1297 sourceEntity);
    }

    @FunctionalInterface
    public interface Remove {

        /**
         * Called when a {@link class_1293} is removed from a {@link class_1309} in
         * {@link class_1309#method_6016(class_6880)}.
         * <p>
         * Most importantly, this event runs when finishing drinking milk and allows for preventing certain effects from
         * being removed as a result.
         *
         * @param livingEntity the entity the effect instance is to be removed from
         * @param mobEffect    the effect instance to remove
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent this effect instance from being removed</li>
         *         <li>{@link EventResult#PASS PASS} to let vanilla logic handle this case</li>
         *         </ul>
         */
        EventResult onMobEffectRemove(class_1309 livingEntity, class_1293 mobEffect);
    }

    @FunctionalInterface
    public interface Expire {

        /**
         * Called when a {@link class_1293} is removed in {@link class_1309#method_6050()} due to the instance
         * duration having run out.
         * <p>
         * This is the case when {@link class_1293#method_48562()} returns {@code false}.
         *
         * @param livingEntity the living entity the effect instance has run out on
         * @param mobEffect    the mob effect instance that has run out
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent this effect instance from being removed</li>
         *         <li>{@link EventResult#PASS PASS} to let vanilla logic handle this case</li>
         *         </ul>
         */
        EventResult onMobEffectExpire(class_1309 livingEntity, class_1293 mobEffect);
    }
}
