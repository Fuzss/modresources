package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_11515;
import net.minecraft.class_2248;
import net.minecraft.class_3611;

/**
 * Register custom {@link class_11515 ChunkSectionLayers} for blocks and fluids.
 *
 * @param <T> type supported by provider, either {@link class_2248} or {@link class_3611}
 */
public interface RenderTypesContext<T> {

    /**
     * Register a {@link class_11515}.
     *
     * @param object            the object
     * @param chunkSectionLayer the chunk section layer
     */
    void registerChunkRenderType(T object, class_11515 chunkSectionLayer);

    /**
     * Allows for retrieving the {@link class_11515} that has been registered for an object.
     * <p>
     * When no render type is registered, {@link class_11515#field_60923} is returned.
     *
     * @param object the object
     * @return the chunk section layer
     */
    class_11515 getChunkRenderType(T object);
}
