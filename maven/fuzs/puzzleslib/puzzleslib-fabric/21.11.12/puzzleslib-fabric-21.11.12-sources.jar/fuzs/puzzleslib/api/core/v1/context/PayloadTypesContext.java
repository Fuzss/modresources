package fuzs.puzzleslib.api.core.v1.context;

import fuzs.puzzleslib.api.network.v4.message.configuration.ClientboundConfigurationMessage;
import fuzs.puzzleslib.api.network.v4.message.configuration.ServerboundConfigurationMessage;
import fuzs.puzzleslib.api.network.v4.message.play.ClientboundPlayMessage;
import fuzs.puzzleslib.api.network.v4.message.play.ServerboundPlayMessage;
import net.minecraft.class_2540;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Register custom messages that are compatible with vanilla {@link net.minecraft.class_2596 Packets}.
 */
public interface PayloadTypesContext {

    /**
     * Register a message that will be sent to clients during the play phase.
     *
     * @param clazz       the message class type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ClientboundPlayMessage> void playToClient(Class<T> clazz, class_9139<? super class_9129, T> streamCodec);

    /**
     * Register a message that will be sent to the server during the play phase.
     *
     * @param clazz       the message class type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ServerboundPlayMessage> void playToServer(Class<T> clazz, class_9139<? super class_9129, T> streamCodec);

    /**
     * Register a message that will be sent to clients during the configuration phase.
     *
     * @param clazz       the message class type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ClientboundConfigurationMessage> void configurationToClient(Class<T> clazz, class_9139<? super class_2540, T> streamCodec);

    /**
     * Register a message that will be sent to the server during the configuration phase.
     *
     * @param clazz       the message class type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ServerboundConfigurationMessage> void configurationToServer(Class<T> clazz, class_9139<? super class_2540, T> streamCodec);

    /**
     * Register a message that will be sent to clients during the play phase.
     *
     * @param payloadType the custom packet payload type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ClientboundPlayMessage> void playToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec);

    /**
     * Register a message that will be sent to the server during the play phase.
     *
     * @param payloadType the custom packet payload type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ServerboundPlayMessage> void playToServer(class_8710.class_9154<T> payloadType, class_9139<? super class_9129, T> streamCodec);

    /**
     * Register a message that will be sent to clients during the configuration phase.
     *
     * @param payloadType the custom packet payload type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ClientboundConfigurationMessage> void configurationToClient(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec);

    /**
     * Register a message that will be sent to the server during the configuration phase.
     *
     * @param payloadType the custom packet payload type
     * @param streamCodec the message stream codec
     * @param <T>         the message type
     */
    <T extends ServerboundConfigurationMessage> void configurationToServer(class_8710.class_9154<T> payloadType, class_9139<? super class_2540, T> streamCodec);

    /**
     * Are clients &amp; servers without this mod or vanilla clients &amp; servers compatible.
     * <p>
     * Not supported in Fabric-like environments.
     */
    void optional();
}
