package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

@FunctionalInterface
public interface ArrowLooseCallback {
    EventInvoker<ArrowLooseCallback> EVENT = EventInvoker.lookup(ArrowLooseCallback.class);

    /**
     * Called when the player stops using a bow or crossbow, just before the arrow is fired.
     *
     * @param player          the player firing the bow
     * @param weaponItemStack the weapon item stack
     * @param level           the level
     * @param chargeAmount    charge of the bow, can be changed to adjust the power the arrow is fired with
     * @param hasProjectile   does the player have ammo, is in creative, or has the infinity enchantment
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent an arrow from being fired</li>
     *         <li>{@link EventResult#PASS PASS} to let vanilla behavior run, which means an arrow is fired with all bow enchantments applied</li>
     *         </ul>
     */
    EventResult onArrowLoose(class_1657 player, class_1799 weaponItemStack, class_1937 level, MutableInt chargeAmount, boolean hasProjectile);
}
