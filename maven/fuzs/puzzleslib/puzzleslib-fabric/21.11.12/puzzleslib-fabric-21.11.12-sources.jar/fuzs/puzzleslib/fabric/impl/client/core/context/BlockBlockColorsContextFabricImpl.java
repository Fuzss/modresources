package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.BlockColorsContext;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_322;
import org.jspecify.annotations.Nullable;

import java.util.Objects;

public final class BlockBlockColorsContextFabricImpl implements BlockColorsContext {

    @Override
    public void registerBlockColor(class_2248 block, class_322 blockColor) {
        Objects.requireNonNull(blockColor, "block color is null");
        Objects.requireNonNull(block, "block is null");
        ColorProviderRegistry.BLOCK.register(blockColor, block);
    }

    @Override
    public @Nullable class_322 getBlockColor(class_2248 block) {
        return ColorProviderRegistry.BLOCK.get(block);
    }
}
