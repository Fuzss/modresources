package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.Function;
import net.minecraft.class_11239;
import net.minecraft.class_11256;
import net.minecraft.class_4597;

/**
 * Register renderers for custom gui elements, like an entity or the enchanting table book.
 * <p>
 * Requires the additional creation of a custom gui render state, which must be registered in
 * {@link
 * net.minecraft.class_11246#method_70922(class_11256)}.
 */
public interface PictureInPictureRenderersContext {

    /**
     * @param renderStateClazz                the render state class type
     * @param pictureInPictureRendererFactory the factory for the custom renderer
     * @param <T>                             the supported render state
     */
    <T extends class_11256> void registerPictureInPictureRenderer(Class<T> renderStateClazz, Function<class_4597.class_4598, class_11239<T>> pictureInPictureRendererFactory);
}
