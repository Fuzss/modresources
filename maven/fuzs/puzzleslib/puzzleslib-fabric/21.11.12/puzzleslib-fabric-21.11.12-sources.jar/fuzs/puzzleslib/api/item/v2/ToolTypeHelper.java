package fuzs.puzzleslib.api.item.v2;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_10192;
import net.minecraft.class_1743;
import net.minecraft.class_1753;
import net.minecraft.class_1764;
import net.minecraft.class_1787;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1835;
import net.minecraft.class_3489;
import net.minecraft.class_8051;
import net.minecraft.class_8162;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.world.item.*;
import org.jetbrains.annotations.MustBeInvokedByOverriders;

/**
 * A small helper class for testing an item stack for a given tool type.
 * <p>
 * Mainly exists for handling item tags across different mod loaders as well as NeoForge's item abilities feature.
 * <p>
 * Inspired by <code>ToolFunctionsHelper</code> found in the <a
 * href="https://github.com/Serilum/Collective">Collective</a> mod.
 */
public interface ToolTypeHelper {
    /**
     * the instance
     */
    ToolTypeHelper INSTANCE = ProxyImpl.get().getToolTypeHelper();

    /**
     * Tests if an item stack is a sword.
     *
     * @param itemStack the item stack to test
     * @return is this stack a sword
     */
    @MustBeInvokedByOverriders
    default boolean isSword(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_42611);
    }

    /**
     * Tests if an item stack is an axe.
     *
     * @param itemStack the item stack to test
     * @return is this stack an axe
     */
    @MustBeInvokedByOverriders
    default boolean isAxe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1743 || itemStack.method_31573(class_3489.field_42612);
    }

    /**
     * Tests if an item stack is a hoe.
     *
     * @param itemStack the item stack to test
     * @return is this stack a hoe
     */
    @MustBeInvokedByOverriders
    default boolean isHoe(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1794 || itemStack.method_31573(class_3489.field_42613);
    }

    /**
     * Tests if an item stack is a pickaxe.
     *
     * @param itemStack the item stack to test
     * @return is this stack a pickaxe
     */
    @MustBeInvokedByOverriders
    default boolean isPickaxe(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_42614);
    }

    /**
     * Tests if an item stack is a shovel.
     *
     * @param itemStack the item stack to test
     * @return is this stack a shovel
     */
    @MustBeInvokedByOverriders
    default boolean isShovel(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1743 || itemStack.method_31573(class_3489.field_42615);
    }

    /**
     * Tests if an item stack is a shears item.
     *
     * @param itemStack the item stack to test
     * @return is this stack a shears item
     */
    @MustBeInvokedByOverriders
    default boolean isShears(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1820;
    }

    /**
     * Tests if an item stack is a shield.
     *
     * @param itemStack the item stack to test
     * @return is this stack a shield
     */
    @MustBeInvokedByOverriders
    default boolean isShield(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1819;
    }

    /**
     * Tests if an item stack is a bow.
     *
     * @param itemStack the item stack to test
     * @return is this stack a bow
     */
    @MustBeInvokedByOverriders
    default boolean isBow(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1753;
    }

    /**
     * Tests if an item stack is a crossbow.
     *
     * @param itemStack the item stack to test
     * @return is this stack a crossbow
     */
    @MustBeInvokedByOverriders
    default boolean isCrossbow(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1764;
    }

    /**
     * Tests if an item stack is a fishing rod.
     *
     * @param itemStack the item stack to test
     * @return is this stack a fishing rod
     */
    @MustBeInvokedByOverriders
    default boolean isFishingRod(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1787;
    }

    /**
     * Tests if an item stack is similar to a trident, like a spear.
     *
     * @param itemStack the item stack to test
     * @return is this stack a trident
     */
    @MustBeInvokedByOverriders
    default boolean isTridentLike(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_1835;
    }

    /**
     * Tests if an item stack is similar to a brush.
     *
     * @param itemStack the item stack to test
     * @return is this stack a brush
     */
    @MustBeInvokedByOverriders
    default boolean isBrush(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_8162;
    }

    /**
     * Tests if an item stack is similar to a mace, like a club.
     *
     * @param itemStack the item stack to test
     * @return is this stack a mace
     */
    @MustBeInvokedByOverriders
    default boolean isMace(class_1799 itemStack) {
        return itemStack.method_7909() instanceof class_9362;
    }

    /**
     * Tests if an item stack is similar to a mace, like a club.
     *
     * @param itemStack the item stack to test
     * @return is this stack a spear
     */
    @MustBeInvokedByOverriders
    default boolean isSpear(class_1799 itemStack) {
        return itemStack.method_31573(class_3489.field_63257);
    }

    /**
     * Tests if an item stack is a weapon used for melee combat.
     *
     * @param itemStack the item stack to test
     * @return is this stack a melee weapon
     */
    @MustBeInvokedByOverriders
    default boolean isMeleeWeapon(class_1799 itemStack) {
        return this.isSword(itemStack) || this.isAxe(itemStack) || this.isTridentLike(itemStack) ||
                this.isMace(itemStack) || this.isSpear(itemStack);
    }

    /**
     * Tests if an item stack is a weapon used for ranged combat.
     *
     * @param itemStack the item stack to test
     * @return is this stack a ranged weapon
     */
    @MustBeInvokedByOverriders
    default boolean isRangedWeapon(class_1799 itemStack) {
        return this.isBow(itemStack) || this.isCrossbow(itemStack) || this.isTridentLike(itemStack);
    }

    /**
     * Tests if an item stack is a weapon.
     *
     * @param itemStack the item stack to test
     * @return is this stack a weapon
     */
    @MustBeInvokedByOverriders
    default boolean isWeapon(class_1799 itemStack) {
        return this.isMeleeWeapon(itemStack) || this.isRangedWeapon(itemStack);
    }

    /**
     * Tests if an item stack is a tool used for mining blocks.
     *
     * @param itemStack the item stack to test
     * @return is this stack a mining tool
     */
    @MustBeInvokedByOverriders
    default boolean isMiningTool(class_1799 itemStack) {
        return this.isAxe(itemStack) || this.isHoe(itemStack) || this.isPickaxe(itemStack) || this.isShovel(itemStack);
    }

    /**
     * Tests if an item stack is any sort of tool.
     *
     * @param itemStack the item stack to test
     * @return is this stack a tool
     */
    @MustBeInvokedByOverriders
    default boolean isTool(class_1799 itemStack) {
        return this.isMiningTool(itemStack) || this.isWeapon(itemStack) || this.isShears(itemStack) ||
                this.isShield(itemStack) || this.isFishingRod(itemStack) || this.isBrush(itemStack);
    }

    /**
     * Tests if an item stack can be equipped as head armor.
     *
     * @param itemStack the item stack to test
     * @return is this stack head armor
     */
    @MustBeInvokedByOverriders
    default boolean isHeadArmor(class_1799 itemStack) {
        return this.isArmor(itemStack, class_8051.field_41934) || itemStack.method_31573(class_3489.field_48297);
    }

    /**
     * Tests if an item stack can be equipped as chest armor.
     *
     * @param itemStack the item stack to test
     * @return is this stack chest armor
     */
    @MustBeInvokedByOverriders
    default boolean isChestArmor(class_1799 itemStack) {
        return this.isArmor(itemStack, class_8051.field_41935) || itemStack.method_31573(class_3489.field_48296);
    }

    /**
     * Tests if an item stack can be equipped as leg armor.
     *
     * @param itemStack the item stack to test
     * @return is this stack leg armor
     */
    @MustBeInvokedByOverriders
    default boolean isLegArmor(class_1799 itemStack) {
        return this.isArmor(itemStack, class_8051.field_41936) || itemStack.method_31573(class_3489.field_48295);
    }

    /**
     * Tests if an item stack can be equipped as foot armor.
     *
     * @param itemStack the item stack to test
     * @return is this stack foot armor
     */
    @MustBeInvokedByOverriders
    default boolean isFootArmor(class_1799 itemStack) {
        return this.isArmor(itemStack, class_8051.field_41937) || itemStack.method_31573(class_3489.field_48294);
    }

    /**
     * Tests if an item stack can be equipped as body armor.
     *
     * @param itemStack the item stack to test
     * @return is this stack body armor
     */
    @MustBeInvokedByOverriders
    default boolean isBodyArmor(class_1799 itemStack) {
        return this.isArmor(itemStack, class_8051.field_48838);
    }

    /**
     * Tests if an item stack can be equipped as a type of armor.
     *
     * @param itemStack the item stack to test
     * @param armorType the type of armor
     * @return is this stack that type of armor
     */
    @MustBeInvokedByOverriders
    private boolean isArmor(class_1799 itemStack, class_8051 armorType) {
        class_10192 equippable = itemStack.method_58694(class_9334.field_54196);
        return equippable != null && equippable.comp_3174() == armorType.method_48399();
    }

    /**
     * Tests if an item stack can be equipped as armor.
     *
     * @param itemStack the item stack to test
     * @return is this stack armor
     */
    @MustBeInvokedByOverriders
    default boolean isArmor(class_1799 itemStack) {
        return this.isHeadArmor(itemStack) || this.isChestArmor(itemStack) || this.isLegArmor(itemStack) ||
                this.isFootArmor(itemStack) || this.isBodyArmor(itemStack);
    }
}
