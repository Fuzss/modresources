package fuzs.puzzleslib.api.network.v4.message.play;

import fuzs.puzzleslib.api.network.v4.NetworkingHelper;
import fuzs.puzzleslib.api.network.v4.message.Message;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_8705;

/**
 * Template for a message sent by the server and received by a client during the play phase.
 */
public interface ClientboundPlayMessage extends Message<ClientboundPlayMessage.Context> {

    @Override
    default class_2596<class_8705> toPacket() {
        return NetworkingHelper.toClientboundPacket(this);
    }

    /**
     * The context provided in {@link #getListener()}.
     */
    interface Context extends Message.Context<class_634> {

        /**
         * @return the client
         */
        class_310 client();

        /**
         * @return the player
         */
        class_746 player();

        /**
         * @return the level
         */
        class_638 level();
    }
}
