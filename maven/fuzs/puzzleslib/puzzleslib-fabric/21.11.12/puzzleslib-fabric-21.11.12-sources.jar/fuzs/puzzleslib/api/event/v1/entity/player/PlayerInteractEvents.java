package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3965;

public final class PlayerInteractEvents {
    public static final EventInvoker<UseBlock> USE_BLOCK = EventInvoker.lookup(UseBlock.class);
    public static final EventInvoker<AttackBlock> ATTACK_BLOCK = EventInvoker.lookup(AttackBlock.class);
    public static final EventInvoker<UseItem> USE_ITEM = EventInvoker.lookup(UseItem.class);
    public static final EventInvoker<UseEntity> USE_ENTITY = EventInvoker.lookup(UseEntity.class);
    public static final EventInvoker<UseEntityAt> USE_ENTITY_AT = EventInvoker.lookup(UseEntityAt.class);
    public static final EventInvoker<AttackEntity> ATTACK_ENTITY = EventInvoker.lookup(AttackEntity.class);

    private PlayerInteractEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface UseBlock {

        /**
         * This event is fired on both sides before the player triggers
         * {@link net.minecraft.class_2248#method_55765(class_1799, class_2680, class_1937, class_2338, class_1657,
         * class_1268, class_3965)} by right-clicking.
         *
         * @param player          the player interacting with the block
         * @param level           the level the interaction is happening in
         * @param interactionHand the hand the player is using to interact
         * @param hitResult       the targeted block
         * @return {@link EventResultHolder#interrupt(Object)} to cancel vanilla interaction, returning the instance
         *         supplier to the holder instead, {@link EventResultHolder#pass()} to allow the vanilla behavior for
         *         this interaction to proceed
         */
        EventResultHolder<class_1269> onUseBlock(class_1657 player, class_1937 level, class_1268 interactionHand, class_3965 hitResult);
    }

    @FunctionalInterface
    public interface AttackBlock {

        /**
         * This event is fired on both sides before the player triggers
         * {@link net.minecraft.class_2248#method_9606(class_2680, class_1937, class_2338, class_1657)} by left-clicking.
         *
         * @param player          the player interacting with the block
         * @param level           the level the interaction is happening in
         * @param interactionHand the hand the player is using to interact
         * @param blockPos        the position of the block in the <code>level</code>
         * @param direction       the direction the block is clicked at
         * @return {@link EventResult#INTERRUPT} to prevent the player from beginning to mine the block,
         *         {@link EventResult#PASS} to allow the vanilla behavior for this interaction to proceed
         */
        EventResult onAttackBlock(class_1657 player, class_1937 level, class_1268 interactionHand, class_2338 blockPos, class_2350 direction);
    }

    @FunctionalInterface
    public interface UseItem {

        /**
         * This event is fired on both sides before the player triggers {@link class_1792#method_7836(class_1937, class_1657, class_1268)}
         * by right-clicking an item.
         *
         * @param player          the player using the item
         * @param level           the level the interaction is happening in
         * @param interactionHand the hand the player is holding the item
         * @return {@link EventResultHolder#interrupt(Object)} to cancel vanilla interaction, returning the instance
         *         supplier to the holder instead, {@link EventResultHolder#pass()} to allow the vanilla behavior for
         *         this interaction to proceed
         */
        EventResultHolder<class_1269> onUseItem(class_1657 player, class_1937 level, class_1268 interactionHand);
    }

    @FunctionalInterface
    public interface UseEntity {

        /**
         * Called when the player clicks an entity, runs on the player first, then proceeds to calling
         * {@link class_1297#method_5688(class_1657, class_1268)}.
         * <p>This type of interaction also allows for opening menus via an entity implementing {@link class_3908}.
         *
         * @param player          the player interacting with the entity
         * @param level           the level the interaction is happening in
         * @param interactionHand the hand the player is using to interact
         * @param entity          the entity this interaction is happening on
         * @return {@link EventResultHolder#interrupt(Object)} to cancel vanilla interaction, returning the instance
         *         supplier to the holder instead, {@link EventResultHolder#pass()} to allow the vanilla behavior for
         *         this interaction to proceed
         */
        EventResultHolder<class_1269> onUseEntity(class_1657 player, class_1937 level, class_1268 interactionHand, class_1297 entity);
    }

    @FunctionalInterface
    public interface UseEntityAt {

        /**
         * Called when the player clicks an entity, this interaction includes the exact position where the player
         * clicked on the entity's bounding box.
         * <p>For this interaction {@link class_1297#method_5664(class_1657, class_243, class_1268)} is called, if it returns
         * {@link class_1269#field_5811} more interactions are tried.
         *
         * @param player          the player interacting with the entity
         * @param level           the level the interaction is happening in
         * @param interactionHand the hand the player is using to interact
         * @param entity          the entity this interaction is happening on
         * @param hitVector       the exact position where the player has clicked on the entity's bounding box
         * @return {@link EventResultHolder#interrupt(Object)} to cancel vanilla interaction, returning the instance
         *         supplier to the holder instead, {@link EventResultHolder#pass()} to allow the vanilla behavior for
         *         this interaction to proceed
         */
        EventResultHolder<class_1269> onUseEntityAt(class_1657 player, class_1937 level, class_1268 interactionHand, class_1297 entity, class_243 hitVector);
    }

    @FunctionalInterface
    public interface AttackEntity {

        /**
         * Called before a player attack another entity in {@link class_1657#method_7324(class_1297)}. Allows for preventing the
         * attack.
         *
         * @param player          the player that is attacking
         * @param level           the level the interaction is happening in
         * @param interactionHand the hand the player is using to interact
         * @param entity          the entity under attack
         * @return {@link EventResult#INTERRUPT} to prevent the entity from being attacked, allows for processing
         *         different actions on hitting an entity, {@link EventResult#PASS} to allow the entity to be attack
         */
        EventResult onAttackEntity(class_1657 player, class_1937 level, class_1268 interactionHand, class_1297 entity);
    }
}
