package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Cancellable;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import com.llamalad7.mixinextras.sugar.ref.LocalDoubleRef;
import com.llamalad7.mixinextras.sugar.ref.LocalFloatRef;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableDouble;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.fabric.impl.event.CapturedDropsEntity;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import fuzs.puzzleslib.impl.PuzzlesLib;
import fuzs.puzzleslib.impl.event.EventImplHelper;
import fuzs.puzzleslib.impl.event.data.DefaultedDouble;
import fuzs.puzzleslib.impl.event.data.DefaultedFloat;
import fuzs.puzzleslib.impl.event.data.DefaultedInt;
import fuzs.puzzleslib.impl.event.data.DefaultedValue;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jspecify.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_6880;

@Mixin(class_1309.class)
abstract class LivingEntityFabricMixin extends class_1297 implements CapturedDropsEntity {
    @Shadow
    protected class_1799 useItem;
    @Shadow
    protected int useItemRemaining;
    @Shadow
    protected int lastHurtByPlayerMemoryTime;
    @Shadow
    @Final
    private Map<class_6880<class_1291>, class_1293> activeEffects;

    public LivingEntityFabricMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    public void die(class_1282 damageSource, CallbackInfo callback) {
        EventResult eventResult = FabricLivingEvents.LIVING_DEATH.invoker()
                .onLivingDeath(class_1309.class.cast(this), damageSource);
        if (eventResult.isInterrupt()) {
            callback.cancel();
        }
    }

    @Inject(method = "startUsingItem",
            at = @At(value = "FIELD",
                     target = "Lnet/minecraft/world/entity/LivingEntity;useItemRemaining:I",
                     shift = At.Shift.AFTER,
                     opcode = Opcodes.PUTFIELD),
            cancellable = true)
    public void startUsingItem(class_1268 interactionHand, CallbackInfo callback) {
        // this injects after the field is already updated, so it is fine to use instead of ItemStack::getUseDuration
        DefaultedInt useItemRemaining = DefaultedInt.fromValue(this.useItemRemaining);
        EventResult eventResult = FabricLivingEvents.USE_ITEM_START.invoker()
                .onUseItemStart(class_1309.class.cast(this), this.useItem, interactionHand, useItemRemaining);
        if (eventResult.isInterrupt()) {
            this.useItem = class_1799.field_8037;
            this.useItemRemaining = 0;
            callback.cancel();
        } else {
            this.useItemRemaining = useItemRemaining.getAsOptionalInt().orElse(this.useItemRemaining);
        }
    }

    @Inject(method = "updateUsingItem", at = @At("HEAD"), cancellable = true)
    protected void updateUsingItem(class_1799 usingItem, CallbackInfo callback) {
        if (!usingItem.method_7960()) {
            DefaultedInt remainingUseDuration = DefaultedInt.fromValue(this.getUseItemRemainingTicks());
            EventResult eventResult = FabricLivingEvents.USE_ITEM_TICK.invoker()
                    .onUseItemTick(class_1309.class.cast(this),
                            usingItem,
                            this.getUsedItemHand(),
                            remainingUseDuration);
            // --this.useItemRemaining == 0 runs at the end of this method, when 0 is set increase by one again,
            // so that LivingEntity::completeUsingItem does run
            remainingUseDuration.getAsOptionalInt()
                    .ifPresent((int useItemRemaining) -> this.useItemRemaining =
                            useItemRemaining == 0 ? 1 : useItemRemaining);
            if (eventResult.isInterrupt()) {
                // this copies LivingEntity::updateUsingItem without calling ItemStack::onUseTick
                if (--this.useItemRemaining == 0 && !this.method_73183().method_8608() && !usingItem.method_7967()) {
                    this.completeUsingItem();
                }

                callback.cancel();
            }
        }
    }

    @Shadow
    public abstract int getUseItemRemainingTicks();

    @Shadow
    protected abstract void completeUsingItem();

    @Shadow
    private void updatingUsingItem() {
        throw new RuntimeException();
    }

    @Inject(method = "completeUsingItem",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/world/item/ItemStack;finishUsingItem(Lnet/minecraft/world/level/Level;Lnet/minecraft/world/entity/LivingEntity;)Lnet/minecraft/world/item/ItemStack;"))
    protected void completeUsingItem(CallbackInfo callback, @Share("originalUseItem") LocalRef<class_1799> originalUseItem) {
        originalUseItem.set(this.useItem.method_7972());
    }

    @ModifyVariable(method = "completeUsingItem", at = @At("STORE"), ordinal = 0)
    protected class_1799 completeUsingItem(class_1799 useItem, @Share("originalUseItem") LocalRef<class_1799> originalUseItem) {
        Objects.requireNonNull(originalUseItem.get(), "original use item is null");
        DefaultedValue<class_1799> itemStack = DefaultedValue.fromValue(useItem);
        FabricLivingEvents.USE_ITEM_FINISH.invoker()
                .onUseItemFinish(class_1309.class.cast(this),
                        itemStack,
                        originalUseItem.get(),
                        this.getUsedItemHand());
        return itemStack.getAsOptional().orElse(useItem);
    }

    @Shadow
    public abstract void stopUsingItem();

    @Inject(method = "releaseUsingItem", at = @At("HEAD"), cancellable = true)
    public void releaseUsingItem(CallbackInfo callback) {
        if (!this.useItem.method_7960()) {
            if (FabricLivingEvents.USE_ITEM_STOP.invoker()
                    .onUseItemStop(class_1309.class.cast(this),
                            this.useItem,
                            this.getUsedItemHand(),
                            this.useItemRemaining)
                    .isPass()) {
                return;
            }
            if (this.useItem.method_7967()) {
                this.updatingUsingItem();
            }

            this.stopUsingItem();
            callback.cancel();
        }
    }

    @Inject(method = "dropAllDeathLoot", at = @At("HEAD"))
    protected void dropAllDeathLoot$1(class_3218 level, class_1282 damageSource, CallbackInfo callback) {
        this.puzzleslib$acceptCapturedDrops(new ArrayList<>());
    }

    @Inject(method = "dropAllDeathLoot", at = @At("TAIL"))
    protected void dropAllDeathLoot$2(class_3218 level, class_1282 damageSource, CallbackInfo callback) {
        if (!FabricEventImplHelper.tryOnLivingDrops(class_1309.class.cast(this),
                damageSource,
                this.lastHurtByPlayerMemoryTime)) {
            PuzzlesLib.LOGGER.warn("Unable to invoke LivingDropsCallback for entity {}: Drops is null",
                    this.method_5477().getString());
        }
    }

    @Inject(method = "die", at = @At("TAIL"))
    public void die$1(class_1282 damageSource, CallbackInfo callback) {
        // this is a safety precaution, in case LivingEntity::dropAllDeathLoot does not reach TAIL and therefore doesn't spawn the captured drops (another mixin might cancel the method mid-way)
        // this should work rather fine, as LivingEntity::dropAllDeathLoot is basically exclusively called from LivingEntity::die,
        // and spawning captured drops in LivingEntity::dropAllDeathLoot only rarely has a conflict if any at all
        FabricEventImplHelper.tryOnLivingDrops(class_1309.class.cast(this),
                damageSource,
                this.lastHurtByPlayerMemoryTime);
    }

    @Inject(method = "drop",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/world/level/Level;addFreshEntity(Lnet/minecraft/world/entity/Entity;)Z"),
            cancellable = true)
    public void drop(CallbackInfoReturnable<class_1542> callback, @Local class_1542 itemEntity) {
        Collection<class_1542> capturedDrops = this.puzzleslib$getCapturedDrops();
        if (capturedDrops != null) {
            capturedDrops.add(itemEntity);
            callback.setReturnValue(itemEntity);
        }
    }

    @Inject(method = "dropExperience",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/world/entity/ExperienceOrb;award(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/phys/Vec3;I)V"),
            cancellable = true)
    protected void dropExperience(class_3218 serverLevel, @Nullable class_1297 killer, CallbackInfo callback) {
        DefaultedInt experienceReward = DefaultedInt.fromValue(this.getBaseExperienceReward(serverLevel));
        EventResult eventResult = FabricLivingEvents.EXPERIENCE_DROP.invoker()
                .onLivingExperienceDrop(class_1309.class.cast(this), this.getLastHurtByPlayer(), experienceReward);
        if (eventResult.isInterrupt()) {
            callback.cancel();
        } else {
            experienceReward.getAsOptionalInt().ifPresent((int value) -> {
                class_1303.method_31493((class_3218) this.method_73183(), this.method_73189(), value);
                callback.cancel();
            });
        }
    }

    @Shadow
    protected abstract int getBaseExperienceReward(class_3218 serverLevel);

    @Shadow
    public abstract @Nullable class_1657 getLastHurtByPlayer();

    @ModifyVariable(method = "actuallyHurt", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    protected float actuallyHurt(float damageAmount, class_3218 serverLevel, class_1282 damageSource, @Cancellable CallbackInfo callback) {
        if (!this.isInvulnerableTo(serverLevel, damageSource)) {
            MutableBoolean preventHurting = new MutableBoolean();
            damageAmount = FabricEventImplHelper.onLivingHurt(class_1309.class.cast(this),
                    serverLevel,
                    damageSource,
                    damageAmount,
                    preventHurting);
            if (preventHurting.booleanValue()) {
                callback.cancel();
            }
        }

        return damageAmount;
    }

    @Shadow
    public abstract boolean isInvulnerableTo(class_3218 serverLevel, class_1282 damageSource);

    @ModifyExpressionValue(method = "applyItemBlocking",
                           at = @At(value = "INVOKE",
                                    target = "Lnet/minecraft/world/item/component/BlocksAttacks;resolveBlockedDamage(Lnet/minecraft/world/damagesource/DamageSource;FD)F"))
    public float applyItemBlocking(float blockedDamage, class_3218 serverLevel, class_1282 damageSource, float damageAmount, @Cancellable CallbackInfoReturnable<Float> callback) {
        DefaultedFloat blockedDamageValue = DefaultedFloat.fromValue(blockedDamage);
        EventResult eventResult = FabricLivingEvents.SHIELD_BLOCK.invoker()
                .onShieldBlock(class_1309.class.cast(this), damageSource, blockedDamageValue);
        if (eventResult.isInterrupt()) {
            callback.setReturnValue(0.0F);
            return 0.0F;
        } else {
            return blockedDamageValue.getAsFloat();
        }
    }

    @Inject(method = "causeFallDamage", at = @At("HEAD"), cancellable = true)
    public void causeFallDamage(CallbackInfoReturnable<Boolean> callback, @Local(ordinal = 0,
                                                                                 argsOnly = true) LocalDoubleRef fallDistanceRef, @Local(
            ordinal = 0,
            argsOnly = true) LocalFloatRef damageMultiplierRef) {
        MutableDouble fallDistance = MutableDouble.fromEvent(fallDistanceRef::set, fallDistanceRef::get);
        MutableFloat damageMultiplier = MutableFloat.fromEvent(damageMultiplierRef::set, damageMultiplierRef::get);
        EventResult eventResult = FabricLivingEvents.LIVING_FALL.invoker()
                .onLivingFall(class_1309.class.cast(this), fallDistance, damageMultiplier);
        if (eventResult.isInterrupt()) {
            callback.setReturnValue(false);
        }
    }

    @Inject(method = "knockback", at = @At("HEAD"), cancellable = true)
    public void knockback(CallbackInfo callback, @Local(ordinal = 0,
                                                        argsOnly = true) LocalDoubleRef strengthRef, @Local(ordinal = 1,
                                                                                                            argsOnly = true) LocalDoubleRef ratioXRef, @Local(
            ordinal = 2,
            argsOnly = true) LocalDoubleRef ratioZRef) {
        MutableDouble knockbackStrength = MutableDouble.fromEvent(strengthRef::set, strengthRef::get);
        MutableDouble ratioX = MutableDouble.fromEvent(ratioXRef::set, ratioXRef::get);
        MutableDouble ratioZ = MutableDouble.fromEvent(ratioZRef::set, ratioZRef::get);
        EventResult eventResult = FabricLivingEvents.LIVING_KNOCK_BACK.invoker()
                .onLivingKnockBack(class_1309.class.cast(this), knockbackStrength, ratioX, ratioZ);
        if (eventResult.isInterrupt()) {
            callback.cancel();
        }
    }

    @ModifyVariable(method = "addEffect(Lnet/minecraft/world/effect/MobEffectInstance;Lnet/minecraft/world/entity/Entity;)Z",
                    at = @At("STORE"),
                    ordinal = 1)
    public class_1293 addEffect(@Nullable class_1293 oldEffectInstance, class_1293 mobEffect, @Nullable class_1297 entity) {
        FabricLivingEvents.MOB_EFFECT_APPLY.invoker()
                .onMobEffectApply(class_1309.class.cast(this), mobEffect, oldEffectInstance, entity);
        return oldEffectInstance;
    }

    @Inject(method = "canBeAffected", at = @At("HEAD"), cancellable = true)
    public void canBeAffected(class_1293 mobEffect, CallbackInfoReturnable<Boolean> callback) {
        // Forge also adds this patch to spiders, but let's just say no one wants to remove poison immunity from them
        // Forge is incomplete anyway, with mobs are not affected by this event when checking for the wither effect
        EventResult eventResult = FabricLivingEvents.MOB_EFFECT_AFFECTS.invoker()
                .onMobEffectAffects(class_1309.class.cast(this), mobEffect);
        if (eventResult.isInterrupt()) {
            callback.setReturnValue(eventResult.getAsBoolean());
        }
    }

    @Inject(method = "removeEffect", at = @At("HEAD"), cancellable = true)
    public void removeEffect(class_6880<class_1291> effect, CallbackInfoReturnable<Boolean> callback) {
        class_1293 mobEffect = this.getEffect(effect);
        if (mobEffect != null) {
            EventResult eventResult = FabricLivingEvents.MOB_EFFECT_REMOVE.invoker()
                    .onMobEffectRemove(class_1309.class.cast(this), mobEffect);
            if (eventResult.isInterrupt()) {
                callback.setReturnValue(false);
            }
        }
    }

    @Shadow
    public abstract @Nullable class_1293 getEffect(class_6880<class_1291> effect);

    @Inject(method = "removeAllEffects", at = @At("HEAD"), cancellable = true)
    public void removeAllEffects(CallbackInfoReturnable<Boolean> callback) {
        if (this.method_73183().method_8608() || this.activeEffects.isEmpty()) {
            return;
        }

        Map<class_6880<class_1291>, class_1293> removedActiveEffects = new HashMap<>();
        for (Map.Entry<class_6880<class_1291>, class_1293> entry : this.activeEffects.entrySet()) {
            EventResult eventResult = FabricLivingEvents.MOB_EFFECT_REMOVE.invoker()
                    .onMobEffectRemove(class_1309.class.cast(this), entry.getValue());
            if (eventResult.isPass()) {
                removedActiveEffects.put(entry.getKey(), entry.getValue());
            }
        }

        if (removedActiveEffects.size() != this.activeEffects.size()) {
            removedActiveEffects.keySet().forEach(this.activeEffects::remove);
            this.onEffectsRemoved(removedActiveEffects.values());
            callback.setReturnValue(true);
        }
    }

    @Shadow
    protected abstract void onEffectsRemoved(Collection<class_1293> mobEffects);

    @Shadow
    public abstract class_1268 getUsedItemHand();

    @ModifyExpressionValue(method = "tickEffects",
                           at = @At(value = "INVOKE",
                                    target = "Lnet/minecraft/world/effect/MobEffectInstance;tickServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/entity/LivingEntity;Ljava/lang/Runnable;)Z"))
    protected boolean tickEffects(boolean tickServer, @Local class_1293 mobEffect, @Share("isExpired") LocalBooleanRef isExpired) {
        isExpired.set(false);
        if (tickServer) {
            return true;
        } else if (FabricLivingEvents.MOB_EFFECT_EXPIRE.invoker()
                .onMobEffectExpire(class_1309.class.cast(this), mobEffect)
                .isInterrupt()) {
            // There are multiple things that happen when an effect expires.
            // To bypass all of them, we prevent it from expiring and then cancel everything that would follow normally.
            isExpired.set(true);
            return true;
        } else {
            return false;
        }
    }

    @ModifyExpressionValue(method = "tickEffects",
                           at = @At(value = "INVOKE",
                                    target = "Lnet/minecraft/world/effect/MobEffectInstance;getDuration()I"))
    protected int tickEffects(int duration, @Share("isExpired") LocalBooleanRef isExpired) {
        return isExpired.get() ? -1 : duration;
    }

    @Inject(method = "jumpFromGround", at = @At("TAIL"))
    protected void jumpFromGround(CallbackInfo callback) {
        EventImplHelper.onLivingJump(FabricLivingEvents.LIVING_JUMP.invoker(), class_1309.class.cast(this));
    }

    @ModifyVariable(method = "getVisibilityPercent", at = @At("TAIL"), ordinal = 0)
    public double getVisibilityPercent(double value, @Nullable class_1297 lookingEntity) {
        DefaultedDouble visibilityPercentage = DefaultedDouble.fromValue(value);
        FabricLivingEvents.CALCULATE_LIVING_VISIBILITY.invoker()
                .onCalculateLivingVisibility(class_1309.class.cast(this), lookingEntity, visibilityPercentage);
        return visibilityPercentage.getAsOptionalDouble()
                .stream()
                .map((double visibilityPercentageValue) -> Math.max(visibilityPercentageValue, 0.0))
                .findAny()
                .orElse(value);
    }

    @ModifyReturnValue(method = "getProjectile", at = @At("RETURN"))
    public class_1799 getProjectile(class_1799 projectileItemStack, class_1799 weaponItemStack) {
        if (weaponItemStack.method_7909() instanceof class_1811) {
            DefaultedValue<class_1799> projectileItemStackValue = DefaultedValue.fromValue(projectileItemStack);
            FabricLivingEvents.PICK_PROJECTILE.invoker()
                    .onPickProjectile(class_1309.class.cast(this), weaponItemStack, projectileItemStackValue);
            return projectileItemStackValue.getAsOptional().orElse(projectileItemStack);
        } else {
            return projectileItemStack;
        }
    }
}
