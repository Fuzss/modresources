package fuzs.puzzleslib.api.util.v1;

import fuzs.puzzleslib.impl.PuzzlesLib;
import java.util.function.Consumer;
import net.minecraft.class_11352;
import net.minecraft.class_11362;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2487;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_8942;

/**
 * A helper for working with {@link class_11372} and {@link class_11368}.
 */
public final class ValueSerializationHelper {

    private ValueSerializationHelper() {
        // NO-OP
    }

    /**
     * Writes data using a {@link class_11372} to a {@link class_2487}.
     *
     * @param pathElement         the problem reporter path
     * @param valueOutputConsumer the value output consumer
     * @return the compound tag
     */
    public static class_2487 save(class_8942.class_11336 pathElement, Consumer<class_11372> valueOutputConsumer) {
        return save(pathElement, class_5455.field_40585, valueOutputConsumer);
    }

    /**
     * Writes data using a {@link class_11372} to a {@link class_2487}.
     *
     * @param pathElement         the problem reporter path
     * @param registries          the dynamic registries
     * @param valueOutputConsumer the value output consumer
     * @return the compound tag
     */
    public static class_2487 save(class_8942.class_11336 pathElement, class_7225.class_7874 registries, Consumer<class_11372> valueOutputConsumer) {
        try (class_8942.class_11340 scopedCollector = new class_8942.class_11340(pathElement,
                PuzzlesLib.LOGGER)) {
            class_11362 valueOutput;
            if (registries != class_5455.field_40585) {
                valueOutput = class_11362.method_71459(scopedCollector, registries);
            } else {
                valueOutput = class_11362.method_71458(scopedCollector);
            }
            valueOutputConsumer.accept(valueOutput);
            return valueOutput.method_71475();
        }
    }

    /**
     * Reads data using a {@link class_11368} from a {@link class_2487}.
     *
     * @param pathElement        the problem reporter path
     * @param registries         the dynamic registries
     * @param compoundTag        the compound tag
     * @param valueInputConsumer the value input consumer
     */
    public static void load(class_8942.class_11336 pathElement, class_7225.class_7874 registries, class_2487 compoundTag, Consumer<class_11368> valueInputConsumer) {
        try (class_8942.class_11340 scopedCollector = new class_8942.class_11340(pathElement,
                PuzzlesLib.LOGGER)) {
            class_11368 valueInput = class_11352.method_71417(scopedCollector, registries, compoundTag);
            valueInputConsumer.accept(valueInput);
        }
    }
}
