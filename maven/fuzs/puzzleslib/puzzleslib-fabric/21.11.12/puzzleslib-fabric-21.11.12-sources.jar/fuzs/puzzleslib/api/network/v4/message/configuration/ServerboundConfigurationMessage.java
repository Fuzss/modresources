package fuzs.puzzleslib.api.network.v4.message.configuration;

import fuzs.puzzleslib.api.network.v4.NetworkingHelper;
import fuzs.puzzleslib.api.network.v4.message.Message;
import net.minecraft.class_2596;
import net.minecraft.class_8610;
import net.minecraft.class_8706;
import net.minecraft.server.MinecraftServer;

/**
 * Template for a message sent by the client and received by the server during the configuration phase.
 */
public interface ServerboundConfigurationMessage extends Message<ServerboundConfigurationMessage.Context> {

    @Override
    default class_2596<class_8706> toPacket() {
        return NetworkingHelper.toServerboundPacket(this);
    }

    /**
     * The context provided in {@link #getListener()}.
     */
    interface Context extends Message.Context<class_8610> {

        /**
         * @return the server
         */
        MinecraftServer server();
    }
}
