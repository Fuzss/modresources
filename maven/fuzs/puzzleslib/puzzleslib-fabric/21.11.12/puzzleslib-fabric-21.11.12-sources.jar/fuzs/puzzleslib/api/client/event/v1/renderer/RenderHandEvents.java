package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;

public final class RenderHandEvents {
    public static final EventInvoker<MainHand> MAIN_HAND = EventInvoker.lookup(MainHand.class);
    public static final EventInvoker<OffHand> OFF_HAND = EventInvoker.lookup(OffHand.class);
    public static final EventInvoker<MainHand> BOTH = (EventPhase phase, MainHand callback) -> {
        MAIN_HAND.register(phase, callback);
        OFF_HAND.register(phase, callback::onRenderMainHand);
    };

    private RenderHandEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface MainHand {

        /**
         * Called before the player's {@link net.minecraft.class_1268#field_5808} is rendered in first-person
         * mode.
         * <p>
         * Allows for cancelling rendering of the hand.
         *
         * @param itemInHandRenderer the item in hand renderer instance
         * @param interactionHand    the player hand
         * @param player             the local player instance used for first-person rendering
         * @param humanoidArm        the screen side the arm is rendering at
         * @param itemStack          the {@link class_1799} held in the hand
         * @param poseStack          the current {@link class_4587}
         * @param nodeCollector      the current {@link class_11659}
         * @param combinedLight      packet light the hand is rendered with
         * @param partialTick        current partial tick time
         * @param interpolatedPitch  the pitch interpolated for current tick delta from {@link class_1657#method_36455()}
         * @param swingProgress      the forward swing state of the hand from attacking / mining, originally retrieved
         *                           from {@link class_1657#method_6055(float)}
         * @param equipProgress      the height the hand is rendered at, changes when switching between hotbar items and
         *                           after triggering the attack cool-down, originally retrieved from
         *                           {@link class_1657#method_7261(float)}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the hand from rendering</li>
         *         <li>{@link EventResult#PASS PASS} to allow the hand to render normally</li>
         *         </ul>
         */
        EventResult onRenderMainHand(class_759 itemInHandRenderer, class_1268 interactionHand, class_742 player, class_1306 humanoidArm, class_1799 itemStack, class_4587 poseStack, class_11659 nodeCollector, int combinedLight, float partialTick, float interpolatedPitch, float swingProgress, float equipProgress);
    }

    @FunctionalInterface
    public interface OffHand {

        /**
         * Called before the player's {@link net.minecraft.class_1268#field_5810} is rendered in first-person
         * mode.
         * <p>
         * Allows for cancelling rendering of the hand.
         *
         * @param itemInHandRenderer the item in hand renderer instance
         * @param interactionHand    the player hand
         * @param player             the local player instance used for first-person rendering
         * @param humanoidArm        the screen side the arm is rendering at
         * @param itemStack          the {@link class_1799} held in the hand
         * @param poseStack          the current {@link class_4587}
         * @param nodeCollector      the current {@link class_11659}
         * @param combinedLight      packet light the hand is rendered with
         * @param partialTick        current partial tick time
         * @param interpolatedPitch  the pitch interpolated for current tick delta from {@link class_1657#method_36455()}
         * @param swingProgress      the forward swing state of the hand from attacking / mining, originally retrieved
         *                           from {@link class_1657#method_6055(float)}
         * @param equipProgress      the height the hand is rendered at, changes when switching between hotbar items and
         *                           after triggering the attack cool-down, originally retrieved from
         *                           {@link class_1657#method_7261(float)}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the hand from rendering</li>
         *         <li>{@link EventResult#PASS PASS} to allow the hand to render normally</li>
         *         </ul>
         */
        EventResult onRenderOffHand(class_759 itemInHandRenderer, class_1268 interactionHand, class_742 player, class_1306 humanoidArm, class_1799 itemStack, class_4587 poseStack, class_11659 nodeCollector, int combinedLight, float partialTick, float interpolatedPitch, float swingProgress, float equipProgress);
    }
}
