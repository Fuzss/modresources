package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingAttackCallback {
    EventInvoker<LivingAttackCallback> EVENT = EventInvoker.lookup(LivingAttackCallback.class);

    /**
     * Fires when a {@link class_1309} is attacked, allows for cancelling that attack.
     *
     * @param livingEntity the entity that is attacked
     * @param damageSource the {@link class_1282} the entity has been attacked by
     * @param damageAmount the amount of damage the entity is attacked with
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the attack from happening, dealing no damage</li>
     *         <li>{@link EventResult#PASS PASS} to allow the entity to be attacked and to take damage</li>
     *         </ul>
     */
    EventResult onLivingAttack(class_1309 livingEntity, class_1282 damageSource, float damageAmount);
}
