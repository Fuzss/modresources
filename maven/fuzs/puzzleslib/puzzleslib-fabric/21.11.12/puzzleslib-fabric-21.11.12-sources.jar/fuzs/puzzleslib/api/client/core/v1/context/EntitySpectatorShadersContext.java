package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_2960;

/**
 * Register a custom shader applied when spectating an entity type.
 */
public interface EntitySpectatorShadersContext {

    /**
     * Register the custom shader.
     *
     * @param entityType       the entity type being spectated
     * @param identifier the location to the shader file, usually at {@code shaders/post/<file>.json}
     */
    void registerSpectatorShader(class_1299<?> entityType, class_2960 identifier);
}
