package fuzs.puzzleslib.api.data.v2.core;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_7225;
import net.minecraft.class_7877;

/**
 * An extension for {@link net.minecraft.class_5475} for obtaining the updated
 * {@link class_7225.class_7874} future.
 */
public interface RegistriesDataProvider {

    /**
     * @return the updated {@link class_7225.class_7874} future obtained from
     *         {@link class_7877.class_8993#comp_2113()}
     */
    CompletableFuture<class_7225.class_7874> getRegistries();
}
