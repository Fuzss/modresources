package fuzs.puzzleslib.fabric.impl.client.config;

import com.electronwill.nightconfig.core.UnmodifiableConfig;
import com.google.common.collect.ImmutableSet;
import fuzs.puzzleslib.api.core.v1.ModContainer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_410;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4667;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7842;
import net.minecraft.class_7919;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.config.ModConfigs;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.logging.log4j.util.Strings;
import org.jspecify.annotations.Nullable;

import java.util.*;

/**
 * An extension of {@link ConfigurationScreen} that replaces translated components with literals.
 * <p>
 * It also allows for displaying configs from multiple mods in a single selection menu.
 * <p>
 * This class is synced between Fabric &amp; NeoForge, as there is no shared config library in Common to build against.
 */
public class CustomConfigurationScreen extends class_4667 {
    /**
     * Show server configs last; all else are global configs that are merged under the same section header.
     */
    private static final List<ModConfig.Type> CONFIG_TYPE_DISPLAY_ORDER = List.of(ModConfig.Type.STARTUP,
            ModConfig.Type.COMMON,
            ModConfig.Type.CLIENT,
            ModConfig.Type.SERVER);
    private static final class_2561 EDIT_COMPONENT = class_2561.method_43470("Edit").method_10852(class_5244.field_39678);
    /**
     * @see ConfigurationScreen#LANG_PREFIX
     */
    private static final String LANG_PREFIX = "neoforge.configuration.uitext.";
    /**
     * @see ConfigurationScreen#CRUMB
     */
    private static final String CRUMB = LANG_PREFIX + "breadcrumb.order";

    protected final Set<String> modIds;

    public CustomConfigurationScreen(String modId, class_437 lastScreen) {
        this(Collections.singleton(modId), lastScreen, getConfigTitleComponent(modId));
    }

    public CustomConfigurationScreen(String modId, class_437 lastScreen, String... modIds) {
        this(ImmutableSet.<String>builder().add(modId).add(modIds).build(), lastScreen, getConfigTitleComponent(modId));
    }

    public CustomConfigurationScreen(Set<String> modIds, class_437 lastScreen, class_2561 title) {
        super(lastScreen, class_310.method_1551().field_1690, title);
        this.modIds = modIds;
    }

    @Override
    protected void method_60325() {
        boolean hasSectionHeader = false;
        List<ModConfig> modConfigs = new ArrayList<>();
        for (ModConfig.Type type : CONFIG_TYPE_DISPLAY_ORDER) {
            // We combine all global config types under the same header, while only server configs get their own.
            if (type == ModConfig.Type.SERVER) {
                hasSectionHeader = false;
            }

            for (ModConfig modConfig : ModConfigs.getConfigSet(type)) {
                if (this.modIds.contains(modConfig.getModId())) {
                    if (!hasSectionHeader) {
                        // This tricks the string widget into centering the text, while also allowing it to scroll instead of overflowing.
                        this.field_51824.method_20407(new class_7842(ConfigurationScreen.BIG_BUTTON_WIDTH,
                                class_4185.field_39501,
                                getConfigSectionComponent(type),
                                this.field_22793) {
                            @Override
                            public int method_25368() {
                                return this.field_22758;
                            }
                        }.method_73395(1, class_7842.class_11764.field_62127), null);
                        hasSectionHeader = true;
                    }

                    class_4185 button = class_4185.method_46430(class_2561.method_43470(modConfig.getFileName()), (class_4185 buttonX) -> {
                        this.openModConfigScreen(modConfig, this);
                    }).method_46432(ConfigurationScreen.BIG_BUTTON_WIDTH).method_46431();
                    class_2561 tooltip = this.getTooltipComponent(type, modConfig);
                    if (tooltip != null) {
                        button.method_47400(class_7919.method_47407(tooltip));
                        button.field_22763 = false;
                    }

                    this.field_51824.method_20407(button, null);
                    modConfigs.add(modConfig);
                }
            }
        }

        // When there is only one config, go to that config screen directly.
        if (modConfigs.size() == 1) {
            this.openModConfigScreen(modConfigs.getFirst(), this.field_21335);
        }
    }

    protected void openModConfigScreen(ModConfig modConfig, class_437 lastScreen) {
        class_2561 component = getConfigTitleComponent(modConfig.getModId());
        this.field_22787.method_1507(new CustomConfigurationSectionScreen(lastScreen,
                modConfig.getType(),
                modConfig,
                component));
    }

    /**
     * @see ConfigurationScreen#method_60325()
     */
    protected class_2561 getTooltipComponent(ModConfig.Type type, ModConfig modConfig) {
        if (!((ModConfigSpec) modConfig.getSpec()).isLoaded()) {
            return ConfigurationScreen.TOOLTIP_CANNOT_EDIT_NOT_LOADED;
        } else if (type == ModConfig.Type.SERVER && this.field_22787.method_1558() != null
                && !this.field_22787.method_47392()) {
            return ConfigurationScreen.TOOLTIP_CANNOT_EDIT_THIS_WHILE_ONLINE;
        } else if (type == ModConfig.Type.SERVER && this.field_22787.method_1496()
                && this.field_22787.method_1576().method_3860()) {
            return ConfigurationScreen.TOOLTIP_CANNOT_EDIT_THIS_WHILE_OPEN_TO_LAN;
        } else {
            return null;
        }
    }

    /**
     * The title component shown on top of the config selection screen.
     *
     * @param modId the mod id
     * @return the title component
     */
    private static class_2561 getConfigTitleComponent(String modId) {
        return class_2561.method_43470(ModContainer.getDisplayName(modId) + " Settings");
    }

    /**
     * Creates a section component for grouping configs based on their type.
     *
     * @param type the config type
     * @return the config type section component
     */
    private static class_2561 getConfigSectionComponent(ModConfig.Type type) {
        String message;
        if (type != ModConfig.Type.SERVER) {
            message = "Global Configurations";
        } else {
            message = "World Configurations";
        }

        return class_2561.method_43470(message).method_27695(class_124.field_1067, class_124.field_1054);
    }

    /**
     * Turns a config value key usually in lowercase underscore format into human-readable text.
     *
     * @param valueKey the value name in the config
     * @return the text component
     */
    private static class_5250 getConfigValueComponent(String valueKey) {
        String string = ModContainer.getCapitalizedString(valueKey).replace(" And ", " & ").replace(" Or ", " / ");
        return class_2561.method_43470(string);
    }

    /**
     * Applies pretty text component formatting including splitting and coloring to a config value description string.
     *
     * @param valueKeyComponent the value key component from {@link #getConfigValueComponent(String)}
     * @param rawComment        the raw comment string
     * @return the tooltip component
     */
    private static class_2561 getConfigValueTooltipComponent(class_2561 valueKeyComponent, String rawComment) {
        if (!Strings.isBlank(rawComment)) {
            class_2561 component = getStylizedStrings(rawComment.split("\\R"));
            if (component != null) {
                return class_2561.method_43473()
                        .method_10852(valueKeyComponent)
                        .method_10852(class_5244.field_33849)
                        .method_10852(class_5244.field_33849)
                        .method_10852(component);
            }
        }

        return class_5244.field_39003;
    }

    /**
     * Combines multiple strings into a multi-line component with altering text colors.
     *
     * @param strings the strings to combine
     * @return the colored component
     */
    private static @Nullable class_2561 getStylizedStrings(String... strings) {
        class_5250 mutableComponent = null;
        for (int i = 0, j = 0; i < strings.length; i++) {
            // The default value is otherwise displayed twice.
            if (!strings[i].matches("^ Default: .*")) {
                String string = strings[i].replaceAll("^ Range: ", "Value Range: ");
                class_124 chatFormatting = j++ % 2 == 0 ? class_124.field_1054 : class_124.field_1065;
                class_5250 component = class_2561.method_43470(string).method_27692(chatFormatting);
                if (mutableComponent != null) {
                    mutableComponent.method_10852(class_5244.field_33849).method_10852(component);
                } else {
                    mutableComponent = component;
                }
            }
        }

        return mutableComponent;
    }

    public static class CustomConfigurationSectionScreen extends ConfigurationScreen.ConfigurationSectionScreen {

        public CustomConfigurationSectionScreen(class_437 parent, ModConfig.Type type, ModConfig modConfig, class_2561 title) {
            super(parent, type, modConfig, title);
            // This is set to GAME for startup configs, which is wrong, as they reload just fine.
            this.needsRestart = ModConfigSpec.RestartType.NONE;
        }

        public CustomConfigurationSectionScreen(final Context parentContext, final class_437 parent, final Map<String, Object> valueSpecs, final String key, final Set<? extends UnmodifiableConfig.Entry> entrySet, class_2561 title) {
            super(parentContext, parent, valueSpecs, key, entrySet, title);
            // This is set to GAME for startup configs, which is wrong, as they reload just fine.
            this.needsRestart = ModConfigSpec.RestartType.NONE;
        }

        @Override
        protected class_5250 getTranslationComponent(String key) {
            // Replace the usage of translatable components with component literals directly computed from the value key.
            return getConfigValueComponent(key);
        }

        @Override
        protected class_2561 getTooltipComponent(final String key, ModConfigSpec.@Nullable Range<?> range) {
            // Replace the usage of translatable components with component literals and apply pretty formatting.
            return getConfigValueTooltipComponent(this.getTranslationComponent(key), this.getComment(key));
        }

        @Override
        public ConfigurationScreen.ConfigurationSectionScreen rebuild() {
            return super.rebuild();
        }

        @Override
        public void method_25419() {
            // Move the warning message regarding the restart type for changed settings to the individual config screen
            // instead of having it on the main config selection screen.
            // This makes it much easier to implement, especially as we remove the relog / restart options which are not necessary.
            super.method_25419();
            if (this.changed && !(this.field_21335 instanceof ConfigurationScreen.ConfigurationSectionScreen)) {
                switch (this.needsRestart) {
                    case GAME -> {
                        this.openConfirmScreen(ConfigurationScreen.GAME_RESTART_TITLE,
                                ConfigurationScreen.GAME_RESTART_MESSAGE);
                    }
                    case WORLD -> {
                        if (this.field_22787.field_1687 != null) {
                            this.openConfirmScreen(ConfigurationScreen.SERVER_RESTART_TITLE,
                                    ConfigurationScreen.SERVER_RESTART_MESSAGE);
                        }
                    }
                }
            }
        }

        private void openConfirmScreen(class_2561 title, class_2561 message) {
            this.field_22787.method_1507(new class_410((boolean hasConfirmed) -> {
                if (hasConfirmed) {
                    super.method_25419();
                } else {
                    this.field_22787.method_1507(this);
                }
            }, title, message, class_5244.field_41873, class_5244.field_24339));
        }

        @Nullable
        protected Element createSection(final String key, final UnmodifiableConfig subconfig, final UnmodifiableConfig subsection) {
            // Make sure our own screen is used for submenus, while also replacing translated components with literals.
            if (subconfig.isEmpty()) {
                return null;
            } else {
                return new Element(this.getTranslationComponent(key).method_10852(class_5244.field_39678),
                        this.getTooltipComponent(key, null),
                        class_4185.method_46430(EDIT_COMPONENT,
                                        (class_4185 button) -> this.field_22787.method_1507(new CustomConfigurationSectionScreen(this.context,
                                                this,
                                                subconfig.valueMap(),
                                                key,
                                                subsection.entrySet(),
                                                this.getTranslationComponent(key)).rebuild()))
                                .method_46436(class_7919.method_47407(this.getTooltipComponent(key, null)))
                                .method_46431(),
                        false);
            }
        }

        @Nullable
        protected <T> Element createList(final String key, final ModConfigSpec.ListValueSpec spec, final ModConfigSpec.ConfigValue<List<T>> list) {
            // Make sure our own screen is used for submenus, while also replacing translated components with literals.
            return new Element(this.getTranslationComponent(key).method_10852(class_5244.field_39678),
                    this.getTooltipComponent(key, null),
                    class_4185.method_46430(EDIT_COMPONENT,
                                    button -> this.field_22787.method_1507(new CustomConfigurationListScreen<>(Context.list(this.context,
                                            this),
                                            key,
                                            class_2561.method_43469(CRUMB,
                                                    this.method_25440(),
                                                    ConfigurationScreen.CRUMB_SEPARATOR,
                                                    this.getTranslationComponent(key)),
                                            spec,
                                            list).rebuild()))
                            .method_46436(class_7919.method_47407(this.getTooltipComponent(key, null)))
                            .method_46431(),
                    false);
        }
    }

    public static class CustomConfigurationListScreen<T> extends ConfigurationScreen.ConfigurationListScreen<T> {

        public CustomConfigurationListScreen(Context context, String key, class_2561 title, ModConfigSpec.ListValueSpec spec, ModConfigSpec.ConfigValue<List<T>> valueList) {
            super(context, key, title, spec, valueList);
            // This is set to GAME for startup configs, which is wrong, as they reload just fine.
            this.needsRestart = ModConfigSpec.RestartType.NONE;
        }

        @Override
        protected class_5250 getTranslationComponent(String key) {
            // Replace the usage of translatable components with component literals directly computed from the value key.
            return getConfigValueComponent(key);
        }

        @Override
        protected class_2561 getTooltipComponent(final String key, ModConfigSpec.@Nullable Range<?> range) {
            // Replace the usage of translatable components with component literals and apply pretty formatting.
            return getConfigValueTooltipComponent(this.getTranslationComponent(key), this.getComment(key));
        }

        @Override
        public ConfigurationScreen.ConfigurationSectionScreen rebuild() {
            return super.rebuild();
        }

        @Override
        protected @Nullable Element createOtherValue(int idx, T entry) {
            // Remove the tooltip for list entries.
            Element element = super.createOtherValue(idx, entry);
            if (element != null && element.widget() != null) {
                element.widget().method_47400(null);
            }

            return element;
        }

        @Override
        protected @Nullable Element createStringListValue(int idx, String value) {
            // Remove the tooltip for list entries.
            Element element = super.createStringListValue(idx, value);
            if (element != null && element.widget() != null) {
                element.widget().method_47400(null);
            }

            return element;
        }

        @Override
        protected @Nullable Element createDoubleListValue(int idx, Double value) {
            // Remove the tooltip for list entries.
            Element element = super.createDoubleListValue(idx, value);
            if (element != null && element.widget() != null) {
                element.widget().method_47400(null);
            }

            return element;
        }

        @Override
        protected @Nullable Element createLongListValue(int idx, Long value) {
            // Remove the tooltip for list entries.
            Element element = super.createLongListValue(idx, value);
            if (element != null && element.widget() != null) {
                element.widget().method_47400(null);
            }

            return element;
        }

        @Override
        protected @Nullable Element createIntegerListValue(int idx, Integer value) {
            // Remove the tooltip for list entries.
            Element element = super.createIntegerListValue(idx, value);
            if (element != null && element.widget() != null) {
                element.widget().method_47400(null);
            }

            return element;
        }

        @Override
        protected @Nullable Element createBooleanListValue(int idx, Boolean value) {
            // Remove the tooltip for list entries.
            Element element = super.createBooleanListValue(idx, value);
            if (element != null && element.widget() != null) {
                element.widget().method_47400(null);
            }

            return element;
        }
    }
}
