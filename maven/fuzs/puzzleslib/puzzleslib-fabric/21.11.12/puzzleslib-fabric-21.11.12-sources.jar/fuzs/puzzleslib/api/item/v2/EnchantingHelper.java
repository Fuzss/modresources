package fuzs.puzzleslib.api.item.v2;

import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.apache.commons.lang3.mutable.MutableFloat;

import java.util.List;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_9331;
import net.minecraft.class_9698;
import net.minecraft.class_9699;
import net.minecraft.class_9723;

/**
 * A helper class containing enchanting related methods.
 */
public final class EnchantingHelper {

    private EnchantingHelper() {
        // NO-OP
    }

    /**
     * Returns the enchanting power provided by a block. An enchanting power of 15 is required for level 30 enchants,
     * each bookshelf block provides exactly one enchanting power.
     *
     * @param blockState the block state at the given position
     * @param level      the level
     * @param blockPos   the block position in the level
     * @return the enchanting power, usually zero for blocks other than bookshelves
     */
    public static float getEnchantPowerBonus(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return ProxyImpl.get().getEnchantPowerBonus(blockState, level, blockPos);
    }

    /**
     * Check if the given enchanted be applied to an item stack via enchanting (in an enchanting table).
     *
     * @param enchantment the enchantment to check
     * @param itemStack   the item stack receiving the enchantment
     * @return is the application allowed
     */
    public static boolean canApplyAtEnchantingTable(class_6880<class_1887> enchantment, class_1799 itemStack) {
        return ProxyImpl.get().canApplyAtEnchantingTable(enchantment, itemStack);
    }

    /**
     * Looks up an enchantment holder in the provided registry access.
     *
     * @param entity      the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    public static class_6880<class_1887> lookup(class_1297 entity, class_5321<class_1887> resourceKey) {
        return LookupHelper.lookup(entity, class_7924.field_41265, resourceKey);
    }

    /**
     * Looks up an enchantment holder in the provided registry access.
     *
     * @param levelReader the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    public static class_6880<class_1887> lookup(class_4538 levelReader, class_5321<class_1887> resourceKey) {
        return LookupHelper.lookup(levelReader, class_7924.field_41265, resourceKey);
    }

    /**
     * Looks up an enchantment holder in the provided registry access.
     *
     * @param registries  the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    public static class_6880<class_1887> lookup(class_7225.class_7874 registries, class_5321<class_1887> resourceKey) {
        return LookupHelper.lookup(registries, class_7924.field_41265, resourceKey);
    }

    /**
     * @see class_1890#method_8225(class_6880, class_1799)
     */
    public static int getItemEnchantmentLevel(class_7225.class_7874 registries, class_5321<class_1887> enchantment, class_1799 itemStack) {
        class_6880<class_1887> holder = lookup(registries, enchantment);
        return class_1890.method_8225(holder, itemStack);
    }

    /**
     * @see class_1890#method_8203(class_6880, class_1309)
     */
    public static int getEnchantmentLevel(class_5321<class_1887> enchantment, class_1309 livingEntity) {
        class_6880<class_1887> holder = lookup(livingEntity, enchantment);
        return class_1890.method_8203(holder, livingEntity);
    }

    /**
     * @see class_1890#method_60142(class_1799, class_9331)
     */
    public static boolean has(class_1309 livingEntity, class_9331<?> componentType) {
        MutableBoolean mutableBoolean = new MutableBoolean(false);
        class_1890.method_8209(livingEntity,
                (class_6880<class_1887> holder, int enchantmentLevel, class_9699 enchantedItemInUse) -> {
                    if (holder.comp_349().comp_2689().method_57832(componentType)) {
                        mutableBoolean.setTrue();
                    }
                });
        return mutableBoolean.booleanValue();
    }

    /**
     * @param itemStack     the item stack used as the enchantment holder
     * @param entity        the entity used as the enchantment holder
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8220(class_1799, class_1890.class_1891)
     * @see class_1887#method_60506(class_9331, class_5819, int, MutableFloat)
     */
    public static float getUnfilteredValueEffectBonus(class_1799 itemStack, class_1297 entity, class_9331<class_9723> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8220(itemStack, (class_6880<class_1887> holder, int enchantmentLevel) -> {
            holder.comp_349().method_60506(componentType, entity.method_59922(), enchantmentLevel, mutableFloat);
        });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param livingEntity  the entity used as the enchantment holder
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8209(class_1309, class_1890.class_9702)
     * @see class_1887#method_60506(class_9331, class_5819, int, MutableFloat)
     */
    public static float getUnfilteredValueEffectBonus(class_1309 livingEntity, class_9331<class_9723> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8209(livingEntity,
                (class_6880<class_1887> holder, int enchantmentLevel, class_9699 enchantedItemInUse) -> {
                    class_1887 enchantment = holder.comp_349();
                    enchantment.method_60506(componentType,
                            livingEntity.method_59922(),
                            enchantmentLevel,
                            mutableFloat);
                });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param serverLevel   the server level for creating the loot context
     * @param itemStack     the item stack used as the enchantment holder
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8220(class_1799, class_1890.class_1891)
     * @see class_1887#method_60037(class_9331, class_3218, int, class_1799, MutableFloat)
     */
    public static float getItemFilteredValueEffectBonus(class_3218 serverLevel, class_1799 itemStack, class_9331<List<class_9698<class_9723>>> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8220(itemStack, (class_6880<class_1887> holder, int enchantmentLevel) -> {
            holder.comp_349()
                    .method_60037(componentType, serverLevel, enchantmentLevel, itemStack, mutableFloat);
        });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param serverLevel   the server level for creating the loot context
     * @param livingEntity  the entity used as the enchantment holder
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8209(class_1309, class_1890.class_9702)
     * @see class_1887#method_60037(class_9331, class_3218, int, class_1799, MutableFloat)
     */
    public static float getItemFilteredValueEffectBonus(class_3218 serverLevel, class_1309 livingEntity, class_9331<List<class_9698<class_9723>>> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8209(livingEntity,
                (class_6880<class_1887> holder, int enchantmentLevel, class_9699 enchantedItemInUse) -> {
                    holder.comp_349()
                            .method_60037(componentType,
                                    serverLevel,
                                    enchantmentLevel,
                                    enchantedItemInUse.comp_2682(),
                                    mutableFloat);
                });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param serverLevel   the server level for creating the loot context
     * @param itemStack     the item stack used as the enchantment holder
     * @param entity        the entity used as the enchantment holder
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8220(class_1799, class_1890.class_1891)
     * @see class_1887#method_60036(class_9331, class_3218, int, class_1799, class_1297,
     *         MutableFloat)
     */
    public static float getEntityFilteredValueEffectBonus(class_3218 serverLevel, class_1799 itemStack, class_1297 entity, class_9331<List<class_9698<class_9723>>> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8220(itemStack, (class_6880<class_1887> holder, int enchantmentLevel) -> {
            holder.comp_349()
                    .method_60036(componentType,
                            serverLevel,
                            enchantmentLevel,
                            itemStack,
                            entity,
                            mutableFloat);
        });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param serverLevel   the server level for creating the loot context
     * @param livingEntity  the entity used as the enchantment holder
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8209(class_1309, class_1890.class_9702)
     * @see class_1887#method_60036(class_9331, class_3218, int, class_1799, class_1297,
     *         MutableFloat)
     */
    public static float getEntityFilteredValueEffectBonus(class_3218 serverLevel, class_1309 livingEntity, class_9331<List<class_9698<class_9723>>> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8209(livingEntity,
                (class_6880<class_1887> holder, int enchantmentLevel, class_9699 enchantedItemInUse) -> {
                    holder.comp_349()
                            .method_60036(componentType,
                                    serverLevel,
                                    enchantmentLevel,
                                    enchantedItemInUse.comp_2682(),
                                    livingEntity,
                                    mutableFloat);
                });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param serverLevel   the server level for creating the loot context
     * @param itemStack     the item stack used as the enchantment holder
     * @param entity        the entity used as the enchantment holder
     * @param damageSource  the damage source
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8220(class_1799, class_1890.class_1891)
     * @see class_1887#method_60035(class_9331, class_3218, int, class_1799, class_1297,
     *         class_1282, MutableFloat)
     */
    public static float getDamageFilteredValueEffectBonus(class_3218 serverLevel, class_1799 itemStack, class_1297 entity, class_1282 damageSource, class_9331<List<class_9698<class_9723>>> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8220(itemStack, (class_6880<class_1887> holder, int enchantmentLevel) -> {
            holder.comp_349()
                    .method_60035(componentType,
                            serverLevel,
                            enchantmentLevel,
                            itemStack,
                            entity,
                            damageSource,
                            mutableFloat);
        });
        return Math.max(0.0F, mutableFloat.floatValue());
    }

    /**
     * @param serverLevel   the server level for creating the loot context
     * @param livingEntity  the entity used as the enchantment holder
     * @param damageSource  the damage source
     * @param componentType the enchantment effect component type
     * @return the enchantment value effect bonus
     *
     * @see class_1890#method_8209(class_1309, class_1890.class_9702)
     * @see class_1887#method_60035(class_9331, class_3218, int, class_1799, class_1297,
     *         class_1282, MutableFloat)
     */
    public static float getDamageFilteredValueEffectBonus(class_3218 serverLevel, class_1309 livingEntity, class_1282 damageSource, class_9331<List<class_9698<class_9723>>> componentType) {
        MutableFloat mutableFloat = new MutableFloat(0.0F);
        class_1890.method_8209(livingEntity,
                (class_6880<class_1887> holder, int enchantmentLevel, class_9699 enchantedItemInUse) -> {
                    holder.comp_349()
                            .method_60035(componentType,
                                    serverLevel,
                                    enchantmentLevel,
                                    enchantedItemInUse.comp_2682(),
                                    livingEntity,
                                    damageSource,
                                    mutableFloat);
                });
        return Math.max(0.0F, mutableFloat.floatValue());
    }
}
