package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import fuzs.puzzleslib.fabric.impl.core.context.DataPackSourcesContextFabricImpl;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

public final class ResourcePackSourcesContextFabricImpl implements PackRepositorySourcesContext {

    @Override
    public void registerRepositorySource(class_3285 repositorySource) {
        Objects.requireNonNull(repositorySource, "repository source is null");
        class_3283 packRepository = class_310.method_1551().method_1520();
        DataPackSourcesContextFabricImpl.getRepositorySources(packRepository).add(repositorySource);
    }

    @Override
    public void registerBuiltInPack(class_2960 identifier, class_2561 displayName, boolean shouldAddAutomatically) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(displayName, "display name is null");
        DataPackSourcesContextFabricImpl.registerBuiltInPack(identifier,
                displayName, shouldAddAutomatically,
                class_3264.field_14188);
    }
}
