package fuzs.puzzleslib.fabric.impl.biome;

import fuzs.puzzleslib.api.biome.v1.ClimateSettingsContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.class_1959;
import org.jspecify.annotations.NonNull;

public record ClimateSettingsContextFabric(class_1959 biome,
                                           BiomeModificationContext.WeatherContext context) implements ClimateSettingsContext {

    @Override
    public void hasPrecipitation(boolean hasPrecipitation) {
        this.context.setPrecipitation(hasPrecipitation);
    }

    @Override
    public boolean hasPrecipitation() {
        return this.biome.method_48163();
    }

    @Override
    public void setTemperature(float temperature) {
        this.context.setTemperature(temperature);
    }

    @Override
    public float getTemperature() {
        return this.biome.method_8712();
    }

    @Override
    public void setTemperatureModifier(class_1959.@NonNull class_5484 temperatureModifier) {
        this.context.setTemperatureModifier(temperatureModifier);
    }

    @Override
    public void setDownfall(float downfall) {
        this.context.setDownfall(downfall);
    }
}
