package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_437;

/**
 * Register a client-side screen factory to be constructed when opening an {@link class_1703}.
 */
public interface MenuScreensContext {

    /**
     * Register a factory for creating a {@link net.minecraft.class_465} for
     * a corresponding {@link class_3917}.
     *
     * @param menuType              the menu type
     * @param menuScreenConstructor the screen factory
     * @param <M>                   the type of menu
     * @param <S>                   the type of screen
     */
    <M extends class_1703, S extends class_437 & class_3936<M>> void registerMenuScreen(class_3917<? extends M> menuType, class_3929.class_3930<M, S> menuScreenConstructor);
}
