package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_10515;
import net.minecraft.class_2248;

public interface SpecialBlockModelRenderersContext {

    /**
     * Register a custom unbaked special model renderer implementation to be used for statically rendered blocks, such
     * as blocks visually appearing in minecarts and held by enderman.
     *
     * @param block                the block requiring a special model renderer
     * @param specialModelRenderer the unbaked special model renderer implementation
     */
    void registerSpecialBlockModelRenderer(class_2248 block, class_10515.class_10516 specialModelRenderer);
}
