package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_9799;

/**
 * Register a render buffer for a {@link class_1921} that is added in
 * {@link net.minecraft.class_4599#class_4599(int)}.
 */
public interface RenderBuffersContext {

    /**
     * Registers a render buffer for the specified render type.
     *
     * @param renderType the render type of the render buffer
     */
    default void registerRenderBuffer(class_1921 renderType) {
        Objects.requireNonNull(renderType, "render type is null");
        this.registerRenderBuffer(renderType, new class_9799(renderType.method_22722()));
    }

    /**
     * Registers a render buffer for the specified render type.
     *
     * @param renderType   the render type of the render buffer
     * @param renderBuffer the render buffer
     */
    void registerRenderBuffer(class_1921 renderType, class_9799 renderBuffer);
}
