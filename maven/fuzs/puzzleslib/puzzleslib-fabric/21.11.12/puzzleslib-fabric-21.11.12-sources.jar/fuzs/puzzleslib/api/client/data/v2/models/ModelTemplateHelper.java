package fuzs.puzzleslib.api.client.data.v2.models;

import java.util.Optional;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4944;
import net.minecraft.class_4945;

public final class ModelTemplateHelper {

    private ModelTemplateHelper() {
        // NO-OP
    }

    public static class_4942 createBlockModelTemplate(class_2960 identifier, class_4945... requiredSlots) {
        return createBlockModelTemplate(identifier, "", requiredSlots);
    }

    public static class_4942 createBlockModelTemplate(class_2960 identifier, String suffix, class_4945... requiredSlots) {
        return new class_4942(Optional.of(ModelLocationHelper.getBlockModel(identifier)),
                Optional.of(suffix),
                requiredSlots);
    }

    public static class_4942 createItemModelTemplate(class_2960 identifier, class_4945... requiredSlots) {
        return createItemModelTemplate(identifier, "", requiredSlots);
    }

    public static class_4942 createItemModelTemplate(class_2960 identifier, String suffix, class_4945... requiredSlots) {
        return new class_4942(Optional.of(ModelLocationHelper.getItemModel(identifier)),
                Optional.of(suffix),
                requiredSlots);
    }

    public static class_4944 createParticleTextureMapping(class_2248 block) {
        return createParticleTextureMapping(block, "");
    }

    public static class_4944 createParticleTextureMapping(class_2248 block, String suffix) {
        class_2960 identifier = class_4944.method_25866(block, suffix);
        return new class_4944().method_25868(class_4945.field_23011, identifier)
                .method_25868(class_4945.field_23012, identifier);
    }

    public static class_4944 createSingleSlotMapping(class_4945 textureSlot, class_2248 block) {
        return class_4944.method_25883(textureSlot, class_4944.method_25860(block));
    }
}
