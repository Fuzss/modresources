package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import net.minecraft.class_1752;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1752.class)
abstract class BoneMealItemFabricMixin extends class_1792 {

    public BoneMealItemFabricMixin(class_1793 properties) {
        super(properties);
    }

    @Inject(method = "growCrop", at = @At("HEAD"), cancellable = true)
    private static void growCrop(class_1799 itemStack, class_1937 level, class_2338 blockPos, CallbackInfoReturnable<Boolean> callbackInfo) {
        EventResult result = FabricLevelEvents.USE_BONE_MEAL.invoker()
                .onUseBoneMeal(level, blockPos, level.method_8320(blockPos), itemStack);
        if (result.isInterrupt()) {
            callbackInfo.setReturnValue(result.getAsBoolean());
        }
    }
}
