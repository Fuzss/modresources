package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_2248;
import net.minecraft.class_322;
import org.jspecify.annotations.Nullable;

/**
 * Register block color providers, like tint getters for leaves or grass.
 */
public interface BlockColorsContext {

    /**
     * Register a new block color provider.
     *
     * @param block      the block
     * @param blockColor the {@link class_322}
     */
    void registerBlockColor(class_2248 block, class_322 blockColor);

    /**
     * Provides access to already registered block color providers.
     * <p>
     * Might be incomplete during registration, but is good to use as long as it doesn't try to retrieve itself.
     *
     * @return the registered {@link class_322}
     */
    @Nullable class_322 getBlockColor(class_2248 block);
}
