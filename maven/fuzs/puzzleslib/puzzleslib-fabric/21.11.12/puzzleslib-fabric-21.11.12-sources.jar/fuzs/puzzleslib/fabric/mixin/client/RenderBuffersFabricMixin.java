package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.fabric.impl.client.core.context.RenderBuffersContextFabricImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.SequencedMap;
import net.minecraft.class_1921;
import net.minecraft.class_4599;
import net.minecraft.class_9799;

@Mixin(class_4599.class)
abstract class RenderBuffersFabricMixin {

    @ModifyVariable(method = "<init>", at = @At(value = "STORE", ordinal = 0))
    public SequencedMap<class_1921, class_9799> init(SequencedMap<class_1921, class_9799> sequencedMap) {
        RenderBuffersContextFabricImpl.addAll(sequencedMap);
        return sequencedMap;
    }
}
