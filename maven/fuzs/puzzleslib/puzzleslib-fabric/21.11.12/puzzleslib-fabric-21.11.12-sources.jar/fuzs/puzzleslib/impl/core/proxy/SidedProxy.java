package fuzs.puzzleslib.impl.core.proxy;

import fuzs.puzzleslib.api.util.v1.CommonHelper;
import net.minecraft.class_1255;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.class_5455;

public interface SidedProxy {

    void registerAllLoadingHandlers();

    void registerAllEventHandlers();

    default class_1255<? super class_3738> getBlockableEventLoop(class_1937 level) {
        if (level instanceof class_3218 serverLevel) {
            return serverLevel.method_8503();
        } else {
            throw new RuntimeException("Blockable event loop accessed for the wrong physical side!");
        }
    }

    default class_5455 getRegistryAccess() {
        return CommonHelper.getMinecraftServer() != null ? CommonHelper.getMinecraftServer().method_30611() : null;
    }

    default class_1657 getClientPlayer() {
        throw new RuntimeException("Client player accessed for the wrong physical side!");
    }

    default class_1937 getClientLevel() {
        throw new RuntimeException("Client level accessed for the wrong physical side!");
    }

    default boolean hasControlDown() {
        return false;
    }

    default boolean hasShiftDown() {
        return false;
    }

    default boolean hasAltDown() {
        return false;
    }

    default void registerConfigurationScreen(String modId, String... otherModIds) {
        // NO-OP
    }
}
