package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.LayerDefinitionsContext;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import java.util.Objects;
import java.util.function.Supplier;

public final class LayerDefinitionsContextFabricImpl implements LayerDefinitionsContext {

    @Override
    public void registerLayerDefinition(class_5601 modelLayer, Supplier<class_5607> layerSupplier) {
        Objects.requireNonNull(modelLayer, "layer location is null");
        Objects.requireNonNull(layerSupplier, "layer supplier is null");
        EntityModelLayerRegistry.registerModelLayer(modelLayer, layerSupplier::get);
    }
}
