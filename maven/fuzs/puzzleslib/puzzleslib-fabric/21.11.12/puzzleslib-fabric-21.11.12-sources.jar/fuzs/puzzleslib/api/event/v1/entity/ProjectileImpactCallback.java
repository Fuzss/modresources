package fuzs.puzzleslib.api.event.v1.entity;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1676;
import net.minecraft.class_239;

@FunctionalInterface
public interface ProjectileImpactCallback {
    EventInvoker<ProjectileImpactCallback> EVENT = EventInvoker.lookup(ProjectileImpactCallback.class);

    /**
     * Fires when a projectile entity impacts on something, either a block or another entity.
     *
     * @param projectile the projectile about to impact
     * @param hitResult  {@link class_239} context
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} tp prevent the impact from being processed, meaning {@link class_1676#method_7488(class_239)} does not run, the projectile will just keep flying</li>
     *         <li>{@link EventResult#PASS PASS} to let vanilla behavior process the impact, destroying the projectile as a
     *         result</li>
     *         </ul>
     */
    EventResult onProjectileImpact(class_1676 projectile, class_239 hitResult);
}
