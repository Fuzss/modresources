package fuzs.puzzleslib.api.client.core.v1.context;

import com.google.common.collect.ImmutableMap;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Supplier;
import net.minecraft.class_11677;
import net.minecraft.class_5601;
import net.minecraft.class_5607;

/**
 * Register layer definitions for entity models.
 */
public interface LayerDefinitionsContext {

    /**
     * @param modelLayer    the model layer location
     * @param layerSupplier the layer definition supplier
     */
    void registerLayerDefinition(class_5601 modelLayer, Supplier<class_5607> layerSupplier);

    /**
     * @param modelLayerSet    the model layer location set
     * @param layerSetSupplier the layer definition set supplier
     * @see class_11677#method_72960(class_11677, ImmutableMap.Builder)
     */
    default void registerArmorDefinition(class_11677<class_5601> modelLayerSet, Supplier<class_11677<class_5607>> layerSetSupplier) {
        class_11677<MutableObject<class_5607>> mutableLayerSet = new class_11677<>(new MutableObject<>(),
                new MutableObject<>(),
                new MutableObject<>(),
                new MutableObject<>());
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                class_11677::comp_4542,
                class_11677::comp_4543,
                class_11677::comp_4544,
                class_11677::comp_4545);
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                class_11677::comp_4543,
                class_11677::comp_4542,
                class_11677::comp_4544,
                class_11677::comp_4545);
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                class_11677::comp_4544,
                class_11677::comp_4542,
                class_11677::comp_4543,
                class_11677::comp_4545);
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                class_11677::comp_4545,
                class_11677::comp_4542,
                class_11677::comp_4543,
                class_11677::comp_4544);
    }

    private void registerArmorDefinition(class_11677<class_5601> modelLayerSet, class_11677<MutableObject<class_5607>> mutableLayerSet, Supplier<class_11677<class_5607>> layerSetSupplier, ArmorModelSetGetter primaryGetter, ArmorModelSetGetter secondaryGetter, ArmorModelSetGetter tertiaryGetter, ArmorModelSetGetter quaternaryGetter) {
        this.registerLayerDefinition(primaryGetter.apply(modelLayerSet), () -> {
            return this.storeArmorModelLayers(mutableLayerSet,
                    layerSetSupplier,
                    primaryGetter,
                    secondaryGetter,
                    tertiaryGetter,
                    quaternaryGetter);
        });
    }

    /**
     * This implementation tries to create the armor models just once from the supplier, then stores all remaining three
     * models until they are used.
     * <p>
     * Since {@link class_5607} registration is likely to run sequentially in order this should work to reduce
     * overhead and avoid recreating models unnecessarily.
     */
    private class_5607 storeArmorModelLayers(class_11677<MutableObject<class_5607>> mutableLayerSet, Supplier<class_11677<class_5607>> layerSetSupplier, ArmorModelSetGetter primaryGetter, ArmorModelSetGetter secondaryGetter, ArmorModelSetGetter tertiaryGetter, ArmorModelSetGetter quaternaryGetter) {
        class_5607 layerDefinition = primaryGetter.apply(mutableLayerSet).getValue();
        if (layerDefinition != null) {
            primaryGetter.apply(mutableLayerSet).setValue(null);
            return layerDefinition;
        } else {
            class_11677<class_5607> armorModelSet = layerSetSupplier.get();
            secondaryGetter.apply(mutableLayerSet).setValue(secondaryGetter.apply(armorModelSet));
            tertiaryGetter.apply(mutableLayerSet).setValue(tertiaryGetter.apply(armorModelSet));
            quaternaryGetter.apply(mutableLayerSet).setValue(quaternaryGetter.apply(armorModelSet));
            return primaryGetter.apply(armorModelSet);
        }
    }

    @ApiStatus.Internal
    @FunctionalInterface
    interface ArmorModelSetGetter {
        <T> T apply(class_11677<T> armorModelSet);
    }
}
