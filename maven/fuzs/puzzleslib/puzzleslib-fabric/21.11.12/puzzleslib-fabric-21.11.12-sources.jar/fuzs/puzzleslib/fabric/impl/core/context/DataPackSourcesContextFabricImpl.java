package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import fuzs.puzzleslib.api.resources.v1.PackResourcesHelper;
import net.fabricmc.fabric.api.resource.v1.pack.PackActivationType;
import net.fabricmc.fabric.impl.resource.ResourceLoaderImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3283;
import net.minecraft.class_3285;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

public final class DataPackSourcesContextFabricImpl implements PackRepositorySourcesContext {
    private static final Set<class_3285> REPOSITORY_SOURCES_REGISTRY = new LinkedHashSet<>();

    @Override
    public void registerRepositorySource(class_3285 repositorySource) {
        Objects.requireNonNull(repositorySource, "repository source is null");
        REPOSITORY_SOURCES_REGISTRY.add(repositorySource);
    }

    @Override
    public void registerBuiltInPack(class_2960 identifier, class_2561 displayName, boolean shouldAddAutomatically) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(displayName, "display name is null");
        registerBuiltInPack(identifier, displayName, shouldAddAutomatically, class_3264.field_14190);
    }

    @SuppressWarnings("UnstableApiUsage")
    public static void registerBuiltInPack(class_2960 identifier, class_2561 displayName, boolean shouldAddAutomatically, class_3264 packType) {
        ModContainer modContainer = FabricLoader.getInstance().getModContainer(identifier.method_12836()).orElseThrow();
        ResourceLoaderImpl.registerBuiltinPack(identifier,
                PackResourcesHelper.getBuiltInPack(identifier, packType).method_12832(),
                modContainer,
                displayName,
                shouldAddAutomatically ? PackActivationType.DEFAULT_ENABLED : PackActivationType.NORMAL);
    }

    public static void addAll(class_3283 packRepository) {
        Set<class_3285> repositorySources = getRepositorySources(packRepository);
        repositorySources.addAll(REPOSITORY_SOURCES_REGISTRY);
    }

    public static Set<class_3285> getRepositorySources(class_3283 packRepository) {
        Set<class_3285> repositorySources = packRepository.field_14227;
        // Fabric Api internally replaces the immutable set already and leaves it like that, just verify in case internal implementation changes
        if (!(repositorySources instanceof LinkedHashSet<class_3285>)) {
            return packRepository.field_14227 = new LinkedHashSet<>(repositorySources);
        } else {
            return repositorySources;
        }
    }
}
