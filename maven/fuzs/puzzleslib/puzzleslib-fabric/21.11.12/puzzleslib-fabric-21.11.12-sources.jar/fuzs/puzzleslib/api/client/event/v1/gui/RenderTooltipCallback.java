package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@FunctionalInterface
public interface RenderTooltipCallback {
    EventInvoker<RenderTooltipCallback> EVENT = EventInvoker.lookup(RenderTooltipCallback.class);

    /**
     * Called just before a tooltip is drawn on a screen, allows for preventing the tooltip from drawing.
     *
     * @param guiGraphics       the gui graphics instance
     * @param font              the font instance
     * @param mouseX            the mouse cursor x-position
     * @param mouseY            the mouse cursor y-position
     * @param components        the components to render in the tooltip
     * @param tooltipPositioner the positioner for placing the tooltip in relation to provided mouse coordinates
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the tooltip from rendering, allows for fully taking over rendering</li>
     *         <li>{@link EventResult#PASS PASS} to allow the vanilla tooltip to render as usual</li>
     *         </ul>
     */
    EventResult onRenderTooltip(class_332 guiGraphics, class_327 font, int mouseX, int mouseY, List<class_5684> components, class_8000 tooltipPositioner);
}
