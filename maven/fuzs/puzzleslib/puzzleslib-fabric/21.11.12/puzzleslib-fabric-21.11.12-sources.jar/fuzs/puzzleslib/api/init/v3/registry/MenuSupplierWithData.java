package fuzs.puzzleslib.api.init.v3.registry;

import net.minecraft.class_1661;
import net.minecraft.class_1703;

/**
 * An extended implementation of {@link net.minecraft.class_3917.class_3918}, that allows for sending
 * additional data from the server.
 *
 * @param <T> the type of menu
 */
@FunctionalInterface
public interface MenuSupplierWithData<T extends class_1703, S> {

    /**
     * Create the container menu.
     *
     * @param containerId the menu id
     * @param inventory   the player inventory
     * @param data        the additional data to send to the client
     * @return the container menu
     */
    T create(int containerId, class_1661 inventory, S data);
}
