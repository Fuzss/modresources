package fuzs.puzzleslib.fabric.impl.item;

import fuzs.puzzleslib.api.item.v2.ToolTypeHelper;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalItemTags;
import net.minecraft.class_1799;

public final class FabricToolTypeHelper implements ToolTypeHelper {

    @Override
    public boolean isShears(class_1799 itemStack) {
        return ToolTypeHelper.super.isShears(itemStack) || itemStack.method_31573(ConventionalItemTags.SHEAR_TOOLS);
    }

    @Override
    public boolean isShield(class_1799 itemStack) {
        return ToolTypeHelper.super.isShield(itemStack) || itemStack.method_31573(ConventionalItemTags.SHIELD_TOOLS);
    }

    @Override
    public boolean isBow(class_1799 itemStack) {
        return ToolTypeHelper.super.isBow(itemStack) || itemStack.method_31573(ConventionalItemTags.BOW_TOOLS);
    }

    @Override
    public boolean isCrossbow(class_1799 itemStack) {
        return ToolTypeHelper.super.isCrossbow(itemStack) || itemStack.method_31573(ConventionalItemTags.CROSSBOW_TOOLS);
    }

    @Override
    public boolean isFishingRod(class_1799 itemStack) {
        return ToolTypeHelper.super.isFishingRod(itemStack) || itemStack.method_31573(ConventionalItemTags.FISHING_ROD_TOOLS);
    }

    @Override
    public boolean isTridentLike(class_1799 itemStack) {
        return ToolTypeHelper.super.isTridentLike(itemStack) || itemStack.method_31573(ConventionalItemTags.SPEAR_TOOLS);
    }

    @Override
    public boolean isBrush(class_1799 itemStack) {
        return ToolTypeHelper.super.isBrush(itemStack) || itemStack.method_31573(ConventionalItemTags.BRUSH_TOOLS);
    }

    @Override
    public boolean isMace(class_1799 itemStack) {
        return ToolTypeHelper.super.isMace(itemStack) || itemStack.method_31573(ConventionalItemTags.MACE_TOOLS);
    }

    @Override
    public boolean isMeleeWeapon(class_1799 itemStack) {
        return ToolTypeHelper.super.isMeleeWeapon(itemStack) || itemStack.method_31573(ConventionalItemTags.MELEE_WEAPON_TOOLS);
    }

    @Override
    public boolean isRangedWeapon(class_1799 itemStack) {
        return ToolTypeHelper.super.isRangedWeapon(itemStack) || itemStack.method_31573(ConventionalItemTags.RANGED_WEAPON_TOOLS);
    }

    @Override
    public boolean isMiningTool(class_1799 itemStack) {
        return ToolTypeHelper.super.isMiningTool(itemStack) || itemStack.method_31573(ConventionalItemTags.MINING_TOOL_TOOLS);
    }

    @Override
    public boolean isTool(class_1799 itemStack) {
        return ToolTypeHelper.super.isTool(itemStack) || itemStack.method_31573(ConventionalItemTags.TOOLS);
    }

    @Override
    public boolean isArmor(class_1799 itemStack) {
        return ToolTypeHelper.super.isArmor(itemStack) || itemStack.method_31573(ConventionalItemTags.ARMORS);
    }
}
