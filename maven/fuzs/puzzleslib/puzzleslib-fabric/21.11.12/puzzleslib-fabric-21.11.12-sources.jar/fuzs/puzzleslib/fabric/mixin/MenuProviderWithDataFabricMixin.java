package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.container.v1.MenuProviderWithData;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_3222;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(MenuProviderWithData.class)
public interface MenuProviderWithDataFabricMixin<T> extends ExtendedScreenHandlerFactory<T> {

    @Shadow(remap = false)
    T getMenuData(@Nullable class_3222 serverPlayer);

    @Override
    default T getScreenOpeningData(class_3222 serverPlayer) {
        return this.getMenuData(serverPlayer);
    }
}
