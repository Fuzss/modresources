package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricEntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1676;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_9109;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1676.class)
abstract class ProjectileFabricMixin extends class_1297 {

    public ProjectileFabricMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "hitTargetOrDeflectSelf", at = @At("HEAD"), cancellable = true)
    protected void hitTargetOrDeflectSelf(class_239 hitResult, CallbackInfoReturnable<class_9109> callback) {
        // simplified patch for this event, Projectile::hitTargetOrDeflectSelf might be overridden in mod classes,
        // but so might the NeoForge patches in e.g. Projectile::onHit
        EventResult result = FabricEntityEvents.PROJECTILE_IMPACT.invoker().onProjectileImpact(
                class_1676.class.cast(this), hitResult);
        if (result.isInterrupt()) {
            callback.setReturnValue(class_9109.field_48347);
        }
    }
}
