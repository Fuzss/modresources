package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.EntityRenderersContext;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;
import java.util.Objects;

public final class EntityRenderersContextFabricImpl implements EntityRenderersContext {

    @Override
    public <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> entityType, class_5617<T> entityRendererProvider) {
        Objects.requireNonNull(entityType, "entity type is null");
        Objects.requireNonNull(entityRendererProvider, "entity renderer provider is null");
        EntityRendererRegistry.register(entityType, entityRendererProvider);
    }
}
