package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
abstract class AbstractContainerScreenFabricMixin extends class_437 {

    protected AbstractContainerScreenFabricMixin(class_2561 component) {
        super(component);
    }

    @Inject(
            method = "renderContents", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;renderLabels(Lnet/minecraft/client/gui/GuiGraphics;II)V",
            shift = At.Shift.AFTER
    )
    )
    public void renderContents(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks, CallbackInfo callback) {
        FabricGuiEvents.RENDER_CONTAINER_SCREEN_CONTENTS.invoker()
                .onRenderContainerScreenContents(class_465.class.cast(this), guiGraphics, mouseX, mouseY);
    }
}
