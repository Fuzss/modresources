package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import net.minecraft.class_11659;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
abstract class ItemInHandRendererFabricMixin {

    @Inject(method = "renderArmWithItem", at = @At("HEAD"), cancellable = true)
    private void renderArmWithItem(class_742 abstractClientPlayer, float partialTick, float interpolatedPitch, class_1268 interactionHand, float swingProgress, class_1799 itemStack, float equipProgress, class_4587 poseStack, class_11659 submitNodeCollector, int packedLight, CallbackInfo callback) {
        if (interactionHand == class_1268.field_5808) {
            EventResult result = FabricRendererEvents.RENDER_MAIN_HAND.invoker()
                    .onRenderMainHand(class_759.class.cast(this),
                            interactionHand,
                            abstractClientPlayer,
                            abstractClientPlayer.method_6068(),
                            itemStack,
                            poseStack,
                            submitNodeCollector,
                            packedLight,
                            partialTick,
                            interpolatedPitch,
                            swingProgress,
                            equipProgress);
            if (result.isInterrupt()) {
                callback.cancel();
            }
        } else if (interactionHand == class_1268.field_5810) {
            EventResult result = FabricRendererEvents.RENDER_OFF_HAND.invoker()
                    .onRenderOffHand(class_759.class.cast(this),
                            interactionHand,
                            abstractClientPlayer,
                            abstractClientPlayer.method_6068().method_5928(),
                            itemStack,
                            poseStack,
                            submitNodeCollector,
                            packedLight,
                            partialTick,
                            interpolatedPitch,
                            swingProgress,
                            equipProgress);
            if (result.isInterrupt()) {
                callback.cancel();
            }
        }
    }
}
