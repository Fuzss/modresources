package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.EntitySpectatorShadersContext;
import org.jspecify.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public final class EntitySpectatorShadersContextFabricImpl implements EntitySpectatorShadersContext {
    private static final Map<class_1299<?>, class_2960> ENTITY_SPECTATOR_SHADERS = new LinkedHashMap<>();

    @Override
    public void registerSpectatorShader(class_1299<?> entityType, class_2960 identifier) {
        Objects.requireNonNull(entityType, "entity type is null");
        Objects.requireNonNull(identifier, "shader location is null");
        ENTITY_SPECTATOR_SHADERS.put(entityType, identifier);
    }

    public static Optional<class_2960> getEntityShader(@Nullable class_1297 entity) {
        if (entity != null && ENTITY_SPECTATOR_SHADERS.containsKey(entity.method_5864())) {
            return Optional.of(ENTITY_SPECTATOR_SHADERS.get(entity.method_5864()));
        } else {
            return Optional.empty();
        }
    }
}
