package fuzs.puzzleslib.api.util.v1;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/**
 * A helper class for converting various text representations.
 * <p>
 * Useful for text instances returned from {@link net.minecraft.class_5225} and
 * {@link class_2561#method_30937()}.
 * <p>
 * All methods automatically convert legacy {@link class_124} included as part of the backing string to a proper
 * {@link class_2583} object.
 */
public final class ComponentHelper {

    private ComponentHelper() {
        // NO-OP
    }

    /**
     * Converts a string to a {@link class_2561}.
     *
     * @param text the string to convert
     * @return the new component
     */
    public static class_2561 getAsComponent(String text) {
        return StyleCombiningCharSink.of(text, class_2583.field_24360).getAsComponent();
    }

    /**
     * Converts an instance of {@link class_5348} to a {@link class_2561}.
     *
     * @param formattedText the text to convert
     * @return the new component
     */
    public static class_2561 getAsComponent(class_5348 formattedText) {
        return StyleCombiningCharSink.of(formattedText, class_2583.field_24360).getAsComponent();
    }

    /**
     * Converts an instance of {@link class_5348} to a string which includes formatting codes supplied via configured
     * {@link class_2583 Styles}.
     * <p>
     * This is mostly useful when working with instances where vanilla still renders raw strings, which inherently
     * support the old chat formatting system, such as in
     * {@link net.minecraft.class_340}.
     *
     * @param formattedText the text to convert
     * @return the string
     */
    public static String getAsString(class_5348 formattedText) {
        return StyleCombiningCharSink.of(formattedText, class_2583.field_24360).getAsString();
    }

    /**
     * Converts an instance of {@link class_5481} to a {@link class_2561}.
     *
     * @param formattedCharSequence the text to convert
     * @return the new component
     */
    public static class_2561 getAsComponent(class_5481 formattedCharSequence) {
        return StyleCombiningCharSink.of(formattedCharSequence, class_2583.field_24360).getAsComponent();
    }

    /**
     * Converts an instance of {@link class_5481} to a string which includes formatting codes supplied via
     * configured {@link class_2583 Styles}.
     * <p>
     * This is mostly useful when working with instances where vanilla still renders raw strings, which inherently
     * support the old chat formatting system, such as in
     * {@link net.minecraft.class_340}.
     *
     * @param formattedCharSequence the text to convert
     * @return the string
     */
    public static String getAsString(class_5481 formattedCharSequence) {
        return StyleCombiningCharSink.of(formattedCharSequence, class_2583.field_24360).getAsString();
    }

    /**
     * Converts a string to a {@link class_2561} with the specified {@link class_2583}.
     *
     * @param text  the string to convert
     * @param style the style to apply to the component
     * @return the new component with the applied style
     */
    public static class_2561 getAsComponent(String text, class_2583 style) {
        return class_2561.method_43470(text).method_27696(style);
    }

    /**
     * Converts the given string into a formatted string by applying the specified {@link class_2583}.
     * <p>
     * If the provided style is not empty, the method appends the style's formatting codes and resets formatting after
     * the original string.
     *
     * @param text  the original string to format
     * @param style the {@link class_2583} to apply to the string
     * @return the formatted string if the style is not empty; otherwise, the original string
     */
    public static String getAsString(String text, class_2583 style) {
        if (!style.method_10967()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(ComponentHelper.getAsString(style));
            stringBuilder.append(text);
            stringBuilder.append(class_124.field_1070);
            return stringBuilder.toString();
        } else {
            return text;
        }
    }

    /**
     * Gets the primary i.e., the very first non-empty {@link class_2583} used by a {@link class_2561}.
     * <p>
     * Useful for formatting code config options together with {@link #getAsString(class_2583)}.
     *
     * @param component the component
     * @return the style
     */
    public static class_2583 getDefaultStyle(class_2561 component) {
        Set<class_2561> visitedComponents = new HashSet<>();
        while (true) {
            if (component.method_10855().isEmpty() || !component.method_10866().method_10967()) {
                return component.method_10866();
            } else if (visitedComponents.contains(component)) {
                return class_2583.field_24360;
            } else {
                visitedComponents.add(component);
                component = component.method_10855().getFirst();
            }
        }
    }

    /**
     * Gets the primary i.e., the very first non-empty {@link class_2583} used by a {@link String}.
     * <p>
     * Useful for formatting code config options together with {@link #getAsString(class_2583)}.
     *
     * @param text the string
     * @return the style
     */
    public static class_2583 getDefaultStyle(String text) {
        Objects.requireNonNull(text, "text is null");
        class_2561 component = getAsComponent(text);
        // No style will have been passed when the component is empty.
        // We could also strip formatting codes from the string and check if it is empty,
        // but that might return false negatives with surrogates, maybe.
        if (!text.isEmpty() && component.getString().isEmpty()) {
            StringBuilder stringBuilder = new StringBuilder(text);
            // A hack to get raw formatting without any non-formatting characters to apply.
            // We basically check if only formatting is present (when the component is empty),
            // then insert a temporary space and create a new component from that, which we only use the style from.
            int index = text.indexOf(class_124.field_1070.toString());
            stringBuilder.insert(index != -1 ? index : text.length(), " ");
            return getDefaultStyle(getAsComponent(stringBuilder.toString()));
        } else {
            return getDefaultStyle(component);
        }
    }

    /**
     * Gets the primary i.e., the very first non-empty {@link class_2583} used by a {@link class_5348}.
     *
     * @param formattedText the text
     * @return the style
     */
    public static class_2583 getDefaultStyle(class_5348 formattedText) {
        // Pass this through our component conversion to make sure all formatting codes included in the string itself are properly applied.
        return getDefaultStyle(getAsComponent(formattedText));
    }

    /**
     * Gets the primary i.e., the very first non-empty {@link class_2583} used by a {@link class_5481}.
     *
     * @param formattedCharSequence the text
     * @return the style
     */
    public static class_2583 getDefaultStyle(class_5481 formattedCharSequence) {
        // Pass this through our component conversion to make sure all formatting codes included in the string itself are properly applied.
        return getDefaultStyle(getAsComponent(formattedCharSequence));
    }

    /**
     * Converts a {@link class_2583} to {@link class_124 chat formatting codes} and outputs those as a single string.
     *
     * @param style the style
     * @return the string consisting of legacy formatting codes
     */
    public static String getAsString(class_2583 style) {
        Objects.requireNonNull(style, "style is null");
        if (style.method_10967()) {
            return "";
        }

        StringBuilder stringBuilder = new StringBuilder();
        getLegacyFormat(style, (class_124 chatFormatting) -> {
            stringBuilder.append(chatFormatting.toString());
        });
        return stringBuilder.toString();
    }

    /**
     * Outputs all {@link class_124 chat formatting codes} supplied by a style in the correct order.
     *
     * @param style                  the style
     * @param chatFormattingConsumer the chat formatting output
     */
    public static void getLegacyFormat(class_2583 style, Consumer<class_124> chatFormattingConsumer) {
        Objects.requireNonNull(style, "style is null");
        if (style.method_10967()) {
            return;
        }

        // colour must be added before formatting
        if (style.method_10973() != null) {
            class_124 color = class_124.method_533(style.method_10973().method_27721());

            if (color != null) {
                chatFormattingConsumer.accept(color);
            }
        }

        // multiple formatting codes may exist at the same time
        if (style.method_10984()) {
            chatFormattingConsumer.accept(class_124.field_1067);
        }

        if (style.method_10966()) {
            chatFormattingConsumer.accept(class_124.field_1056);
        }

        if (style.method_10965()) {
            chatFormattingConsumer.accept(class_124.field_1073);
        }

        if (style.method_10986()) {
            chatFormattingConsumer.accept(class_124.field_1055);
        }

        if (style.method_10987()) {
            chatFormattingConsumer.accept(class_124.field_1051);
        }
    }

    /**
     * Reverts effects from using {@link class_2583#method_27707(class_124)} to achieve the same result as
     * {@link class_2583#method_27706(class_124)} would for a more compact and versatile style object.
     *
     * @param style the style
     * @return the sanitised style
     */
    public static class_2583 sanitizeLegacyFormat(class_2583 style) {
        Objects.requireNonNull(style, "style is null");
        if (style.method_10967()) {
            return style;
        }

        if (!style.method_10984()) {
            style = style.method_10982(null);
        }

        if (!style.method_10966()) {
            style = style.method_10978(null);
        }

        if (!style.method_10965()) {
            style = style.method_30938(null);
        }

        if (!style.method_10986()) {
            style = style.method_36140(null);
        }

        if (!style.method_10987()) {
            style = style.method_36141(null);
        }

        return style;
    }
}
