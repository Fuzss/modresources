package fuzs.puzzleslib.fabric.impl.init;

import fuzs.puzzleslib.api.event.v1.server.RegisterPotionBrewingMixesCallback;
import java.util.Objects;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1856;
import net.minecraft.class_6880;

public record FabricPotionBrewingBuilder(class_1845.class_9665 builder) implements RegisterPotionBrewingMixesCallback.Builder {

    @Override
    public void registerPotionContainer(class_1812 item) {
        Objects.requireNonNull(item, "container item is null");
        this.builder.method_59702(item);
    }

    @Override
    public void registerContainerRecipe(class_1812 inputItem, class_1856 ingredient, class_1812 outputItem) {
        Objects.requireNonNull(inputItem, "input item is null");
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(outputItem, "output item is null");
        this.builder.registerItemRecipe(inputItem, ingredient, outputItem);
    }

    @Override
    public void registerPotionRecipe(class_6880<class_1842> intputPotion, class_1856 ingredient, class_6880<class_1842> outputPotion) {
        Objects.requireNonNull(intputPotion, "input potion is null");
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(outputPotion, "output potion is null");
        this.builder.registerPotionRecipe(intputPotion, ingredient, outputPotion);
    }
}
