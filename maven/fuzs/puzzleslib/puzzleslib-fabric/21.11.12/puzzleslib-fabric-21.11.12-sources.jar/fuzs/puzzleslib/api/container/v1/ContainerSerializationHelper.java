package fuzs.puzzleslib.api.container.v1;

import fuzs.puzzleslib.impl.container.SlotsProvider;
import net.minecraft.class_11343;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1263;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

/**
 * An adjusted version of {@link net.minecraft.class_1262} that allows for using {@link class_1263} instead of
 * {@link net.minecraft.class_2371}.
 */
public final class ContainerSerializationHelper {

    private ContainerSerializationHelper() {
        // NO-OP
    }

    /**
     * Write item stacks to an output.
     *
     * @param valueOutput the value output
     * @param itemStacks  the item list
     * @see net.minecraft.class_1262#method_5426(class_11372, class_2371)
     */
    public static void saveAllItems(class_11372 valueOutput, class_2371<class_1799> itemStacks) {
        storeAsSlots(itemStacks, valueOutput.method_71467("Items", class_11343.field_60354));
    }

    /**
     * Write item stacks to an output.
     *
     * @param valueOutput the value output
     * @param container   the container
     * @see net.minecraft.class_1262#method_5426(class_11372, class_2371)
     */
    public static void saveAllItems(class_11372 valueOutput, class_1263 container) {
        storeAsSlots(container, valueOutput.method_71467("Items", class_11343.field_60354));
    }

    /**
     * Write item stacks to an output.
     *
     * @param itemStacks      the item list
     * @param typedOutputList the output list
     * @see net.minecraft.class_1730#method_71391(class_11372.class_11373)
     */
    public static void storeAsSlots(class_2371<class_1799> itemStacks, class_11372.class_11373<class_11343> typedOutputList) {
        storeAsSlots(SlotsProvider.of(itemStacks), typedOutputList);
    }

    /**
     * Write item stacks to an output.
     *
     * @param container       the container
     * @param typedOutputList the output list
     * @see net.minecraft.class_1730#method_71391(class_11372.class_11373)
     */
    public static void storeAsSlots(class_1263 container, class_11372.class_11373<class_11343> typedOutputList) {
        storeAsSlots(SlotsProvider.of(container), typedOutputList);
    }

    private static void storeAsSlots(SlotsProvider slotsProvider, class_11372.class_11373<class_11343> typedOutputList) {
        for (int i = 0; i < slotsProvider.getContainerSize(); i++) {
            class_1799 itemStack = slotsProvider.getItem(i);
            if (!itemStack.method_7960()) {
                typedOutputList.method_71484(new class_11343(i, itemStack));
            }
        }
    }

    /**
     * Read item stacks from an input.
     *
     * @param valueInput the value input
     * @param itemStacks the item list
     * @see net.minecraft.class_1262#method_5429(class_11368, class_2371)
     */
    public static void loadAllItems(class_11368 valueInput, class_2371<class_1799> itemStacks) {
        fromSlots(itemStacks, valueInput.method_71437("Items", class_11343.field_60354));
    }

    /**
     * Read item stacks from an input.
     *
     * @param valueInput the value input
     * @param container  the container
     * @see net.minecraft.class_1262#method_5429(class_11368, class_2371)
     */
    public static void loadAllItems(class_11368 valueInput, class_1263 container) {
        fromSlots(container, valueInput.method_71437("Items", class_11343.field_60354));
    }

    /**
     * Read item stacks from an input.
     *
     * @param itemStacks     the item list
     * @param typedInputList the input list
     * @see net.minecraft.class_1730#method_71390(class_11368.class_11369)
     */
    public static void fromSlots(class_2371<class_1799> itemStacks, class_11368.class_11369<class_11343> typedInputList) {
        fromSlots(SlotsProvider.of(itemStacks), typedInputList);
    }

    /**
     * Read item stacks from an input.
     *
     * @param container      the container
     * @param typedInputList the input list
     * @see net.minecraft.class_1730#method_71390(class_11368.class_11369)
     */
    public static void fromSlots(class_1263 container, class_11368.class_11369<class_11343> typedInputList) {
        fromSlots(SlotsProvider.of(container), typedInputList);
    }

    private static void fromSlots(SlotsProvider slotsProvider, class_11368.class_11369<class_11343> typedInputList) {
        slotsProvider.clearContent();
        for (class_11343 itemStackWithSlot : typedInputList) {
            if (itemStackWithSlot.method_71368(slotsProvider.getContainerSize())) {
                slotsProvider.setItem(itemStackWithSlot.comp_4211(), itemStackWithSlot.comp_4212());
            }
        }
    }
}
