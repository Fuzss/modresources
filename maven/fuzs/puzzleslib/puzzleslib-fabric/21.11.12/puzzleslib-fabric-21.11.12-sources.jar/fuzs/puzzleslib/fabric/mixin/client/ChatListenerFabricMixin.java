package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.sugar.Cancellable;
import com.llamalad7.mixinextras.sugar.Local;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.UUID;
import net.minecraft.class_2556;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_7471;
import net.minecraft.class_7594;

@Mixin(class_7594.class)
abstract class ChatListenerFabricMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @ModifyArg(method = "lambda$handleDisguisedChatMessage$3",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/ChatComponent;addMessage(Lnet/minecraft/network/chat/Component;)V"))
    public class_2561 handleDisguisedChatMessage(class_2561 component, @Local(argsOnly = true) class_2556.class_7602 boundChatType, @Cancellable CallbackInfoReturnable<Boolean> callback) {
        MutableValue<class_2561> chatMessage = MutableValue.fromValue(component);
        EventResult result = FabricClientEvents.CHAT_MESSAGE_RECEIVED.invoker()
                .onChatMessageReceived(chatMessage, boundChatType, null, false);
        if (result.isInterrupt()) callback.setReturnValue(true);
        return chatMessage.get();
    }

    @ModifyArg(method = "showMessageToPlayer",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/ChatComponent;addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/GuiMessageTag;)V"),
            require = 2)
    public class_2561 showMessageToPlayer(class_2561 component, @Local(argsOnly = true) class_2556.class_7602 boundChatType, @Local(
            argsOnly = true) class_7471 playerChatMessage, @Cancellable CallbackInfoReturnable<Boolean> callback) {
        MutableValue<class_2561> chatMessage = MutableValue.fromValue(component);
        EventResult result = FabricClientEvents.CHAT_MESSAGE_RECEIVED.invoker()
                .onChatMessageReceived(chatMessage, boundChatType, playerChatMessage, false);
        if (result.isInterrupt()) callback.setReturnValue(true);
        return chatMessage.get();
    }

    @ModifyVariable(method = "handleSystemMessage", at = @At("HEAD"), argsOnly = true)
    public class_2561 handleSystemMessage(class_2561 component, @Local(argsOnly = true) boolean isOverlay, @Cancellable CallbackInfo callback) {
        if (!this.minecraft.field_1690.method_42451().method_41753()
                || !this.minecraft.method_29042(this.guessChatUUID(component))) {
            MutableValue<class_2561> chatMessage = MutableValue.fromValue(component);
            EventResult result = FabricClientEvents.CHAT_MESSAGE_RECEIVED.invoker()
                    .onChatMessageReceived(chatMessage, null, null, isOverlay);
            if (result.isInterrupt()) callback.cancel();
            return chatMessage.get();
        } else {
            return component;
        }
    }

    @Shadow
    private UUID guessChatUUID(class_2561 message) {
        throw new RuntimeException();
    }
}
