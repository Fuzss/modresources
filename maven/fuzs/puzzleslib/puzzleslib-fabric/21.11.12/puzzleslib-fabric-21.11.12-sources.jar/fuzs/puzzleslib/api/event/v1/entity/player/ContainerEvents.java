package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

public final class ContainerEvents {
    public static final EventInvoker<Open> OPEN = EventInvoker.lookup(Open.class);
    public static final EventInvoker<Close> CLOSE = EventInvoker.lookup(Close.class);

    private ContainerEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Open {

        /**
         * Called after the player has opened a container, which is when the new {@link class_1703} has been
         * set to {@link class_1657#field_7512} in {@link class_1657#method_17355(class_3908)}.
         *
         * @param serverPlayer  the server player
         * @param containerMenu the container menu
         */
        void onContainerOpen(class_3222 serverPlayer, class_1703 containerMenu);
    }

    @FunctionalInterface
    public interface Close {

        /**
         * Called when the player is closing an open container, where {@link class_1657#field_7512} is reset to
         * {@link class_1657#field_7498} in {@link class_1657#method_14247()}.
         *
         * @param serverPlayer  the server player
         * @param containerMenu the container menu
         */
        void onContainerClose(class_3222 serverPlayer, class_1703 containerMenu);
    }
}
