package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.fabric.impl.event.SpawnReasonMob;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import fuzs.puzzleslib.impl.event.data.DefaultedValue;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1266;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.world.entity.*;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1308.class)
abstract class MobFabricMixin extends class_1309 implements SpawnReasonMob {
    @Shadow
    @Nullable private class_1309 target;
    @Unique @Nullable private class_3730 puzzleslib$spawnReason;

    protected MobFabricMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "finalizeSpawn", at = @At("TAIL"))
    public void finalizeSpawn(class_5425 level, class_1266 difficulty, class_3730 reason, @Nullable class_1315 spawnData, CallbackInfoReturnable<class_1315> callback) {
        this.puzzleslib$spawnReason = reason;
    }

    @Override
    @Nullable public final class_3730 puzzleslib$getSpawnReason() {
        return this.puzzleslib$spawnReason;
    }

    @Override
    public void puzzleslib$setSpawnReason(@Nullable class_3730 entitySpawnReason) {
        this.puzzleslib$spawnReason = entitySpawnReason;
    }

    @Inject(method = "setTarget", at = @At("HEAD"), cancellable = true)
    public void setTarget(@Nullable class_1309 livingEntity, CallbackInfo callback) {
        DefaultedValue<class_1309> target = DefaultedValue.fromValue(livingEntity);
        EventResult result = FabricLivingEvents.LIVING_CHANGE_TARGET.invoker().onLivingChangeTarget(this, target);
        if (result.isInterrupt()) {
            callback.cancel();
        } else if (target.getAsOptional().isPresent()) {
            this.target = target.get();
            callback.cancel();
        }
    }

    @Inject(method = "checkDespawn",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/world/level/Level;getNearestPlayer(Lnet/minecraft/world/entity/Entity;D)Lnet/minecraft/world/entity/player/Player;"),
            cancellable = true)
    public void checkDespawn(CallbackInfo callback) {
        EventResult result = FabricLivingEvents.CHECK_MOB_DESPAWN.invoker()
                .onCheckMobDespawn(class_1308.class.cast(this), (class_3218) this.method_73183());
        if (result.isInterrupt()) {
            if (result.getAsBoolean()) {
                this.method_31472();
            } else {
                this.field_6278 = 0;
            }
            callback.cancel();
        }
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    public void addAdditionalSaveData(class_11372 valueOutput, CallbackInfo callback) {
        valueOutput.method_71477(PuzzlesLibMod.id("spawn_type").toString(),
                SpawnReasonMob.CODEC,
                this.puzzleslib$spawnReason);
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    public void readAdditionalSaveData(class_11368 valueInput, CallbackInfo callback) {
        this.puzzleslib$spawnReason = valueInput.method_71426(PuzzlesLibMod.id("spawn_type").toString(), SpawnReasonMob.CODEC)
                .orElse(null);
    }
}
