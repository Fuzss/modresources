package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.impl.event.PotentialSpawnsList;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1311;
import net.minecraft.class_1948;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6010;
import net.minecraft.class_6012;
import net.minecraft.class_6880;

@Mixin(class_1948.class)
abstract class NaturalSpawnerFabricMixin {

    @ModifyReturnValue(method = "mobsAt", at = @At("RETURN"))
    private static class_6012<class_5483.class_1964> mobsAt(class_6012<class_5483.class_1964> weightedList, class_3218 serverLevel, class_5138 structureManager, class_2794 chunkGenerator, class_1311 mobCategory, class_2338 blockPos, @Nullable class_6880<class_1959> biome) {
        MutableObject<List<class_6010<class_5483.class_1964>>> holder = new MutableObject<>();
        List<class_6010<class_5483.class_1964>> mobs = new PotentialSpawnsList<>(() -> {
            return holder.get() != null ? holder.get() : weightedList.method_34994();
        }, (class_6010<class_5483.class_1964> spawnerData) -> {
            List<class_6010<class_5483.class_1964>> spawnerDataList = holder.get();
            if (spawnerDataList == null) {
                holder.setValue(spawnerDataList = new ArrayList<>(weightedList.method_34994()));
            }

            return spawnerDataList.add(spawnerData);
        }, (class_6010<class_5483.class_1964> spawnerData) -> {
            List<class_6010<class_5483.class_1964>> spawnerDataList = holder.get();
            if (spawnerDataList == null) {
                holder.setValue(spawnerDataList = new ArrayList<>(weightedList.method_34994()));
            }

            return spawnerDataList.remove(spawnerData);
        });
        FabricLevelEvents.GATHER_POTENTIAL_SPAWNS.invoker()
                .onGatherPotentialSpawns(serverLevel, structureManager, chunkGenerator, mobCategory, blockPos, mobs);
        return holder.get() != null ? class_6012.method_34988(holder.get()) : weightedList;
    }
}
