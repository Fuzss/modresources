package fuzs.puzzleslib.api.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1792;
import net.minecraft.class_9323;
import net.minecraft.class_9326;

@FunctionalInterface
public interface FinalizeItemComponentsCallback {
    EventInvoker<FinalizeItemComponentsCallback> EVENT = EventInvoker.lookup(FinalizeItemComponentsCallback.class);

    /**
     * Called when default item data components are constructed, allows for applying patches directly.
     *
     * @param item     the item
     * @param consumer apply a patch to the default item data components
     */
    void onFinalizeItemComponents(class_1792 item, Consumer<Function<class_9323, class_9326>> consumer);
}
