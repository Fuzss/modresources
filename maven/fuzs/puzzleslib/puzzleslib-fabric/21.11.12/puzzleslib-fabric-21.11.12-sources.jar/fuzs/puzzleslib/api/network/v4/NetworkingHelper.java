package fuzs.puzzleslib.api.network.v4;

import fuzs.puzzleslib.api.network.v4.message.Message;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.core.context.PayloadTypesContextImpl;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import java.util.Objects;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3222;
import net.minecraft.class_8605;
import net.minecraft.class_8705;
import net.minecraft.class_8706;
import net.minecraft.class_8710;
import net.minecraft.class_8735;

public final class NetworkingHelper {

    private NetworkingHelper() {
        // NO-OP
    }

    /**
     * Get the custom packet payload type for a registered message class.
     * <p>
     * The type can also be obtained from the instance itself via {@link Message#method_56479()}.
     *
     * @param payloadClazz the message clazz type
     * @param <T>          the message type
     * @return the custom packet payload type
     */
    public static <T extends Message<?>> class_8710.class_9154<T> getPayloadType(Class<T> payloadClazz) {
        Objects.requireNonNull(payloadClazz, "payload class is null");
        return PayloadTypesContextImpl.getPayloadType(payloadClazz);
    }

    /**
     * Creates a packet that can be sent to clients from the provided payload.
     *
     * @param payload the custom packet payload
     * @return the packet
     */
    public static class_2596<class_8705> toClientboundPacket(class_8710 payload) {
        Objects.requireNonNull(payload, "payload is null");
        return ProxyImpl.get().toClientboundPacket(payload);
    }

    /**
     * Creates a packet that can be sent to the server from the provided payload.
     *
     * @param payload the custom packet payload
     * @return the packet
     */
    public static class_2596<class_8706> toServerboundPacket(class_8710 payload) {
        Objects.requireNonNull(payload, "payload is null");
        return ProxyImpl.get().toServerboundPacket(payload);
    }

    /**
     * Reports a configuration task as finished, so that the {@link class_8735} may move on to
     * the next task.
     * <p>
     * Usually called after completing the task on the server, or after receiving the client response packet.
     *
     * @param packetListener        the packet listener
     * @param configurationTaskType the configuration task type
     */
    public static void finishConfigurationTask(class_8735 packetListener, class_8605.class_8606 configurationTaskType) {
        Objects.requireNonNull(packetListener, "packet listener is null");
        Objects.requireNonNull(configurationTaskType, "configuration task type is null");
        ProxyImpl.get().finishConfigurationTask(packetListener, configurationTaskType);
    }

    /**
     * Checks if the packet listener has declared the ability to receive a specific custom packet payload type.
     *
     * @param packetListener the packet listener
     * @param payloadType    the packet type
     * @return can the custom packet payload type be received
     */
    public static boolean hasChannel(class_2547 packetListener, class_8710.class_9154<?> payloadType) {
        Objects.requireNonNull(packetListener, "packet listener is null");
        Objects.requireNonNull(payloadType, "custom packet payload type is null");
        return ProxyImpl.get().hasChannel(packetListener, payloadType);
    }

    /**
     * @return the connection to the server on the physical client
     */
    public static class_2602 getClientPacketListener() {
        return ProxyImpl.get().getClientPacketListener();
    }

    /**
     * Get the {@link class_2535} from a packet listener.
     *
     * @param packetListener the packet listener
     * @return the connection
     */
    public static class_2535 getConnection(class_2547 packetListener) {
        Objects.requireNonNull(packetListener, "packet listener is null");
        class_2535 connection = ProxyImpl.get().getConnection(packetListener);
        Objects.requireNonNull(connection, "connection is null");
        return connection;
    }

    /**
     * A simple check for any mod constructed using Puzzles Lib to find if the mod is installed on the server; useful
     * for altering behaviour depending on the mod state.
     * <p>
     * This method <b>CANNOT</b> be used for checking the state of any arbitrary mod, only Puzzles Lib mods are
     * supported.
     *
     * @param modId the mod to check
     * @return is the mod installed on the server
     */
    public static boolean isModPresentServerside(String modId) {
        return ModContext.getModContexts().containsKey(modId) && ModContext.getModContexts()
                .get(modId)
                .isPresentServerside();
    }

    /**
     * A simple check for any mod constructed using Puzzles Lib to find if the mod is installed on a client; useful for
     * altering behaviour depending on the mod state.
     * <p>
     * This method <b>CANNOT</b> be used for checking the state of any arbitrary mod, only Puzzles Lib mods are
     * supported.
     *
     * @param serverPlayer the client to check
     * @param modId        the mod to check
     * @return is the mod installed on a client
     */
    public static boolean isModPresentClientside(class_3222 serverPlayer, String modId) {
        return ModContext.getModContexts().containsKey(modId) && ModContext.getModContexts()
                .get(modId)
                .isPresentClientside(serverPlayer);
    }
}
