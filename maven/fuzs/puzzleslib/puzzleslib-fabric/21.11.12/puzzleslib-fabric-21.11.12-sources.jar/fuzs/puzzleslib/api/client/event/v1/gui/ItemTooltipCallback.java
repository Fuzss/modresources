package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import org.jspecify.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

@FunctionalInterface
public interface ItemTooltipCallback {
    EventInvoker<ItemTooltipCallback> EVENT = EventInvoker.lookup(ItemTooltipCallback.class);

    /**
     * Called at the end of item tooltip gathering in
     * {@link class_1799#method_7950(class_1792.class_9635, class_1657, class_1836)}.
     * <p>
     * Allows for both appending additional tooltip lines and removing / replacing existing lines.
     *
     * @param itemStack      the item stack owning this tooltip
     * @param tooltipLines   the tooltip lines
     * @param tooltipContext the tooltip item context
     * @param player         the player looking at the tooltip, null when search trees are created
     * @param tooltipFlag    the tooltip flag context
     */
    void onItemTooltip(class_1799 itemStack, List<class_2561> tooltipLines, class_1792.class_9635 tooltipContext, @Nullable class_1657 player, class_1836 tooltipFlag);
}
