package fuzs.puzzleslib.fabric.impl.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.context.EntityAttributesContext;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_5132;
import net.minecraft.class_5135;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import java.util.Objects;

@SuppressWarnings("DataFlowIssue")
public final class EntityAttributesContextFabricImpl implements EntityAttributesContext {

    @Override
    public void registerAttributes(class_1299<? extends class_1309> entityType, class_5132.class_5133 attributesBuilder) {
        Objects.requireNonNull(entityType, "entity type is null");
        Objects.requireNonNull(attributesBuilder, "attributes builder is null");
        Preconditions.checkState(!class_5135.method_26875(entityType),
                "attributes already present for " + entityType);
        FabricDefaultAttributeRegistry.register(entityType, attributesBuilder);
    }

    @Override
    public void registerAttribute(class_1299<? extends class_1309> entityType, class_6880<class_1320> attribute, double attributeValue) {
        Objects.requireNonNull(entityType, "entity type is null");
        Objects.requireNonNull(attribute, "attribute is null");
        Preconditions.checkState(class_5135.method_26875(entityType), "attributes missing for " + entityType);
        class_5132 attributeSupplier = class_5135.method_26873(entityType);
        class_5132.class_5133 attributesBuilder = class_5132.method_26861();
        // there aren't many attributes anyway, so iterating the whole registry isn't costly
        class_7923.field_41190.method_42017().forEach((class_6880.class_6883<class_1320> holder) -> {
            if (attributeSupplier.method_27310(holder)) {
                attributesBuilder.method_26868(holder, attributeSupplier.method_26864(holder));
            }
        });
        attributesBuilder.method_26868(attribute, attributeValue);
        FabricDefaultAttributeRegistry.register(entityType, attributesBuilder);
    }
}
