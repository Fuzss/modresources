package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.minecraft.class_11515;
import net.minecraft.class_2248;
import net.minecraft.class_4696;
import java.util.Objects;

public final class BlockRenderTypesContextFabricImpl implements RenderTypesContext<class_2248> {

    @Override
    public void registerChunkRenderType(class_2248 block, class_11515 chunkSectionLayer) {
        Objects.requireNonNull(block, "block is null");
        Objects.requireNonNull(chunkSectionLayer, "chunk section layer is null");
        BlockRenderLayerMap.putBlock(block, chunkSectionLayer);
    }

    @Override
    public class_11515 getChunkRenderType(class_2248 block) {
        Objects.requireNonNull(block, "block is null");
        return class_4696.method_23679(block.method_9564());
    }
}
