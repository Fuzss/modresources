package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import fuzs.puzzleslib.fabric.impl.client.core.context.SkullRenderersContextFabricImpl;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;
import net.minecraft.class_836;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_836.class)
abstract class SkullBlockRendererFabricMixin {

    @ModifyReturnValue(method = "createModel", at = @At("RETURN"))
    private static @Nullable class_5598 createModel(@Nullable class_5598 skullModel, class_5599 modelSet, class_2484.class_2485 type) {
        return skullModel == null ? SkullRenderersContextFabricImpl.createSkullModel(type, modelSet) : skullModel;
    }
}
