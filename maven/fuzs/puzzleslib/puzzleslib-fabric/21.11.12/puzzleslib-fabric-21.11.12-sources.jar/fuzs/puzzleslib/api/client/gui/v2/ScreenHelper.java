package fuzs.puzzleslib.api.client.gui.v2;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import net.minecraft.class_11909;
import net.minecraft.class_1293;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_312;
import net.minecraft.class_329;

/**
 * A {@link net.minecraft.class_437} related helper class.
 */
public final class ScreenHelper {

    private ScreenHelper() {
        // NO-OP
    }

    /**
     * Get the current partial tick time; respecting whether the game is paused.
     *
     * @return the current partial tick time
     */
    public static float getPartialTick() {
        return class_310.method_1551().method_61966().method_60637(false);
    }

    /**
     * @return the current mouse x-position
     */
    public static int getMouseX() {
        class_310 minecraft = class_310.method_1551();
        return (int) (minecraft.field_1729.method_1603() * minecraft.method_22683().method_4486() / minecraft.method_22683()
                .method_4480());
    }

    /**
     * @return the current mouse y-position
     */
    public static int getMouseY() {
        class_310 minecraft = class_310.method_1551();
        return (int) (minecraft.field_1729.method_1604() * minecraft.method_22683().method_4502() / minecraft.method_22683()
                .method_4507());
    }

    /**
     * @param mouseButtonEvent the mouse button event
     * @return is this a double click
     */
    public static boolean isDoubleClick(class_11909 mouseButtonEvent) {
        class_312 mouseHandler = class_310.method_1551().field_1729;
        if (mouseHandler.field_64192 == null) {
            return false;
        } else if (mouseHandler.field_64192.comp_5178() != class_310.method_1551().field_1755) {
            return false;
        } else if (mouseHandler.field_61507 != mouseButtonEvent.method_74245()) {
            return false;
        } else if (class_156.method_658() - mouseHandler.field_64192.comp_5177() >= 250L) {
            return false;
        } else {
            return true;
        }
    }

    /**
     * Checks if the mouse cursor is hovering in a defined region.
     *
     * @param posX   the x-start of the hover area
     * @param posY   the y-start of the hover area
     * @param width  the width from x-start of the hover area
     * @param height the height from y-start of the hover area
     * @param mouseX the mouse x-position
     * @param mouseY the mouse y-position
     * @return is the mouse cursor hovering the defined region
     */
    public static boolean isHovering(int posX, int posY, int width, int height, double mouseX, double mouseY) {
        return mouseX >= posX && mouseX < posX + width && mouseY >= posY && mouseY < posY + height;
    }

    /**
     * Returns the current render height for status bars on the left side drawn as part of the gui.
     * <p>
     * In vanilla this includes player health and armor level.
     *
     * @param identifier the height provider location
     * @return the status bar render height
     */
    public static int getLeftStatusBarHeight(class_2960 identifier) {
        return ClientProxyImpl.get().getLeftStatusBarHeight(identifier);
    }

    /**
     * Returns the current render height for status bars on the right side drawn as part of the gui.
     * <p>
     * In vanilla this includes player food level, vehicle health and air bubbles.
     *
     * @param identifier the height provider location
     * @return the status bar render height
     */
    public static int getRightStatusBarHeight(class_2960 identifier) {
        return ClientProxyImpl.get().getRightStatusBarHeight(identifier);
    }

    /**
     * Can a mob effect render in the player inventory via
     * {@link net.minecraft.class_485}.
     *
     * @param mobEffect the mob effect
     * @return is rendering permitted
     */
    public static boolean isEffectVisibleInInventory(class_1293 mobEffect) {
        return ClientProxyImpl.get().isEffectVisibleInInventory(mobEffect);
    }

    /**
     * Can a mob effect render in the {@link class_329}.
     *
     * @param mobEffect the mob effect
     * @return is rendering permitted
     */
    public static boolean isEffectVisibleInGui(class_1293 mobEffect) {
        return ClientProxyImpl.get().isEffectVisibleInGui(mobEffect);
    }
}
