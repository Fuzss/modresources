package fuzs.puzzleslib.api.biome.v1;

import com.google.common.collect.ImmutableSet;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Set;
import java.util.function.BiPredicate;
import java.util.stream.Stream;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;
import net.minecraft.class_6010;

/**
 * The modification context for the biomes spawn settings.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically
 * <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext$SpawnSettingsContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification
 * system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
public interface MobSpawnSettingsContext {

    /**
     * Associated JSON property: <code>spawners</code>.
     *
     * @see class_5483#method_31004(class_1311)
     * @see class_5483.class_5496#method_31011(class_1311, int, class_5483.class_1964)
     */
    void addSpawn(class_1311 mobCategory, int weight, class_5483.class_1964 spawnerData);

    /**
     * Removes any spawns matching the given predicate from this biome, and returns true if any matched.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     */
    boolean removeSpawns(BiPredicate<class_1311, class_5483.class_1964> filter);

    /**
     * Removes all spawns of the given entity type.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     *
     * @return True if any spawns were removed.
     */
    default boolean removeSpawnsOfEntityType(class_1299<?> entityType) {
        return this.removeSpawns((class_1311 mobCategory, class_5483.class_1964 spawnerData) -> {
            return spawnerData.comp_3488() == entityType;
        });
    }

    /**
     * Removes all spawns of the given spawn group.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     */
    default void clearSpawns(class_1311 mobCategory) {
        this.removeSpawns((class_1311 mobCategoryX, class_5483.class_1964 spawnerData) -> {
            return mobCategoryX == mobCategory;
        });
    }

    /**
     * Removes all spawns.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     */
    default void clearSpawns() {
        this.removeSpawns((class_1311 mobCategory, class_5483.class_1964 spawnerData) -> {
            return true;
        });
    }

    /**
     * Associated JSON property: <code>spawn_costs</code>.
     *
     * @param entityType   the entity type
     * @param energyBudget a tolerance level for how close other spawns can happen nearby, like an aura; the higher this
     *                     value is the closer mobs can spawn together, usually <code>0.15</code> in vanilla
     * @param charge       the strength of a spawn aura, defines how far away other spawn attempts are affected,
     *                     usually
     *                     <code>0.7</code> in vanilla
     * @see class_5483#method_31003(class_1299)
     * @see class_5483.class_5496#method_31009(class_1299, double, double)
     * @see <a
     *         href="https://www.reddit.com/r/minecraft_configs/comments/idmyyr/so_how_does_spawn_costs_actuallywork/">Reddit:
     *         So how does spawn_costs actually...work?</a>
     */
    void setSpawnCost(class_1299<?> entityType, double energyBudget, double charge);

    /**
     * Removes a spawn cost entry for a given entity type.
     *
     * <p>Associated JSON property: <code>spawn_costs</code>.
     */
    boolean clearSpawnCost(class_1299<?> entityType);

    /**
     * @return all {@link class_1311}s that have any spawns registered for them
     */
    default Set<class_1311> getMobCategoriesWithSpawns() {
        return Stream.of(class_1311.values())
                .filter((class_1311 mobCategory) -> !this.getSpawnerData(mobCategory).isEmpty())
                .collect(ImmutableSet.toImmutableSet());
    }

    /**
     * @param mobCategory mob category
     * @return all {@link net.minecraft.class_5483.class_1964} registered for the given
     *         <code>type</code>
     */
    List<class_6010<class_5483.class_1964>> getSpawnerData(class_1311 mobCategory);

    /**
     * @return all {@link class_1299}s with a registered spawn cost
     */
    Set<class_1299<?>> getEntityTypesWithSpawnCost();

    /**
     * @param entityType entity type
     * @return the {@link net.minecraft.class_5483.class_5265} for the given
     *         <code>type</code>
     */
    class_5483.@Nullable class_5265 getSpawnCost(class_1299<?> entityType);

    /**
     * Associated JSON property: <code>creature_spawn_probability</code>.
     *
     * @see class_5483#method_31002()
     * @see class_5483.class_5496#method_31008(float)
     */
    float getCreatureGenerationProbability();

    /**
     * Associated JSON property: <code>creature_spawn_probability</code>.
     *
     * @see class_5483#method_31002()
     * @see class_5483.class_5496#method_31008(float)
     */
    void setCreatureGenerationProbability(float probability);
}
