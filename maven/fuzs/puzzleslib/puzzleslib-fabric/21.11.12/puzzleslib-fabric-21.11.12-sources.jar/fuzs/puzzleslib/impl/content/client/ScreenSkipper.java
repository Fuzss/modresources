package fuzs.puzzleslib.impl.content.client;

import com.google.common.base.Preconditions;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import fuzs.puzzleslib.api.client.event.v1.gui.ScreenEvents;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.minecraft.class_11910;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_4069;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5699;

/**
 * Allows for skipping a screen that's just been opened by automatically triggering the press action of a button on that
 * screen.
 */
public final class ScreenSkipper {
    public static final Codec<ScreenSkipper> CODEC = RecordCodecBuilder.create(instance -> instance.group(Codec.STRING.optionalFieldOf(
                            "screen_title_translation_key").forGetter(config -> getOptionalComponent(config.titleComponent)),
                    Codec.STRING.optionalFieldOf("button_translation_key")
                            .forGetter(config -> getOptionalComponent(config.buttonComponent)),
                    Codec.STRING.optionalFieldOf("last_screen_title_translation_key")
                            .forGetter(config -> getOptionalComponent(config.lastTitleComponent)),
                    class_5699.field_33442.optionalFieldOf("skip_buttons")
                            .forGetter(config -> config.skipButtons > 0 ? Optional.of(config.skipButtons) : Optional.empty()),
                    Codec.BOOL.optionalFieldOf("single_trigger")
                            .forGetter(config -> config.singleTrigger ? Optional.of(config.singleTrigger) : Optional.empty()))
            .apply(instance, ScreenSkipper::new));

    static Optional<String> getOptionalComponent(@Nullable class_2561 component) {
        if (component != null && component.method_10851() instanceof class_2588 contents) {
            return Optional.of(contents.method_11022());
        } else {
            return Optional.empty();
        }
    }

    @Nullable private final class_2561 titleComponent;
    @Nullable private final class_2561 buttonComponent;
    @Nullable private final class_2561 lastTitleComponent;
    private final int skipButtons;
    private final boolean singleTrigger;
    private EventResult trigger;

    private ScreenSkipper(Optional<String> titleComponent, Optional<String> buttonComponent, Optional<String> lastTitleComponent, Optional<Integer> skipButtons, Optional<Boolean> singleTrigger) {
        this(titleComponent.map(class_2561::method_43471).orElse(null),
                buttonComponent.map(class_2561::method_43471).orElse(null),
                lastTitleComponent.map(class_2561::method_43471).orElse(null),
                skipButtons.orElse(0),
                singleTrigger.orElse(false));
    }

    private ScreenSkipper() {
        this(null, null, null, 0, false);
    }

    private ScreenSkipper(@Nullable class_2561 titleComponent, @Nullable class_2561 buttonComponent, @Nullable class_2561 lastTitleComponent, int skipButtons, boolean singleTrigger) {
        this.titleComponent = titleComponent;
        this.buttonComponent = buttonComponent;
        this.lastTitleComponent = lastTitleComponent;
        this.skipButtons = skipButtons;
        this.singleTrigger = singleTrigger;
    }

    /**
     * @return the builder instance
     */
    public static ScreenSkipper create() {
        return new ScreenSkipper();
    }

    /**
     * @param titleKey the screen title translation key
     * @return the builder instance
     */
    public ScreenSkipper setTitleComponent(String titleKey) {
        return this.setTitleComponent(class_2561.method_43471(titleKey));
    }

    /**
     * @param titleComponent the screen title component
     * @return the builder instance
     */
    public ScreenSkipper setTitleComponent(class_2561 titleComponent) {
        return new ScreenSkipper(titleComponent,
                this.buttonComponent,
                this.lastTitleComponent,
                this.skipButtons,
                this.singleTrigger);
    }

    /**
     * @param buttonKey the button translation key
     * @return the builder instance
     */
    public ScreenSkipper setButtonComponent(String buttonKey) {
        return this.setButtonComponent(class_2561.method_43471(buttonKey));
    }

    /**
     * @param buttonComponent the button component
     * @return the builder instance
     */
    public ScreenSkipper setButtonComponent(class_2561 buttonComponent) {
        return new ScreenSkipper(this.titleComponent,
                buttonComponent,
                this.lastTitleComponent,
                this.skipButtons,
                this.singleTrigger);
    }

    /**
     * @param lastTitleKey the last screen title translation key
     * @return the builder instance
     */
    public ScreenSkipper setLastTitleComponent(String lastTitleKey) {
        return this.setLastTitleComponent(class_2561.method_43471(lastTitleKey));
    }

    /**
     * @param lastTitleComponent the last screen title component
     * @return the builder instance
     */
    public ScreenSkipper setLastTitleComponent(class_2561 lastTitleComponent) {
        return new ScreenSkipper(this.titleComponent,
                this.buttonComponent,
                lastTitleComponent,
                this.skipButtons,
                this.singleTrigger);
    }

    /**
     * Define matching buttons to skip, allows for specifying buttons that cannot be targeted via their component.
     *
     * @param skipButtons the buttons to skip
     * @return the builder instance
     */
    public ScreenSkipper setSkipButtons(int skipButtons) {
        return new ScreenSkipper(this.titleComponent,
                this.buttonComponent,
                this.lastTitleComponent,
                skipButtons,
                this.singleTrigger);
    }

    /**
     * Allow the implementation to only trigger once. Useful for screens shown during start-up.
     *
     * @return the builder instance
     */
    public ScreenSkipper setSingleTrigger() {
        return new ScreenSkipper(this.titleComponent,
                this.buttonComponent,
                this.lastTitleComponent,
                this.skipButtons,
                true);
    }

    /**
     * Complete the builder by registering the implementation.
     */
    public void build() {
        Preconditions.checkState(this.titleComponent != null || this.lastTitleComponent != null,
                "screen not specified");
        this.setTriggerProperty(false);
        ScreenEvents.afterInit(class_437.class).register(this::onAfterInit);
        if (this.lastTitleComponent != null) {
            ScreenEvents.remove(class_437.class).register((class_437 screen) -> {
                if (this.trigger == EventResult.PASS && screen.method_25440().equals(this.lastTitleComponent)) {
                    this.trigger = EventResult.ALLOW;
                }
            });
        }
    }

    private void setTriggerProperty(boolean triggered) {
        if (triggered && this.singleTrigger) {
            this.trigger = EventResult.DENY;
        } else {
            this.trigger = this.lastTitleComponent != null ? EventResult.PASS : EventResult.ALLOW;
        }
    }

    private void onAfterInit(class_310 minecraft, class_437 screen, int screenWidth, int screenHeight, List<class_339> widgets, UnaryOperator<class_339> addWidget, Consumer<class_339> removeWidget) {
        if (this.trigger == EventResult.ALLOW && (this.titleComponent == null || screen.method_25440()
                .equals(this.titleComponent))) {
            this.iterateAllWidgets(widgets, this.skipButtons);
        }
    }

    private void iterateAllWidgets(List<? extends class_364> widgets, int skipButtons) {
        for (class_364 guiEventListener : widgets) {
            if (guiEventListener instanceof class_4185 button) {
                if (this.buttonComponent == null || button.method_25369().equals(this.buttonComponent)) {
                    if (skipButtons-- <= 0) {
                        button.method_25306(new class_11910(class_3675.field_32000, 0));
                        this.setTriggerProperty(true);
                        break;
                    }
                }
            } else if (guiEventListener instanceof class_4069 containerEventHandler) {
                this.iterateAllWidgets(containerEventHandler.method_25396(), skipButtons);
            }
        }
    }
}
