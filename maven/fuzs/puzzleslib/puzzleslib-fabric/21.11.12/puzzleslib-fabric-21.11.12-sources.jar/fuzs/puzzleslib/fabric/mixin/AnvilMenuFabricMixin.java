package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import net.minecraft.class_1661;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import net.minecraft.class_3914;
import net.minecraft.class_3915;
import net.minecraft.class_3917;
import net.minecraft.class_4861;
import net.minecraft.class_8047;
import net.minecraft.world.inventory.*;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1706.class)
abstract class AnvilMenuFabricMixin extends class_4861 {
    @Shadow
    private int repairItemCountCost;
    @Shadow
    private String itemName;
    @Shadow
    @Final
    private class_3915 cost;

    public AnvilMenuFabricMixin(@Nullable class_3917<?> menuType, int i, class_1661 inventory, class_3914 containerLevelAccess, class_8047 itemCombinerMenuSlotDefinition) {
        super(menuType, i, inventory, containerLevelAccess, itemCombinerMenuSlotDefinition);
    }

    @Inject(method = "createResult", at = @At("RETURN"))
    public void createResult(CallbackInfo callback) {
        class_1799 primaryItemStack = this.field_22480.method_5438(0);
        class_1799 secondaryItemStack = this.field_22480.method_5438(1);
        MutableValue<class_1799> outputItemStack = MutableValue.fromEvent((class_1799 itemStack) -> this.field_22479.method_5447(
                0,
                itemStack), () -> this.field_22479.method_5438(0));
        MutableInt enchantmentLevelCost = MutableInt.fromEvent(this.cost::method_17404, this.cost::method_17407);
        MutableInt repairMaterialCost = MutableInt.fromEvent((int i) -> this.repairItemCountCost = i,
                () -> this.repairItemCountCost);
        EventResult eventResult = FabricPlayerEvents.CREATE_ANVIL_RESULT.invoker()
                .onCreateAnvilResult(this.field_22482,
                        primaryItemStack,
                        secondaryItemStack,
                        outputItemStack,
                        this.itemName,
                        enchantmentLevelCost,
                        repairMaterialCost);
        if (eventResult.isInterrupt()) {
            outputItemStack.accept(class_1799.field_8037);
            enchantmentLevelCost.accept(0);
            repairMaterialCost.accept(0);
        }
    }
}
