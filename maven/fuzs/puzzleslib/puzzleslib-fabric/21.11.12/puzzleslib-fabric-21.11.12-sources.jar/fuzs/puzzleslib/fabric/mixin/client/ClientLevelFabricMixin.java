package fuzs.puzzleslib.fabric.mixin.client;

import com.google.common.base.Preconditions;
import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Cancellable;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientEntityEvents;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientLevelEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricEntityEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2874;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_761;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(class_638.class)
abstract class ClientLevelFabricMixin extends class_1937 {

    protected ClientLevelFabricMixin(class_5269 writableLevelData, class_5321<class_1937> resourceKey, class_5455 registryAccess, class_6880<class_2874> holder, boolean bl, boolean bl2, long l, int i) {
        super(writableLevelData, resourceKey, registryAccess, holder, bl, bl2, l, i);
    }

    @Inject(method = "<init>", at = @At("TAIL"))
    public void init(class_634 clientPacketListener, class_638.class_5271 clientLevelData, class_5321<class_1937> resourceKey, class_6880<class_2874> holder, int i, int j, class_761 levelRenderer, boolean bl, long l, int k, CallbackInfo callback) {
        FabricClientLevelEvents.LOAD_LEVEL.invoker().onLevelLoad(class_310.method_1551(), class_638.class.cast(this));
    }

    @WrapWithCondition(
            method = "tickNonPassenger",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V")
    )
    public boolean tickNonPassenger(class_1297 entity, @Share("isEntityTickCancelled") LocalBooleanRef isEntityTickCancelled) {
        // avoid using @WrapOperation, so we are not blamed for any overhead from running the entity tick
        EventResult eventResult = FabricEntityEvents.ENTITY_TICK_START.invoker().onStartEntityTick(entity);
        isEntityTickCancelled.set(eventResult.isInterrupt());
        return eventResult.isPass();
    }

    @Inject(
            method = "tickNonPassenger",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;tick()V", shift = At.Shift.AFTER)
    )
    public void tickNonPassenger(class_1297 entity, CallbackInfo callback, @Share("isEntityTickCancelled") LocalBooleanRef isEntityTickCancelled) {
        if (!isEntityTickCancelled.get()) {
            FabricEntityEvents.ENTITY_TICK_END.invoker().onEndEntityTick(entity);
        }
    }

    @Inject(method = "addEntity", at = @At("HEAD"), cancellable = true)
    private void addEntity(class_1297 entityToSpawn, CallbackInfo callback) {
        if (FabricClientEntityEvents.ENTITY_LOAD.invoker()
                .onEntityLoad(entityToSpawn, class_638.class.cast(this))
                .isInterrupt()) {
            if (entityToSpawn instanceof class_1657) {
                // we do not support players as it isn't as straight-forward to implement for the server event on Fabric
                throw new UnsupportedOperationException("Cannot prevent player from spawning in!");
            } else {
                callback.cancel();
            }
        }
    }

    @ModifyArgs(
            method = "playSeededSound(Lnet/minecraft/world/entity/Entity;DDDLnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/multiplayer/ClientLevel;playSound(DDDLnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FFZJ)V"
            )
    )
    public void playSeededSound$0(Args args, @Cancellable CallbackInfo callback) {
        Preconditions.checkArgument(args.get(3) instanceof class_3414, "sound event is wrong type");
        EventResult eventResult = FabricEventImplHelper.onPlaySound((MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch) -> {
                    return FabricLevelEvents.PLAY_SOUND_AT_POSITION.invoker()
                            .onPlaySoundAtPosition(this,
                                    new class_243(args.get(0), args.get(1), args.get(2)),
                                    soundEvent,
                                    soundSource,
                                    soundVolume,
                                    soundPitch);
                },
                args,
                MutableValue.fromEvent((class_6880<class_3414> holder) -> args.set(3, holder.comp_349()),
                        () -> class_7923.field_41172.method_47983(args.get(3))),
                4,
                5,
                6);
        if (eventResult.isInterrupt()) callback.cancel();
    }

    @ModifyArgs(
            method = "playSeededSound(Lnet/minecraft/world/entity/Entity;Lnet/minecraft/world/entity/Entity;Lnet/minecraft/core/Holder;Lnet/minecraft/sounds/SoundSource;FFJ)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/resources/sounds/EntityBoundSoundInstance;<init>(Lnet/minecraft/sounds/SoundEvent;Lnet/minecraft/sounds/SoundSource;FFLnet/minecraft/world/entity/Entity;J)V"
            )
    )
    public void playSeededSound$1(Args args, @Cancellable CallbackInfo callback) {
        Preconditions.checkArgument(args.get(0) instanceof class_3414, "sound event is wrong type");
        EventResult eventResult = FabricEventImplHelper.onPlaySound((MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch) -> {
                    return FabricLevelEvents.PLAY_SOUND_AT_ENTITY.invoker()
                            .onPlaySoundAtEntity(this, args.get(4), soundEvent, soundSource, soundVolume, soundPitch);
                },
                args,
                MutableValue.fromEvent((class_6880<class_3414> holder) -> args.set(0, holder.comp_349()),
                        () -> class_7923.field_41172.method_47983(args.get(0))),
                1,
                2,
                3);
        if (eventResult.isInterrupt()) callback.cancel();
    }
}
