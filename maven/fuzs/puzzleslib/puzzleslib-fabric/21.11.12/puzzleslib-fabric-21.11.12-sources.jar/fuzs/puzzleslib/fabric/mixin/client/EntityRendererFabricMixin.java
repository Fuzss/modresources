package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_897.class)
abstract class EntityRendererFabricMixin<T extends class_1297, S extends class_10017> {

    @WrapWithCondition(method = "submit",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/entity/EntityRenderer;submitNameTag(Lnet/minecraft/client/renderer/entity/state/EntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V"))
    protected boolean submit(class_897<T, S> entityRenderer, S renderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        return FabricRendererEvents.SUBMIT_NAME_TAG.invoker()
                .onSubmitNameTag(entityRenderer, renderState, poseStack, submitNodeCollector, cameraRenderState)
                .isPass();
    }

    @Inject(method = "createRenderState(Lnet/minecraft/world/entity/Entity;F)Lnet/minecraft/client/renderer/entity/state/EntityRenderState;",
            at = @At("RETURN"))
    public void createRenderState(T entity, float partialTick, CallbackInfoReturnable<S> callback) {
        FabricRendererEvents.EXTRACT_RENDER_STATE.invoker()
                .onExtractRenderState(entity, callback.getReturnValue(), partialTick);
    }
}
