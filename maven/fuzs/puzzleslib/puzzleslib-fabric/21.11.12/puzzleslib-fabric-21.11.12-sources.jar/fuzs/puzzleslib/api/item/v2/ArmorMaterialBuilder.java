package fuzs.puzzleslib.api.item.v2;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_10191;
import net.minecraft.class_10394;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_8051;

/**
 * A builder class for {@link class_1741}.
 */
public final class ArmorMaterialBuilder {
    private static final class_2960 NO_RENDER_ASSET_ID = PuzzlesLibMod.id("no_render");

    private int durability;
    private Map<class_8051, Integer> defense = class_156.method_654(new EnumMap<>(class_8051.class),
            (EnumMap<class_8051, Integer> map) -> {
                for (class_8051 armorType : class_8051.values()) {
                    map.put(armorType, 0);
                }
            });
    private int enchantmentValue = 1;
    private class_6880<class_3414> equipSound = class_3417.field_14883;
    private float toughness;
    private float knockbackResistance;
    private class_6862<class_1792> repairIngredient;
    private class_5321<class_10394> assetId;

    private ArmorMaterialBuilder() {
        // NO-OP
    }

    /**
     * @param repairIngredient the repair material used in an anvil for restoring item durability
     * @return the builder
     */
    public static ArmorMaterialBuilder of(class_6862<class_1792> repairIngredient) {
        return new ArmorMaterialBuilder().setRepairIngredient(repairIngredient);
    }

    /**
     * @param assetId          the location for the equipment model definition file at
     *                         {@code assets/<namespace>/equipment/<path>.json}
     * @param repairIngredient the repair material used in an anvil for restoring item durability
     * @return the builder
     */
    public static ArmorMaterialBuilder of(class_2960 assetId, class_6862<class_1792> repairIngredient) {
        return new ArmorMaterialBuilder().setRepairIngredient(repairIngredient).setAssetId(assetId);
    }

    /**
     * @param armorMaterial the armor material
     * @return the builder
     */
    public static ArmorMaterialBuilder copyOf(class_1741 armorMaterial) {
        return new ArmorMaterialBuilder().setRepairIngredient(armorMaterial.comp_2301())
                .setAssetId(armorMaterial.comp_3168())
                .setDurability(armorMaterial.comp_3166())
                .setDefense(armorMaterial.comp_2298())
                .setEnchantmentValue(armorMaterial.comp_3167())
                .setEquipSound(armorMaterial.comp_2300())
                .setToughness(armorMaterial.comp_2303())
                .setKnockbackResistance(armorMaterial.comp_2304());
    }

    /**
     * @param durability multiplier for internal base durability per slot type
     * @return the builder
     */
    public ArmorMaterialBuilder setDurability(int durability) {
        this.durability = durability;
        return this;
    }

    /**
     * @param defense the defense value for this armor set
     * @return the builder
     */
    public ArmorMaterialBuilder setDefense(int defense) {
        return this.setDefense(defense, defense, defense, defense, defense);
    }

    /**
     * @param boots      the boots defense value
     * @param leggings   the leggings defense value
     * @param chestplate the chestplate defense value
     * @param helmet     the helmet defense value
     * @return the builder
     */
    public ArmorMaterialBuilder setDefense(int boots, int leggings, int chestplate, int helmet) {
        return this.setDefense(boots, leggings, chestplate, helmet, 0);
    }

    /**
     * @param boots      the boots defense value
     * @param leggings   the leggings defense value
     * @param chestplate the chestplate defense value
     * @param helmet     the helmet defense value
     * @param body       the body defense value
     * @return the builder
     */
    public ArmorMaterialBuilder setDefense(int boots, int leggings, int chestplate, int helmet, int body) {
        return this.setDefense(class_8051.field_41937, boots)
                .setDefense(class_8051.field_41936, leggings)
                .setDefense(class_8051.field_41935, chestplate)
                .setDefense(class_8051.field_41934, helmet)
                .setDefense(class_8051.field_48838, body);
    }

    /**
     * @param armorType the armor type
     * @param defense   the defense value
     * @return the builder
     */
    public ArmorMaterialBuilder setDefense(class_8051 armorType, int defense) {
        this.defense.put(armorType, defense);
        return this;
    }

    private ArmorMaterialBuilder setDefense(Map<class_8051, Integer> defense) {
        this.defense = defense;
        return this;
    }

    /**
     * @param enchantmentValue the item enchantment value
     * @return the builder
     */
    public ArmorMaterialBuilder setEnchantmentValue(int enchantmentValue) {
        this.enchantmentValue = enchantmentValue;
        return this;
    }

    /**
     * @param equipSound the sound played when putting a piece of armor in the correct equipment slot
     * @return the builder
     */
    public ArmorMaterialBuilder setEquipSound(class_6880<class_3414> equipSound) {
        Objects.requireNonNull(equipSound, "equip sound is null");
        this.equipSound = equipSound;
        return this;
    }

    /**
     * @param toughness the armor toughness value for this armor set
     * @return the builder
     */
    public ArmorMaterialBuilder setToughness(float toughness) {
        this.toughness = toughness;
        return this;
    }

    /**
     * @param knockbackResistance the knockback resistance value for this armor set
     * @return the builder
     */
    public ArmorMaterialBuilder setKnockbackResistance(float knockbackResistance) {
        this.knockbackResistance = knockbackResistance;
        return this;
    }

    /**
     * @param repairIngredient the repair material used in an anvil for restoring item durability
     * @return the builder
     */
    public ArmorMaterialBuilder setRepairIngredient(class_6862<class_1792> repairIngredient) {
        Objects.requireNonNull(repairIngredient, "repair ingredient is null");
        this.repairIngredient = repairIngredient;
        return this;
    }

    /**
     * @param assetId the location for the equipment model definition file at
     *                {@code assets/<namespace>/equipment/<path>.json}
     * @return the builder
     */
    public ArmorMaterialBuilder setAssetId(class_2960 assetId) {
        Objects.requireNonNull(assetId, "asset id is null");
        return this.setAssetId(class_5321.method_29179(class_10191.field_55214, assetId));
    }

    /**
     * @param assetId the location for the equipment model definition file at
     *                {@code assets/<namespace>/equipment/<path>.json}
     * @return the builder
     */
    public ArmorMaterialBuilder setAssetId(class_5321<class_10394> assetId) {
        Objects.requireNonNull(assetId, "asset id is null");
        this.assetId = assetId;
        return this;
    }

    /**
     * Prevent the armor set from rendering by setting an invalid equipment model definition.
     *
     * @return the builder
     */
    public ArmorMaterialBuilder setNoAssetId() {
        return this.setAssetId(NO_RENDER_ASSET_ID);
    }

    /**
     * @return the armor material
     */
    public class_1741 build() {
        Objects.requireNonNull(this.defense, "defense map is null");
        Objects.requireNonNull(this.equipSound, "equip sound is null");
        Objects.requireNonNull(this.repairIngredient, "repair ingredient is null");
        Objects.requireNonNull(this.assetId, "asset id is null");
        return new class_1741(this.durability,
                Maps.immutableEnumMap(this.defense),
                this.enchantmentValue,
                this.equipSound,
                this.toughness,
                this.knockbackResistance,
                this.repairIngredient,
                this.assetId);
    }
}
