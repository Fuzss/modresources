package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import net.minecraft.class_10042;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_897;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_922.class)
abstract class LivingEntityRendererFabricMixin<T extends class_1309, S extends class_10042, M extends class_583<? super S>> extends class_897<T, S> {

    protected LivingEntityRendererFabricMixin(class_5617.class_5618 context) {
        super(context);
    }

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At("HEAD"),
            cancellable = true)
    public void render$0(S livingEntityRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo callback) {
        EventResult result = FabricRendererEvents.BEFORE_SUBMIT_LIVING_ENTITY.invoker()
                .onBeforeSubmitLivingEntity(livingEntityRenderState,
                        class_922.class.cast(this), poseStack,
                        submitNodeCollector);
        if (result.isInterrupt()) {
            callback.cancel();
        }
    }

    @Inject(method = "submit(Lnet/minecraft/client/renderer/entity/state/LivingEntityRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/CameraRenderState;)V",
            at = @At("TAIL"))
    public void render$1(S livingEntityRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState, CallbackInfo callback) {
        FabricRendererEvents.AFTER_SUBMIT_LIVING_ENTITY.invoker()
                .onAfterSubmitLivingEntity(livingEntityRenderState,
                        class_922.class.cast(this), poseStack,
                        submitNodeCollector);
    }
}
