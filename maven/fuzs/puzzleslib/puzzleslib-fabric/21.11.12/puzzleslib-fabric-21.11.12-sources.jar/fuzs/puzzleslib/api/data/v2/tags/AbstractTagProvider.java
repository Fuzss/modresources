package fuzs.puzzleslib.api.data.v2.tags;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.api.init.v3.tags.TagFactory;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import fuzs.puzzleslib.impl.data.SortingTagBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3483;
import net.minecraft.class_3489;
import net.minecraft.class_3495;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.tags.*;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

public abstract class AbstractTagProvider<T> extends class_2474<T> {
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_2248>> VARIANT_BLOCK_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_2248>>builder()
            .put(BlockSetVariant.BUTTON, class_3481.field_15493)
            .put(BlockSetVariant.DOOR, class_3481.field_15495)
            .put(BlockSetVariant.FENCE, class_3481.field_16584)
            .put(BlockSetVariant.FENCE_GATE, class_3481.field_25147)
            .put(BlockSetVariant.SIGN, class_3481.field_15472)
            .put(BlockSetVariant.SLAB, class_3481.field_15469)
            .put(BlockSetVariant.STAIRS, class_3481.field_15459)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3481.field_24076)
            .put(BlockSetVariant.TRAPDOOR, class_3481.field_15487)
            .put(BlockSetVariant.WALL, class_3481.field_15504)
            .put(BlockSetVariant.WALL_SIGN, class_3481.field_15492)
            .put(BlockSetVariant.HANGING_SIGN, class_3481.field_40103)
            .put(BlockSetVariant.WALL_HANGING_SIGN, class_3481.field_40104)
            .build();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_2248>> VARIANT_STONE_BLOCK_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_2248>>builder()
            .putAll(VARIANT_BLOCK_TAGS)
            .put(BlockSetVariant.BUTTON, class_3481.field_44590)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3481.field_24077)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_2248>> VARIANT_WOODEN_BLOCK_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_2248>>builder()
            .putAll(VARIANT_BLOCK_TAGS)
            .put(BlockSetVariant.BUTTON, class_3481.field_15499)
            .put(BlockSetVariant.DOOR, class_3481.field_15494)
            .put(BlockSetVariant.FENCE, class_3481.field_17619)
            .put(BlockSetVariant.SLAB, class_3481.field_15468)
            .put(BlockSetVariant.STAIRS, class_3481.field_15502)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3481.field_15477)
            .put(BlockSetVariant.TRAPDOOR, class_3481.field_15491)
            .put(BlockSetVariant.SHELF, class_3481.field_61211)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1792>> VARIANT_ITEM_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1792>>builder()
            .put(BlockSetVariant.BUTTON, class_3489.field_15551)
            .put(BlockSetVariant.DOOR, class_3489.field_15553)
            .put(BlockSetVariant.FENCE, class_3489.field_16585)
            .put(BlockSetVariant.FENCE_GATE, class_3489.field_40858)
            .put(BlockSetVariant.SLAB, class_3489.field_15535)
            .put(BlockSetVariant.STAIRS, class_3489.field_15526)
            .put(BlockSetVariant.TRAPDOOR, class_3489.field_15548)
            .put(BlockSetVariant.WALL, class_3489.field_15560)
            .put(BlockSetVariant.SIGN, class_3489.field_15533)
            .put(BlockSetVariant.HANGING_SIGN, class_3489.field_40108)
            .put(BlockSetVariant.BOAT, class_3489.field_15536)
            .put(BlockSetVariant.CHEST_BOAT, class_3489.field_38080)
            .build();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1792>> VARIANT_STONE_ITEM_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1792>>builder()
            .putAll(VARIANT_ITEM_TAGS)
            .put(BlockSetVariant.BUTTON, class_3489.field_44592)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1792>> VARIANT_WOODEN_ITEM_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1792>>builder()
            .putAll(VARIANT_ITEM_TAGS)
            .put(BlockSetVariant.BUTTON, class_3489.field_15555)
            .put(BlockSetVariant.DOOR, class_3489.field_15552)
            .put(BlockSetVariant.FENCE, class_3489.field_17620)
            .put(BlockSetVariant.SLAB, class_3489.field_15534)
            .put(BlockSetVariant.STAIRS, class_3489.field_15557)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3489.field_15540)
            .put(BlockSetVariant.TRAPDOOR, class_3489.field_15550)
            .put(BlockSetVariant.SHELF, class_3489.field_61218)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1299<?>>> VARIANT_ENTITY_TYPE_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1299<?>>>builder()
            .put(BlockSetVariant.BOAT, class_3483.field_54404)
            .put(BlockSetVariant.CHEST_BOAT, TagFactory.COMMON.registerEntityTypeTag("boats"))
            .build();

    protected final String modId;

    public AbstractTagProvider(class_5321<? extends class_2378<T>> registryKey, DataProviderContext context) {
        this(registryKey, context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractTagProvider(class_5321<? extends class_2378<T>> registryKey, String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
        super(packOutput, registryKey, registries);
        this.modId = modId;
    }

    @Override
    public abstract void method_10514(class_7225.class_7874 registries);

    @Override
    protected class_3495 method_27169(class_6862<T> tagKey) {
        // use our own tag builder implementation
        return this.field_11481.computeIfAbsent(tagKey.comp_327(), (class_2960 identifier) -> new SortingTagBuilder());
    }

    public AbstractTagAppender<T> tag(String string) {
        return this.tag(class_2960.method_60654(string));
    }

    public AbstractTagAppender<T> tag(class_2960 identifier) {
        return this.tag(class_6862.method_40092(this.field_40957, identifier));
    }

    public AbstractTagAppender<T> tag(class_6862<T> tagKey) {
        return createTagAppender(this.method_27169(tagKey), this.field_40957);
    }

    public final void generateFor(Map<BlockSetVariant, class_6880.class_6883<T>> variants, Map<BlockSetVariant, class_6862<T>> variantTags) {
        variants.forEach((BlockSetVariant variant, class_6880.class_6883<T> holder) -> {
            class_6862<T> tagKey = variantTags.get(variant);
            if (tagKey != null) {
                this.tag(tagKey).add(holder);
            }
        });
    }

    @ApiStatus.Internal
    public static <T> AbstractTagAppender<T> createTagAppender(class_3495 tagBuilder, class_5321<? extends class_2378<? super T>> registryKey) {
        Optional<class_2378<T>> optional = LookupHelper.getRegistry(registryKey);
        Function<T, class_5321<T>> keyExtractor = optional.isPresent() ?
                (T t) -> optional.flatMap((class_2378<T> registry) -> registry.method_29113(t)).orElseThrow(() -> {
                    return new IllegalStateException("Missing value in " + registryKey + ": " + t);
                }) : null;
        return ProxyImpl.get().getTagAppender(tagBuilder, keyExtractor);
    }
}
