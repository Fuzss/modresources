package fuzs.puzzleslib.fabric.impl.event;

import com.mojang.serialization.Codec;
import fuzs.puzzleslib.api.util.v1.CodecExtras;
import net.minecraft.class_1266;
import net.minecraft.class_1315;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.jspecify.annotations.Nullable;

/**
 * An extension to {@link net.minecraft.class_1308} that stores the {@link class_3730} the mob was
 * initially spawned with when
 * {@link net.minecraft.class_1308#method_5943(class_5425, class_1266, class_3730,
 * class_1315)} was called.
 * <p>
 * The implementation is just like NeoForge, but also allows for setting the spawn type in case e.g.
 * {@link net.minecraft.class_1308#method_5943(class_5425, class_1266, class_3730,
 * class_1315)} was overridden without calling {@code super}.
 */
public interface SpawnReasonMob {
    /**
     * Use {@link Enum#name()} for backward compatibility.
     */
    Codec<class_3730> CODEC = CodecExtras.fromEnumWithMapping(class_3730::values, Enum::name);

    @Nullable class_3730 puzzleslib$getSpawnReason();

    void puzzleslib$setSpawnReason(@Nullable class_3730 entitySpawnReason);
}
