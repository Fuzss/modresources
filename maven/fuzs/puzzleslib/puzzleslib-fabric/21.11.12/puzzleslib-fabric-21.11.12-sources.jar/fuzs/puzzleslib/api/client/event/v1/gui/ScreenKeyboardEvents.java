package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.Objects;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_437;

@SuppressWarnings("unchecked")
public final class ScreenKeyboardEvents {

    private ScreenKeyboardEvents() {
        // NO-OP
    }

    public static <T extends class_437> EventInvoker<BeforeKeyPress<T>> beforeKeyPress(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeKeyPress<T>>) (Class<?>) BeforeKeyPress.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterKeyPress<T>> afterKeyPress(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterKeyPress<T>>) (Class<?>) AfterKeyPress.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeKeyRelease<T>> beforeKeyRelease(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeKeyRelease<T>>) (Class<?>) BeforeKeyRelease.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterKeyRelease<T>> afterKeyRelease(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterKeyRelease<T>>) (Class<?>) AfterKeyRelease.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeCharacterType<T>> beforeCharacterType(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeCharacterType<T>>) (Class<?>) BeforeCharacterType.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterCharacterType<T>> afterCharacterType(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterCharacterType<T>>) (Class<?>) AfterCharacterType.class, screen);
    }

    @FunctionalInterface
    public interface BeforeKeyPress<T extends class_437> {

        /**
         * Called before a key is pressed.
         *
         * @param screen   the currently displayed screen
         * @param keyEvent the key event; for bundled values see {@link net.minecraft.class_3675}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the event as handled, it will not be passed to other listeners and vanilla behaviour will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeKeyPress(T screen, class_11908 keyEvent);
    }

    @FunctionalInterface
    public interface AfterKeyPress<T extends class_437> {

        /**
         * Called after a key is pressed.
         *
         * @param screen   the currently displayed screen
         * @param keyEvent the key event; for bundled values see {@link net.minecraft.class_3675}
         */
        void onAfterKeyPress(T screen, class_11908 keyEvent);
    }

    @FunctionalInterface
    public interface BeforeKeyRelease<T extends class_437> {

        /**
         * Called before a pressed key is released.
         *
         * @param screen   the currently displayed screen
         * @param keyEvent the key event; for bundled values see {@link net.minecraft.class_3675}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the event as handled, it will not be passed to other listeners and vanilla behaviour will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeKeyRelease(T screen, class_11908 keyEvent);
    }

    @FunctionalInterface
    public interface AfterKeyRelease<T extends class_437> {

        /**
         * Called after a pressed key is released.
         *
         * @param screen   the currently displayed screen
         * @param keyEvent the key event; for bundled values see {@link net.minecraft.class_3675}
         */
        void onAfterKeyRelease(T screen, class_11908 keyEvent);
    }

    @FunctionalInterface
    public interface BeforeCharacterType<T extends class_437> {

        /**
         * Called before a character is typed.
         *
         * @param screen         the currently displayed screen
         * @param characterEvent the character event; in particular {@link class_11905#method_74226()}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} for marking the event as handled, it will not be passed to other listeners and vanilla behaviour will not run</li>
         *         <li>{@link EventResult#PASS PASS} for letting other listeners as well as vanilla process this event</li>
         *         </ul>
         */
        EventResult onBeforeCharacterType(T screen, class_11905 characterEvent);
    }

    @FunctionalInterface
    public interface AfterCharacterType<T extends class_437> {

        /**
         * Called after a character is typed.
         *
         * @param screen         the currently displayed screen
         * @param characterEvent the character event; in particular {@link class_11905#method_74226()}
         */
        void onAfterCharacterType(T screen, class_11905 characterEvent);
    }
}
