package fuzs.puzzleslib.api.util.v1;

import net.minecraft.class_1269;
import net.minecraft.class_1799;

/**
 * A helper class for adapting the new {@link class_1269} class from the previous {@code InteractionResult},
 * {@code ItemInteractionResult}, and {@code InteractionResultHolder} implementations.
 */
@Deprecated
public final class InteractionResultHelper {
    /**
     * An abstraction for {@code InteractionResult#SUCCESS}.
     */
    public static final class_1269 SUCCESS = class_1269.field_5812;
    /**
     * An abstraction for {@code InteractionResult#CONSUME}.
     */
    public static final class_1269 CONSUME = class_1269.field_21466;
    /**
     * An abstraction for {@code InteractionResult#PASS}.
     */
    public static final class_1269 PASS = class_1269.field_5811;
    /**
     * An abstraction for {@code InteractionResult#FAIL}.
     */
    public static final class_1269 FAIL = class_1269.field_5814;
    /**
     * An abstraction for {@code ItemInteractionResult#PASS_TO_DEFAULT_BLOCK_INTERACTION}.
     */
    public static final class_1269 PASS_TO_DEFAULT_BLOCK_INTERACTION = class_1269.field_52423;
    /**
     * An abstraction for {@code ItemInteractionResult#SKIP_DEFAULT_BLOCK_INTERACTION}.
     */
    public static final class_1269 SKIP_DEFAULT_BLOCK_INTERACTION = class_1269.field_5811;

    private InteractionResultHelper() {
        // NO-OP
    }

    /**
     * An abstraction for {@code InteractionResult::consumesAction}.
     *
     * @param interactionResult the interaction result
     * @return should any further attempts at an interaction be prevented
     */
    public static boolean consumesAction(class_1269 interactionResult) {
        return interactionResult.method_23665();
    }

    /**
     * An abstraction for {@code InteractionResult::shouldSwing}.
     *
     * @param interactionResult the interaction result
     * @return should the player arm be swung via Player::swing
     */
    public static boolean shouldSwing(class_1269 interactionResult) {
        // there is no need for distinguishing between client and server swing sources
        return interactionResult instanceof class_1269.class_9860 success &&
                success.comp_2909() != class_1269.class_9861.field_52426;
    }

    /**
     * An abstraction for {@code InteractionResult::indicateItemUse}.
     *
     * @param interactionResult the interaction result
     * @return should {@link net.minecraft.class_3468#field_15372} be awarded
     */
    public static boolean indicateItemUse(class_1269 interactionResult) {
        return interactionResult instanceof class_1269.class_9860 success &&
                success.comp_2910().comp_2907();
    }

    /**
     * An abstraction for {@code InteractionResult::sidedSuccess}.
     *
     * @param isClientSide should the interaction trigger an arm swing on the client-side only
     * @return the interaction result
     */
    public static class_1269 sidedSuccess(boolean isClientSide) {
        return class_1269.field_5812;
    }

    /**
     * An abstraction for {@code InteractionResultHolder::getObject}.
     *
     * @param interactionResult the interaction result
     * @return the new held item stack, possibly {@link class_1799#field_8037} if not available
     */
    public static class_1799 getObject(class_1269 interactionResult) {
        return interactionResult instanceof class_1269.class_9860 success &&
                success.method_61396() != null ? success.method_61396() : class_1799.field_8037;
    }

    /**
     * An abstraction for {@code InteractionResultHolder::success}.
     *
     * @param itemStack the item stack resulting from the interaction
     * @return the interaction result
     */
    public static class_1269 success(class_1799 itemStack) {
        return class_1269.field_5812.method_61393(itemStack);
    }

    /**
     * An abstraction for {@code InteractionResultHolder::consume}.
     *
     * @param itemStack the item stack resulting from the interaction
     * @return the interaction result
     */
    public static class_1269 consume(class_1799 itemStack) {
        return class_1269.field_21466;
    }

    /**
     * An abstraction for {@code InteractionResultHolder::pass}.
     *
     * @param itemStack the item stack resulting from the interaction
     * @return the interaction result
     */
    public static class_1269 pass(class_1799 itemStack) {
        return class_1269.field_5811;
    }

    /**
     * An abstraction for {@code InteractionResultHolder::fail}.
     *
     * @param itemStack the item stack resulting from the interaction
     * @return the interaction result
     */
    public static class_1269 fail(class_1799 itemStack) {
        return class_1269.field_5814;
    }

    /**
     * An abstraction for {@code InteractionResultHolder::sidedSuccess}.
     *
     * @param itemStack    the item stack resulting from the interaction
     * @param isClientSide should the interaction trigger an arm swing on the client-side only
     * @return the interaction result
     */
    public static class_1269 sidedSuccess(class_1799 itemStack, boolean isClientSide) {
        return class_1269.field_5812.method_61393(itemStack);
    }
}
