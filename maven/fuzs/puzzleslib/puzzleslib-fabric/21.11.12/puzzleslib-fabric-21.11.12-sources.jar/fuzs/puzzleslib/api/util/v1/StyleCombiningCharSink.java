package fuzs.puzzleslib.api.util.v1;

import org.apache.commons.lang3.mutable.MutableInt;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.BiPredicate;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5223;
import net.minecraft.class_5224;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

public class StyleCombiningCharSink implements class_5224 {
    private final List<Map.Entry<StringBuilder, class_2583>> strings;
    private final class_2583 defaultStyle;
    private int length;

    public StyleCombiningCharSink(class_2583 defaultStyle) {
        this.strings = new ArrayList<>(List.of(Map.entry(new StringBuilder(), class_2583.field_24360)));
        this.defaultStyle = defaultStyle;
    }

    public static StyleCombiningCharSink of(String text, class_2583 defaultStyle) {
        Objects.requireNonNull(text, "text is null");
        return of(class_5348.method_29430(text), defaultStyle);
    }

    public static StyleCombiningCharSink of(class_5348 formattedText, class_2583 defaultStyle) {
        Objects.requireNonNull(formattedText, "formatted text is null");
        StyleCombiningCharSink styleCombiningCharSink = new StyleCombiningCharSink(defaultStyle);
        // Use this to properly convert legacy formatting codes that are part of the string value.
        class_5223.method_27476(formattedText, defaultStyle, styleCombiningCharSink);
        return styleCombiningCharSink;
    }

    public static StyleCombiningCharSink of(class_5481 formattedCharSequence, class_2583 defaultStyle) {
        Objects.requireNonNull(formattedCharSequence, "formatted char sequence is null");
        StyleCombiningCharSink styleCombiningCharSink = new StyleCombiningCharSink(defaultStyle);
        formattedCharSequence.accept(styleCombiningCharSink);
        return of(styleCombiningCharSink.getAsComponent(), defaultStyle);
    }

    public int length() {
        return this.length;
    }

    @Override
    public boolean accept(int position, class_2583 style, int codePoint) {
        Map.Entry<StringBuilder, class_2583> entry = this.strings.getLast();
        StringBuilder stringBuilder;
        if (Objects.equals(entry.getValue(), style)) {
            stringBuilder = entry.getKey();
        } else {
            stringBuilder = new StringBuilder();
            this.strings.add(Map.entry(stringBuilder, style));
        }

        stringBuilder.appendCodePoint(codePoint);
        this.length += Character.charCount(codePoint);
        return true;
    }

    public class_2561 getAsComponent() {
        class_5250 mutableComponent = class_2561.method_43473().method_27696(this.defaultStyle);
        this.iterateForwards((String string, class_2583 style) -> {
            class_2561 component = ComponentHelper.getAsComponent(string, style);
            mutableComponent.method_10852(component);
        });
        return mutableComponent;
    }

    public String getAsString() {
        StringBuilder stringBuilder = new StringBuilder();
        this.iterateForwards((String string, class_2583 style) -> {
            stringBuilder.append(ComponentHelper.getAsString(string, style));
        });
        return ComponentHelper.getAsString(stringBuilder.toString(), this.defaultStyle);
    }

    public void iterateForwards(class_5224 formattedCharSink) {
        MutableInt mutableInt = new MutableInt();
        this.iterate(this.strings, (String string, class_2583 style) -> {
            if (class_5223.method_27474(string, style, (int position, class_2583 currentStyle, int codePoint) -> {
                return formattedCharSink.accept(mutableInt.intValue() + position, currentStyle, codePoint);
            })) {
                mutableInt.add(string.length());
                return true;
            } else {
                return false;
            }
        });
    }

    public void iterateForwards(BiConsumer<String, class_2583> componentConsumer) {
        this.iterate(this.strings, (String string, class_2583 style) -> {
            componentConsumer.accept(string, style);
            return true;
        });
    }

    public void iterateBackwards(class_5224 formattedCharSink) {
        MutableInt mutableInt = new MutableInt(this.length());
        this.iterate(this.strings.reversed(), (String string, class_2583 style) -> {
            mutableInt.subtract(string.length());
            return class_5223.method_27478(string,
                    style,
                    (int position, class_2583 currentStyle, int codePoint) -> {
                        return formattedCharSink.accept(mutableInt.intValue() + position, currentStyle, codePoint);
                    });
        });
    }

    public void iterateBackwards(BiConsumer<String, class_2583> componentConsumer) {
        this.iterate(this.strings.reversed(), (String string, class_2583 style) -> {
            componentConsumer.accept(string, style);
            return true;
        });
    }

    private void iterate(List<Map.Entry<StringBuilder, class_2583>> strings, BiPredicate<String, class_2583> componentConsumer) {
        for (Map.Entry<StringBuilder, class_2583> entry : strings) {
            // The default style is "wrapped" around the whole component / string, so we can safely remove it from individual parts.
            if (!entry.getKey().isEmpty() || !entry.getValue().method_10967() && !Objects.equals(entry.getValue(),
                    this.defaultStyle)) {
                class_2583 style = this.defaultStyle.method_10967() ? ComponentHelper.sanitizeLegacyFormat(entry.getValue()) :
                        entry.getValue();
                if (!componentConsumer.test(entry.getKey().toString(), style)) {
                    break;
                }
            }
        }
    }
}
