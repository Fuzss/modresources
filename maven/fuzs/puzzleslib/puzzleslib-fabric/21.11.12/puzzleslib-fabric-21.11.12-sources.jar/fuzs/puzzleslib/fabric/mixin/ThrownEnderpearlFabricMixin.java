package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricEntityEvents;
import fuzs.puzzleslib.impl.event.data.DefaultedFloat;
import net.minecraft.class_1299;
import net.minecraft.class_1684;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_3222;
import net.minecraft.class_3857;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(class_1684.class)
abstract class ThrownEnderpearlFabricMixin extends class_3857 {

    public ThrownEnderpearlFabricMixin(class_1299<? extends class_3857> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyExpressionValue(method = "onHit",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/server/network/ServerGamePacketListenerImpl;isAcceptingMessages()Z"))
    protected boolean onHit(boolean isAcceptingMessages, class_239 hitResult, @Share("damageAmount") LocalRef<DefaultedFloat> damageAmountRef) {
        if (isAcceptingMessages && this.method_24921() instanceof class_3222 serverPlayer) {
            damageAmountRef.set(DefaultedFloat.fromValue(5.0F));
            EventResult result = FabricEntityEvents.ENDER_PEARL_TELEPORT.invoker()
                    .onEnderPearlTeleport(serverPlayer,
                            this.method_61411(),
                            class_1684.class.cast(this),
                            damageAmountRef.get(),
                            hitResult);
            if (result.isInterrupt()) {
                return false;
            }
        }

        return isAcceptingMessages;
    }

    @ModifyArg(method = "onHit",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/server/level/ServerPlayer;hurtServer(Lnet/minecraft/server/level/ServerLevel;Lnet/minecraft/world/damagesource/DamageSource;F)Z"))
    protected float onHit(float damageAmount, @Share("damageAmount") LocalRef<DefaultedFloat> damageAmountRef) {
        return damageAmountRef.get().getAsOptionalFloat().orElse(damageAmount);
    }
}
