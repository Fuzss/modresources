package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.impl.event.EventImplHelper;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1496;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1496.class)
abstract class AbstractHorseFabricMixin extends class_1429 {

    protected AbstractHorseFabricMixin(class_1299<? extends class_1429> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "executeRidersJump",
            at = @At(value = "FIELD",
                    target = "Lnet/minecraft/world/entity/animal/equine/AbstractHorse;needsSync:Z",
                    shift = At.Shift.AFTER,
                    opcode = Opcodes.PUTFIELD))
    public void executeRidersJump(float playerJumpPendingScale, class_243 travelVector, CallbackInfo callback) {
        EventImplHelper.onLivingJump(FabricLivingEvents.LIVING_JUMP.invoker(), this);
    }
}
