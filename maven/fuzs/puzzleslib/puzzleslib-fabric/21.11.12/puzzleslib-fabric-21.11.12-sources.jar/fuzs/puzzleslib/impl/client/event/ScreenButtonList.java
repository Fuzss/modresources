package fuzs.puzzleslib.impl.client.event;

import fuzs.puzzleslib.api.core.v1.util.TransformingForwardingList;
import org.jspecify.annotations.Nullable;

import java.util.List;
import net.minecraft.class_339;
import net.minecraft.class_4068;

/**
 * A simple utility class that allows getting a list of all {@link class_339} instances in screen, but as a view of
 * {@link net.minecraft.class_437#field_33816}.
 * <p>
 * Intended for use during init events. A view is required so that changes from additions and removals of widgets are
 * reflected.
 * <p>
 * This is basically the same as Fabric Api's <code>net.fabricmc.fabric.impl.client.screen.ButtonList</code>, just much
 * simpler as it does not need to handle additions and removals (Forge has dedicated methods in the init events for
 * that).
 */
public final class ScreenButtonList extends TransformingForwardingList<class_339, class_4068> {

    public ScreenButtonList(List<class_4068> delegate) {
        super(delegate);
    }

    @Override
    protected @Nullable class_339 getAsElement(@Nullable class_4068 element) {
        return element instanceof class_339 abstractWidget ? abstractWidget : null;
    }

    @Override
    protected @Nullable class_4068 getAsListElement(@Nullable class_339 abstractWidget) {
        return abstractWidget;
    }
}
