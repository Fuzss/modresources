package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_327;
import net.minecraft.class_332;

@FunctionalInterface
public interface DrawItemStackOverlayCallback {

    static EventInvoker<DrawItemStackOverlayCallback> drawItemStackOverlay(class_1935 item) {
        Objects.requireNonNull(item, "item is null");
        return EventInvoker.lookup(DrawItemStackOverlayCallback.class, item.method_8389());
    }

    /**
     * /** Fires at the end of {@link class_332#method_51432(class_327, class_1799, int, int, String)} and allows
     * for drawing custom item stack decorations.
     * <p>
     * In vanilla these are: durability bar, cooldown overlay and stack count.
     *
     * @param guiGraphics the gui graphics
     * @param font        the font renderer
     * @param itemStack   the item stack
     * @param posX        the x-position of the item stack
     * @param posY        the y-position of the item stack
     */
    void onDrawItemStackOverlay(class_332 guiGraphics, class_327 font, class_1799 itemStack, int posX, int posY);
}
