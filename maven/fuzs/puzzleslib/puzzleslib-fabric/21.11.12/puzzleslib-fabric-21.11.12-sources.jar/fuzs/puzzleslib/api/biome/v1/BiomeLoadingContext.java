package fuzs.puzzleslib.api.biome.v1;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1959;
import net.minecraft.class_2975;
import net.minecraft.class_3195;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6796;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6885;

/**
 * Context given to a biome selector for deciding whether it applies to a biome or not.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
public interface BiomeLoadingContext {

    /**
     * Returns the key used to represent this biome in the dynamic biome registry.
     */
    class_5321<class_1959> getResourceKey();

    /**
     * Returns the biome with modifications by biome modifiers of higher priority already applied.
     */
    class_1959 getBiome();

    /**
     * Returns this biome wrapped in a holder.
     */
    class_6880<class_1959> holder();

    /**
     * Returns true if this biome contains a placed feature referencing a configured feature with the given key.
     */
    default boolean hasFeature(class_5321<class_2975<?, ?>> key) {
        List<class_6885<class_6796>> featureSteps = this.getBiome().method_30970().method_30983();

        for (class_6885<class_6796> featureSuppliers : featureSteps) {
            for (class_6880<class_6796> featureSupplier : featureSuppliers) {
                if (featureSupplier.comp_349().method_39643().anyMatch(cf -> this.getFeatureKey(cf).orElse(null) == key)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Returns true if this biome contains a placed feature with the given key.
     */
    default boolean hasPlacedFeature(class_5321<class_6796> key) {
        List<class_6885<class_6796>> featureSteps = this.getBiome().method_30970().method_30983();

        for (class_6885<class_6796> featureSuppliers : featureSteps) {
            for (class_6880<class_6796> featureSupplier : featureSuppliers) {
                if (this.getPlacedFeatureKey(featureSupplier.comp_349()).orElse(null) == key) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Tries to retrieve the registry key for the given configured feature, which should be from this biomes
     * current feature list. May be empty if the configured feature is not registered, or does not come
     * from this biomes feature list.
     */
    Optional<class_5321<class_2975<?, ?>>> getFeatureKey(class_2975<?, ?> configuredFeature);

    /**
     * Tries to retrieve the registry key for the given placed feature, which should be from this biomes
     * current feature list. May be empty if the placed feature is not registered, or does not come
     * from this biomes feature list.
     */
    Optional<class_5321<class_6796>> getPlacedFeatureKey(class_6796 placedFeature);

    /**
     * Returns true if the configured structure with the given key can start in this biome in any chunk generator
     * used by the current world-save.
     */
    boolean validForStructure(class_5321<class_3195> key);

    /**
     * Tries to retrieve the registry key for the given configured feature, which should be from this biomes
     * current structure list. May be empty if the configured feature is not registered, or does not come
     * from this biomes feature list.
     */
    Optional<class_5321<class_3195>> getStructureKey(class_3195 structureFeature);

    /**
     * Tries to determine whether this biome generates in a specific dimension, based on the {@link net.minecraft.class_7726}
     * used by the current world-save.
     *
     * <p>If no dimension options exist for the given dimension key, <code>false</code> is returned.
     */
    boolean canGenerateIn(class_5321<class_5363> dimensionKey);

    /**
     * @param tag tag key to check for biome
     * @return is the biome in this context contained in the given <code>tag</code> key
     */
    boolean is(class_6862<class_1959> tag);

    /**
     * @param biome biome to check for equality
     * @return is the biome in this context equal to the given <code>biome</code>
     */
    default boolean is(class_1959 biome) {
        return this.getBiome() == biome;
    }

    /**
     * @param holder holder to check for equality
     * @return is the holder for the biome in this context equal to the given <code>holder</code>
     */
    default boolean is(class_6880<class_1959> holder) {
        return this.holder() == holder;
    }

    /**
     * @param resourceKey resourceKey to check for equality
     * @return is the resource key for the biome in this context equal to the given <code>resourceKey</code>
     */
    default boolean is(class_5321<class_1959> resourceKey) {
        return this.getResourceKey() == resourceKey;
    }
}
