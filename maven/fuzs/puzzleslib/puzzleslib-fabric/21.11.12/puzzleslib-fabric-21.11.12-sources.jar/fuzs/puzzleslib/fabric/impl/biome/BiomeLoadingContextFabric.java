package fuzs.puzzleslib.fabric.impl.biome;

import fuzs.puzzleslib.api.biome.v1.BiomeLoadingContext;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.minecraft.class_1959;
import net.minecraft.class_2975;
import net.minecraft.class_3195;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6796;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import java.util.Optional;

public record BiomeLoadingContextFabric(BiomeSelectionContext context) implements BiomeLoadingContext {

    @Override
    public class_5321<class_1959> getResourceKey() {
        return this.context.getBiomeKey();
    }

    @Override
    public class_1959 getBiome() {
        return this.context.getBiome();
    }

    @Override
    public class_6880<class_1959> holder() {
        return this.context.getBiomeRegistryEntry();
    }

    @Override
    public Optional<class_5321<class_2975<?, ?>>> getFeatureKey(class_2975<?, ?> configuredFeature) {
        return this.context.getFeatureKey(configuredFeature);
    }

    @Override
    public Optional<class_5321<class_6796>> getPlacedFeatureKey(class_6796 placedFeature) {
        return this.context.getPlacedFeatureKey(placedFeature);
    }

    @Override
    public boolean validForStructure(class_5321<class_3195> key) {
        return this.context.validForStructure(key);
    }

    @Override
    public Optional<class_5321<class_3195>> getStructureKey(class_3195 structureFeature) {
        return this.context.getStructureKey(structureFeature);
    }

    @Override
    public boolean canGenerateIn(class_5321<class_5363> dimensionKey) {
        return this.context.canGenerateIn(dimensionKey);
    }

    @Override
    public boolean is(class_6862<class_1959> tag) {
        return this.context.hasTag(tag);
    }
}
