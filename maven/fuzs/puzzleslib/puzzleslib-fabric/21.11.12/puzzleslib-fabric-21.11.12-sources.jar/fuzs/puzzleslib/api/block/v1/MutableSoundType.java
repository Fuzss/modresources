package fuzs.puzzleslib.api.block.v1;

import java.util.Objects;
import net.minecraft.class_2498;
import net.minecraft.class_3414;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

/**
 * An extended {@link class_2498} allowing for easily setting new values.
 */
public class MutableSoundType extends HolderBackedSoundType {

    /**
     * @param volume     sound volume
     * @param pitch      sound pitch
     * @param breakSound break sound
     * @param stepSound  step sound
     * @param placeSound place sound
     * @param hitSound   hit sound
     * @param fallSound  fall sound
     */
    public MutableSoundType(float volume, float pitch, class_3414 breakSound, class_3414 stepSound, class_3414 placeSound, class_3414 hitSound, class_3414 fallSound) {
        super(volume,
                pitch,
                class_7923.field_41172.method_47983(breakSound),
                class_7923.field_41172.method_47983(stepSound),
                class_7923.field_41172.method_47983(placeSound),
                class_7923.field_41172.method_47983(hitSound),
                class_7923.field_41172.method_47983(fallSound)
        );
    }

    /**
     * @param volume     sound volume
     * @param pitch      sound pitch
     * @param breakSound break sound
     * @param stepSound  step sound
     * @param placeSound place sound
     * @param hitSound   hit sound
     * @param fallSound  fall sound
     */
    public MutableSoundType(float volume, float pitch, class_6880<class_3414> breakSound, class_6880<class_3414> stepSound, class_6880<class_3414> placeSound, class_6880<class_3414> hitSound, class_6880<class_3414> fallSound) {
        super(volume, pitch, breakSound, stepSound, placeSound, hitSound, fallSound);
    }

    /**
     * @param soundType the original sound type
     * @return mutable copy of sound type
     */
    public static MutableSoundType copyOf(class_2498 soundType) {
        Objects.requireNonNull(soundType, "sound type is null");
        if (soundType instanceof HolderBackedSoundType holderBackedSoundType) {
            return new MutableSoundType(holderBackedSoundType.method_10597(),
                    holderBackedSoundType.method_10599(),
                    holderBackedSoundType.breakSound,
                    holderBackedSoundType.stepSound,
                    holderBackedSoundType.placeSound,
                    holderBackedSoundType.hitSound,
                    holderBackedSoundType.fallSound
            );
        } else {
            return new MutableSoundType(soundType.method_10597(),
                    soundType.method_10599(),
                    soundType.method_10595(),
                    soundType.method_10594(),
                    soundType.method_10598(),
                    soundType.method_10596(),
                    soundType.method_10593()
            );
        }
    }

    /**
     * @param volume a new volume
     * @return the mutable instance
     */
    public MutableSoundType setVolume(float volume) {
        return new MutableSoundType(volume,
                this.method_10599(),
                this.breakSound,
                this.stepSound,
                this.placeSound,
                this.hitSound,
                this.fallSound
        );
    }

    /**
     * @param pitch a new pitch
     * @return the mutable instance
     */
    public MutableSoundType setPitch(float pitch) {
        return new MutableSoundType(this.method_10597(),
                pitch,
                this.breakSound,
                this.stepSound,
                this.placeSound,
                this.hitSound,
                this.fallSound
        );
    }

    /**
     * @param breakSound a new break sound
     * @return the mutable instance
     */
    public MutableSoundType setBreakSound(class_3414 breakSound) {
        Objects.requireNonNull(breakSound, "break sound is null");
        return this.setBreakSound(class_7923.field_41172.method_47983(breakSound));
    }

    /**
     * @param breakSound a new break sound
     * @return the mutable instance
     */
    public MutableSoundType setBreakSound(class_6880<class_3414> breakSound) {
        Objects.requireNonNull(breakSound, "break sound is null");
        return new MutableSoundType(this.method_10597(),
                this.method_10599(),
                breakSound,
                this.stepSound,
                this.placeSound,
                this.hitSound,
                this.fallSound
        );
    }

    /**
     * @param stepSound a new step sound
     * @return the mutable instance
     */
    public MutableSoundType setStepSound(class_3414 stepSound) {
        Objects.requireNonNull(stepSound, "step sound is null");
        return this.setStepSound(class_7923.field_41172.method_47983(stepSound));
    }

    /**
     * @param stepSound a new step sound
     * @return the mutable instance
     */
    public MutableSoundType setStepSound(class_6880<class_3414> stepSound) {
        Objects.requireNonNull(stepSound, "step sound is null");
        return new MutableSoundType(this.method_10597(),
                this.method_10599(),
                this.breakSound,
                stepSound,
                this.placeSound,
                this.hitSound,
                this.fallSound
        );
    }

    /**
     * @param placeSound a new place sound
     * @return the mutable instance
     */
    public MutableSoundType setPlaceSound(class_3414 placeSound) {
        Objects.requireNonNull(placeSound, "place sound is null");
        return this.setPlaceSound(class_7923.field_41172.method_47983(placeSound));
    }

    /**
     * @param placeSound a new place sound
     * @return the mutable instance
     */
    public MutableSoundType setPlaceSound(class_6880<class_3414> placeSound) {
        Objects.requireNonNull(placeSound, "place sound is null");
        return new MutableSoundType(this.method_10597(),
                this.method_10599(),
                this.breakSound,
                this.stepSound,
                placeSound,
                this.hitSound,
                this.fallSound
        );
    }

    /**
     * @param hitSound a new hit sound
     * @return the mutable instance
     */
    public MutableSoundType setHitSound(class_3414 hitSound) {
        Objects.requireNonNull(hitSound, "hit sound is null");
        return this.setHitSound(class_7923.field_41172.method_47983(hitSound));
    }

    /**
     * @param hitSound a new hit sound
     * @return the mutable instance
     */
    public MutableSoundType setHitSound(class_6880<class_3414> hitSound) {
        Objects.requireNonNull(hitSound, "hit sound is null");
        return new MutableSoundType(this.method_10597(),
                this.method_10599(),
                this.breakSound,
                this.stepSound,
                this.placeSound,
                hitSound,
                this.fallSound
        );
    }

    /**
     * @param fallSound a new fall sound
     * @return the mutable instance
     */
    public MutableSoundType setFallSound(class_3414 fallSound) {
        Objects.requireNonNull(fallSound, "fall sound is null");
        return this.setFallSound(class_7923.field_41172.method_47983(fallSound));
    }

    /**
     * @param fallSound a new fall sound
     * @return the mutable instance
     */
    public MutableSoundType setFallSound(class_6880<class_3414> fallSound) {
        Objects.requireNonNull(fallSound, "fall sound is null");
        return new MutableSoundType(this.method_10597(),
                this.method_10599(),
                this.breakSound,
                this.stepSound,
                this.placeSound,
                this.hitSound,
                fallSound
        );
    }
}
