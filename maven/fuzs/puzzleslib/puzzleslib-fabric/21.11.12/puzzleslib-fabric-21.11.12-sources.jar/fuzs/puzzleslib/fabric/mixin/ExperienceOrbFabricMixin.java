package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1303.class)
abstract class ExperienceOrbFabricMixin extends class_1297 {

    public ExperienceOrbFabricMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "playerTouch",
            at = @At(value = "FIELD",
                    target = "Lnet/minecraft/world/entity/player/Player;takeXpDelay:I",
                    opcode = Opcodes.PUTFIELD),
            cancellable = true)
    public void playerTouch(class_1657 player, CallbackInfo callback) {
        if (FabricPlayerEvents.PICKUP_EXPERIENCE.invoker()
                .onPickupExperience(player, class_1303.class.cast(this))
                .isInterrupt()) {
            callback.cancel();
        }
    }
}
