package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_3218;
import net.minecraft.server.MinecraftServer;
import java.util.function.BooleanSupplier;

public final class ServerLevelTickEvents {
    public static final EventInvoker<Start> START = EventInvoker.lookup(Start.class);
    public static final EventInvoker<End> END = EventInvoker.lookup(End.class);

    private ServerLevelTickEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Start {

        /**
         * Fires before ticking the server level in {@link MinecraftServer#method_3813(BooleanSupplier)}.
         *
         * @param minecraftServer the current minecraft server instance
         * @param serverLevel     the server level that is being ticked
         */
        void onStartLevelTick(MinecraftServer minecraftServer, class_3218 serverLevel);
    }

    @FunctionalInterface
    public interface End {

        /**
         * Fires after ticking the server level in {@link MinecraftServer#method_3813(BooleanSupplier)}.
         *
         * @param minecraftServer the current minecraft server instance
         * @param serverLevel     the server level that is being ticked
         */
        void onEndLevelTick(MinecraftServer minecraftServer, class_3218 serverLevel);
    }
}
