package fuzs.puzzleslib.api.init.v3.registry;

import com.google.common.collect.ImmutableSet;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import fuzs.puzzleslib.api.core.v1.util.EnvironmentAwareBuilder;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.item.CreativeModeTabHelper;
import net.minecraft.class_10355;
import net.minecraft.class_11845;
import net.minecraft.class_12279;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1320;
import net.minecraft.class_1329;
import net.minecraft.class_1703;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1826;
import net.minecraft.class_1842;
import net.minecraft.class_1860;
import net.minecraft.class_1887;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2319;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2400;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2941;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_4158;
import net.minecraft.class_4311;
import net.minecraft.class_4970;
import net.minecraft.class_5198;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.class_7924;
import net.minecraft.class_8054;
import net.minecraft.class_8110;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9331;
import net.minecraft.world.item.*;
import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

/**
 * Handles registering to game registries. Registration is performed instantly on Fabric and is deferred on Forge.
 */
public interface RegistryManager extends EnvironmentAwareBuilder<RegistryManager> {

    /**
     * Creates a new registry manager for <code>modId</code> or returns an existing one.
     *
     * @param modId the namespace used for registration
     * @return the mod-specific registry manager
     */
    static RegistryManager from(String modId) {
        return ModContext.get(modId).getRegistryManager();
    }

    /**
     * Creates a new {@link class_5321} for a provided registry from the given path.
     *
     * @param registryKey key for registry to create {@link class_5321} for
     * @param path        the registered name
     * @param <T>         registry type
     * @return {@link class_5321} for path
     */
    @SuppressWarnings("unchecked")
    default <T> class_5321<T> makeResourceKey(class_5321<? extends class_2378<? super T>> registryKey, String path) {
        return class_5321.method_29179((class_5321<class_2378<T>>) registryKey, this.makeKey(path));
    }

    /**
     * Create a new {@link class_2960} for the set mod id.
     *
     * @param path path for location
     * @return identifier for set namespace
     */
    class_2960 makeKey(String path);

    /**
     * Creates a lazy holder reference that will update when used.
     *
     * @param registryKey key for registry to register to
     * @param path        the registered name
     * @param <T>         registry type
     * @return new placeholder registry object
     */
    <T> class_6880.class_6883<T> registerLazily(class_5321<? extends class_2378<? super T>> registryKey, String path);

    /**
     * Register a supplied value to a given registry of that type returning a holder reference.
     *
     * @param registryKey key for registry to register to
     * @param path        the registered name
     * @param supplier    supplier for entry to register
     * @param <T>         registry type
     * @return the holder reference
     */
    <T> class_6880.class_6883<T> register(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier);

    /**
     * Register a block.
     *
     * @param path                    the registered name
     * @param blockPropertiesSupplier supplier for block properties
     * @return the holder reference
     */
    default class_6880.class_6883<class_2248> registerBlock(String path, Supplier<class_4970.class_2251> blockPropertiesSupplier) {
        return this.registerBlock(path, class_2248::new, blockPropertiesSupplier);
    }

    /**
     * Register a block.
     *
     * @param path                    the registered name
     * @param blockFactory            factory for new block
     * @param blockPropertiesSupplier supplier for block properties
     * @return the holder reference
     */
    default class_6880.class_6883<class_2248> registerBlock(String path, Function<class_4970.class_2251, class_2248> blockFactory, Supplier<class_4970.class_2251> blockPropertiesSupplier) {
        return this.register(class_7924.field_41254,
                path,
                () -> blockFactory.apply(blockPropertiesSupplier.get()
                        .method_63500(this.makeResourceKey(class_7924.field_41254, path))));
    }

    /**
     * Register an item.
     *
     * @param path the registered name
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerItem(String path) {
        return this.registerItem(path, class_1792.class_1793::new);
    }

    /**
     * Register an item.
     *
     * @param path                   the registered name
     * @param itemPropertiesSupplier supplier for new item properties
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerItem(String path, Supplier<class_1792.class_1793> itemPropertiesSupplier) {
        return this.registerItem(path, class_1792::new, itemPropertiesSupplier);
    }

    /**
     * Register an item.
     *
     * @param path        the registered name
     * @param itemFactory factory for new item
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerItem(String path, Function<class_1792.class_1793, class_1792> itemFactory) {
        return this.registerItem(path, itemFactory, class_1792.class_1793::new);
    }

    /**
     * Register an item.
     *
     * @param path                   the registered name
     * @param itemFactory            factory for new item
     * @param itemPropertiesSupplier supplier for new item properties
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerItem(String path, Function<class_1792.class_1793, class_1792> itemFactory, Supplier<class_1792.class_1793> itemPropertiesSupplier) {
        return this.register(class_7924.field_41197,
                path,
                () -> itemFactory.apply(itemPropertiesSupplier.get()
                        .method_63686(this.makeResourceKey(class_7924.field_41197, path))));
    }

    /**
     * Registers a block item for a block.
     *
     * @param block reference for block to register item variant for
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerBlockItem(class_6880<class_2248> block) {
        return this.registerBlockItem(block, class_1792.class_1793::new);
    }

    /**
     * Registers a block item for a block.
     *
     * @param block                  reference for block to register item variant for
     * @param itemPropertiesSupplier supplier for new item properties
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerBlockItem(class_6880<class_2248> block, Supplier<class_1792.class_1793> itemPropertiesSupplier) {
        return this.registerBlockItem(block, class_1747::new, itemPropertiesSupplier);
    }

    /**
     * Registers a block item for a block.
     *
     * @param block       reference for block to register item variant for
     * @param itemFactory factory for new item
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerBlockItem(class_6880<class_2248> block, BiFunction<class_2248, class_1792.class_1793, ? extends class_1747> itemFactory) {
        return this.registerBlockItem(block, itemFactory, class_1792.class_1793::new);
    }

    /**
     * Registers a block item for a block.
     *
     * @param block                  reference for block to register item variant for
     * @param itemFactory            factory for new item
     * @param itemPropertiesSupplier supplier for new item properties
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerBlockItem(class_6880<class_2248> block, BiFunction<class_2248, class_1792.class_1793, ? extends class_1747> itemFactory, Supplier<class_1792.class_1793> itemPropertiesSupplier) {
        return this.registerItem(block.method_40230().orElseThrow().method_29177().method_12832(),
                (class_1792.class_1793 itemProperties) -> {
                    return itemFactory.apply(block.comp_349(), itemProperties);
                },
                () -> itemPropertiesSupplier.get().method_63685());
    }

    /**
     * Registers a spawn egg item for an entity type.
     *
     * @param entityTypeHolder the entity type holder
     * @return the holder reference
     */
    default class_6880.class_6883<class_1792> registerSpawnEggItem(class_6880<? extends class_1299<? extends class_1308>> entityTypeHolder) {
        return this.registerItem(entityTypeHolder.method_40230().orElseThrow().method_29177().method_12832() + "_spawn_egg",
                class_1826::new,
                () -> new class_1792.class_1793().method_72499(entityTypeHolder.comp_349()));
    }

    /**
     * Register a creative mode tab.
     *
     * @param iconHolder the tab icon item stack
     * @return the holder reference
     */
    default class_6880.class_6883<class_1761> registerCreativeModeTab(class_6880<? extends class_1935> iconHolder) {
        return this.registerCreativeModeTab(() -> new class_1799(iconHolder.comp_349()));
    }

    /**
     * Register a creative mode tab.
     *
     * @param iconSupplier the tab icon item stack
     * @return the holder reference
     */
    default class_6880.class_6883<class_1761> registerCreativeModeTab(Supplier<class_1799> iconSupplier) {
        class_2960 identifier = this.makeKey("main");
        return this.registerCreativeModeTab(identifier.method_12832(),
                iconSupplier,
                CreativeModeTabHelper.getDisplayItems(identifier.method_12836()),
                false);
    }

    /**
     * Register a creative mode tab.
     *
     * @param iconSupplier the tab icon item stack
     * @param displayItems the display items generator
     * @return the holder reference
     */
    default class_6880.class_6883<class_1761> registerCreativeModeTab(Supplier<class_1799> iconSupplier, class_1761.class_7914 displayItems) {
        return this.registerCreativeModeTab("main", iconSupplier, displayItems, false);
    }

    /**
     * Register a creative mode tab.
     *
     * @param path          the registered name
     * @param iconSupplier  the tab icon item stack
     * @param displayItems  the display items generator
     * @param withSearchBar should the tab include a search bar (only supported for NeoForge)
     * @return the holder reference
     */
    class_6880.class_6883<class_1761> registerCreativeModeTab(String path, Supplier<class_1799> iconSupplier, class_1761.class_7914 displayItems, boolean withSearchBar);

    /**
     * Register a data component type.
     *
     * @param path     the registered name
     * @param operator the supplier for entry to register
     * @param <T>      the component type
     * @return the holder reference
     */
    default <T> class_6880.class_6883<class_9331<T>> registerDataComponentType(String path, UnaryOperator<class_9331.class_9332<T>> operator) {
        return this.register(class_7924.field_49659,
                path,
                () -> operator.apply(class_9331.method_57873()).method_57880());
    }

    /**
     * Register a fluid.
     *
     * @param path          the registered name
     * @param fluidSupplier supplier for entry to register
     * @return the holder reference
     */
    default class_6880.class_6883<class_3611> registerFluid(String path, Supplier<class_3611> fluidSupplier) {
        return this.register(class_7924.field_41270, path, fluidSupplier);
    }

    /**
     * Register a mob effect.
     *
     * @param path              the registered name
     * @param mobEffectSupplier supplier for entry to register
     * @return the holder reference
     */
    default class_6880.class_6883<class_1291> registerMobEffect(String path, Supplier<class_1291> mobEffectSupplier) {
        return this.register(class_7924.field_41208, path, mobEffectSupplier);
    }

    /**
     * Register a sound event.
     *
     * @param path the registered name
     * @return the holder reference
     */
    default class_6880.class_6883<class_3414> registerSoundEvent(String path) {
        return this.register(class_7924.field_41225, path, () -> {
            return class_3414.method_47908(this.makeKey(path));
        });
    }

    /**
     * Register a potion.
     *
     * @param path           the registered name
     * @param potionSupplier supplier for entry to register
     * @return the holder reference
     */
    default class_6880.class_6883<class_1842> registerPotion(String path, Supplier<class_1842> potionSupplier) {
        return this.registerPotion(path, (String name) -> potionSupplier.get());
    }

    /**
     * Register a potion.
     *
     * @param path          the registered name
     * @param potionFactory function for entry to register, receiving the passed path parameter
     * @return the holder reference
     */
    default class_6880.class_6883<class_1842> registerPotion(String path, Function<String, class_1842> potionFactory) {
        return this.register(class_7924.field_41215, path, () -> potionFactory.apply(path));
    }

    /**
     * Register an enchantment.
     *
     * @param path the registered name
     * @return the holder reference
     */
    default class_5321<class_1887> registerEnchantment(String path) {
        return this.makeResourceKey(class_7924.field_41265, path);
    }

    /**
     * Register an enchantment effect component type.
     *
     * @param path     the registered name
     * @param operator the supplier for entry to register
     * @param <T>      the component type
     * @return the holder reference
     */
    default <T> class_6880.class_6883<class_9331<T>> registerEnchantmentEffectComponentType(String path, UnaryOperator<class_9331.class_9332<T>> operator) {
        return this.register(class_7924.field_51838,
                path,
                () -> operator.apply(class_9331.method_57873()).method_57880());
    }

    /**
     * Register an entity type.
     *
     * @param path               the registered name
     * @param entityTypeSupplier supplier for entry to register
     * @param <T>                entity type parameter
     * @return the holder reference
     */
    @SuppressWarnings("unchecked")
    default <T extends class_1297> class_6880.class_6883<class_1299<T>> registerEntityType(String path, Supplier<class_1299.class_1300<T>> entityTypeSupplier) {
        return this.register((class_5321<class_2378<class_1299<T>>>) (class_5321<?>) class_7924.field_41266,
                path,
                () -> {
                    return entityTypeSupplier.get().method_5905(this.makeResourceKey(class_7924.field_41266, path));
                });
    }

    /**
     * Register a block entity type.
     *
     * @param path               the registered name
     * @param blockEntityFactory factory for every newly created block entity instance
     * @param validBlock         block allowed to use this block entity
     * @param <T>                block entity type parameter
     * @return the holder reference
     */
    default <T extends class_2586> class_6880.class_6883<class_2591<T>> registerBlockEntityType(String path, BiFunction<class_2338, class_2680, T> blockEntityFactory, class_6880<class_2248> validBlock) {
        return this.registerBlockEntityType(path, blockEntityFactory, () -> Collections.singleton(validBlock.comp_349()));
    }

    /**
     * Register a block entity type.
     *
     * @param path               the registered name
     * @param blockEntityFactory factory for every newly created block entity instance
     * @param validBlocks        blocks allowed to use this block entity
     * @param <T>                block entity type parameter
     * @return the holder reference
     */
    <T extends class_2586> class_6880.class_6883<class_2591<T>> registerBlockEntityType(String path, BiFunction<class_2338, class_2680, T> blockEntityFactory, Supplier<Set<class_2248>> validBlocks);

    /**
     * Register a menu type.
     *
     * @param path         the registered name
     * @param menuSupplier the menu supplier
     * @param <T>          the menu type
     * @return the holder reference
     */
    @SuppressWarnings("unchecked")
    default <T extends class_1703> class_6880.class_6883<class_3917<T>> registerMenuType(String path, class_3917.class_3918<T> menuSupplier) {
        return this.register((class_5321<class_2378<class_3917<T>>>) (class_5321<?>) class_7924.field_41207, path, () -> {
            return new class_3917<>(menuSupplier, class_7701.field_40183);
        });
    }

    /**
     * Register a menu type with additional data for constructing the menu on the client.
     *
     * @param path         the registered name
     * @param menuSupplier the menu supplier
     * @param streamCodec  the stream codec for additional data
     * @param <T>          the menu type
     * @param <S>          the data type
     * @return the holder reference
     */
    <T extends class_1703, S> class_6880.class_6883<class_3917<T>> registerMenuType(String path, MenuSupplierWithData<T, S> menuSupplier, class_9139<? super class_9129, S> streamCodec);

    /**
     * Register a poi type.
     *
     * @param path          the registered name
     * @param matchingBlock block valid for this poi type
     * @return the holder reference
     */
    default class_6880.class_6883<class_4158> registerPoiType(String path, class_6880<class_2248> matchingBlock) {
        return this.registerPoiType(path, () -> Collections.singleton(matchingBlock.comp_349()));
    }

    /**
     * Register a poi type.
     *
     * @param path           the registered name
     * @param matchingBlocks blocks valid for this poi type
     * @return the holder reference
     */
    default class_6880.class_6883<class_4158> registerPoiType(String path, Supplier<Set<class_2248>> matchingBlocks) {
        return this.registerPoiType(path, 0, 1, () -> {
            return matchingBlocks.get()
                    .stream()
                    .flatMap((class_2248 block) -> block.method_9595().method_11662().stream())
                    .collect(ImmutableSet.toImmutableSet());
        });
    }

    /**
     * Register a poi type.
     *
     * @param path                the registered name
     * @param maxTickets          max amount of accessor tickets
     * @param validRange          distance to search for this poi type
     * @param matchingBlockStates blocks states valid for this poi type
     * @return the holder reference
     */
    class_6880.class_6883<class_4158> registerPoiType(String path, int maxTickets, int validRange, Supplier<Set<class_2680>> matchingBlockStates);

    /**
     * Register an argument type.
     *
     * @param path          the registered name
     * @param argumentClass argument type class
     * @param argumentType  argument type factory
     * @param <A>           argument type
     * @return the holder reference
     */
    default <A extends ArgumentType<?>> class_6880.class_6883<class_2314<?, ?>> registerArgumentType(String path, Class<? extends A> argumentClass, Supplier<A> argumentType) {
        return this.registerArgumentType(path, argumentClass, class_2319.method_41999(argumentType));
    }

    /**
     * Register an argument type.
     *
     * @param path             the registered name
     * @param argumentClass    argument type class
     * @param argumentTypeInfo argument type info
     * @param <A>              argument type
     * @param <T>              argument type info
     * @return the holder reference
     */
    <A extends ArgumentType<?>, T extends class_2314.class_7217<A>> class_6880.class_6883<class_2314<?, ?>> registerArgumentType(String path, Class<? extends A> argumentClass, class_2314<A, T> argumentTypeInfo);

    /**
     * Register a type of recipe.
     *
     * @param path the registered name
     * @param <T>  recipe type
     * @return the holder reference
     */
    default <T extends class_1860<?>> class_6880.class_6883<class_3956<T>> registerRecipeType(String path) {
        return this.register(class_7924.field_41217, path, () -> {
            class_2960 identifier = this.makeKey(path);
            return new class_3956<>() {
                @Override
                public String toString() {
                    return "RecipeType[" + identifier + "]";
                }
            };
        });
    }

    /**
     * Register a recipe book category.
     *
     * @param path the registered name
     * @return the holder reference
     */
    default class_6880.class_6883<class_10355> registerRecipeBookCategory(String path) {
        return this.register(class_7924.field_54928, path, () -> {
            class_2960 identifier = this.makeKey(path);
            return new class_10355() {
                @Override
                public String toString() {
                    return "RecipeBookCategory[" + identifier + "]";
                }
            };
        });
    }

    /**
     * Register a game event.
     *
     * @param path               the registered name
     * @param notificationRadius range in blocks in which this event will be listened to
     * @return the holder reference
     */
    default class_6880.class_6883<class_5712> registerGameEvent(String path, int notificationRadius) {
        return this.register(class_7924.field_41273, path, () -> {
            return new class_5712(notificationRadius);
        });
    }

    /**
     * Register a simple particle type.
     *
     * @param path the registered name
     * @return the holder reference
     */
    default class_6880.class_6883<class_2400> registerParticleType(String path) {
        return this.register(class_7924.field_41210, path, () -> {
            return new class_2400(false);
        });
    }

    /**
     * Register a particle type.
     *
     * @param path              the registered name
     * @param overrideLimiter   allow this particle to spawn regardless of the global particle limit
     * @param codecGetter       the codec for serialization
     * @param streamCodecGetter the stream codec for network synchronization
     * @param <T>               the particle type
     * @return the holder reference
     */
    default <T extends class_2394> class_6880.class_6883<class_2396<T>> registerParticleType(String path, boolean overrideLimiter, Function<class_2396<T>, MapCodec<T>> codecGetter, Function<class_2396<T>, class_9139<? super class_9129, T>> streamCodecGetter) {
        return this.register(class_7924.field_41210, path, () -> new class_2396<T>(overrideLimiter) {
            @Override
            public MapCodec<T> method_29138() {
                return codecGetter.apply(this);
            }

            @Override
            public class_9139<? super class_9129, T> method_56179() {
                return streamCodecGetter.apply(this);
            }
        });
    }

    /**
     * Register an attribute.
     *
     * @param path         the registered name
     * @param defaultValue the default value when no base value is otherwise specified
     * @param minValue     the min value
     * @param maxValue     the max value
     * @return the holder reference
     */
    default class_6880.class_6883<class_1320> registerAttribute(String path, double defaultValue, double minValue, double maxValue) {
        return this.registerAttribute(path, defaultValue, minValue, maxValue, true, class_1320.class_9764.field_51885);
    }

    /**
     * Register an attribute.
     *
     * @param path         the registered name
     * @param defaultValue the default value when no base value is otherwise specified
     * @param minValue     the min value
     * @param maxValue     the max value
     * @param syncable     is this attribute synced to clients
     * @param sentiment    the sentiment used for the attribute color on tooltips
     * @return the holder reference
     */
    default class_6880.class_6883<class_1320> registerAttribute(String path, double defaultValue, double minValue, double maxValue, boolean syncable, class_1320.class_9764 sentiment) {
        Objects.requireNonNull(sentiment, "sentiment is null");
        return this.register(class_7924.field_41251, path, () -> {
            String descriptionId = this.makeKey(path).method_42093(class_7924.method_60915(class_7924.field_41251));
            return new class_1329(descriptionId, defaultValue, minValue, maxValue).method_26829(syncable)
                    .method_60493(sentiment);
        });
    }

    /**
     * Register a boolean based {@link class_12279}.
     *
     * @param path             the registered name
     * @param gameRuleCategory the category for the game rules screen shown during world creation
     * @param defaultValue     the default value for the game rule
     * @return the game rule holder reference
     */
    default class_6880.class_6883<class_12279<Boolean>> registerGameRule(String path, class_5198 gameRuleCategory, boolean defaultValue) {
        return this.register(class_7924.field_64253,
                path,
                () -> new class_12279<>(gameRuleCategory,
                        class_11845.field_62400,
                        BoolArgumentType.bool(),
                        class_4311::method_27329,
                        Codec.BOOL,
                        (Boolean value) -> value ? 1 : 0,
                        defaultValue,
                        class_7699.method_45397()));
    }

    /**
     * Register an integer based {@link class_12279}.
     *
     * @param path             the registered name
     * @param gameRuleCategory the category for the game rules screen shown during world creation
     * @param defaultValue     the default value for the game rule
     * @return the game rule holder reference
     */
    default class_6880.class_6883<class_12279<Integer>> registerGameRule(String path, class_5198 gameRuleCategory, int defaultValue) {
        return this.registerGameRule(path, gameRuleCategory, defaultValue, 0, Integer.MAX_VALUE);
    }

    /**
     * Register an integer based {@link class_12279}.
     *
     * @param path             the registered name
     * @param gameRuleCategory the category for the game rules screen shown during world creation
     * @param defaultValue     the default value for the game rule
     * @param minValue         the minimum value for this rule
     * @param maxValue         the maximum value for this rule
     * @return the game rule holder reference
     */
    default class_6880.class_6883<class_12279<Integer>> registerGameRule(String path, class_5198 gameRuleCategory, int defaultValue, int minValue, int maxValue) {
        return this.register(class_7924.field_64253,
                path,
                () -> new class_12279<>(gameRuleCategory,
                        class_11845.field_62399,
                        IntegerArgumentType.integer(minValue, maxValue),
                        class_4311::method_27330,
                        Codec.intRange(minValue, maxValue),
                        integer -> integer,
                        defaultValue,
                        class_7699.method_45397()));
    }

    /**
     * Register an entity data serializer.
     * <p>
     * Registration to a game registry is only required on NeoForge, therefore a direct holder is returned on other mod
     * loaders.
     *
     * @param path                         the registered name
     * @param entityDataSerializerSupplier supplier for entry to register
     * @return the holder reference
     */
    <T> class_6880.class_6883<class_2941<T>> registerEntityDataSerializer(String path, Supplier<class_2941<T>> entityDataSerializerSupplier);

    /**
     * Creates a new {@link class_5321} for a {@link class_8110}.
     *
     * @param path path for new resource key
     * @return new resource key
     */
    default class_5321<class_8110> registerDamageType(String path) {
        return this.makeResourceKey(class_7924.field_42534, path);
    }

    /**
     * Creates a new {@link class_5321} for a {@link net.minecraft.class_8054}.
     *
     * @param path path for new resource key
     * @return new resource key
     */
    default class_5321<class_8054> registerTrimMaterial(String path) {
        return this.makeResourceKey(class_7924.field_42083, path);
    }

    /**
     * Creates a new {@link class_5321} for a {@link class_52}.
     *
     * @param path path for new resource key
     * @return new resource key
     */
    default class_5321<class_52> registerLootTable(String path) {
        return this.makeResourceKey(class_7924.field_50079, path);
    }

    /**
     * Creates an empty tag in the corresponding registry, so that the tag can be used during data generation via
     * {@link net.minecraft.class_7871#method_46733(class_6862)} and
     * {@link net.minecraft.class_7871#method_46735(class_6862)}.
     *
     * @param registryKey the registry key
     * @param tagKey      the tag key
     * @param <T>         the registry type
     */
    <T> void prepareTag(class_5321<? extends class_2378<? super T>> registryKey, class_6862<T> tagKey);
}
