package fuzs.puzzleslib.fabric.impl.event;

import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.api.network.v4.MessageSender;
import fuzs.puzzleslib.fabric.impl.core.FabricProxy;
import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2885;
import net.minecraft.class_2886;
import net.minecraft.class_3965;

public interface FabricPlayerInteraction {
    FabricPlayerInteraction USE_BLOCK = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(class_1269 interactionResult) {
            return interactionResult != class_1269.field_5812;
        }

        @Override
        public void sendServerboundPacket(class_1657 player, class_1937 level, class_1268 interactionHand, @Nullable class_1297 entity, @Nullable class_239 hitResult) {
            Objects.requireNonNull(hitResult, "hit result is null");
            FabricProxy.get()
                    .startClientPrediction(level,
                            (int id) -> new class_2885(interactionHand,
                                    (class_3965) hitResult,
                                    id));
        }
    };
    FabricPlayerInteraction USE_ITEM = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(class_1269 interactionResult) {
            return interactionResult != class_1269.field_5812;
        }

        @Override
        public void sendServerboundPacket(class_1657 player, class_1937 level, class_1268 interactionHand, @Nullable class_1297 entity, @Nullable class_239 hitResult) {
            // send the move packet like vanilla to ensure the position+view vectors are accurate
            MessageSender.broadcast(new class_2828.class_2830(player.method_23317(),
                    player.method_23318(),
                    player.method_23321(),
                    player.method_36454(),
                    player.method_36455(),
                    player.method_24828(),
                    player.field_5976));
            // send the interaction packet to the server with a new sequentially assigned id
            FabricProxy.get()
                    .startClientPrediction(level,
                            (int id) -> new class_2886(interactionHand,
                                    id,
                                    player.method_36454(),
                                    player.method_36455()));
        }
    };
    FabricPlayerInteraction USE_ENTITY = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(class_1269 interactionResult) {
            // cancel Fabric Api fully, it sends the wrong packet for a successful interaction
            return true;
        }

        @Override
        public void sendServerboundPacket(class_1657 player, class_1937 level, class_1268 interactionHand, @Nullable class_1297 entity, @Nullable class_239 hitResult) {
            Objects.requireNonNull(entity, "entity is null");
            MessageSender.broadcast(class_2824.method_34207(entity,
                    player.method_5715(),
                    interactionHand));
        }

        @Override
        public class_1269 finalizeInteraction(class_1269 interactionResult, class_1657 player, class_1268 interactionHand) {
            // Fabric Api usually does this for us, but since we always fail, it will not
            if (interactionResult instanceof class_1269.class_9860 success) {
                if (success.comp_2909() == class_1269.class_9861.field_52427) {
                    player.method_6104(interactionHand);
                }
            }

            return class_1269.field_5814;
        }
    };
    FabricPlayerInteraction USE_ENTITY_AT = new FabricPlayerInteraction() {
        @Override
        public boolean sendServerboundPacket(class_1269 interactionResult) {
            return !interactionResult.method_23665();
        }

        @Override
        public void sendServerboundPacket(class_1657 player, class_1937 level, class_1268 interactionHand, @Nullable class_1297 entity, @Nullable class_239 hitResult) {
            Objects.requireNonNull(entity, "entity is null");
            Objects.requireNonNull(hitResult, "hit result is null");
            MessageSender.broadcast(class_2824.method_34208(entity,
                    player.method_5715(),
                    interactionHand,
                    hitResult.method_17784()));
        }
    };

    default class_1269 getHandledInteractionResult(EventResultHolder<class_1269> eventResult, class_1657 player, class_1937 level, class_1268 interactionHand, @Nullable class_1297 entity, @Nullable class_239 hitResult) {
        Optional<class_1269> optional = eventResult.getInterrupt();

        if (optional.isPresent()) {
            class_1269 interactionResult = optional.get();

            if (level.method_8608() && this.sendServerboundPacket(interactionResult)) {
                // this brings parity with Forge where the server is notified regardless of the returned InteractionResult,
                // as the Forge event runs after the server packet is sent
                this.sendServerboundPacket(player, level, interactionHand, entity, hitResult);
            }

            return this.finalizeInteraction(interactionResult, player, interactionHand);
        } else {
            return class_1269.field_5811;
        }
    }

    boolean sendServerboundPacket(class_1269 interactionResult);

    void sendServerboundPacket(class_1657 player, class_1937 level, class_1268 interactionHand, @Nullable class_1297 entity, @Nullable class_239 hitResult);

    default class_1269 finalizeInteraction(class_1269 interactionResult, class_1657 player, class_1268 interactionHand) {
        // this is done for parity with Forge where InteractionResult#PASS can be cancelled,
        // while on Fabric it will mark the event as having done nothing
        // unfortunately this will prevent the off-hand from being processed (if fired for the main hand),
        // but it's the best we can do
        return interactionResult != class_1269.field_5811 ? interactionResult : class_1269.field_5814;
    }
}
