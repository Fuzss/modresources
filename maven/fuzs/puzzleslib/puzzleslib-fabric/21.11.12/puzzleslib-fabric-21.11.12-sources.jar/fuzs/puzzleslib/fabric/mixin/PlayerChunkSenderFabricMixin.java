package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3244;
import net.minecraft.class_8608;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_8608.class)
abstract class PlayerChunkSenderFabricMixin {

    @Inject(method = "sendChunk", at = @At("TAIL"))
    private static void sendChunk(class_3244 packetListener, class_3218 level, class_2818 chunk, CallbackInfo callback) {
        FabricLevelEvents.WATCH_CHUNK.invoker().onChunkWatch(packetListener.method_32311(), chunk, level);
    }
}
