package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.List;
import net.minecraft.class_1293;
import net.minecraft.class_2561;
import net.minecraft.class_465;

@FunctionalInterface
public interface GatherEffectScreenTooltipCallback {
    EventInvoker<GatherEffectScreenTooltipCallback> EVENT = EventInvoker.lookup(GatherEffectScreenTooltipCallback.class);

    /**
     * Called when tooltip lines are gathered for an effect widget in the player inventory when it is hovered by the
     * cursor.
     * <p>
     * Only runs for small effects widgets.
     *
     * @param screen       the effect rendering inventory screen instance
     * @param mobEffect    the effect instance the tooltip is drawn for
     * @param tooltipLines the current tooltip components
     */
    void onGatherEffectScreenTooltip(class_465<?> screen, class_1293 mobEffect, List<class_2561> tooltipLines);
}
