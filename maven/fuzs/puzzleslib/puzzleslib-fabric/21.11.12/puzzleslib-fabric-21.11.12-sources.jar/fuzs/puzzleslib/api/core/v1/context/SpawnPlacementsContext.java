package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1317;
import net.minecraft.class_2902;
import net.minecraft.class_9168;

/**
 * Register a default spawn placement for entities.
 */
public interface SpawnPlacementsContext {

    /**
     * Registers a spawning behavior for an entity type.
     *
     * @param entityType         the entity type
     * @param spawnPlacementType the type of spawn placement, probably
     *                           {@link net.minecraft.class_9169#field_48745}
     * @param heightmapType      the heightmap type, probably {@link class_2902.class_2903#field_13203}
     * @param spawnPredicate     the custom spawn predicate for the mob
     * @param <T>                the type of entity
     */
    <T extends class_1308> void registerSpawnPlacement(class_1299<T> entityType, class_9168 spawnPlacementType, class_2902.class_2903 heightmapType, class_1317.class_4306<T> spawnPredicate);
}
