package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import net.minecraft.class_2338;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import org.jspecify.annotations.Nullable;

@FunctionalInterface
public interface ExtractBlockOutlineCallback {
    EventInvoker<ExtractBlockOutlineCallback> EVENT = EventInvoker.lookup(ExtractBlockOutlineCallback.class);

    /**
     * Called when the block highlight outline for the current hit result is about to be submitted.
     *
     * @param clientLevel      the current client level
     * @param blockPos         the block position from the hit result
     * @param blockState       the block state from the hit result
     * @param hitResult        the hit result to render the outline for
     * @param collisionContext the collision context for the camera entity
     * @return <ul>
     *         <li>{@link EventResultHolder#interrupt(Object)} to pass a custom {@link class_265}; or potentially {@code null} to prevent any outline from rendering</li>
     *         <li>{@link EventResultHolder#pass()} to allow vanilla outline rendering to happen without changes</li>
     *         </ul>
     */
    EventResultHolder<@Nullable class_265> onExtractBlockOutline(class_638 clientLevel, class_2338 blockPos, class_2680 blockState, class_3965 hitResult, class_3726 collisionContext);
}
