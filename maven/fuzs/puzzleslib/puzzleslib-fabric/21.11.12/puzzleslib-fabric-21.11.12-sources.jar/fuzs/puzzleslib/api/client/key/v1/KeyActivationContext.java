package fuzs.puzzleslib.api.client.key.v1;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_310;

/**
 * An activation context for key mappings, allowing to restrict key mappings in regard to a screen being open or not.
 */
public enum KeyActivationContext {
    /**
     * A key mapping that is always processed no matter whether a screen is open or not.
     */
    UNIVERSAL(true, true),
    /**
     * A key mapping that is processed when the game is running without a screen being open in
     * {@link net.minecraft.class_310#field_1755}.
     * <p>
     * These keys are usually processed in {@link class_310#method_1574()} and corresponding events.
     */
    GAME(false, true),
    /**
     * A key mapping that is processed when a screen is open in {@link class_310#field_1755}
     * <p>
     * These keys are usually processed in {@link net.minecraft.class_437#method_25404(class_11908)} and
     * {@link net.minecraft.class_437#method_25402(class_11909, boolean)}.
     */
    SCREEN(true, false);

    private final boolean isScreenContext;
    private final boolean isGameContext;

    KeyActivationContext(boolean isScreenContext, boolean isGameContext) {
        this.isScreenContext = isScreenContext;
        this.isGameContext = isGameContext;
    }

    /**
     * @return is the activation context able to trigger the key binding
     */
    public boolean isSupportedEnvironment() {
        if (this.isScreenContext && class_310.method_1551().field_1755 != null) {
            return true;
        } else if (this.isGameContext && class_310.method_1551().field_1755 == null) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Tests if this activation context is incompatible with another one.
     *
     * @param otherContext the other activation context
     * @return is the given activation context incompatible with this one
     */
    public boolean hasConflict(KeyActivationContext otherContext) {
        return this.isScreenContext != otherContext.isScreenContext && this.isGameContext != otherContext.isGameContext;
    }
}
