package fuzs.puzzleslib.fabric.impl.item.crafting;

import fuzs.puzzleslib.api.item.v2.crafting.CombinedIngredients;
import net.fabricmc.fabric.api.recipe.v1.ingredient.DefaultCustomIngredients;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import java.util.Objects;

public final class FabricCombinedIngredients implements CombinedIngredients {

    @Override
    public class_1856 all(class_1856... ingredients) {
        Objects.requireNonNull(ingredients, "ingredients is null");
        for (class_1856 ingredient : ingredients) Objects.requireNonNull(ingredient, "ingredient is null");
        return DefaultCustomIngredients.all(ingredients);
    }

    @Override
    public class_1856 any(class_1856... ingredients) {
        Objects.requireNonNull(ingredients, "ingredients is null");
        for (class_1856 ingredient : ingredients) Objects.requireNonNull(ingredient, "ingredient is null");
        return DefaultCustomIngredients.any(ingredients);
    }

    @Override
    public class_1856 difference(class_1856 ingredient, class_1856 subtracted) {
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(subtracted, "subtracted is null");
        return DefaultCustomIngredients.difference(ingredient, subtracted);
    }

    @Override
    public class_1856 components(class_1799 itemStack) {
        Objects.requireNonNull(itemStack, "item stack is null");
        return DefaultCustomIngredients.components(itemStack);
    }
}
