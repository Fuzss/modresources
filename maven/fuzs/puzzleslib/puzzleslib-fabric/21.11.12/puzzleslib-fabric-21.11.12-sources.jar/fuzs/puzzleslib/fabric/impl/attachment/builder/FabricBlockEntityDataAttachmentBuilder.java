package fuzs.puzzleslib.fabric.impl.attachment.builder;

import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_2586;
import net.minecraft.class_5455;

public final class FabricBlockEntityDataAttachmentBuilder<V> extends FabricDataAttachmentBuilder<class_2586, V, DataAttachmentRegistry.BlockEntityBuilder<V>> implements DataAttachmentRegistry.BlockEntityBuilder<V> {

    @Override
    public DataAttachmentRegistry.BlockEntityBuilder<V> getThis() {
        return this;
    }

    @Override
    public DataAttachmentRegistry.BlockEntityBuilder<V> defaultValue(Predicate<class_2586> defaultFilter, Function<class_5455, V> defaultValueProvider) {
        Objects.requireNonNull(defaultFilter, "default filter is null");
        Objects.requireNonNull(defaultValueProvider, "default value provider is null");
        this.defaultValues.put(defaultFilter, defaultValueProvider);
        return this;
    }

    @Override
    protected class_5455 getRegistryAccess(class_2586 holder) {
        return holder.method_10997().method_30349();
    }
}
