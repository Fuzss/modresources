package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.mojang.serialization.MapCodec;
import fuzs.puzzleslib.api.client.core.v1.context.ItemModelsContext;
import java.util.Objects;
import net.minecraft.class_10401;
import net.minecraft.class_10402;
import net.minecraft.class_10439;
import net.minecraft.class_10443;
import net.minecraft.class_10459;
import net.minecraft.class_10460;
import net.minecraft.class_10482;
import net.minecraft.class_10493;
import net.minecraft.class_10494;
import net.minecraft.class_10515;
import net.minecraft.class_10517;
import net.minecraft.class_1800;
import net.minecraft.class_2960;

public final class ItemModelsContextFabricImpl implements ItemModelsContext {

    @Override
    public void registerItemModel(class_2960 identifier, MapCodec<? extends class_10439.class_10441> codec) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(codec, "codec is null");
        class_10443.field_55336.method_65325(identifier, codec);
    }

    @Override
    public void registerSpecialModelRenderer(class_2960 identifier, MapCodec<? extends class_10515.class_10516> codec) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(codec, "codec is null");
        class_10517.field_55453.method_65325(identifier, codec);
    }

    @Override
    public void registerItemTintSource(class_2960 identifier, MapCodec<? extends class_10401> codec) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(codec, "codec is null");
        class_10402.field_55235.method_65325(identifier, codec);
    }

    @Override
    public void registerSelectItemModelProperty(class_2960 identifier, class_10494.class_10495<?, ?> type) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(type, "type is null");
        class_10493.field_55421.method_65325(identifier, type);
    }

    @Override
    public void registerConditionalItemModelProperty(class_2960 identifier, MapCodec<? extends class_10460> codec) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(codec, "codec is null");
        class_10459.field_55372.method_65325(identifier, codec);
    }

    @Override
    public void registerRangeSelectItemModelProperty(class_2960 identifier, MapCodec<? extends class_1800> codec) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(codec, "codec is null");
        class_10482.field_55408.method_65325(identifier, codec);
    }
}
