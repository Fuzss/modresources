package fuzs.puzzleslib.api.client.event.v1.model;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import net.minecraft.class_10439;
import net.minecraft.class_1087;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7775;

public final class ModelBakingEvents {
    public static final EventInvoker<BeforeBlock> BEFORE_BLOCK = EventInvoker.lookup(BeforeBlock.class);
    public static final EventInvoker<AfterBlock> AFTER_BLOCK = EventInvoker.lookup(AfterBlock.class);
    public static final EventInvoker<BeforeItem> BEFORE_ITEM = EventInvoker.lookup(BeforeItem.class);
    public static final EventInvoker<AfterItem> AFTER_ITEM = EventInvoker.lookup(AfterItem.class);

    private ModelBakingEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface BeforeBlock {

        /**
         * An event that runs for every unbaked block model. Allows for replacing the model.
         *
         * @param blockState   the block state the model is loaded for
         * @param unbakedModel the unbaked block model
         * @param modelBaker   the model baker instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<class_1087.class_9979> onBeforeBakeBlock(class_2680 blockState, class_1087.class_9979 unbakedModel, class_7775 modelBaker);
    }

    @FunctionalInterface
    public interface AfterBlock {

        /**
         * An event that runs for every baked block model. Allows for replacing the model.
         *
         * @param blockState   the block state the model is loaded for
         * @param bakedModel   the baked block model
         * @param unbakedModel the original unbaked block model
         * @param modelBaker   the model baker instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<class_1087> onAfterBakeBlock(class_2680 blockState, class_1087 bakedModel, class_1087.class_9979 unbakedModel, class_7775 modelBaker);
    }

    @FunctionalInterface
    public interface BeforeItem {

        /**
         * An event that runs for every unbaked item model. Allows for replacing the model.
         *
         * @param identifier the identifier for the item
         * @param unbakedModel     the unbaked item model
         * @param context          the item baking context instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<class_10439.class_10441> onBeforeBakeItem(class_2960 identifier, class_10439.class_10441 unbakedModel, class_10439.class_10440 context);
    }

    @FunctionalInterface
    public interface AfterItem {

        /**
         * An event that runs for every baked item model. Allows for replacing the model.
         *
         * @param identifier the identifier for the item
         * @param bakedModel       the baked item model
         * @param unbakedModel     the original unbaked item model
         * @param context          the item baking context instance
         * @return <ul>
         *         <li>{@link EventResultHolder#interrupt(Object)} to replace the model</li>
         *         <li>{@link EventResultHolder#pass()} to allow the original model to be used</li>
         *         </ul>
         */
        EventResultHolder<class_10439> onAfterBakeItem(class_2960 identifier, class_10439 bakedModel, class_10439.class_10441 unbakedModel, class_10439.class_10440 context);
    }
}
