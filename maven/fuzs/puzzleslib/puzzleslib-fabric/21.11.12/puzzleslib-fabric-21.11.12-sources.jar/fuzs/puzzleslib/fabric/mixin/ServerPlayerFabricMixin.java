package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.authlib.GameProfile;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.fabric.impl.event.CapturedDropsEntity;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.OptionalInt;
import net.minecraft.class_1263;
import net.minecraft.class_1282;
import net.minecraft.class_1496;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

@Mixin(class_3222.class)
abstract class ServerPlayerFabricMixin extends class_1657 implements CapturedDropsEntity {

    public ServerPlayerFabricMixin(class_1937 level, GameProfile gameProfile) {
        super(level, gameProfile);
    }

    @Inject(method = "drop(Z)V",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/server/level/ServerPlayer;drop(Lnet/minecraft/world/item/ItemStack;ZZ)Lnet/minecraft/world/entity/item/ItemEntity;"),
            cancellable = true)
    public void drop(CallbackInfo callback, @Local class_1799 itemStack) {
        EventResult eventResult = FabricPlayerEvents.ITEM_TOSS.invoker()
                .onItemToss(class_3222.class.cast(this), itemStack);
        if (eventResult.isInterrupt()) {
            callback.cancel();
        }
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    public void die(class_1282 damageSource, CallbackInfo callback) {
        EventResult eventResult = FabricLivingEvents.LIVING_DEATH.invoker().onLivingDeath(this, damageSource);
        if (eventResult.isInterrupt()) {
            callback.cancel();
        }
    }

    @Inject(method = "openMenu", at = @At("TAIL"))
    public void openMenu(@Nullable class_3908 menu, CallbackInfoReturnable<OptionalInt> callback) {
        FabricPlayerEvents.CONTAINER_OPEN.invoker().onContainerOpen(class_3222.class.cast(this), this.field_7512);
    }

    @Inject(method = "openHorseInventory", at = @At("TAIL"))
    public void openHorseInventory(class_1496 horse, class_1263 inventory, CallbackInfo callback) {
        FabricPlayerEvents.CONTAINER_OPEN.invoker().onContainerOpen(class_3222.class.cast(this), this.field_7512);
    }

    @Inject(method = "doCloseContainer",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/world/inventory/InventoryMenu;transferState(Lnet/minecraft/world/inventory/AbstractContainerMenu;)V",
                     shift = At.Shift.AFTER))
    public void doCloseContainer(CallbackInfo callback) {
        FabricPlayerEvents.CONTAINER_CLOSE.invoker()
                .onContainerClose(class_3222.class.cast(this), this.field_7512);
    }

    @Inject(method = "stopSleepInBed", at = @At("HEAD"))
    public void stopSleepInBed(boolean wakeImmediately, boolean updateLevelForSleepingPlayers, CallbackInfo callback) {
        FabricPlayerEvents.STOP_SLEEP_IN_BED.invoker()
                .onStopSleepInBed(class_3222.class.cast(this), !wakeImmediately && !updateLevelForSleepingPlayers);
    }
}
