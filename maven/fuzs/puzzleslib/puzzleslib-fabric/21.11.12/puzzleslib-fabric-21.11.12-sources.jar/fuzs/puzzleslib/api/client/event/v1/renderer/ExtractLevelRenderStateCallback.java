package fuzs.puzzleslib.api.client.event.v1.renderer;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_11658;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import net.minecraft.class_9922;
import org.joml.Matrix4f;
import org.joml.Vector4f;

@FunctionalInterface
public interface ExtractLevelRenderStateCallback {
    EventInvoker<ExtractLevelRenderStateCallback> EVENT = EventInvoker.lookup(ExtractLevelRenderStateCallback.class);

    /**
     * Called during
     * {@link class_761#method_22710(class_9922, class_9779, boolean, class_4184, Matrix4f, Matrix4f,
     * Matrix4f, GpuBufferSlice, Vector4f, boolean)}, for setting up the render state of the level for future
     * rendering.
     *
     * @param levelRenderer the level renderer
     * @param renderState   the level render state
     * @param level         the level
     * @param camera        the camera
     * @param frustum       the frustum
     * @param deltaTracker  the delta tracker
     */
    void onExtractLevelRenderState(class_761 levelRenderer, class_11658 renderState, class_638 level, class_4184 camera, class_4604 frustum, class_9779 deltaTracker);
}
