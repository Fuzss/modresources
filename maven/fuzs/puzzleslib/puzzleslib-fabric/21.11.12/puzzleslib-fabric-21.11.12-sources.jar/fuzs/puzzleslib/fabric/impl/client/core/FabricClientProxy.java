package fuzs.puzzleslib.fabric.impl.client.core;

import fuzs.forgeconfigapiport.fabric.api.v5.client.ConfigScreenFactoryRegistry;
import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.api.client.renderer.v1.model.MutableBakedQuad;
import fuzs.puzzleslib.api.core.v1.context.PayloadTypesContext;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import fuzs.puzzleslib.fabric.impl.client.config.CustomConfigurationScreen;
import fuzs.puzzleslib.fabric.impl.client.core.context.GuiLayersContextFabricImpl;
import fuzs.puzzleslib.fabric.impl.client.event.FabricClientEventInvokers;
import fuzs.puzzleslib.fabric.impl.client.key.FabricKeyMappingHelper;
import fuzs.puzzleslib.fabric.impl.core.FabricCommonProxy;
import fuzs.puzzleslib.fabric.impl.core.context.PayloadTypesContextFabricImpl;
import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import fuzs.puzzleslib.impl.core.context.ModConstructorImpl;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.RenderStateDataKey;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudStatusBarHeightRegistry;
import net.minecraft.class_10017;
import net.minecraft.class_11908;
import net.minecraft.class_1293;
import net.minecraft.class_169;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_2792;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_4719;
import net.minecraft.class_4722;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_634;
import net.minecraft.class_636;
import net.minecraft.class_638;
import net.minecraft.class_777;
import net.minecraft.class_8000;
import net.minecraft.class_8673;
import net.minecraft.class_8674;
import net.minecraft.class_8709;
import net.minecraft.class_8710;
import net.minecraft.client.multiplayer.*;
import org.jspecify.annotations.Nullable;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.IntFunction;

public class FabricClientProxy extends FabricCommonProxy implements ClientProxyImpl {
    private final Map<class_169<?>, RenderStateDataKey<?>> entityRenderStateKeys = new IdentityHashMap<>();

    @Override
    public void registerAllLoadingHandlers() {
        super.registerAllLoadingHandlers();
        FabricClientEventInvokers.registerLoadingHandlers();
    }

    @Override
    public void registerAllEventHandlers() {
        super.registerAllEventHandlers();
        FabricClientEventInvokers.registerEventHandlers();
    }

    @Override
    public boolean hasChannel(class_2547 packetListener, class_8710.class_9154<?> type) {
        if (super.hasChannel(packetListener, type)) {
            return true;
        } else if (packetListener instanceof class_8674) {
            return ClientConfigurationNetworking.canSend(type);
        } else if (packetListener instanceof class_634) {
            return ClientPlayNetworking.canSend(type);
        } else {
            return false;
        }
    }

    @Override
    public class_2535 getConnection(class_2547 packetListener) {
        return packetListener instanceof class_8673 clientPacketListener ?
                clientPacketListener.field_45589 : super.getConnection(packetListener);
    }

    @Override
    public PayloadTypesContext createPayloadTypesContext(String modId) {
        return new PayloadTypesContextFabricImpl.ClientImpl(modId);
    }

    @Override
    public void setupHandshakePayload(class_8710.class_9154<class_8709> payloadType) {
        super.setupHandshakePayload(payloadType);
        ClientPlayNetworking.registerGlobalReceiver(payloadType,
                (class_8709 payload, ClientPlayNetworking.Context context) -> {
                    // NO-OP
                });
    }

    @Override
    public boolean shouldStartDestroyBlock(class_2338 blockPos) {
        class_636 gameMode = class_310.method_1551().field_1761;
        Objects.requireNonNull(gameMode, "game mode is null");
        return !gameMode.method_2923() || !gameMode.method_2922(blockPos);
    }

    @Override
    public void startClientPrediction(class_1937 level, IntFunction<class_2596<class_2792>> predictiveAction) {
        class_636 gameMode = class_310.method_1551().field_1761;
        Objects.requireNonNull(gameMode, "game mode is null");
        gameMode.method_41931((class_638) level, predictiveAction::apply);
    }

    @Override
    public ModConstructorImpl<ClientModConstructor> getClientModConstructorImpl() {
        return new FabricClientModConstructor();
    }

    @Override
    public KeyMappingHelper getKeyMappingActivationHelper() {
        return new FabricKeyMappingHelper();
    }

    @Override
    public <T> @Nullable T getRenderProperty(class_10017 renderState, class_169<T> key) {
        return renderState.getData(this.getRenderStateDataKey(key));
    }

    @Override
    public <T> void setRenderProperty(class_10017 renderState, class_169<T> key, @Nullable T t) {
        renderState.setData(this.getRenderStateDataKey(key), t);
    }

    @SuppressWarnings("unchecked")
    private <T> RenderStateDataKey<T> getRenderStateDataKey(class_169<T> key) {
        return (RenderStateDataKey<T>) this.entityRenderStateKeys.computeIfAbsent(key,
                (class_169<?> keyX) -> RenderStateDataKey.create(keyX::toString));
    }

    @Override
    public boolean isKeyActiveAndMatches(class_304 keyMapping, class_11908 keyEvent) {
        return keyMapping.method_1417(keyEvent);
    }

    @Override
    public class_5684 createImageComponent(class_5632 imageComponent) {
        class_5684 component = TooltipComponentCallback.EVENT.invoker().getComponent(imageComponent);
        return Objects.requireNonNullElseGet(component, () -> class_5684.method_32663(imageComponent));
    }

    @Override
    public boolean onRenderTooltip(class_332 guiGraphics, class_327 font, int mouseX, int mouseY, List<class_5684> components, class_8000 positioner) {
        return FabricGuiEvents.RENDER_TOOLTIP.invoker()
                .onRenderTooltip(guiGraphics, font, mouseX, mouseY, components, positioner)
                .isInterrupt();
    }

    @Override
    public MutableBakedQuad getMutableBakedQuad(class_777 bakedQuad) {
        return new MutableBakedQuad(bakedQuad) {
            // NO-OP
        };
    }

    @Override
    public boolean isEffectVisibleInInventory(class_1293 mobEffect) {
        return true;
    }

    @Override
    public boolean isEffectVisibleInGui(class_1293 mobEffect) {
        return true;
    }

    @Override
    public void registerWoodType(class_4719 woodType) {
        // This might register fine, but if another mod loads the Sheets class too early, it will be missing.
        // Also, wrap this in the event, so we ourselves do not load the Sheets class too early.
        ClientLifecycleEvents.CLIENT_STARTED.register((class_310 minecraft) -> {
            class_4722.field_21712.put(woodType, class_4722.method_24064(woodType));
            class_4722.field_40515.put(woodType, class_4722.method_45782(woodType));
        });
    }

    @Override
    public void registerConfigurationScreen(String modId, String... otherModIds) {
        ConfigScreenFactoryRegistry.INSTANCE.register(modId, (String string, class_437 screen) -> {
            return new CustomConfigurationScreen(string, screen, otherModIds);
        });
    }

    @Override
    public int getLeftStatusBarHeight(class_2960 identifier) {
        class_2960 vanillaGuiLayer = GuiLayersContextFabricImpl.getVanillaGuiLayer(identifier);
        return HudStatusBarHeightRegistry.getHeight(vanillaGuiLayer);
    }

    @Override
    public int getRightStatusBarHeight(class_2960 identifier) {
        class_2960 vanillaGuiLayer = GuiLayersContextFabricImpl.getVanillaGuiLayer(identifier);
        return HudStatusBarHeightRegistry.getHeight(vanillaGuiLayer);
    }
}
