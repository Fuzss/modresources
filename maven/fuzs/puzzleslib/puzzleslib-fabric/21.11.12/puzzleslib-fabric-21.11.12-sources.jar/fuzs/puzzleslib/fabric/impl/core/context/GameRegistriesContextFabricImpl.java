package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.GameRegistriesContext;
import java.util.Objects;
import net.minecraft.class_2378;

public final class GameRegistriesContextFabricImpl implements GameRegistriesContext {

    @Override
    public <T> void registerRegistry(class_2378<T> registry) {
        Objects.requireNonNull(registry, "registry is null");
        // new registries are directly registered on Fabric upon construction
    }
}
