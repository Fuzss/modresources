package fuzs.puzzleslib.api.data.v2;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.serialization.JsonOps;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_161;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2446;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2960;
import net.minecraft.class_3981;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5794;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7701;
import net.minecraft.class_7784;
import net.minecraft.class_7800;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8074;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.stream.Stream;

public abstract class AbstractRecipeProvider extends class_2446 implements class_2405 {
    private static final class_5455 REGISTRY_ACCESS = class_5455.method_40302(class_7923.field_41167);
    private static final class_8790 RECIPE_OUTPUT = ProxyImpl.get().getThrowingRecipeOutput();
    /**
     * @see #generateFor(BlockSetFamily, Map)
     */
    public static final Map<BlockSetVariant, FamilyRecipeProvider> VARIANT_STONE_PROVIDERS = ImmutableMap.<BlockSetVariant, FamilyRecipeProvider>builder()
            .put(BlockSetVariant.CHISELED, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.CUT, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.SLAB, FamilyRecipeProvider.stonecutting(2))
            .put(BlockSetVariant.STAIRS, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.POLISHED, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.WALL, FamilyRecipeProvider.stonecutting())
            .build();

    private final String modId;
    private final class_7784 packOutput;
    private final CompletableFuture<class_7225.class_7874> registries;

    public AbstractRecipeProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractRecipeProvider(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
        super(REGISTRY_ACCESS, RECIPE_OUTPUT);
        this.modId = modId;
        this.packOutput = packOutput;
        this.registries = registries;
    }

    @Nullable
    public static <T> JsonElement searchAndReplaceValue(@Nullable JsonElement jsonElement, T searchFor, T replaceWith) {
        Objects.requireNonNull(searchFor, "search for is null");
        Objects.requireNonNull(replaceWith, "replace with is null");
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            if (jsonElement.isJsonPrimitive()) {
                JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
                if (jsonPrimitive.isNumber()) {
                    if (searchFor.equals(jsonPrimitive.getAsNumber())) {
                        return new JsonPrimitive((Number) replaceWith);
                    }
                } else if (jsonPrimitive.isBoolean()) {
                    if (searchFor.equals(jsonPrimitive.getAsBoolean())) {
                        return new JsonPrimitive((Boolean) replaceWith);
                    }
                } else if (jsonPrimitive.isString()) {
                    if (searchFor.toString().equals(jsonPrimitive.getAsString())) {
                        return new JsonPrimitive(replaceWith.toString());
                    }
                }

                return jsonElement;
            } else if (jsonElement.isJsonArray()) {
                JsonArray jsonArray = jsonElement.getAsJsonArray();
                for (int i = 0; i < jsonArray.size(); i++) {
                    jsonArray.set(i, searchAndReplaceValue(jsonArray.get(i), searchFor, replaceWith));
                }
            } else if (jsonElement.isJsonObject()) {
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                    entry.setValue(searchAndReplaceValue(entry.getValue(), searchFor, replaceWith));
                }
            }
        }

        return jsonElement;
    }

    /**
     * @see #generateFor(BlockSetFamily, Map)
     */
    public static Map<BlockSetVariant, FamilyRecipeProvider> createVariantWoodProviders(BlockSetFamily blockSetFamily, class_2248 strippedBlock) {
        return ImmutableMap.<BlockSetVariant, FamilyRecipeProvider>builder()
                .put(BlockSetVariant.HANGING_SIGN,
                        (class_2446 recipeProvider, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            recipeProvider.method_46208(result, strippedBlock);
                        })
                .put(BlockSetVariant.SHELF,
                        (class_2446 recipeProvider, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            recipeProvider.method_73067(result, strippedBlock);
                        })
                .put(BlockSetVariant.BOAT,
                        (class_2446 recipeProvider, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            recipeProvider.method_24478(result, input);
                        })
                .put(BlockSetVariant.CHEST_BOAT,
                        (class_2446 recipeProvider, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            class_6880.class_6883<class_1792> boatItem = blockSetFamily.getItem(BlockSetVariant.BOAT);
                            Objects.requireNonNull(boatItem, "boat item is null");
                            recipeProvider.method_42754(result, boatItem.comp_349());
                        })
                .build();
    }

    @Deprecated(forRemoval = true)
    public void generateForBlockFamilies(Stream<class_5794> blockFamilies) {
        blockFamilies.filter(class_5794::method_33478)
                .forEach((class_5794 blockFamily) -> this.method_33535(blockFamily, class_7701.field_40183));
    }

    public void generateFor(BlockSetFamily blockSetFamily, Map<BlockSetVariant, FamilyRecipeProvider> variants) {
        class_5794 blockFamily = blockSetFamily.getBlockFamily();
        this.method_33535(blockFamily, class_7701.field_40183);
        if (blockFamily.method_33478()) {
            blockSetFamily.getItemVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_1792> holder) -> {
                FamilyRecipeProvider recipeProvider = variants.get(variant);
                if (recipeProvider != null) {
                    class_1935 baseBlock;
                    if (variant.toVanilla() != null) {
                        baseBlock = this.method_33533(blockFamily, variant.toVanilla());
                    } else {
                        baseBlock = blockSetFamily.getBaseBlock().comp_349();
                    }

                    recipeProvider.create(this,
                            holder.comp_349(),
                            baseBlock,
                            blockFamily.method_33479(),
                            blockFamily.method_33480());
                }
            });
        }
    }

    public void stair(class_7800 recipeCategory, class_1935 resultItem, class_1935 ingredientItem) {
        this.stairBuilder(recipeCategory, resultItem, class_1856.method_8101(ingredientItem))
                .method_33530(method_32807(ingredientItem), this.method_10426(ingredientItem))
                .method_10431(this.field_53721);
    }

    public class_5797 stairBuilder(class_7800 recipeCategory, class_1935 resultItem, class_1856 ingredient) {
        return this.method_62747(recipeCategory, resultItem, 4)
                .method_10428('#', ingredient)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###");
    }

    public void metalCooking(class_1935 resultItem, class_1935 ingredientItem, float experience) {
        this.metalCooking(resultItem, ingredientItem, experience, 200);
    }

    public void metalCooking(class_1935 resultItem, class_1935 ingredientItem, float experience, int baseCookingTime) {
        class_2454.method_17802(class_1856.method_8101(ingredientItem),
                class_7800.field_40642,
                resultItem,
                experience,
                baseCookingTime).method_10469(method_32807(ingredientItem), this.method_10426(ingredientItem)).method_10431(this.field_53721);
        class_2454.method_10473(class_1856.method_8101(ingredientItem),
                        class_7800.field_40642,
                        resultItem,
                        experience,
                        baseCookingTime / 2)
                .method_10469(method_32807(ingredientItem), this.method_10426(ingredientItem))
                .method_36443(this.field_53721, method_36452(resultItem));
    }

    public void foodCooking(class_1935 resultItem, class_1935 ingredientItem) {
        this.foodCooking(resultItem, ingredientItem, 0.35F, 200);
    }

    public void foodCooking(class_1935 resultItem, class_1935 ingredientItem, float experienceReward, int baseCookingTime) {
        class_2454.method_17802(class_1856.method_8101(ingredientItem),
                class_7800.field_40640,
                resultItem,
                experienceReward,
                baseCookingTime).method_10469(method_32807(ingredientItem), this.method_10426(ingredientItem)).method_10431(this.field_53721);
        class_2454.method_35918(class_1856.method_8101(ingredientItem),
                        class_7800.field_40640,
                        resultItem,
                        experienceReward,
                        baseCookingTime / 2)
                .method_10469(method_32807(ingredientItem), this.method_10426(ingredientItem))
                .method_36443(this.field_53721, getCraftingMethodRecipeName(resultItem, class_1865.field_17085));
        class_2454.method_35916(class_1856.method_8101(ingredientItem),
                        class_7800.field_40640,
                        resultItem,
                        experienceReward,
                        baseCookingTime * 3)
                .method_10469(method_32807(ingredientItem), this.method_10426(ingredientItem))
                .method_36443(this.field_53721, getCraftingMethodRecipeName(resultItem, class_1865.field_17347));
    }

    public class_5797 stonecutterResultFromBaseBuilder(class_7800 recipeCategory, class_1935 resultItem, class_1856 ingredient) {
        return this.stonecutterResultFromBaseBuilder(recipeCategory, resultItem, ingredient, 1);
    }

    public class_5797 stonecutterResultFromBaseBuilder(class_7800 recipeCategory, class_1935 resultItem, class_1856 ingredient, int count) {
        return class_3981.method_17969(ingredient, recipeCategory, resultItem, count);
    }

    public void smithing(class_7800 recipeCategory, class_1935 resultItem, class_1935 templateItem, class_1935 baseItem, class_1935 materialItem) {
        class_8074.method_48535(class_1856.method_8101(templateItem),
                        class_1856.method_8101(baseItem),
                        class_1856.method_8101(materialItem),
                        recipeCategory,
                        resultItem.method_8389())
                .method_48536(method_32807(materialItem), this.method_10426(materialItem))
                .method_48538(this.field_53721, getSmithingRecipeName(resultItem));
    }

    public void waxing(class_1935 resultItem, class_1935 ingredientItem) {
        class_2450.method_62770(this.field_53722, class_7800.field_40634, resultItem)
                .method_10454(ingredientItem)
                .method_10454(class_1802.field_20414)
                .method_10452(method_33716(resultItem))
                .method_10442(method_32807(ingredientItem), this.method_10426(ingredientItem))
                .method_36443(this.field_53721, method_33714(resultItem, class_1802.field_20414));
    }

    public static String getCraftingMethodRecipeName(class_1935 resultItem, class_1865<?> recipeSerializer) {
        class_2960 identifier = class_7923.field_41189.method_10221(recipeSerializer);
        Objects.requireNonNull(identifier, "identifier is null");
        return getCraftingMethodRecipeName(resultItem, identifier.method_12832());
    }

    public static String getCraftingMethodRecipeName(class_1935 resultItem, String craftingMethod) {
        return method_33716(resultItem) + "_from_" + craftingMethod;
    }

    public static String getStonecuttingRecipeName(class_1935 resultItem, class_1935 material) {
        return method_33714(resultItem, material) + "_stonecutting";
    }

    public static String getSmithingRecipeName(class_1935 resultItem) {
        return method_33716(resultItem) + "_smithing";
    }

    public static String getHasName(class_6862<class_1792> tagKey) {
        return "has_" + tagKey.comp_327().method_12832();
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 output) {
        // this must not be CompletableFuture::thenApply, as not all futures are guaranteed to complete in time,
        // leading to some files silently failing to generate at all
        return this.registries.thenCompose((class_7225.class_7874 registries) -> {
            List<CompletableFuture<?>> completableFutures = new ArrayList<>();
            class_8790 recipeOutput = ProxyImpl.get()
                    .getRecipeProviderOutput(output, this.modId, this.packOutput, registries, completableFutures::add);
            this.injectRegistries(registries, recipeOutput);
            this.addRecipes(recipeOutput);
            return CompletableFuture.allOf(completableFutures.toArray(CompletableFuture[]::new));
        }).thenRun(() -> {
            this.injectRegistries(REGISTRY_ACCESS, RECIPE_OUTPUT);
        });
    }

    private void injectRegistries(class_7225.class_7874 registries, class_8790 recipeOutput) {
        super.field_48981 = registries;
        super.field_53722 = registries.method_46762(class_7924.field_41197);
        super.field_53721 = recipeOutput;
    }

    public final class_7225.class_7874 registries() {
        Preconditions.checkState(super.field_48981 != REGISTRY_ACCESS, "registry access is empty");
        return super.field_48981;
    }

    public final class_7871<class_1792> items() {
        Preconditions.checkState(super.field_48981 != REGISTRY_ACCESS, "registry access is empty");
        return super.field_53722;
    }

    @Override
    public void method_10419() {
        throw new UnsupportedOperationException();
    }

    public abstract void addRecipes(class_8790 recipeOutput);

    @Override
    public String method_10321() {
        return "Recipes";
    }

    @FunctionalInterface
    public interface FamilyRecipeProvider {
        void create(class_2446 recipeProvider, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy);

        static FamilyRecipeProvider stonecutting() {
            return stonecutting(1);
        }

        static FamilyRecipeProvider stonecutting(int count) {
            return (class_2446 recipeProvider, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                class_3981 recipeBuilder = class_3981.method_17969(class_1856.method_8101(input),
                        class_7800.field_40634,
                        result,
                        count);
                recipeBuilder.method_17970(recipeUnlockedBy.orElseGet(() -> method_32807(input)),
                        recipeProvider.method_10426(input));
                recipeBuilder.method_36443(recipeProvider.field_53721, getStonecuttingRecipeName(result, input));
            };
        }
    }

    @ApiStatus.Internal
    public static abstract class RecipeOutputImpl implements class_8790 {
        private final class_7403 output;
        private final String modId;
        private final class_7784.class_7489 recipePathProvider;
        private final class_7784.class_7489 advancementPathProvider;
        private final class_7225.class_7874 registries;
        private final Consumer<CompletableFuture<?>> consumer;
        private final Set<class_5321<class_1860<?>>> recipes = new HashSet<>();

        protected RecipeOutputImpl(class_7403 output, String modId, class_7784 packOutput, class_7225.class_7874 registries, Consumer<CompletableFuture<?>> consumer) {
            this.output = output;
            this.modId = modId;
            this.recipePathProvider = packOutput.method_60917(class_7924.field_52178);
            this.advancementPathProvider = packOutput.method_60917(class_7924.field_52177);
            this.registries = registries;
            this.consumer = consumer;
        }

        @Override
        public void method_53819(class_5321<class_1860<?>> resourceKey, class_1860<?> recipe, @Nullable class_8779 advancementHolder) {
            final class_5321<class_1860<?>> originalResourceKey = resourceKey;
            // relocate all recipes to the mod id, so they do not depend on the item namespace which would
            // place e.g. new recipes for vanilla items in 'minecraft' which is not desired
            class_2960 identifier = class_2960.method_60655(this.modId, resourceKey.method_29177().method_12832());
            resourceKey = class_5321.method_29179(class_7924.field_52178, identifier);
            if (!this.recipes.add(resourceKey)) {
                throw new IllegalStateException("Duplicate recipe " + resourceKey);
            } else {
                this.consumer.accept(class_2405.method_53496(this.output,
                        this.registries,
                        class_1860.field_47319,
                        recipe,
                        this.recipePathProvider.method_44107(resourceKey.method_29177())));
                if (advancementHolder != null) {
                    class_6903<JsonElement> registryOps = this.registries.method_57093(JsonOps.INSTANCE);
                    JsonElement jsonElement = class_161.field_47179.encodeStart(registryOps, advancementHolder.comp_1920())
                            .getOrThrow();
                    jsonElement = searchAndReplaceValue(jsonElement, originalResourceKey, resourceKey);
                    class_2960 advancementLocation = class_2960.method_60655(this.modId,
                            advancementHolder.comp_1919().method_12832());
                    this.consumer.accept(class_2405.method_10320(this.output,
                            jsonElement,
                            this.advancementPathProvider.method_44107(advancementLocation)));
                }
            }
        }

        @SuppressWarnings("removal")
        @Override
        public class_161.class_162 method_53818() {
            return class_161.class_162.method_51698().method_708(class_5797.field_39377);
        }

        @Override
        public void method_62738() {
            throw new UnsupportedOperationException();
        }
    }
}
