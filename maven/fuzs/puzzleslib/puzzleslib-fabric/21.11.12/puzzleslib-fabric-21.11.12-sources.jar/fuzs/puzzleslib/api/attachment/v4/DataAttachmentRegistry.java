package fuzs.puzzleslib.api.attachment.v4;

import com.google.common.base.Predicates;
import com.mojang.serialization.Codec;
import fuzs.puzzleslib.api.network.v4.PlayerSet;
import fuzs.puzzleslib.impl.attachment.DataAttachmentRegistryImpl;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_5455;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * A registry for creating new attachment types.
 */
public final class DataAttachmentRegistry {

    private DataAttachmentRegistry() {
        // NO-OP
    }

    /**
     * @param <V> attachment value type
     * @return the entity attachment type builder
     */
    public static <V> EntityBuilder<V> entityBuilder() {
        return DataAttachmentRegistryImpl.INSTANCE.getEntityTypeBuilder();
    }

    /**
     * @param <V> attachment value type
     * @return the block entity attachment type builder
     */
    public static <V> BlockEntityBuilder<V> blockEntityBuilder() {
        return DataAttachmentRegistryImpl.INSTANCE.getBlockEntityTypeBuilder();
    }

    /**
     * @param <V> attachment value type
     * @return the level chunk attachment type builder
     */
    public static <V> LevelChunkBuilder<V> levelChunkBuilder() {
        return DataAttachmentRegistryImpl.INSTANCE.getLevelChunkBuilder();
    }

    /**
     * @param <V> attachment value type
     * @return the level attachment type builder
     */
    public static <V> LevelBuilder<V> levelBuilder() {
        return DataAttachmentRegistryImpl.INSTANCE.getLevelBuilder();
    }

    /**
     * General attachment type builder.
     *
     * @param <T> attachment holder type
     * @param <V> attachment value type
     */
    public interface Builder<T, V, B extends Builder<T, V, B>> {

        /**
         * @return the builder instance
         */
        B getThis();

        /**
         * Set a default value for all attachment holders.
         *
         * @param defaultValue the default value
         * @return the builder instance
         */
        default B defaultValue(V defaultValue) {
            return this.defaultValue((class_5455 registries) -> defaultValue);
        }

        /**
         * Set a default value for all attachment holders.
         *
         * @param defaultValueProvider the default value provider
         * @return the builder instance
         */
        B defaultValue(Function<class_5455, V> defaultValueProvider);

        /**
         * Allow the attachment type to be serialised.
         *
         * @param codec the attachment value codec
         * @return the builder instance
         */
        B persistent(Codec<V> codec);

        /**
         * Automatically synchronise the attachment value with remotes.
         *
         * @param streamCodec            the attachment value stream codec
         * @param synchronizationTargets the remotes to synchronise the attachment value with; the following are
         *                               recommended:
         *                               <ul>
         *                               <li>{@link PlayerSet#ofEntity(class_1297)}</li>
         *                               <li>{@link PlayerSet#nearEntity(class_1297)}</li>
         *                               <li>{@link PlayerSet#nearBlockEntity(class_2586)}</li>
         *                               <li>{@link PlayerSet#nearChunk(class_2818)}</li>
         *                               <li>{@link PlayerSet#inLevel(class_3218)}</li>
         *                               </ul>
         * @return the builder instance
         */
        B networkSynchronized(class_9139<? super class_9129, V> streamCodec, Function<T, PlayerSet> synchronizationTargets);

        /**
         * Build the attachment type.
         * <p>
         * Can be called multiple times with different inputs.
         *
         * @param identifier the identifier
         * @return the attachment type
         */
        DataAttachmentType<T, V> build(class_2960 identifier);
    }

    /**
     * Attachment type builder for multiple possible holder types.
     *
     * @param <T> attachment holder type
     * @param <V> attachment value type
     */
    public interface RegistryBuilder<T, V, B extends RegistryBuilder<T, V, B>> extends Builder<T, V, B> {

        @Override
        default B defaultValue(Function<class_5455, V> defaultValueProvider) {
            return this.defaultValue(Predicates.alwaysTrue(), defaultValueProvider);
        }

        /**
         * Set a default value for the provided holder type.
         *
         * @param holderType   the attachment holder type
         * @param defaultValue the default value
         * @return the builder instance
         */
        default B defaultValue(Class<? extends T> holderType, V defaultValue) {
            return this.defaultValue(holderType::isInstance, defaultValue);
        }

        /**
         * Set a default value for the provided holder type.
         *
         * @param defaultFilter the attachment holder filter
         * @param defaultValue  the default value
         * @return the builder instance
         */
        default B defaultValue(Predicate<T> defaultFilter, V defaultValue) {
            return this.defaultValue(defaultFilter, (class_5455 registries) -> defaultValue);
        }

        /**
         * Set a default value for the provided holder type.
         *
         * @param defaultFilter        the attachment holder filter
         * @param defaultValueProvider the default value provider
         * @return the builder instance
         */
        B defaultValue(Predicate<T> defaultFilter, Function<class_5455, V> defaultValueProvider);
    }

    /**
     * Attachment type builder for entities.
     *
     * @param <V> attachment value type
     */
    public interface EntityBuilder<V> extends RegistryBuilder<class_1297, V, EntityBuilder<V>> {

        /**
         * Set a default value for the provided entity type.
         *
         * @param entityType   the entity type
         * @param defaultValue the default value
         * @return the builder instance
         */
        default EntityBuilder<V> defaultValue(class_1299<?> entityType, V defaultValue) {
            return this.defaultValue((class_1297 entity) -> entity.method_5864() == entityType, defaultValue);
        }

        /**
         * Copy the attachment value when the entity dies.
         * <p>
         * Requires a persistent attachment type via {@link Builder#persistent(Codec)}.
         *
         * @return the builder instance
         */
        EntityBuilder<V> copyOnDeath();
    }

    /**
     * Attachment type builder for block entities.
     *
     * @param <V> attachment value type
     */
    public interface BlockEntityBuilder<V> extends RegistryBuilder<class_2586, V, BlockEntityBuilder<V>> {

        /**
         * Set a default value for the provided block entity type.
         *
         * @param blockEntityType the block entity type
         * @param defaultValue    the default value
         * @return the builder instance
         */
        default BlockEntityBuilder<V> defaultValue(class_2591<?> blockEntityType, V defaultValue) {
            return this.defaultValue((class_2586 blockEntity) -> {
                return blockEntity.method_11017() == blockEntityType;
            }, defaultValue);
        }
    }

    /**
     * Attachment type builder for chunks.
     *
     * @param <V> attachment value type
     */
    public interface LevelChunkBuilder<V> extends Builder<class_2818, V, LevelChunkBuilder<V>> {

    }

    /**
     * Attachment type builder for levels.
     *
     * @param <V> attachment value type
     */
    public interface LevelBuilder<V> extends Builder<class_1937, V, LevelBuilder<V>> {

    }
}
