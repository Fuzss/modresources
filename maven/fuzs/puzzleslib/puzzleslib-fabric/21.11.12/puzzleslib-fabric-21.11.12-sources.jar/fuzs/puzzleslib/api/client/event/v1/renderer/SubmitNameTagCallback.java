package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_10017;
import net.minecraft.class_11659;
import net.minecraft.class_12075;
import net.minecraft.class_4587;
import net.minecraft.class_897;

@FunctionalInterface
public interface SubmitNameTagCallback {
    EventInvoker<SubmitNameTagCallback> EVENT = EventInvoker.lookup(SubmitNameTagCallback.class);

    /**
     * Fires before the name tag of an entity is submitted.
     * <p>
     * For {@link net.minecraft.class_1007} this includes not only the name tag itself
     * but also the score text value.
     *
     * @param entityRenderer    the entity renderer instance
     * @param renderState       the entity render state
     * @param poseStack         the pose stack
     * @param nodeCollector     the submit node collector
     * @param cameraRenderState the camera render state
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the name tag from rendering</li>
     *         <li>{@link EventResult#PASS PASS} to allow the name tag to render if present</li>
     *         </ul>
     */
    EventResult onSubmitNameTag(class_897<?, ?> entityRenderer, class_10017 renderState, class_4587 poseStack, class_11659 nodeCollector, class_12075 cameraRenderState);
}
