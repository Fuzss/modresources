package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import net.minecraft.class_1296;
import net.minecraft.class_1299;
import net.minecraft.class_1429;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1429.class)
abstract class AnimalFabricMixin extends class_1296 {

    protected AnimalFabricMixin(class_1299<? extends class_1296> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "spawnChildFromBreeding", at = @At("STORE"))
    public class_1296 spawnChildFromBreeding(@Nullable class_1296 child, class_3218 serverLevel, class_1429 partner) {
        MutableValue<class_1296> defaultedChild = MutableValue.fromValue(child);
        if (FabricLivingEvents.BABY_ENTITY_SPAWN.invoker().onBabyEntitySpawn(this, partner, defaultedChild).isInterrupt()) {
            this.method_5614(6000);
            partner.method_5614(6000);
            this.resetLove();
            partner.method_6477();
            return null;
        } else {
            return defaultedChild.get();
        }
    }

    @Shadow
    public abstract void resetLove();
}
