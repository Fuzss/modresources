package fuzs.puzzleslib.impl.core.context;

import fuzs.puzzleslib.api.core.v1.ModContainer;
import fuzs.puzzleslib.api.core.v1.context.PayloadTypesContext;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_8710;

public abstract class PayloadTypesContextImpl implements PayloadTypesContext {
    private static final Map<Class<?>, class_8710.class_9154<?>> MESSAGE_TYPES = new IdentityHashMap<>();

    private final AtomicInteger discriminator = new AtomicInteger();
    protected final class_2960 channelName;

    protected PayloadTypesContextImpl(String modId) {
        this.channelName = class_2960.method_60655(modId, "main");
    }

    @SuppressWarnings("unchecked")
    public static <T extends class_8710> class_8710.class_9154<T> getPayloadType(Class<T> payloadClazz) {
        Objects.requireNonNull(payloadClazz, "payload class is null");
        class_8710.class_9154<T> payloadType = (class_8710.class_9154<T>) PayloadTypesContextImpl.MESSAGE_TYPES.get(
                payloadClazz);
        Objects.requireNonNull(payloadType, "payload type is null");
        return payloadType;
    }

    protected synchronized final <T extends class_8710> class_8710.class_9154<T> registerPayloadType(Class<T> clazz) {
        class_2960 identifier = this.channelName.method_48331("/" + this.discriminator.getAndIncrement());
        class_8710.class_9154<T> type = new class_8710.class_9154<>(identifier);
        MESSAGE_TYPES.put(clazz, type);
        return type;
    }

    protected final BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally(String payloadContext) {
        return (Throwable throwable, Consumer<class_2561> consumer) -> {
            String modName = ModContainer.getDisplayName(this.channelName.method_12836());
            consumer.accept(class_2561.method_43470("Receiving %s from %s failed: %s".formatted(payloadContext,
                    modName,
                    throwable.getMessage())));
        };
    }
}
