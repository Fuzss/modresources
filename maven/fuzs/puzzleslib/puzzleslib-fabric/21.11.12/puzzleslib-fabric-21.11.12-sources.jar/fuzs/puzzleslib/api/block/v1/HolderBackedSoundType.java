package fuzs.puzzleslib.api.block.v1;

import net.minecraft.class_2498;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_6880;

/**
 * An extended {@link class_2498} allowing for using {@link class_6880 Holders}, to allow for using
 * {@link class_3414 SoundEvents} that have not necessarily been registered yet.
 */
public class HolderBackedSoundType extends class_2498 {
    final class_6880<class_3414> breakSound;
    final class_6880<class_3414> stepSound;
    final class_6880<class_3414> placeSound;
    final class_6880<class_3414> hitSound;
    final class_6880<class_3414> fallSound;

    /**
     * @param volume     sound volume
     * @param pitch      sound pitch
     * @param breakSound break sound
     * @param stepSound  step sound
     * @param placeSound place sound
     * @param hitSound   hit sound
     * @param fallSound  fall sound
     */
    public HolderBackedSoundType(float volume, float pitch, class_6880<class_3414> breakSound, class_6880<class_3414> stepSound, class_6880<class_3414> placeSound, class_6880<class_3414> hitSound, class_6880<class_3414> fallSound) {
        super(volume, pitch, class_3417.field_42593, class_3417.field_42593, class_3417.field_42593, class_3417.field_42593, class_3417.field_42593);
        this.breakSound = breakSound;
        this.stepSound = stepSound;
        this.placeSound = placeSound;
        this.hitSound = hitSound;
        this.fallSound = fallSound;
    }

    @Override
    public class_3414 method_10595() {
        return this.breakSound.comp_349();
    }

    @Override
    public class_3414 method_10594() {
        return this.stepSound.comp_349();
    }

    @Override
    public class_3414 method_10598() {
        return this.placeSound.comp_349();
    }

    @Override
    public class_3414 method_10596() {
        return this.hitSound.comp_349();
    }

    @Override
    public class_3414 method_10593() {
        return this.fallSound.comp_349();
    }
}
