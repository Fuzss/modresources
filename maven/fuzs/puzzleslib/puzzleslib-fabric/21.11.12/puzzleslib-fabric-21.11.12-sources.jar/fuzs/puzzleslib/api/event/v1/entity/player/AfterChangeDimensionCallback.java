package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

@FunctionalInterface
public interface AfterChangeDimensionCallback {
    EventInvoker<AfterChangeDimensionCallback> EVENT = EventInvoker.lookup(AfterChangeDimensionCallback.class);

    /**
     * Called after a player has been moved to different level.
     *
     * @param serverPlayer  the player
     * @param originalLevel the original level the player was in
     * @param newLevel      the new level the player was moved to
     */
    void onAfterChangeDimension(class_3222 serverPlayer, class_3218 originalLevel, class_3218 newLevel);
}
