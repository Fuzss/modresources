package fuzs.puzzleslib.api.client.init.v1.family;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.api.client.core.v1.context.EntityRenderersContext;
import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import fuzs.puzzleslib.api.client.init.v1.ClientWoodTypeRegistry;
import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import java.util.Map;
import net.minecraft.class_10255;
import net.minecraft.class_11515;
import net.minecraft.class_1299;
import net.minecraft.class_2248;
import net.minecraft.class_5601;
import net.minecraft.class_5617;
import net.minecraft.class_6880;
import net.minecraft.class_881;

/**
 * Client side version extension for registration methods in {@link BlockSetFamily}.
 */
public final class ClientBlockSetFamily {
    public static final Map<BlockSetVariant, class_11515> VARIANT_RENDER_TYPE = ImmutableMap.of(BlockSetVariant.DOOR,
            class_11515.field_60925,
            BlockSetVariant.TRAPDOOR,
            class_11515.field_60925);

    private ClientBlockSetFamily() {
        // NO-OP
    }

    public static void register(BlockSetFamily blockSetFamily) {
        ClientWoodTypeRegistry.registerWoodType(blockSetFamily.getWoodType());
    }

    public static void registerFor(BlockSetFamily blockSetFamily, RenderTypesContext<class_2248> context, Map<BlockSetVariant, class_11515> variants) {
        blockSetFamily.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> holder) -> {
            class_11515 chunkSectionLayer = variants.get(variant);
            if (chunkSectionLayer != null) {
                context.registerChunkRenderType(holder.comp_349(), chunkSectionLayer);
            }
        });
    }

    @SuppressWarnings("unchecked")
    public static void registerFor(BlockSetFamily blockSetFamily, EntityRenderersContext context, class_5601 boatModelLayer, class_5601 chestBoatModelLayer) {
        context.registerEntityRenderer((class_1299<? extends class_10255>) blockSetFamily.getEntityType(BlockSetVariant.BOAT)
                .comp_349(), (class_5617.class_5618 contextX) -> new class_881(contextX, boatModelLayer));
        context.registerEntityRenderer((class_1299<? extends class_10255>) blockSetFamily.getEntityType(BlockSetVariant.CHEST_BOAT)
                .comp_349(), (class_5617.class_5618 contextX) -> new class_881(contextX, chestBoatModelLayer));
    }
}
