package fuzs.puzzleslib.api.data.v2;

import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import net.minecraft.class_12079;
import net.minecraft.class_161;
import net.minecraft.class_1799;
import net.minecraft.class_185;
import net.minecraft.class_189;
import net.minecraft.class_2405;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7785;
import net.minecraft.class_7924;
import net.minecraft.class_8779;

public abstract class AbstractAdvancementProvider implements class_2405, class_7785 {
    private final String modId;
    private final class_7784.class_7489 pathProvider;
    private final CompletableFuture<class_7225.class_7874> registries;

    public AbstractAdvancementProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractAdvancementProvider(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
        this.modId = modId;
        this.pathProvider = packOutput.method_60917(class_7924.field_52177);
        this.registries = registries;
    }

    protected static class_185 display(class_1799 itemStack, class_2960 identifier) {
        return display(itemStack, identifier, class_189.field_1254);
    }

    protected static class_185 display(class_1799 itemStack, class_2960 identifier, class_189 advancementType) {
        return display(itemStack, identifier, null, advancementType, false);
    }

    protected static class_185 display(class_1799 itemStack, class_2960 identifier, @Nullable class_2960 background, class_189 advancementType, boolean hidden) {
        return display(itemStack, identifier, background, advancementType, true, true, hidden);
    }

    protected static class_185 display(class_1799 itemStack, class_2960 identifier, @Nullable class_2960 background, class_189 advancementType, boolean showToast, boolean announceChat, boolean hidden) {
        AdvancementToken advancementToken = new AdvancementToken(identifier);
        return new class_185(itemStack,
                advancementToken.title(),
                advancementToken.description(),
                Optional.ofNullable(background).map(class_12079.class_10726::new),
                advancementType,
                true,
                true,
                hidden);
    }

    @Override
    public final CompletableFuture<?> method_10319(class_7403 output) {
        return this.registries.thenCompose((class_7225.class_7874 registries) -> {
            Set<class_2960> set = new HashSet<>();
            List<CompletableFuture<?>> list = new ArrayList<>();
            Consumer<class_8779> consumer = (class_8779 holder) -> {
                class_2960 identifier = class_2960.method_60655(this.modId, holder.comp_1919().method_12832());
                if (!set.add(identifier)) {
                    throw new IllegalStateException("Duplicate advancement " + identifier);
                } else {
                    Path path = this.pathProvider.method_44107(identifier);
                    list.add(class_2405.method_53496(output, registries, class_161.field_47179, holder.comp_1920(), path));
                }
            };

            this.method_10335(registries, consumer);
            return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
        });
    }

    @Override
    public final void method_10335(class_7225.class_7874 registries, Consumer<class_8779> writer) {
        this.addAdvancements(registries, writer);
    }

    public abstract void addAdvancements(class_7225.class_7874 registries, Consumer<class_8779> writer);

    @Override
    public String method_10321() {
        return "Advancements";
    }

    public record AdvancementToken(class_2960 id) {

        public class_2561 title() {
            return class_2561.method_43471(this.id.method_48747("advancements", "title"));
        }

        public class_2561 description() {
            return class_2561.method_43471(this.id.method_48747("advancements", "description"));
        }

        public class_8779 asParent() {
            // workaround for getting the proper parent id,
            // the advancement holder from saving the builder always has the `minecraft` namespace set
            // (which we replace when running the data generator which happens later though)
            return new class_8779(this.id, null);
        }

        public String name() {
            return this.id.method_12832();
        }
    }
}
