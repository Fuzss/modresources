package fuzs.puzzleslib.api.core.v1.context;

import com.mojang.serialization.Codec;
import net.minecraft.class_2378;
import net.minecraft.class_5321;

/**
 * Register data pack-driven dynamic registries.
 */
public interface DataPackRegistriesContext {

    /**
     * Registers an unsynchronised dynamic registry.
     *
     * @param registryKey the registry resource key
     * @param codec       the codec for serialising registry values
     * @param <T>         the registry value type
     */
    <T> void registerRegistry(class_5321<class_2378<T>> registryKey, Codec<T> codec);

    /**
     * Registers a synchronised dynamic registry.
     *
     * @param registryKey the registry resource key
     * @param codec       the codec for serialising registry values
     * @param <T>         the registry value type
     */
    default <T> void registerSyncedRegistry(class_5321<class_2378<T>> registryKey, Codec<T> codec) {
        this.registerSyncedRegistry(registryKey, codec, codec);
    }

    /**
     * Registers a synchronised dynamic registry.
     *
     * @param registryKey  the registry resource key
     * @param codec        the codec for serialising registry values
     * @param networkCodec an optional more compressed network codec for serialising registry values for synchronisation
     *                     across networks
     * @param <T>          the registry value type
     */
    <T> void registerSyncedRegistry(class_5321<class_2378<T>> registryKey, Codec<T> codec, Codec<T> networkCodec);
}
