package fuzs.puzzleslib.fabric.impl.event;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.impl.event.data.DefaultedFloat;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_3218;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_6880;

public final class FabricEventImplHelper {

    private FabricEventImplHelper() {
        // NO-OP
    }

    public static int onAnimalTame(class_1429 animal, class_1657 player, int intValue) {
        return onAnimalTame(animal, player, intValue, 1, intValue == 0);
    }

    public static int onAnimalTame(class_1429 animal, class_1657 player, int intValue, int returnValue, boolean tameCondition) {
        if (tameCondition && FabricLivingEvents.ANIMAL_TAME.invoker().onAnimalTame(animal, player).isInterrupt()) {
            return returnValue;
        } else {
            return intValue;
        }
    }

    public static float onLivingHurt(class_1309 livingEntity, class_3218 serverLevel, class_1282 damageSource, float damageAmount, MutableBoolean preventHurting) {
        if (!livingEntity.method_5679(serverLevel, damageSource)) {
            DefaultedFloat damageAmountValue = DefaultedFloat.fromValue(damageAmount);
            EventResult eventResult = FabricLivingEvents.LIVING_HURT.invoker()
                    .onLivingHurt(livingEntity, damageSource, damageAmountValue);
            if (eventResult.isInterrupt()) {
                preventHurting.setTrue();
            }
            return damageAmountValue.getAsOptionalFloat().orElse(damageAmount);
        } else {
            return damageAmount;
        }
    }

    public static boolean tryOnLivingDrops(class_1309 entity, class_1282 damageSource, int lastHurtByPlayerMemoryTime) {
        Collection<class_1542> capturedDrops = ((CapturedDropsEntity) entity).puzzleslib$acceptCapturedDrops(null);
        if (capturedDrops != null) {
            EventResult eventResult = FabricLivingEvents.LIVING_DROPS.invoker()
                    .onLivingDrops(entity, damageSource, capturedDrops, lastHurtByPlayerMemoryTime > 0);
            if (eventResult.isPass()) {
                capturedDrops.forEach((class_1542 itemEntity) -> {
                    entity.method_73183().method_8649(itemEntity);
                });
            }
            return true;
        } else {
            return false;
        }
    }

    public static EventResult onPlaySound(LevelSoundEventInvoker eventInvoker, Args args, MutableValue<class_6880<class_3414>> soundEvent, int soundSourceOrdinal, int soundVolumeOrdinal, int soundPitchOrdinal) {
        Preconditions.checkArgument(args.get(soundSourceOrdinal) instanceof class_3419, "sound source is wrong type");
        Preconditions.checkArgument(args.get(soundVolumeOrdinal) instanceof Float, "sound volume is wrong type");
        Preconditions.checkArgument(args.get(soundPitchOrdinal) instanceof Float, "sound pitch is wrong type");
        MutableValue<class_3419> soundSource = MutableValue.fromEvent((class_3419 soundSourceX) -> args.set(
                soundSourceOrdinal,
                soundSourceX), () -> args.get(soundSourceOrdinal));
        MutableFloat soundVolume = MutableFloat.fromEvent((Float volume) -> args.set(soundVolumeOrdinal, volume),
                () -> args.get(soundVolumeOrdinal));
        MutableFloat soundPitch = MutableFloat.fromEvent((Float pitch) -> args.set(soundPitchOrdinal, pitch),
                () -> args.get(soundPitchOrdinal));
        return eventInvoker.onPlaySound(soundEvent, soundSource, soundVolume, soundPitch);
    }

    @FunctionalInterface
    public interface LevelSoundEventInvoker {
        EventResult onPlaySound(MutableValue<class_6880<class_3414>> soundEvent, MutableValue<class_3419> soundSource, MutableFloat soundVolume, MutableFloat soundPitch);
    }
}
