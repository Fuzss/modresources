package fuzs.puzzleslib.api.client.gui.v2.components;

import java.util.function.ToIntFunction;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_5244;
import net.minecraft.class_8666;
import net.minecraft.class_9848;

/**
 * A button implementation very similar to the old {@link net.minecraft.class_344} with a couple
 * extra features:
 * <ul>
 * <li>No need for using {@link class_8666}.</li>
 * <li>Completely mutable to allow for manipulating texture coordinates, size and position after the button has been
 * initialised.</li>
 * <li>Control over texture layout, meaning how inactive, active, and hovered sprites are arranged in the texture source
 * file.</li>
 * <li>Optionally draws the vanilla background texture behind the rendered sprite.</li>
 * </ul>
 */
@Deprecated
public class SpritelessImageButton extends class_4185 {
    /**
     * The texture layout used in the old {@link net.minecraft.class_344}.
     * <p>
     * The order from top to bottom is:
     * <ul>
     * <li>Active</li>
     * <li>Hovered</li>
     * <li>Inactive</li>
     * </ul>
     */
    public static final ToIntFunction<class_4185> TEXTURE_LAYOUT = (class_4185 button) -> {
        return !button.method_37303() ? 2 : button.method_25367() ? 1 : 0;
    };
    /**
     * The texture layout used in the old <code>textures/gui/widgets.png</code>.
     * <p>
     * The order from top to bottom is:
     * <ul>
     * <li>Inactive</li>
     * <li>Active</li>
     * <li>Hovered</li>
     * </ul>
     */
    public static final ToIntFunction<class_4185> LEGACY_TEXTURE_LAYOUT = (class_4185 button) -> {
        return !button.method_37303() ? 0 : button.method_25367() ? 2 : 1;
    };
    /**
     * A texture layout that always returns the same texture index.
     */
    public static final ToIntFunction<class_4185> SINGLE_TEXTURE_LAYOUT = (class_4185 button) -> {
        return 0;
    };
    /**
     * The texture layout used in the old {@link net.minecraft.class_344} for buttons that are
     * always active.
     * <p>
     * The order from top to bottom is:
     * <ul>
     * <li>Active / Inactive</li>
     * <li>Hovered</li>
     * </ul>
     */
    public static final ToIntFunction<class_4185> ALWAYS_ACTIVE_TEXTURE_LAYOUT = (class_4185 button) -> {
        return button.method_25367() ? 1 : 0;
    };

    public class_2960 identifier;
    public int xTexStart;
    public int yTexStart;
    public int yDiffTex;
    public int textureWidth;
    public int textureHeight;
    private ToIntFunction<class_4185> textureLayout = TEXTURE_LAYOUT;
    private boolean drawBackground;

    public SpritelessImageButton(int x, int y, int width, int height, int xTexStart, int yTexStart, class_2960 identifier, class_4241 onPress) {
        this(x, y, width, height, xTexStart, yTexStart, height, identifier, onPress);
    }

    public SpritelessImageButton(int x, int y, int width, int height, int xTexStart, int yTexStart, int yDiffTex, class_2960 identifier, class_4241 onPress) {
        this(x, y, width, height, xTexStart, yTexStart, yDiffTex, identifier, 256, 256, onPress);
    }

    public SpritelessImageButton(int x, int y, int width, int height, int xTexStart, int yTexStart, int yDiffTex, class_2960 identifier, int textureWidth, int textureHeight, class_4241 onPress) {
        this(x,
                y,
                width,
                height,
                xTexStart,
                yTexStart,
                yDiffTex,
                identifier,
                textureWidth,
                textureHeight,
                onPress,
                class_5244.field_39003);
    }

    public SpritelessImageButton(int x, int y, int width, int height, int xTexStart, int yTexStart, int yDiffTex, class_2960 identifier, int textureWidth, int textureHeight, class_4241 onPress, class_2561 message) {
        super(x, y, width, height, message, onPress, field_40754);
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        this.xTexStart = xTexStart;
        this.yTexStart = yTexStart;
        this.yDiffTex = yDiffTex;
        this.identifier = identifier;
    }

    public SpritelessImageButton setTextureCoordinates(int xTexStart, int yTexStart) {
        this.xTexStart = xTexStart;
        this.yTexStart = yTexStart;
        return this;
    }

    public SpritelessImageButton setTextureDimensions(int textureWidth, int textureHeight) {
        this.textureWidth = textureWidth;
        this.textureHeight = textureHeight;
        return this;
    }

    /**
     * Controls how inactive, active, and hovered sprites are arranged in the texture source file.
     *
     * @param textureLayout layout property
     * @return builder instance
     */
    public SpritelessImageButton setTextureLayout(ToIntFunction<class_4185> textureLayout) {
        this.textureLayout = textureLayout;
        return this;
    }

    /**
     * Draws the vanilla button texture when rendering so that sprites provided by this implementation can be drawn on
     * top.
     * <p>
     * This does, however, not include drawing the button message.
     *
     * @return builder instance
     */
    public SpritelessImageButton setDrawBackground() {
        this.drawBackground = true;
        return this;
    }

    @Override
    protected void method_75752(class_332 guiGraphics, int i, int j, float f) {
        if (this.drawBackground) {
            this.method_75794(guiGraphics);
        }

        guiGraphics.method_25291(class_10799.field_56883,
                this.identifier,
                this.method_46426(),
                this.method_46427(),
                this.xTexStart,
                this.yTexStart + this.yDiffTex * this.getTextureY(),
                this.field_22758,
                this.field_22759,
                this.textureWidth,
                this.textureHeight,
                class_9848.method_61317(this.field_22765));
    }

    /**
     * Controls how inactive, active, and hovered sprites are arranged in the texture source file.
     *
     * @return the texture y index (0, 1, or 2)
     */
    protected int getTextureY() {
        return this.textureLayout.applyAsInt(this);
    }
}
