package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

@Mixin(class_332.class)
abstract class GuiGraphicsFabricMixin {

    @Inject(method = "renderTooltip", at = @At("HEAD"), cancellable = true)
    private void renderTooltip(class_327 font, List<class_5684> tooltipComponents, int mouseX, int mouseY, class_8000 clientTooltipPositioner, @Nullable class_2960 identifier, CallbackInfo callback) {
        if (!tooltipComponents.isEmpty()) {
            EventResult result = FabricGuiEvents.RENDER_TOOLTIP.invoker()
                    .onRenderTooltip(class_332.class.cast(this),
                            font,
                            mouseX,
                            mouseY,
                            tooltipComponents,
                            clientTooltipPositioner);
            if (result.isInterrupt()) callback.cancel();
        }
    }
}
