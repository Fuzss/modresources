package fuzs.puzzleslib.impl.content;

import org.slf4j.Logger;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.nio.file.Path;
import java.util.Enumeration;
import java.util.Objects;
import java.util.Optional;
import java.util.Scanner;
import net.minecraft.class_1267;
import net.minecraft.class_1934;
import net.minecraft.class_3806;
import net.minecraft.class_3808;

/**
 * Keep this separate to prevent early class loading issues from the mixin.
 */
public final class ServerPropertiesHelper {

    private ServerPropertiesHelper() {
        // NO-OP
    }

    public static class_3806 createDedicatedServerProperties(Path path, Logger logger) {
        return new class_3806(class_3808.method_16727(path)) {
            class_3806 setProperties() {
                this.field_16848.put("online-mode", String.valueOf(false));
                this.field_16848.put("difficulty", class_1267.field_5807.method_15434());
                this.field_16848.put("gamemode", class_1934.field_9220.method_15434());
                this.field_16848.put("max-players", String.valueOf(4));
                this.field_16848.put("spawn-protection", String.valueOf(0));
                this.field_16848.put("view-distance", String.valueOf(16));
                Scanner scanner = new Scanner(System.in);
                Optional<String> hostAddress = getHostAddress();
                while (true) {
                    logger.warn("Invalid server ip address! {}",
                            hostAddress.isPresent() ? hostAddress.map((String string) -> {
                                return "Using fallback: " + string;
                            }).get() : "");
                    System.out.print("server-ip=");
                    String input = scanner.nextLine();
                    if (input.isBlank() && hostAddress.isPresent()) {
                        input = hostAddress.get();
                    }

                    // from https://www.oreilly.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
                    if (input.matches("^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$")) {
                        this.field_16848.put("server-ip", input);
                        break;
                    }
                }

                return new class_3806(this.field_16848);
            }
        }.setProperties();
    }

    public static Optional<String> getHostAddress() {
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface networkInterface = interfaces.nextElement();
                if (!networkInterface.isLoopback() && networkInterface.isUp()) {
                    Enumeration<InetAddress> addresses = networkInterface.getInetAddresses();
                    while (addresses.hasMoreElements()) {
                        InetAddress address = addresses.nextElement();
                        if (address instanceof Inet4Address && !Objects.equals(address.getHostAddress(), "127.0.0.1")) {
                            return Optional.of(address.getHostAddress());
                        }
                    }
                }
            }
        } catch (Exception exception) {
            // NO-OP
        }

        return Optional.empty();
    }
}
