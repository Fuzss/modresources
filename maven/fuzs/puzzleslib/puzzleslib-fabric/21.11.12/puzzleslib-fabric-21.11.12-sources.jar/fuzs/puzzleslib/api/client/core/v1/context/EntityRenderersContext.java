package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;

public interface EntityRenderersContext {

    /**
     * Register an {@link net.minecraft.class_897} for an entity.
     *
     * @param entityType             the entity type
     * @param entityRendererProvider the entity renderer provider
     * @param <T>                    the type of entity
     */
    <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> entityType, class_5617<T> entityRendererProvider);
}
