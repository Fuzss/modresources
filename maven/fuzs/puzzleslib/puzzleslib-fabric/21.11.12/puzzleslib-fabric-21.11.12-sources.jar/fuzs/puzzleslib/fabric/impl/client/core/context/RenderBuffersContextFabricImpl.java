package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.RenderBuffersContext;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_9799;

public final class RenderBuffersContextFabricImpl implements RenderBuffersContext {
    private static final Map<class_1921, class_9799> RENDER_TYPE_BUFFER_BUILDERS = new LinkedHashMap<>();

    @Override
    public void registerRenderBuffer(class_1921 renderType, class_9799 renderBuffer) {
        Objects.requireNonNull(renderType, "render type is null");
        Objects.requireNonNull(renderBuffer, "render buffer is null");
        RENDER_TYPE_BUFFER_BUILDERS.put(renderType, renderBuffer);
    }

    public static void addAll(Map<class_1921, class_9799> renderBuffers) {
        renderBuffers.putAll(RENDER_TYPE_BUFFER_BUILDERS);
    }
}
