package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.impl.core.context.DataPackReloadListenersContextFabricImpl;
import net.minecraft.class_5350;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_5350.class)
abstract class ReloadableServerResourcesFabricMixin {

    @ModifyVariable(method = "lambda$loadResources$1(Lnet/minecraft/world/flag/FeatureFlagSet;Lnet/minecraft/commands/Commands$CommandSelection;Ljava/util/List;Lnet/minecraft/server/permissions/PermissionSet;Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Lnet/minecraft/server/ReloadableServerRegistries$LoadResult;)Ljava/util/concurrent/CompletionStage;",
                    at = @At(value = "STORE", ordinal = 0))
    private static class_5350 loadResources(class_5350 reloadableServerResources) {
        DataPackReloadListenersContextFabricImpl.setReloadableServerResources(reloadableServerResources);
        return reloadableServerResources;
    }
}
