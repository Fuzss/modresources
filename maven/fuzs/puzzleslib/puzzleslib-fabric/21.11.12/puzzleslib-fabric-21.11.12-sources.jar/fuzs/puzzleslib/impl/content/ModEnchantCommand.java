package fuzs.puzzleslib.impl.content;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import java.util.Collection;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_5250;
import net.minecraft.class_6880;
import net.minecraft.class_7157;
import net.minecraft.class_7733;
import net.minecraft.class_7924;
import net.minecraft.class_9304;
import net.minecraft.class_9636;

/**
 * An improved version of the vanilla {@code /enchant} allowing for removing and changing enchantments, additionally
 * featuring a slightly more convenient command syntax.
 *
 * @see net.minecraft.class_3048
 */
public class ModEnchantCommand {
    public static final String KEY_REMOVE_SUCCESS_SINGLE = "commands.enchant.remove.success.single";
    public static final String KEY_REMOVE_SUCCESS_MULTIPLE = "commands.enchant.remove.success.multiple";
    private static final DynamicCommandExceptionType ERROR_NOT_LIVING_ENTITY = new DynamicCommandExceptionType(object -> class_2561.method_43469(
            "commands.enchant.failed.entity",
            object));
    private static final DynamicCommandExceptionType ERROR_NO_ITEM = new DynamicCommandExceptionType(object -> class_2561.method_43469(
            "commands.enchant.failed.itemless",
            object));
    private static final DynamicCommandExceptionType ERROR_INCOMPATIBLE = new DynamicCommandExceptionType(object -> class_2561.method_43469(
            "commands.enchant.failed.incompatible",
            object));
    private static final SimpleCommandExceptionType ERROR_NOTHING_HAPPENED = new SimpleCommandExceptionType(class_2561.method_43471(
            "commands.enchant.failed"));

    public static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context) {
        dispatcher.register(class_2170.method_9247("enchant")
                .requires(class_2170.method_71774(class_2170.field_31839))
                .then(class_2170.method_9244("targets", class_2186.method_9306())
                        .then(class_2170.method_9244("enchantment",
                                        class_7733.method_45603(context, class_7924.field_41265))
                                .executes(commandContext -> enchant(commandContext.getSource(),
                                        class_2186.method_9317(commandContext, "targets"),
                                        class_7733.method_45612(commandContext, "enchantment")))
                                .then(
                                        // restrict this to 255, enchantment levels above 255 are not supported in vanilla and will be reset to that anyway
                                        // min of 0 wouldn't do anything in vanilla, but now we use it to remove enchantments
                                        class_2170.method_9244("level", IntegerArgumentType.integer(0, 255))
                                                .executes(commandContext -> enchant(commandContext.getSource(),
                                                        class_2186.method_9317(commandContext, "targets"),
                                                        class_7733.method_45612(commandContext, "enchantment"),
                                                        IntegerArgumentType.getInteger(commandContext, "level")))))));
    }

    private static int enchant(class_2168 commandSourceStack, Collection<? extends class_1297> collection, class_6880<class_1887> holder) throws CommandSyntaxException {
        return enchant(commandSourceStack, collection, holder, holder.comp_349().method_8183());
    }

    private static int enchant(class_2168 commandSourceStack, Collection<? extends class_1297> entities, class_6880<class_1887> enchantment, int level) throws CommandSyntaxException {

        // removed max level check (/effect command doesn't have it as well)
        // this should actually be restricted via the argument type, but doesn't seem to work reliably
        // so just throw the same exception the argument type would
        if (level > 255) {
            throw CommandSyntaxException.BUILT_IN_EXCEPTIONS.integerTooHigh().create(level, 255);
        }

        int successCount = 0;
        for (class_1297 entity : entities) {

            if (entity instanceof class_1309 livingEntity) {

                class_1799 itemStack = livingEntity.method_6047();
                if (!itemStack.method_7960()) {

                    class_9304 itemEnchantments = class_1890.method_57532(itemStack);
                    if (level == 0 || (isBook(itemStack) || enchantment.comp_349().method_8192(itemStack))
                            && isEnchantmentCompatible(itemEnchantments, enchantment)) {

                        class_9304.class_9305 mutable = new class_9304.class_9305(itemEnchantments);
                        if (mutable.method_57546(enchantment) != level) {
                            mutable.method_57547(enchantment, level);
                        } else {
                            if (entities.size() == 1) {
                                throw ERROR_NOTHING_HAPPENED.create();
                            }
                        }

                        if (itemStack.method_31574(class_1802.field_8529) && !mutable.method_57545().isEmpty()) {
                            // if there are more than one book in the item stack they are deleted, but that is fine since cheats are enabled anyway
                            itemStack = itemStack.method_56701(class_1802.field_8598, 1);
                        }

                        class_1890.method_57530(itemStack, mutable.method_57549());

                        if (itemStack.method_31574(class_1802.field_8598) && mutable.method_57545().isEmpty()) {
                            itemStack = itemStack.method_56701(class_1802.field_8529, 1);
                        }

                        livingEntity.method_6122(class_1268.field_5808, itemStack);

                        ++successCount;
                    } else if (entities.size() == 1) {
                        throw ERROR_INCOMPATIBLE.create(itemStack.method_7909().method_7864(itemStack).getString());
                    }
                } else if (entities.size() == 1) {
                    throw ERROR_NO_ITEM.create(livingEntity.method_5477().getString());
                }
            } else if (entities.size() == 1) {
                throw ERROR_NOT_LIVING_ENTITY.create(entity.method_5477().getString());
            }
        }

        if (successCount == 0) {
            throw ERROR_NOTHING_HAPPENED.create();
        } else {
            if (entities.size() == 1) {
                commandSourceStack.method_9226(() -> level > 0 ? class_2561.method_43469(
                        "commands.enchant.success.single",
                        class_1887.method_8179(enchantment, level),
                        entities.iterator().next().method_5476()) : class_2561.method_48322(
                        KEY_REMOVE_SUCCESS_SINGLE,
                        "Removed enchantment %s from %s's item",
                        getFullname(enchantment),
                        entities.iterator().next().method_5476()), true);
            } else {
                commandSourceStack.method_9226(() -> level > 0 ? class_2561.method_43469(
                        "commands.enchant.success.multiple",
                        class_1887.method_8179(enchantment, level),
                        entities.size()) : class_2561.method_48322(KEY_REMOVE_SUCCESS_MULTIPLE,
                        "Removed enchantment %s from %s entities",
                        getFullname(enchantment),
                        entities.size()), true);
            }

            return successCount;
        }
    }

    /**
     * Copied from {@link class_1887#method_8179(class_6880, int)} without an enchantment level added at the end.
     */
    private static class_2561 getFullname(class_6880<class_1887> enchantment) {
        class_5250 mutableComponent = enchantment.comp_349().comp_2686().method_27661();
        if (enchantment.method_40220(class_9636.field_51551)) {
            return mutableComponent.method_27692(class_124.field_1061);
        } else {
            return mutableComponent.method_27692(class_124.field_1080);
        }
    }

    private static boolean isBook(class_1799 itemStack) {
        return itemStack.method_31574(class_1802.field_8529) || itemStack.method_31574(class_1802.field_8598);
    }

    private static boolean isEnchantmentCompatible(class_9304 itemEnchantments, class_6880<class_1887> enchantment) {
        class_9304.class_9305 mutable = new class_9304.class_9305(itemEnchantments);
        mutable.method_57547(enchantment, 0);
        return class_1890.method_8201(mutable.method_57545(), enchantment);
    }
}
