package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1657;

public final class PlayerTickEvents {
    public static final EventInvoker<Start> START = EventInvoker.lookup(Start.class);
    public static final EventInvoker<End> END = EventInvoker.lookup(End.class);

    private PlayerTickEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Start {

        /**
         * Called at the beginning of {@link class_1657#method_5773()}.
         *
         * @param player the ticking player
         */
        void onStartPlayerTick(class_1657 player);
    }

    @FunctionalInterface
    public interface End {

        /**
         * Called at the end of {@link class_1657#method_5773()}.
         *
         * @param player the ticking player
         */
        void onEndPlayerTick(class_1657 player);
    }
}
