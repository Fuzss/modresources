package fuzs.puzzleslib.api.init.v3.registry;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.jspecify.annotations.Nullable;

/**
 * Create new {@link class_2378 Registries}.
 */
public interface RegistryFactory {
    /**
     * the instance
     */
    RegistryFactory INSTANCE = ProxyImpl.get().getRegistryFactory();

    /**
     * Create an un-synchronized {@link net.minecraft.class_2348}.
     *
     * @param registryKey the registry key
     * @param <T>         the registry value type
     * @return the new registry
     */
    default <T> class_2378<T> create(class_5321<class_2378<T>> registryKey) {
        return this.create(registryKey, (String) null);
    }

    /**
     * Create a synchronized {@link net.minecraft.class_2348}, so that numeric registry ids can be
     * used in networking.
     *
     * @param registryKey the registry key
     * @param <T>         the registry value type
     * @return the new registry
     */
    default <T> class_2378<T> createSynced(class_5321<class_2378<T>> registryKey) {
        return this.createSynced(registryKey, (String) null);
    }

    /**
     * Create an un-synchronized {@link net.minecraft.class_2348}.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param <T>         the registry value type
     * @return the new registry
     */
    default <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, @Nullable String defaultKey) {
        return this.create(registryKey, defaultKey != null ? registryKey.method_29177().method_45136(defaultKey) : null);
    }

    /**
     * Create a synchronized {@link net.minecraft.class_2348}, so that numeric registry ids can be
     * used in networking.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param <T>         the registry value type
     * @return the new registry
     */
    default <T> class_2378<T> createSynced(class_5321<class_2378<T>> registryKey, @Nullable String defaultKey) {
        return this.createSynced(registryKey,
                defaultKey != null ? registryKey.method_29177().method_45136(defaultKey) : null);
    }

    /**
     * Create an un-synchronized {@link net.minecraft.class_2348}.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param <T>         the registry value type
     * @return the new registry
     */
    <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, @Nullable class_2960 defaultKey);

    /**
     * Create a synchronized {@link net.minecraft.class_2348}, so that numeric registry ids can be
     * used in networking.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param <T>         the registry value type
     * @return the new registry
     */
    <T> class_2378<T> createSynced(class_5321<class_2378<T>> registryKey, @Nullable class_2960 defaultKey);
}
