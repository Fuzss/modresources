package fuzs.puzzleslib.impl.client.gui;

import net.minecraft.class_1011;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_7764;
import net.minecraft.class_7771;

public final class SingleTextureAtlasSprite extends class_1058 {

    public SingleTextureAtlasSprite(class_2960 identifier, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        this(identifier, spriteWidth, spriteHeight, uOffset, vOffset, 256, 256);
    }

    public SingleTextureAtlasSprite(class_2960 identifier, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int textureWidth, int textureHeight) {
        super(identifier,
                new class_7764(identifier,
                        new class_7771(spriteWidth, spriteHeight),
                        new class_1011(textureWidth, textureHeight, false)),
                textureWidth,
                textureHeight,
                uOffset,
                vOffset,
                0);
    }
}
