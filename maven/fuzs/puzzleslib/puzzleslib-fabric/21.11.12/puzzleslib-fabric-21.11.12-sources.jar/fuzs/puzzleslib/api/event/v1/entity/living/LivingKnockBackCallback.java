package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableDouble;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingKnockBackCallback {
    EventInvoker<LivingKnockBackCallback> EVENT = EventInvoker.lookup(LivingKnockBackCallback.class);

    /**
     * Called before an entity is knocked-back in {@link class_1309#method_6005(double, double, double)}, allows for
     * preventing the knock-back.
     *
     * @param livingEntity      the living entity that will be knocked back
     * @param knockbackStrength the strength that will be used to knock back <code>entity</code>, values usually range
     *                          between 0.5-1.0, 0.0 or negative values prevent any knock-back, value is additionally
     *                          reduced by
     *                          {@link net.minecraft.class_5134#field_23718}
     * @param ratioX            the x-direction to knock back in, will be scaled by <code>strength</code>
     * @param ratioZ            the z-direction to knock back in, will be scaled by <code>strength</code>
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT} to prevent the knock-back from happening</li>
     *         <li>{@link EventResult#PASS} to allow the knock-back to happen with values supplied by the event</li>
     *         </ul>
     */
    EventResult onLivingKnockBack(class_1309 livingEntity, MutableDouble knockbackStrength, MutableDouble ratioX, MutableDouble ratioZ);
}
