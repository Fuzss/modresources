package fuzs.puzzleslib.fabric.impl.event;

import org.jspecify.annotations.Nullable;

import java.util.Collection;
import net.minecraft.class_1542;

public interface CapturedDropsEntity {

    @Nullable Collection<class_1542> puzzleslib$acceptCapturedDrops(@Nullable Collection<class_1542> capturedDrops);

    @Nullable Collection<class_1542> puzzleslib$getCapturedDrops();
}
