package fuzs.puzzleslib.api.client.core.v1.context;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10401;
import net.minecraft.class_10439;
import net.minecraft.class_10460;
import net.minecraft.class_10494;
import net.minecraft.class_10515;
import net.minecraft.class_1800;
import net.minecraft.class_2960;

/**
 * Register codecs for handling custom item model types and properties.
 */
public interface ItemModelsContext {

    /**
     * Register a codec for a custom {@link class_10439.class_10441} type.
     *
     * @param identifier the identifier
     * @param codec            the corresponding codec for the type
     */
    void registerItemModel(class_2960 identifier, MapCodec<? extends class_10439.class_10441> codec);

    /**
     * Register a codec for a custom {@link class_10515.class_10516} type.
     *
     * @param identifier the identifier
     * @param codec            the corresponding codec for the type
     */
    void registerSpecialModelRenderer(class_2960 identifier, MapCodec<? extends class_10515.class_10516> codec);

    /**
     * Register a codec for a custom {@link class_10401} type.
     *
     * @param identifier the identifier
     * @param codec            the corresponding codec for the type
     */
    void registerItemTintSource(class_2960 identifier, MapCodec<? extends class_10401> codec);

    /**
     * Register a type for a custom {@link class_10494} implementation.
     *
     * @param identifier the identifier
     * @param type             the corresponding codec for the type
     */
    void registerSelectItemModelProperty(class_2960 identifier, class_10494.class_10495<?, ?> type);

    /**
     * Register a codec for a custom {@link class_10460} type.
     *
     * @param identifier the identifier
     * @param codec            the corresponding codec for the type
     */
    void registerConditionalItemModelProperty(class_2960 identifier, MapCodec<? extends class_10460> codec);

    /**
     * Register a codec for a custom {@link class_1800} type.
     *
     * @param identifier the identifier
     * @param codec            the corresponding codec for the type
     */
    void registerRangeSelectItemModelProperty(class_2960 identifier, MapCodec<? extends class_1800> codec);
}
