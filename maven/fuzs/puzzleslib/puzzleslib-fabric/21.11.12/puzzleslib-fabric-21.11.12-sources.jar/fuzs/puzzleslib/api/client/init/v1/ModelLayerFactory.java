package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_11677;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_5601;
import net.minecraft.class_5602;
import net.minecraft.class_7761;

/**
 * A helper class for creating {@link class_5601 ModelLayerLocations} with a provided namespace.
 * <p>
 * Most methods are copied from {@link net.minecraft.class_5602} to allow for usage with a custom
 * namespace.
 */
@FunctionalInterface
public interface ModelLayerFactory {

    /**
     * Creates a new instance from a mod id.
     *
     * @param modId the model layer location namespace
     * @return the new factory
     */
    static ModelLayerFactory from(String modId) {
        return () -> modId;
    }

    /**
     * @return the mod id
     */
    String modId();

    /**
     * Creates a new {@link class_5601}.
     *
     * @param path  the entity name
     * @param layer the layer name
     * @return the new model layer location
     */
    default class_5601 registerModelLayer(String path, String layer) {
        class_5601 modelLayerLocation = new class_5601(class_2960.method_60655(this.modId(),
                path), layer);
        if (!class_5602.field_27650.add(modelLayerLocation)) {
            throw new IllegalStateException("Duplicate registration for " + modelLayerLocation);
        } else {
            return modelLayerLocation;
        }
    }

    /**
     * Creates a new {@link class_5601}; the used layer is {@code main}.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    default class_5601 registerModelLayer(String path) {
        return this.registerModelLayer(path, "main");
    }

    /**
     * Creates a new {@link class_5601}; the used layer is {@code main}.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    default class_11677<class_5601> registerArmorSet(String path) {
        return new class_11677<>(this.registerModelLayer(path, "helmet"),
                this.registerModelLayer(path, "chestplate"),
                this.registerModelLayer(path, "leggings"),
                this.registerModelLayer(path, "boots"));
    }

    /**
     * Creates a new {@link class_5601} for a standing sign; the used layer is {@code main}.
     *
     * @param woodType the wood type
     * @return the new model layer location
     */
    default class_5601 createStandingSignModelName(class_4719 woodType) {
        return this.registerModelLayer("sign/standing/" + woodType.comp_1299());
    }

    /**
     * Creates a new {@link class_5601} for a wall sign; the used layer is {@code main}.
     *
     * @param woodType the wood type
     * @return the new model layer location
     */
    default class_5601 createWallSignModelName(class_4719 woodType) {
        return this.registerModelLayer("sign/wall/" + woodType.comp_1299());
    }

    /**
     * Creates a new {@link class_5601} for a hanging sign; the used layer is {@code main}.
     *
     * @param woodType       the wood type
     * @param attachmentType the attachment type
     * @return the new model layer location
     */
    default class_5601 createHangingSignModelName(class_4719 woodType, class_7761.class_10381 attachmentType) {
        return this.registerModelLayer("hanging_sign/" + woodType.comp_1299() + "/" + attachmentType.method_15434());
    }
}
