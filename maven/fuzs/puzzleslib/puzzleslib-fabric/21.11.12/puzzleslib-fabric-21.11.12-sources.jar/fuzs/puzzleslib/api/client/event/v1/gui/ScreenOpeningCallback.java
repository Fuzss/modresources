package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import net.minecraft.class_437;
import org.jspecify.annotations.Nullable;

@FunctionalInterface
public interface ScreenOpeningCallback {
    EventInvoker<ScreenOpeningCallback> EVENT = EventInvoker.lookup(ScreenOpeningCallback.class);

    /**
     * Called just before a new screen is set to {@link net.minecraft.class_310#field_1755} in
     * {@link net.minecraft.class_310#method_1507}, allows for exchanging the new screen with a different one, or
     * can prevent a new screen from opening, by returning the original screen (which will be initialised once again).
     *
     * @param oldScreen the screen that is being removed, which may be {@code null} when opening the screen from
     *                  {@link net.minecraft.class_329}, like {@link net.minecraft.class_433}
     * @param newScreen the new screen that is being set, which may be {@code null} when closing a screen and returning
     *                  to the in-game hud
     * @return <ul>
     *         <li>{@link EventResultHolder#interrupt(Object)} to set a different new screen, potentially the original screen for no change (except the original screen being initialised again), or {@code null} when closing a screen and returning to the in-game gui</li>
     *         <li>{@link EventResultHolder#pass()} to allow the vanilla screen to be set</li>
     *         </ul>
     */
    EventResultHolder<@Nullable class_437> onScreenOpening(@Nullable class_437 oldScreen, @Nullable class_437 newScreen);
}
