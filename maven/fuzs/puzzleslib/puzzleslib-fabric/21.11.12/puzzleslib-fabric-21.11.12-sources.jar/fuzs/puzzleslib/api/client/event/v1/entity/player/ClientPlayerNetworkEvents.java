package fuzs.puzzleslib.api.client.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_2535;
import net.minecraft.class_636;
import net.minecraft.class_746;

public final class ClientPlayerNetworkEvents {
    public static final EventInvoker<Join> JOIN = EventInvoker.lookup(Join.class);
    public static final EventInvoker<Leave> LEAVE = EventInvoker.lookup(Leave.class);

    private ClientPlayerNetworkEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Join {

        /**
         * Called when a player joins the server, the player is already initialized.
         *
         * @param player              the player logging out
         * @param multiPlayerGameMode the multiplayer game mode controller for the player
         * @param connection          the network connection to the server for this player
         */
        void onPlayerJoin(class_746 player, class_636 multiPlayerGameMode, class_2535 connection);
    }

    @FunctionalInterface
    public interface Leave {

        /**
         * Called when a player disconnects from the server, but also occurs before joining a new single player level or
         * server.
         *
         * @param player              the player logging out
         * @param multiPlayerGameMode the multiplayer game mode controller for the player
         * @param connection          the network connection to the server for this player
         */
        void onPlayerLeave(class_746 player, class_636 multiPlayerGameMode, class_2535 connection);
    }
}
