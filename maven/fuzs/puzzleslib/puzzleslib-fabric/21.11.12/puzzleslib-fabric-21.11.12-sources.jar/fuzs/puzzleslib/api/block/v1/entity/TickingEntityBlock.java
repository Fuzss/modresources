package fuzs.puzzleslib.api.block.v1.entity;

import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5558;
import org.jspecify.annotations.Nullable;

/**
 * A simple extension to {@link class_2343} for a default implementation of
 * {@link class_2343#method_31645(class_1937, class_2680, class_2591)}.
 *
 * @param <T> type of the corresponding {@link class_2586}
 */
public interface TickingEntityBlock<T extends class_2586 & TickingBlockEntity> extends class_2343 {

    /**
     * Get the {@link class_2591} for this block.
     *
     * @return tne block entity type token
     */
    class_2591<? extends T> getBlockEntityType();

    @Override
    default class_2586 method_10123(class_2338 blockPos, class_2680 blockState) {
        return this.getBlockEntityType().method_11032(blockPos, blockState);
    }

    @Nullable
    @Override
    default <BE extends class_2586> class_5558<BE> method_31645(class_1937 level, class_2680 blockState, class_2591<BE> blockEntityType) {
        // due to the type bounds in TickingEntityBlock this guarantees we have a TickingBlockEntity instance
        return this.getBlockEntityType() == blockEntityType ? this.getBlockEntityTicker() : null;

    }

    private <BE extends class_2586> class_5558<BE> getBlockEntityTicker() {
        return (class_1937 level, class_2338 blockPos, class_2680 blockState, BE blockEntity) -> {
            if (level instanceof class_3218 serverLevel) {
                ((TickingBlockEntity) blockEntity).serverTick(serverLevel, blockPos, blockState);
            } else {
                ((TickingBlockEntity) blockEntity).clientTick(level, blockPos, blockState);
            }
        };
    }
}
