package fuzs.puzzleslib.fabric.impl.client.event;

import com.mojang.blaze3d.systems.RenderSystem;
import fuzs.puzzleslib.api.client.event.v1.ClientInputEvents;
import fuzs.puzzleslib.api.client.event.v1.ClientLifecycleEvents;
import fuzs.puzzleslib.api.client.event.v1.ClientSetupCallback;
import fuzs.puzzleslib.api.client.event.v1.ClientTickEvents;
import fuzs.puzzleslib.api.client.event.v1.entity.ClientEntityLevelEvents;
import fuzs.puzzleslib.api.client.event.v1.entity.player.*;
import fuzs.puzzleslib.api.client.event.v1.gui.*;
import fuzs.puzzleslib.api.client.event.v1.level.ClientChunkEvents;
import fuzs.puzzleslib.api.client.event.v1.level.ClientLevelEvents;
import fuzs.puzzleslib.api.client.event.v1.level.ClientLevelTickEvents;
import fuzs.puzzleslib.api.client.event.v1.model.ModelBakingEvents;
import fuzs.puzzleslib.api.client.event.v1.model.ModelLoadingEvents;
import fuzs.puzzleslib.api.client.event.v1.renderer.*;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.fabric.api.client.event.v1.*;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import fuzs.puzzleslib.impl.event.data.DefaultedInt;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_10439;
import net.minecraft.class_1087;
import net.minecraft.class_1100;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_12074;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_265;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_5617;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_922;
import net.minecraft.class_9779;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;

import static fuzs.puzzleslib.fabric.api.event.v1.core.FabricEventInvokerRegistry.INSTANCE;

@SuppressWarnings("unchecked")
public final class FabricClientEventInvokers {

    public static void registerLoadingHandlers() {
        INSTANCE.register(ScreenOpeningCallback.class, FabricGuiEvents.SCREEN_OPENING);
        INSTANCE.register(ModelLoadingEvents.LoadModel.class,
                (ModelLoadingEvents.LoadModel callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyModelOnLoad()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_1100 model, ModelModifier.OnLoad.Context context) -> {
                                            EventResultHolder<class_1100> eventResult = callback.onLoadModel(context.id(),
                                                    model);
                                            return eventResult.getInterrupt().orElse(model);
                                        });
                    });
                });
        INSTANCE.register(ModelBakingEvents.BeforeItem.class,
                (ModelBakingEvents.BeforeItem callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyItemModelBeforeBake()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_10439.class_10441 model, ModelModifier.BeforeBakeItem.Context context) -> {
                                            EventResultHolder<class_10439.class_10441> eventResult = callback.onBeforeBakeItem(
                                                    context.itemId(),
                                                    model,
                                                    context.bakeContext());
                                            return eventResult.getInterrupt().orElse(model);
                                        });
                    });
                });
        INSTANCE.register(ModelBakingEvents.AfterItem.class,
                (ModelBakingEvents.AfterItem callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyItemModelAfterBake()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_10439 model, ModelModifier.AfterBakeItem.Context context) -> {
                                            EventResultHolder<class_10439> eventResult = callback.onAfterBakeItem(context.itemId(),
                                                    model,
                                                    context.sourceModel(),
                                                    context.bakeContext());
                                            return eventResult.getInterrupt().orElse(model);
                                        });
                    });
                });
        INSTANCE.register(ModelLoadingEvents.LoadBlockModel.class,
                (ModelLoadingEvents.LoadBlockModel callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyBlockModelOnLoad()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_1087.class_9979 model, ModelModifier.OnLoadBlock.Context context) -> {
                                            EventResultHolder<class_1087.class_9979> eventResult = callback.onLoadBlockModel(
                                                    context.state(),
                                                    model);
                                            return eventResult.getInterrupt().orElse(model);
                                        });
                    });
                });
        INSTANCE.register(ModelBakingEvents.BeforeBlock.class,
                (ModelBakingEvents.BeforeBlock callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyBlockModelBeforeBake()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_1087.class_9979 model, ModelModifier.BeforeBakeBlock.Context context) -> {
                                            EventResultHolder<class_1087.class_9979> eventResult = callback.onBeforeBakeBlock(
                                                    context.state(),
                                                    model,
                                                    context.baker());
                                            return eventResult.getInterrupt().orElse(model);
                                        });
                    });
                });
        INSTANCE.register(ModelBakingEvents.AfterBlock.class,
                (ModelBakingEvents.AfterBlock callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyBlockModelAfterBake()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_1087 model, ModelModifier.AfterBakeBlock.Context context) -> {
                                            EventResultHolder<class_1087> eventResult = callback.onAfterBakeBlock(
                                                    context.state(),
                                                    model,
                                                    context.sourceModel(),
                                                    context.baker());
                                            return eventResult.getInterrupt().orElse(model);
                                        });
                    });
                });
        INSTANCE.register(ClientLifecycleEvents.Started.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED,
                (ClientLifecycleEvents.Started callback) -> {
                    return callback::onClientStarted;
                });
        INSTANCE.register(ClientLifecycleEvents.Stopping.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING,
                (ClientLifecycleEvents.Stopping callback) -> {
                    return callback::onClientStopping;
                });
        INSTANCE.register(ClientSetupCallback.class, (ClientSetupCallback callback, @Nullable Object context) -> {
            callback.onClientSetup();
        });
        INSTANCE.register(DrawItemStackOverlayCallback.class,
                net.fabricmc.fabric.api.client.rendering.v1.DrawItemStackOverlayCallback.EVENT,
                (DrawItemStackOverlayCallback callback, @Nullable Object context) -> {
                    return (class_332 guiGraphics, class_327 font, class_1799 itemStack, int posX, int posY) -> {
                        Objects.requireNonNull(context, "context is null");
                        class_1792 item = (class_1792) context;
                        if (itemStack.method_31574(item)) {
                            callback.onDrawItemStackOverlay(guiGraphics, font, itemStack, posX, posY);
                        }
                    };
                });
        INSTANCE.register(AddLivingEntityRenderLayersCallback.class,
                LivingEntityFeatureRendererRegistrationCallback.EVENT,
                (AddLivingEntityRenderLayersCallback callback) -> {
                    return (class_1299<? extends class_1309> entityType, class_922<?, ?, ?> entityRenderer, LivingEntityFeatureRendererRegistrationCallback.RegistrationHelper registrationHelper, class_5617.class_5618 context) -> {
                        callback.addLivingEntityRenderLayers(entityType, entityRenderer, context);
                    };
                });
    }

    public static void registerEventHandlers() {
        INSTANCE.register(ClientTickEvents.Start.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK,
                (ClientTickEvents.Start callback) -> {
                    return callback::onStartClientTick;
                });
        INSTANCE.register(ClientTickEvents.End.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK,
                (ClientTickEvents.End callback) -> {
                    return callback::onEndClientTick;
                });
        AtomicInteger atomicInteger = new AtomicInteger();
        INSTANCE.register(RenderGuiEvents.Before.class, (RenderGuiEvents.Before callback, @Nullable Object context) -> {
            // register as late as possible, so we capture as many hud layers as possible
            net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED.register((class_310 minecraft) -> {
                HudElementRegistry.addFirst(PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (class_332 guiGraphics, class_9779 deltaTracker) -> {
                            if (!minecraft.field_1690.field_1842) {
                                callback.onBeforeRenderGui(guiGraphics, deltaTracker);
                            }
                        });
                // the sleep layer is the only layer that renders when the gui is hidden
                HudElementRegistry.attachElementBefore(VanillaHudElements.SLEEP,
                        PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (class_332 guiGraphics, class_9779 deltaTracker) -> {
                            if (minecraft.field_1690.field_1842) {
                                callback.onBeforeRenderGui(guiGraphics, deltaTracker);
                            }
                        });
            });
        });
        INSTANCE.register(RenderGuiEvents.After.class, (RenderGuiEvents.After callback, @Nullable Object context) -> {
            // register as late as possible, so we capture as many hud layers as possible
            net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED.register((class_310 minecraft) -> {
                HudElementRegistry.addLast(PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (class_332 guiGraphics, class_9779 deltaTracker) -> {
                            if (!minecraft.field_1690.field_1842) {
                                callback.onAfterRenderGui(guiGraphics, deltaTracker);
                            }
                        });
                // the sleep layer is the only layer that renders when the gui is hidden
                HudElementRegistry.attachElementAfter(VanillaHudElements.SLEEP,
                        PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (class_332 guiGraphics, class_9779 deltaTracker) -> {
                            if (minecraft.field_1690.field_1842) {
                                callback.onAfterRenderGui(guiGraphics, deltaTracker);
                            }
                        });
            });
        });
        INSTANCE.register(ItemTooltipCallback.class,
                net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT,
                (ItemTooltipCallback callback) -> {
                    return (class_1799 stack, class_1792.class_9635 tooltipContext, class_1836 context, List<class_2561> lines) -> {
                        // This uses some font texture when splitting text or measuring text width.
                        // It will throw if not on the render thread, like some worker or networking.
                        if (!RenderSystem.isOnRenderThread()) {
                            return;
                        }

                        callback.onItemTooltip(stack, lines, tooltipContext, class_310.method_1551().field_1724, context);
                    };
                });
        INSTANCE.register(SubmitNameTagCallback.class, FabricRendererEvents.SUBMIT_NAME_TAG);
        INSTANCE.register(RenderContainerScreenContentsCallback.class,
                FabricGuiEvents.RENDER_CONTAINER_SCREEN_CONTENTS);
        INSTANCE.register(PrepareInventoryMobEffectsCallback.class, FabricGuiEvents.INVENTORY_MOB_EFFECTS);
        INSTANCE.register(ComputeFovModifierCallback.class, FabricClientPlayerEvents.COMPUTE_FOV_MODIFIER);
        INSTANCE.register(ScreenEvents.BeforeInit.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT,
                (callback, context) -> {
                    Objects.requireNonNull(context, "context is null");
                    return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (!((Class<?>) context).isInstance(screen)) {
                            return;
                        }

                        callback.onBeforeInit(minecraft,
                                screen,
                                scaledWidth,
                                scaledHeight,
                                Collections.unmodifiableList(Screens.getButtons(screen)));
                    };
                });
        INSTANCE.register(ScreenEvents.AfterInit.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT,
                (callback, context) -> {
                    Objects.requireNonNull(context, "context is null");
                    return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (!((Class<?>) context).isInstance(screen)) {
                            return;
                        }

                        List<class_339> widgets = Screens.getButtons(screen);
                        callback.onAfterInit(minecraft,
                                screen,
                                scaledWidth,
                                scaledHeight,
                                Collections.unmodifiableList(widgets),
                                (UnaryOperator<class_339>) (class_339 abstractWidget) -> {
                                    widgets.add(abstractWidget);
                                    return abstractWidget;
                                },
                                (Consumer<class_339>) widgets::remove);
                    };
                });
        registerScreenEvent(ScreenEvents.Remove.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.Remove.class,
                callback -> {
                    return callback::onRemove;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::remove);
        registerScreenEvent(ScreenEvents.BeforeRender.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BeforeRender.class,
                callback -> {
                    return callback::onBeforeRender;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::beforeRender);
        registerScreenEvent(ScreenEvents.AfterRender.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterRender.class,
                callback -> {
                    return callback::onAfterRender;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterRender);
        registerScreenEvent(ScreenEvents.AfterBackground.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterBackground.class,
                callback -> {
                    return callback::onAfterBackground;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterBackground);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseClick.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseClick.class,
                callback -> {
                    return (class_437 screen, class_11909 mouseButtonEvent) -> {
                        return callback.onBeforeMouseClick(screen, mouseButtonEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseClick);
        registerScreenEvent(ScreenMouseEvents.AfterMouseClick.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseClick.class,
                callback -> {
                    return (class_437 screen, class_11909 mouseButtonEvent, boolean consumed) -> {
                        callback.onAfterMouseClick(screen, mouseButtonEvent);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseClick);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseRelease.class,
                callback -> {
                    return (class_437 screen, class_11909 mouseButtonEvent) -> {
                        return callback.onBeforeMouseRelease(screen, mouseButtonEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseRelease);
        registerScreenEvent(ScreenMouseEvents.AfterMouseRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseRelease.class,
                callback -> {
                    return (class_437 screen, class_11909 mouseButtonEvent, boolean consumed) -> {
                        callback.onAfterMouseRelease(screen, mouseButtonEvent);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseRelease);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseScroll.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseScroll.class,
                callback -> {
                    return (class_437 screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount) -> {
                        return callback.onBeforeMouseScroll(screen, mouseX, mouseY, horizontalAmount, verticalAmount)
                                .isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseScroll);
        registerScreenEvent(ScreenMouseEvents.AfterMouseScroll.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseScroll.class,
                callback -> {
                    return (class_437 screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount, boolean consumed) -> {
                        callback.onAfterMouseScroll(screen, mouseX, mouseY, horizontalAmount, verticalAmount);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseScroll);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseDrag.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseDrag.class,
                callback -> {
                    return (class_437 screen, class_11909 mouseButtonEvent, double horizontalAmount, double verticalAmount) -> {
                        return callback.onBeforeMouseDrag(screen, mouseButtonEvent, horizontalAmount, verticalAmount)
                                .isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseDrag);
        registerScreenEvent(ScreenMouseEvents.AfterMouseDrag.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseDrag.class,
                callback -> {
                    return (class_437 screen, class_11909 mouseButtonEvent, double horizontalAmount, double verticalAmount, boolean consumed) -> {
                        callback.onAfterMouseDrag(screen, mouseButtonEvent, horizontalAmount, verticalAmount);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseDrag);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyPress.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyPress.class,
                callback -> {
                    return (class_437 screen, class_11908 keyEvent) -> {
                        return callback.onBeforeKeyPress(screen, keyEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyPress.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyPress.class,
                callback -> {
                    return callback::onAfterKeyPress;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyRelease.class,
                callback -> {
                    return (class_437 screen, class_11908 keyEvent) -> {
                        return callback.onBeforeKeyRelease(screen, keyEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyRelease);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyRelease.class,
                callback -> {
                    return callback::onAfterKeyRelease;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyRelease);
        INSTANCE.register((Class<ScreenKeyboardEvents.BeforeCharacterType<?>>) (Class<?>) ScreenKeyboardEvents.BeforeCharacterType.class,
                (ScreenKeyboardEvents.BeforeCharacterType<?> callback, @Nullable Object context) -> {
                    // TODO invoke proper Fabric event when added
                });
        INSTANCE.register((Class<ScreenKeyboardEvents.AfterCharacterType<?>>) (Class<?>) ScreenKeyboardEvents.AfterCharacterType.class,
                (ScreenKeyboardEvents.AfterCharacterType<?> callback, @Nullable Object context) -> {
                    // TODO invoke proper Fabric event when added
                });
        INSTANCE.register(CustomizeChatPanelCallback.class,
                (CustomizeChatPanelCallback callback, @Nullable Object context) -> {
                    HudElementRegistry.replaceElement(VanillaHudElements.CHAT, (HudElement hudElement) -> {
                        return (class_332 guiGraphics, class_9779 deltaTracker) -> {
                            guiGraphics.method_51448().pushMatrix();
                            DefaultedInt posX = DefaultedInt.fromValue(0);
                            DefaultedInt posY = DefaultedInt.fromValue(guiGraphics.method_51443() - 48);
                            callback.onRenderChatPanel(guiGraphics, deltaTracker, posX, posY);
                            if (posX.getAsOptionalInt().isPresent() || posY.getAsOptionalInt().isPresent()) {
                                guiGraphics.method_51448()
                                        .translate(posX.getAsInt(), posY.getAsInt() - (guiGraphics.method_51443() - 48));
                            }

                            hudElement.render(guiGraphics, deltaTracker);
                            guiGraphics.method_51448().popMatrix();
                        };
                    });
                });
        INSTANCE.register(ClientEntityLevelEvents.Load.class, FabricClientEntityEvents.ENTITY_LOAD);
        INSTANCE.register(ClientEntityLevelEvents.Unload.class,
                ClientEntityEvents.ENTITY_UNLOAD,
                (ClientEntityLevelEvents.Unload callback) -> {
                    return callback::onEntityUnload;
                });
        INSTANCE.register(ClientInputEvents.MouseClick.class, FabricClientEvents.MOUSE_CLICK);
        INSTANCE.register(ClientInputEvents.MouseScroll.class, FabricClientEvents.MOUSE_SCROLL);
        INSTANCE.register(ClientInputEvents.KeyPress.class, FabricClientEvents.KEY_PRESS);
        INSTANCE.register(SubmitLivingEntityEvents.Before.class, FabricRendererEvents.BEFORE_SUBMIT_LIVING_ENTITY);
        INSTANCE.register(SubmitLivingEntityEvents.After.class, FabricRendererEvents.AFTER_SUBMIT_LIVING_ENTITY);
        INSTANCE.register(RenderHandEvents.MainHand.class, FabricRendererEvents.RENDER_MAIN_HAND);
        INSTANCE.register(RenderHandEvents.OffHand.class, FabricRendererEvents.RENDER_OFF_HAND);
        INSTANCE.register(ComputeCameraAnglesCallback.class, FabricRendererEvents.COMPUTE_CAMERA_ANGLES);
        INSTANCE.register(ClientLevelTickEvents.Start.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_WORLD_TICK,
                (ClientLevelTickEvents.Start callback) -> {
                    return (class_638 clientLevel) -> {
                        callback.onStartLevelTick(class_310.method_1551(), clientLevel);
                    };
                });
        INSTANCE.register(ClientLevelTickEvents.End.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_WORLD_TICK,
                (ClientLevelTickEvents.End callback) -> {
                    return (class_638 clientLevel) -> {
                        callback.onEndLevelTick(class_310.method_1551(), clientLevel);
                    };
                });
        INSTANCE.register(ClientChunkEvents.Load.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_LOAD,
                (ClientChunkEvents.Load callback) -> {
                    return callback::onChunkLoad;
                });
        INSTANCE.register(ClientChunkEvents.Unload.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_UNLOAD,
                (ClientChunkEvents.Unload callback) -> {
                    return callback::onChunkUnload;
                });
        INSTANCE.register(ClientPlayerNetworkEvents.Join.class, FabricClientPlayerEvents.PLAYER_JOIN);
        INSTANCE.register(ClientPlayerNetworkEvents.Leave.class, FabricClientPlayerEvents.PLAYER_LEAVE);
        INSTANCE.register(ClientPlayerCopyCallback.class, FabricClientPlayerEvents.PLAYER_COPY);
        INSTANCE.register(InteractionInputEvents.Attack.class,
                ClientPreAttackCallback.EVENT,
                (InteractionInputEvents.Attack callback) -> {
                    return (class_310 minecraft, class_746 player, int clickCount) -> {
                        if (minecraft.field_1771 <= 0 && minecraft.field_1765 != null) {
                            if (clickCount != 0) {
                                if (!player.method_3144()) {
                                    class_1799 itemInHand = player.method_5998(class_1268.field_5808);
                                    if (itemInHand.method_45435(minecraft.field_1687.method_45162())) {
                                        return callback.onAttackInteraction(minecraft, player, minecraft.field_1765)
                                                .isInterrupt();
                                    }
                                }
                            } else {
                                if (!player.method_6115() && minecraft.field_1765.method_17783() == class_239.class_240.field_1332) {
                                    if (!minecraft.field_1687.method_22347(((class_3965) minecraft.field_1765).method_17777())) {
                                        return callback.onAttackInteraction(minecraft, player, minecraft.field_1765)
                                                .isInterrupt();
                                    }
                                }
                            }
                        }

                        return false;
                    };
                });
        INSTANCE.register(InteractionInputEvents.Use.class,
                UseBlockCallback.EVENT,
                (InteractionInputEvents.Use callback, @Nullable Object context) -> {
                    return (class_1657 player, class_1937 level, class_1268 hand, class_3965 hitResult) -> {
                        // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                        // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                        if (!level.method_8608()) {
                            return class_1269.field_5811;
                        }

                        class_310 minecraft = class_310.method_1551();
                        EventResult eventResult = callback.onUseInteraction(minecraft,
                                (class_746) player,
                                hand,
                                minecraft.field_1765);
                        // when interrupted cancel the interaction without the server being notified
                        return eventResult.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
                    };
                },
                EventPhase::early,
                true);
        INSTANCE.register(InteractionInputEvents.Use.class,
                UseEntityCallback.EVENT,
                (InteractionInputEvents.Use callback, @Nullable Object context) -> {
                    return (class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) -> {
                        // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                        // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                        if (!level.method_8608()) {
                            return class_1269.field_5811;
                        }

                        class_310 minecraft = class_310.method_1551();
                        EventResult eventResult = callback.onUseInteraction(minecraft,
                                (class_746) player,
                                hand,
                                minecraft.field_1765);
                        // when interrupted cancel the interaction without the server being notified
                        return eventResult.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
                    };
                },
                EventPhase::early,
                true);
        INSTANCE.register(InteractionInputEvents.Use.class,
                UseItemCallback.EVENT,
                (InteractionInputEvents.Use callback, @Nullable Object context) -> {
                    return (class_1657 player, class_1937 level, class_1268 hand) -> {
                        // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                        // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                        if (!level.method_8608()) {
                            return class_1269.field_5811;
                        }

                        class_310 minecraft = class_310.method_1551();
                        EventResult eventResult = callback.onUseInteraction(minecraft,
                                (class_746) player,
                                hand,
                                minecraft.field_1765);
                        // when interrupted cancel the interaction without the server being notified
                        return eventResult.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
                    };
                },
                EventPhase::early,
                true);
        INSTANCE.register(InteractionInputEvents.Pick.class, FabricClientPlayerEvents.PICK_INTERACTION_INPUT);
        INSTANCE.register(ClientLevelEvents.Load.class, FabricClientLevelEvents.LOAD_LEVEL);
        INSTANCE.register(ClientLevelEvents.Unload.class, FabricClientLevelEvents.UNLOAD_LEVEL);
        INSTANCE.register(MovementInputUpdateCallback.class, FabricClientPlayerEvents.MOVEMENT_INPUT_UPDATE);
        INSTANCE.register(RenderBlockOverlayCallback.class, FabricRendererEvents.RENDER_BLOCK_OVERLAY);
        INSTANCE.register(FogEvents.Setup.class, FabricRendererEvents.SETUP_FOG);
        INSTANCE.register(FogEvents.Color.class, FabricRendererEvents.FOG_COLOR);
        INSTANCE.register(RenderTooltipCallback.class, FabricGuiEvents.RENDER_TOOLTIP);
        INSTANCE.register(ExtractBlockOutlineCallback.class,
                WorldRenderEvents.AFTER_BLOCK_OUTLINE_EXTRACTION,
                (ExtractBlockOutlineCallback callback) -> {
                    return (WorldExtractionContext context, @Nullable class_239 hitResult) -> {
                        if (hitResult == null || hitResult.method_17783() != class_239.class_240.field_1332) {
                            return;
                        }

                        class_12074 renderState = context.worldState().field_63083;
                        if (renderState == null) {
                            return;
                        }

                        class_2338 blockPos = ((class_3965) hitResult).method_17777();
                        EventResultHolder<@Nullable class_265> eventResult = callback.onExtractBlockOutline(context.world(),
                                blockPos,
                                context.world().method_8320(blockPos),
                                (class_3965) hitResult,
                                class_3726.method_16195(context.camera().method_19331()));
                        eventResult.ifInterrupt((@Nullable class_265 voxelShape) -> {
                            if (voxelShape != null) {
                                context.worldState().field_63083 = new class_12074(renderState.comp_4932(),
                                        renderState.comp_4933(),
                                        renderState.comp_4934(),
                                        voxelShape,
                                        renderState.comp_4936(),
                                        renderState.comp_4937(),
                                        renderState.comp_4938());
                            } else {
                                context.worldState().field_63083 = null;
                            }
                        });
                    };
                });
        INSTANCE.register(GameRenderEvents.Before.class, FabricRendererEvents.BEFORE_GAME_RENDER);
        INSTANCE.register(GameRenderEvents.After.class, FabricRendererEvents.AFTER_GAME_RENDER);
        INSTANCE.register(AddToastCallback.class, FabricGuiEvents.ADD_TOAST);
        INSTANCE.register(ComputeFieldOfViewCallback.class, FabricRendererEvents.COMPUTE_FIELD_OF_VIEW);
        INSTANCE.register(ChatMessageReceivedCallback.class, FabricClientEvents.CHAT_MESSAGE_RECEIVED);
        INSTANCE.register(GatherEffectScreenTooltipCallback.class, FabricGuiEvents.GATHER_EFFECT_SCREEN_TOOLTIP);
        INSTANCE.register(ExtractRenderStateCallback.class, FabricRendererEvents.EXTRACT_RENDER_STATE);
        INSTANCE.register(ExtractLevelRenderStateCallback.class,
                WorldRenderEvents.END_EXTRACTION,
                (ExtractLevelRenderStateCallback callback) -> {
                    return (WorldExtractionContext context) -> {
                        callback.onExtractLevelRenderState(context.worldRenderer(),
                                context.worldState(),
                                context.world(),
                                context.camera(),
                                context.frustum(),
                                context.tickCounter());
                    };
                });
    }

    private static <T, E> void registerScreenEvent(Class<T> clazz, Class<E> eventType, Function<T, E> converter, Function<class_437, Event<E>> eventGetter) {
        INSTANCE.register(clazz,
                eventType,
                converter,
                (Object context, Consumer<Event<E>> applyToInvoker, Consumer<Event<E>> removeInvoker) -> {
                    // we need to keep our own event invokers during the whole pre-init phase to guarantee phase ordering is applied correctly,
                    // since this is managed in the event invokers and there seems to be no way to handle it with just the Fabric event
                    // (since the Fabric event doesn't allow for retrieving already applied event phase orders),
                    // so we register all screen events during pre-init, which allows post-init to already clear our internal map again
                    net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT.register((class_310 client, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (((Class<?>) context).isInstance(screen)) {
                            applyToInvoker.accept(eventGetter.apply(screen));
                        }
                    });
                    net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((class_310 client, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (((Class<?>) context).isInstance(screen)) {
                            removeInvoker.accept(eventGetter.apply(screen));
                        }
                    });
                });
    }
}
