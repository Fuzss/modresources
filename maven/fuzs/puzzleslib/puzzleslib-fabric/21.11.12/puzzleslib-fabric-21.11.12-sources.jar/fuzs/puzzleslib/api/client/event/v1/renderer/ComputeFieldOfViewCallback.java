package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import net.minecraft.class_4184;
import net.minecraft.class_757;

@FunctionalInterface
public interface ComputeFieldOfViewCallback {
    EventInvoker<ComputeFieldOfViewCallback> EVENT = EventInvoker.lookup(ComputeFieldOfViewCallback.class);

    /**
     * Runs after field of view is calculated, based on the game setting, but before in-game effects such as nausea are
     * applied.
     *
     * @param gameRenderer the game renderer instance
     * @param camera       the client camera instance
     * @param partialTick  the partial tick
     * @param fieldOfView  the field of view value
     */
    void onComputeFieldOfView(class_757 gameRenderer, class_4184 camera, float partialTick, MutableFloat fieldOfView);
}
