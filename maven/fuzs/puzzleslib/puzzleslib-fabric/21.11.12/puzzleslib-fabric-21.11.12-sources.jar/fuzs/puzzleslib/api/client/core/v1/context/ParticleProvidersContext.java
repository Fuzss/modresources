package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_11938;
import net.minecraft.class_11939;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_3999;
import net.minecraft.class_702;
import net.minecraft.class_707;
import net.minecraft.client.particle.*;
import java.util.function.Function;

/**
 * Register client-side particle providers for particle types.
 */
public interface ParticleProvidersContext {

    /**
     * Register a factory for a particle type.
     *
     * @param particleType     the particle type
     * @param particleProvider the particle factory
     * @param <T>              the type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707<T> particleProvider);

    /**
     * Register a factory for a particle type.
     *
     * @param particleType    the particle type
     * @param particleFactory the particle factory
     * @param <T>             the type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_11939.class_4091<T> particleFactory);

    /**
     * Register a factory for a particle group.
     *
     * @param particleRenderType   the particle group type
     * @param particleGroupFactory the particle group factory
     */
    void registerParticleRenderType(class_3999 particleRenderType, Function<class_702, class_11938<?>> particleGroupFactory);
}
