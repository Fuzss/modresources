package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.BlockStateResolverContext;
import net.fabricmc.fabric.api.client.model.loading.v1.BlockStateResolver;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.PreparableModelLoadingPlugin;
import net.minecraft.class_1087;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;

public final class BlockStateResolverContextFabricImpl implements BlockStateResolverContext {

    @Override
    public void registerBlockStateResolver(class_2248 block, Consumer<BiConsumer<class_2680, class_1087.class_9979>> blockStateConsumer) {
        ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
            pluginContext.registerBlockStateResolver(block, (BlockStateResolver.Context context) -> {
                blockStateConsumer.accept(context::setModel);
            });
        });
    }

    @Override
    public <T> void registerBlockStateResolver(class_2248 block, BiFunction<class_3300, Executor, CompletableFuture<T>> resourceLoader, BiConsumer<T, BiConsumer<class_2680, class_1087.class_9979>> blockStateConsumer) {
        PreparableModelLoadingPlugin.register((class_3302.class_11558 sharedState, Executor backgroundExecutor) -> resourceLoader.apply(
                sharedState.method_72361(),
                backgroundExecutor), (T data, ModelLoadingPlugin.Context pluginContext) -> {
            pluginContext.registerBlockStateResolver(block, (BlockStateResolver.Context context) -> {
                blockStateConsumer.accept(data, context::setModel);
            });
        });
    }
}
