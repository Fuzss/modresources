package fuzs.puzzleslib.api.event.v1.server;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_12279;
import net.minecraft.server.MinecraftServer;
import java.util.Objects;

@FunctionalInterface
public interface GameRuleUpdatedCallback<T> {

    @SuppressWarnings("unchecked")
    static <T> EventInvoker<GameRuleUpdatedCallback<T>> gameRuleUpdated(class_12279<T> gameRule) {
        Objects.requireNonNull(gameRule, "game rule is null");
        return (EventInvoker<GameRuleUpdatedCallback<T>>) (EventInvoker<?>) EventInvoker.lookup(GameRuleUpdatedCallback.class,
                gameRule);
    }

    /**
     * Called at the end of {@link MinecraftServer#method_74058(class_12279, Object)}, and allows for custom handling
     * of updated game rule values.
     *
     * @param minecraftServer  the server
     * @param gameRule         the game rule
     * @param newGameRuleValue the new game rule value
     */
    void onGameRuleUpdated(MinecraftServer minecraftServer, class_12279<T> gameRule, T newGameRuleValue);
}
