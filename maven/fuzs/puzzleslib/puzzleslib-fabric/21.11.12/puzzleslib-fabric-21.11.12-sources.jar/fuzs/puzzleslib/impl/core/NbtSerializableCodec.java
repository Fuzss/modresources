package fuzs.puzzleslib.impl.core;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import fuzs.puzzleslib.api.core.v1.util.NbtSerializable;
import java.util.function.Supplier;
import net.minecraft.class_2487;
import net.minecraft.class_2522;
import net.minecraft.class_6903;

/**
 * A codec adapter for {@link NbtSerializable}. Uses {@link class_2522#field_51469} internally.
 *
 * @param factory the nbt serializable factory
 * @param <T>     the nbt serializable type
 */
public record NbtSerializableCodec<T extends NbtSerializable>(Supplier<T> factory) implements Codec<T> {

    @Override
    public <T1> DataResult<Pair<T, T1>> decode(DynamicOps<T1> ops, T1 input) {
        if (ops instanceof class_6903<T1> registryOps &&
                registryOps.field_40852 instanceof class_6903.class_9683 adapter) {
            return class_2522.field_51469.decode(ops, input).map((Pair<class_2487, T1> pair) -> {
                return pair.mapFirst((class_2487 compoundTag) -> {
                    T nbtSerializable = this.factory.get();
                    nbtSerializable.read(compoundTag, adapter.field_51501);
                    return nbtSerializable;
                });
            });
        } else {
            return DataResult.error(() -> "Can't decode element " + input + " without registry");
        }
    }

    @Override
    public <T1> DataResult<T1> encode(T input, DynamicOps<T1> ops, T1 prefix) {
        if (ops instanceof class_6903<T1> registryOps &&
                registryOps.field_40852 instanceof class_6903.class_9683 adapter) {
            return class_2522.field_51469.encode(input.toCompoundTag(adapter.field_51501), ops, prefix);
        } else {
            return DataResult.error(() -> "Can't encode element " + input + " without registry");
        }
    }
}
