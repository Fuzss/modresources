package fuzs.puzzleslib.api.util.v1;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1255;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3738;
import net.minecraft.class_5455;
import net.minecraft.server.MinecraftServer;

/**
 * Provides access to common helper methods, some abstracting client-only code.
 */
public final class CommonHelper {

    private CommonHelper() {
        // NO-OP
    }

    /**
     * @return the currently running minecraft server, otherwise {@code null}
     */
    public static MinecraftServer getMinecraftServer() {
        return ProxyImpl.get().getMinecraftServer();
    }

    /**
     * @param level the level
     * @return the event loop for running {@link class_3738 TickTasks}
     */
    public static class_1255<? super class_3738> getBlockableEventLoop(class_1937 level) {
        return ProxyImpl.get().getBlockableEventLoop(level);
    }

    /**
     * @return the registry access from the current client / server context, otherwise {@code null}
     */
    public static class_5455 getRegistryAccess() {
        return ProxyImpl.get().getRegistryAccess();
    }

    /**
     * @return the client player; throws an exception on dedicated servers
     */
    public static class_1657 getClientPlayer() {
        return ProxyImpl.get().getClientPlayer();
    }

    /**
     * @return the client level; throws an exception on dedicated servers
     */
    public static class_1937 getClientLevel() {
        return ProxyImpl.get().getClientLevel();
    }

    /**
     * @return is the control key pressed; always {@code false} on dedicated servers
     */
    public static boolean hasControlDown() {
        return ProxyImpl.get().hasControlDown();
    }

    /**
     * @return is the shift key pressed; always {@code false} on dedicated servers
     */
    public static boolean hasShiftDown() {
        return ProxyImpl.get().hasShiftDown();
    }

    /**
     * @return is the alt key pressed; always {@code false} on dedicated servers
     */
    public static boolean hasAltDown() {
        return ProxyImpl.get().hasAltDown();
    }
}
