package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.BlockEntityRenderersContext;
import java.util.Objects;
import net.minecraft.class_11954;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;
import net.minecraft.class_5616;

public final class BlockEntityRenderersContextFabricImpl implements BlockEntityRenderersContext {

    @Override
    public <T extends class_2586, S extends class_11954> void registerBlockEntityRenderer(class_2591<? extends T> blockEntityType, class_5614<T, S> blockEntityRendererProvider) {
        Objects.requireNonNull(blockEntityType, "block entity type is null");
        Objects.requireNonNull(blockEntityRendererProvider, "block entity renderer provider is null");
        class_5616.method_32144(blockEntityType, blockEntityRendererProvider);
    }
}
