package fuzs.puzzleslib.fabric.impl.data;

import fuzs.puzzleslib.api.data.v2.tags.AbstractTagAppender;
import net.fabricmc.fabric.impl.datagen.FabricTagBuilder;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_3497;
import net.minecraft.class_5321;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class FabricTagAppender<T> extends AbstractTagAppender<T> {
    /**
     * Only fully supported on NeoForge.
     */
    private final List<class_3497> removeEntries = new ArrayList<>();

    public FabricTagAppender(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        super(tagBuilder, keyExtractor);
    }

    @Override
    public AbstractTagAppender<T> setReplace(boolean replace) {
        ((FabricTagBuilder) this.tagBuilder).fabric_setReplace(replace);
        return this;
    }

    @Override
    public AbstractTagAppender<T> remove(class_2960 identifier) {
        this.removeEntries.add(class_3497.method_43937(identifier));
        return this;
    }

    @Override
    public AbstractTagAppender<T> removeOptional(class_2960 identifier) {
        this.removeEntries.add(class_3497.method_43942(identifier));
        return this;
    }

    @Override
    public AbstractTagAppender<T> removeTag(class_2960 identifier) {
        this.removeEntries.add(class_3497.method_43945(identifier));
        return this;
    }

    @Override
    public AbstractTagAppender<T> removeOptionalTag(class_2960 identifier) {
        this.removeEntries.add(class_3497.method_43947(identifier));
        return this;
    }

    @Override
    public List<String> asStringList() {
        List<String> list = new ArrayList<>();
        for (class_3497 tagEntry : this.tagBuilder.method_26782()) {
            list.add(tagEntry.toString());
        }

        for (class_3497 tagEntry : this.removeEntries) {
            list.add("!" + tagEntry);
        }

        return list;
    }
}
