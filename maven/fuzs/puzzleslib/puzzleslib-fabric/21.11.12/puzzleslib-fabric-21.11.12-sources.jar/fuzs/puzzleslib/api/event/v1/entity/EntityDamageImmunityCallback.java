package fuzs.puzzleslib.api.event.v1.entity;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableBoolean;
import net.minecraft.class_1282;
import net.minecraft.class_1297;

@FunctionalInterface
public interface EntityDamageImmunityCallback {
    EventInvoker<EntityDamageImmunityCallback> EVENT = EventInvoker.lookup(EntityDamageImmunityCallback.class);

    /**
     * Runs in {@link class_1297#method_64421(class_1282)} when an entity is attacked to determine if said entity
     * is invulnerable to the specific damage source.
     *
     * @param entity         the entity
     * @param damageSource   the damage source
     * @param isInvulnerable is the entity invulnerable to the damage source
     */
    void onEntityDamageImmunity(class_1297 entity, class_1282 damageSource, MutableBoolean isInvulnerable);
}
