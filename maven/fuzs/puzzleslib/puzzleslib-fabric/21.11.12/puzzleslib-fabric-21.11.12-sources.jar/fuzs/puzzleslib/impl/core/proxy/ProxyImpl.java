package fuzs.puzzleslib.impl.core.proxy;

import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.core.v1.ServiceProviderHelper;
import fuzs.puzzleslib.api.event.v1.LoadCompleteCallback;
import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.event.core.EventInvokerImpl;
import net.minecraft.class_1268;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1887;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_3908;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jspecify.annotations.Nullable;

import java.util.function.Consumer;

public interface ProxyImpl extends SidedProxy, FactoriesProxy, NetworkingProxy, EntityProxy {
    ProxyImpl INSTANCE = class_156.method_656(() -> {
        if (ModLoaderEnvironment.INSTANCE.isClient()) {
            return ServiceProviderHelper.load(ClientProxyImpl.class);
        } else {
            return ServiceProviderHelper.load(ProxyImpl.class);
        }
    });

    static ProxyImpl get() {
        return ProxyImpl.INSTANCE;
    }

    @MustBeInvokedByOverriders
    default void registerEventHandlers() {
        LoadCompleteCallback.EVENT.register(() -> {
            ModContext.forEach(ModContext::runAfterConstruction);
            EventInvokerImpl.initialize();
        });
    }

    MinecraftServer getMinecraftServer();

    <T> void openMenu(class_1657 player, class_3908 menuProvider, T data);

    class_3288.class_7679 createPackInfo(class_2960 identifier, class_2561 descriptionComponent, class_3281 packCompatibility, class_7699 featureFlagSet, boolean isHidden);

    boolean isPackHidden(class_3288 pack);

    void setPackHidden(class_3288 pack, boolean isHidden);

    class_2583 getRarityStyle(class_1814 rarity);

    void onPlayerDestroyItem(class_1657 player, class_1799 originalItemStack, @Nullable class_1268 interactionHand);

    void forEachPool(class_52.class_53 lootTable, Consumer<? super class_55.class_56> lootPoolConsumer);

    float getEnchantPowerBonus(class_2680 blockState, class_1937 level, class_2338 blockPos);

    boolean canApplyAtEnchantingTable(class_6880<class_1887> enchantment, class_1799 itemStack);
}
