package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1764.class)
abstract class CrossbowItemFabricMixin extends class_1811 {

    public CrossbowItemFabricMixin(class_1793 properties) {
        super(properties);
    }

    @Inject(method = "performShooting", at = @At("HEAD"), cancellable = true)
    public void performShooting(class_1937 level, class_1309 shooter, class_1268 usedHand, class_1799 weapon, float velocity, float inaccuracy, @Nullable class_1309 target, CallbackInfo callback) {
        if (level instanceof class_3218 && shooter instanceof class_1657 player) {
            EventResult result = FabricPlayerEvents.ARROW_LOOSE.invoker().onArrowLoose(player, weapon, level, MutableInt.fromValue(1), true);
            if (result.isInterrupt()) callback.cancel();
        }
    }
}
