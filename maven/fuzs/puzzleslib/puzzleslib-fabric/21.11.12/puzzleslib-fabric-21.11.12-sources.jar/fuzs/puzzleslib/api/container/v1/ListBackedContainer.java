package fuzs.puzzleslib.api.container.v1;

import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

/**
 * A simple {@link class_1263} implementation with only default methods and an item list getter.
 */
@FunctionalInterface
public interface ListBackedContainer extends SimpleContainerImpl {

    /**
     * Creates a container backed by the item list.
     */
    static ListBackedContainer of(class_2371<class_1799> items) {
        return () -> items;
    }

    /**
     * Creates a new empty container with the specified size.
     */
    static ListBackedContainer of(int size) {
        return of(class_2371.method_10213(size, class_1799.field_8037));
    }

    /**
     * Retrieves the item list backing this inventory.
     */
    class_2371<class_1799> getContainerItems();

    @Override
    default int method_5439() {
        return this.getContainerItems().size();
    }

    @Override
    default void method_5431() {
        // NO-OP
    }

    @Override
    default boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    default class_1799 getContainerItem(int slot) {
        return this.getContainerItems().get(slot);
    }

    @Override
    default class_1799 removeContainerItem(int slot, int amount) {
        return class_1262.method_5430(this.getContainerItems(), slot, amount);
    }

    @Override
    default class_1799 removeContainerItemNoUpdate(int slot) {
        return class_1262.method_5428(this.getContainerItems(), slot);
    }

    @Override
    default void setContainerItem(int slot, class_1799 itemStack) {
        this.getContainerItems().set(slot, itemStack);
    }
}
