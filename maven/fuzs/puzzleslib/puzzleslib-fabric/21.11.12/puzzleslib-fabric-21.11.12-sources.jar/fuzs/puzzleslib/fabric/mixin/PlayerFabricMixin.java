package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Cancellable;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.fabric.impl.event.FabricEventImplHelper;
import fuzs.puzzleslib.impl.event.data.DefaultedFloat;
import fuzs.puzzleslib.impl.event.data.DefaultedValue;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1937;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1657.class)
abstract class PlayerFabricMixin extends class_1309 {

    protected PlayerFabricMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(method = "tick", at = @At("HEAD"))
    public void tick$0(CallbackInfo callback) {
        FabricPlayerEvents.PLAYER_TICK_START.invoker().onStartPlayerTick(class_1657.class.cast(this));
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void tick$1(CallbackInfo callback) {
        FabricPlayerEvents.PLAYER_TICK_END.invoker().onEndPlayerTick(class_1657.class.cast(this));
    }

    @Inject(method = "drop", at = @At(value = "HEAD"), cancellable = true)
    public void drop(class_1799 itemStack, boolean includeThrowerName, CallbackInfoReturnable<class_1542> callback) {
        if (!class_3222.class.isInstance(this)) {
            return;
        }

        EventResult eventResult = FabricPlayerEvents.ITEM_TOSS.invoker()
                .onItemToss(class_3222.class.cast(this), itemStack);
        if (eventResult.isInterrupt()) {
            callback.setReturnValue(null);
        }
    }

    @ModifyReturnValue(method = "getDestroySpeed", at = @At("TAIL"))
    public float getDestroySpeed(float destroySpeed, class_2680 blockState) {
        DefaultedFloat defaultedFloat = DefaultedFloat.fromValue(destroySpeed);
        if (FabricPlayerEvents.CALCULATE_BLOCK_BREAK_SPEED.invoker()
                .onCalculateBlockBreakSpeed(class_1657.class.cast(this), blockState, defaultedFloat)
                .isInterrupt()) {
            defaultedFloat.accept(-1.0F);
        }

        return defaultedFloat.getAsOptionalFloat().orElse(destroySpeed);
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    public void die(class_1282 damageSource, CallbackInfo callback) {
        // this will fire twice for players, since the die method calls super on LivingEntity, where this is hooked in again
        // Forge has it implemented like this, so let's leave it for now for parity
        // can't easily filter out the second call on Forge unfortunately
        EventResult result = FabricLivingEvents.LIVING_DEATH.invoker().onLivingDeath(this, damageSource);
        if (result.isInterrupt()) {
            callback.cancel();
        }
    }

    @ModifyVariable(method = "actuallyHurt", at = @At("HEAD"), ordinal = 0, argsOnly = true)
    protected float actuallyHurt(float damageAmount, class_3218 serverLevel, class_1282 damageSource, @Cancellable CallbackInfo callback) {
        if (!this.method_5679(serverLevel, damageSource)) {
            MutableBoolean cancelInjection = new MutableBoolean();
            damageAmount = FabricEventImplHelper.onLivingHurt(this,
                    serverLevel,
                    damageSource,
                    damageAmount,
                    cancelInjection);
            if (cancelInjection.booleanValue()) {
                callback.cancel();
            }
        }

        return damageAmount;
    }

    @ModifyReturnValue(method = "getProjectile", at = @At("RETURN"))
    public class_1799 getProjectile(class_1799 projectileItemStack, class_1799 weaponItemStack) {
        if (weaponItemStack.method_7909() instanceof class_1811) {
            DefaultedValue<class_1799> projectileItemStackValue = DefaultedValue.fromValue(projectileItemStack);
            FabricLivingEvents.PICK_PROJECTILE.invoker()
                    .onPickProjectile(this, weaponItemStack, projectileItemStackValue);
            return projectileItemStackValue.getAsOptional().orElse(projectileItemStack);
        } else {
            return projectileItemStack;
        }
    }
}
