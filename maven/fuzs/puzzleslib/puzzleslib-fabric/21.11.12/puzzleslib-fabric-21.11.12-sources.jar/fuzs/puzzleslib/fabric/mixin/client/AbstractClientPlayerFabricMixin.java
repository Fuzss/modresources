package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.authlib.GameProfile;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientPlayerEvents;
import fuzs.puzzleslib.impl.event.data.DefaultedFloat;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_742.class)
abstract class AbstractClientPlayerFabricMixin extends class_1657 {

    public AbstractClientPlayerFabricMixin(class_1937 level, GameProfile gameProfile) {
        super(level, gameProfile);
    }

    @ModifyReturnValue(method = "getFieldOfViewModifier", at = @At("TAIL"))
    public float getFieldOfViewModifier(float scaledFieldOfView, @Local(ordinal = 0,
            argsOnly = true) float fieldOfView) {
        float fovEffectScale = class_310.method_1551().field_1690.method_42454().method_41753().floatValue();
        // if fov effects don't apply due to the option being set to 0, so no need to fire the event
        if (fovEffectScale != 0.0F) {
            // reverse fovEffectScale calculations applied by vanilla in return statement,
            // we could capture the original value previous to return, but this approach only needs one mixin
            DefaultedFloat fieldOfViewModifier = DefaultedFloat.fromValue(fieldOfView);
            FabricClientPlayerEvents.COMPUTE_FOV_MODIFIER.invoker().onComputeFovModifier(this, fieldOfViewModifier);
            return fieldOfViewModifier.getAsOptionalFloat()
                    .map(value -> class_3532.method_16439(fovEffectScale, 1.0F, value))
                    .orElse(scaledFieldOfView);
        } else {
            return scaledFieldOfView;
        }
    }
}
