package fuzs.puzzleslib.api.container.v1;

import net.minecraft.class_3222;
import net.minecraft.class_3908;

/**
 * A custom {@link class_3908} for menu types registered via
 * {@link fuzs.puzzleslib.api.init.v3.registry.MenuSupplierWithData}.
 *
 * @param <T> the menu data type
 */
public interface MenuProviderWithData<T> extends class_3908 {

    /**
     * @param serverPlayer the player opening the menu, potentially {@code null} when unable to retrieve from inventory
     *                     slots
     * @return the menu data
     */
    T getMenuData(class_3222 serverPlayer);
}
