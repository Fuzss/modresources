package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_9892;

@Mixin(class_9892.class)
abstract class ServerExplosionFabricMixin {
    @Shadow
    @Final
    private class_3218 level;
    @Unique private List<class_2338> puzzleslib$explodedPositions;

    @ModifyVariable(method = "explode", at = @At("STORE"), ordinal = 0)
    public List<class_2338> explode(List<class_2338> explodedPositions) {
        return this.puzzleslib$explodedPositions = explodedPositions;
    }

    @ModifyVariable(method = "hurtEntities", at = @At("STORE"), ordinal = 0, require = 0)
    public List<class_1297> hurtEntities(List<class_1297> hurtEntities) {
        Objects.requireNonNull(this.puzzleslib$explodedPositions, "exploded positions is null");
        FabricLevelEvents.EXPLOSION_DETONATE.invoker().onExplosionDetonate(this.level, class_9892.class.cast(this),
                this.puzzleslib$explodedPositions, hurtEntities
        );
        return hurtEntities;
    }
}
