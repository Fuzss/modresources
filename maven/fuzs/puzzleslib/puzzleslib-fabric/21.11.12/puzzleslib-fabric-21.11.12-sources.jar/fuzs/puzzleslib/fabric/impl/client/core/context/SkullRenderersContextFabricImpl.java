package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.SkullRenderersContext;
import org.jspecify.annotations.Nullable;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_2484;
import net.minecraft.class_2960;
import net.minecraft.class_5598;
import net.minecraft.class_5599;
import net.minecraft.class_836;

public final class SkullRenderersContextFabricImpl implements SkullRenderersContext {
    private static final Map<class_2484.class_2485, Function<class_5599, class_5598>> SKULL_MODEL_FACTORIES = new IdentityHashMap<>();

    @Override
    public void registerSkullRenderer(class_2484.class_2485 skullBlockType, class_2960 textureLocation, Function<class_5599, class_5598> skullModelFactory) {
        Objects.requireNonNull(skullBlockType, "skull block type is null");
        Objects.requireNonNull(textureLocation, "texture location is null");
        Objects.requireNonNull(skullModelFactory, "skull model factory is null");
        class_836.field_4390.put(skullBlockType, textureLocation);
        SKULL_MODEL_FACTORIES.put(skullBlockType, skullModelFactory);
    }

    @Nullable public static class_5598 createSkullModel(class_2484.class_2485 skullBlockType, class_5599 entityModelSet) {
        Function<class_5599, class_5598> skullModelFactory = SKULL_MODEL_FACTORIES.get(skullBlockType);
        return skullModelFactory != null ? skullModelFactory.apply(entityModelSet) : null;
    }
}
