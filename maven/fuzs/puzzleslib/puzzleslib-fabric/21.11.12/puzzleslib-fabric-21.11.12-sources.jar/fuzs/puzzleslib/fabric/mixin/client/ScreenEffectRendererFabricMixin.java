package fuzs.puzzleslib.fabric.mixin.client;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricRendererEvents;
import net.minecraft.class_1058;
import net.minecraft.class_11701;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_4603.class)
abstract class ScreenEffectRendererFabricMixin {
    @Shadow
    @Final
    private class_310 minecraft;
    @Shadow
    @Final
    private class_11701 materials;

    @WrapWithCondition(method = "renderScreenEffect",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/ScreenEffectRenderer;renderTex(Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V"))
    public boolean renderScreenEffect(class_1058 textureAtlasSprite, class_4587 poseStack, class_4597 bufferSource, @Local class_2680 blockState) {
        return FabricRendererEvents.RENDER_BLOCK_OVERLAY.invoker()
                .onRenderBlockOverlay(this.minecraft.field_1724, poseStack, bufferSource, blockState, this.materials)
                .isPass();
    }

    @WrapWithCondition(method = "renderScreenEffect",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/ScreenEffectRenderer;renderWater(Lnet/minecraft/client/Minecraft;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;)V"))
    public boolean renderScreenEffect(class_310 minecraft, class_4587 poseStack, class_4597 bufferSource) {
        return FabricRendererEvents.RENDER_BLOCK_OVERLAY.invoker()
                .onRenderBlockOverlay(minecraft.field_1724,
                        poseStack,
                        bufferSource,
                        class_2246.field_10382.method_9564(),
                        this.materials)
                .isPass();
    }

    @WrapWithCondition(method = "renderScreenEffect",
            at = @At(value = "INVOKE",
                    target = "Lnet/minecraft/client/renderer/ScreenEffectRenderer;renderFire(Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/MultiBufferSource;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;)V"))
    public boolean renderScreenEffect(class_4587 poseStack, class_4597 bufferSource, class_1058 textureAtlasSprite) {
        return FabricRendererEvents.RENDER_BLOCK_OVERLAY.invoker()
                .onRenderBlockOverlay(this.minecraft.field_1724,
                        poseStack,
                        bufferSource,
                        class_2246.field_10036.method_9564(),
                        this.materials)
                .isPass();
    }
}
