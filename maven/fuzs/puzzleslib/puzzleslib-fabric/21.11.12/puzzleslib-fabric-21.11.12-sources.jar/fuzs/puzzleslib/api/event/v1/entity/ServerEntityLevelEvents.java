package fuzs.puzzleslib.api.event.v1.entity;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1266;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1315;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5425;

public final class ServerEntityLevelEvents {
    public static final EventInvoker<Load> LOAD = EventInvoker.lookup(Load.class);
    public static final EventInvoker<Unload> UNLOAD = EventInvoker.lookup(Unload.class);

    private ServerEntityLevelEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Load {

        /**
         * Fired when an entity is added to the level on the server, either when being loaded from chunk storage or when
         * just having been spawned in.
         * <p>
         * For newly spawned entities the {@link net.minecraft.class_3730} can be obtained via
         * {@link fuzs.puzzleslib.api.util.v1.EntityHelper#getMobSpawnReason(class_1297)} if captured in
         * {@link class_1308#method_5943(class_5425, class_1266, class_3730, class_1315)}.
         *
         * @param entity         the entity that is being loaded
         * @param serverLevel    the level the entity is loaded in
         * @param isNewlySpawned the entity has just been spawned in instead of being loaded from storage
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the entity from being added to the level, effectively discarding it</li>
         *         <li>{@link EventResult#PASS PASS} for the entity to be added normally</li>
         *         </ul>
         */
        EventResult onEntityLoad(class_1297 entity, class_3218 serverLevel, boolean isNewlySpawned);
    }

    @FunctionalInterface
    public interface Unload {

        /**
         * Fired when an entity is removed from the level on the server.
         *
         * @param entity      the entity that is being unloaded
         * @param serverLevel the level the entity is unloaded in
         */
        void onEntityUnload(class_1297 entity, class_3218 serverLevel);
    }
}
