package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import net.minecraft.class_1657;
import net.minecraft.class_2680;

@FunctionalInterface
public interface CalculateBlockBreakSpeedCallback {
    EventInvoker<CalculateBlockBreakSpeedCallback> EVENT = EventInvoker.lookup(CalculateBlockBreakSpeedCallback.class);

    /**
     * Called when the player attempts to harvest a block in {@link class_1657#method_7351(class_2680)}.
     *
     * @param player     the player breaking the block
     * @param blockState the block state being broken
     * @param breakSpeed the speed at which the block is broken, usually a value around 1.0
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the block from breaking, effectively setting the break speed to -1.0</li>
     *         <li>{@link EventResult#PASS PASS} to allow the block to be broken at the defined break speed</li>
     *         </ul>
     */
    EventResult onCalculateBlockBreakSpeed(class_1657 player, class_2680 blockState, MutableFloat breakSpeed);
}
