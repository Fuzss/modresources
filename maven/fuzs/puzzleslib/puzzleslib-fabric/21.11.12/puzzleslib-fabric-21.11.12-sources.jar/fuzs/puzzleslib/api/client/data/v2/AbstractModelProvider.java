package fuzs.puzzleslib.api.client.data.v2;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import net.minecraft.class_10405;
import net.minecraft.class_10410;
import net.minecraft.class_10434;
import net.minecraft.class_10439;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4910.class_4912;
import net.minecraft.class_4915;
import net.minecraft.class_4916;
import net.minecraft.class_4941;
import net.minecraft.class_4943;
import net.minecraft.class_4946;
import net.minecraft.class_5794;
import net.minecraft.class_6880;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;

public abstract class AbstractModelProvider implements class_2405 {
    /**
     * @see #generateForItems(class_4915, BlockSetFamily, Map)
     */
    public static final Map<BlockSetVariant, BiConsumer<class_4915, class_1792>> VARIANT_WOOD_ITEM_PROVIDERS = ImmutableMap.<BlockSetVariant, BiConsumer<class_4915, class_1792>>builder()
            .put(BlockSetVariant.BOAT, (class_4915 itemModelGenerators, class_1792 item) -> {
                itemModelGenerators.method_65442(item, class_4943.field_22938);
            })
            .put(BlockSetVariant.CHEST_BOAT, (class_4915 itemModelGenerators, class_1792 item) -> {
                itemModelGenerators.method_65442(item, class_4943.field_22938);
            })
            .build();

    private final String modId;
    private final class_7784.class_7489 blockStatePathProvider;
    private final class_7784.class_7489 itemInfoPathProvider;
    private final class_7784.class_7489 modelPathProvider;
    private final Set<Object> skipValidation = new HashSet<>();

    public AbstractModelProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput());
    }

    public AbstractModelProvider(String modId, class_7784 packOutput) {
        this.modId = modId;
        this.blockStatePathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "blockstates");
        this.itemInfoPathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "items");
        this.modelPathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "models");
    }

    /**
     * @see #generateForBlocks(class_4910, BlockSetFamily, Map)
     */
    public static Map<BlockSetVariant, BiConsumer<class_4910, class_2248>> createVariantWoodBlockProviders(BlockSetFamily blockSetFamily, class_2248 strippedBlock) {
        return ImmutableMap.<BlockSetVariant, BiConsumer<class_4910, class_2248>>builder()
                .put(BlockSetVariant.HANGING_SIGN, (class_4910 blockModelGenerators, class_2248 block) -> {
                    class_6880.class_6883<class_2248> wallHangingSign = blockSetFamily.getBlock(BlockSetVariant.WALL_HANGING_SIGN);
                    Objects.requireNonNull(wallHangingSign, "wall hanging sign is null");
                    blockModelGenerators.method_46190(strippedBlock, block, wallHangingSign.comp_349());
                })
                .put(BlockSetVariant.SHELF, (class_4910 blockModelGenerators, class_2248 block) -> {
                    blockModelGenerators.method_72719(block, strippedBlock);
                })
                .build();
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 output) {
        BlockStateOutputImpl blockStateOutput = new BlockStateOutputImpl(this::isValid);
        ItemModelOutputImpl itemModelOutput = new ItemModelOutputImpl(this::isValid);
        class_4916.class_10408 modelOutput = new class_4916.class_10408();
        this.addBlockModels(this.setupBlockModelGenerators(new class_4910(blockStateOutput,
                itemModelOutput,
                modelOutput)));
        this.addItemModels(new class_4915(itemModelOutput, modelOutput));
        blockStateOutput.method_65462();
        itemModelOutput.method_65469();
        return CompletableFuture.allOf(blockStateOutput.method_65465(output, this.blockStatePathProvider),
                modelOutput.method_65478(output, this.modelPathProvider),
                itemModelOutput.method_65473(output, this.itemInfoPathProvider));
    }

    private class_4910 setupBlockModelGenerators(class_4910 blockModelGenerators) {
        // Make all these mutable, so it is possible to add our own entries.
        class_4910.field_56789 = new ArrayList<>(class_4910.field_56789);
        class_4910.field_56790 = new HashMap<>(class_4910.field_56790);
        class_4910.field_56796 = new HashMap<>(class_4910.field_56796);
        return blockModelGenerators;
    }

    private <T> boolean isValid(class_6880.class_6883<T> holder) {
        if (!this.skipAllValidation()) {
            if (holder.method_40237().method_29177().method_12836().equals(this.modId)) {
                return !this.skipValidation.contains(holder.comp_349());
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public void addBlockModels(class_4910 blockModelGenerators) {
        // NO-OP
    }

    public void addItemModels(class_4915 itemModelGenerators) {
        // NO-OP
    }

    /**
     * @see class_4910#method_25650(class_2248)
     */
    public void generateForBlocks(class_4910 blockModelGenerators, BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<class_4910, class_2248>> variants) {
        this.generateForBlocks(blockModelGenerators,
                blockSetFamily,
                variants,
                class_4946.field_23036.get(blockSetFamily.getBaseBlock().comp_349()));
    }

    /**
     * @see class_4910#method_25650(class_2248)
     */
    public void generateForBlocks(class_4910 blockModelGenerators, BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<class_4910, class_2248>> variants, class_4946 texturedModel) {
        class_5794 blockFamily = blockSetFamily.getBlockFamily();
        if (blockFamily.method_33477()) {
            class_4910.class_4912 familyProvider = blockModelGenerators.new class_4912(
                    texturedModel.method_25921());
            familyProvider.field_22838 = class_4910.method_67806(texturedModel.method_25914()
                    .method_54828(blockFamily.method_33469()));
            familyProvider.method_33522(blockFamily);
            blockSetFamily.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> holder) -> {
                BiConsumer<class_4910, class_2248> modelProvider = variants.get(variant);
                if (modelProvider != null) {
                    modelProvider.accept(blockModelGenerators, holder.comp_349());
                }
            });
        }
    }

    public void generateForItems(class_4915 itemModelGenerators, BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<class_4915, class_1792>> variants) {
        class_5794 blockFamily = blockSetFamily.getBlockFamily();
        if (blockFamily.method_33477()) {
            blockSetFamily.getItemVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_1792> holder) -> {
                BiConsumer<class_4915, class_1792> modelProvider = variants.get(variant);
                if (modelProvider != null) {
                    modelProvider.accept(itemModelGenerators, holder.comp_349());
                }
            });
        }
    }

    protected boolean skipAllValidation() {
        return false;
    }

    protected final void skipBlockValidation(class_2248 block) {
        this.skipValidation.add(block);
    }

    protected final void skipItemValidation(class_1792 item) {
        this.skipValidation.add(item);
    }

    @Override
    public final String method_10321() {
        return "Model Definitions";
    }

    public interface CustomItemModelOutput extends class_10405 {

        void method_65460(class_1792 item, class_10439.class_10441 model, class_10434.class_10543 properties);

        default void accept(class_2960 identifier, class_10439.class_10441 model) {
            this.accept(identifier, model, class_10434.class_10543.field_55549);
        }

        void accept(class_2960 identifier, class_10439.class_10441 model, class_10434.class_10543 properties);
    }

    static class BlockStateOutputImpl extends class_4916.class_10406 {
        private final Predicate<class_6880.class_6883<class_2248>> filter;

        public BlockStateOutputImpl(Predicate<class_6880.class_6883<class_2248>> filter) {
            this.filter = filter;
        }

        @Override
        public void method_65462() {
            List<class_2960> list = class_7923.field_41175.method_42017()
                    // apply a filter, so we only consider our own content
                    .filter(this.filter)
                    .filter((class_6880.class_6883<class_2248> holder) -> !this.field_55248.containsKey(holder.comp_349()))
                    .map((class_6880.class_6883<class_2248> holder) -> holder.method_40237().method_29177())
                    .toList();
            if (!list.isEmpty()) {
                throw new IllegalStateException("Missing blockstate definitions for: " + list);
            }
        }
    }

    private static class ItemModelOutputImpl extends class_4916.class_10407 implements CustomItemModelOutput {
        private final Map<class_2960, class_10434> additionalItemInfos = new HashMap<>();
        private final Predicate<class_6880.class_6883<class_1792>> filter;

        public ItemModelOutputImpl(Predicate<class_6880.class_6883<class_1792>> filter) {
            this.filter = filter;
        }

        @Override
        public void method_65460(class_1792 item, class_10439.class_10441 model, class_10434.class_10543 properties) {
            this.method_65471(item, new class_10434(model, properties));
        }

        @Override
        public void accept(class_2960 identifier, class_10439.class_10441 model, class_10434.class_10543 properties) {
            class_10434 clientItem = this.additionalItemInfos.put(identifier, new class_10434(model, properties));
            if (clientItem != null) {
                throw new IllegalStateException("Duplicate item model definition for " + identifier);
            }
        }

        @Override
        public void method_65469() {
            // apply a filter, so we only consider our own content
            class_7923.field_41178.method_42017().filter(this.filter).forEach((class_6880.class_6883<class_1792> item) -> {
                if (!this.field_55250.containsKey(item.comp_349())) {
                    if (item.comp_349() instanceof class_1747 blockItem && !this.field_55249.containsKey(blockItem)) {
                        class_2960 identifier = class_4941.method_25842(blockItem.method_7711());
                        this.method_75343(blockItem, class_10410.method_65481(identifier));
                    }
                }
            });
            this.field_55250.forEach((class_1792 item, class_1792 other) -> {
                class_10434 clientItem = this.field_55249.get(other);
                if (clientItem == null) {
                    throw new IllegalStateException("Missing donor: " + other + " -> " + item);
                } else {
                    this.method_65471(item, clientItem);
                }
            });
            List<class_2960> list = class_7923.field_41178.method_42017()
                    // apply a filter, so we only consider our own content
                    .filter(this.filter)
                    .filter((class_6880.class_6883<class_1792> item) -> !this.field_55249.containsKey(item.comp_349()))
                    .map((class_6880.class_6883<class_1792> item) -> item.method_40237().method_29177())
                    .toList();
            if (!list.isEmpty()) {
                throw new IllegalStateException("Missing item model definitions for: " + list);
            }
        }

        @Override
        public CompletableFuture<?> method_65473(class_7403 output, class_7784.class_7489 pathProvider) {
            return CompletableFuture.allOf(super.method_65473(output, pathProvider),
                    class_2405.method_65771(output, class_10434.field_55327, pathProvider::method_44107, this.additionalItemInfos));
        }
    }
}
