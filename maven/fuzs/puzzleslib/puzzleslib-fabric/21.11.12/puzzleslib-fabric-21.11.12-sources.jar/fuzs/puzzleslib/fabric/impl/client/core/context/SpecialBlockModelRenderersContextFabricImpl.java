package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.SpecialBlockModelRenderersContext;
import net.fabricmc.fabric.api.client.rendering.v1.SpecialBlockRendererRegistry;
import net.minecraft.class_10515;
import net.minecraft.class_2248;
import java.util.Objects;

public final class SpecialBlockModelRenderersContextFabricImpl implements SpecialBlockModelRenderersContext {

    @Override
    public void registerSpecialBlockModelRenderer(class_2248 block, class_10515.class_10516 specialModelRenderer) {
        Objects.requireNonNull(block, "block is null");
        Objects.requireNonNull(specialModelRenderer, "special model renderer is null");
        SpecialBlockRendererRegistry.register(block, specialModelRenderer);
    }
}
