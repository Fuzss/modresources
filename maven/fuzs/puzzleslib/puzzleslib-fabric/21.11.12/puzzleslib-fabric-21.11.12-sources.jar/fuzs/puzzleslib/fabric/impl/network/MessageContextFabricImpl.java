package fuzs.puzzleslib.fabric.impl.network;

import fuzs.puzzleslib.api.network.v4.message.configuration.ClientboundConfigurationMessage;
import fuzs.puzzleslib.api.network.v4.message.configuration.ServerboundConfigurationMessage;
import fuzs.puzzleslib.api.network.v4.message.play.ClientboundPlayMessage;
import fuzs.puzzleslib.api.network.v4.message.play.ServerboundPlayMessage;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_8610;
import net.minecraft.class_8674;
import net.minecraft.class_8710;
import net.minecraft.server.MinecraftServer;
import java.util.Objects;

public final class MessageContextFabricImpl {

    private MessageContextFabricImpl() {
        // NO-OP
    }

    public record ClientboundConfiguration(ClientConfigurationNetworking.Context context) implements ClientboundConfigurationMessage.Context {

        @Override
        public class_8674 packetListener() {
            class_8674 networkHandler = this.context.networkHandler();
            Objects.requireNonNull(networkHandler, "network handler is null");
            return networkHandler;
        }

        @Override
        public void reply(class_8710 payload) {
            this.context.responseSender().sendPacket(payload);
        }

        @Override
        public void disconnect(class_2561 component) {
            this.context.responseSender().disconnect(component);
        }

        @Override
        public class_310 client() {
            class_310 client = this.context.client();
            Objects.requireNonNull(client, "client is null");
            return client;
        }
    }

    public record ClientboundPlay(ClientPlayNetworking.Context context) implements ClientboundPlayMessage.Context {

        @Override
        public class_634 packetListener() {
            class_634 networkHandler = this.client().method_1562();
            Objects.requireNonNull(networkHandler, "network handler is null");
            return networkHandler;
        }

        @Override
        public void reply(class_8710 payload) {
            this.context.responseSender().sendPacket(payload);
        }

        @Override
        public void disconnect(class_2561 component) {
            this.context.responseSender().disconnect(component);
        }

        @Override
        public class_310 client() {
            class_310 client = this.context.client();
            Objects.requireNonNull(client, "client is null");
            return client;
        }

        @Override
        public class_746 player() {
            class_746 player = this.context.player();
            Objects.requireNonNull(player, "player is null");
            return player;
        }

        @Override
        public class_638 level() {
            return this.client().field_1687;
        }
    }

    public record ServerboundConfiguration(ServerConfigurationNetworking.Context context) implements ServerboundConfigurationMessage.Context {

        @Override
        public class_8610 packetListener() {
            class_8610 networkHandler = this.context().networkHandler();
            Objects.requireNonNull(networkHandler, "network handler is null");
            return networkHandler;
        }

        @Override
        public void reply(class_8710 payload) {
            this.context.responseSender().sendPacket(payload);
        }

        @Override
        public void disconnect(class_2561 component) {
            this.context.responseSender().disconnect(component);
        }

        @Override
        public MinecraftServer server() {
            MinecraftServer server = this.context.server();
            Objects.requireNonNull(server, "server is null");
            return server;
        }
    }

    public record ServerboundPlay(ServerPlayNetworking.Context context) implements ServerboundPlayMessage.Context {

        @Override
        public class_3244 packetListener() {
            class_3244 networkHandler = this.player().field_13987;
            Objects.requireNonNull(networkHandler, "network handler is null");
            return networkHandler;
        }

        @Override
        public void reply(class_8710 payload) {
            this.context.responseSender().sendPacket(payload);
        }

        @Override
        public void disconnect(class_2561 component) {
            this.context.responseSender().disconnect(component);
        }

        @Override
        public MinecraftServer server() {
            MinecraftServer server = this.context.server();
            Objects.requireNonNull(server, "server is null");
            return server;
        }

        @Override
        public class_3222 player() {
            class_3222 player = this.context.player();
            Objects.requireNonNull(player, "player is null");
            return player;
        }

        @Override
        public class_3218 level() {
            return this.player().method_51469();
        }
    }
}
