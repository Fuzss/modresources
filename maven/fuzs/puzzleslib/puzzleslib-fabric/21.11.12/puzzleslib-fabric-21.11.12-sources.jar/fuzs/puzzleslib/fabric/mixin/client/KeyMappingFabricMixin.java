package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.client.key.v1.KeyActivationContext;
import fuzs.puzzleslib.fabric.impl.client.key.ActivationContextKeyMapping;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;
import net.minecraft.class_11908;
import net.minecraft.class_304;

@Mixin(class_304.class)
abstract class KeyMappingFabricMixin implements ActivationContextKeyMapping {
    @Nullable @Unique private KeyActivationContext puzzleslib$keyActivationContext;

    @Inject(method = "isDown", at = @At("HEAD"), cancellable = true)
    public void isDown(CallbackInfoReturnable<Boolean> callback) {
        if (!this.puzzleslib$getKeyActivationContext().isSupportedEnvironment()) {
            callback.setReturnValue(false);
        }
    }

    @Inject(method = "matches", at = @At("HEAD"), cancellable = true)
    public void matches(class_11908 keyEvent, CallbackInfoReturnable<Boolean> callback) {
        if (!this.puzzleslib$getKeyActivationContext().isSupportedEnvironment()) {
            callback.setReturnValue(false);
        }
    }

    @Override
    public void puzzleslib$setKeyActivationContext(KeyActivationContext context) {
        Objects.requireNonNull(context, "context is null");
        this.puzzleslib$keyActivationContext = context;
    }

    @Override
    public KeyActivationContext puzzleslib$getKeyActivationContext() {
        return this.puzzleslib$keyActivationContext != null ? this.puzzleslib$keyActivationContext :
                KeyActivationContext.UNIVERSAL;
    }
}
