package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_11954;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;

/**
 * Register a renderer for a block entity.
 */
public interface BlockEntityRenderersContext {

    /**
     * Registers an {@link net.minecraft.class_827} for a given block entity.
     *
     * @param blockEntityType             the block entity type token to render for
     * @param blockEntityRendererProvider the block entity renderer provider
     * @param <T>                         the type of block entity
     */
    <T extends class_2586, S extends class_11954> void registerBlockEntityRenderer(class_2591<? extends T> blockEntityType, class_5614<T, S> blockEntityRendererProvider);
}
