package fuzs.puzzleslib.api.event.v1.server;

import com.mojang.brigadier.CommandDispatcher;
import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;

@FunctionalInterface
public interface RegisterCommandsCallback {
    EventInvoker<RegisterCommandsCallback> EVENT = EventInvoker.lookup(RegisterCommandsCallback.class);

    /**
     * Register a new command, also supports replacing existing commands by default.
     *
     * @param dispatcher  the dispatcher used for registering commands
     * @param environment command selection environment
     * @param context     registry access context
     */
    void onRegisterCommands(CommandDispatcher<class_2168> dispatcher, class_7157 context, class_2170.class_5364 environment);
}
