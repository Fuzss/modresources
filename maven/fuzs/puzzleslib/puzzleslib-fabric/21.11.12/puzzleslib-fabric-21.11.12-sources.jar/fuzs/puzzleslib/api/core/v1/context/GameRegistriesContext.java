package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_2378;

/**
 * Register built-in static registries.
 * <p>
 * For creating static registries see {@link fuzs.puzzleslib.api.init.v3.registry.RegistryFactory}.
 */
public interface GameRegistriesContext {

    /**
     * Register an already constructed static registry.
     *
     * @param registry the registry
     * @param <T>      registry values type
     */
    <T> void registerRegistry(class_2378<T> registry);
}
