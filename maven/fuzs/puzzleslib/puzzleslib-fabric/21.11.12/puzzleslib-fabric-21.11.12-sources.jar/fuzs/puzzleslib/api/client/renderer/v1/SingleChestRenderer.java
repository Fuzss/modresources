package fuzs.puzzleslib.api.client.renderer.v1;

import net.minecraft.class_1058;
import net.minecraft.class_11659;
import net.minecraft.class_11701;
import net.minecraft.class_11959;
import net.minecraft.class_12075;
import net.minecraft.class_12249;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_4722;
import net.minecraft.class_4730;
import net.minecraft.class_5614;
import net.minecraft.class_7833;
import net.minecraft.class_826;
import net.minecraft.class_9944;
import org.jspecify.annotations.Nullable;

/**
 * An extension of {@link class_826} that allows specifying custom chest texture materials for single chests (e.g.
 * ender chest).
 *
 * @param <T> the chest block entity type
 * @param <M> the chest model type
 */
public abstract class SingleChestRenderer<T extends class_2586 & class_2618, M extends class_9944, S extends SingleChestRenderer.SingleChestRenderState> extends class_826<T> {
    /**
     * The material set.
     */
    protected final class_11701 materials;
    /**
     * The chest model.
     */
    protected final M chestModel;

    /**
     * @param context    the renderer context
     * @param chestModel the single chest model
     */
    public SingleChestRenderer(class_5614.class_5615 context, M chestModel) {
        super(context);
        this.materials = context.comp_4541();
        this.chestModel = chestModel;
    }

    @Override
    public S method_74335() {
        return (S) new SingleChestRenderState();
    }

    @Override
    public void method_74365(T blockEntity, class_11959 chestRenderState, float partialTick, class_243 cameraPosition, class_11683.@Nullable class_11792 crumblingOverlay) {
        super.method_74365(blockEntity, chestRenderState, partialTick, cameraPosition, crumblingOverlay);
        ((S) chestRenderState).chestMaterial = this.getChestMaterial(blockEntity, this.field_4365);
    }

    @Override
    public void method_74367(class_11959 chestRenderState, class_4587 poseStack, class_11659 submitNodeCollector, class_12075 cameraRenderState) {
        poseStack.method_22903();
        poseStack.method_46416(0.5F, 0.5F, 0.5F);
        poseStack.method_22907(class_7833.field_40716.rotationDegrees(-chestRenderState.field_62695));
        poseStack.method_46416(-0.5F, -0.5F, -0.5F);
        this.submitChestModel((S) chestRenderState, poseStack, submitNodeCollector);
        poseStack.method_22909();
    }

    /**
     * Submit the single chest model after everything on the pose stack has been set up.
     *
     * @param chestRenderState    the chest render state
     * @param poseStack           the pose stack
     * @param submitNodeCollector the submit node collector
     */
    protected void submitChestModel(S chestRenderState, class_4587 poseStack, class_11659 submitNodeCollector) {
        class_4730 material = chestRenderState.chestMaterial;
        class_1921 renderType = material.method_24146(class_12249::method_75990);
        class_1058 textureAtlasSprite = this.materials.method_73030(material);
        submitNodeCollector.method_73490(this.chestModel,
                chestRenderState.getOpenness(),
                poseStack,
                renderType,
                chestRenderState.field_62676,
                class_4608.field_21444,
                -1,
                textureAtlasSprite,
                0,
                chestRenderState.field_62677);
    }

    /**
     * Get the single chest texture material for the chest type.
     *
     * @param blockEntity  the block entity
     * @param xmasTextures should use holiday textures
     * @return the single chest texture material
     */
    protected abstract class_4730 getChestMaterial(T blockEntity, boolean xmasTextures);

    /**
     * A custom chest render state that stores the {@link class_4730} directly, to allow for working around vanilla's
     * {@link net.minecraft.class_11959.class_11960} enum class.
     */
    public static class SingleChestRenderState extends class_11959 {
        /**
         * The chest material.
         */
        public class_4730 chestMaterial = class_4722.field_21720;

        /**
         * @return the chest lid openness
         */
        public float getOpenness() {
            float openness = this.field_62694;
            openness = 1.0F - openness;
            return 1.0F - openness * openness * openness;
        }
    }
}
