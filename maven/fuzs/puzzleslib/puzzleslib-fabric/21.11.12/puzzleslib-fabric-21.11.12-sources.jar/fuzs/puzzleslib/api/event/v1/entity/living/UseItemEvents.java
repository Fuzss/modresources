package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public final class UseItemEvents {
    public static final EventInvoker<Start> START = EventInvoker.lookup(Start.class);
    public static final EventInvoker<Tick> TICK = EventInvoker.lookup(Tick.class);
    public static final EventInvoker<Stop> STOP = EventInvoker.lookup(Stop.class);
    public static final EventInvoker<Finish> FINISH = EventInvoker.lookup(Finish.class);

    private UseItemEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Start {
        /**
         * Fired when an item starts being used in {@link class_1309#method_6019(class_1268)}.
         * <p>
         * Can be called to set a custom use duration for items, this way items that normally cannot be used for a
         * duration support that.
         *
         * @param livingEntity         the entity using the item
         * @param itemStack            the item stack being used
         * @param interactionHand      the used hand from {@link class_1309#method_6058()}
         * @param remainingUseDuration the duration in ticks the stack needs to be used until
         *                             {@link net.minecraft.class_1792#method_7861(class_1799, class_1937,
         *                             class_1309)} is called retrieved from
         *                             {@link net.minecraft.class_1792#method_7881(class_1799, class_1309)}
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the item from starting to be used</li>
         *         <li>{@link EventResult#PASS PASS} to allow the item to be used continuously</li>
         *         </ul>
         */
        EventResult onUseItemStart(class_1309 livingEntity, class_1799 itemStack, class_1268 interactionHand, MutableInt remainingUseDuration);
    }

    @FunctionalInterface
    public interface Tick {
        /**
         * Fired every tick an entity is using an item.
         *
         * @param livingEntity         the entity using the item
         * @param itemStack            the item stack being used
         * @param interactionHand      the used hand from {@link class_1309#method_6058()}
         * @param remainingUseDuration the duration in ticks the stack has already been in use for
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to immediately stop the item from being used, no methods that usually run on use release or finishing are called</li>
         *         <li>{@link EventResult#PASS PASS} to allow the item to continue ticking</li>
         *         </ul>
         */
        EventResult onUseItemTick(class_1309 livingEntity, class_1799 itemStack, class_1268 interactionHand, MutableInt remainingUseDuration);
    }

    @FunctionalInterface
    public interface Stop {
        /**
         * Fired when an item is stopped being used without being finished, meaning
         * {@link net.minecraft.class_1792#method_7881(class_1799, class_1309)} has not been reached.
         * <p>
         * {@link net.minecraft.class_1792#method_7840(class_1799, class_1937, class_1309, int)} is called for the
         * item-specific behavior to apply, like shooting bows, crossbows and tridents.
         * <p>
         * This event is called for items that do not utilise
         * {@link net.minecraft.class_1792#method_7861(class_1799, class_1937, class_1309)}.
         * <p>
         * Use items that have been stopped due to the held item stack changing do not receive this event.
         *
         * @param livingEntity         the entity using the item
         * @param itemStack            the item stack being used
         * @param interactionHand      the used hand from {@link class_1309#method_6058()}
         * @param remainingUseDuration the duration in ticks the stack has already been in use for
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent {@link net.minecraft.class_1792#method_7840(class_1799, class_1937, class_1309, int)} from being called, directly proceeding to {@link class_1309#method_6021()}</li>
         *         <li>{@link EventResult#PASS PASS} to allow the item to release normally by calling the dedicated vanilla method</li>
         *         </ul>
         */
        EventResult onUseItemStop(class_1309 livingEntity, class_1799 itemStack, class_1268 interactionHand, int remainingUseDuration);
    }

    @FunctionalInterface
    public interface Finish {
        /**
         * Fired when an item is finished being used, meaning
         * {@link net.minecraft.class_1792#method_7881(class_1799, class_1309)} has run out.
         * <p>
         * In that case {@link net.minecraft.class_1792#method_7861(class_1799, class_1937, class_1309)} is called
         * for applying effects to the user, such as restoring food points or applying mob effects.
         *
         * @param livingEntity      the entity using the item
         * @param itemStack         the item that is set to the entity's use hand after has finished, like a bowl from
         *                          eating stew, but most of the time when an item is fully consumed, like when eating
         *                          normal food, is simply returned and reduced by one item in the process
         * @param originalItemStack the copy of the item stack being used, made before using finished
         * @param interactionHand   the used hand from {@link class_1309#method_6058()}
         */
        void onUseItemFinish(class_1309 livingEntity, MutableValue<class_1799> itemStack, class_1799 originalItemStack, class_1268 interactionHand);
    }
}
