package fuzs.puzzleslib.api.network.v4.message;

import net.minecraft.class_2540;
import net.minecraft.class_9139;
import net.minecraft.class_9141;

/**
 * A simplified message that allows for manually writing to and reading from a provided
 * {@link io.netty.buffer.ByteBuf}.
 * <p>
 * This should be implemented together with any of the clientbound or serverbound message templates.
 *
 * @param <B> the {@link io.netty.buffer.ByteBuf} type
 */
public interface WritableMessage<B extends class_2540> {

    /**
     * Create a simple {@link class_9139} for the message.
     *
     * @param streamDecoder the message constructor accepting a single {@link io.netty.buffer.ByteBuf} argument
     * @param <B>the        {@link io.netty.buffer.ByteBuf} type
     * @param <V>           the message type
     * @return the stream codec
     */
    static <B extends class_2540, V extends WritableMessage<B>> class_9139<B, V> streamCodec(class_9141<B, V> streamDecoder) {
        return class_9139.method_56438(V::write, streamDecoder);
    }

    /**
     * Serialize the message to {@link io.netty.buffer.ByteBuf}.
     *
     * @param buf the byte buffer
     */
    void write(B buf);
}
