package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_332;
import net.minecraft.class_465;

@FunctionalInterface
public interface RenderContainerScreenContentsCallback {
    EventInvoker<RenderContainerScreenContentsCallback> EVENT = EventInvoker.lookup(
            RenderContainerScreenContentsCallback.class);

    /**
     * Called for {@link net.minecraft.class_465 AbstractContainerScreens},
     * after the screen foreground is drawn (like text labels) via
     * {@link class_465#method_71085(class_332, int, int, float)}.
     *
     * @param screen      the currently displayed screen
     * @param guiGraphics the gui graphics component
     * @param mouseX      the x-position of the mouse
     * @param mouseY      the y-position of the mouse
     */
    void onRenderContainerScreenContents(class_465<?> screen, class_332 guiGraphics, int mouseX, int mouseY);
}
