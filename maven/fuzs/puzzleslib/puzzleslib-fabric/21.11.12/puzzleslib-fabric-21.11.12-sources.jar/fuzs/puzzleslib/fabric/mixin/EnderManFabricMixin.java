package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import net.minecraft.class_1299;
import net.minecraft.class_1560;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1560.class)
abstract class EnderManFabricMixin extends class_1588 {

    protected EnderManFabricMixin(class_1299<? extends class_1588> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyReturnValue(method = "isBeingStaredBy", at = @At("TAIL"))
    boolean isBeingStaredBy(boolean isBeingStaredBy, class_1657 player) {
        return isBeingStaredBy && FabricLivingEvents.LOOKING_AT_ENDERMAN.invoker().onLookingAtEnderManCallback(
                class_1560.class.cast(this), player).isPass();
    }
}
