package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import net.minecraft.class_368;
import net.minecraft.class_374;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_374.class)
abstract class ToastComponentFabricMixin {

    @Inject(method = "addToast", at = @At("HEAD"), cancellable = true)
    public void addToast(class_368 toast, CallbackInfo callback) {
        EventResult result = FabricGuiEvents.ADD_TOAST.invoker().onAddToast(class_374.class.cast(this), toast);
        if (result.isInterrupt()) callback.cancel();
    }
}
