package fuzs.puzzleslib.impl.client.core.proxy;

import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.api.client.renderer.v1.model.MutableBakedQuad;
import fuzs.puzzleslib.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_10017;
import net.minecraft.class_11908;
import net.minecraft.class_1255;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_169;
import net.minecraft.class_1937;
import net.minecraft.class_2602;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3738;
import net.minecraft.class_4719;
import net.minecraft.class_5455;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_634;
import net.minecraft.class_777;
import net.minecraft.class_8000;

public interface ClientProxyImpl extends ProxyImpl {

    static ClientProxyImpl get() {
        return (ClientProxyImpl) ProxyImpl.INSTANCE;
    }

    ModConstructorImpl<ClientModConstructor> getClientModConstructorImpl();

    KeyMappingHelper getKeyMappingActivationHelper();

    @Nullable <T> T getRenderProperty(class_10017 entityRenderState, class_169<T> key);

    <T> void setRenderProperty(class_10017 entityRenderState, class_169<T> key, @Nullable T t);

    boolean isKeyActiveAndMatches(class_304 keyMapping, class_11908 keyEvent);

    class_5684 createImageComponent(class_5632 imageComponent);

    boolean onRenderTooltip(class_332 guiGraphics, class_327 font, int mouseX, int mouseY, List<class_5684> components, class_8000 positioner);

    MutableBakedQuad getMutableBakedQuad(class_777 bakedQuad);

    boolean isEffectVisibleInInventory(class_1293 mobEffect);

    boolean isEffectVisibleInGui(class_1293 mobEffect);

    void registerWoodType(class_4719 woodType);

    int getLeftStatusBarHeight(class_2960 identifier);

    int getRightStatusBarHeight(class_2960 identifier);

    @Override
    default class_1255<? super class_3738> getBlockableEventLoop(class_1937 level) {
        if (level.method_8608()) {
            return class_310.method_1551();
        } else {
            return ProxyImpl.super.getBlockableEventLoop(level);
        }
    }

    @Override
    default class_5455 getRegistryAccess() {
        return class_310.method_1551().method_1562() != null ?
                class_310.method_1551().method_1562().method_29091() : null;
    }

    @Override
    default class_1657 getClientPlayer() {
        return class_310.method_1551().field_1724;
    }

    @Override
    default class_1937 getClientLevel() {
        return class_310.method_1551().field_1687;
    }

    @Override
    default class_2602 getClientPacketListener() {
        class_634 clientPacketListener = class_310.method_1551().method_1562();
        Objects.requireNonNull(clientPacketListener, "client packet listener is null");
        return clientPacketListener;
    }

    @Override
    default boolean hasControlDown() {
        return class_310.method_1551().method_74188();
    }

    @Override
    default boolean hasShiftDown() {
        return class_310.method_1551().method_74187();
    }

    @Override
    default boolean hasAltDown() {
        return class_310.method_1551().method_74189();
    }
}
