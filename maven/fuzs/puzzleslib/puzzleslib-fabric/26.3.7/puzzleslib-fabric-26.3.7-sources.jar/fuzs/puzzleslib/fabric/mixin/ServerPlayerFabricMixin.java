package fuzs.puzzleslib.fabric.mixin;

import com.llamalad7.mixinextras.injector.v2.WrapWithCondition;
import com.mojang.authlib.GameProfile;
import fuzs.puzzleslib.common.api.event.v1.core.EventResult;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import fuzs.puzzleslib.fabric.api.event.v1.FabricPlayerEvents;
import fuzs.puzzleslib.fabric.impl.event.CapturedDropsEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Prediction;
import net.minecraft.world.Container;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.OptionalInt;

@Mixin(ServerPlayer.class)
abstract class ServerPlayerFabricMixin extends Player implements CapturedDropsEntity {

    public ServerPlayerFabricMixin(Level level, GameProfile gameProfile) {
        super(level, gameProfile);
    }

    @WrapWithCondition(method = "drop(Z)V",
                       at = @At(value = "INVOKE",
                                target = "Lnet/minecraft/server/level/ServerPlayer;drop(Lnet/minecraft/world/item/ItemStack;ZLnet/minecraft/util/Prediction;)Lnet/minecraft/world/entity/item/ItemEntity;"))
    public boolean drop(ServerPlayer player, ItemStack itemStack, boolean thrownFromHand, Prediction prediction) {
        return FabricPlayerEvents.ITEM_TOSS.invoker().onItemToss(player, itemStack).isPass();
    }

    @Inject(method = "die", at = @At("HEAD"), cancellable = true)
    public void die(DamageSource source, CallbackInfo callback) {
        EventResult eventResult = FabricLivingEvents.LIVING_DEATH.invoker().onLivingDeath(this, source);
        if (eventResult.isInterrupt()) {
            callback.cancel();
        }
    }

    @Inject(method = "openMenu", at = @At("TAIL"))
    public void openMenu(@Nullable MenuProvider provider, CallbackInfoReturnable<OptionalInt> callback) {
        FabricPlayerEvents.CONTAINER_OPEN.invoker().onContainerOpen(ServerPlayer.class.cast(this), this.containerMenu);
    }

    @Inject(method = "openHorseInventory", at = @At("TAIL"))
    public void openHorseInventory(AbstractHorse horse, Container container, CallbackInfo callback) {
        FabricPlayerEvents.CONTAINER_OPEN.invoker().onContainerOpen(ServerPlayer.class.cast(this), this.containerMenu);
    }

    @Inject(method = "doCloseContainer",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/world/inventory/InventoryMenu;transferState(Lnet/minecraft/world/inventory/AbstractContainerMenu;)V",
                     shift = At.Shift.AFTER))
    public void doCloseContainer(CallbackInfo callback) {
        FabricPlayerEvents.CONTAINER_CLOSE.invoker()
                .onContainerClose(ServerPlayer.class.cast(this), this.containerMenu);
    }

    @Inject(method = "stopSleepInBed", at = @At("HEAD"))
    public void stopSleepInBed(boolean forcefulWakeUp, boolean updateLevelList, CallbackInfo callback) {
        FabricPlayerEvents.STOP_SLEEP_IN_BED.invoker()
                .onStopSleepInBed(ServerPlayer.class.cast(this), !forcefulWakeUp && !updateLevelList);
    }
}
