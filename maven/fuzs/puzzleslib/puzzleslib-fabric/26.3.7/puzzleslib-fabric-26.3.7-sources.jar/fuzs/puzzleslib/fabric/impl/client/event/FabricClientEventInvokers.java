package fuzs.puzzleslib.fabric.impl.client.event;

import com.mojang.blaze3d.systems.RenderSystem;
import fuzs.puzzleslib.common.api.client.event.v1.*;
import fuzs.puzzleslib.common.api.client.event.v1.entity.ClientEntityEvents;
import fuzs.puzzleslib.common.api.client.event.v1.entity.player.*;
import fuzs.puzzleslib.common.api.client.event.v1.gui.*;
import fuzs.puzzleslib.common.api.client.event.v1.level.ClientChunkEvents;
import fuzs.puzzleslib.common.api.client.event.v1.level.ClientLevelEvents;
import fuzs.puzzleslib.common.api.client.event.v1.level.ClientLevelTickEvents;
import fuzs.puzzleslib.common.api.client.event.v1.renderer.*;
import fuzs.puzzleslib.common.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.common.api.event.v1.core.EventResult;
import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.common.impl.PuzzlesLibMod;
import fuzs.puzzleslib.fabric.api.client.event.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.ExtractItemDecorationsCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityRenderLayerRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.level.LevelExtractionEvents;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.CommonLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.CharacterEvent;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.state.level.BlockOutlineRenderState;
import net.minecraft.core.BlockPos;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Function;

import static fuzs.puzzleslib.fabric.api.event.v1.core.FabricEventInvokerRegistry.INSTANCE;

@SuppressWarnings("unchecked")
public final class FabricClientEventInvokers {

    private FabricClientEventInvokers() {
        // NO-OP
    }

    public static void registerLoadingHandlers() {
        INSTANCE.register(ScreenOpeningCallback.class, FabricGuiEvents.SCREEN_OPENING);
        INSTANCE.register(ClientLifecycleEvents.Started.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED,
                (ClientLifecycleEvents.Started callback) -> {
                    return callback::onClientStarted;
                });
        INSTANCE.register(ClientLifecycleEvents.Stopping.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING,
                (ClientLifecycleEvents.Stopping callback) -> {
                    return callback::onClientStopping;
                });
        INSTANCE.register(ClientSetupCallback.class, (ClientSetupCallback callback, @Nullable Object context) -> {
            callback.onClientSetup();
        });
        INSTANCE.register(ExtractItemStackDecorationsCallback.class,
                ExtractItemDecorationsCallback.EVENT,
                (ExtractItemStackDecorationsCallback callback, @Nullable Object context) -> {
                    return (GuiGraphicsExtractor guiGraphics, Font font, ItemStack itemStack, int posX, int posY) -> {
                        Objects.requireNonNull(context, "context is null");
                        Item item = (Item) context;
                        if (itemStack.is(item)) {
                            callback.onExtractItemStackDecorations(guiGraphics, font, itemStack, posX, posY);
                        }
                    };
                });
        INSTANCE.register(AddLivingEntityRenderLayersCallback.class,
                LivingEntityRenderLayerRegistrationCallback.EVENT,
                (AddLivingEntityRenderLayersCallback callback) -> {
                    return (EntityType<? extends LivingEntity> entityType, LivingEntityRenderer<?, ?, ?> entityRenderer, LivingEntityRenderLayerRegistrationCallback.RegistrationHelper registrationHelper, EntityRendererProvider.Context context) -> {
                        callback.addLivingEntityRenderLayers(entityType, entityRenderer, context);
                    };
                });
    }

    public static void registerEventHandlers() {
        INSTANCE.register(ClientTagsUpdatedCallback.class,
                CommonLifecycleEvents.TAGS_LOADED,
                (ClientTagsUpdatedCallback callback) -> {
                    return (RegistryAccess registries, boolean client) -> {
                        if (client) {
                            callback.onClientTagsUpdated(registries);
                        }
                    };
                });
        INSTANCE.register(ClientTickEvents.Start.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK,
                (ClientTickEvents.Start callback) -> {
                    return callback::onStartClientTick;
                });
        INSTANCE.register(ClientTickEvents.End.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK,
                (ClientTickEvents.End callback) -> {
                    return callback::onEndClientTick;
                });
        AtomicInteger atomicInteger = new AtomicInteger();
        INSTANCE.register(RenderGuiEvents.Before.class, (RenderGuiEvents.Before callback, @Nullable Object context) -> {
            // register as late as possible, so we capture as many hud layers as possible
            net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED.register((Minecraft minecraft) -> {
                HudElementRegistry.addFirst(PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker) -> {
                            if (!minecraft.gui.hud.isHidden()) {
                                callback.onBeforeRenderGui(guiGraphics, deltaTracker);
                            }
                        });
                // the sleep layer is the only layer that renders when the gui is hidden
                HudElementRegistry.attachElementBefore(VanillaHudElements.SLEEP,
                        PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker) -> {
                            if (minecraft.gui.hud.isHidden()) {
                                callback.onBeforeRenderGui(guiGraphics, deltaTracker);
                            }
                        });
            });
        });
        INSTANCE.register(RenderGuiEvents.After.class, (RenderGuiEvents.After callback, @Nullable Object context) -> {
            // register as late as possible, so we capture as many hud layers as possible
            net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED.register((Minecraft minecraft) -> {
                HudElementRegistry.addLast(PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker) -> {
                            if (!minecraft.gui.hud.isHidden()) {
                                callback.onAfterRenderGui(guiGraphics, deltaTracker);
                            }
                        });
                // the sleep layer is the only layer that renders when the gui is hidden
                HudElementRegistry.attachElementAfter(VanillaHudElements.SLEEP,
                        PuzzlesLibMod.id(String.valueOf(atomicInteger.getAndIncrement())),
                        (GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker) -> {
                            if (minecraft.gui.hud.isHidden()) {
                                callback.onAfterRenderGui(guiGraphics, deltaTracker);
                            }
                        });
            });
        });
        INSTANCE.register(ItemTooltipCallback.class,
                net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT,
                (ItemTooltipCallback callback) -> {
                    return (ItemStack stack, Item.TooltipContext tooltipContext, TooltipFlag context, List<Component> lines) -> {
                        // This uses some font texture when splitting text or measuring text width.
                        // It will throw if not on the render thread, like some worker or networking.
                        if (!RenderSystem.isOnRenderThread()) {
                            return;
                        }

                        callback.onItemTooltip(stack, lines, tooltipContext, Minecraft.getInstance().player, context);
                    };
                });
        INSTANCE.register(SubmitNameTagCallback.class, FabricRendererEvents.SUBMIT_NAME_TAG);
        INSTANCE.register(PrepareInventoryMobEffectsCallback.class, FabricGuiEvents.INVENTORY_MOB_EFFECTS);
        INSTANCE.register(ComputeFovModifierCallback.class, FabricClientPlayerEvents.COMPUTE_FOV_MODIFIER);
        INSTANCE.register(ScreenEvents.BeforeInit.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT,
                (callback, context) -> {
                    Objects.requireNonNull(context, "context is null");
                    return (Minecraft minecraft, Screen screen, int scaledWidth, int scaledHeight) -> {
                        if (!((Class<?>) context).isInstance(screen)) {
                            return;
                        }

                        callback.onBeforeInit(screen, scaledWidth, scaledHeight);
                    };
                });
        INSTANCE.register(ScreenEvents.AfterInit.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT,
                (callback, context) -> {
                    Objects.requireNonNull(context, "context is null");
                    return (Minecraft minecraft, Screen screen, int scaledWidth, int scaledHeight) -> {
                        if (!((Class<?>) context).isInstance(screen)) {
                            return;
                        }

                        callback.onAfterInit(screen, scaledWidth, scaledHeight);
                    };
                });
        registerScreenEvent(ScreenEvents.Remove.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.Remove.class,
                callback -> {
                    return callback::onRemove;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::remove);
        registerScreenEvent(ScreenEvents.BeforeExtract.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BeforeExtract.class,
                callback -> {
                    return callback::onBeforeExtract;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::beforeExtract);
        registerScreenEvent(ScreenEvents.AfterBackground.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterBackground.class,
                callback -> {
                    return callback::onAfterBackground;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterBackground);
        registerScreenEvent(ScreenEvents.AfterForeground.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterForeground.class,
                callback -> {
                    return callback::onAfterForeground;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterForeground);
        registerScreenEvent(ScreenEvents.AfterExtract.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterExtract.class,
                callback -> {
                    return callback::onAfterExtract;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterExtract);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseClick.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseClick.class,
                callback -> {
                    return (Screen screen, MouseButtonEvent mouseButtonEvent) -> {
                        return callback.onBeforeMouseClick(screen, mouseButtonEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseClick);
        registerScreenEvent(ScreenMouseEvents.AfterMouseClick.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseClick.class,
                callback -> {
                    return (Screen screen, MouseButtonEvent mouseButtonEvent, boolean consumed) -> {
                        callback.onAfterMouseClick(screen, mouseButtonEvent);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseClick);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseRelease.class,
                callback -> {
                    return (Screen screen, MouseButtonEvent mouseButtonEvent) -> {
                        return callback.onBeforeMouseRelease(screen, mouseButtonEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseRelease);
        registerScreenEvent(ScreenMouseEvents.AfterMouseRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseRelease.class,
                callback -> {
                    return (Screen screen, MouseButtonEvent mouseButtonEvent, boolean consumed) -> {
                        callback.onAfterMouseRelease(screen, mouseButtonEvent);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseRelease);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseScroll.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseScroll.class,
                callback -> {
                    return (Screen screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount) -> {
                        return callback.onBeforeMouseScroll(screen, mouseX, mouseY, horizontalAmount, verticalAmount)
                                .isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseScroll);
        registerScreenEvent(ScreenMouseEvents.AfterMouseScroll.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseScroll.class,
                callback -> {
                    return (Screen screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount, boolean consumed) -> {
                        callback.onAfterMouseScroll(screen, mouseX, mouseY, horizontalAmount, verticalAmount);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseScroll);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseDrag.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseDrag.class,
                callback -> {
                    return (Screen screen, MouseButtonEvent mouseButtonEvent, double horizontalAmount, double verticalAmount) -> {
                        return callback.onBeforeMouseDrag(screen, mouseButtonEvent, horizontalAmount, verticalAmount)
                                .isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseDrag);
        registerScreenEvent(ScreenMouseEvents.AfterMouseDrag.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseDrag.class,
                callback -> {
                    return (Screen screen, MouseButtonEvent mouseButtonEvent, double horizontalAmount, double verticalAmount, boolean consumed) -> {
                        callback.onAfterMouseDrag(screen, mouseButtonEvent, horizontalAmount, verticalAmount);
                        return false;
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseDrag);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyPress.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyPress.class,
                callback -> {
                    return (Screen screen, KeyEvent keyEvent) -> {
                        return callback.onBeforeKeyPress(screen, keyEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyPress.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyPress.class,
                callback -> {
                    return callback::onAfterKeyPress;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyRelease.class,
                callback -> {
                    return (Screen screen, KeyEvent keyEvent) -> {
                        return callback.onBeforeKeyRelease(screen, keyEvent).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyRelease);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyRelease.class,
                callback -> {
                    return callback::onAfterKeyRelease;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyRelease);
        registerScreenEvent(ScreenKeyboardEvents.BeforeCharacterType.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowCharType.class,
                callback -> {
                    return (Screen screen, CharacterEvent event) -> {
                        return callback.onBeforeCharacterType(screen, event).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowCharType);
        registerScreenEvent(ScreenKeyboardEvents.AfterCharacterType.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterCharType.class,
                callback -> {
                    return callback::onAfterCharacterType;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterCharType);
        INSTANCE.register(ClientEntityEvents.Load.class, FabricClientEntityEvents.ENTITY_LOAD);
        INSTANCE.register(ClientEntityEvents.Unload.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents.ENTITY_UNLOAD,
                (ClientEntityEvents.Unload callback) -> {
                    return callback::onEntityUnload;
                });
        INSTANCE.register(ClientInputEvents.MouseClick.class, FabricClientEvents.MOUSE_CLICK);
        INSTANCE.register(ClientInputEvents.MouseScroll.class, FabricClientEvents.MOUSE_SCROLL);
        INSTANCE.register(ClientInputEvents.KeyPress.class, FabricClientEvents.KEY_PRESS);
        INSTANCE.register(SubmitLivingEntityEvents.Before.class, FabricRendererEvents.BEFORE_SUBMIT_LIVING_ENTITY);
        INSTANCE.register(SubmitLivingEntityEvents.After.class, FabricRendererEvents.AFTER_SUBMIT_LIVING_ENTITY);
        INSTANCE.register(SubmitArmWithItemCallback.class, FabricRendererEvents.SUBMIT_ARM_WITH_ITEM);
        INSTANCE.register(ComputeCameraAnglesCallback.class, FabricRendererEvents.COMPUTE_CAMERA_ANGLES);
        INSTANCE.register(ClientLevelTickEvents.Start.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_LEVEL_TICK,
                (ClientLevelTickEvents.Start callback) -> {
                    return (ClientLevel clientLevel) -> {
                        callback.onStartLevelTick(Minecraft.getInstance(), clientLevel);
                    };
                });
        INSTANCE.register(ClientLevelTickEvents.End.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_LEVEL_TICK,
                (ClientLevelTickEvents.End callback) -> {
                    return (ClientLevel clientLevel) -> {
                        callback.onEndLevelTick(Minecraft.getInstance(), clientLevel);
                    };
                });
        INSTANCE.register(ClientChunkEvents.Load.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_LOAD,
                (ClientChunkEvents.Load callback) -> {
                    return callback::onChunkLoad;
                });
        INSTANCE.register(ClientChunkEvents.Unload.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_UNLOAD,
                (ClientChunkEvents.Unload callback) -> {
                    return callback::onChunkUnload;
                });
        INSTANCE.register(ClientPlayerNetworkEvents.Join.class, FabricClientPlayerEvents.PLAYER_JOIN);
        INSTANCE.register(ClientPlayerNetworkEvents.Leave.class, FabricClientPlayerEvents.PLAYER_LEAVE);
        INSTANCE.register(ClientPlayerCopyCallback.class, FabricClientPlayerEvents.PLAYER_COPY);
        INSTANCE.register(InteractionInputEvents.Attack.class,
                ClientPreAttackCallback.EVENT,
                (InteractionInputEvents.Attack callback) -> {
                    return (Minecraft minecraft, LocalPlayer player, int clickCount) -> {
                        if (minecraft.missTime <= 0 && minecraft.hitResult != null) {
                            if (clickCount != 0) {
                                if (!player.isHandsBusy()) {
                                    ItemStack itemInHand = player.getItemInHand(InteractionHand.MAIN_HAND);
                                    if (itemInHand.isItemEnabled(minecraft.level.enabledFeatures())) {
                                        return callback.onAttackInteraction(minecraft, player, minecraft.hitResult)
                                                .isInterrupt();
                                    }
                                }
                            } else {
                                if (!player.isUsingItem() && minecraft.hitResult.getType() == HitResult.Type.BLOCK) {
                                    if (!minecraft.level.isEmptyBlock(((BlockHitResult) minecraft.hitResult).getBlockPos())) {
                                        return callback.onAttackInteraction(minecraft, player, minecraft.hitResult)
                                                .isInterrupt();
                                    }
                                }
                            }
                        }

                        return false;
                    };
                });
        INSTANCE.register(InteractionInputEvents.Use.class,
                UseBlockCallback.EVENT,
                (InteractionInputEvents.Use callback, @Nullable Object context) -> {
                    return (Player player, Level level, InteractionHand hand, BlockHitResult hitResult) -> {
                        // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                        // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                        if (!level.isClientSide()) {
                            return InteractionResult.PASS;
                        }

                        Minecraft minecraft = Minecraft.getInstance();
                        EventResult eventResult = callback.onUseInteraction(minecraft,
                                (LocalPlayer) player,
                                hand,
                                minecraft.hitResult);
                        // when interrupted cancel the interaction without the server being notified
                        return eventResult.isInterrupt() ? InteractionResult.FAIL : InteractionResult.PASS;
                    };
                },
                EventPhase::early,
                true);
        INSTANCE.register(InteractionInputEvents.Use.class,
                UseEntityCallback.EVENT,
                (InteractionInputEvents.Use callback, @Nullable Object context) -> {
                    return (Player player, Level level, InteractionHand hand, Entity entity, @Nullable EntityHitResult hitResult) -> {
                        // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                        // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                        if (!level.isClientSide()) {
                            return InteractionResult.PASS;
                        }

                        Minecraft minecraft = Minecraft.getInstance();
                        EventResult eventResult = callback.onUseInteraction(minecraft,
                                (LocalPlayer) player,
                                hand,
                                minecraft.hitResult);
                        // when interrupted cancel the interaction without the server being notified
                        return eventResult.isInterrupt() ? InteractionResult.FAIL : InteractionResult.PASS;
                    };
                },
                EventPhase::early,
                true);
        INSTANCE.register(InteractionInputEvents.Use.class,
                UseItemCallback.EVENT,
                (InteractionInputEvents.Use callback, @Nullable Object context) -> {
                    return (Player player, Level level, InteractionHand hand) -> {
                        // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                        // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                        if (!level.isClientSide()) {
                            return InteractionResult.PASS;
                        }

                        Minecraft minecraft = Minecraft.getInstance();
                        EventResult eventResult = callback.onUseInteraction(minecraft,
                                (LocalPlayer) player,
                                hand,
                                minecraft.hitResult);
                        // when interrupted cancel the interaction without the server being notified
                        return eventResult.isInterrupt() ? InteractionResult.FAIL : InteractionResult.PASS;
                    };
                },
                EventPhase::early,
                true);
        INSTANCE.register(InteractionInputEvents.Pick.class, FabricClientPlayerEvents.PICK_INTERACTION_INPUT);
        INSTANCE.register(ClientLevelEvents.Load.class, FabricClientLevelEvents.LOAD_LEVEL);
        INSTANCE.register(ClientLevelEvents.Unload.class, FabricClientLevelEvents.UNLOAD_LEVEL);
        INSTANCE.register(MovementInputUpdateCallback.class, FabricClientPlayerEvents.MOVEMENT_INPUT_UPDATE);
        INSTANCE.register(FogEvents.Setup.class, FabricRendererEvents.SETUP_FOG);
        INSTANCE.register(FogEvents.Color.class, FabricRendererEvents.FOG_COLOR);
        INSTANCE.register(RenderTooltipCallback.class, FabricGuiEvents.RENDER_TOOLTIP);
        INSTANCE.register(ExtractBlockOutlineCallback.class,
                LevelExtractionEvents.AFTER_BLOCK_OUTLINE_EXTRACTION,
                (ExtractBlockOutlineCallback callback) -> {
                    return (LevelExtractionContext context, @Nullable HitResult hitResult) -> {
                        if (hitResult == null || hitResult.getType() != HitResult.Type.BLOCK) {
                            return;
                        }

                        BlockOutlineRenderState renderState = context.levelState().blockOutlineRenderState;
                        if (renderState == null) {
                            return;
                        }

                        BlockPos blockPos = ((BlockHitResult) hitResult).getBlockPos();
                        EventResultHolder<@Nullable VoxelShape> eventResult = callback.onExtractBlockOutline(context.level(),
                                blockPos,
                                context.level().getBlockState(blockPos),
                                (BlockHitResult) hitResult,
                                CollisionContext.of(context.camera().entity()));
                        eventResult.ifInterrupt((@Nullable VoxelShape voxelShape) -> {
                            if (voxelShape != null) {
                                context.levelState().blockOutlineRenderState = new BlockOutlineRenderState(renderState.pos(),
                                        renderState.isTranslucent(),
                                        renderState.highContrast(),
                                        voxelShape,
                                        renderState.collisionShape(),
                                        renderState.occlusionShape(),
                                        renderState.interactionShape());
                            } else {
                                context.levelState().blockOutlineRenderState = null;
                            }
                        });
                    };
                });
        INSTANCE.register(AddToastCallback.class, FabricGuiEvents.ADD_TOAST);
        INSTANCE.register(ComputeFieldOfViewCallback.class, FabricRendererEvents.COMPUTE_FIELD_OF_VIEW);
        INSTANCE.register(ChatMessageReceivedCallback.class, FabricClientEvents.CHAT_MESSAGE_RECEIVED);
        INSTANCE.register(GatherEffectScreenTooltipCallback.class, FabricGuiEvents.GATHER_EFFECT_SCREEN_TOOLTIP);
        INSTANCE.register(ExtractEntityRenderStateCallback.class, FabricRendererEvents.EXTRACT_ENTITY_RENDER_STATE);
        INSTANCE.register(ExtractLevelRenderStateCallback.class,
                LevelExtractionEvents.END_EXTRACTION,
                (ExtractLevelRenderStateCallback callback) -> {
                    return (LevelExtractionContext context) -> {
                        callback.onExtractLevelRenderState(Minecraft.getInstance().levelExtractor,
                                context.levelState(),
                                context.level(),
                                context.camera(),
                                context.camera().getCullFrustum(),
                                context.deltaTracker());
                    };
                });
    }

    private static <T, E> void registerScreenEvent(Class<T> clazz, Class<E> eventType, Function<T, E> converter, Function<Screen, Event<E>> eventGetter) {
        INSTANCE.register(clazz,
                eventType,
                converter,
                (Object context, Consumer<Event<E>> applyToInvoker, Consumer<Event<E>> removeInvoker) -> {
                    // we need to keep our own event invokers during the whole pre-init phase to guarantee phase ordering is applied correctly,
                    // since this is managed in the event invokers and there seems to be no way to handle it with just the Fabric event
                    // (since the Fabric event doesn't allow for retrieving already applied event phase orders),
                    // so we register all screen events during pre-init, which allows post-init to already clear our internal map again
                    net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT.register((Minecraft client, Screen screen, int scaledWidth, int scaledHeight) -> {
                        if (((Class<?>) context).isInstance(screen)) {
                            applyToInvoker.accept(eventGetter.apply(screen));
                        }
                    });
                    net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((Minecraft client, Screen screen, int scaledWidth, int scaledHeight) -> {
                        if (((Class<?>) context).isInstance(screen)) {
                            removeInvoker.accept(eventGetter.apply(screen));
                        }
                    });
                });
    }
}
