package fuzs.puzzleslib.fabric.api.client.event.v1;

import fuzs.puzzleslib.common.api.client.event.v1.gui.*;
import fuzs.puzzleslib.fabric.api.event.v1.core.FabricEventFactory;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.screens.Screen;

public final class FabricGuiEvents {
    /**
     * Called before mob effects are drawn next to the inventory menu, used to force a rendering mode; or to cancel the
     * rendering completely.
     */
    public static final Event<PrepareInventoryMobEffectsCallback> INVENTORY_MOB_EFFECTS = FabricEventFactory.createResult(
            PrepareInventoryMobEffectsCallback.class);
    /**
     * Called just before a new screen is set to {@link Gui#screen()} in {@link Gui#setScreen(Screen)}, allows for
     * exchanging the new screen with a different one, or can prevent a new screen from opening, by returning the
     * original screen (which will be initialized once again).
     */
    public static final Event<ScreenOpeningCallback> SCREEN_OPENING = FabricEventFactory.createResultHolder(
            ScreenOpeningCallback.class);
    /**
     * Called just before a tooltip is drawn on a screen, allows for preventing the tooltip from drawing.
     */
    public static final Event<RenderTooltipCallback> RENDER_TOOLTIP = FabricEventFactory.createResult(
            RenderTooltipCallback.class);
    /**
     * Fires when a {@link Toast} is about to be queued in
     * {@link net.minecraft.client.gui.components.toasts.ToastManager#addToast(Toast)}.
     */
    public static final Event<AddToastCallback> ADD_TOAST = FabricEventFactory.createResult(AddToastCallback.class);
    /**
     * Called when tooltip lines are gathered for an effect widget in the player inventory when it is hovered by the
     * cursor.
     */
    public static final Event<GatherEffectScreenTooltipCallback> GATHER_EFFECT_SCREEN_TOOLTIP = FabricEventFactory.create(
            GatherEffectScreenTooltipCallback.class);

    private FabricGuiEvents() {
        // NO-OP
    }
}
