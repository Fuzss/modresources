package fuzs.puzzleslib.api.data.v2.tags;

import fuzs.puzzleslib.api.config.v3.serialization.KeyedValueProvider;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.api.init.v3.registry.RegistryHelper;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import fuzs.puzzleslib.impl.data.SortingTagBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_2378;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public abstract class AbstractTagProvider<T> extends class_2474<T> {
    private static final class_3495 STATIC_TAG_BUILDER = class_3495.method_26778();

    protected final String modId;
    @Nullable
    private final class_2378<T> registry;
    @Nullable
    private final Function<T, class_5321<T>> keyExtractor;

    public AbstractTagProvider(class_5321<? extends class_2378<T>> registryKey, DataProviderContext context) {
        this(registryKey, context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractTagProvider(class_5321<? extends class_2378<T>> registryKey, String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
        super(packOutput, registryKey, registries, CompletableFuture.completedFuture((class_6862<T> tagKey) -> {
            return Objects.equals(tagKey.comp_327().method_12836(), modId) ? Optional.empty() :
                    Optional.of(STATIC_TAG_BUILDER);
        }));
        this.modId = modId;
        this.registry = LookupHelper.getRegistry(registryKey).orElse(null);
        this.keyExtractor =
                this.registry != null ? (T t) -> RegistryHelper.getResourceKeyOrThrow(this.registry, t) : null;
    }

    @Override
    public abstract void method_10514(class_7225.class_7874 registries);

    @Override
    protected class_3495 method_27169(class_6862<T> tag) {
        return this.field_11481.computeIfAbsent(tag.comp_327(), (class_2960 id) -> new SortingTagBuilder());
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(String id) {
        return this.tag(class_2960.method_60654(id));
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(String id, boolean replace) {
        return this.tag(class_2960.method_60654(id), replace);
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(class_2960 id) {
        return this.method_10512(class_6862.method_40092(this.field_40957, id));
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(class_2960 id, boolean replace) {
        return this.tag(class_6862.method_40092(this.field_40957, id), replace);
    }

    @Override
    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> method_10512(class_6862<T> tag) {
        class_3495 builder = this.method_27169(tag);
        return KeyedValueProvider.tags(builder, this.field_40957);
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(class_6862<T> tag, boolean replace) {
        class_3495 builder = this.method_27169(tag);
        ProxyImpl.get().setTagBuilderReplace(builder, replace);
        return KeyedValueProvider.tags(builder, this.field_40957);
    }

    @Deprecated
    public AbstractTagAppender<T> add(String string) {
        return this.add(class_2960.method_60654(string));
    }

    @Deprecated
    public AbstractTagAppender<T> add(class_2960 resourceLocation) {
        return this.add(class_6862.method_40092(this.field_40957, resourceLocation));
    }

    @Deprecated
    public AbstractTagAppender<T> add(class_6862<T> tagKey) {
        return ProxyImpl.get().getTagAppenderV2(this.method_27169(tagKey), this.keyExtractor);
    }

    @Deprecated
    protected class_2378<T> registry() {
        Objects.requireNonNull(this.registry, "registry is null");
        return this.registry;
    }

    @Deprecated
    protected Function<T, class_5321<T>> keyExtractor() {
        Objects.requireNonNull(this.keyExtractor, "key extractor is null");
        return this.keyExtractor;
    }
}
