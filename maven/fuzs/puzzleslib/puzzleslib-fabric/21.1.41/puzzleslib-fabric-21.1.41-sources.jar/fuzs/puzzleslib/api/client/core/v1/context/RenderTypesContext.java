package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_3611;

/**
 * Register custom {@link class_1921}s for blocks and fluids.
 *
 * @param <T> object type supported by provider, either {@link class_2248} or {@link class_3611}
 */
public interface RenderTypesContext<T> {

    /**
     * Register a <code>renderType</code> for an <code>object</code>
     *
     * @param renderType the {@link class_1921} for <code>object</code>
     * @param objects    object types supporting render type, either {@link class_2248} or {@link class_3611}
     */
    @SuppressWarnings("unchecked")
    void registerRenderType(class_1921 renderType, T... objects);

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for an object type.
     * <p>When not render type is registered {@link class_1921#method_23577()} is returned.
     *
     * @param object the object type to get the render type for
     * @return the render type
     */
    class_1921 getRenderType(T object);
}
