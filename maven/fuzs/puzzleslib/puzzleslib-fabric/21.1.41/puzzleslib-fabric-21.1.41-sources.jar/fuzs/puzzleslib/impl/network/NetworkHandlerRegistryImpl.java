package fuzs.puzzleslib.impl.network;

import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import fuzs.puzzleslib.api.core.v1.ModContainer;
import fuzs.puzzleslib.api.core.v1.Proxy;
import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.*;
import fuzs.puzzleslib.api.network.v4.NetworkingHelper;
import fuzs.puzzleslib.api.util.v1.EntityHelper;
import fuzs.puzzleslib.impl.core.Freezable;
import fuzs.puzzleslib.impl.network.codec.CustomPacketPayloadAdapter;
import org.jetbrains.annotations.Nullable;

import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2540;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_634;
import net.minecraft.class_8705;
import net.minecraft.class_8706;
import net.minecraft.class_8710;
import net.minecraft.class_9141;

public abstract class NetworkHandlerRegistryImpl implements NetworkHandler.Builder, Freezable {
    private final Map<Class<?>, class_8710.class_9154<CustomPacketPayloadAdapter<?>>> messageTypes = new IdentityHashMap<>();
    private final Map<Class<?>, class_9141<class_2540, ?>> clientboundMessages = new LinkedHashMap<>();
    private final Map<Class<?>, class_9141<class_2540, ?>> serverboundMessages = new LinkedHashMap<>();
    protected final AtomicInteger discriminator = new AtomicInteger();
    protected final class_2960 channelName;
    protected boolean optional;
    protected boolean isFrozen;

    protected NetworkHandlerRegistryImpl(String modId) {
        this.channelName = class_2960.method_60655(modId, "play");
    }

    @Override
    public abstract <T> class_2596<class_8705> toClientboundPacket(ClientboundMessage<T> message);

    @Override
    public abstract <T> class_2596<class_8706> toServerboundPacket(ServerboundMessage<T> message);

    @Override
    public <T> void sendMessage(PlayerSet playerSet, ClientboundMessage<T> message) {
        class_8710.class_9154<?> type = this.getMessageType(message);
        class_2596<?> packet = this.toClientboundPacket(message);
        playerSet.apply((class_3222 serverPlayer) -> {
            if (NetworkingHelper.hasChannel(serverPlayer.field_13987, type)
                    && !EntityHelper.isFakePlayer(serverPlayer)) {
                serverPlayer.field_13987.method_14364(packet);
            }
        });
    }

    @Override
    public <T> void sendMessage(ServerboundMessage<T> message) {
        class_634 clientPacketListener = Proxy.INSTANCE.getClientPacketListener();
        class_8710.class_9154<?> type = this.getMessageType(message);
        if (ClientAbstractions.INSTANCE.hasChannel(clientPacketListener, type)) {
            clientPacketListener.method_52787(this.toServerboundPacket(message));
        }
    }

    @Override
    public <T extends Record & ClientboundMessage<T>> Builder registerClientbound(Class<T> clazz) {
        return this.registerMessage(this.clientboundMessages, clazz, null);
    }

    @Override
    public <T extends Record & ServerboundMessage<T>> Builder registerServerbound(Class<T> clazz) {
        return this.registerMessage(this.serverboundMessages, clazz, null);
    }

    @Override
    public <T extends MessageV2<T>> Builder registerLegacyClientbound(Class<T> clazz, class_9141<class_2540, T> factory) {
        return this.registerMessage(this.clientboundMessages, clazz, factory);
    }

    @Override
    public <T extends MessageV2<T>> Builder registerLegacyServerbound(Class<T> clazz, class_9141<class_2540, T> factory) {
        return this.registerMessage(this.serverboundMessages, clazz, factory);
    }

    private Builder registerMessage(Map<Class<?>, class_9141<class_2540, ?>> messages, Class<?> clazz, @Nullable class_9141<class_2540, ?> factory) {
        this.isWritableOrThrow();
        if (messages.containsKey(clazz)) {
            throw new IllegalStateException("Duplicate message of type " + clazz);
        } else {
            messages.put(clazz, factory);
        }

        return this;
    }

    @Override
    public Builder optional() {
        this.isWritableOrThrow();
        this.optional = true;
        return this;
    }

    @Override
    public void freeze() {
        for (Map.Entry<Class<?>, class_9141<class_2540, ?>> entry : this.clientboundMessages.entrySet()) {
            if (entry.getValue() != null) {
                this.registerLegacyClientbound$Internal(entry.getKey(), entry.getValue());
            } else {
                this.registerClientbound$Internal(entry.getKey());
            }
        }

        for (Map.Entry<Class<?>, class_9141<class_2540, ?>> entry : this.serverboundMessages.entrySet()) {
            if (entry.getValue() != null) {
                this.registerLegacyServerbound$Internal(entry.getKey(), entry.getValue());
            } else {
                this.registerServerbound$Internal(entry.getKey());
            }
        }

        this.clientboundMessages.clear();
        this.serverboundMessages.clear();
    }

    @Override
    public boolean isFrozen() {
        return this.isFrozen;
    }

    protected BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally(Class<?> clazz) {
        return (Throwable throwable, Consumer<class_2561> consumer) -> {
            String modName = ModContainer.getDisplayName(this.channelName.method_12836());
            consumer.accept(class_2561.method_43470("Receiving %s from %s failed: %s".formatted(clazz.getSimpleName(),
                    modName,
                    throwable.getMessage())));
        };
    }

    protected Consumer<Consumer<class_2561>> disconnectWrongSide(Class<?> clazz) {
        return (Consumer<class_2561> consumer) -> {
            String modName = ModContainer.getDisplayName(this.channelName.method_12836());
            consumer.accept(class_2561.method_43470("Receiving %s from %s on wrong side!".formatted(clazz.getSimpleName(),
                    modName)));
        };
    }

    @SuppressWarnings("unchecked")
    protected <T> class_8710.class_9154<CustomPacketPayloadAdapter<T>> registerMessageType(Class<T> clazz) {
        class_2960 resourceLocation = this.channelName.method_45134((String path) -> path + "/"
                + this.discriminator.getAndIncrement());
        class_8710.class_9154<CustomPacketPayloadAdapter<T>> type = new class_8710.class_9154<>(resourceLocation);
        this.messageTypes.put(clazz,
                (class_8710.class_9154<CustomPacketPayloadAdapter<?>>) (class_8710.class_9154<?>) type);
        return type;
    }

    protected <T1 extends MessageV3<T2, ?>, T2, L extends class_2547> class_2596<L> toPacket(Function<class_8710, class_2596<L>> packetFactory, T1 message) {
        class_8710.class_9154<CustomPacketPayloadAdapter<T2>> type = this.getMessageType(message);
        return packetFactory.apply(new CustomPacketPayloadAdapterImpl<>(type, message.unwrap()));
    }

    @SuppressWarnings("unchecked")
    protected <T1 extends MessageV3<T2, ?>, T2> class_8710.class_9154<CustomPacketPayloadAdapter<T2>> getMessageType(T1 message) {
        Class<T2> clazz = (Class<T2>) message.unwrap().getClass();
        class_8710.class_9154<CustomPacketPayloadAdapter<T2>> type = (class_8710.class_9154<CustomPacketPayloadAdapter<T2>>) (class_8710.class_9154<?>) this.messageTypes.get(
                clazz);
        Objects.requireNonNull(type, "Unknown message of type: " + clazz);
        return type;
    }

    protected abstract <T extends Record & ClientboundMessage<T>> void registerClientbound$Internal(Class<?> clazz);

    protected abstract <T extends Record & ServerboundMessage<T>> void registerServerbound$Internal(Class<?> clazz);

    protected abstract <T extends MessageV2<T>> void registerLegacyClientbound$Internal(Class<?> clazz, class_9141<class_2540, ?> factory);

    protected abstract <T extends MessageV2<T>> void registerLegacyServerbound$Internal(Class<?> clazz, class_9141<class_2540, ?> factory);
}
