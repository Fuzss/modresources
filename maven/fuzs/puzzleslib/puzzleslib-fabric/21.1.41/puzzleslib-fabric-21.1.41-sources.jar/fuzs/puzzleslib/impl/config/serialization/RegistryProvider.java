package fuzs.puzzleslib.impl.config.serialization;

import fuzs.puzzleslib.api.config.v3.serialization.KeyedValueProvider;
import fuzs.puzzleslib.api.init.v3.registry.RegistryHelper;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

public record RegistryProvider<T>(class_2378<T> registry) implements KeyedValueProvider<T> {

    public RegistryProvider(class_5321<? extends class_2378<? super T>> registryKey) {
        this(RegistryHelper.findBuiltInRegistry(registryKey));
    }

    @Override
    public Optional<T> getValue(class_2960 name) {
        return this.registry.method_17966(name);
    }

    @Override
    public class_2960 getKey(T value) {
        return this.registry.method_10221(value);
    }

    @Override
    public Stream<Map.Entry<class_2960, T>> stream() {
        return this.registry.method_29722().stream().map(entry -> Map.entry(entry.getKey().method_29177(), entry.getValue()));
    }

    @Override
    public Stream<T> streamValues() {
        return this.registry.method_10220();
    }

    @Override
    public String name() {
        return this.registry.method_30517().method_29177().toString();
    }
}
