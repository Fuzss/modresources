package fuzs.puzzleslib.impl.init;

import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7876;

/**
 * A {@link class_6880} implementation similar to DeferredHolder on NeoForge, but extending
 * {@link net.minecraft.class_6880.class_6883} to allow for using {@link class_6883#method_40237()}.
 * <p>
 * Also supports lazy initialization on Fabric &amp; Forge.
 */
public final class LazyHolder<T> extends class_6880.class_6883<T> {
    @Nullable
    private Supplier<class_6880<T>> supplier;
    private class_6880<T> holder;

    public LazyHolder(class_5321<? extends class_2378<? super T>> registryKey, class_6880<T> holder) {
        this(registryKey, holder.method_40230().orElseThrow(), () -> holder);
    }

    public LazyHolder(class_5321<? extends class_2378<? super T>> registryKey, class_5321<T> key, Supplier<class_6880<T>> supplier) {
        super(class_6880.class_6883.class_6884.field_36454, new class_7876<>() {
            @Override
            public String toString() {
                return registryKey.toString();
            }
        }, key, null);
        Objects.requireNonNull(registryKey, "registry key is null");
        Objects.requireNonNull(key, "key is null");
        Objects.requireNonNull(supplier, "supplier is null");
        this.supplier = supplier;
    }

    private void bindHolder(boolean failIfNull) {
        if (this.supplier != null) {
            class_6880<T> holder = this.supplier.get();
            if (holder != null) {
                this.holder = holder;
                super.method_45918(this.holder.comp_349());
                this.supplier = null;
            } else if (failIfNull) {
                throw new NullPointerException("holder is null");
            }
        }
    }

    @Override
    public void method_45918(T value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void method_40235(Collection<class_6862<T>> tags) {
        throw new UnsupportedOperationException();
    }

    @Override
    public T comp_349() {
        this.bindHolder(true);
        return super.comp_349();
    }

    @Override
    public boolean method_40227() {
        this.bindHolder(false);
        return super.method_40227();
    }

    @Override
    public boolean method_40220(class_6862<T> tagKey) {
        this.bindHolder(true);
        return this.holder.method_40220(tagKey);
    }

    @Override
    public Stream<class_6862<T>> method_40228() {
        this.bindHolder(true);
        return this.holder.method_40228();
    }

    @Override
    public boolean method_46745(class_7876<T> owner) {
        this.bindHolder(true);
        return this.holder.method_46745(owner);
    }

    @Override
    public String toString() {
        return "Reference{" + this.method_40237() + (this.supplier == null ? "=" + this.comp_349() : "") + "}";
    }
}
