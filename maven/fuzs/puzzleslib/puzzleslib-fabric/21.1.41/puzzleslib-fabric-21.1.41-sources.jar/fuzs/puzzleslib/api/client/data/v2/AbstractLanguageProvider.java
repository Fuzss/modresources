package fuzs.puzzleslib.api.client.data.v2;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonObject;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1535;
import net.minecraft.class_156;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1826;
import net.minecraft.class_1842;
import net.minecraft.class_1887;
import net.minecraft.class_1928;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2405;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3414;
import net.minecraft.class_3448;
import net.minecraft.class_5321;
import net.minecraft.class_5794;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

public abstract class AbstractLanguageProvider implements class_2405 {
    protected final String languageCode;
    protected final String modId;
    protected final class_7784.class_7489 pathProvider;

    public AbstractLanguageProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput());
    }

    public AbstractLanguageProvider(String languageCode, DataProviderContext context) {
        this(languageCode, context.getModId(), context.getPackOutput());
    }

    public AbstractLanguageProvider(String modId, class_7784 packOutput) {
        this("en_us", modId, packOutput);
    }

    public AbstractLanguageProvider(String languageCode, String modId, class_7784 packOutput) {
        this.languageCode = languageCode;
        this.modId = modId;
        this.pathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "lang");
    }

    public abstract void addTranslations(TranslationBuilder translationBuilder);

    @Override
    public CompletableFuture<?> method_10319(class_7403 cachedOutput) {
        JsonObject jsonObject = new JsonObject();
        this.addTranslations((String translationKey, String value) -> {
            Objects.requireNonNull(translationKey, "translation key is null");
            Objects.requireNonNull(value, "value is null");
            if (jsonObject.has(translationKey)) {
                throw new IllegalStateException("Created duplicate translation key: " + translationKey);
            } else {
                jsonObject.addProperty(translationKey, value);
            }
        });

        this.verifyRequiredTranslationKeys(jsonObject::has, class_7923.field_41175, TranslationBuilder::addBlock);
        this.verifyRequiredTranslationKeys(jsonObject::has, class_7923.field_41178, TranslationBuilder::addItem);
        this.verifyRequiredTranslationKeys(jsonObject::has,
                class_7923.field_41177,
                TranslationBuilder::addEntityType);
        this.verifyRequiredTranslationKeys(jsonObject::has,
                class_7923.field_41190,
                TranslationBuilder::addAttribute);
        this.verifyRequiredTranslationKeys(jsonObject::has,
                class_7923.field_41174,
                TranslationBuilder::addMobEffect);

        class_2960 resourceLocation = class_2960.method_60655(this.modId, this.languageCode);
        return class_2405.method_10320(cachedOutput, jsonObject, this.pathProvider.method_44107(resourceLocation));
    }

    private <T> void verifyRequiredTranslationKeys(Predicate<String> predicate, class_2378<T> registry, HolderTranslationCollector<T> holderTranslationCollector) {
        registry.method_40270()
                .filter((class_6880.class_6883<T> holder) -> holder.method_40237().method_29177().method_12836().equals(this.modId))
                .forEach((class_6880.class_6883<T> holder) -> {
                    holderTranslationCollector.accept((String translationKey, String value) -> {
                        Objects.requireNonNull(translationKey, "translation key is null");
                        if (this.mustHaveTranslationKey(holder, translationKey) && !predicate.test(translationKey)) {
                            throw new IllegalStateException("Missing translation key '%s' for '%s'".formatted(
                                    translationKey,
                                    holder));
                        }
                    }, holder, "");
                });
    }

    protected boolean mustHaveTranslationKey(class_6880.class_6883<?> holder, String translationKey) {
        return true;
    }

    @Override
    public String method_10321() {
        return "Language (%s)".formatted(this.languageCode);
    }

    @ApiStatus.NonExtendable
    @FunctionalInterface
    public interface TranslationBuilder {

        void add(String translationKey, String value);

        default void add(String translationKey, String additionalKey, String value) {
            Objects.requireNonNull(additionalKey, "additional key is null");
            this.add(translationKey + (additionalKey.isEmpty() ? "" : "." + additionalKey), value);
        }

        default void add(class_2960 resourceLocation, String value) {
            this.add(resourceLocation, "", value);
        }

        default void add(class_2960 resourceLocation, String additionalKey, String value) {
            Objects.requireNonNull(resourceLocation, "resource location is null");
            this.add(resourceLocation.method_42094(), additionalKey, value);
        }

        default void add(class_2561 component) {
            Objects.requireNonNull(component, "component is null");
            if (component.method_10851() instanceof class_2588 contents && contents.method_48323() != null) {
                this.add(contents.method_11022(), contents.method_48323());
            } else {
                throw new IllegalArgumentException("Unsupported component: " + component);
            }
        }

        default void add(class_2561 component, String value) {
            Objects.requireNonNull(component, "component is null");
            if (component.method_10851() instanceof class_2588 contents) {
                this.add(contents.method_11022(), value);
            } else {
                throw new IllegalArgumentException("Unsupported component: " + component);
            }
        }

        default void add(class_6880<?> holder, String value) {
            this.add(holder, "", value);
        }

        default void add(class_6880<?> holder, String additionalKey, String value) {
            Objects.requireNonNull(holder, "holder is null");
            this.add(holder.method_40230().orElseThrow(), additionalKey, value);
        }

        default void add(class_5321<?> resourceKey, String value) {
            this.add(resourceKey, "", value);
        }

        default void add(class_5321<?> resourceKey, String additionalKey, String value) {
            Objects.requireNonNull(resourceKey, "resource key is null");
            String registry = class_7924.method_60915(resourceKey.method_58273());
            this.add(registry, resourceKey.method_29177(), additionalKey, value);
        }

        default void add(String registry, class_2960 resourceLocation, String value) {
            this.add(registry, resourceLocation, "", value);
        }

        default void add(String registry, class_2960 resourceLocation, String additionalKey, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(resourceLocation, "resource location is null");
            this.add(resourceLocation.method_42093(registry), additionalKey, value);
        }

        default void add(class_6862<?> tagKey, String value) {
            Objects.requireNonNull(tagKey, "tag key is null");
            String registry = class_7924.method_60915(tagKey.comp_326());
            this.add("tag." + tagKey.comp_327().method_42093(registry), value);
        }

        default BlockFamilyBuilder blockFamily(String blockValue) {
            return new BlockFamilyBuilder(this::add, blockValue);
        }

        default BlockFamilyBuilder blockFamily(String blockValue, String baseBlockValue) {
            return new BlockFamilyBuilder(this::add, blockValue, baseBlockValue);
        }

        @Deprecated
        default void add(String registry, class_6880<?> holder, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(holder, "holder is null");
            this.add(registry, holder.method_40230().orElseThrow(), value);
        }

        @Deprecated
        default void add(String registry, class_5321<?> resourceKey, String value) {
            Objects.requireNonNull(registry, "registry is null");
            Objects.requireNonNull(resourceKey, "resource key is null");
            this.add(registry, resourceKey.method_29177(), value);
        }

        default void addBlock(class_6880<class_2248> block, String value) {
            Objects.requireNonNull(block, "block is null");
            this.add(block.comp_349(), value);
        }

        default void add(class_2248 block, String value) {
            this.add(block, "", value);
        }

        default void add(class_2248 block, String additionalKey, String value) {
            Objects.requireNonNull(block, "block is null");
            this.add(block.method_9539(), additionalKey, value);
        }

        default void addItem(class_6880<class_1792> item, String value) {
            Objects.requireNonNull(item, "item is null");
            this.add(item.comp_349(), value);
        }

        default void add(class_1792 item, String value) {
            this.add(item, "", value);
        }

        default void add(class_1792 item, String additionalKey, String value) {
            Objects.requireNonNull(item, "item is null");
            this.add(item.method_7876(), additionalKey, value);
        }

        default void addSpawnEgg(class_1792 item, String value) {
            Objects.requireNonNull(item, "item is null");
            if (item instanceof class_1826) {
                this.add(item, value + " Spawn Egg");
            } else {
                throw new IllegalArgumentException("Unsupported item: " + item);
            }
        }

        @Deprecated
        default void addEnchantment(class_5321<class_1887> enchantment, String value) {
            this.addEnchantment(enchantment, "", value);
        }

        @Deprecated
        default void addEnchantment(class_5321<class_1887> enchantment, String additionalKey, String value) {
            Objects.requireNonNull(enchantment, "enchantment is null");
            String translationKey = class_156.method_646(enchantment.method_41185().method_12832(), enchantment.method_29177());
            this.add(translationKey, additionalKey, value);
        }

        default void addMobEffect(class_6880<class_1291> mobEffect, String value) {
            Objects.requireNonNull(mobEffect, "mob effect is null");
            this.add(mobEffect.comp_349(), value);
        }

        default void add(class_1291 mobEffect, String value) {
            this.add(mobEffect, "", value);
        }

        default void add(class_1291 mobEffect, String additionalKey, String value) {
            Objects.requireNonNull(mobEffect, "mob effect is null");
            this.add(mobEffect.method_5567(), additionalKey, value);
        }

        default void addEntityType(class_6880<? extends class_1299<?>> entityType, String value) {
            Objects.requireNonNull(entityType, "entity type is null");
            this.add(entityType.comp_349(), value);
        }

        default void add(class_1299<?> entityType, String value) {
            this.add(entityType, "", value);
        }

        default void add(class_1299<?> entityType, String additionalKey, String value) {
            Objects.requireNonNull(entityType, "entity type is null");
            this.add(entityType.method_5882(), additionalKey, value);
        }

        default void addAttribute(class_6880<class_1320> attribute, String value) {
            Objects.requireNonNull(attribute, "attribute is null");
            this.add(attribute.comp_349(), value);
        }

        default void add(class_1320 attribute, String value) {
            this.add(attribute, "", value);
        }

        default void add(class_1320 attribute, String additionalKey, String value) {
            Objects.requireNonNull(attribute, "attribute is null");
            this.add(attribute.method_26830(), additionalKey, value);
        }

        default void addStatType(class_6880<class_3448<?>> statType, String value) {
            Objects.requireNonNull(statType, "stat type is null");
            this.add(statType.comp_349(), value);
        }

        default void add(class_3448<?> statType, String value) {
            this.add(statType, "", value);
        }

        default void add(class_3448<?> statType, String additionalKey, String value) {
            Objects.requireNonNull(statType, "stat type is null");
            Objects.requireNonNull(statType.method_30739(), "component is null");
            if (statType.method_30739().method_10851() instanceof class_2588 contents) {
                this.add(contents.method_11022(), additionalKey, value);
            } else {
                throw new IllegalArgumentException("Unsupported component: " + statType.method_30739());
            }
        }

        default void addPotion(class_6880<class_1842> potion, String value) {
            Objects.requireNonNull(potion, "potion is null");
            Function<class_1792, String> potionNameGetter = (class_1792 item) -> {
                return class_1842.method_8051(Optional.of(potion), item.method_7876() + ".effect.");
            };
            this.add(potionNameGetter.apply(class_1802.field_8087), "Arrow of " + value);
            this.add(potionNameGetter.apply(class_1802.field_8574), "Potion of " + value);
            this.add(potionNameGetter.apply(class_1802.field_8436), "Splash Potion of " + value);
            this.add(potionNameGetter.apply(class_1802.field_8150), "Lingering Potion of " + value);
        }

        default void addSoundEvent(class_6880<class_3414> soundEvent, String value) {
            Objects.requireNonNull(soundEvent, "sound event is null");
            this.add(soundEvent.comp_349(), value);
        }

        default void add(class_3414 soundEvent, String value) {
            Objects.requireNonNull(soundEvent, "sound event is null");
            this.add("subtitles." + soundEvent.method_14833().method_12832(), value);
        }

        default void addCreativeModeTab(class_6880<class_1761> creativeModeTab, String value) {
            Objects.requireNonNull(creativeModeTab, "creative mode tab is null");
            this.add(creativeModeTab.comp_349(), value);
        }

        default void add(class_1761 creativeModeTab, String value) {
            Objects.requireNonNull(creativeModeTab, "creative mode tab is null");
            this.add(creativeModeTab.method_7737(), value);
        }

        @Deprecated
        default void addCreativeModeTab(String modId, String value) {
            this.addCreativeModeTab(modId, "main", value);
        }

        @Deprecated
        default void addCreativeModeTab(String modId, String tabId, String value) {
            Objects.requireNonNull(modId, "mod id is null");
            Objects.requireNonNull(tabId, "tab id is null");
            this.addCreativeModeTab(ResourceLocationHelper.fromNamespaceAndPath(modId, tabId), value);
        }

        @Deprecated
        default void addCreativeModeTab(class_2960 resourceLocation, String value) {
            Objects.requireNonNull(resourceLocation, "resource location is null");
            this.addCreativeModeTab(class_5321.method_29179(class_7924.field_44688, resourceLocation), value);
        }

        @Deprecated
        default void addCreativeModeTab(class_5321<class_1761> resourceKey, String value) {
            Objects.requireNonNull(resourceKey, "resource key is null");
            this.add(class_7923.field_44687.method_29107(resourceKey), value);
        }

        default void addBiome(class_5321<class_1959> biome, String value) {
            Objects.requireNonNull(biome, "biome is null");
            this.add(biome.method_29177().method_42093("biome"), value);
        }

        default void addGenericDamageType(class_5321<class_8110> damageType, String value) {
            Objects.requireNonNull(damageType, "damage type is null");
            this.add("death.attack." + damageType.method_29177().method_12832(), value);
        }

        default void addPlayerDamageType(class_5321<class_8110> damageType, String value) {
            Objects.requireNonNull(damageType, "damage type is null");
            this.add("death.attack." + damageType.method_29177().method_12832() + ".player", value);
        }

        default void addItemDamageType(class_5321<class_8110> damageType, String value) {
            Objects.requireNonNull(damageType, "damage type is null");
            this.add("death.attack." + damageType.method_29177().method_12832() + ".item", value);
        }

        default void addPaintingVariant(class_5321<class_1535> paintingVariant, String title, String author) {
            Objects.requireNonNull(paintingVariant, "painting variant is null");
            // do not use the registry name, it is "painting_variant", not "painting"
            this.add(paintingVariant.method_29177().method_48747("painting", "title"), title);
            this.add(paintingVariant.method_29177().method_48747("painting", "author"), author);
        }

        default void add(class_304 keyMapping, String value) {
            Objects.requireNonNull(keyMapping, "key mapping is null");
            this.add(keyMapping.method_1431(), value);
        }

        default void addKeyCategory(String modId, String value) {
            this.add("key.categories." + modId, value);
        }

        default void add(class_1928.class_4313<?> gameRule, String value) {
            this.add(gameRule, "", value);
        }

        default void addGameRuleDescription(class_1928.class_4313<?> gameRule, String value) {
            this.add(gameRule, "description", value);
        }

        default void add(class_1928.class_4313<?> gameRule, String additionalKey, String value) {
            Objects.requireNonNull(gameRule, "game rule is null");
            this.add(gameRule.method_27334(), additionalKey, value);
        }
    }

    public static class BlockFamilyBuilder {
        static final Map<class_5794.class_5796, BiFunction<BlockFamilyBuilder, class_2248, BlockFamilyBuilder>> VARIANT_FUNCTIONS = ImmutableMap.<class_5794.class_5796, BiFunction<BlockFamilyBuilder, class_2248, BlockFamilyBuilder>>builder()
                .put(class_5794.class_5796.field_28533, BlockFamilyBuilder::button)
                .put(class_5794.class_5796.field_28534, BlockFamilyBuilder::chiseled)
                .put(class_5794.class_5796.field_29503, BlockFamilyBuilder::cracked)
                .put(class_5794.class_5796.field_33689, BlockFamilyBuilder::cut)
                .put(class_5794.class_5796.field_28535, BlockFamilyBuilder::door)
                .put(class_5794.class_5796.field_40592, BlockFamilyBuilder::fence)
                .put(class_5794.class_5796.field_28536, BlockFamilyBuilder::fence)
                .put(class_5794.class_5796.field_40593, BlockFamilyBuilder::fenceGate)
                .put(class_5794.class_5796.field_28537, BlockFamilyBuilder::fenceGate)
                .put(class_5794.class_5796.field_40594, BlockFamilyBuilder::mosaic)
                .put(class_5794.class_5796.field_28538, BlockFamilyBuilder::sign)
                .put(class_5794.class_5796.field_28539, BlockFamilyBuilder::slab)
                .put(class_5794.class_5796.field_28540, BlockFamilyBuilder::stairs)
                .put(class_5794.class_5796.field_28541, BlockFamilyBuilder::pressurePlate)
                .put(class_5794.class_5796.field_28542, BlockFamilyBuilder::polished)
                .put(class_5794.class_5796.field_28543, BlockFamilyBuilder::trapdoor)
                .put(class_5794.class_5796.field_28544, BlockFamilyBuilder::wall)
                .build();
        private final BiConsumer<class_2248, String> valueConsumer;
        private final String blockValue;
        private final String baseBlockValue;

        private BlockFamilyBuilder(BiConsumer<class_2248, String> valueConsumer, String blockValue) {
            this(valueConsumer, blockValue, blockValue);
        }

        private BlockFamilyBuilder(BiConsumer<class_2248, String> valueConsumer, String blockValue, String baseBlockValue) {
            this.valueConsumer = valueConsumer;
            this.blockValue = blockValue;
            this.baseBlockValue = baseBlockValue;
        }

        public void generateFor(class_5794 blockFamily) {
            this.baseBlock(blockFamily.method_33469());
            blockFamily.method_33474().forEach((class_5794.class_5796 variant, class_2248 block) -> {
                BiFunction<BlockFamilyBuilder, class_2248, BlockFamilyBuilder> variantFunction = VARIANT_FUNCTIONS.get(
                        variant);
                if (variantFunction != null) {
                    variantFunction.apply(this, block);
                }
            });
        }

        public BlockFamilyBuilder baseBlock(class_2248 block) {
            this.valueConsumer.accept(block, this.baseBlockValue);
            return this;
        }

        public BlockFamilyBuilder button(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Button");
            return this;
        }

        public BlockFamilyBuilder chiseled(class_2248 block) {
            this.valueConsumer.accept(block, "Chiseled " + this.blockValue);
            return this;
        }

        public BlockFamilyBuilder cracked(class_2248 block) {
            this.valueConsumer.accept(block, "Cracked " + this.blockValue);
            return this;
        }

        public BlockFamilyBuilder cut(class_2248 block) {
            this.valueConsumer.accept(block, "Cut " + this.blockValue);
            return this;
        }

        public BlockFamilyBuilder door(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Door");
            return this;
        }

        public BlockFamilyBuilder fence(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Fence");
            return this;
        }

        public BlockFamilyBuilder fenceGate(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Fence Gate");
            return this;
        }

        public BlockFamilyBuilder mosaic(class_2248 block) {
            this.valueConsumer.accept(block, "Mosaic " + this.blockValue);
            return this;
        }

        public BlockFamilyBuilder sign(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Sign");
            return this;
        }

        public BlockFamilyBuilder slab(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Slab");
            return this;
        }

        public BlockFamilyBuilder hangingSign(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Hanging Sign");
            return this;
        }

        public BlockFamilyBuilder stairs(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Stairs");
            return this;
        }

        public BlockFamilyBuilder pressurePlate(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Pressure Plate");
            return this;
        }

        public BlockFamilyBuilder polished(class_2248 block) {
            this.valueConsumer.accept(block, "Polished " + this.blockValue);
            return this;
        }

        public BlockFamilyBuilder trapdoor(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Trapdoor");
            return this;
        }

        public BlockFamilyBuilder wall(class_2248 block) {
            this.valueConsumer.accept(block, this.blockValue + " Wall");
            return this;
        }
    }

    @FunctionalInterface
    protected interface HolderTranslationCollector<T> {

        void accept(TranslationBuilder translationBuilder, class_6880<T> holder, String value);
    }
}
