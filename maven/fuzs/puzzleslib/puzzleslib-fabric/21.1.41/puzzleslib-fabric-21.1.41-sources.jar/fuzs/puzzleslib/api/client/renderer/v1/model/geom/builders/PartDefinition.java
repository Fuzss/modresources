package fuzs.puzzleslib.api.client.renderer.v1.model.geom.builders;

import fuzs.puzzleslib.api.client.renderer.v1.model.geom.ModelPart;
import fuzs.puzzleslib.api.client.renderer.v1.model.geom.PartPose;
import it.unimi.dsi.fastutil.objects.Object2ObjectArrayMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import net.minecraft.class_5604;
import net.minecraft.class_5606;

/**
 * Copied from Minecraft 1.21.10.
 */
public class PartDefinition extends net.minecraft.class_5610 {

    public PartDefinition(List<class_5604> cubes, PartPose partPose) {
        super(cubes, partPose);
    }

    public PartDefinition(net.minecraft.class_5610 partDefinition) {
        super(partDefinition.field_27728, partDefinition.field_27729);
        this.field_27730.putAll(partDefinition.field_27730);
    }

    @Override
    public PartDefinition method_32117(String name, class_5606 cubes, net.minecraft.class_5603 partPose) {
        PartDefinition partDefinition = new PartDefinition(cubes.method_32107(),
                partPose instanceof PartPose ? (PartPose) partPose : new PartPose(partPose));
        return this.addOrReplaceChild(name, partDefinition);
    }

    public PartDefinition addOrReplaceChild(String name, PartDefinition child) {
        PartDefinition partDefinition = (PartDefinition) this.field_27730.put(name, child);
        if (partDefinition != null) {
            child.field_27730.putAll(partDefinition.field_27730);
        }

        return child;
    }

    public PartDefinition clearRecursively() {
        for (String string : this.field_27730.keySet()) {
            this.clearChild(string).clearRecursively();
        }

        return this;
    }

    public PartDefinition clearChild(String name) {
        PartDefinition partDefinition = (PartDefinition) this.field_27730.get(name);
        if (partDefinition == null) {
            throw new IllegalArgumentException("No child with name: " + name);
        } else {
            return this.method_32117(name, class_5606.method_32108(), partDefinition.field_27729);
        }
    }

    public void retainPartsAndChildren(Set<String> parts) {
        for (Entry<String, net.minecraft.class_5610> entry : this.field_27730.entrySet()) {
            PartDefinition partDefinition = (PartDefinition) entry.getValue();
            if (!parts.contains(entry.getKey())) {
                this.method_32117(entry.getKey(), class_5606.method_32108(), partDefinition.field_27729)
                        .retainPartsAndChildren(parts);
            }
        }
    }

    public void retainExactParts(Set<String> parts) {
        for (Entry<String, net.minecraft.class_5610> entry : this.field_27730.entrySet()) {
            PartDefinition partDefinition = (PartDefinition) entry.getValue();
            if (parts.contains(entry.getKey())) {
                partDefinition.clearRecursively();
            } else {
                this.method_32117(entry.getKey(), class_5606.method_32108(), partDefinition.field_27729)
                        .retainExactParts(parts);
            }
        }
    }

    @Override
    public ModelPart method_32112(int texWidth, int texHeight) {
        Object2ObjectArrayMap<String, ModelPart> object2ObjectArrayMap = this.getChildren()
                .stream()
                .collect(
                        Collectors.toMap(
                                Entry::getKey,
                                (Entry<String, PartDefinition> entry) -> {
                                    return entry.getValue().method_32112(texWidth, texHeight);
                                },
                                (ModelPart oldModelPart, ModelPart modelPartx) -> {
                                    return oldModelPart;
                                },
                                Object2ObjectArrayMap::new
                        )
                );
        List<ModelPart.Cube> list = this.field_27728.stream().map((class_5604 cube) -> {
            return cube.method_32093(texWidth, texHeight);
        }).toList();
        ModelPart modelPart = new ModelPart(list, object2ObjectArrayMap);
        modelPart.method_41918(this.field_27729);
        modelPart.method_32085(this.field_27729);
        return modelPart;
    }

    @Override
    public PartDefinition method_32116(String name) {
        return (PartDefinition) this.field_27730.get(name);
    }

    public Set<Entry<String, PartDefinition>> getChildren() {
        return (Set<Entry<String, PartDefinition>>) (Set<?>) this.field_27730.entrySet();
    }

    public PartDefinition transformed(UnaryOperator<PartPose> transformer) {
        PartDefinition partDefinition = new PartDefinition(this.field_27728, transformer.apply((PartPose) this.field_27729));
        partDefinition.field_27730.putAll(this.field_27730);
        return partDefinition;
    }
}
