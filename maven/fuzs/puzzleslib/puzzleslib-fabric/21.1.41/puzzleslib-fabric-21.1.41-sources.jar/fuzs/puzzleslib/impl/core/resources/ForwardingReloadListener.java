package fuzs.puzzleslib.impl.core.resources;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.core.v1.resources.NamedReloadListener;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;

public class ForwardingReloadListener<T extends class_3302> implements NamedReloadListener {
    private final class_2960 identifier;
    private final Supplier<Collection<T>> supplier;
    @Nullable
    private Collection<T> reloadListeners;


    public ForwardingReloadListener(class_2960 identifier, Supplier<Collection<T>> supplier) {
        Objects.requireNonNull(identifier, "identifier is null");
        Objects.requireNonNull(supplier, "supplier is null");
        this.identifier = identifier;
        this.supplier = supplier;
    }

    @Override
    public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
        return CompletableFuture.completedFuture(null).thenCompose($ -> {
            return CompletableFuture.allOf(this.reloadListeners().stream().map(reloadListener -> {
                try {
                    return reloadListener.method_25931(preparationBarrier,
                            resourceManager,
                            preparationsProfiler,
                            reloadProfiler,
                            backgroundExecutor,
                            gameExecutor
                    );
                } catch (Exception exception) {
                    PuzzlesLib.LOGGER.error("Unable to reload listener {}", reloadListener.method_22322(), exception);
                }
                return CompletableFuture.completedFuture(null).thenCompose(preparationBarrier::method_18352);
            }).toArray(CompletableFuture[]::new));
        });
    }

    @Override
    public final String toString() {
        return this.method_22322();
    }

    @Override
    public class_2960 identifier() {
        return this.identifier;
    }

    synchronized final Collection<T> reloadListeners() {
        if (this.reloadListeners == null) {
            Collection<T> collection = this.supplier.get();
            Objects.requireNonNull(collection, "collection is null");
            if (collection.isEmpty()) {
                PuzzlesLib.LOGGER.error("{} is empty", this.identifier);
                // don't throw for now, seems to happen occasionally, want to test if maybe a second reload is triggered allowing this to still work
                return collection;
            } else {
                return this.reloadListeners = ImmutableList.copyOf(collection);
            }
        } else {
            return this.reloadListeners;
        }
    }
}
