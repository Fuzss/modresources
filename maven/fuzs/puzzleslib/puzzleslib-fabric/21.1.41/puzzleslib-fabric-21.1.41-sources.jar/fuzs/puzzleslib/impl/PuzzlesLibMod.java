package fuzs.puzzleslib.impl;

import fuzs.puzzleslib.api.core.v1.ModConstructor;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.init.v3.override.CommandOverrides;
import fuzs.puzzleslib.api.init.v3.override.GameRuleValueOverrides;
import fuzs.puzzleslib.api.network.v3.NetworkHandler;
import fuzs.puzzleslib.impl.capability.ClientboundEntityCapabilityMessage;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1294;
import net.minecraft.class_1928;
import net.minecraft.class_2960;

/**
 * This has been separated from {@link PuzzlesLib} to prevent issues with static initialization when accessing constants
 * in {@link PuzzlesLib} early.
 */
public class PuzzlesLibMod extends PuzzlesLib implements ModConstructor {
    public static final NetworkHandler NETWORK = NetworkHandler.builder(MOD_ID)
            .optional()
            .registerClientbound(ClientboundEntityCapabilityMessage.class);

    @Override
    public void onConstructMod() {
        ProxyImpl.get().registerEventHandlers();
        setupDevelopmentEnvironment();
    }

    private static void setupDevelopmentEnvironment() {
        if (!ModLoaderEnvironment.INSTANCE.isDevelopmentEnvironmentWithoutDataGeneration(PuzzlesLib.MOD_ID)) return;
        CommandOverrides.registerHandlers();
        initializeGameRules();
        initializeCommands();
    }

    private static void initializeCommands() {
        CommandOverrides.registerServerCommand("time set 4000", false);
        CommandOverrides.registerPlayerCommand("op @s", true);
        CommandOverrides.registerEffectCommand(class_1294.field_5925);
        CommandOverrides.registerEffectCommand(class_1294.field_5907);
        CommandOverrides.registerEffectCommand(class_1294.field_5918);
        CommandOverrides.registerEffectCommand(class_1294.field_5910);
        CommandOverrides.registerEffectCommand(class_1294.field_5923);
    }

    private static void initializeGameRules() {
        GameRuleValueOverrides.setValue(class_1928.field_19396, false);
        GameRuleValueOverrides.setValue(class_1928.field_19406, false);
        GameRuleValueOverrides.setValue(class_1928.field_19389, true);
        GameRuleValueOverrides.setValue(class_1928.field_19387, false);
        GameRuleValueOverrides.setValue(class_1928.field_19388, false);
        GameRuleValueOverrides.setValue(class_1928.field_20637, false);
        GameRuleValueOverrides.setValue(class_1928.field_21831, false);
        GameRuleValueOverrides.setValue(class_1928.field_21832, false);
        GameRuleValueOverrides.setValue(class_1928.field_42474, false);
        GameRuleValueOverrides.setValue(class_1928.field_19405, 0);
        GameRuleValueOverrides.setValue(class_1928.field_46794, 1);
        GameRuleValueOverrides.setValue(class_1928.field_19394, false);
    }

    public static class_2960 id(String path) {
        return ResourceLocationHelper.fromNamespaceAndPath(MOD_ID, path);
    }
}
