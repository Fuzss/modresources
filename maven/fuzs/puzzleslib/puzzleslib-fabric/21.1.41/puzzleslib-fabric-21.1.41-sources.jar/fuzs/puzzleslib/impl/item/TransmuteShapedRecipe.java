package fuzs.puzzleslib.impl.item;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_9694;

public final class TransmuteShapedRecipe extends class_1869 implements CustomTransmuteRecipe {
    private final class_1865<?> recipeSerializer;
    private final class_1856 input;

    public TransmuteShapedRecipe(String modId, class_1869 shapedRecipe, class_1856 input) {
        this(CustomTransmuteRecipe.getModSerializer(modId, CustomTransmuteRecipe.TRANSMUTE_SHAPED_RECIPE_SERIALIZER_ID),
                shapedRecipe,
                input);
    }

    public TransmuteShapedRecipe(class_1865<?> recipeSerializer, class_1869 shapedRecipe, class_1856 input) {
        super(shapedRecipe.method_8112(),
                shapedRecipe.method_45441(),
                shapedRecipe.field_47320,
                shapedRecipe.method_8110(class_5455.field_40585),
                shapedRecipe.method_49188());
        this.recipeSerializer = recipeSerializer;
        this.input = input;
    }

    @Override
    public class_1799 method_17727(class_9694 craftingInput, class_7225.class_7874 registries) {
        class_1799 itemStack = super.method_17727(craftingInput, registries);
        CustomTransmuteRecipe.super.transmuteInput(itemStack, craftingInput);
        return itemStack;
    }

    @Override
    public class_1865<? extends class_1869> method_8119() {
        return (class_1865<? extends class_1869>) this.recipeSerializer;
    }

    @Override
    public class_1856 getInput() {
        return this.input;
    }
}
