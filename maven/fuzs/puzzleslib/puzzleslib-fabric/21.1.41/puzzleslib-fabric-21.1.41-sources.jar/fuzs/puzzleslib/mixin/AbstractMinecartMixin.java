package fuzs.puzzleslib.mixin;

import fuzs.puzzleslib.impl.init.MinecartTypeRegistryImpl;
import net.minecraft.class_1299;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3218;
import net.minecraft.class_8836;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1688.class)
abstract class AbstractMinecartMixin extends class_8836 {

    public AbstractMinecartMixin(class_1299<?> entityType, class_1937 level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "createMinecart", at = @At("STORE"))
    private static class_1688 createMinecart(class_1688 abstractMinecart, class_3218 level, double x, double y, double z, class_1688.class_1689 type, class_1799 stack, @Nullable class_1657 player) {
        return MinecartTypeRegistryImpl.createMinecartForType(type, level, x, y, z).orElse(abstractMinecart);
    }
}
