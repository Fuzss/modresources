package fuzs.puzzleslib.impl.event;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.api.event.v1.data.DefaultedDouble;
import fuzs.puzzleslib.api.event.v1.entity.living.LivingJumpCallback;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_3803;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.OptionalDouble;

public final class EventImplHelper {

    private EventImplHelper() {
        // NO-OP
    }

    public static void onLivingJump(LivingJumpCallback callback, class_1309 entity) {
        class_243 deltaMovement = entity.method_18798();
        DefaultedDouble jumpPower = DefaultedDouble.fromValue(deltaMovement.field_1351);
        OptionalDouble newJumpPower;
        if (callback.onLivingJump(entity, jumpPower).isInterrupt()) {
            newJumpPower = OptionalDouble.of(0.0);
        } else {
            newJumpPower = jumpPower.getAsOptionalDouble();
        }
        if (newJumpPower.isPresent()) {
            entity.method_18800(deltaMovement.field_1352, newJumpPower.getAsDouble(), deltaMovement.field_1350);
        }
    }

    @Nullable
    public static class_1657 getPlayerFromContainerMenu(class_1703 abstractContainerMenu) {
        for (class_1735 slot : abstractContainerMenu.field_7761) {
            if (slot.field_7871 instanceof class_1661 inventory) {
                return inventory.field_7546;
            }
        }

        MinecraftServer minecraftServer = ProxyImpl.get().getMinecraftServer();
        if (minecraftServer != null) {
            for (class_3222 serverPlayer : minecraftServer.method_3760().method_14571()) {
                if (serverPlayer.field_7512 == abstractContainerMenu) {
                    return serverPlayer;
                }
            }
        }

        return null;
    }

    public static Optional<class_1657> getGrindstoneUsingPlayer(class_1799 topInput, class_1799 bottomInput) {
        MinecraftServer minecraftServer = CommonAbstractions.INSTANCE.getMinecraftServer();
        Optional<class_1657> optional = Optional.empty();
        for (class_3222 player : minecraftServer.method_3760().method_14571()) {
            if (player.field_7512 instanceof class_3803 menu) {
                optional = Optional.of(player);
                if (menu.method_7611(0).method_7677() == topInput && menu.method_7611(1).method_7677() == bottomInput) {
                    break;
                }
            }
        }
        return optional;
    }
}
