package fuzs.puzzleslib.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_3611;

public final class FluidRenderTypesContextImpl implements RenderTypesContext<class_3611> {

    @Override
    public void registerRenderType(class_1921 renderType, class_3611... fluids) {
        Objects.requireNonNull(renderType, "render type is null");
        Objects.requireNonNull(fluids, "fluids is null");
        Preconditions.checkState(fluids.length > 0, "fluids is empty");
        for (class_3611 fluid : fluids) {
            Objects.requireNonNull(fluid, "fluid is null");
            ClientAbstractions.INSTANCE.registerRenderType(fluid, renderType);
        }
    }

    @Override
    public class_1921 getRenderType(class_3611 object) {
        return ClientAbstractions.INSTANCE.getRenderType(object);
    }
}
