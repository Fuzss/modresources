package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_1690;
import net.minecraft.class_2960;
import net.minecraft.class_4719;
import net.minecraft.class_5601;
import net.minecraft.class_5602;

/**
 * A helper class for creating {@link class_5601 ModelLayerLocations} with a provided namespace.
 */
@FunctionalInterface
public interface ModelLayerFactory {

    /**
     * Creates a new instance from a mod id.
     *
     * @param modId model layer location namespace
     * @return the new factory
     */
    static ModelLayerFactory from(String modId) {
        return () -> modId;
    }

    /**
     * @return the mod id
     */
    String modId();

    /**
     * Creates a new {@link class_5601}.
     *
     * @param path  the entity name
     * @param layer the layer name
     * @return the new model layer location
     */
    @Deprecated
    default class_5601 register(String path, String layer) {
        return this.registerModelLayer(path, layer);
    }

    /**
     * Creates a new {@link class_5601}, the used layer is <code>main</code>.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    @Deprecated
    default class_5601 register(String path) {
        return this.registerModelLayer(path);
    }

    /**
     * Creates a new {@link class_5601}, the used layer is <code>inner_armor</code>.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    @Deprecated
    default class_5601 registerInnerArmor(String path) {
        return this.registerModelLayer(path, "inner_armor");
    }

    /**
     * Creates a new {@link class_5601}, the used layer is <code>outer_armor</code>.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    @Deprecated
    default class_5601 registerOuterArmor(String path) {
        return this.registerModelLayer(path, "outer_armor");
    }

    /**
     * Creates a new {@link class_5601}.
     *
     * @param path  the entity name
     * @param layer the layer name
     * @return the new model layer location
     */
    default class_5601 registerModelLayer(String path, String layer) {
        class_5601 modelLayerLocation = new class_5601(class_2960.method_60655(this.modId(),
                path), layer);
        if (!class_5602.field_27650.add(modelLayerLocation)) {
            throw new IllegalStateException("Duplicate registration for " + modelLayerLocation);
        } else {
            return modelLayerLocation;
        }
    }

    /**
     * Creates a new {@link class_5601}; the used layer is {@code main}.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    default class_5601 registerModelLayer(String path) {
        return this.registerModelLayer(path, "main");
    }

    /**
     * Creates a new {@link class_5601}; the used layer is {@code main}.
     *
     * @param path the entity name
     * @return the new model layer location
     */
    default ArmorModelSet<class_5601> registerArmorSet(String path) {
        return new ArmorModelSet<>(this.registerModelLayer(path, "helmet"),
                this.registerModelLayer(path, "chestplate"),
                this.registerModelLayer(path, "leggings"),
                this.registerModelLayer(path, "boots"));
    }

    /**
     * Creates a new {@link class_5601} for a raft; the used layer is {@code main}.
     *
     * @param boatType the boat type
     * @return the new model layer location
     */
    default class_5601 createRaftModelName(class_1690.class_1692 boatType) {
        return this.registerModelLayer("raft/" + boatType.method_7559());
    }

    /**
     * Creates a new {@link class_5601} for a chest raft; the used layer is {@code main}.
     *
     * @param boatType the boat type
     * @return the new model layer location
     */
    default class_5601 createChestRaftModelName(class_1690.class_1692 boatType) {
        return this.registerModelLayer("chest_raft/" + boatType.method_7559());
    }

    /**
     * Creates a new {@link class_5601} for a boat; the used layer is {@code main}.
     *
     * @param boatType the boat type
     * @return the new model layer location
     */
    default class_5601 createBoatModelName(class_1690.class_1692 boatType) {
        return this.registerModelLayer("boat/" + boatType.method_7559());
    }

    /**
     * Creates a new {@link class_5601} for a chest boat; the used layer is {@code main}.
     *
     * @param boatType the boat type
     * @return the new model layer location
     */
    default class_5601 createChestBoatModelName(class_1690.class_1692 boatType) {
        return this.registerModelLayer("chest_boat/" + boatType.method_7559());
    }

    /**
     * Creates a new {@link class_5601} for a sign; the used layer is {@code main}.
     *
     * @param woodType the wood type
     * @return the new model layer location
     */
    default class_5601 createSignModelName(class_4719 woodType) {
        return this.registerModelLayer("sign/" + woodType.comp_1299());
    }

    /**
     * Creates a new {@link class_5601} for a hanging sign; the used layer is {@code main}.
     *
     * @param woodType the wood type
     * @return the new model layer location
     */
    default class_5601 createHangingSignModelName(class_4719 woodType) {
        return this.registerModelLayer("hanging_sign/" + woodType.comp_1299());
    }
}
