package fuzs.puzzleslib.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import fuzs.puzzleslib.api.client.core.v1.context.RenderTypesContext;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_2248;

public final class BlockRenderTypesContextImpl implements RenderTypesContext<class_2248> {

    @Override
    public void registerRenderType(class_1921 renderType, class_2248... blocks) {
        Objects.requireNonNull(renderType, "render type is null");
        Objects.requireNonNull(blocks, "blocks is null");
        Preconditions.checkState(blocks.length > 0, "blocks is empty");
        for (class_2248 block : blocks) {
            Objects.requireNonNull(block, "block is null");
            ClientAbstractions.INSTANCE.registerRenderType(block, renderType);
        }
    }

    @Override
    public class_1921 getRenderType(class_2248 object) {
        return ClientAbstractions.INSTANCE.getRenderType(object);
    }
}
