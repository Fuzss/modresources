package fuzs.puzzleslib.impl.capability;

import fuzs.puzzleslib.api.capability.v3.CapabilityController;
import fuzs.puzzleslib.api.capability.v3.data.CapabilityKey;
import fuzs.puzzleslib.api.network.v3.ClientMessageListener;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import net.minecraft.class_1297;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;

public record ClientboundEntityCapabilityMessage(class_2960 identifier, int entityId, class_2487 tag) implements ClientboundMessage<ClientboundEntityCapabilityMessage> {

    @Override
    public ClientMessageListener<ClientboundEntityCapabilityMessage> getHandler() {
        return new ClientMessageListener<>() {

            @Override
            public void handle(ClientboundEntityCapabilityMessage message, class_310 minecraft, class_634 handler, class_746 player, class_638 level) {
                class_1297 entity = level.method_8469(message.entityId);
                if (entity != null) {
                    CapabilityKey<?, ?> capabilityKey = CapabilityController.get(message.identifier);
                    capabilityKey.getIfProvided(entity).ifPresent(capabilityComponent -> capabilityComponent.read(message.tag, handler.method_29091()));
                }
            }
        };
    }
}