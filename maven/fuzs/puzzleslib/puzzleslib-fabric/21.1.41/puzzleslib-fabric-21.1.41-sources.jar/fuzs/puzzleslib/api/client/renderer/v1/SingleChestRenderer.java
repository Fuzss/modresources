package fuzs.puzzleslib.api.client.renderer.v1;

import fuzs.puzzleslib.api.client.renderer.v1.model.RootedModel;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_2586;
import net.minecraft.class_2618;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4730;
import net.minecraft.class_5614;
import net.minecraft.class_630;
import net.minecraft.class_826;

/**
 * An extension of {@link class_826} that allows specifying custom chest texture materials for single chests (e.g.
 * ender chest).
 *
 * @param <T> the chest block entity type
 * @param <M> the chest model type
 */
public abstract class SingleChestRenderer<T extends class_2586 & class_2618, M extends SingleChestRenderer.ChestModel> extends class_826<T> {
    protected final M model;
    @Nullable
    private T blockEntity;
    @Nullable
    private Float partialTick;
    @Nullable
    private class_4597 bufferSource;

    /**
     * @param context the renderer context
     * @param model   the single chest model
     */
    protected SingleChestRenderer(class_5614.class_5615 context, M model) {
        super(context);
        this.model = model;
    }

    @Override
    public final void method_3569(T blockEntity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        this.blockEntity = blockEntity;
        this.partialTick = partialTick;
        this.bufferSource = bufferSource;
        super.method_3569(blockEntity, partialTick, poseStack, bufferSource, packedLight, packedOverlay);
        this.blockEntity = null;
        this.partialTick = null;
        this.bufferSource = null;
    }

    @ApiStatus.Internal
    @Override
    protected final void method_22749(class_4587 poseStack, class_4588 consumer, class_630 lidPart, class_630 lockPart, class_630 bottomPart, float openness, int packedLight, int packedOverlay) {
        Objects.requireNonNull(this.blockEntity, "block entity is null");
        Objects.requireNonNull(this.partialTick, "partial tick is null");
        Objects.requireNonNull(this.bufferSource, "buffer source is null");
        this.model.setupAnim(openness);
        this.renderModel(this.blockEntity, this.partialTick, poseStack, this.bufferSource, packedLight, packedOverlay);
    }

    /**
     * Render the single chest model after everything on the pose stack has been set up.
     *
     * @param blockEntity   the block entity
     * @param partialTick   the partial tick time
     * @param poseStack     the pose stack
     * @param bufferSource  the multi buffer source
     * @param packedLight   the packed light
     * @param packedOverlay the packed overlay
     */
    protected void renderModel(T blockEntity, float partialTick, class_4587 poseStack, class_4597 bufferSource, int packedLight, int packedOverlay) {
        class_4588 vertexConsumer = this.getChestMaterial(blockEntity, this.getXmasTextures())
                .method_24145(bufferSource, class_1921::method_23576);
        this.model.method_60879(poseStack, vertexConsumer, packedLight, packedOverlay);
    }

    /**
     * Get the single chest texture material for the chest type.
     *
     * @param blockEntity  the block entity
     * @param xmasTextures should use holiday textures
     * @return the single chest texture material
     */
    protected abstract class_4730 getChestMaterial(T blockEntity, boolean xmasTextures);

    /**
     * @return should use holiday textures
     */
    protected boolean getXmasTextures() {
        return this.field_4365;
    }

    public static class ChestModel extends RootedModel {
        private final class_630 lid;
        private final class_630 lock;

        public ChestModel(class_630 root) {
            super(root, class_1921::method_23572);
            this.lid = root.method_32086("lid");
            this.lock = root.method_32086("lock");
        }

        public void setupAnim(float openness) {
            this.resetPose();
            this.lid.field_3654 = -(openness * (float) (Math.PI / 2));
            this.lock.field_3654 = this.lid.field_3654;
        }
    }
}
