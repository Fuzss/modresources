package fuzs.puzzleslib.impl.item;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import fuzs.puzzleslib.api.core.v1.ContentRegistrationFlags;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_1869;
import net.minecraft.class_3955;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9694;
import net.minecraft.world.item.crafting.*;

import java.util.function.BiConsumer;
import java.util.function.Supplier;

@Deprecated
public interface CopyComponentsRecipe {
    /**
     * The shaped recipe serializer id that is used during registration.
     */
    String SHAPED_RECIPE_SERIALIZER_ID = "copy_components_shaped_recipe";
    /**
     * The shapeless recipe serializer id that is used during registration.
     */
    String SHAPELESS_RECIPE_SERIALIZER_ID = "copy_components_shapeless_recipe";

    /**
     * Finds the mod-specific {@link class_1865} in the registry.
     * <p>{@link fuzs.puzzleslib.api.core.v1.ContentRegistrationFlags#COPY_RECIPES} must be enabled so the
     * serializer is registered.
     *
     * @param modId              the mod id to find the serializer for
     * @param recipeSerializerId the serializer string id, either {@link #SHAPED_RECIPE_SERIALIZER_ID} or
     *                           {@link #SHAPELESS_RECIPE_SERIALIZER_ID}
     * @return the serializer
     */
    static class_1865<?> getModSerializer(String modId, String recipeSerializerId) {
        class_1865<?> recipeSerializer = class_7923.field_41189.method_10223(ResourceLocationHelper.fromNamespaceAndPath(
                modId,
                recipeSerializerId
        ));
        if (recipeSerializer == null) ContentRegistrationFlags.throwForFlag(ContentRegistrationFlags.COPY_RECIPES);
        return recipeSerializer;
    }

    static void registerSerializers(BiConsumer<String, Supplier<class_1865<?>>> registrar) {
        registrar.accept(SHAPED_RECIPE_SERIALIZER_ID,
                () -> new Serializer<>(new class_1869.class_1870(), CopyComponentsShapedRecipe::new)
        );
        registrar.accept(SHAPELESS_RECIPE_SERIALIZER_ID,
                () -> new Serializer<>(new class_1867.class_1868(), CopyComponentsShapelessRecipe::new)
        );
    }

    class_1856 getComponentsSource();

    default void copyComponentsToResult(class_1799 result, class_9694 craftingInput) {
        for (int i = 0; i < craftingInput.method_59983(); i++) {
            class_1799 itemStack = craftingInput.method_59984(i);
            if (this.getComponentsSource().method_8093(itemStack)) {
                result.method_57365(itemStack.method_57353());
                return;
            }
        }
    }

    @FunctionalInterface
    interface Factory<T extends class_3955, S extends class_3955 & CopyComponentsRecipe> {

        S apply(class_1865<?> recipeSerializer, T craftingRecipe, class_1856 ingredient);
    }

    record Serializer<R1 extends class_3955, R2 extends class_3955 & CopyComponentsRecipe>(class_1865<R1> serializer,
                                                                                                   Factory<R1, R2> factory) implements class_1865<R2> {

        @Override
        public MapCodec<R2> method_53736() {
            return RecordCodecBuilder.mapCodec((instance) -> {
                return instance.group(this.serializer.method_53736().forGetter((R2 arg) -> {
                            return (R1) arg;
                        }), class_1856.field_46095.fieldOf("copy_from").forGetter(CopyComponentsRecipe::getComponentsSource))
                        .apply(instance,
                                (R1 craftingRecipe, class_1856 ingredient) -> this.factory.apply(this,
                                        craftingRecipe,
                                        ingredient
                                )
                        );
            });
        }

        @Override
        public class_9139<class_9129, R2> method_56104() {
            return class_9139.method_56437(this::toNetwork, this::fromNetwork);
        }

        private R2 fromNetwork(class_9129 buffer) {
            R1 recipe = this.serializer.method_56104().decode(buffer);
            class_1856 ingredient = class_1856.field_48355.decode(buffer);
            return this.factory.apply(this, recipe, ingredient);
        }

        private void toNetwork(class_9129 buffer, R2 recipe) {
            this.serializer.method_56104().encode(buffer, (R1) recipe);
            class_1856.field_48355.encode(buffer, recipe.getComponentsSource());
        }
    }
}
