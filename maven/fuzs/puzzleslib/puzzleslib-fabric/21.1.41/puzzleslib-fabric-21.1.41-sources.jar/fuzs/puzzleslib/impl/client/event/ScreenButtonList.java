package fuzs.puzzleslib.impl.client.event;

import java.util.AbstractList;
import java.util.List;
import net.minecraft.class_339;
import net.minecraft.class_4068;

/**
 * A simple utility class that allows getting a list of all {@link class_339} instances in screen, but as a view of
 * {@link net.minecraft.class_437#field_33816}.
 * <p>
 * Intended for use during init events. A view is required so that changes from additions and removals of widgets are
 * reflected.
 * <p>
 * This is basically the same as Fabric Api's <code>net.fabricmc.fabric.impl.client.screen.ButtonList</code>, just much
 * simpler as it does not need to handle additions and removals (Forge has dedicated methods in the init events for
 * that).
 */
public final class ScreenButtonList extends AbstractList<class_339> {
    private final List<class_4068> renderables;

    public ScreenButtonList(List<class_4068> renderables) {
        this.renderables = renderables;
    }

    @Override
    public int size() {
        return (int) this.renderables.stream().filter(class_339.class::isInstance).count();
    }

    @Override
    public class_339 get(int index) {
        return this.renderables.stream()
                .filter(class_339.class::isInstance)
                .skip(index)
                .findFirst()
                .map(class_339.class::cast)
                .orElseThrow(() -> new IndexOutOfBoundsException(index));
    }
}
