package fuzs.puzzleslib.impl.client.event;

import org.jetbrains.annotations.Nullable;

import java.lang.ref.WeakReference;
import java.util.function.Function;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_7923;
import net.minecraft.class_9824;

public final class ModelLoadingHelper {
    private static WeakReference<@Nullable class_9824> modelLoaderReference = new WeakReference<>(null);

    private ModelLoadingHelper() {
        // NO-OP
    }

    public static void setModelLoader(class_9824 modelLoader) {
        // do not discard this at the end of model loading,
        // with ModernFix models can be loaded at any time, and we never know when it is needed
        // wrapping in a weak reference should be fine though, so it is only held on to when necessary (and still strongly referenced by ModernFix)
        ModelLoadingHelper.modelLoaderReference = new WeakReference<>(modelLoader);
    }

    public static Function<class_1091, class_1100> getUnbakedTopLevelModel(class_1088 modelBakery) {
        return (class_1091 modelResourceLocation) -> {
            return getUnbakedTopLevelModel(modelBakery, modelResourceLocation);
        };
    }

    private static class_1100 getUnbakedTopLevelModel(class_1088 modelBakery, class_1091 modelResourceLocation) {
        class_1100 unbakedModel = modelBakery.field_5394.get(modelResourceLocation);
        // when ModernFix is installed the model will likely be missing from ModelBakery#topLevelModels
        // so try to load it manually here, alternatively ModelManager::getModel works as well in some scenarios
        class_9824 modelLoader = modelLoaderReference.get();
        if (unbakedModel == null && modelLoader != null) {
            unbakedModel = loadUnbakedBlockStateModel(modelBakery, modelLoader, modelResourceLocation);
        } else if (unbakedModel != null) {
            // this is necessary, or else some random block states will have missed out on it for some reason
            unbakedModel.method_45785(modelBakery::method_4726);
        }
        if (unbakedModel == null) {
            return modelBakery.field_5394.get(class_1088.field_52276);
        } else {
            return unbakedModel;
        }
    }

    @Nullable
    public static class_1100 loadUnbakedBlockStateModel(class_1088 modelBakery, class_9824 blockStateModelLoader, class_1091 modelResourceLocation) {
        return class_7923.field_41175.method_17966(modelResourceLocation.comp_2875()).map(block -> {
            blockStateModelLoader.method_61053(modelResourceLocation.comp_2875(), block.method_9595());
            class_1100 unbakedModel = modelBakery.field_5394.get(modelResourceLocation);
            if (unbakedModel != null) unbakedModel.method_45785(modelBakery::method_4726);
            return unbakedModel;
        }).orElse(null);
    }
}
