package fuzs.puzzleslib.impl.network.codec;

import fuzs.puzzleslib.impl.network.CustomPacketPayloadAdapterImpl;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/**
 * An extension to {@link class_8710} for wrapping a custom object.
 *
 * @param <T> the message type
 */
public interface CustomPacketPayloadAdapter<T> extends class_8710 {

    @Override
    class_9154<? extends CustomPacketPayloadAdapter<T>> method_56479();

    /**
     * @return the wrapped object
     */
    T unwrap();

    /**
     * Creates a {@link class_8710} compatible {@link class_9139}.
     *
     * @param type        the custom packet payload type
     * @param streamCodec the stream codec
     * @param <T>         data type
     * @return the {@link class_8710} stream codec
     */
    static <B extends ByteBuf, T> class_9139<? super B, CustomPacketPayloadAdapter<T>> streamCodec(class_8710.class_9154<CustomPacketPayloadAdapter<T>> type, class_9139<? super ByteBuf, T> streamCodec) {
        return class_8710.method_56484((CustomPacketPayloadAdapter<T> adapter, ByteBuf buf) -> {
            streamCodec.encode(buf, adapter.unwrap());
        }, (ByteBuf buf) -> {
            return new CustomPacketPayloadAdapterImpl<>(type, streamCodec.decode(buf));
        });
    }
}
