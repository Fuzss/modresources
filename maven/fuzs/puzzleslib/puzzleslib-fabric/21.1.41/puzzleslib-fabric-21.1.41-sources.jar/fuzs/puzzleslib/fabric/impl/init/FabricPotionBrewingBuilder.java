package fuzs.puzzleslib.fabric.impl.init;

import fuzs.puzzleslib.api.event.v1.server.RegisterPotionBrewingMixesCallback;
import java.util.Objects;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1856;
import net.minecraft.class_6880;

public record FabricPotionBrewingBuilder(class_1845.class_9665 builder) implements RegisterPotionBrewingMixesCallback.Builder {

    @Override
    public void registerPotionContainer(class_1812 item) {
        Objects.requireNonNull(item, "container item is null");
        this.builder.method_59702(item);
    }

    @Override
    public void registerContainerRecipe(class_1812 from, class_1856 ingredient, class_1812 to) {
        Objects.requireNonNull(from, "from item is null");
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(to, "to item is null");
        this.builder.registerItemRecipe(from, ingredient, to);
    }

    @Override
    public void registerPotionRecipe(class_6880<class_1842> from, class_1856 ingredient, class_6880<class_1842> to) {
        Objects.requireNonNull(from, "from potion is null");
        Objects.requireNonNull(ingredient, "ingredient is null");
        Objects.requireNonNull(to, "to potion is null");
        this.builder.registerPotionRecipe(from, ingredient, to);
    }
}
