package fuzs.puzzleslib.fabric.impl.init;

import fuzs.puzzleslib.api.init.v3.GameRulesFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.class_1928;
import net.minecraft.server.MinecraftServer;
import java.util.function.BiConsumer;

public final class FabricGameRulesFactory implements GameRulesFactory {

    @Override
    public <T extends class_1928.class_4315<T>> class_1928.class_4313<T> register(String name, class_1928.class_5198 category, class_1928.class_4314<T> type) {
        return GameRuleRegistry.register(name, category, type);
    }

    @Override
    public class_1928.class_4314<class_1928.class_4310> createBooleanRule(boolean defaultValue, BiConsumer<MinecraftServer, class_1928.class_4310> callback) {
        return GameRuleFactory.createBooleanRule(defaultValue, callback);
    }

    @Override
    public class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue, int minimumValue, int maximumValue, BiConsumer<MinecraftServer, class_1928.class_4312> callback) {
        return GameRuleFactory.createIntRule(defaultValue, minimumValue, maximumValue, callback);
    }
}
