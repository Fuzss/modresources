package fuzs.puzzleslib.impl.network.codec;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.mojang.authlib.GameProfile;
import fuzs.puzzleslib.api.network.v3.codec.ExtraStreamCodecs;
import fuzs.puzzleslib.api.network.v3.codec.StreamCodecRegistry;
import fuzs.puzzleslib.impl.PuzzlesLib;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_1291;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1856;
import net.minecraft.class_1923;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2379;
import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2487;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_3611;
import net.minecraft.class_3850;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_3917;
import net.minecraft.class_3965;
import net.minecraft.class_4050;
import net.minecraft.class_4158;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9336;
import net.minecraft.core.*;
import org.joml.Vector3f;

import java.lang.reflect.Array;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.time.Instant;
import java.util.*;
import java.util.function.Function;
import java.util.function.IntFunction;

public final class StreamCodecRegistryImpl implements StreamCodecRegistry<StreamCodecRegistryImpl> {
    public static final StreamCodecRegistry<?> INSTANCE = new StreamCodecRegistryImpl();
    private static final Map<Class<?>, class_9139<?, ?>> SERIALIZERS = Collections.synchronizedMap(Maps.newIdentityHashMap());
    private static final Map<Class<?>, Function<Type[], class_9139<?, ?>>> CONTAINER_PROVIDERS = Collections.synchronizedMap(
            Maps.newLinkedHashMap());

    @Override
    public <B extends ByteBuf, V> StreamCodecRegistryImpl registerSerializer(Class<V> type, class_9139<? super B, V> streamCodec) {
        if (SERIALIZERS.put(type, streamCodec) != null) {
            PuzzlesLib.LOGGER.warn("Overriding serializer registered for type {}", type);
        }

        return this;
    }

    @SuppressWarnings("unchecked")
    @Override
    public <B extends ByteBuf, V> StreamCodecRegistryImpl registerContainerProvider(Class<V> type, Function<Type[], class_9139<? super B, ? extends V>> factory) {
        if (CONTAINER_PROVIDERS.put(type, (Function<Type[], class_9139<?, ?>>) (Function<?, ?>) factory) != null) {
            PuzzlesLib.LOGGER.warn("Overriding collection provider registered for type {}", type);
        }

        return this;
    }

    /**
     * Find a serializer for a given type. Some serializers (for records, arrays, and enums) can be created
     * dynamically.
     *
     * @param type serializable type
     * @param <V>  data type
     * @return serializer for this type
     */
    @SuppressWarnings("unchecked")
    public static <B extends ByteBuf, V> class_9139<B, V> fromType(Class<V> type) {
        // don't use Map::computeIfAbsent on map, it will throw java.lang.ConcurrentModificationException as during the Map::computeIfAbsent for the main record type
        // more calls to MessageSerializers::getByType can happen when the record contains other records / enums / arrays as fields
        class_9139<B, V> streamCodec = (class_9139<B, V>) SERIALIZERS.get(type);
        if (streamCodec == null) {
            streamCodec = computeIfAbsent(type);
            SERIALIZERS.put(type, streamCodec);
        }

        return streamCodec;
    }

    @SuppressWarnings("unchecked")
    private static <B extends ByteBuf, V> class_9139<B, V> computeIfAbsent(Class<V> clazz) {
        if (Record.class.isAssignableFrom(clazz)) {
            return (class_9139<B, V>) RecordStreamCodec.createRecordSerializer((Class<Record>) clazz);
        } else if (clazz.isArray()) {
            return (class_9139<B, V>) createArraySerializer(clazz.getComponentType());
        } else if (clazz.isEnum()) {
            return (class_9139<B, V>) createEnumSerializer((Class<Enum<?>>) clazz);
        } else {
            throw new RuntimeException("Missing serializer for type " + clazz);
        }
    }

    @SuppressWarnings("unchecked")
    public static <B extends ByteBuf, V> class_9139<B, V> fromGenericType(Type type) {

        if (type instanceof Class<?>) {

            return fromType((Class<V>) type);
        } else {

            ParameterizedType parameterizedType = (ParameterizedType) type;
            Class<?> clazz = (Class<?>) parameterizedType.getRawType();
            Type[] typeArguments = parameterizedType.getActualTypeArguments();

            for (Map.Entry<Class<?>, Function<Type[], class_9139<?, ?>>> entry : CONTAINER_PROVIDERS.entrySet()) {

                if (entry.getKey().isAssignableFrom(clazz)) {

                    return (class_9139<B, V>) entry.getValue().apply(typeArguments);
                }
            }

            // fallback for collections, don't include in providers to allow for handling more concrete collection implementations
            if (Collection.class.isAssignableFrom(clazz)) {

                return (class_9139<B, V>) createCollectionSerializer(typeArguments,
                        Sets::newLinkedHashSetWithExpectedSize
                );
            }

            return fromType((Class<V>) clazz);
        }
    }

    @SuppressWarnings("unchecked")
    private static <K, V> class_9139<class_2540, Map<K, V>> createMapSerializer(Type[] typeArguments) {
        class_9139<ByteBuf, K> keyStreamCodec = fromType((Class<K>) typeArguments[0]);
        class_9139<ByteBuf, V> valueStreamCodec = fromType((Class<V>) typeArguments[1]);
        return class_9139.method_56437((class_2540 friendlyByteBuf, Map<K, V> map) -> {
            friendlyByteBuf.method_34063(map, keyStreamCodec, valueStreamCodec);
        }, (class_2540 buf) -> {
            return buf.method_34067(keyStreamCodec, valueStreamCodec);
        });
    }

    @SuppressWarnings("unchecked")
    private static <V, C extends Collection<V>> class_9139<class_2540, C> createCollectionSerializer(Type[] typeArguments, IntFunction<C> factory) {
        class_9139<ByteBuf, V> streamCodec = fromType((Class<V>) typeArguments[0]);
        return class_9139.method_56437((class_2540 buf, C collection) -> {
            buf.method_34062(collection, streamCodec);
        }, (class_2540 buf) -> {
            return buf.method_34068(factory, streamCodec);
        });
    }

    @SuppressWarnings("unchecked")
    private static <V> class_9139<class_2540, Optional<V>> createOptionalSerializer(Type[] typeArguments) {
        class_9139<ByteBuf, V> streamCodec = fromType((Class<V>) typeArguments[0]);
        return class_9139.method_56437((class_2540 buf, Optional<V> optional) -> {
            buf.method_37435(optional, streamCodec);
        }, (class_2540 buf) -> {
            return buf.method_37436(streamCodec);
        });
    }

    @SuppressWarnings("unchecked")
    private static <V> class_9139<class_9129, class_6880<V>> createHolderSerializer(Type[] typeArguments) {
        return class_9139.method_56437((class_9129 buf, class_6880<V> holder) -> {
            class_5321<V> resourceKey = holder.method_40230().orElseThrow();
            ExtraStreamCodecs.DIRECT_RESOURCE_KEY.encode(buf, resourceKey);
            class_9135.method_56383(resourceKey.method_58273()).encode(buf, holder);
        }, (class_9129 buf) -> {
            class_5321<V> resourceKey = (class_5321<V>) ExtraStreamCodecs.DIRECT_RESOURCE_KEY.decode(buf);
            return class_9135.method_56383(resourceKey.method_58273()).decode(buf);
        });
    }

    @SuppressWarnings("unchecked")
    private static <V> class_9139<class_2540, V[]> createArraySerializer(Class<?> clazz) {
        class_9139<ByteBuf, V> streamCodec = (class_9139<ByteBuf, V>) fromType(clazz);
        return class_9139.method_56437((class_2540 buf, V[] array) -> {
            final int length = Array.getLength(array);
            buf.method_10804(length);
            for (int i = 0; i < length; i++) {
                streamCodec.encode(buf, (V) Array.get(array, i));
            }
        }, (class_2540 buf) -> {
            final int length = buf.method_10816();
            Object array = Array.newInstance(clazz, length);
            for (int i = 0; i < length; i++) {
                Array.set(array, i, streamCodec.decode(buf));
            }
            return (V[]) array;
        });
    }

    @SuppressWarnings("unchecked")
    private static <E extends Enum<E>> class_9139<class_2540, E> createEnumSerializer(Class<Enum<?>> clazz) {
        return class_9139.method_56437(class_2540::method_10817, (class_2540 buf) -> {
            return buf.method_10818((Class<E>) clazz);
        });
    }

    static {
        INSTANCE.registerSerializer(boolean.class, class_9135.field_48547);
        INSTANCE.registerSerializer(Boolean.class, class_9135.field_48547);
        INSTANCE.registerSerializer(int.class, class_9135.field_48550);
        INSTANCE.registerSerializer(Integer.class, class_9135.field_48550);
        INSTANCE.registerSerializer(long.class, class_9135.field_48551);
        INSTANCE.registerSerializer(Long.class, class_9135.field_48551);
        INSTANCE.registerSerializer(float.class, class_9135.field_48552);
        INSTANCE.registerSerializer(Float.class, class_9135.field_48552);
        INSTANCE.registerSerializer(double.class, class_9135.field_48553);
        INSTANCE.registerSerializer(Double.class, class_9135.field_48553);
        INSTANCE.registerSerializer(byte.class, class_9135.field_48548);
        INSTANCE.registerSerializer(Byte.class, class_9135.field_48548);
        INSTANCE.registerSerializer(short.class, class_9135.field_48549);
        INSTANCE.registerSerializer(Short.class, class_9135.field_48549);
        INSTANCE.registerSerializer(char.class, ExtraStreamCodecs.CHAR);
        INSTANCE.registerSerializer(Character.class, ExtraStreamCodecs.CHAR);

        INSTANCE.registerSerializer(String.class, class_9135.field_48554);
        INSTANCE.registerSerializer(Date.class, ExtraStreamCodecs.DATE);
        INSTANCE.registerSerializer(Instant.class, ExtraStreamCodecs.INSTANT);
        INSTANCE.registerSerializer(UUID.class, class_4844.field_48453);

        INSTANCE.registerSerializer(class_2561.class, class_8824.field_49666);
        INSTANCE.registerSerializer(class_1799.class, class_1799.field_49268);
        INSTANCE.registerSerializer(class_1856.class, class_1856.field_48355);
        INSTANCE.registerSerializer(class_2379.class, class_2379.field_48452);
        INSTANCE.registerSerializer(class_2338.class, class_2338.field_48404);
        INSTANCE.registerSerializer(class_2350.class, class_2350.field_48450);
        INSTANCE.registerSerializer(class_2487.class, class_9135.field_49677);
        INSTANCE.registerSerializer(class_2394.class, class_2398.field_48456);
        INSTANCE.registerSerializer(class_3850.class, class_3850.field_48345);
        INSTANCE.registerSerializer(class_4050.class, class_4050.field_48323);
        INSTANCE.registerSerializer(class_1923.class, ExtraStreamCodecs.CHUNK_POS);
        INSTANCE.registerSerializer(class_2960.class, class_2960.field_48267);
        INSTANCE.registerSerializer((Class<class_5321<?>>) (Class<?>) class_5321.class,
                ExtraStreamCodecs.DIRECT_RESOURCE_KEY
        );
        INSTANCE.registerSerializer((Class<class_9336<?>>) (Class<?>) class_9336.class,
                class_9336.field_49657
        );
        INSTANCE.registerSerializer(class_3965.class, ExtraStreamCodecs.BLOCK_HIT_RESULT);
        INSTANCE.registerSerializer(BitSet.class, ExtraStreamCodecs.BIT_SET);
        INSTANCE.registerSerializer(GameProfile.class, class_9135.field_49679);
        INSTANCE.registerSerializer(class_243.class, ExtraStreamCodecs.VEC3);
        INSTANCE.registerSerializer(Vector3f.class, ExtraStreamCodecs.VECTOR3F);
        INSTANCE.registerSerializer(class_2540.class, ExtraStreamCodecs.FRIENDLY_BYTE_BUF);
        INSTANCE.registerSerializer(class_9129.class, ExtraStreamCodecs.REGISTRY_FRIENDLY_BYTE_BUF);

        INSTANCE.registerSerializer(class_3414.class, class_7924.field_41225);
        INSTANCE.registerSerializer(class_3611.class, class_7924.field_41270);
        INSTANCE.registerSerializer(class_1291.class, class_7924.field_41208);
        INSTANCE.registerSerializer(class_2248.class, class_7924.field_41254);
        INSTANCE.registerSerializer(class_1299.class, class_7924.field_41266);
        INSTANCE.registerSerializer(class_1792.class, class_7924.field_41197);
        INSTANCE.registerSerializer(class_1842.class, class_7924.field_41215);
        INSTANCE.registerSerializer(class_2396.class, class_7924.field_41210);
        INSTANCE.registerSerializer(class_2591.class, class_7924.field_41255);
        INSTANCE.registerSerializer(class_3917.class, class_7924.field_41207);
        INSTANCE.registerSerializer(class_1320.class, class_7924.field_41251);
        INSTANCE.registerSerializer(class_5712.class, class_7924.field_41273);
        INSTANCE.registerSerializer(class_3854.class, class_7924.field_41235);
        INSTANCE.registerSerializer(class_3852.class, class_7924.field_41234);
        INSTANCE.registerSerializer(class_4158.class, class_7924.field_41212);

        INSTANCE.registerContainerProvider(Map.class, StreamCodecRegistryImpl::createMapSerializer);
        INSTANCE.registerContainerProvider(List.class,
                (Type[] typeArguments) -> createCollectionSerializer(typeArguments, ArrayList::new)
        );
        INSTANCE.registerContainerProvider(Optional.class, StreamCodecRegistryImpl::createOptionalSerializer);
        INSTANCE.registerContainerProvider(class_6880.class, StreamCodecRegistryImpl::createHolderSerializer);
    }
}
