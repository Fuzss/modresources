package fuzs.puzzleslib.api.client.core.v1;

import fuzs.puzzleslib.api.client.core.v1.context.ClientTooltipComponentsContext;
import fuzs.puzzleslib.api.client.gui.v2.ScreenHelper;
import fuzs.puzzleslib.api.client.renderer.v1.RenderTypeHelper;
import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import java.util.List;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3611;
import net.minecraft.class_4696;
import net.minecraft.class_5481;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_634;
import net.minecraft.class_8000;
import net.minecraft.class_8710;

/**
 * Useful methods for client related things that require mod loader specific abstractions.
 */
@Deprecated
public interface ClientAbstractions {
    ClientAbstractions INSTANCE = new ClientAbstractions() {
        // NO-OP
    };

    /**
     * Checks if the connected server declared the ability to receive a specific type of packet.
     *
     * @param clientPacketListener the client packet listener
     * @param type                 the packet type
     * @return if the connected server has declared the ability to receive a specific type of packet
     */
    default boolean hasChannel(class_634 clientPacketListener, class_8710.class_9154<?> type) {
        return ClientProxyImpl.get().hasChannel(clientPacketListener, type);
    }

    /**
     * Checks if a key mapping is pressed.
     * <p>
     * NeoForge replaces the vanilla call to {@link class_304#method_1417(int, int)} in a few places to account for key
     * activation contexts (game &amp; screen environments).
     *
     * @param keyMapping the key mapping to check if pressed
     * @param keyCode    the current key code
     * @param scanCode   the key scan code
     * @return is the key mapping pressed
     */
    default boolean isKeyActiveAndMatches(class_304 keyMapping, int keyCode, int scanCode) {
        return ClientProxyImpl.get().isKeyActiveAndMatches(keyMapping, keyCode, scanCode);
    }

    /**
     * Converts an image {@link class_5632} into the appropriate client-side component.
     * <p>
     * {@link class_5684}s must first be registered in
     * {@link ClientModConstructor#onRegisterClientTooltipComponents(ClientTooltipComponentsContext)}, otherwise
     * {@link IllegalArgumentException} will be thrown.
     * <p>
     * For simple text based components directly use {@link class_5684#method_32662(class_5481)}
     * instead.
     *
     * @param imageComponent the un-sided {@link class_5632} to convert
     * @return the client tooltip components representation
     */
    default class_5684 createImageComponent(class_5632 imageComponent) {
        return ClientProxyImpl.get().createImageComponent(imageComponent);
    }

    /**
     * Retrieves a model from the {@link class_1092}, allows for using {@link class_2960} instead of
     * {@link net.minecraft.class_1091}.
     *
     * @param resourceLocation the model resource location
     * @return the model, or the missing model if not found
     *
     * @deprecated use {@link #getBakedModel(class_1092, class_2960)}
     */
    @Deprecated(forRemoval = true)
    default class_1087 getBakedModel(class_2960 resourceLocation) {
        return this.getBakedModel(class_310.method_1551().method_1554(), resourceLocation);
    }

    /**
     * Retrieves a model from the {@link class_1092}, allows for using {@link class_2960} instead of
     * {@link net.minecraft.class_1091}.
     *
     * @param modelManager     the model manager instance
     * @param resourceLocation the model resource location
     * @return the model, or the missing model if not found
     */
    default class_1087 getBakedModel(class_1092 modelManager, class_2960 resourceLocation) {
        return ClientProxyImpl.get().getBakedModel(modelManager, resourceLocation);
    }

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for a block.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is returned.
     *
     * @param block the block to get the render type for
     * @return the render type
     */
    default class_1921 getRenderType(class_2248 block) {
        return RenderTypeHelper.getRenderType(block);
    }

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for a fluid.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is returned.
     *
     * @param fluid the fluid to get the render type for
     * @return the render type
     */
    default class_1921 getRenderType(class_3611 fluid) {
        return class_4696.method_23680(fluid.method_15785());
    }

    /**
     * Allows for registering a {@link class_1921} for a block.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is used.
     *
     * @param block      the block to register the render type for
     * @param renderType the render type
     */
    default void registerRenderType(class_2248 block, class_1921 renderType) {
        ClientProxyImpl.get().registerRenderType(block, renderType);
    }

    /**
     * Allows for registering a {@link class_1921} for a fluid.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is used.
     *
     * @param fluid      the fluid to register the render type for
     * @param renderType the render type
     */
    default void registerRenderType(class_3611 fluid, class_1921 renderType) {
        ClientProxyImpl.get().registerRenderType(fluid, renderType);
    }

    /**
     * Get the current partial tick time while taking into account whether the game is paused.
     *
     * @return current partial tick time
     */
    default float getPartialTick() {
        return ScreenHelper.getPartialTick();
    }

    /**
     * Called just before a tooltip is drawn on a screen, allows for preventing the tooltip from drawing.
     *
     * @param guiGraphics the gui graphics instance
     * @param font        the font instance
     * @param mouseX      x position of the mouse cursor
     * @param mouseY      y position of the mouse cursor
     * @param components  components to render in the tooltip
     * @param positioner  positioner for placing the tooltip in relation to provided mouse coordinates
     * @return <code>true</code> to prevent the tooltip from rendering, allows for fully taking over rendering
     */
    default boolean onRenderTooltip(class_332 guiGraphics, class_327 font, int mouseX, int mouseY, List<class_5684> components, class_8000 positioner) {
        return ClientProxyImpl.get().onRenderTooltip(guiGraphics, font, mouseX, mouseY, components, positioner);
    }

    /**
     * Returns the current render height for hotbar decorations on the left side.
     * <p>
     * In vanilla this includes player health and armor level.
     *
     * @param gui the gui instance
     * @return the hotbar decorations render height
     */
    default int getGuiLeftHeight(class_329 gui) {
        return ClientProxyImpl.get().getGuiLeftHeight(gui);
    }

    /**
     * Returns the current render height for hotbar decorations on the right side.
     * <p>
     * In vanilla this includes player food level, vehicle health and air supply.
     *
     * @param gui the gui instance
     * @return the hotbar decorations render height
     */
    default int getGuiRightHeight(class_329 gui) {
        return ClientProxyImpl.get().getGuiRightHeight(gui);
    }

    /**
     * Add to the current render height for hotbar decorations on the left side.
     *
     * @param gui        the gui instance
     * @param leftHeight the additional hotbar decorations render height
     */
    default void addGuiLeftHeight(class_329 gui, int leftHeight) {
        ClientProxyImpl.get().addGuiLeftHeight(gui, leftHeight);
    }

    /**
     * Add to the current render height for hotbar decorations on the right side.
     *
     * @param gui         the gui instance
     * @param rightHeight the additional hotbar decorations render height
     */
    default void addGuiRightHeight(class_329 gui, int rightHeight) {
        ClientProxyImpl.get().addGuiRightHeight(gui, rightHeight);
    }
}
