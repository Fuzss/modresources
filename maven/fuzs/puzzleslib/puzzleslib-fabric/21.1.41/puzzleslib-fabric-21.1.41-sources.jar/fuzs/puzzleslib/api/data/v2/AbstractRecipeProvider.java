package fuzs.puzzleslib.api.data.v2;

import com.google.common.base.Preconditions;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.serialization.JsonOps;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import net.minecraft.class_161;
import net.minecraft.class_175;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2405;
import net.minecraft.class_2446;
import net.minecraft.class_2960;
import net.minecraft.class_3981;
import net.minecraft.class_5797;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7800;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public abstract class AbstractRecipeProvider extends class_2446 {
    protected final String modId;

    public AbstractRecipeProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractRecipeProvider(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
        super(packOutput, lookupProvider);
        this.modId = modId;
    }

    @Nullable
    protected static <T> JsonElement searchAndReplaceValue(@Nullable JsonElement jsonElement, T searchFor, T replaceWith) {
        Objects.requireNonNull(searchFor, "search for is null");
        Objects.requireNonNull(replaceWith, "replace with is null");
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            if (jsonElement.isJsonPrimitive()) {
                JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
                if (jsonPrimitive.isNumber()) {
                    if (searchFor.equals(jsonPrimitive.getAsNumber())) {
                        return new JsonPrimitive((Number) replaceWith);
                    }
                } else if (jsonPrimitive.isBoolean()) {
                    if (searchFor.equals(jsonPrimitive.getAsBoolean())) {
                        return new JsonPrimitive((Boolean) replaceWith);
                    }
                } else if (jsonPrimitive.isString()) {
                    if (searchFor.toString().equals(jsonPrimitive.getAsString())) {
                        return new JsonPrimitive(replaceWith.toString());
                    }
                }
                return jsonElement;
            } else if (jsonElement.isJsonArray()) {
                JsonArray jsonArray = jsonElement.getAsJsonArray();
                for (int i = 0; i < jsonArray.size(); i++) {
                    jsonArray.set(i, searchAndReplaceValue(jsonArray.get(i), searchFor, replaceWith));
                }
            } else if (jsonElement.isJsonObject()) {
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                    entry.setValue(searchAndReplaceValue(entry.getValue(), searchFor, replaceWith));
                }
            }
        }
        return jsonElement;
    }

    public static String getItemName(class_1856 ingredient) {
        return getItemName(Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    public static String getItemName(class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return Arrays.stream(items).map(class_2446::method_33716).collect(Collectors.joining("_or_"));
    }

    public static String getConversionRecipeName(class_1935 result, class_1856 ingredient) {
        return getConversionRecipeName(result, Arrays.stream(ingredient.method_8105())
                .map(class_1799::method_7909)
                .toArray(class_1935[]::new));
    }

    public static String getConversionRecipeName(class_1935 result, class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return method_33716(result) + "_from_" + getItemName(items);
    }

    public static String getHasName(class_1856 ingredient) {
        return getHasName(Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    public static String getHasName(class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return "has_" + getItemName(items);
    }

    public static class_175<class_2066.class_2068> has(class_1856 ingredient) {
        return has(Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    public static class_175<class_2066.class_2068> has(class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return method_10423(class_2073.class_2074.method_8973().method_8977(items).method_8976());
    }

    public static void stonecutterResultFromBase(class_8790 recipeOutput, class_7800 category, class_1935 result, class_1856 material) {
        stonecutterResultFromBase(recipeOutput, category, result, material, 1);
    }

    public static void stonecutterResultFromBase(class_8790 recipeOutput, class_7800 category, class_1935 result, class_1856 material, int resultCount) {
        class_3981.method_17969(material, category, result, resultCount).method_17970(getHasName(material),
                has(material)
        ).method_36443(recipeOutput, getConversionRecipeName(result, material) + "_stonecutting");
    }

    @Override
    public CompletableFuture<?> method_56888(class_7403 output, class_7225.class_7874 registries) {
        List<CompletableFuture<?>> completableFutures = new ArrayList<>();
        this.method_10419(new IdentifiableRecipeOutput(output, registries, completableFutures));
        return CompletableFuture.allOf(completableFutures.toArray(CompletableFuture[]::new));
    }

    @Override
    public final void method_10419(class_8790 recipeOutput) {
        this.addRecipes(recipeOutput);
    }

    public abstract void addRecipes(class_8790 recipeOutput);

    public class IdentifiableRecipeOutput implements class_8790 {
        private final class_7403 output;
        private final class_7225.class_7874 registries;
        private final List<CompletableFuture<?>> completableFutures;
        private final Set<class_2960> generatedRecipes = new HashSet<>();

        public IdentifiableRecipeOutput(class_7403 output, class_7225.class_7874 registries, List<CompletableFuture<?>> completableFutures) {
            this.output = output;
            this.registries = registries;
            this.completableFutures = completableFutures;
        }

        public String getModId() {
            return AbstractRecipeProvider.this.modId;
        }

        @Override
        public void method_53819(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement) {
            final class_2960 oldLocation = location;
            // relocate all recipes to the mod id, so they do not depend on the item namespace which would
            // place e.g. new recipes for vanilla items in 'minecraft' which is not desired
            location = ResourceLocationHelper.fromNamespaceAndPath(AbstractRecipeProvider.this.modId,
                    location.method_12832()
            );
            if (!this.generatedRecipes.add(location)) {
                throw new IllegalStateException("Duplicate recipe " + location);
            } else {
                this.completableFutures.add(class_2405.method_53496(this.output, this.registries, class_1860.field_47319, recipe,
                        AbstractRecipeProvider.this.field_39378.method_44107(location)
                ));
                if (advancement != null) {
                    class_6903<JsonElement> registryOps = this.registries.method_57093(JsonOps.INSTANCE);
                    JsonElement jsonElement = class_161.field_47179.encodeStart(registryOps, advancement.comp_1920())
                            .getOrThrow();
                    jsonElement = searchAndReplaceValue(jsonElement, oldLocation, location);
                    class_2960 advancementLocation = ResourceLocationHelper.fromNamespaceAndPath(
                            AbstractRecipeProvider.this.modId, advancement.comp_1919().method_12832());
                    this.completableFutures.add(class_2405.method_10320(this.output, jsonElement,
                            AbstractRecipeProvider.this.field_39379.method_44107(advancementLocation)
                    ));
                }
            }
        }

        @SuppressWarnings("removal")
        @Override
        public class_161.class_162 method_53818() {
            return class_161.class_162.method_51698().method_708(class_5797.field_39377);
        }
    }
}
