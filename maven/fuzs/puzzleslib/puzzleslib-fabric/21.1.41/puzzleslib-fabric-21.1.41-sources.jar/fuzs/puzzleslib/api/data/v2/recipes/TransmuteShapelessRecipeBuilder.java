package fuzs.puzzleslib.api.data.v2.recipes;

import fuzs.puzzleslib.impl.item.CustomTransmuteRecipe;
import fuzs.puzzleslib.impl.item.TransmuteShapelessRecipe;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_1935;
import net.minecraft.class_2450;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import net.minecraft.class_8790;

public class TransmuteShapelessRecipeBuilder extends class_2450 {
    private final class_1865<?> recipeSerializer;
    private class_1856 input;

    public TransmuteShapelessRecipeBuilder(class_1865<?> recipeSerializer, class_7800 recipeCategory, class_1799 result) {
        super(recipeCategory, result.method_7909(), result.method_7947());
        this.recipeSerializer = recipeSerializer;
    }

    public static TransmuteShapelessRecipeBuilder shapeless(class_1865<?> recipeSerializer, class_7800 category, class_1935 result) {
        return shapeless(recipeSerializer, category, result, 1);
    }

    public static TransmuteShapelessRecipeBuilder shapeless(class_1865<?> recipeSerializer, class_7800 category, class_1935 result, int count) {
        return new TransmuteShapelessRecipeBuilder(recipeSerializer,
                category,
                result.method_8389().method_7854().method_46651(count));
    }

    public static class_1865<?> getRecipeSerializer(String modId) {
        return CustomTransmuteRecipe.getModSerializer(modId,
                CustomTransmuteRecipe.TRANSMUTE_SHAPELESS_RECIPE_SERIALIZER_ID);
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_10446(class_6862<class_1792> tag) {
        super.method_10446(tag);
        return this;
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_10454(class_1935 item) {
        super.method_10454(item);
        return this;
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_10449(class_1935 item, int quantity) {
        super.method_10449(item, quantity);
        return this;
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_10451(class_1856 ingredient) {
        super.method_10451(ingredient);
        return this;
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_10453(class_1856 ingredient, int quantity) {
        super.method_10453(ingredient, quantity);
        return this;
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_33530(String criterionName, class_175<?> criterionTrigger) {
        super.method_10442(criterionName, criterionTrigger);
        return this;
    }

    @Override
    public TransmuteShapelessRecipeBuilder method_33529(@Nullable String groupName) {
        super.method_10452(groupName);
        return this;
    }

    public TransmuteShapelessRecipeBuilder input(class_1935 input) {
        return this.input(class_1856.method_8091(input));
    }

    public TransmuteShapelessRecipeBuilder input(class_1856 input) {
        Objects.requireNonNull(input, "input is null");
        this.input = input;
        return this;
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_2960 resourceLocation) {
        Objects.requireNonNull(this.input, "input is null");
        super.method_17972(new TransformingRecipeOutput(recipeOutput, (class_1860<?> recipe) -> {
            return new TransmuteShapelessRecipe(TransmuteShapelessRecipeBuilder.this.recipeSerializer,
                    (class_1867) recipe,
                    TransmuteShapelessRecipeBuilder.this.input);
        }), resourceLocation);
    }
}
