package fuzs.puzzleslib.api.client.renderer.v1;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_3611;
import net.minecraft.class_4696;

/**
 * A helper class containing render type related methods.
 */
public final class RenderTypeHelper {

    private RenderTypeHelper() {
        // NO-OP
    }

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for a block.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is returned.
     *
     * @param block the block to get the render type for
     * @return the render type
     */
    public static class_1921 getRenderType(class_2248 block) {
        return class_4696.method_23679(block.method_9564());
    }

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for a fluid.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is returned.
     *
     * @param fluid the fluid to get the render type for
     * @return the render type
     */
    public static class_1921 getRenderType(class_3611 fluid) {
        return class_4696.method_23680(fluid.method_15785());
    }

    /**
     * Allows for registering a {@link class_1921} for a block.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is used.
     *
     * @param block      the block to register the render type for
     * @param renderType the render type
     */
    public static void registerRenderType(class_2248 block, class_1921 renderType) {
        ClientProxyImpl.get().registerRenderType(block, renderType);
    }

    /**
     * Allows for registering a {@link class_1921} for a fluid.
     * <p>
     * When no render type is registered, {@link class_1921#method_23577()} is used.
     *
     * @param fluid      the fluid to register the render type for
     * @param renderType the render type
     */
    public static void registerRenderType(class_3611 fluid, class_1921 renderType) {
        ClientProxyImpl.get().registerRenderType(fluid, renderType);
    }
}
