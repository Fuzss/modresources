package fuzs.puzzleslib.impl.client.core.proxy;

import fuzs.puzzleslib.api.chat.v1.ComponentHelper;
import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.gui.v2.components.tooltip.ClientComponentSplitter;
import fuzs.puzzleslib.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.impl.client.init.ItemDisplayOverridesImpl;
import fuzs.puzzleslib.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_1255;
import net.minecraft.class_1293;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3611;
import net.minecraft.class_3738;
import net.minecraft.class_437;
import net.minecraft.class_4719;
import net.minecraft.class_5455;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_634;
import net.minecraft.class_777;
import net.minecraft.class_8000;

public interface ClientProxyImpl extends ProxyImpl {

    static ClientProxyImpl get() {
        return (ClientProxyImpl) ProxyImpl.INSTANCE;
    }

    ModConstructorImpl<ClientModConstructor> getClientModConstructorImpl();

    ItemDisplayOverridesImpl<?> getItemModelDisplayOverrides();

    KeyMappingHelper getKeyMappingActivationHelper();

    boolean isKeyActiveAndMatches(class_304 keyMapping, int keyCode, int scanCode);

    class_5684 createImageComponent(class_5632 imageComponent);

    boolean onRenderTooltip(class_332 guiGraphics, class_327 font, int mouseX, int mouseY, List<class_5684> components, class_8000 positioner);

    class_777 copyBakedQuad(class_777 bakedQuad);

    boolean isEffectVisibleInInventory(class_1293 mobEffect);

    boolean isEffectVisibleInGui(class_1293 mobEffect);

    void registerWoodType(class_4719 woodType);

    class_1087 getBakedModel(class_1092 modelManager, class_2960 resourceLocation);

    void registerRenderType(class_2248 block, class_1921 renderType);

    void registerRenderType(class_3611 fluid, class_1921 renderType);

    int getGuiLeftHeight(class_329 gui);

    int getGuiRightHeight(class_329 gui);

    void addGuiLeftHeight(class_329 gui, int leftHeight);

    void addGuiRightHeight(class_329 gui, int rightHeight);

    @Override
    default class_1255<? super class_3738> getBlockableEventLoop(class_1937 level) {
        if (level.method_8608()) {
            return class_310.method_1551();
        } else {
            return ProxyImpl.super.getBlockableEventLoop(level);
        }
    }

    @Override
    default class_5455 getRegistryAccess() {
        return class_310.method_1551().method_1562() != null ?
                class_310.method_1551().method_1562().method_29091() : null;
    }

    @Override
    default class_1657 getClientPlayer() {
        return class_310.method_1551().field_1724;
    }

    @Override
    default class_1937 getClientLevel() {
        return class_310.method_1551().field_1687;
    }

    @Override
    default class_634 getClientPacketListener() {
        class_634 connection = class_310.method_1551().method_1562();
        Objects.requireNonNull(connection, "client packet listener is null");
        return connection;
    }

    @Override
    default boolean hasControlDown() {
        return class_437.method_25441();
    }

    @Override
    default boolean hasShiftDown() {
        return class_437.method_25442();
    }

    @Override
    default boolean hasAltDown() {
        return class_437.method_25443();
    }

    @Override
    default List<class_2561> splitTooltipLines(class_2561 component) {
        return ClientComponentSplitter.splitTooltipLines(component).map(ComponentHelper::toComponent).toList();
    }
}
