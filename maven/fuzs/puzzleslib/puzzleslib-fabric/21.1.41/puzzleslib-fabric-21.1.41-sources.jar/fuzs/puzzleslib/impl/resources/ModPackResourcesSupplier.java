package fuzs.puzzleslib.impl.resources;

import fuzs.puzzleslib.api.resources.v1.AbstractModPackResources;
import java.util.Optional;
import net.minecraft.class_155;
import net.minecraft.class_2561;
import net.minecraft.class_3262;
import net.minecraft.class_3264;
import net.minecraft.class_3272;
import net.minecraft.class_3288;
import net.minecraft.class_7662;
import net.minecraft.class_9224;

public record ModPackResourcesSupplier(class_3264 packType,
                                       class_9224 info,
                                       PackResourcesSupplier<AbstractModPackResources> supplier,
                                       class_7662 metadata) implements class_3288.class_7680 {

    public static ModPackResourcesSupplier create(class_3264 packType, class_9224 info, PackResourcesSupplier<AbstractModPackResources> supplier, class_2561 description) {
        class_3272 metadataSection = new class_3272(description,
                class_155.method_16673().method_48017(packType),
                Optional.empty()
        );
        return new ModPackResourcesSupplier(packType,
                info,
                supplier,
                class_7662.method_45174(class_3272.field_14202, metadataSection)
        );
    }

    @Override
    public class_3262 method_52424(class_9224 info) {
        return this.getAndSetupPackResources();
    }

    @Override
    public class_3262 method_52425(class_9224 info, class_3288.class_7679 packMetadata) {
        return this.getAndSetupPackResources();
    }

    private AbstractModPackResources getAndSetupPackResources() {
        return this.supplier.apply(this.packType, this.info, this.metadata);
    }

    @FunctionalInterface
    public interface PackResourcesSupplier<T extends class_3262> {

        T apply(class_3264 packType, class_9224 info, class_7662 metadata);
    }
}
