package fuzs.puzzleslib.impl.attachment;

import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

public interface AttachmentTypeAdapter<T, V> {

    class_2960 id();

    boolean hasData(T holder);

    @Nullable V getData(T holder);

    @Nullable V setData(T holder, V value);

    @Nullable V removeData(T holder);
}
