package fuzs.puzzleslib.impl.item;

import java.util.function.Supplier;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_6862;

public record TierImpl(class_6862<class_2248> incorrectBlocksForDrops,
                       int itemDurability,
                       float miningSpeed,
                       float attackDamage,
                       int enchantmentValue,
                       Supplier<class_1856> repairIngredient) implements class_1832 {

    @Override
    public int method_8025() {
        return this.itemDurability;
    }

    @Override
    public float method_8027() {
        return this.miningSpeed;
    }

    @Override
    public float method_8028() {
        return this.attackDamage;
    }

    @Override
    public class_6862<class_2248> method_58419() {
        return this.incorrectBlocksForDrops;
    }

    @Override
    public int method_8026() {
        return this.enchantmentValue;
    }

    @Override
    public class_1856 method_8023() {
        return this.repairIngredient.get();
    }
}
