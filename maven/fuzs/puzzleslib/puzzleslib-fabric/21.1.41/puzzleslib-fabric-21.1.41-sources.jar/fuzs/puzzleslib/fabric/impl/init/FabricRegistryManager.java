package fuzs.puzzleslib.fabric.impl.init;

import com.mojang.brigadier.arguments.ArgumentType;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.init.v3.registry.ExtendedMenuSupplier;
import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.api.init.v3.registry.MenuSupplierWithData;
import fuzs.puzzleslib.api.network.v3.codec.ExtraStreamCodecs;
import fuzs.puzzleslib.impl.init.DirectReferenceHolder;
import fuzs.puzzleslib.impl.init.LazyHolder;
import fuzs.puzzleslib.impl.init.RegistryManagerImpl;
import net.fabricmc.fabric.api.command.v2.ArgumentTypeRegistry;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.object.builder.v1.world.poi.PointOfInterestHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1703;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2314;
import net.minecraft.class_2378;
import net.minecraft.class_2385;
import net.minecraft.class_2680;
import net.minecraft.class_2941;
import net.minecraft.class_2943;
import net.minecraft.class_3917;
import net.minecraft.class_4158;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

public final class FabricRegistryManager extends RegistryManagerImpl {
    private boolean isFrozen;

    public FabricRegistryManager(String modId) {
        super(modId);
    }

    @Override
    public <T> class_6880.class_6883<T> registerLazily(class_5321<? extends class_2378<? super T>> registryKey, String path) {
        this.isWritableOrThrow();
        class_2378<T> registry = LookupHelper.getRegistry(registryKey).orElseThrow();
        class_5321<T> resourceKey = this.makeResourceKey(registryKey, path);
        return new LazyHolder<>(registryKey, resourceKey, () -> {
            class_6880.class_6883<T> holder = registry.method_40290(resourceKey);
            if (!holder.method_40227()) {
                T value = registry.method_29107(resourceKey);
                Objects.requireNonNull(value, "value is null");
                holder.method_45918(value);
            }

            return holder;
        });
    }

    @Override
    protected <T> class_6880.class_6883<T> getHolderReference(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration) {
        T value = supplier.get();
        Objects.requireNonNull(value, "value is null");
        class_2378<T> registry = LookupHelper.getRegistry(registryKey).orElseThrow();
        class_6880.class_6883<T> holder;
        if (skipRegistration) {
            holder = registry.method_40290(this.makeResourceKey(registryKey, path));
        } else {
            holder = class_2378.method_47985(registry, this.makeKey(path), value);
        }

        // bind the value immediately, so we can use it
        // Fabric Api should already do this for us, but better safe than sorry ¯\_(ツ)_/¯
        if (!holder.method_40227()) {
            holder.method_45918(value);
        }

        return holder;
    }

    @Override
    protected class_1761.class_7913 getCreativeModeTabBuilder(boolean withSearchBar) {
        return FabricItemGroup.builder();
    }

    @Override
    public class_6880.class_6883<class_1792> registerLegacySpawnEggItem(class_6880<? extends class_1299<? extends class_1308>> entityTypeReference, int backgroundColor, int highlightColor) {
        return this.registerItem(entityTypeReference.method_40230().orElseThrow().method_29177().method_12832() + "_spawn_egg",
                (class_1792.class_1793 itemProperties) -> new class_1826(entityTypeReference.comp_349(),
                        backgroundColor,
                        highlightColor,
                        itemProperties));
    }

    @Override
    public <T extends class_1703, S> class_6880.class_6883<class_3917<T>> registerMenuType(String path, MenuSupplierWithData<T, S> menuSupplier, class_9139<? super class_9129, S> streamCodec) {
        return this.register((class_5321<class_2378<class_3917<T>>>) (class_5321<?>) class_7924.field_41207,
                path,
                () -> new ExtendedScreenHandlerType<>(menuSupplier::create, streamCodec));
    }

    @SuppressWarnings("unchecked")
    @Override
    public <T extends class_1703> class_6880.class_6883<class_3917<T>> registerExtendedMenuType(String path, Supplier<ExtendedMenuSupplier<T>> entry) {
        return this.register((class_5321<class_2378<class_3917<T>>>) (class_5321<?>) class_7924.field_41207,
                path,
                () -> new ExtendedScreenHandlerType<>(entry.get()::create,
                        ExtraStreamCodecs.REGISTRY_FRIENDLY_BYTE_BUF));
    }

    @Override
    public class_6880.class_6883<class_4158> registerPoiType(String path, int maxTickets, int validRange, Supplier<Set<class_2680>> matchingBlockStates) {
        return this.register(class_7924.field_41212,
                path,
                () -> PointOfInterestHelper.register(this.makeKey(path),
                        maxTickets,
                        validRange,
                        matchingBlockStates.get()),
                true);
    }

    @Override
    public <A extends ArgumentType<?>, T extends class_2314.class_7217<A>> class_6880.class_6883<class_2314<?, ?>> registerArgumentType(String path, Class<? extends A> argumentClass, class_2314<A, T> argumentTypeInfo) {
        return this.register(class_7924.field_41262, path, () -> {
            ArgumentTypeRegistry.registerArgumentType(this.makeKey(path), argumentClass, argumentTypeInfo);
            return argumentTypeInfo;
        }, true);
    }

    @Override
    public <T> class_6880.class_6883<class_2941<T>> registerEntityDataSerializer(String path, Supplier<class_2941<T>> entry) {
        class_5321<class_2378<class_2941<?>>> registryKey = class_5321.method_29180(
                ResourceLocationHelper.withDefaultNamespace("entity_data_serializers"));
        class_2941<T> serializer = entry.get();
        class_2943.method_12720(serializer);
        return new DirectReferenceHolder<>(this.makeResourceKey(registryKey, path), serializer);
    }

    @Override
    public <T> void prepareTag(class_5321<? extends class_2378<? super T>> registryKey, class_6862<T> tagKey) {
        this.isWritableOrThrow();
        Objects.requireNonNull(registryKey, "registry key is null");
        Objects.requireNonNull(tagKey, "tag key is null");
        class_2378<T> registry = LookupHelper.getRegistry(registryKey).orElseThrow();
        ((class_2385<T>) registry).method_46769().method_46735(tagKey);
    }

    @Override
    public void freeze() {
        this.isWritableOrThrow();
        this.isFrozen = true;
    }

    @Override
    public boolean isFrozen() {
        return this.isFrozen;
    }
}
