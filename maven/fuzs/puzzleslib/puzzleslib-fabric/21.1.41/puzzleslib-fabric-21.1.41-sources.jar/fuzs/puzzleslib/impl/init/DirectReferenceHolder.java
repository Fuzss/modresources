package fuzs.puzzleslib.impl.init;

import java.util.Objects;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7876;

public final class DirectReferenceHolder<T> extends class_6880.class_6883<T> {

    public DirectReferenceHolder(class_5321<T> key, T value) {
        super(class_6884.field_36454, null, key, value);
        Objects.requireNonNull(key, "key is null");
        Objects.requireNonNull(value, "value is null");
    }

    @Override
    public boolean method_46745(class_7876<T> owner) {
        return true;
    }

    @Override
    public void method_45918(T value) {
        throw new UnsupportedOperationException();
    }
}
