package fuzs.puzzleslib.impl.client.init;

import com.google.common.base.Function;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Sets;
import fuzs.puzzleslib.api.client.init.v1.ItemModelDisplayOverrides;
import java.util.*;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import net.minecraft.class_811;

public abstract class ItemDisplayOverridesImpl<T> implements ItemModelDisplayOverrides {
    private final Map<class_1091, Map<class_811, Function<BakedModelResolver, class_1087>>> overrideLocations = new HashMap<>();

    protected ItemDisplayOverridesImpl() {
        this.registerEventHandlers();
    }

    @Override
    public void register(class_1091 itemModel, class_1091 itemModelOverride) {
        this.register(itemModel, itemModelOverride, getVanillaItemModelDisplayOverrides());
    }

    @Override
    public void register(class_1091 itemModel, class_2960 itemModelOverride) {
        this.register(itemModel, itemModelOverride, getVanillaItemModelDisplayOverrides());
    }

    static class_811[] getVanillaItemModelDisplayOverrides() {
        return EnumSet.complementOf(Sets.newEnumSet(
                Arrays.asList(class_811.field_4317, class_811.field_4318, class_811.field_4319),
                class_811.class
        )).toArray(class_811[]::new);
    }

    protected void register(class_1091 modelResourceLocation, Function<BakedModelResolver, class_1087> bakedModelGetter, class_811[] itemDisplayContexts) {
        Objects.requireNonNull(modelResourceLocation, "item model is null");
        Preconditions.checkState(itemDisplayContexts.length > 0, "item display contexts is empty");
        Map<class_811, Function<BakedModelResolver, class_1087>> overrides = this.overrideLocations.computeIfAbsent(
                modelResourceLocation, $ -> new EnumMap<>(class_811.class));
        for (class_811 itemDisplayContext : itemDisplayContexts) {
            if (overrides.put(itemDisplayContext, bakedModelGetter) != null) {
                throw new IllegalStateException(
                        "Attempting to register duplicate item model display override for model %s and display context %s".formatted(
                                modelResourceLocation, itemDisplayContext));
            }
        }
    }

    protected Map<T, Map<class_811, class_1087>> computeOverrideModels(BakedModelResolver modelResolver, class_1087 missingModel) {
        ImmutableMap.Builder<T, Map<class_811, class_1087>> builder = ImmutableMap.builder();
        for (Map.Entry<class_1091, Map<class_811, Function<BakedModelResolver, class_1087>>> overrideEntry : this.overrideLocations.entrySet()) {
            class_1087 itemModel = modelResolver.getModel(overrideEntry.getKey());
            Preconditions.checkState(itemModel != missingModel, "item model is missing");
            ImmutableMap.Builder<class_811, class_1087> overrideBuilder = ImmutableMap.builder();
            for (Map.Entry<class_811, Function<BakedModelResolver, class_1087>> entry : overrideEntry.getValue()
                    .entrySet()) {
                class_1087 overrideModel = entry.getValue().apply(modelResolver);
                Preconditions.checkState(overrideModel != missingModel, "override model is missing");
                overrideBuilder.put(entry.getKey(), overrideModel);
            }
            T overrideModelKey = this.createOverrideModelKey(overrideEntry.getKey(), itemModel);
            builder.put(overrideModelKey, overrideBuilder.build());
        }
        return builder.build();
    }

    protected abstract T createOverrideModelKey(class_1091 modelResourceLocation, class_1087 itemModel);

    protected abstract void registerEventHandlers();

    protected interface BakedModelResolver {

        class_1087 getModel(class_1091 modelResourceLocation);

        class_1087 getModel(class_2960 resourceLocation);
    }
}
