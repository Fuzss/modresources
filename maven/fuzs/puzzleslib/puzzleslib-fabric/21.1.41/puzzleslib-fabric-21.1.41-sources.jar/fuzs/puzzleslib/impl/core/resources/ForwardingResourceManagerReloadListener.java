package fuzs.puzzleslib.impl.core.resources;

import fuzs.puzzleslib.impl.PuzzlesLib;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Supplier;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3695;
import net.minecraft.class_4013;

public class ForwardingResourceManagerReloadListener extends ForwardingReloadListener<class_4013> implements class_4013 {

    public ForwardingResourceManagerReloadListener(class_2960 identifier, Supplier<Collection<class_4013>> supplier) {
        super(identifier, supplier);
    }

    @Override
    public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
        return class_4013.super.method_25931(preparationBarrier,
                resourceManager,
                preparationsProfiler,
                reloadProfiler,
                backgroundExecutor,
                gameExecutor
        );
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        for (class_4013 reloadListener : this.reloadListeners()) {
            try {
                reloadListener.method_14491(resourceManager);
            } catch (Exception exception) {
                PuzzlesLib.LOGGER.error("Unable to reload listener {}", reloadListener.method_22322(), exception);
            }
        }
    }
}
