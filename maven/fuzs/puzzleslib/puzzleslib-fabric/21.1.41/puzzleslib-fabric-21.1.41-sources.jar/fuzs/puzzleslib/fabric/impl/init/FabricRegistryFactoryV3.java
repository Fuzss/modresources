package fuzs.puzzleslib.fabric.impl.init;

import fuzs.puzzleslib.api.init.v3.registry.RegistryFactory;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.minecraft.class_2378;
import net.minecraft.class_2385;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import java.util.Objects;

public final class FabricRegistryFactoryV3 implements RegistryFactory {

    @Override
    public <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, boolean synced) {
        Objects.requireNonNull(registryKey, "registry key is null");
        FabricRegistryBuilder<T, ? extends class_2378<T>> builder = FabricRegistryBuilder.createSimple(registryKey);
        if (synced) builder.attribute(RegistryAttribute.SYNCED);
        return builder.buildAndRegister();
    }

    @Override
    public <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, class_2960 defaultKey, boolean synced) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Objects.requireNonNull(defaultKey, "default key is null");
        FabricRegistryBuilder<T, ? extends class_2378<T>> builder = FabricRegistryBuilder.createDefaulted(registryKey,
                defaultKey
        );
        if (synced) builder.attribute(RegistryAttribute.SYNCED);
        return builder.buildAndRegister();
    }

    @Override
    public <T> class_2378<T> register(class_2378<T> registry) {
        return FabricRegistryBuilder.from((class_2385<T>) registry).buildAndRegister();
    }
}
