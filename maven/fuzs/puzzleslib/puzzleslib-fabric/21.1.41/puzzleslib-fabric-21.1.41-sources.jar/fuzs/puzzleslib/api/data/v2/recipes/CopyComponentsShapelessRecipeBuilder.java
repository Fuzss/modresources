package fuzs.puzzleslib.api.data.v2.recipes;

import fuzs.puzzleslib.api.data.v2.AbstractRecipeProvider;
import fuzs.puzzleslib.impl.item.CopyComponentsRecipe;
import fuzs.puzzleslib.impl.item.CopyComponentsShapelessRecipe;
import net.minecraft.class_161;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_1935;
import net.minecraft.class_2450;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import org.jetbrains.annotations.Nullable;

public class CopyComponentsShapelessRecipeBuilder extends class_2450 {
    private class_1856 copyFrom;

    public CopyComponentsShapelessRecipeBuilder(class_7800 recipeCategory, class_1935 result, int count) {
        super(recipeCategory, result, count);
    }

    public static CopyComponentsShapelessRecipeBuilder method_10447(class_7800 category, class_1935 result) {
        return method_10448(category, result, 1);
    }

    public static CopyComponentsShapelessRecipeBuilder method_10448(class_7800 category, class_1935 result, int count) {
        return new CopyComponentsShapelessRecipeBuilder(category, result, count);
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_10446(class_6862<class_1792> tag) {
        super.method_10446(tag);
        return this;
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_10454(class_1935 item) {
        super.method_10454(item);
        return this;
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_10449(class_1935 item, int quantity) {
        super.method_10449(item, quantity);
        return this;
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_10451(class_1856 ingredient) {
        super.method_10451(ingredient);
        return this;
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_10453(class_1856 ingredient, int quantity) {
        super.method_10453(ingredient, quantity);
        return this;
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_33530(String criterionName, class_175<?> criterionTrigger) {
        super.method_10442(criterionName, criterionTrigger);
        return this;
    }

    @Override
    public CopyComponentsShapelessRecipeBuilder method_33529(@Nullable String groupName) {
        super.method_10452(groupName);
        return this;
    }

    public CopyComponentsShapelessRecipeBuilder copyFrom(class_1935 copyFrom) {
        return this.copyFrom(class_1856.method_8091(copyFrom));
    }

    public CopyComponentsShapelessRecipeBuilder copyFrom(class_1856 copyFrom) {
        this.copyFrom = copyFrom;
        return this;
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_2960 id) {
        super.method_17972(new class_8790() {

            @Override
            public class_161.class_162 method_53818() {
                return recipeOutput.method_53818();
            }

            @Override
            public void method_53819(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement) {
                // some weird hack to get the proper mod id for the serializer
                String modId =
                        recipeOutput instanceof AbstractRecipeProvider.IdentifiableRecipeOutput identifiableRecipeOutput ?
                                identifiableRecipeOutput.getModId() : id.method_12836();
                class_1865<?> recipeSerializer = CopyComponentsRecipe.getModSerializer(modId,
                        CopyComponentsRecipe.SHAPELESS_RECIPE_SERIALIZER_ID
                );
                recipe = new CopyComponentsShapelessRecipe(recipeSerializer, (class_1867) recipe,
                        CopyComponentsShapelessRecipeBuilder.this.copyFrom
                );
                recipeOutput.method_53819(location, recipe, advancement);
            }
        }, id);
    }
}
