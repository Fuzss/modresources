package fuzs.puzzleslib.mixin.client;

import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_342.class)
abstract class EditBoxMixin extends class_339 {
    @Shadow
    @Final
    private class_327 font;
    @Shadow
    private String value;
    @Shadow
    private boolean bordered;
    @Shadow
    private int displayPos;
    @Shadow
    private int cursorPos;
    @Shadow
    private int highlightPos;
    @Unique
    private long puzzleslib$lastClickTime;
    @Unique
    private boolean puzzleslib$doubleClick;
    @Unique
    private int puzzleslib$doubleClickHighlightPos;
    @Unique
    private int puzzleslib$doubleClickCursorPos;

    public EditBoxMixin(int x, int y, int width, int height, class_2561 message) {
        super(x, y, width, height, message);
    }

    @Inject(method = "deleteText(I)V", at = @At("HEAD"), cancellable = true)
    protected void deleteText(int charCount, CallbackInfo callback) {
        // delete entire words or everything until edit box beginning / end based on held modifier key
        if (class_437.method_25441()) {
            if (charCount < 0) this.deleteChars(-this.cursorPos);
        } else if (class_437.method_25443()) {
            this.deleteWords(charCount);
        } else {
            this.deleteChars(charCount);
        }

        callback.cancel();
    }

    @Shadow
    public abstract void deleteWords(int num);

    @Shadow
    public abstract void deleteChars(int num);

    @Shadow
    public abstract int getWordPosition(int numWords);

    @Shadow
    protected abstract int getWordPosition(int numWords, int pos, boolean skipConsecutiveSpaces);

    @Inject(method = "getWordPosition(IIZ)I", at = @At("HEAD"), cancellable = true)
    protected void getWordPosition(int numWords, int pos, boolean skipConsecutiveSpaces, CallbackInfoReturnable<Integer> callback) {
        int i = pos;
        boolean backwards = numWords < 0;
        int skippedWords = Math.abs(numWords);

        for (int k = 0; k < skippedWords; ++k) {
            if (!backwards) {
                int l = this.value.length();
                while (skipConsecutiveSpaces && i == pos && i < l && !puzzleslib$isWordChar(this.value.charAt(i))) {
                    ++i;
                    pos++;
                }

                while (i < l && puzzleslib$isWordChar(this.value.charAt(i))) {
                    ++i;
                }
            } else {
                while (skipConsecutiveSpaces && i == pos && i > 0 && !puzzleslib$isWordChar(this.value.charAt(i - 1))) {
                    --i;
                    pos--;
                }

                while (i > 0 && puzzleslib$isWordChar(this.value.charAt(i - 1))) {
                    --i;
                }
            }
        }

        callback.setReturnValue(i);
    }

    @Unique
    private static boolean puzzleslib$isWordChar(char charAt) {
        // break skipping on more than just spaces, from Owo Lib, thanks!
        return charAt == '_' || Character.isAlphabetic(charAt) || Character.isDigit(charAt);
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    public void keyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> callback) {
        if (this.method_37303() && this.method_25370()) {
            if (keyCode == class_3675.field_31984) {
                // when text is selected and the cursor is moved without selecting new text,
                // make it jump to either the beginning or end of the selection
                boolean allowedToMoveRight = true;
                if (!class_437.method_25442() && this.highlightPos != this.cursorPos) {
                    this.setCursorPosition(Math.max(this.getCursorPosition(), this.highlightPos));
                    this.setHighlightPos(this.getCursorPosition());
                    allowedToMoveRight = false;
                }
                // select entire words or everything until edit box beginning / end based on held modifier key
                if (class_437.method_25441()) {
                    this.moveCursorToEnd(class_437.method_25442());
                } else if (class_437.method_25443()) {
                    this.moveCursorTo(this.getWordPosition(1), class_437.method_25442());
                } else if (allowedToMoveRight) {
                    this.moveCursor(1, class_437.method_25442());
                }

                callback.setReturnValue(true);
            } else if (keyCode == class_3675.field_31983) {
                // when text is selected and the cursor is moved without selecting new text,
                // make it jump to either the beginning or end of the selection
                boolean allowedToMoveLeft = true;
                if (!class_437.method_25442() && this.highlightPos != this.cursorPos) {
                    this.setCursorPosition(Math.min(this.getCursorPosition(), this.highlightPos));
                    this.setHighlightPos(this.getCursorPosition());
                    allowedToMoveLeft = false;
                }
                // select entire words or everything until edit box beginning / end based on held modifier key
                if (class_437.method_25441()) {
                    this.moveCursorToStart(class_437.method_25442());
                } else if (class_437.method_25443()) {
                    this.moveCursorTo(this.getWordPosition(-1), class_437.method_25442());
                } else if (allowedToMoveLeft) {
                    this.moveCursor(-1, class_437.method_25442());
                }

                callback.setReturnValue(true);
            }
        }
    }

    @Shadow
    public abstract void moveCursor(int delta, boolean select);

    @Shadow
    public abstract void moveCursorTo(int delta, boolean select);

    @Shadow
    public abstract void setCursorPosition(int pos);

    @Shadow
    public abstract void moveCursorToStart(boolean select);

    @Shadow
    public abstract void moveCursorToEnd(boolean select);

    @Shadow
    public abstract int getCursorPosition();

    @Shadow
    public abstract int getInnerWidth();

    @Shadow
    public abstract void setHighlightPos(int position);

    @Inject(method = "onClick", at = @At("TAIL"))
    public void onClick(double mouseX, double mouseY, CallbackInfo callback) {
        long millis = class_156.method_658();
        boolean tripleClick = this.puzzleslib$doubleClick;
        this.puzzleslib$doubleClick = millis - this.puzzleslib$lastClickTime < 250L;
        if (this.puzzleslib$doubleClick) {
            if (tripleClick) {
                // triple click to select all text in the edit box
                this.moveCursorToEnd(false);
                this.setHighlightPos(0);
            } else {
                // double click to select the clicked word
                // highlight positions is right selection boundary, cursor position is left selection boundary
                this.puzzleslib$doubleClickHighlightPos = this.getWordPosition(1, this.getCursorPosition(), false);
                this.moveCursorTo(this.puzzleslib$doubleClickHighlightPos, false);
                this.puzzleslib$doubleClickCursorPos = this.getWordPosition(-1, this.getCursorPosition(), false);
                this.moveCursorTo(this.puzzleslib$doubleClickCursorPos, true);
            }
        }

        this.puzzleslib$lastClickTime = millis;
    }

    @Override
    protected void method_25349(double mouseX, double mouseY, double dragX, double dragY) {
        int i = class_3532.method_15357(mouseX) - this.method_46426();
        if (this.bordered) {
            i -= 4;
        }

        String string = this.font.method_27523(this.value.substring(this.displayPos), this.getInnerWidth());
        int mousePosition = this.font.method_27523(string, i).length() + this.displayPos;

        if (this.puzzleslib$doubleClick) {
            // double click drag across text to select individual words
            // dragging outside the edit box will select everything until beginning / end
            if (this.method_25361(mouseX, mouseY)) {
                int rightBoundary = this.getWordPosition(1, mousePosition, false);
                this.moveCursorTo(Math.max(this.puzzleslib$doubleClickHighlightPos, rightBoundary), false);
                int leftBoundary = this.getWordPosition(-1, mousePosition, false);
                this.moveCursorTo(Math.min(this.puzzleslib$doubleClickCursorPos, leftBoundary), true);
            } else {
                if (mousePosition > this.puzzleslib$doubleClickHighlightPos) {
                    this.moveCursorToEnd(false);
                } else {
                    this.moveCursorTo(this.puzzleslib$doubleClickHighlightPos, false);
                }
                if (mousePosition < this.puzzleslib$doubleClickCursorPos) {
                    this.moveCursorToStart(true);
                } else {
                    this.moveCursorTo(this.puzzleslib$doubleClickCursorPos, true);
                }
            }
        } else {
            // drag across text to select individual letters
            // dragging outside the edit box will select everything until beginning / end
            if (this.method_25361(mouseX, mouseY)) {
                this.moveCursorTo(mousePosition, true);
            } else if (this.highlightPos < mousePosition) {
                this.moveCursorToEnd(true);
            } else {
                this.moveCursorToStart(true);
            }
        }
    }
}