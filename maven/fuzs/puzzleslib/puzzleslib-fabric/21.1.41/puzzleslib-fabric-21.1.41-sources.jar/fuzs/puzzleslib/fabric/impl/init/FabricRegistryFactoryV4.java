package fuzs.puzzleslib.fabric.impl.init;

import fuzs.puzzleslib.api.init.v4.registry.RegistryFactory;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public final class FabricRegistryFactoryV4 implements RegistryFactory {

    @Override
    public <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, @Nullable class_2960 defaultKey) {
        Objects.requireNonNull(registryKey, "registry key is null");
        FabricRegistryBuilder<T, ? extends class_2378<T>> builder;
        if (defaultKey != null) {
            builder = FabricRegistryBuilder.createDefaulted(registryKey, defaultKey);
        } else {
            builder = FabricRegistryBuilder.createSimple(registryKey);
        }

        return builder.buildAndRegister();
    }

    @Override
    public <T> class_2378<T> createSynced(class_5321<class_2378<T>> registryKey, @Nullable class_2960 defaultKey) {
        Objects.requireNonNull(registryKey, "registry key is null");
        FabricRegistryBuilder<T, ? extends class_2378<T>> builder;
        if (defaultKey != null) {
            builder = FabricRegistryBuilder.createDefaulted(registryKey, defaultKey);
        } else {
            builder = FabricRegistryBuilder.createSimple(registryKey);
        }

        return builder.attribute(RegistryAttribute.SYNCED).buildAndRegister();
    }
}
