package fuzs.puzzleslib.impl.core.proxy;

import fuzs.puzzleslib.api.core.v1.Proxy;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2596;
import net.minecraft.class_634;
import net.minecraft.class_8605;
import net.minecraft.class_8705;
import net.minecraft.class_8706;
import net.minecraft.class_8710;
import net.minecraft.class_8735;

public interface NetworkingProxy extends Proxy {

    boolean hasChannel(class_2547 packetListener, class_8710.class_9154<?> type);

    default class_634 getClientPacketListener() {
        throw new RuntimeException("Client connection accessed for wrong side!");
    }

    class_2535 getConnection(class_2547 packetListener);

    class_2596<class_8705> toClientboundPacket(class_8710 payload);

    class_2596<class_8706> toServerboundPacket(class_8710 payload);

    void finishConfigurationTask(class_8735 packetListener, class_8605.class_8606 type);
}
