package fuzs.puzzleslib.impl.attachment;

import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1937;
import net.minecraft.class_2818;

public interface DataAttachmentRegistryImpl {
    DataAttachmentRegistryImpl INSTANCE = ProxyImpl.get().getDataAttachmentRegistry();

    <A> DataAttachmentRegistry.EntityBuilder<A> getEntityTypeBuilder();

    <A> DataAttachmentRegistry.BlockEntityBuilder<A> getBlockEntityTypeBuilder();

    <A> DataAttachmentRegistry.Builder<class_2818, A> getLevelChunkBuilder();

    <A> DataAttachmentRegistry.Builder<class_1937, A> getLevelBuilder();
}
