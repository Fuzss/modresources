package fuzs.puzzleslib.impl.event.core;

import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import java.util.Objects;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;

public record EventPhaseImpl(class_2960 resourceLocation,
                             EventPhase parent,
                             Ordering ordering) implements EventPhase {

    @Override
    public void applyOrdering(class_2960 resourceLocation, BiConsumer<class_2960, class_2960> phaseOrderingConsumer) {
        Objects.requireNonNull(this.parent, "parent is null");
        Objects.requireNonNull(this.ordering, "ordering is null");
        this.ordering.apply(phaseOrderingConsumer, resourceLocation, this.parent.resourceLocation());
    }

    @Override
    public int getOrderingValue() {
        Objects.requireNonNull(this.ordering, "ordering is null");
        return this.ordering.value;
    }

    public enum Ordering {
        BEFORE(-1) {
            @Override
            public void apply(BiConsumer<class_2960, class_2960> consumer, class_2960 first, class_2960 second) {
                consumer.accept(first, second);
            }
        },
        AFTER(1) {
            @Override
            public void apply(BiConsumer<class_2960, class_2960> consumer, class_2960 first, class_2960 second) {
                consumer.accept(second, first);
            }
        };

        public final int value;

        Ordering(int value) {
            this.value = value;
        }

        public abstract void apply(BiConsumer<class_2960, class_2960> consumer, class_2960 first, class_2960 second);
    }
}
