package fuzs.puzzleslib.impl.capability;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.capability.v3.data.CapabilityComponent;
import fuzs.puzzleslib.api.capability.v3.data.CapabilityKey;
import org.jetbrains.annotations.NotNull;

import java.util.Map;
import java.util.Set;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_2960;

public final class GlobalCapabilityRegister {
    private static final Map<class_2960, CapabilityKey<?, ?>> REGISTER = Maps.newConcurrentMap();
    private static final Set<Class<?>> VALID_CAPABILITY_TYPES = Set.of(class_1297.class, class_2586.class, class_2818.class, class_1937.class);

    private GlobalCapabilityRegister() {

    }

    public static <T, C extends CapabilityComponent<T>> void register(CapabilityKey<T, C> capabilityKey) {
        if (REGISTER.put(capabilityKey.identifier(), capabilityKey) != null) {
            throw new IllegalStateException("Duplicate capability " + capabilityKey.identifier());
        }
    }

    @NotNull
    public static CapabilityKey<?, ?> get(class_2960 identifier) {
        CapabilityKey<?, ?> capabilityKey = REGISTER.get(identifier);
        if (capabilityKey != null) {
            return capabilityKey;
        } else {
            throw new IllegalStateException("No capability registered for identifier " + identifier);
        }
    }

    public static void testHolderType(Class<?> holderType) {
        if (!GlobalCapabilityRegister.VALID_CAPABILITY_TYPES.contains(holderType)) {
            throw new IllegalArgumentException(holderType.getName() + " is an invalid type");
        }
    }
}
