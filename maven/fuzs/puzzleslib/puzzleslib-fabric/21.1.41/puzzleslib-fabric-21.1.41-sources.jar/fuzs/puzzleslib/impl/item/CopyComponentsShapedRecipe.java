package fuzs.puzzleslib.impl.item;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_9694;

@Deprecated
public class CopyComponentsShapedRecipe extends class_1869 implements CopyComponentsRecipe {
    private final class_1865<?> recipeSerializer;
    private final class_1856 copyFrom;

    public CopyComponentsShapedRecipe(String modId, class_1869 shapedRecipe, class_1856 copyFrom) {
        this(CopyComponentsRecipe.getModSerializer(modId, CopyComponentsRecipe.SHAPED_RECIPE_SERIALIZER_ID),
                shapedRecipe,
                copyFrom);
    }

    public CopyComponentsShapedRecipe(class_1865<?> recipeSerializer, class_1869 shapedRecipe, class_1856 copyFrom) {
        super(shapedRecipe.method_8112(),
                shapedRecipe.method_45441(),
                shapedRecipe.field_47320,
                shapedRecipe.method_8110(class_5455.field_40585),
                shapedRecipe.method_49188());
        this.recipeSerializer = recipeSerializer;
        this.copyFrom = copyFrom;
    }

    @Override
    public class_1799 method_17727(class_9694 craftingInput, class_7225.class_7874 registries) {
        class_1799 itemStack = super.method_17727(craftingInput, registries);
        CopyComponentsRecipe.super.copyComponentsToResult(itemStack, craftingInput);
        return itemStack;
    }

    @Override
    public class_1865<?> method_8119() {
        return this.recipeSerializer;
    }

    @Override
    public class_1856 getComponentsSource() {
        return this.copyFrom;
    }
}
