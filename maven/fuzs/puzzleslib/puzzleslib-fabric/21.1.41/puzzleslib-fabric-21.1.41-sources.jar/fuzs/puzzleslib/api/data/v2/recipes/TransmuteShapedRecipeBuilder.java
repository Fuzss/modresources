package fuzs.puzzleslib.api.data.v2.recipes;

import fuzs.puzzleslib.impl.item.CustomTransmuteRecipe;
import fuzs.puzzleslib.impl.item.TransmuteShapedRecipe;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1935;
import net.minecraft.class_2447;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import net.minecraft.class_8790;

public class TransmuteShapedRecipeBuilder extends class_2447 {
    private final class_1865<?> recipeSerializer;
    private class_1856 input;

    public TransmuteShapedRecipeBuilder(class_1865<?> recipeSerializer, class_7800 recipeCategory, class_1799 result) {
        super(recipeCategory, result.method_7909(), result.method_7947());
        this.recipeSerializer = recipeSerializer;
    }

    public static TransmuteShapedRecipeBuilder shaped(class_1865<?> recipeSerializer, class_7800 category, class_1935 result) {
        return shaped(recipeSerializer, category, result, 1);
    }

    public static TransmuteShapedRecipeBuilder shaped(class_1865<?> recipeSerializer, class_7800 category, class_1935 result, int count) {
        return new TransmuteShapedRecipeBuilder(recipeSerializer, category,
                result.method_8389().method_7854().method_46651(count));
    }

    public static class_1865<?> getRecipeSerializer(String modId) {
        return CustomTransmuteRecipe.getModSerializer(modId,
                CustomTransmuteRecipe.TRANSMUTE_SHAPED_RECIPE_SERIALIZER_ID);
    }

    @Override
    public TransmuteShapedRecipeBuilder method_10433(Character symbol, class_6862<class_1792> tag) {
        super.method_10433(symbol, tag);
        return this;
    }

    @Override
    public TransmuteShapedRecipeBuilder method_10434(Character symbol, class_1935 item) {
        super.method_10434(symbol, item);
        return this;
    }

    @Override
    public TransmuteShapedRecipeBuilder method_10428(Character symbol, class_1856 ingredient) {
        super.method_10428(symbol, ingredient);
        return this;
    }

    @Override
    public TransmuteShapedRecipeBuilder method_10439(String pattern) {
        super.method_10439(pattern);
        return this;
    }

    @Override
    public TransmuteShapedRecipeBuilder method_33530(String criterionName, class_175<?> criterionTrigger) {
        super.method_10429(criterionName, criterionTrigger);
        return this;
    }

    @Override
    public TransmuteShapedRecipeBuilder method_10435(@Nullable String groupName) {
        super.method_10435(groupName);
        return this;
    }

    @Override
    public TransmuteShapedRecipeBuilder method_49380(boolean bl) {
        super.method_49380(bl);
        return this;
    }

    public TransmuteShapedRecipeBuilder input(class_1935 input) {
        return this.input(class_1856.method_8091(input));
    }

    public TransmuteShapedRecipeBuilder input(class_1856 input) {
        Objects.requireNonNull(input, "input is null");
        this.input = input;
        return this;
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_2960 resourceLocation) {
        Objects.requireNonNull(this.input, "input is null");
        super.method_17972(new TransformingRecipeOutput(recipeOutput, (class_1860<?> recipe) -> {
            return new TransmuteShapedRecipe(TransmuteShapedRecipeBuilder.this.recipeSerializer,
                    (class_1869) recipe,
                    TransmuteShapedRecipeBuilder.this.input);
        }), resourceLocation);
    }
}
