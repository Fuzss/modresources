package fuzs.puzzleslib.mixin.server;

import com.mojang.logging.LogUtils;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import java.util.Scanner;
import net.minecraft.class_1934;
import net.minecraft.class_3806;
import net.minecraft.class_3807;
import net.minecraft.class_3808;

@Mixin(class_3807.class)
abstract class DedicatedServerSettingsMixin {
    @Shadow
    private class_3806 properties;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void init(Path path, CallbackInfo callback) {
        if (!this.properties.field_16829.isEmpty()) return;
        Logger logger = LogUtils.getLogger();
        // will print the FileNotFoundException twice, but ¯\_(ツ)_/¯
        this.properties = new class_3806(class_3808.method_16727(path)) {

            class_3806 setProperties() {
                this.field_16848.put("online-mode", String.valueOf(false));
                this.field_16848.put("gamemode", class_1934.field_9220.method_8381());
                this.field_16848.put("enable-command-block", String.valueOf(true));
                this.field_16848.put("max-players", String.valueOf(4));
                this.field_16848.put("spawn-protection", String.valueOf(0));
                this.field_16848.put("view-distance", String.valueOf(16));
                Scanner scanner = new Scanner(System.in);
                while (true) {
                    logger.warn("Invalid server ip address!");
                    System.out.print("server-ip=");
                    String input = scanner.next();
                    // from https://www.oreilly.com/library/view/regular-expressions-cookbook/9780596802837/ch07s16.html
                    if (input.matches("^(?:[0-9]{1,3}\\.){3}[0-9]{1,3}$")) {
                        this.field_16848.put("server-ip", input);
                        break;
                    }
                }
                return new class_3806(this.field_16848);
            }
        }.setProperties();
    }
}
