package fuzs.puzzleslib.impl.core.proxy;

import fuzs.puzzleslib.api.core.v1.Proxy;
import fuzs.puzzleslib.api.util.v1.CommonHelper;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1255;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3738;
import net.minecraft.class_5455;

public interface SidedProxy extends Proxy {

    void registerAllLoadingHandlers();

    void registerAllEventHandlers();

    default class_1255<? super class_3738> getBlockableEventLoop(class_1937 level) {
        if (level instanceof class_3218 serverLevel) {
            return serverLevel.method_8503();
        } else {
            throw new RuntimeException("Blockable event loop accessed for the wrong physical side!");
        }
    }

    default class_5455 getRegistryAccess() {
        return CommonHelper.getMinecraftServer() != null ? CommonHelper.getMinecraftServer().method_30611() : null;
    }

    default class_1657 getClientPlayer() {
        throw new RuntimeException("Client player accessed for the wrong physical side!");
    }

    default class_1937 getClientLevel() {
        throw new RuntimeException("Client level accessed for the wrong physical side!");
    }

    default boolean hasControlDown() {
        return false;
    }

    default boolean hasShiftDown() {
        return false;
    }

    default boolean hasAltDown() {
        return false;
    }

    default List<class_2561> splitTooltipLines(class_2561 component) {
        return Collections.singletonList(component);
    }

    default void registerConfigurationScreen(String modId, String... otherModIds) {
        // NO-OP
    }
}
