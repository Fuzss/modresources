package fuzs.puzzleslib.impl.core.proxy;

import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

public interface EntityProxy {

    boolean canEquip(class_1799 itemStack, class_1304 equipmentSlot, class_1309 livingEntity);

    @Nullable class_3730 getMobSpawnReason(class_1308 mob);

    boolean isMobGriefingAllowed(class_3218 serverLevel, @Nullable class_1297 entity);

    class_1297 getPartEntityParent(class_1297 entity);

    boolean isFakePlayer(class_3222 serverPlayer);

    boolean isPiglinCurrency(class_1799 itemStack);
}
