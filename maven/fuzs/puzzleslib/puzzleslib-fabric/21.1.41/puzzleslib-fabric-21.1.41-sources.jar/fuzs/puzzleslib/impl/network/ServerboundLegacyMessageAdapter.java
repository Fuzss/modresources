package fuzs.puzzleslib.impl.network;

import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.ServerMessageListener;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.server.MinecraftServer;

public record ServerboundLegacyMessageAdapter<T extends MessageV2<T>>(T message) implements ServerboundMessage<T> {

    @Override
    public ServerMessageListener<T> getHandler() {
        return new ServerMessageListener<>() {

            @Override
            public void handle(T message, MinecraftServer server, class_3244 handler, class_3222 player, class_3218 level) {
                message.makeHandler().handle(message, player, server);
            }
        };
    }

    @Override
    public T unwrap() {
        return this.message;
    }
}
