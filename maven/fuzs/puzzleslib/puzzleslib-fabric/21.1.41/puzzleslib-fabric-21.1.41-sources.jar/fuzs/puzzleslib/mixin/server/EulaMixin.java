package fuzs.puzzleslib.mixin.server;

import net.minecraft.class_2981;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2981.class)
abstract class EulaMixin {

    @Inject(method = "readFile", at = @At("HEAD"), cancellable = true)
    private void readFile(CallbackInfoReturnable<Boolean> callback) {
        callback.setReturnValue(true);
    }
}
