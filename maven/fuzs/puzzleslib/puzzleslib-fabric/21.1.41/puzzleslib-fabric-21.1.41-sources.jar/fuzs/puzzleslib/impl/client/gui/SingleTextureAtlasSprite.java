package fuzs.puzzleslib.impl.client.gui;

import net.minecraft.class_1011;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_7368;
import net.minecraft.class_7764;
import net.minecraft.class_7771;

public final class SingleTextureAtlasSprite extends class_1058 {

    public SingleTextureAtlasSprite(class_2960 resourceLocation, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        this(resourceLocation, spriteWidth, spriteHeight, uOffset, vOffset, 256, 256);
    }

    public SingleTextureAtlasSprite(class_2960 resourceLocation, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int textureWidth, int textureHeight) {
        super(resourceLocation, new class_7764(resourceLocation, new class_7771(spriteWidth, spriteHeight),
                new class_1011(textureWidth, textureHeight, false), class_7368.field_38688
        ), textureWidth, textureHeight, uOffset, vOffset);
    }
}
