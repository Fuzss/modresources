package fuzs.puzzleslib.impl.network;

import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.api.network.v3.NetworkHandler;
import fuzs.puzzleslib.api.network.v3.PlayerSet;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import net.minecraft.class_2596;
import net.minecraft.class_8705;
import net.minecraft.class_8706;

public interface NetworkHandlerRegistry extends NetworkHandler {

    @Deprecated
    @Override
    <T> class_2596<class_8705> toClientboundPacket(ClientboundMessage<T> message);

    @Deprecated
    @Override
    <T> class_2596<class_8706> toServerboundPacket(ServerboundMessage<T> message);

    @Deprecated
    @Override
    <T> void sendMessage(PlayerSet playerSet, ClientboundMessage<T> message);

    @Deprecated
    @Override
    <T> void sendMessage(ServerboundMessage<T> message);
}
