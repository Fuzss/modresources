package fuzs.puzzleslib.impl.attachment.builder;

import com.google.common.base.Predicates;
import com.mojang.serialization.Codec;
import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import fuzs.puzzleslib.api.network.v3.PlayerSet;
import org.apache.commons.lang3.mutable.MutableBoolean;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_3222;
import net.minecraft.class_5455;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public abstract class DataAttachmentBuilder<T, A> implements DataAttachmentRegistry.Builder<T, A> {
    protected final Map<Predicate<T>, Function<class_5455, A>> defaultValues = new LinkedHashMap<>();
    @Nullable
    protected Codec<A> codec;
    @Nullable
    protected class_9139<? super class_9129, A> streamCodec;
    @Nullable
    private Function<T, PlayerSet> synchronizationTargets;

    @Override
    public DataAttachmentRegistry.Builder<T, A> defaultValue(Function<class_5455, A> defaultValueProvider) {
        Objects.requireNonNull(defaultValueProvider, "default value provider is null");
        this.defaultValues.put(Predicates.alwaysTrue(), defaultValueProvider);
        return this;
    }

    @Override
    public DataAttachmentRegistry.Builder<T, A> persistent(Codec<A> codec) {
        Objects.requireNonNull(codec, "codec is null");
        this.codec = codec;
        return this;
    }

    @Override
    public DataAttachmentRegistry.Builder<T, A> networkSynchronized(class_9139<? super class_9129, A> streamCodec, Function<T, PlayerSet> targetSelector) {
        Objects.requireNonNull(streamCodec, "stream codec is null");
        Objects.requireNonNull(targetSelector, "synchronization targets is null");
        this.streamCodec = streamCodec;
        this.synchronizationTargets = targetSelector;
        return this;
    }

    protected abstract class_5455 getRegistryAccess(T holder);

    protected boolean syncWith(T holder, class_3222 serverPlayer) {
        Objects.requireNonNull(this.synchronizationTargets, "synchronization targets is null");
        MutableBoolean mutableBoolean = new MutableBoolean();
        this.synchronizationTargets.apply(holder).apply((class_3222 serverPlayerX) -> {
            if (serverPlayer == serverPlayerX) {
                mutableBoolean.setTrue();
            }
        });
        return mutableBoolean.booleanValue();
    }
}
