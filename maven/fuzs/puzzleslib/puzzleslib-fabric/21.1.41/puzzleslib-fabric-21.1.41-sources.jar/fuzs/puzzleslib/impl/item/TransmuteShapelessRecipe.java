package fuzs.puzzleslib.impl.item;

import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1865;
import net.minecraft.class_1867;
import net.minecraft.class_5455;
import net.minecraft.class_7225;
import net.minecraft.class_9694;

public final class TransmuteShapelessRecipe extends class_1867 implements CustomTransmuteRecipe {
    private final class_1865<?> recipeSerializer;
    private final class_1856 input;

    public TransmuteShapelessRecipe(String modId, class_1867 shapelessRecipe, class_1856 input) {
        this(CustomTransmuteRecipe.getModSerializer(modId,
                CustomTransmuteRecipe.TRANSMUTE_SHAPELESS_RECIPE_SERIALIZER_ID), shapelessRecipe, input);
    }

    public TransmuteShapelessRecipe(class_1865<?> recipeSerializer, class_1867 shapelessRecipe, class_1856 input) {
        super(shapelessRecipe.method_8112(),
                shapelessRecipe.method_45441(),
                shapelessRecipe.method_8110(class_5455.field_40585),
                shapelessRecipe.method_8117());
        this.recipeSerializer = recipeSerializer;
        this.input = input;
    }

    @Override
    public class_1799 method_17729(class_9694 craftingInput, class_7225.class_7874 registries) {
        class_1799 itemStack = super.method_17729(craftingInput, registries);
        CustomTransmuteRecipe.super.transmuteInput(itemStack, craftingInput);
        return itemStack;
    }

    @Override
    public class_1865<class_1867> method_8119() {
        return (class_1865<class_1867>) this.recipeSerializer;
    }

    @Override
    public class_1856 getInput() {
        return this.input;
    }
}
