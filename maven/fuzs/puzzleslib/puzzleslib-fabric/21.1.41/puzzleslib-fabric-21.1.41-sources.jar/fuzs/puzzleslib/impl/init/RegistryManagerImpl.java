package fuzs.puzzleslib.impl.init;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.ModLoader;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.init.v3.registry.RegistryManager;
import fuzs.puzzleslib.api.util.v1.ARGB;
import fuzs.puzzleslib.api.util.v1.HSV;
import fuzs.puzzleslib.impl.core.Freezable;
import fuzs.puzzleslib.impl.item.CreativeModeTabHelper;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7924;

public abstract class RegistryManagerImpl implements RegistryManager, Freezable {
    protected final String modId;
    protected Set<ModLoader> allowedModLoaders = EnumSet.allOf(ModLoader.class);

    protected RegistryManagerImpl(String modId) {
        this.modId = modId;
        Preconditions.checkArgument(StringUtils.isNotEmpty(modId), "mod id is invalid");
    }

    @Override
    public class_2960 makeKey(String path) {
        Preconditions.checkArgument(StringUtils.isNotEmpty(path), "path is invalid");
        return class_2960.method_60655(this.modId, path);
    }

    @Override
    public RegistryManager whenOn(ModLoader... allowedModLoaders) {
        Preconditions.checkState(allowedModLoaders.length > 0, "mod loaders is empty");
        this.allowedModLoaders = EnumSet.copyOf(Arrays.asList(allowedModLoaders));
        return this;
    }

    @Override
    public final <T> class_6880.class_6883<T> register(final class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier) {
        this.isWritableOrThrow();
        return this.register(registryKey, path, supplier, false);
    }

    public final <T> class_6880.class_6883<T> register(final class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Preconditions.checkArgument(StringUtils.isNotEmpty(path), "path is invalid");
        Objects.requireNonNull(supplier, "supplier is null");
        class_6880.class_6883<T> holder;
        if (!this.allowedModLoaders.contains(ModLoaderEnvironment.INSTANCE.getModLoader())) {
            holder = this.registerLazily(registryKey, path);
        } else {
            holder = this.getHolderReference(registryKey, path, supplier, skipRegistration);
        }
        this.allowedModLoaders = EnumSet.allOf(ModLoader.class);
        Objects.requireNonNull(holder, "holder is null");
        return holder;
    }

    protected abstract <T> class_6880.class_6883<T> getHolderReference(class_5321<? extends class_2378<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration);

    @Override
    public class_6880.class_6883<class_1792> registerLegacySpawnEggItem(class_6880<? extends class_1299<? extends class_1308>> entityTypeHolder, int backgroundColor) {
        return this.registerLegacySpawnEggItem(entityTypeHolder,
                backgroundColor,
                this.generateSpawnEggHighlightColor(backgroundColor));
    }

    /**
     * @author ChatGPT
     */
    private int generateSpawnEggHighlightColor(int backgroundColor) {
        // Convert base color to HSB
        int hsv = HSV.rgbToHsv(ARGB.redFloat(backgroundColor),
                ARGB.greenFloat(backgroundColor),
                ARGB.blueFloat(backgroundColor));
        // Modify saturation and brightness
        float saturation = Math.min(1.0F, HSV.saturationFloat(hsv) * 1.2F);
        float value = Math.max(0.0F, HSV.valueFloat(hsv) * 0.75F);
        // Convert back to RGB
        return class_3532.method_15369(HSV.hueFloat(hsv), saturation, value);
    }

    @Override
    public class_6880.class_6883<class_1761> registerCreativeModeTab(String path, Supplier<class_1799> iconSupplier, class_1761.class_7914 displayItems, boolean withSearchBar) {
        return this.register(class_7924.field_44688, path, () -> {
            class_1761.class_7913 builder = this.getCreativeModeTabBuilder(withSearchBar);
            class_2960 resourceLocation = this.makeKey(path);
            builder.method_47321(CreativeModeTabHelper.getTitle(resourceLocation));
            builder.method_47320(iconSupplier);
            builder.method_47317(displayItems);
            return builder.method_47324();
        });
    }

    protected abstract class_1761.class_7913 getCreativeModeTabBuilder(boolean withSearchBar);
}
