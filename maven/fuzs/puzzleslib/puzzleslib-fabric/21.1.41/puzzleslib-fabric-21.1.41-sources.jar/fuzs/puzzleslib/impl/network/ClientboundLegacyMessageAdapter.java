package fuzs.puzzleslib.impl.network;

import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.ClientMessageListener;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_746;

public record ClientboundLegacyMessageAdapter<T extends MessageV2<T>>(T message) implements ClientboundMessage<T> {

    @Override
    public ClientMessageListener<T> getHandler() {
        return new ClientMessageListener<>() {

            @Override
            public void handle(T message, class_310 minecraft, class_634 handler, class_746 player, class_638 level) {
                message.makeHandler().handle(message, player, minecraft);
            }
        };
    }

    @Override
    public T unwrap() {
        return this.message;
    }
}
