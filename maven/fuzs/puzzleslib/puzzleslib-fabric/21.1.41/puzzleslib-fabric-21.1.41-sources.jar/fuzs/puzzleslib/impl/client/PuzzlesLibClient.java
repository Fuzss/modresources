package fuzs.puzzleslib.impl.client;

import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.event.v1.gui.AddToastCallback;
import fuzs.puzzleslib.api.client.event.v1.gui.ScreenEvents;
import fuzs.puzzleslib.api.client.event.v1.gui.ScreenMouseEvents;
import fuzs.puzzleslib.api.client.event.v1.gui.ScreenOpeningCallback;
import fuzs.puzzleslib.api.client.gui.v2.screen.ScreenSkipper;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1157;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_364;
import net.minecraft.class_3675;
import net.minecraft.class_368;
import net.minecraft.class_370;
import net.minecraft.class_374;
import net.minecraft.class_425;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_481;
import net.minecraft.class_5244;
import net.minecraft.class_525;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.class_8100;

public class PuzzlesLibClient implements ClientModConstructor {

    @Override
    public void onConstructMod() {
        setupDevelopmentEnvironment();
    }

    private static void setupDevelopmentEnvironment() {
        if (!ModLoaderEnvironment.INSTANCE.isDevelopmentEnvironmentWithoutDataGeneration(PuzzlesLib.MOD_ID)) return;
        if (ModLoaderEnvironment.INSTANCE.getModLoader().isForgeLike()) {
            setupGameOptions();
        }
        ScreenOpeningCallback.EVENT.register((@Nullable class_437 oldScreen, DefaultedValue<class_437> newScreen) -> {
            if (newScreen.get() instanceof class_442 screen) {
                screen.field_18222 = false;
            } else if (newScreen.get() instanceof class_525 screen) {
                screen.method_48657().method_48704(class_8100.class_4539.field_20626);
                screen.method_48657().method_48713(true);
            }
            return EventResult.PASS;
        });
        ScreenEvents.beforeInit(class_442.class)
                .register((class_310 minecraft, class_442 screen, int screenWidth, int screenHeight, List<class_339> widgets) -> {
                    if (minecraft.method_18506() instanceof class_425 loadingOverlay
                            && loadingOverlay.field_17771 != 0L) {
                        loadingOverlay.field_17771 = 0L;
                    }
                });
        AddToastCallback.EVENT.register((class_374 toastManager, class_368 toast) -> {
            if (toast instanceof class_370 systemToast
                    && systemToast.method_1989() == class_370.class_9037.field_47589) {
                // block the annoying unsecure server warning when joining a multiplayer server in offline mode
                return EventResult.INTERRUPT;
            } else if (toastManager.method_45076() == 0) {
                // prevent toast spam when unlocking all advancements at once
                return EventResult.INTERRUPT;
            } else {
                return EventResult.PASS;
            }
        });
        // skip experimental settings warning
        ScreenSkipper.create()
                .setTitleComponent("selectWorld.backupQuestion.experimental")
                .setButtonComponent("selectWorld.backupJoinSkipButton")
                .build();
        ScreenSkipper.create()
                .setTitleComponent("selectWorld.warning.experimental.title")
                .setButtonComponent(class_5244.field_24336)
                .build();
        // launch directly into the key binds screen from the controls button
        ScreenSkipper.create()
                .setTitleComponent("controls.title")
                .setButtonComponent("controls.keybinds")
                .setLastTitleComponent("options.title")
                .build();
        // required for EditBox mixin to work properly on all screens like ChatScreen
        ScreenMouseEvents.beforeMouseClick(class_437.class)
                .register((class_437 screen, double mouseX, double mouseY, int button) -> {
                    for (class_364 guiEventListener : screen.method_25396()) {
                        if (guiEventListener instanceof class_342 && guiEventListener.method_25402(mouseX,
                                mouseY,
                                button)) {
                            screen.method_25395(guiEventListener);
                            if (button == class_3675.field_32000) {
                                screen.method_25398(true);
                            }
                            return EventResult.INTERRUPT;
                        }
                    }
                    return EventResult.PASS;
                });
        ScreenMouseEvents.beforeMouseRelease(class_437.class)
                .register((class_437 screen, double mouseX, double mouseY, int button) -> {
                    screen.method_25398(false);
                    return screen.method_19355(mouseX, mouseY)
                            .filter(class_342.class::isInstance)
                            .filter((class_364 guiEventListener) -> {
                                return guiEventListener.method_25406(mouseX, mouseY, button);
                            })
                            .isPresent() ? EventResult.INTERRUPT : EventResult.PASS;
                });
        ScreenMouseEvents.beforeMouseDrag(class_437.class)
                .register((class_437 screen, double mouseX, double mouseY, int button, double dragX, double dragY) -> {
                    return screen.method_25399() instanceof class_342 && screen.method_25397()
                            && button == class_3675.field_32000 && screen.method_25399()
                            .method_25403(mouseX, mouseY, button, dragX, dragY) ? EventResult.INTERRUPT :
                            EventResult.PASS;
                });
    }

    private static void setupGameOptions() {
        class_310 minecraft = class_310.method_1551();
        // necessary to disable to prevent some options from accessing fields that have not yet been initialized
        boolean running = minecraft.field_1698;
        minecraft.field_1698 = false;
        initializeGameOptions(minecraft.field_1690);
        minecraft.field_1698 = running;
        // no need to save preemptively, we will just apply our settings again if necessary
    }

    public static void initializeGameOptions(class_315 options) {
        if (options.method_37294().exists()) return;
        options.method_42503().method_41748(16);
        options.method_42524().method_41748(60);
        options.method_53530().method_41748(false);
        options.field_1827 = true;
        options.field_1875 = class_1157.field_5653;
        options.field_26844 = true;
        options.field_28777 = true;
        options.method_47395().method_41748(true);
        options.method_42435().method_41748(false);
        options.method_42440().method_41748(false);
        options.method_42443().method_41748(true);
        options.method_42474().method_41748(8);
        options.field_41785 = false;
        options.field_21840 = true;
        options.method_48974().method_41748(0.0);
    }

    @Override
    public void onClientSetup() {
        if (ModLoaderEnvironment.INSTANCE.isDevelopmentEnvironmentWithoutDataGeneration(PuzzlesLib.MOD_ID)) {
            class_481.field_2896 = class_7923.field_44687.method_31140(class_7706.field_40200);
        }
    }
}
