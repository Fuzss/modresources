package fuzs.puzzleslib.mixin.client;

import fuzs.puzzleslib.impl.client.event.ModelLoadingHelper;
import net.minecraft.class_1088;
import net.minecraft.class_9824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(class_1088.class)
abstract class ModelBakeryMixin {

    @ModifyVariable(method = "<init>", at = @At(value = "STORE", ordinal = 0))
    public class_9824 init(class_9824 blockStateModelLoader) {
        ModelLoadingHelper.setModelLoader(blockStateModelLoader);
        return blockStateModelLoader;
    }
}
