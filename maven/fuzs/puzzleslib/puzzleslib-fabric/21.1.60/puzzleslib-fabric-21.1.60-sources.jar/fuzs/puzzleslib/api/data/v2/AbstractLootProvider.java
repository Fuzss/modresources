package fuzs.puzzleslib.api.data.v2;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Multimap;
import com.mojang.serialization.Lifecycle;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_156;
import net.minecraft.class_173;
import net.minecraft.class_176;
import net.minecraft.class_2248;
import net.minecraft.class_2348;
import net.minecraft.class_2378;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_39;
import net.minecraft.class_44;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_55;
import net.minecraft.class_58;
import net.minecraft.class_6673;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_77;
import net.minecraft.class_7701;
import net.minecraft.class_7784;
import net.minecraft.class_7788;
import net.minecraft.class_7789;
import net.minecraft.class_7791;
import net.minecraft.class_7871;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8564;
import net.minecraft.class_8942;
import net.minecraft.class_9248;
import net.minecraft.class_9317;
import net.minecraft.class_9334;
import net.minecraft.core.*;
import org.apache.commons.lang3.StringUtils;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class AbstractLootProvider {

    private AbstractLootProvider() {
        // NO-OP
    }

    public static abstract class Blocks extends class_7788 implements LootTableDataProvider {
        /**
         * @see #generateFor(BlockSetFamily, Map)
         */
        public static final Map<BlockSetVariant, BiConsumer<AbstractLootProvider.Blocks, class_2248>> VARIANT_PROVIDERS = ImmutableMap.<BlockSetVariant, BiConsumer<AbstractLootProvider.Blocks, class_2248>>builder()
                .put(BlockSetVariant.CHISELED, class_7788::method_46025)
                .put(BlockSetVariant.CRACKED, class_7788::method_46025)
                .put(BlockSetVariant.POLISHED, class_7788::method_46025)
                .put(BlockSetVariant.CUT, class_7788::method_46025)
                .put(BlockSetVariant.MOSAIC, class_7788::method_46025)
                .put(BlockSetVariant.STAIRS, class_7788::method_46025)
                .put(BlockSetVariant.SLAB, (AbstractLootProvider.Blocks provider, class_2248 block) -> {
                    provider.method_45994(block, provider::method_45980);
                })
                .put(BlockSetVariant.WALL, class_7788::method_46025)
                .put(BlockSetVariant.FENCE, class_7788::method_46025)
                .put(BlockSetVariant.FENCE_GATE, class_7788::method_46025)
                .put(BlockSetVariant.DOOR, (AbstractLootProvider.Blocks provider, class_2248 block) -> {
                    provider.method_45994(block, provider::method_46022);
                })
                .put(BlockSetVariant.TRAPDOOR, class_7788::method_46025)
                .put(BlockSetVariant.BUTTON, class_7788::method_46025)
                .put(BlockSetVariant.PRESSURE_PLATE, class_7788::method_46025)
                .put(BlockSetVariant.SIGN, class_7788::method_46025)
                .put(BlockSetVariant.HANGING_SIGN, class_7788::method_46025)
                .build();

        private final Set<class_5321<class_52>> skipValidation = new HashSet<>();
        private final class_7784.class_7489 pathProvider;
        private final CompletableFuture<class_7225.class_7874> registries;
        private final String modId;

        public Blocks(DataProviderContext context) {
            this(context.getModId(), context.getPackOutput(), context.getRegistries());
        }

        public Blocks(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
            // we set the correct lookup provider just before we run data generation, it is not available here yet
            super(Collections.emptySet(), class_7701.field_40180.method_45383(), class_5455.field_40585);
            this.pathProvider = packOutput.method_60917(class_7924.field_50079);
            this.registries = registries;
            this.modId = modId;
        }

        @Override
        public CompletableFuture<?> method_10319(class_7403 output) {
            return this.registries.thenApply((class_7225.class_7874 registries) -> {
                return super.field_51845 = registries;
            }).thenCompose((class_7225.class_7874 registries) -> {
                return this.run(output, registries);
            }).thenRun(() -> {
                super.field_51845 = class_5455.field_40585;
            });
        }

        @Override
        public String method_10321() {
            return "Block Loot Tables";
        }

        @Override
        public final void method_10379() {
            this.addLootTables();
        }

        public abstract void addLootTables();

        @Override
        public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> consumer) {
            this.method_10379();
            Set<class_5321<class_52>> lootTables = new HashSet<>();
            this.getRegistryEntries().forEach((class_6880.class_6883<class_2248> holder) -> {
                class_5321<class_52> resourceKey = holder.comp_349().method_26162();
                if (resourceKey != class_39.field_844 && lootTables.add(resourceKey)) {
                    class_52.class_53 builder = this.field_40610.remove(resourceKey);
                    if (builder != null) {
                        consumer.accept(resourceKey, builder);
                    } else if (!this.skipValidationFor(resourceKey)) {
                        throw new IllegalStateException("Missing loot table '%s' for '%s'".formatted(resourceKey,
                                holder.method_40237().method_29177()));
                    }
                }
            });
            if (!this.field_40610.isEmpty()) {
                throw new IllegalStateException("Created block loot tables for non-blocks: " + this.field_40610.keySet());
            }
        }

        @Override
        public class_7225.class_7874 registries() {
            Preconditions.checkState(super.field_51845 != class_5455.field_40585, "registry access is empty");
            return super.field_51845;
        }

        @Override
        public class_7784.class_7489 pathProvider() {
            return this.pathProvider;
        }

        @Override
        public class_176 paramSet() {
            return class_173.field_1172;
        }

        @Override
        public boolean skipValidationFor(class_5321<class_52> resourceKey) {
            return this.skipValidation.contains(resourceKey);
        }

        public void skipValidation(class_2960 resourceLocation) {
            this.skipValidation(class_5321.method_29179(class_7924.field_50079, resourceLocation));
        }

        public void skipValidation(class_5321<class_52> resourceKey) {
            this.skipValidation.add(resourceKey);
        }

        public void skipValidation(class_2248 block) {
            this.skipValidation(block.method_26162());
        }

        public void dropNothing(class_2248 block) {
            this.method_45988(block, method_45975());
        }

        public void dropNameable(class_2248 block) {
            this.method_45994(block, this::method_45996);
        }

        public class_52.class_53 createHeadDrop(class_2248 block) {
            // explosion condition is not applied on purpose; all vanilla heads are explosion-resistant
            return class_52.method_324()
                    .method_336(class_55.method_347()
                            .method_352(class_44.method_32448(1.0F))
                            .method_351(class_77.method_411(block)
                                    .method_438(class_9317.method_57637(class_9317.class_9319.field_49436)
                                            .method_58730(class_9334.field_49618)
                                            .method_58730(class_9334.field_49631)))
                            .method_354());
        }

        public final void generateFor(BlockSetFamily blockSetFamily) {
            this.generateFor(blockSetFamily, VARIANT_PROVIDERS);
        }

        public final void generateFor(BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<AbstractLootProvider.Blocks, class_2248>> variants) {
            blockSetFamily.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> block) -> {
                BiConsumer<AbstractLootProvider.Blocks, class_2248> provider = variants.get(variant);
                if (provider != null) {
                    provider.accept(this, block.comp_349());
                }
            });
        }

        protected Stream<class_6880.class_6883<class_2248>> getRegistryEntries() {
            return class_7923.field_41175.method_40270()
                    .filter(holder -> holder.method_40237().method_29177().method_12836().equals(this.modId));
        }
    }

    public abstract static class EntityTypes extends class_7789 implements LootTableDataProvider {
        private final Set<class_5321<class_52>> skipValidation = new HashSet<>();
        private final class_7784.class_7489 pathProvider;
        private final CompletableFuture<class_7225.class_7874> registries;
        private final String modId;

        public EntityTypes(DataProviderContext context) {
            this(context.getModId(), context.getPackOutput(), context.getRegistries());
        }

        public EntityTypes(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
            // we set the correct lookup provider just before we run data generation, it is not available here yet
            super(class_7701.field_40180.method_45383(), class_5455.field_40585);
            this.pathProvider = packOutput.method_60917(class_7924.field_50079);
            this.registries = registries;
            this.modId = modId;
        }

        @Override
        public CompletableFuture<?> method_10319(class_7403 output) {
            return this.registries.thenCompose((class_7225.class_7874 registries) -> {
                super.field_51846 = registries;
                return this.run(output, registries).thenRun(() -> {
                    super.field_51846 = class_5455.field_40585;
                });
            });
        }

        @Override
        public String method_10321() {
            return "Entity Type Loot Tables";
        }

        @Override
        public final void method_10400() {
            this.addLootTables();
        }

        public abstract void addLootTables();

        @Override
        public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> consumer) {
            this.method_10400();
            Set<class_5321<class_52>> lootTables = new HashSet<>();
            this.getRegistryEntries().forEach((class_6880.class_6883<class_1299<?>> holder) -> {
                class_1299<?> entityType = holder.comp_349();
                Map<class_5321<class_52>, class_52.class_53> map = this.field_40615.remove(entityType);
                if (this.method_46027(entityType)) {
                    class_5321<class_52> resourceKey = entityType.method_16351();
                    if (!resourceKey.equals(class_39.field_844) && !this.skipValidationFor(resourceKey) && (
                            map == null || !map.containsKey(resourceKey))) {
                        throw new IllegalStateException(String.format(Locale.ROOT,
                                "Missing loot table '%s' for '%s'",
                                resourceKey,
                                holder.method_40237().method_29177()));
                    }
                    if (map != null) {
                        map.forEach((resourceLocation, builder) -> {
                            if (!lootTables.add(resourceLocation)) {
                                throw new IllegalStateException(String.format(Locale.ROOT,
                                        "Duplicate loot table '%s' for '%s'",
                                        resourceLocation,
                                        holder.method_40237().method_29177()));
                            } else {
                                consumer.accept(resourceLocation, builder);
                            }
                        });
                    }
                } else if (map != null) {
                    throw new IllegalStateException(String.format(Locale.ROOT,
                            "Weird loot table(s) '%s' for '%s', not a LivingEntity so should not have loot",
                            map.keySet()
                                    .stream()
                                    .map(class_5321::method_29177)
                                    .map(class_2960::toString)
                                    .collect(Collectors.joining(",")),
                            holder.method_40237().method_29177()));
                }
            });
            if (!this.field_40615.isEmpty()) {
                throw new IllegalStateException(
                        "Created loot tables for entities not supported by data pack: " + this.field_40615.keySet());
            }
        }

        @Override
        public class_7225.class_7874 registries() {
            Preconditions.checkState(super.field_51846 != class_5455.field_40585, "registry access is empty");
            return super.field_51846;
        }

        @Override
        public class_7784.class_7489 pathProvider() {
            return this.pathProvider;
        }

        @Override
        public class_176 paramSet() {
            return class_173.field_1173;
        }

        @Override
        public boolean skipValidationFor(class_5321<class_52> resourceKey) {
            return this.skipValidation.contains(resourceKey);
        }

        public void skipValidation(class_2960 resourceLocation) {
            this.skipValidation(class_5321.method_29179(class_7924.field_50079, resourceLocation));
        }

        public void skipValidation(class_5321<class_52> resourceKey) {
            this.skipValidation.add(resourceKey);
        }

        public void skipValidation(class_1299<?> entityType) {
            this.skipValidation(entityType.method_16351());
        }

        protected boolean method_46027(class_1299<?> entityType) {
            return entityType.method_5891() != class_1311.field_17715;
        }

        protected Stream<class_6880.class_6883<class_1299<?>>> getRegistryEntries() {
            return class_7923.field_41177.method_40270()
                    .filter(holder -> holder.method_40237().method_29177().method_12836().equals(this.modId));
        }
    }

    public static abstract class Simple implements LootTableDataProvider {
        private final Map<class_5321<class_52>, class_52.class_53> tables = new HashMap<>();
        private final Set<class_5321<class_52>> skipValidation = new HashSet<>();
        private final class_176 paramSet;
        private final class_7784.class_7489 pathProvider;
        private final CompletableFuture<class_7225.class_7874> registries;
        private class_7225.class_7874 registryAccess;

        public Simple(class_176 paramSet, DataProviderContext context) {
            this(paramSet, context.getPackOutput(), context.getRegistries());
        }

        public Simple(class_176 paramSet, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
            this.paramSet = paramSet;
            this.pathProvider = packOutput.method_60917(class_7924.field_50079);
            this.registries = registries;
            this.registryAccess = class_5455.field_40585;
        }

        @Override
        public CompletableFuture<?> method_10319(class_7403 output) {
            return this.registries.thenCompose((class_7225.class_7874 registries) -> {
                this.registryAccess = registries;
                return this.run(output, registries).thenRun(() -> {
                    this.registryAccess = class_5455.field_40585;
                });
            });
        }

        @Override
        public String method_10321() {
            // multiple data providers cannot have the same name, so handle this like so
            return String.join(" ", StringUtils.splitByCharacterTypeCamelCase(this.getClass().getSimpleName()));
        }

        @Override
        public void method_10399(BiConsumer<class_5321<class_52>, class_52.class_53> exporter) {
            this.addLootTables();
            this.tables.forEach(exporter);
        }

        @Override
        public class_7225.class_7874 registries() {
            Preconditions.checkState(this.registryAccess != class_5455.field_40585, "registry access is empty");
            return this.registryAccess;
        }

        @Override
        public class_7784.class_7489 pathProvider() {
            return this.pathProvider;
        }

        @Override
        public class_176 paramSet() {
            return this.paramSet;
        }

        @Override
        public boolean skipValidationFor(class_5321<class_52> resourceKey) {
            return this.skipValidation.contains(resourceKey);
        }

        public void skipValidation(class_2960 resourceLocation) {
            this.skipValidation(class_5321.method_29179(class_7924.field_50079, resourceLocation));
        }

        public void skipValidation(class_5321<class_52> resourceKey) {
            this.skipValidation.add(resourceKey);
        }

        protected void add(class_5321<class_52> table, class_52.class_53 builder) {
            this.tables.put(table, builder);
        }

        public abstract void addLootTables();
    }

    public interface LootTableDataProvider extends class_2405, class_7791 {

        class_7225.class_7874 registries();

        class_7784.class_7489 pathProvider();

        class_176 paramSet();

        boolean skipValidationFor(class_5321<class_52> resourceKey);

        default CompletableFuture<?> run(class_7403 output, class_7225.class_7874 registries) {
            class_2348<class_52> registry = new class_2348<>("empty",
                    class_7924.field_50079,
                    Lifecycle.experimental(),
                    false);
            class_5321<class_52> defaultKey = class_5321.method_29179(class_7924.field_50079, registry.method_10137());
            registry.method_10272(defaultKey, class_52.field_948, class_9248.field_49136);
            Map<class_6673.class_6674, class_2960> seeds = new Object2ObjectOpenHashMap<>();
            this.method_10399((class_5321<class_52> resourceKey, class_52.class_53 builder) -> {
                class_2960 resourceLocation = resourceKey.method_29177();
                class_2960 oldResourceLocation = seeds.put(class_8564.method_52171(resourceLocation),
                        resourceLocation);
                if (oldResourceLocation != null) {
                    class_156.method_33559(
                            "Loot table random sequence seed collision on " + oldResourceLocation + " and "
                                    + resourceKey);
                }

                builder.method_51883(resourceLocation);
                class_52 lootTable = builder.method_334(this.paramSet()).method_338();
                registry.method_10272(resourceKey, lootTable, class_9248.field_49136);
            });

            registry.method_40276();
            this.validate(registry);

            return CompletableFuture.allOf(registry.method_29722()
                    .stream()
                    .filter((Map.Entry<class_5321<class_52>, class_52> entry) -> {
                        return entry.getKey() != defaultKey;
                    })
                    .map((Map.Entry<class_5321<class_52>, class_52> entry) -> {
                        class_5321<class_52> resourceKey = entry.getKey();
                        class_52 lootTable = entry.getValue();
                        Path path = this.pathProvider().method_44107(resourceKey.method_29177());
                        return class_2405.method_53496(output, registries, class_52.field_50021, lootTable, path);
                    })
                    .toArray(CompletableFuture[]::new));
        }

        default void validate(class_2378<class_52> registry) {
            class_8942.class_8943 collector = new class_8942.class_8943();
            class_7871.class_7872 registries = new class_5455.class_6891(List.of(registry)).method_40316()
                    .method_46758();
            class_58 validationContext = new class_58(collector,
                    class_173.field_1177,
                    registries);

            registry.method_40270().forEach((class_6880.class_6883<class_52> holder) -> {
                this.validate(holder, validationContext);
            });

            Multimap<String, String> multimap = collector.method_54948();
            if (!multimap.isEmpty()) {
                multimap.forEach((string, string2) -> {
                    field_40831.warn("Found validation problem in {}: {}", string, string2);
                });
                throw new IllegalStateException("Failed to validate loot tables, see logs");
            }
        }

        default void validate(class_6880.class_6883<class_52> holder, class_58 validationContext) {
            if (!this.skipValidationFor(holder.method_40237())) {
                holder.comp_349()
                        .method_330(validationContext.method_22568(holder.comp_349().method_322())
                                .method_51219("{" + holder.method_40237().method_29177() + "}", holder.method_40237()));
            }
        }
    }
}
