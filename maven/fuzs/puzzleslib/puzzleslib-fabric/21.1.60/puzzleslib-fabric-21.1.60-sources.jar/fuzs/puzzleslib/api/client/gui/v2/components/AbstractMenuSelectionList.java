package fuzs.puzzleslib.api.client.gui.v2.components;

import fuzs.puzzleslib.api.client.gui.v2.ScreenHelper;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_4265;
import net.minecraft.class_6379;

/**
 * A selection list implementation that can be used as part of a screen anywhere, without having to cover the whole
 * screen width.
 * <p>
 * Also, the scroll bar is mostly handled separately and is placed outside the bounds of the actual list.
 * <p>
 * There is no need to handle
 * {@link net.minecraft.class_350#method_44398(class_332, int, int, int, int,
 * int)} as that is already bypassed in {@link class_4265#method_25332(int)}.
 */
public abstract class AbstractMenuSelectionList<E extends class_4265.class_4266<E>> extends UpdatedContainerObjectSelectionList<E> {
    public static final class_2960 SCROLLER_SPRITE = class_2960.method_60656(
            "container/creative_inventory/scroller");
    public static final class_2960 SCROLLER_DISABLED_SPRITE = class_2960.method_60656(
            "container/creative_inventory/scroller_disabled");

    public AbstractMenuSelectionList(class_310 minecraft, int x, int y, int width, int height, int itemHeight) {
        super(minecraft, width, height, y, itemHeight);
        this.method_46421(x);
    }

    @Override
    public int addEntry(E entry) {
        return super.method_25321(entry);
    }

    @Override
    public int method_25322() {
        return this.method_25368();
    }

    @Override
    protected void extractScrollbar(class_332 guiGraphics, int mouseX, int mouseY) {
        class_2960 sprite = this.scrollable() ? SCROLLER_SPRITE : SCROLLER_DISABLED_SPRITE;
        guiGraphics.method_52706(sprite,
                this.scrollBarX(),
                this.scrollBarY(),
                this.scrollerWidth(),
                this.scrollerHeight());
    }

    @Override
    protected void method_57713(class_332 guiGraphics) {
        // NO-OP
    }

    @Override
    protected void method_57715(class_332 guiGraphics) {
        // NO-OP
    }

    @Override
    protected int contentHeight() {
        return super.contentHeight() - 4;
    }

    @Override
    public int scrollbarWidth() {
        return this.scrollerWidth();
    }

    public int scrollbarHeight() {
        return this.method_25364();
    }

    @Override
    protected int scrollerWidth() {
        return 12;
    }

    @Override
    protected int scrollerHeight() {
        return 15;
    }

    @Override
    public int scrollBarY() {
        if (!this.scrollable() || this.maxScrollAmount() == 0) {
            return this.method_46427();
        } else {
            double scrollScale = this.scrollAmount() / this.maxScrollAmount();
            return this.method_46427() + Math.max(0, (int) (scrollScale * (this.method_25364() - this.scrollerHeight())));
        }
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (this.updateScrolling(mouseX, mouseY, button) && this.field_22750) {
            this.setMouseButtonScrollAmount(mouseX, mouseY, button);
            return true;
        } else {
            return super.method_25402(mouseX, mouseY, button);
        }
    }

    @Override
    public boolean method_25403(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (this.field_22750) {
            this.setMouseButtonScrollAmount(mouseX, mouseY, button);
            return true;
        } else {
            return super.method_25403(mouseX, mouseY, button, dragX, dragY);
        }
    }

    protected void setMouseButtonScrollAmount(double mouseX, double mouseY, int button) {
        double scrollOffset =
                (mouseY - this.method_46427() - this.scrollerHeight() / 2.0) / (this.scrollbarHeight() - this.scrollerHeight());
        this.method_25307(class_3532.method_15350(scrollOffset, 0.0, 1.0) * this.maxScrollAmount());
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return super.method_25405(mouseX, mouseY) || this.isOverScrollbar(mouseX, mouseY);
    }

    @Override
    protected boolean isOverScrollbar(double mouseX, double mouseY) {
        return ScreenHelper.isHovering(this.scrollBarX(),
                this.method_46427(),
                this.scrollbarWidth(),
                this.scrollbarHeight(),
                mouseX,
                mouseY);
    }

    @Override
    public int method_25342() {
        return this.method_46426();
    }

    @Override
    public E method_25308(double mouseX, double mouseY) {
        // A workaround for getting around vanilla subtracting a height of 4.
        // This avoids having to copy the whole method.
        this.field_22748 -= 4;
        E entry = super.method_25308(mouseX, mouseY);
        this.field_22748 += 4;
        return entry;
    }

    @Override
    protected void method_44397(class_332 guiGraphics, int mouseX, int mouseY, float partialTick, int index, int left, int top, int width, int height) {
        // Add back height subtracted by vanilla for the item outline, which we have removed.
        super.method_44397(guiGraphics, mouseX, mouseY, partialTick, index, left, top, width, height + 4);
    }

    @Override
    protected int method_25337(int index) {
        return super.method_25337(index) - 4;
    }

    public static class Entry<E extends Entry<E>> extends class_4265.class_4266<E> {
        private final List<class_339> children = new ArrayList<>();

        public <T extends class_339> T addRenderableWidget(T widget) {
            this.children.add(widget);
            return widget;
        }

        @Override
        public void method_25343(class_332 guiGraphics, int index, int top, int left, int width, int height, int mouseX, int mouseY, boolean hovering, float partialTick) {
            for (class_339 widget : this.children) {
                widget.method_46419(top);
                widget.method_25394(guiGraphics, mouseX, mouseY, partialTick);
            }
        }

        @Override
        public List<? extends class_364> method_25396() {
            return this.children;
        }

        @Override
        public List<? extends class_6379> method_37025() {
            return this.children;
        }
    }
}
