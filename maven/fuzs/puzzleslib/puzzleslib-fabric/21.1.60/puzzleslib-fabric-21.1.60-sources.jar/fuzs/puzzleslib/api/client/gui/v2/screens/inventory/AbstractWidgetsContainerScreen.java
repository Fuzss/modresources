package fuzs.puzzleslib.api.client.gui.v2.screens.inventory;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_465;

/**
 * A custom {@link class_465} extension that fully supports adding
 * {@link net.minecraft.class_339} by adding back the missing super calls to
 * {@link net.minecraft.class_4069}.
 */
public abstract class AbstractWidgetsContainerScreen<T extends class_1703> extends class_465<T> {

    public AbstractWidgetsContainerScreen(T menu, class_1661 inventory, class_2561 title) {
        super(menu, inventory, title);
    }

    public AbstractWidgetsContainerScreen(T menu, class_1661 inventory, class_2561 title, int imageWidth, int imageHeight) {
        super(menu, inventory, title);
        this.field_2792 = imageWidth;
        this.field_2779 = imageHeight;
    }

    /**
     * @see net.minecraft.class_4069#method_25401(double, double, double,
     *         double)
     */
    @Override
    public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
        if (super.method_25401(mouseX, mouseY, scrollX, scrollY)) {
            return true;
        }

        return this.method_19355(mouseX, mouseY).filter((class_364 listener) -> {
            return listener.method_25401(mouseX, mouseY, scrollX, scrollY);
        }).isPresent();
    }
}
