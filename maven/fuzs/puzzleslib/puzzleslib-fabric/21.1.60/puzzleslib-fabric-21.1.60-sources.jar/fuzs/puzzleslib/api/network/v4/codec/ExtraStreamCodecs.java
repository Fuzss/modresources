package fuzs.puzzleslib.api.network.v4.codec;

import io.netty.buffer.ByteBuf;
import java.time.Instant;
import java.util.BitSet;
import java.util.Date;
import java.util.function.IntFunction;
import java.util.function.Supplier;
import java.util.function.ToIntFunction;
import net.minecraft.class_2248;
import net.minecraft.class_2540;
import net.minecraft.class_2680;
import net.minecraft.class_3902;
import net.minecraft.class_3965;
import net.minecraft.class_7995;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * A few additional more or less useful stream codecs.
 */
public final class ExtraStreamCodecs {
    /**
     * {@link Character} stream codec
     */
    public static final class_9139<ByteBuf, Character> CHAR = class_9139.method_56437((ByteBuf buf, Character character) -> {
        buf.writeChar(character);
    }, ByteBuf::readChar);
    /**
     * {@link Date} stream codec
     */
    public static final class_9139<class_2540, Date> DATE = class_9139.method_56437(class_2540::method_10796,
            class_2540::method_10802);
    /**
     * {@link Instant} stream codec
     */
    public static final class_9139<class_2540, Instant> INSTANT = class_9139.method_56437(class_2540::method_44115,
            class_2540::method_44118);
    /**
     * {@link class_3965} stream codec
     */
    public static final class_9139<class_2540, class_3965> BLOCK_HIT_RESULT = class_9139.method_56437(class_2540::method_17813,
            class_2540::method_17814);
    /**
     * {@link BitSet} stream codec
     */
    public static final class_9139<class_2540, BitSet> BIT_SET = class_9139.method_56437(class_2540::method_33557,
            class_2540::method_33558);
    /**
     * {@link class_2680} stream codec
     */
    public static final class_9139<ByteBuf, class_2680> BLOCK_STATE = class_9135.field_48550.method_56432(class_2248::method_9531,
            class_2248::method_9507);
    /**
     * {@link class_3902} stream codec
     */
    public static final class_9139<ByteBuf, class_3902> UNIT = class_9139.method_56431(class_3902.field_17274);

    private ExtraStreamCodecs() {
        // NO-OP
    }

    /**
     * Create an {@link Enum} stream codec.
     *
     * @param clazz the enum class
     * @param <E>   the enum type
     * @return the stream codec
     */
    public static <E extends Enum<E>> class_9139<ByteBuf, E> fromEnum(Class<E> clazz) {
        return fromEnum(clazz::getEnumConstants);
    }

    /**
     * Create an {@link Enum} stream codec.
     *
     * @param enumValues the enum values
     * @param <E>        the enum type
     * @return the stream codec
     */
    public static <E extends Enum<E>> class_9139<ByteBuf, E> fromEnum(Supplier<E[]> enumValues) {
        return fromEnumWithMapping(enumValues, E::ordinal);
    }

    /**
     * Create an {@link Enum} stream codec.
     *
     * @param enumValues  the enum values
     * @param keyFunction the numeric key extractor
     * @param <E>         the enum type
     * @return the stream codec
     */
    public static <E extends Enum<E>> class_9139<ByteBuf, E> fromEnumWithMapping(Supplier<E[]> enumValues, ToIntFunction<E> keyFunction) {
        E[] enums = enumValues.get();
        IntFunction<E> idMapper = class_7995.method_47914(keyFunction, enums, class_7995.class_7996.field_41664);
        return class_9135.method_56375(idMapper, keyFunction);
    }
}
