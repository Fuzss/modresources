package fuzs.puzzleslib.api.entity.v1;

import fuzs.puzzleslib.api.util.v1.CompoundTagHelper;
import java.util.Optional;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5425;
import net.minecraft.class_5455;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7225;

/**
 * Copied from Minecraft 26.2.
 */
public final class VariantUtils {
    public static final String TAG_VARIANT = "variant";

    private VariantUtils() {
        // NO-OP
    }

    public static <T> class_6880<T> getDefaultOrAny(class_5455 registryAccess, class_5321<T> key) {
        class_2378<T> registry = registryAccess.method_30530(key.method_58273());
        return registry.method_40264(key).or(registry::method_60385).orElseThrow();
    }

    public static <T> class_6880<T> getAny(class_5455 registryAccess, class_5321<? extends class_2378<T>> registryKey) {
        return registryAccess.method_30530(registryKey).method_60385().orElseThrow();
    }

    public static <T> void writeVariant(class_2487 output, class_6880<T> variant) {
        variant.method_40230()
                .ifPresent((class_5321<T> resourceKey) -> CompoundTagHelper.store(output,
                        TAG_VARIANT,
                        class_2960.field_25139,
                        resourceKey.method_29177()));
    }

    public static <T> Optional<class_6880<T>> readVariant(class_2487 input, class_5321<? extends class_2378<T>> registryKey, class_7225.class_7874 lookup) {
        return CompoundTagHelper.read(input, TAG_VARIANT, class_2960.field_25139)
                .map((class_2960 id) -> class_5321.method_29179(registryKey, id))
                .flatMap((class_5321<T> key) -> lookup.method_46762(key.method_58273()).method_46746(key));
    }

    public static <T> Optional<class_6880.class_6883<T>> selectVariantToSpawn(class_5425 serverLevel, class_5321<class_2378<T>> registryKey) {
        return serverLevel.method_30349().method_30530(registryKey).method_10240(serverLevel.method_8409());
    }

    public static <T> Optional<class_6880<T>> selectVariantToSpawn(class_5425 serverLevel, class_5321<class_2378<T>> registryKey, class_6862<T> tagKey) {
        return serverLevel.method_30349()
                .method_30530(registryKey)
                .method_56159(tagKey, serverLevel.method_8409());
    }
}
