package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_5455;

@FunctionalInterface
public interface ClientTagsUpdatedCallback {
    EventInvoker<ClientTagsUpdatedCallback> EVENT = EventInvoker.lookup(ClientTagsUpdatedCallback.class);

    /**
     * Fires on the client when tags have been updated; useful for reloading data that depends on them.
     *
     * @param registries the dynamic registries
     */
    void onClientTagsUpdated(class_5455 registries);
}
