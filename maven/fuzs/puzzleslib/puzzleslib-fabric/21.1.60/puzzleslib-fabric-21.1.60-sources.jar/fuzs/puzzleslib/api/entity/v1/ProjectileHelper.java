package fuzs.puzzleslib.api.entity.v1;

import java.util.function.Consumer;
import net.minecraft.class_1309;
import net.minecraft.class_1676;
import net.minecraft.class_1799;
import net.minecraft.class_3218;

/**
 * Copied from {@code Projectile} in Minecraft 26.2.
 */
public final class ProjectileHelper {

    private ProjectileHelper() {
        // NO-OP
    }

    public static <T extends class_1676> T spawnProjectileFromRotation(ProjectileFactory<T> creator, class_3218 serverLevel, class_1799 itemStack, class_1309 source, float yOffset, float pow, float uncertainty) {
        return spawnProjectile(creator.create(serverLevel, source, itemStack),
                serverLevel,
                itemStack,
                (T shotProjectile) -> {
                    shotProjectile.method_24919(source,
                            source.method_36455(),
                            source.method_36454(),
                            yOffset,
                            pow,
                            uncertainty);
                });
    }

    public static <T extends class_1676> T spawnProjectileUsingShoot(ProjectileFactory<T> creator, class_3218 serverLevel, class_1799 itemStack, class_1309 source, double targetX, double targetY, double targetZ, float pow, float uncertainty) {
        return spawnProjectile(creator.create(serverLevel, source, itemStack),
                serverLevel,
                itemStack,
                (T shotProjectile) -> {
                    shotProjectile.method_7485(targetX, targetY, targetZ, pow, uncertainty);
                });
    }

    public static <T extends class_1676> T spawnProjectileUsingShoot(T projectile, class_3218 serverLevel, class_1799 itemStack, double targetX, double targetY, double targetZ, float pow, float uncertainty) {
        return spawnProjectile(projectile, serverLevel, itemStack, (T shotProjectile) -> {
            shotProjectile.method_7485(targetX, targetY, targetZ, pow, uncertainty);
        });
    }

    public static <T extends class_1676> T spawnProjectile(T projectile, class_3218 serverLevel, class_1799 itemStack) {
        return spawnProjectile(projectile, serverLevel, itemStack, (T shotProjectile) -> {
            // NO-OP
        });
    }

    public static <T extends class_1676> T spawnProjectile(T projectile, class_3218 serverLevel, class_1799 itemStack, Consumer<T> shootFunction) {
        shootFunction.accept(projectile);
        serverLevel.method_8649(projectile);
//        projectile.applyOnProjectileSpawned(serverLevel, itemStack);
        return projectile;
    }

    @FunctionalInterface
    public interface ProjectileFactory<T extends class_1676> {
        T create(class_3218 level, class_1309 entity, class_1799 itemStack);
    }
}
