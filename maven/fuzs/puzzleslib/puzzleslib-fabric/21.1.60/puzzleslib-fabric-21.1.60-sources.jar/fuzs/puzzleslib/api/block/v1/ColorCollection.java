package fuzs.puzzleslib.api.block.v1;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableList.Builder;
import org.apache.commons.lang3.function.TriFunction;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1767;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_4970;

/**
 * Copied from Minecraft 26.2.
 */
public record ColorCollection<T>(T white,
                                 T orange,
                                 T magenta,
                                 T lightBlue,
                                 T yellow,
                                 T lime,
                                 T pink,
                                 T gray,
                                 T lightGray,
                                 T cyan,
                                 T purple,
                                 T blue,
                                 T brown,
                                 T green,
                                 T red,
                                 T black) {
    public static final ColorCollection<class_1767> VALUES = new ColorCollection<>(class_1767.field_7952,
            class_1767.field_7946,
            class_1767.field_7958,
            class_1767.field_7951,
            class_1767.field_7947,
            class_1767.field_7961,
            class_1767.field_7954,
            class_1767.field_7944,
            class_1767.field_7967,
            class_1767.field_7955,
            class_1767.field_7945,
            class_1767.field_7966,
            class_1767.field_7957,
            class_1767.field_7942,
            class_1767.field_7964,
            class_1767.field_7963);
    public static final ColorCollection<String> NAMES = VALUES.map(class_1767::method_7792);

    public static <T> ColorCollection<T> create(T value) {
        return new ColorCollection<>(value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value,
                value);
    }

    public static <B extends class_2248, Id> ColorCollection<class_2248> registerBlocks(ColorCollection<Id> ids, TriFunction<Id, Function<class_4970.class_2251, class_2248>, class_4970.class_2251, class_2248> register, BiFunction<class_1767, class_4970.class_2251, B> colorBlockFactory, Function<class_1767, class_4970.class_2251> propertiesSupplier) {
        return zipMap(VALUES,
                ids,
                (color, id) -> register.apply(id,
                        p -> colorBlockFactory.apply(color, p),
                        propertiesSupplier.apply(color)));
    }

    public static <Id> ColorCollection<class_1792> registerBlockItems(ColorCollection<Id> ids, ColorCollection<class_2248> blocks, TriFunction<Id, class_2248, class_1767, class_1792> itemFactory) {
        return zipMap(VALUES, ids, (color, id) -> itemFactory.apply(id, blocks.pick(color), color));
    }

    public static <Id> ColorCollection<class_1792> registerItems(ColorCollection<Id> ids, BiFunction<Id, class_1767, class_1792> itemFactory) {
        return zipMap(VALUES, ids, (color, id) -> itemFactory.apply(id, color));
    }

    public static ColorCollection<String> prefixWithColor(ColorCollection<String> ids) {
        return zipMap(NAMES, ids, (color, id) -> color + "_" + id);
    }

    public List<T> asList() {
        Builder<T> builder = ImmutableList.builderWithExpectedSize(16);
        this.forEach(builder::add);
        return builder.build();
    }

    public void forEach(Consumer<T> consumer) {
        consumer.accept(this.white);
        consumer.accept(this.orange);
        consumer.accept(this.magenta);
        consumer.accept(this.lightBlue);
        consumer.accept(this.yellow);
        consumer.accept(this.lime);
        consumer.accept(this.pink);
        consumer.accept(this.gray);
        consumer.accept(this.lightGray);
        consumer.accept(this.cyan);
        consumer.accept(this.purple);
        consumer.accept(this.blue);
        consumer.accept(this.brown);
        consumer.accept(this.green);
        consumer.accept(this.red);
        consumer.accept(this.black);
    }

    public T pick(class_1767 dyeColor) {
        return (T) (switch (dyeColor) {
            case field_7952 -> this.white;
            case field_7946 -> this.orange;
            case field_7958 -> this.magenta;
            case field_7951 -> this.lightBlue;
            case field_7947 -> this.yellow;
            case field_7961 -> this.lime;
            case field_7954 -> this.pink;
            case field_7944 -> this.gray;
            case field_7967 -> this.lightGray;
            case field_7955 -> this.cyan;
            case field_7945 -> this.purple;
            case field_7966 -> this.blue;
            case field_7957 -> this.brown;
            case field_7942 -> this.green;
            case field_7964 -> this.red;
            case field_7963 -> this.black;
        });
    }

    public <U> ColorCollection<U> map(Function<T, U> mapper) {
        return new ColorCollection<>(mapper.apply(this.white),
                mapper.apply(this.orange),
                mapper.apply(this.magenta),
                mapper.apply(this.lightBlue),
                mapper.apply(this.yellow),
                mapper.apply(this.lime),
                mapper.apply(this.pink),
                mapper.apply(this.gray),
                mapper.apply(this.lightGray),
                mapper.apply(this.cyan),
                mapper.apply(this.purple),
                mapper.apply(this.blue),
                mapper.apply(this.brown),
                mapper.apply(this.green),
                mapper.apply(this.red),
                mapper.apply(this.black));
    }

    public static <T, U> void zipApply(ColorCollection<T> first, ColorCollection<U> second, BiConsumer<T, U> consumer) {
        consumer.accept(first.white(), second.white());
        consumer.accept(first.orange(), second.orange());
        consumer.accept(first.magenta(), second.magenta());
        consumer.accept(first.lightBlue(), second.lightBlue());
        consumer.accept(first.yellow(), second.yellow());
        consumer.accept(first.lime(), second.lime());
        consumer.accept(first.pink(), second.pink());
        consumer.accept(first.gray(), second.gray());
        consumer.accept(first.lightGray(), second.lightGray());
        consumer.accept(first.cyan(), second.cyan());
        consumer.accept(first.purple(), second.purple());
        consumer.accept(first.blue(), second.blue());
        consumer.accept(first.brown(), second.brown());
        consumer.accept(first.green(), second.green());
        consumer.accept(first.red(), second.red());
        consumer.accept(first.black(), second.black());
    }

    public static <T, U, R> ColorCollection<R> zipMap(ColorCollection<T> first, ColorCollection<U> second, BiFunction<T, U, R> operation) {
        return new ColorCollection<>(operation.apply(first.white(), second.white()),
                operation.apply(first.orange(), second.orange()),
                operation.apply(first.magenta(), second.magenta()),
                operation.apply(first.lightBlue(), second.lightBlue()),
                operation.apply(first.yellow(), second.yellow()),
                operation.apply(first.lime(), second.lime()),
                operation.apply(first.pink(), second.pink()),
                operation.apply(first.gray(), second.gray()),
                operation.apply(first.lightGray(), second.lightGray()),
                operation.apply(first.cyan(), second.cyan()),
                operation.apply(first.purple(), second.purple()),
                operation.apply(first.blue(), second.blue()),
                operation.apply(first.brown(), second.brown()),
                operation.apply(first.green(), second.green()),
                operation.apply(first.red(), second.red()),
                operation.apply(first.black(), second.black()));
    }
}
