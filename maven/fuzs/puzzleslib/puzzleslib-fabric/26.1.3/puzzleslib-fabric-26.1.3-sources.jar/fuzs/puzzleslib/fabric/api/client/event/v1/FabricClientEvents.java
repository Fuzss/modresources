package fuzs.puzzleslib.fabric.api.client.event.v1;

import fuzs.puzzleslib.common.api.client.event.v1.ClientInputEvents;
import fuzs.puzzleslib.common.api.client.event.v1.gui.ChatMessageReceivedCallback;
import fuzs.puzzleslib.fabric.api.event.v1.core.FabricEventFactory;
import net.fabricmc.fabric.api.event.Event;

public final class FabricClientEvents {
    /**
     * Called before a mouse button is clicked or released without a screen being open.
     */
    public static final Event<ClientInputEvents.MouseClick> MOUSE_CLICK = FabricEventFactory.createResult(
            ClientInputEvents.MouseClick.class);
    /**
     * Called before a mouse has scrolled without a screen being open.
     */
    public static final Event<ClientInputEvents.MouseScroll> MOUSE_SCROLL = FabricEventFactory.createResult(
            ClientInputEvents.MouseScroll.class);
    /**
     * Called before a key press, release or repeat action is handled.
     */
    public static final Event<ClientInputEvents.KeyPress> KEY_PRESS = FabricEventFactory.createResult(ClientInputEvents.KeyPress.class);
    /**
     * Runs in {@link net.minecraft.client.multiplayer.chat.ChatListener} when a new chat message is about to be added
     * to the client chat. Allows for filtering out or adjusting received messages.
     */
    public static final Event<ChatMessageReceivedCallback> CHAT_MESSAGE_RECEIVED = FabricEventFactory.createResult(
            ChatMessageReceivedCallback.class);

    private FabricClientEvents() {
        // NO-OP
    }
}
