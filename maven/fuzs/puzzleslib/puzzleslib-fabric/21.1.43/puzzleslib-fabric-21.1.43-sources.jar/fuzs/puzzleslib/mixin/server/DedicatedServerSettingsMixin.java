package fuzs.puzzleslib.mixin.server;

import com.mojang.logging.LogUtils;
import fuzs.puzzleslib.impl.content.ServerPropertiesHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.nio.file.Path;
import net.minecraft.class_3806;
import net.minecraft.class_3807;

@Mixin(class_3807.class)
abstract class DedicatedServerSettingsMixin {
    @Shadow
    private class_3806 properties;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void init(Path path, CallbackInfo callback) {
        if (!this.properties.field_16829.isEmpty()) return;
        // will print the FileNotFoundException twice, but ¯\_(ツ)_/¯
        this.properties = ServerPropertiesHelper.createDedicatedServerProperties(path, LogUtils.getLogger());
    }
}
