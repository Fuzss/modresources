package fuzs.puzzleslib.mixin;

import com.google.common.collect.ImmutableList;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import fuzs.puzzleslib.impl.content.ItemDataAccessor;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_3164;

@Mixin(class_3164.class)
abstract class DataCommandsMixin {

    @ModifyExpressionValue(method = "<clinit>",
                           at = @At(value = "FIELD",
                                    target = "Lnet/minecraft/server/commands/data/DataCommands;ALL_PROVIDERS:Ljava/util/List;",
                                    opcode = Opcodes.GETSTATIC))
    private static List<Function<String, class_3164.class_3167>> clinit(List<Function<String, class_3164.class_3167>> allProviders) {
        return ImmutableList.<Function<String, class_3164.class_3167>>builder()
                .addAll(allProviders)
                .add(ItemDataAccessor.PROVIDER)
                .build();
    }
}
