package fuzs.puzzleslib.impl.content;

import fuzs.puzzleslib.api.core.v1.ModConstructor;
import fuzs.puzzleslib.api.init.v3.override.CommandOverrides;
import fuzs.puzzleslib.api.init.v3.override.GameRuleValueOverrides;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.objectweb.asm.Type;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import net.minecraft.class_1294;
import net.minecraft.class_1928;

public class PuzzlesLibDevelopment extends PuzzlesLib implements ModConstructor {

    @Override
    public void onConstructMod() {
        CommandOverrides.registerEventHandlers();
    }

    @Override
    public void onCommonSetup() {
        initializeGameRules();
        initializeCommands();
    }

    private static void initializeCommands() {
        CommandOverrides.registerServerCommand("time set 4000", false);
        CommandOverrides.registerPlayerCommand("op @s", true);
        CommandOverrides.registerEffectCommand(class_1294.field_5925);
        CommandOverrides.registerEffectCommand(class_1294.field_5907);
        CommandOverrides.registerEffectCommand(class_1294.field_5918);
        CommandOverrides.registerEffectCommand(class_1294.field_5910);
        CommandOverrides.registerEffectCommand(class_1294.field_5923);
    }

    private static void initializeGameRules() {
        GameRuleValueOverrides.setValue(class_1928.field_19396, false);
        GameRuleValueOverrides.setValue(class_1928.field_19406, false);
        GameRuleValueOverrides.setValue(class_1928.field_19389, true);
        GameRuleValueOverrides.setValue(class_1928.field_19387, false);
        GameRuleValueOverrides.setValue(class_1928.field_19388, false);
        GameRuleValueOverrides.setValue(class_1928.field_20637, false);
        GameRuleValueOverrides.setValue(class_1928.field_21831, false);
        GameRuleValueOverrides.setValue(class_1928.field_21832, false);
        GameRuleValueOverrides.setValue(class_1928.field_42474, false);
        GameRuleValueOverrides.setValue(class_1928.field_19405, 0);
        GameRuleValueOverrides.setValue(class_1928.field_46794, 1);
        GameRuleValueOverrides.setValue(class_1928.field_19394, false);
    }

    public static void printClazzComponentsWithoutAccess(Class<?> clazz) {
        for (Field field : clazz.getDeclaredFields()) {
            if (!Modifier.isPublic(field.getModifiers()) && !field.isSynthetic()) {
                LOGGER.info("transitive-accessible\tfield\t{}\t{}\t{}",
                        Type.getInternalName(field.getDeclaringClass()),
                        field.getName(),
                        Type.getDescriptor(field.getType()));
            }
        }

        for (Method method : clazz.getDeclaredMethods()) {
            if (!Modifier.isPublic(method.getModifiers()) && !method.isSynthetic()) {
                LOGGER.info("transitive-accessible\tmethod\t{}\t{}\t{}",
                        Type.getInternalName(method.getDeclaringClass()),
                        method.getName(),
                        Type.getMethodDescriptor(method));
            }
        }
    }
}
