package fuzs.puzzleslib.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Collection;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_637;

@Mixin(class_637.class)
abstract class ClientSuggestionProviderMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @ModifyReturnValue(method = "getSelectedEntities", at = @At("RETURN"))
    public Collection<String> getSelectedEntities(Collection<String> entities) {
        // include suggestions for nearby entities, if none is highlighted
        if (entities.isEmpty() && this.minecraft.field_1687 != null && this.minecraft.field_1724 != null) {
            return this.minecraft.field_1687.method_8333(this.minecraft.field_1724,
                    this.minecraft.field_1724.method_5829().method_1014(5.0),
                    class_1297::method_5863).stream().map(class_1297::method_5845).toList();
        } else {
            return entities;
        }
    }
}
