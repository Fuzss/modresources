package fuzs.puzzleslib.mixin;

import com.mojang.brigadier.CommandDispatcher;
import fuzs.puzzleslib.impl.content.CustomEnchantCommand;
import net.minecraft.class_2168;
import net.minecraft.class_3048;
import net.minecraft.class_7157;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3048.class)
abstract class EnchantCommandMixin {

    @Inject(method = "register", at = @At("HEAD"), cancellable = true)
    private static void register(CommandDispatcher<class_2168> dispatcher, class_7157 context, CallbackInfo callback) {
        CustomEnchantCommand.register(dispatcher, context);
        callback.cancel();
    }
}
