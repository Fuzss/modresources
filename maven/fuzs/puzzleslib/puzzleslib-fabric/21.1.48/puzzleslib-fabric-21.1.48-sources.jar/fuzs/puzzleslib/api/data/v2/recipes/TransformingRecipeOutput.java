package fuzs.puzzleslib.api.data.v2.recipes;

import org.jetbrains.annotations.Nullable;

import java.util.function.UnaryOperator;
import net.minecraft.class_161;
import net.minecraft.class_1860;
import net.minecraft.class_2960;
import net.minecraft.class_8779;
import net.minecraft.class_8790;

/**
 * Allows for using vanilla recipe builders with custom recipe implementations based on vanilla recipe types.
 */
public record TransformingRecipeOutput(class_8790 recipeOutput,
                                       UnaryOperator<class_1860<?>> operator) implements class_8790 {

    static class_8790 transformed(class_8790 recipeOutput, UnaryOperator<class_1860<?>> operator) {
        return new TransformingRecipeOutput(recipeOutput, operator);
    }

    @Override
    public void method_53819(class_2960 resourceLocation, class_1860<?> recipe, @Nullable class_8779 advancement) {
        this.recipeOutput.method_53819(resourceLocation, this.operator().apply(recipe), advancement);
    }

    @Override
    public class_161.class_162 method_53818() {
        return this.recipeOutput.method_53818();
    }
}
