package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.LayerDefinitionsContext;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import java.util.Objects;
import java.util.function.Supplier;

public final class LayerDefinitionsContextFabricImpl implements LayerDefinitionsContext {

    @Override
    public void registerLayerDefinition(class_5601 layerLocation, Supplier<class_5607> supplier) {
        Objects.requireNonNull(layerLocation, "layer location is null");
        Objects.requireNonNull(supplier, "layer supplier is null");
        EntityModelLayerRegistry.registerModelLayer(layerLocation, supplier::get);
    }
}
