package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1303;
import net.minecraft.class_1657;

@FunctionalInterface
public interface PickupExperienceCallback {
    EventInvoker<PickupExperienceCallback> EVENT = EventInvoker.lookup(PickupExperienceCallback.class);

    /**
     * Called when a {@link class_1657} collides with an {@link class_1303} entity, just before it is added to the player.
     *
     * @param player the player colliding with the orb
     * @param orb    the orb that's being collided with
     * @return {@link EventResult#INTERRUPT} to prevent the player from collecting orbs, they will remain unchanged in the world,
     * {@link EventResult#PASS} to proceed with the player picking up the orbs
     */
    EventResult onPickupExperience(class_1657 player, class_1303 orb);
}
