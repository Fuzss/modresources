package fuzs.puzzleslib.api.core.v2;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_2960;
import net.minecraft.class_9139;

/**
 * Copied from Minecraft 26.1.
 */
public interface ClientAsset {
    class_2960 id();

    record DownloadedTexture(class_2960 texturePath, String url) implements Texture {
        @Override
        public class_2960 id() {
            return this.texturePath;
        }
    }

    record ResourceTexture(class_2960 id, class_2960 texturePath) implements Texture {
        public static final Codec<ResourceTexture> CODEC = class_2960.field_25139.xmap(ResourceTexture::new,
                ResourceTexture::id);
        public static final MapCodec<ResourceTexture> DEFAULT_FIELD_CODEC = CODEC.fieldOf("asset_id");
        public static final class_9139<ByteBuf, ResourceTexture> STREAM_CODEC = class_2960.field_48267.method_56432(
                ResourceTexture::new,
                ResourceTexture::id);

        public ResourceTexture(class_2960 texture) {
            this(texture, texture.method_45134(path -> "textures/" + path + ".png"));
        }
    }

    interface Texture extends ClientAsset {
        class_2960 texturePath();
    }
}
