package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.Function;
import net.minecraft.class_5632;
import net.minecraft.class_5684;

/**
 * register a client-side tooltip component factory
 */
@FunctionalInterface
public interface ClientTooltipComponentsContext {

    /**
     * register custom tooltip components
     *
     * @param type    common {@link class_5632} class
     * @param factory factory for creating {@link class_5684} from <code>type</code>
     * @param <T>     type of common component
     */
    <T extends class_5632> void registerClientTooltipComponent(Class<T> type, Function<? super T, ? extends class_5684> factory);
}
