package fuzs.puzzleslib.fabric.impl.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.context.CompostableBlocksContext;
import net.fabricmc.fabric.api.registry.CompostingChanceRegistry;
import net.minecraft.class_1935;
import net.minecraft.class_6880;
import java.util.Objects;

@Deprecated
public final class CompostableBlocksContextFabricImpl implements CompostableBlocksContext {

    @Override
    public void registerCompostable(float compostingChance, class_6880<? extends class_1935>... items) {
        Preconditions.checkArgument(compostingChance >= 0.0F && compostingChance <= 1.0F,
                "Value " + compostingChance + " outside of range [" + 0.0F + ":" + 1.0F + "]");
        Objects.requireNonNull(items, "items is null");
        Preconditions.checkState(items.length > 0, "items is empty");
        for (class_6880<? extends class_1935> item : items) {
            Objects.requireNonNull(item, "item is null");
            CompostingChanceRegistry.INSTANCE.add(item.comp_349(), compostingChance);
        }
    }
}
