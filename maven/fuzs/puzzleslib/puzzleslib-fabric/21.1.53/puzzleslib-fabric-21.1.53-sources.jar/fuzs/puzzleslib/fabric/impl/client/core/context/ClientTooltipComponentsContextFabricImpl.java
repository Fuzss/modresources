package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.ClientTooltipComponentsContext;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import java.util.Objects;
import java.util.function.Function;

public final class ClientTooltipComponentsContextFabricImpl implements ClientTooltipComponentsContext {

    @SuppressWarnings("unchecked")
    @Override
    public <T extends class_5632> void registerClientTooltipComponent(Class<T> type, Function<? super T, ? extends class_5684> factory) {
        Objects.requireNonNull(type, "tooltip component type is null");
        Objects.requireNonNull(factory, "tooltip component factory is null");
        TooltipComponentCallback.EVENT.register((class_5632 data) -> {
            if (data.getClass() == type) return factory.apply((T) data);
            return null;
        });
    }
}
