package fuzs.puzzleslib.api.event.v1.server;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import net.minecraft.class_2960;
import net.minecraft.class_3302;
import net.minecraft.class_5455;
import net.minecraft.class_7225;

@FunctionalInterface
public interface AddDataPackReloadListenersCallback {
    EventInvoker<AddDataPackReloadListenersCallback> EVENT = EventInvoker.lookup(
            AddDataPackReloadListenersCallback.class);

    /**
     * Adds a listener to the server resource manager (for data packs) to reload at the end of all resources.
     * <p>
     * Note that the {@link class_5455} instance is unable to create tags, instead use {@link class_7225.class_7874}
     * which does not have full access to registries though.
     *
     * @param consumer registers a reload listener with an id for debugging, common listener types include:
     *                 <ul>
     *                 <li>{@link net.minecraft.class_3302}</li>
     *                 <li>{@link net.minecraft.class_4013}</li>
     *                 <li>{@link net.minecraft.class_4080}</li>
     *                 </ul>
     */
    void onAddDataPackReloadListeners(BiConsumer<class_2960, BiFunction<class_7225.class_7874, class_5455, class_3302>> consumer);
}
