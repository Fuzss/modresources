package fuzs.puzzleslib.api.init.v3.registry;

import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_9129;

/**
 * A mod loader independent implementation of {@link net.minecraft.class_3917.class_3918}, allowing for
 * additional data being sent from the server in form of a {@link class_9129}.
 *
 * @param <T> type of menu
 */
@Deprecated
@FunctionalInterface
public interface ExtendedMenuSupplier<T extends class_1703> {

    /**
     * Creates the supplied container menu.
     *
     * @param containerId             menu id
     * @param inventory               player inventory
     * @param registryFriendlyByteBuf additional data to be sent to client
     * @return the container menu
     */
    T create(int containerId, class_1661 inventory, class_9129 registryFriendlyByteBuf);
}
