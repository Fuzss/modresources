package fuzs.puzzleslib.fabric.impl.data;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.data.v2.tags.AbstractTagAppender;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_3497;
import net.minecraft.class_5321;

public final class FabricTagAppenderV2<T> extends AbstractTagAppender<T> {
    private final List<class_3497> removeEntries = new ArrayList<>();

    public FabricTagAppenderV2(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        super(tagBuilder, keyExtractor);
    }

    @Override
    public AbstractTagAppender<T> remove(class_2960 resourceLocation) {
        // only fully supported on NeoForge
        this.removeEntries.add(class_3497.method_43937(resourceLocation));
        return this;
    }

    @Override
    public AbstractTagAppender<T> removeTag(class_2960 resourceLocation) {
        // only fully supported on NeoForge
        this.removeEntries.add(class_3497.method_43945(resourceLocation));
        return this;
    }

    @Override
    public List<String> asStringList() {
        ImmutableList.Builder<String> builder = ImmutableList.builder();
        for (class_3497 tagEntry : this.tagBuilder.method_26782()) {
            builder.add(tagEntry.toString());
        }
        for (class_3497 tagEntry : this.removeEntries) {
            builder.add("!" + tagEntry);
        }
        return builder.build();
    }
}
