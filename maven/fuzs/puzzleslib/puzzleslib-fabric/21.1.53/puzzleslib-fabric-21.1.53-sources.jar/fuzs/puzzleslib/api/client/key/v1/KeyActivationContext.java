package fuzs.puzzleslib.api.client.key.v1;

import net.minecraft.class_310;

/**
 * An activation context for key mappings, allowing to restrict key mappings in regard to a screen being open or not.
 */
public enum KeyActivationContext {
    /**
     * A key mapping that is always processed, no matter of whether a screen is open or not.
     */
    UNIVERSAL,
    /**
     * A key mapping that is processed when the game is running without a screen being open in
     * {@link net.minecraft.class_310#field_1755}.
     * <p>
     * These keys are usually processed in {@link class_310#method_1574()} and corresponding events.
     */
    GAME,
    /**
     * A key mapping that is processed when a screen is open in {@link class_310#field_1755}
     * <p>
     * These keys are usually processed in {@link net.minecraft.class_437#method_25404(int, int, int)} and
     * {@link net.minecraft.class_437#method_25402(double, double, int)}.
     */
    SCREEN;

    /**
     * @return is the activation context able to trigger the key binding
     */
    public boolean isActive() {
        return switch (this) {
            case UNIVERSAL -> true;
            case SCREEN -> class_310.method_1551().field_1755 != null;
            case GAME -> class_310.method_1551().field_1755 == null;
        };
    }

    /**
     * Tests if this activation context is incompatible with another one.
     *
     * @param other the other activation context
     * @return is the given activation context incompatible with this one
     */
    public boolean isConflictingWith(KeyActivationContext other) {
        return this == UNIVERSAL || other == UNIVERSAL || this == other;
    }
}
