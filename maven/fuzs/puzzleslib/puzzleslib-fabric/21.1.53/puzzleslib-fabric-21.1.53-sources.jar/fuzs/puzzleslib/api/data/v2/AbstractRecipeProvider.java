package fuzs.puzzleslib.api.data.v2;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.mojang.serialization.JsonOps;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_161;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1935;
import net.minecraft.class_2066;
import net.minecraft.class_2073;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2446;
import net.minecraft.class_2447;
import net.minecraft.class_2450;
import net.minecraft.class_2454;
import net.minecraft.class_2960;
import net.minecraft.class_3981;
import net.minecraft.class_5794;
import net.minecraft.class_5797;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_6903;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7701;
import net.minecraft.class_7784;
import net.minecraft.class_7800;
import net.minecraft.class_7923;
import net.minecraft.class_8074;
import net.minecraft.class_8779;
import net.minecraft.class_8790;
import net.minecraft.data.recipes.*;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

public abstract class AbstractRecipeProvider extends class_2446 {
    /**
     * @see #generateFor(class_8790, BlockSetFamily, Map)
     */
    public static final Map<BlockSetVariant, FamilyRecipeProvider> VARIANT_STONE_PROVIDERS = ImmutableMap.<BlockSetVariant, FamilyRecipeProvider>builder()
            .put(BlockSetVariant.CHISELED, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.CUT, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.SLAB, FamilyRecipeProvider.stonecutting(2))
            .put(BlockSetVariant.STAIRS, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.POLISHED, FamilyRecipeProvider.stonecutting())
            .put(BlockSetVariant.WALL, FamilyRecipeProvider.stonecutting())
            .build();

    protected final String modId;

    public AbstractRecipeProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractRecipeProvider(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> lookupProvider) {
        super(packOutput, lookupProvider);
        this.modId = modId;
    }

    @Nullable
    protected static <T> JsonElement searchAndReplaceValue(@Nullable JsonElement jsonElement, T searchFor, T replaceWith) {
        Objects.requireNonNull(searchFor, "search for is null");
        Objects.requireNonNull(replaceWith, "replace with is null");
        if (jsonElement != null && !jsonElement.isJsonNull()) {
            if (jsonElement.isJsonPrimitive()) {
                JsonPrimitive jsonPrimitive = jsonElement.getAsJsonPrimitive();
                if (jsonPrimitive.isNumber()) {
                    if (searchFor.equals(jsonPrimitive.getAsNumber())) {
                        return new JsonPrimitive((Number) replaceWith);
                    }
                } else if (jsonPrimitive.isBoolean()) {
                    if (searchFor.equals(jsonPrimitive.getAsBoolean())) {
                        return new JsonPrimitive((Boolean) replaceWith);
                    }
                } else if (jsonPrimitive.isString()) {
                    if (searchFor.toString().equals(jsonPrimitive.getAsString())) {
                        return new JsonPrimitive(replaceWith.toString());
                    }
                }
                return jsonElement;
            } else if (jsonElement.isJsonArray()) {
                JsonArray jsonArray = jsonElement.getAsJsonArray();
                for (int i = 0; i < jsonArray.size(); i++) {
                    jsonArray.set(i, searchAndReplaceValue(jsonArray.get(i), searchFor, replaceWith));
                }
            } else if (jsonElement.isJsonObject()) {
                JsonObject jsonObject = jsonElement.getAsJsonObject();
                for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                    entry.setValue(searchAndReplaceValue(entry.getValue(), searchFor, replaceWith));
                }
            }
        }
        return jsonElement;
    }

    /**
     * @see #generateFor(class_8790, BlockSetFamily, Map)
     */
    public static Map<BlockSetVariant, FamilyRecipeProvider> createVariantWoodProviders(BlockSetFamily blockSetFamily, class_2248 strippedBlock) {
        return ImmutableMap.<BlockSetVariant, FamilyRecipeProvider>builder()
                .put(BlockSetVariant.HANGING_SIGN,
                        (class_8790 recipeOutput, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            method_46208(recipeOutput, result, strippedBlock);
                        })
                .put(BlockSetVariant.BOAT,
                        (class_8790 recipeOutput, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            method_24478(recipeOutput, result, input);
                        })
                .put(BlockSetVariant.CHEST_BOAT,
                        (class_8790 recipeOutput, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                            class_6880.class_6883<class_1792> boatItem = blockSetFamily.getItem(BlockSetVariant.BOAT);
                            Objects.requireNonNull(boatItem, "boat item is null");
                            method_42754(recipeOutput, result, boatItem.comp_349());
                        })
                .build();
    }

    @Deprecated
    public static String getItemName(class_1856 ingredient) {
        return getItemName(Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    @Deprecated
    public static String getItemName(class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return Arrays.stream(items).map(class_2446::method_33716).collect(Collectors.joining("_or_"));
    }

    @Deprecated
    public static String getConversionRecipeName(class_1935 result, class_1856 ingredient) {
        return getConversionRecipeName(result,
                Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    @Deprecated
    public static String getConversionRecipeName(class_1935 result, class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return method_33716(result) + "_from_" + getItemName(items);
    }

    @Deprecated
    public static String getHasName(class_1856 ingredient) {
        return getHasName(Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    @Deprecated
    public static String getHasName(class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return "has_" + getItemName(items);
    }

    @Deprecated
    public static class_175<class_2066.class_2068> has(class_1856 ingredient) {
        return has(Arrays.stream(ingredient.method_8105()).map(class_1799::method_7909).toArray(class_1935[]::new));
    }

    @Deprecated
    public static class_175<class_2066.class_2068> has(class_1935... items) {
        Preconditions.checkState(items.length > 0, "items is empty");
        return method_10423(class_2073.class_2074.method_8973().method_8977(items).method_8976());
    }

    @Deprecated
    public static void stonecutterResultFromBase(class_8790 recipeOutput, class_7800 category, class_1935 result, class_1856 material) {
        stonecutterResultFromBase(recipeOutput, category, result, material, 1);
    }

    @Deprecated
    public static void stonecutterResultFromBase(class_8790 recipeOutput, class_7800 category, class_1935 result, class_1856 material, int resultCount) {
        class_3981.method_17969(material, category, result, resultCount)
                .method_17970(getHasName(material), has(material))
                .method_36443(recipeOutput, getConversionRecipeName(result, material) + "_stonecutting");
    }

    public void generateFor(class_8790 recipeOutput, BlockSetFamily blockSetFamily, Map<BlockSetVariant, FamilyRecipeProvider> variants) {
        class_5794 blockFamily = blockSetFamily.getBlockFamily();
        method_33535(recipeOutput, blockFamily, class_7701.field_40183);
        if (blockFamily.method_33478()) {
            blockSetFamily.getItemVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_1792> holder) -> {
                FamilyRecipeProvider recipeProvider = variants.get(variant);
                if (recipeProvider != null) {
                    class_1935 baseBlock;
                    if (variant.toVanilla() != null) {
                        baseBlock = method_33533(blockFamily, variant.toVanilla());
                    } else {
                        baseBlock = blockSetFamily.getBaseBlock().comp_349();
                    }

                    recipeProvider.create(recipeOutput,
                            holder.comp_349(),
                            baseBlock,
                            blockFamily.method_33479(),
                            blockFamily.method_33480());
                }
            });
        }
    }

    public void stair(class_8790 output, class_7800 recipeCategory, class_1935 resultItem, class_1935 ingredientItem) {
        this.stairBuilder(recipeCategory, resultItem, class_1856.method_8091(ingredientItem))
                .method_33530(method_32807(ingredientItem), method_10426(ingredientItem))
                .method_10431(output);
    }

    public class_5797 stairBuilder(class_7800 recipeCategory, class_1935 resultItem, class_1856 ingredient) {
        return class_2447.method_10436(recipeCategory, resultItem, 4)
                .method_10428('#', ingredient)
                .method_10439("#  ")
                .method_10439("## ")
                .method_10439("###");
    }

    public void metalCooking(class_8790 output, class_1935 resultItem, class_1935 ingredientItem, float experience) {
        this.metalCooking(output, resultItem, ingredientItem, experience, 200);
    }

    public void metalCooking(class_8790 output, class_1935 resultItem, class_1935 ingredientItem, float experience, int baseCookingTime) {
        class_2454.method_17802(class_1856.method_8091(ingredientItem),
                class_7800.field_40642,
                resultItem,
                experience,
                baseCookingTime).method_10469(method_32807(ingredientItem), method_10426(ingredientItem)).method_10431(output);
        class_2454.method_10473(class_1856.method_8091(ingredientItem),
                        class_7800.field_40642,
                        resultItem,
                        experience,
                        baseCookingTime / 2)
                .method_10469(method_32807(ingredientItem), method_10426(ingredientItem))
                .method_36443(output, method_36452(resultItem));
    }

    public void foodCooking(class_8790 output, class_1935 resultItem, class_1935 ingredientItem) {
        this.foodCooking(output, resultItem, ingredientItem, 0.35F, 200);
    }

    public void foodCooking(class_8790 output, class_1935 resultItem, class_1935 ingredientItem, float experienceReward, int baseCookingTime) {
        class_2454.method_17802(class_1856.method_8091(ingredientItem),
                class_7800.field_40640,
                resultItem,
                experienceReward,
                baseCookingTime).method_10469(method_32807(ingredientItem), method_10426(ingredientItem)).method_10431(output);
        class_2454.method_35918(class_1856.method_8091(ingredientItem),
                        class_7800.field_40640,
                        resultItem,
                        experienceReward,
                        baseCookingTime / 2)
                .method_10469(method_32807(ingredientItem), method_10426(ingredientItem))
                .method_36443(output, getCraftingMethodRecipeName(resultItem, class_1865.field_17085));
        class_2454.method_35916(class_1856.method_8091(ingredientItem),
                        class_7800.field_40640,
                        resultItem,
                        experienceReward,
                        baseCookingTime * 3)
                .method_10469(method_32807(ingredientItem), method_10426(ingredientItem))
                .method_36443(output, getCraftingMethodRecipeName(resultItem, class_1865.field_17347));
    }

    public class_5797 stonecutterResultFromBaseBuilder(class_7800 recipeCategory, class_1935 resultItem, class_1856 ingredient) {
        return this.stonecutterResultFromBaseBuilder(recipeCategory, resultItem, ingredient, 1);
    }

    public class_5797 stonecutterResultFromBaseBuilder(class_7800 recipeCategory, class_1935 resultItem, class_1856 ingredient, int count) {
        return class_3981.method_17969(ingredient, recipeCategory, resultItem, count);
    }

    public void smithing(class_8790 output, class_7800 recipeCategory, class_1935 resultItem, class_1935 templateItem, class_1935 baseItem, class_1935 materialItem) {
        class_8074.method_48535(class_1856.method_8091(templateItem),
                        class_1856.method_8091(baseItem),
                        class_1856.method_8091(materialItem),
                        recipeCategory,
                        resultItem.method_8389())
                .method_48536(method_32807(materialItem), method_10426(materialItem))
                .method_48538(output, getSmithingRecipeName(resultItem));
    }

    public void waxing(class_8790 output, class_1935 resultItem, class_1935 ingredientItem) {
        class_2450.method_10447(class_7800.field_40634, resultItem)
                .method_10454(ingredientItem)
                .method_10454(class_1802.field_20414)
                .method_10452(method_33716(resultItem))
                .method_10442(method_32807(ingredientItem), method_10426(ingredientItem))
                .method_36443(output, method_33714(resultItem, class_1802.field_20414));
    }

    public static String getCraftingMethodRecipeName(class_1935 resultItem, class_1865<?> recipeSerializer) {
        class_2960 identifier = class_7923.field_41189.method_10221(recipeSerializer);
        Objects.requireNonNull(identifier, "identifier is null");
        return getCraftingMethodRecipeName(resultItem, identifier.method_12832());
    }

    public static String getCraftingMethodRecipeName(class_1935 resultItem, String craftingMethod) {
        return method_33716(resultItem) + "_from_" + craftingMethod;
    }

    public static String getStonecuttingRecipeName(class_1935 resultItem, class_1935 material) {
        return method_33714(resultItem, material) + "_stonecutting";
    }

    public static String getSmithingRecipeName(class_1935 resultItem) {
        return method_33716(resultItem) + "_smithing";
    }

    public static String getHasName(class_6862<class_1792> tagKey) {
        return "has_" + tagKey.comp_327().method_12832();
    }

    @Override
    public CompletableFuture<?> method_56888(class_7403 output, class_7225.class_7874 registries) {
        List<CompletableFuture<?>> completableFutures = new ArrayList<>();
        this.method_10419(ProxyImpl.get().getIdentifiableRecipeOutput(this, output, registries, completableFutures));
        return CompletableFuture.allOf(completableFutures.toArray(CompletableFuture[]::new));
    }

    @Override
    public final void method_10419(class_8790 recipeOutput) {
        this.addRecipes(recipeOutput);
    }

    public abstract void addRecipes(class_8790 recipeOutput);

    @FunctionalInterface
    public interface FamilyRecipeProvider {
        void create(class_8790 recipeOutput, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy);

        static FamilyRecipeProvider stonecutting() {
            return stonecutting(1);
        }

        static FamilyRecipeProvider stonecutting(int count) {
            return (class_8790 recipeOutput, class_1935 result, class_1935 input, Optional<String> recipeGroupPrefix, Optional<String> recipeUnlockedBy) -> {
                class_3981 recipeBuilder = class_3981.method_17969(class_1856.method_8091(input),
                        class_7800.field_40634,
                        result,
                        count);
                recipeBuilder.method_17970(recipeUnlockedBy.orElseGet(() -> method_32807(input)), method_10426(input));
                recipeBuilder.method_36443(recipeOutput, getStonecuttingRecipeName(result, input));
            };
        }
    }

    public abstract class IdentifiableRecipeOutput implements class_8790 {
        private final class_7403 output;
        private final class_7225.class_7874 registries;
        private final List<CompletableFuture<?>> completableFutures;
        private final Set<class_2960> generatedRecipes = new HashSet<>();

        public IdentifiableRecipeOutput(class_7403 output, class_7225.class_7874 registries, List<CompletableFuture<?>> completableFutures) {
            this.output = output;
            this.registries = registries;
            this.completableFutures = completableFutures;
        }

        public String getModId() {
            return AbstractRecipeProvider.this.modId;
        }

        @Override
        public void method_53819(class_2960 location, class_1860<?> recipe, @Nullable class_8779 advancement) {
            final class_2960 oldLocation = location;
            // relocate all recipes to the mod id, so they do not depend on the item namespace which would
            // place e.g. new recipes for vanilla items in 'minecraft' which is not desired
            location = ResourceLocationHelper.fromNamespaceAndPath(AbstractRecipeProvider.this.modId,
                    location.method_12832());
            if (!this.generatedRecipes.add(location)) {
                throw new IllegalStateException("Duplicate recipe " + location);
            } else {
                this.completableFutures.add(class_2405.method_53496(this.output,
                        this.registries,
                        class_1860.field_47319,
                        recipe,
                        AbstractRecipeProvider.this.field_39378.method_44107(location)));
                if (advancement != null) {
                    class_6903<JsonElement> registryOps = this.registries.method_57093(JsonOps.INSTANCE);
                    JsonElement jsonElement = class_161.field_47179.encodeStart(registryOps, advancement.comp_1920())
                            .getOrThrow();
                    jsonElement = searchAndReplaceValue(jsonElement, oldLocation, location);
                    class_2960 advancementLocation = ResourceLocationHelper.fromNamespaceAndPath(
                            AbstractRecipeProvider.this.modId,
                            advancement.comp_1919().method_12832());
                    this.completableFutures.add(class_2405.method_10320(this.output,
                            jsonElement,
                            AbstractRecipeProvider.this.field_39379.method_44107(advancementLocation)));
                }
            }
        }

        @SuppressWarnings("removal")
        @Override
        public class_161.class_162 method_53818() {
            return class_161.class_162.method_51698().method_708(class_5797.field_39377);
        }
    }
}
