package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.BuiltinModelItemRendererContext;
import fuzs.puzzleslib.api.client.init.v1.BuiltinItemRenderer;
import fuzs.puzzleslib.api.client.init.v1.ReloadingBuiltInItemRenderer;
import fuzs.puzzleslib.api.core.v1.resources.ForwardingReloadListenerHelper;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4013;
import net.minecraft.class_7923;
import java.util.List;
import java.util.Objects;

public record BuiltinModelItemRendererContextFabricImpl(String modId,
                                                        List<class_4013> dynamicRenderers) implements BuiltinModelItemRendererContext {

    @Override
    public void registerItemRenderer(class_1792 item, BuiltinItemRenderer itemRenderer) {
        Objects.requireNonNull(item, "item is null");
        Objects.requireNonNull(itemRenderer, "renderer is null");
        BuiltinItemRendererRegistry.INSTANCE.register(item, itemRenderer::renderByItem);
    }

    @Override
    public void registerItemRenderer(class_1792 item, ReloadingBuiltInItemRenderer itemRenderer) {
        this.registerItemRenderer(item, (BuiltinItemRenderer) itemRenderer);
        // store this to enable listening to resource reloads
        String itemName = class_7923.field_41178.method_10221(item).method_12832();
        class_2960 resourceLocation = ResourceLocationHelper.fromNamespaceAndPath(this.modId,
                itemName + "_built_in_model_renderer");
        this.dynamicRenderers.add(ForwardingReloadListenerHelper.fromResourceManagerReloadListener(resourceLocation,
                itemRenderer));
    }
}
