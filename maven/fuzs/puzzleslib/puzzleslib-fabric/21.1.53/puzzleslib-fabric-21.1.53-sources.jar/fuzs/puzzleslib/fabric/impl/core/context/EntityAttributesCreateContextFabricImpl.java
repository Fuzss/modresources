package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.EntityAttributesCreateContext;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_5132;

@Deprecated
public final class EntityAttributesCreateContextFabricImpl implements EntityAttributesCreateContext {

    @Override
    public void registerEntityAttributes(class_1299<? extends class_1309> entityType, class_5132.class_5133 builder) {
        // do not check DefaultAttributes::hasSupplier, it crashes on some dedicated servers
        FabricDefaultAttributeRegistry.register(entityType, builder);
    }
}
