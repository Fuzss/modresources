package fuzs.puzzleslib.fabric.impl.client.init;

import fuzs.puzzleslib.fabric.api.client.event.v1.FabricClientEvents;
import fuzs.puzzleslib.impl.client.init.ItemDisplayOverridesImpl;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_2960;
import net.minecraft.class_811;

public final class FabricItemDisplayOverrides extends ItemDisplayOverridesImpl<class_1087> {
    private Map<class_1087, Map<class_811, class_1087>> overrideModels = Collections.emptyMap();

    @Override
    public void register(class_1091 itemModel, class_1091 itemModelOverride, class_811... itemDisplayContexts) {
        Objects.requireNonNull(itemModelOverride, "item model override is null");
        this.register(itemModel, (BakedModelResolver modelResolver) -> modelResolver.getModel(itemModelOverride),
                itemDisplayContexts
        );
    }

    @Override
    public void register(class_1091 itemModel, class_2960 itemModelOverride, class_811... itemDisplayContexts) {
        Objects.requireNonNull(itemModelOverride, "item model override is null");
        this.register(itemModel, (BakedModelResolver modelResolver) -> modelResolver.getModel(itemModelOverride),
                itemDisplayContexts
        );
    }

    @Override
    protected class_1087 createOverrideModelKey(class_1091 modelResourceLocation, class_1087 itemModel) {
        return itemModel;
    }

    @Override
    protected void registerEventHandlers() {
        // we cannot use Fabric's ForwardingBakedModel as it does not include the current ItemDisplayContext
        FabricClientEvents.COMPLETE_MODEL_LOADING.register(
                (Supplier<class_1092> modelManagerSupplier, Supplier<class_1088> modelBakerySupplier) -> {
                    class_1087 missingModel = modelManagerSupplier.get().method_4742(class_1088.field_52276);
                    Objects.requireNonNull(missingModel, "missing model is null");
                    this.overrideModels = this.computeOverrideModels(new BakedModelResolver() {
                        @Override
                        public class_1087 getModel(class_1091 modelResourceLocation) {
                            return modelManagerSupplier.get().method_4742(modelResourceLocation);
                        }

                        @Override
                        public class_1087 getModel(class_2960 resourceLocation) {
                            return modelManagerSupplier.get().getModel(resourceLocation);
                        }
                    }, missingModel);
                });
    }

    public class_1087 getItemModelDisplayOverride(class_1087 itemModel, class_811 itemDisplayContext) {
        return this.overrideModels.getOrDefault(itemModel, Collections.emptyMap()).getOrDefault(itemDisplayContext,
                itemModel
        );
    }
}
