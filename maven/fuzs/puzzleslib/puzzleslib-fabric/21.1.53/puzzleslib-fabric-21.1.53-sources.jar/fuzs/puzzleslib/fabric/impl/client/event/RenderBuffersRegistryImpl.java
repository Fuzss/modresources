package fuzs.puzzleslib.fabric.impl.client.event;

import com.google.common.collect.Sets;
import fuzs.puzzleslib.fabric.api.client.event.v1.registry.RenderBuffersRegistry;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_1921;
import net.minecraft.class_9799;

public final class RenderBuffersRegistryImpl implements RenderBuffersRegistry {
    private static final Set<Consumer<BiConsumer<class_1921, class_9799>>> CONSUMERS = Sets.newLinkedHashSet();

    @Override
    public void register(class_1921 renderType, class_9799 renderBuffer) {
        Objects.requireNonNull(renderType, "render type is null");
        Objects.requireNonNull(renderBuffer, "render buffer is null");
        CONSUMERS.add(buffers -> buffers.accept(renderType, renderBuffer));
    }

    public static void addAll(Map<class_1921, class_9799> buffers) {
        CONSUMERS.forEach(factory -> factory.accept(buffers::put));
    }
}
