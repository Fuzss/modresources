package fuzs.puzzleslib.api.network.v3;

import fuzs.puzzleslib.api.network.v2.MessageV2;
import fuzs.puzzleslib.api.network.v3.codec.StreamCodecRegistry;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.network.NetworkHandlerRegistry;
import fuzs.puzzleslib.impl.network.codec.StreamCodecRegistryImpl;
import io.netty.buffer.ByteBuf;
import net.minecraft.class_1297;
import net.minecraft.class_1923;
import net.minecraft.class_2382;
import net.minecraft.class_2540;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2818;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_8705;
import net.minecraft.class_8706;
import net.minecraft.class_9139;
import net.minecraft.class_9141;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Type;
import java.util.Collection;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Supplier;

/**
 * Handler for network communications between clients and a server.
 */
public interface NetworkHandler {

    /**
     * Creates a new network handler builder.
     *
     * @param modId mod id for default channel name
     * @return builder for mod specific network handler with default channel
     */
    static Builder builder(String modId) {
        return ModContext.get(modId).getNetworkHandler();
    }

    /**
     * Creates a new network handler builder.
     *
     * @param channelName id for channel name
     * @return builder for mod specific network handler with default channel
     */
    @Deprecated
    static Builder builder(class_2960 channelName) {
        return builder(channelName.method_12836());
    }

    /**
     * creates a packet heading to the client side
     *
     * @param message message to create packet from
     * @return packet for message
     */
    <T> class_2596<class_8705> toClientboundPacket(ClientboundMessage<T> message);

    /**
     * creates a packet heading to the server side
     *
     * @param message message to create packet from
     * @return packet for message
     */
    <T> class_2596<class_8706> toServerboundPacket(ServerboundMessage<T> message);

    /**
     * Send message from server to clients.
     *
     * @param playerSet players to send to
     * @param message   message to send
     */
    <T> void sendMessage(PlayerSet playerSet, ClientboundMessage<T> message);

    /**
     * Send message from client to server.
     *
     * @param message message to send
     */
    <T> void sendMessage(ServerboundMessage<T> message);

    /**
     * Send message from client to server.
     *
     * @param message message to send
     */
    @Deprecated
    default <T> void sendToServer(ServerboundMessage<T> message) {
        this.sendMessage(message);
    }

    /**
     * Send message from server to a player.
     *
     * @param player  player to send to
     * @param message message to send
     */
    @Deprecated
    default <T> void sendTo(class_3222 player, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.ofPlayer(player), message);
    }

    /**
     * Send message from server to all players.
     *
     * @param server  server for retrieving the player list
     * @param message message to send
     */
    @Deprecated
    default <T> void sendToAll(MinecraftServer server, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.ofAll(server), message);
    }

    /**
     * Send message from server to all players except one player.
     *
     * @param server        server for retrieving the player list
     * @param excludePlayer player to exclude
     * @param message       message to send
     */
    @Deprecated
    default <T> void sendToAll(MinecraftServer server, @Nullable class_3222 excludePlayer, ClientboundMessage<T> message) {
        PlayerSet playerSet;
        if (excludePlayer != null) {
            playerSet = PlayerSet.ofOthers(excludePlayer);
        } else {
            playerSet = PlayerSet.ofAll(server);
        }
        this.sendMessage(playerSet, message);
    }

    /**
     * Send message from server to all players except one player.
     *
     * @param playerList    all players to send the message to
     * @param excludePlayer player to exclude
     * @param message       message to send
     */
    @Deprecated
    default <T> void sendToAll(Collection<class_3222> playerList, @Nullable class_3222 excludePlayer, ClientboundMessage<T> message) {
        Objects.requireNonNull(playerList, "player list is null");
        for (class_3222 serverPlayer : playerList) {
            if (serverPlayer != excludePlayer) this.sendTo(serverPlayer, message);
        }
    }

    /**
     * Send message from server to all players in a level.
     *
     * @param level   the level
     * @param message message to send
     */
    @Deprecated
    default <T> void sendToAll(class_3218 level, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.inLevel(level), message);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param pos     source position
     * @param level   the current level
     * @param message message to send
     */
    @Deprecated
    default <T> void sendToAllNear(class_2382 pos, class_3218 level, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.nearPosition(pos, level), message);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param posX    source position x
     * @param posY    source position y
     * @param posZ    source position z
     * @param level   the current level
     * @param message message to send
     */
    @Deprecated
    default <T> void sendToAllNear(double posX, double posY, double posZ, class_3218 level, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.nearPosition(posX, posY, posZ, level), message);
    }

    /**
     * Send message from server to all players near a given position.
     *
     * @param excludePlayer exclude player having caused this event
     * @param posX          source position x
     * @param posY          source position y
     * @param posZ          source position z
     * @param distance      allowed distance from source to receive message
     * @param level         the current level
     * @param message       message to send
     */
    @Deprecated
    default <T> void sendToAllNear(@Nullable class_3222 excludePlayer, double posX, double posY, double posZ, double distance, class_3218 level, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.nearPosition(excludePlayer, posX, posY, posZ, distance, level), message);
    }

    /**
     * Send message from server to all players tracking a block entity at a certain block position.
     *
     * @param blockEntity the block entity a player must track to receive this message
     * @param message     message to send
     */
    @Deprecated
    default <T> void sendToAllTracking(class_2586 blockEntity, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.nearBlockEntity(blockEntity), message);
    }

    /**
     * Send message from server to all players tracking a chunk.
     *
     * @param chunk   the chunk a player must track to receive this message
     * @param message message to send
     */
    @Deprecated
    default <T> void sendToAllTracking(class_2818 chunk, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.nearChunk(chunk), message);
    }

    /**
     * Send message from server to all players tracking a chunk.
     *
     * @param level    the level containing the chunk
     * @param chunkPos the chunk pos a player must track to receive this message
     * @param message  message to send
     */
    @Deprecated
    default <T> void sendToAllTracking(class_3218 level, class_1923 chunkPos, ClientboundMessage<T> message) {
        this.sendMessage(PlayerSet.nearChunk(level, chunkPos), message);
    }

    /**
     * Send message from server to all players tracking a given entity.
     *
     * @param entity      the tracked entity
     * @param message     message to send
     * @param includeSelf when the tracked entity is a player will they receive the message as well
     */
    @Deprecated
    default <T> void sendToAllTracking(class_1297 entity, ClientboundMessage<T> message, boolean includeSelf) {
        if (includeSelf || !(entity instanceof class_3222 serverPlayer)) {
            this.sendMessage(PlayerSet.nearEntity(entity), message);
        } else {
            this.sendMessage(PlayerSet.nearPlayer(serverPlayer), message);
        }
    }

    /**
     * A builder for a network handler, allows for registering messages.
     */
    interface Builder extends NetworkHandlerRegistry, StreamCodecRegistry<Builder> {

        @Override
        default <B extends ByteBuf, V> Builder registerSerializer(Class<V> type, class_9139<? super B, V> streamCodec) {
            StreamCodecRegistryImpl.INSTANCE.registerSerializer(type, streamCodec);
            return this;
        }

        @Override
        default <B extends ByteBuf, V> Builder registerContainerProvider(Class<V> type, Function<Type[], class_9139<? super B, ? extends V>> factory) {
            StreamCodecRegistryImpl.INSTANCE.registerContainerProvider(type, factory);
            return this;
        }

        /**
         * Register a message that will be sent to clients.
         *
         * @param clazz message class type
         * @param <T>   message implementation
         * @return this builder instance
         */
        <T extends Record & ClientboundMessage<T>> Builder registerClientbound(Class<T> clazz);

        /**
         * Register a message that will be sent to servers.
         *
         * @param clazz message class type
         * @param <T>   message implementation
         * @return this builder instance
         */
        <T extends Record & ServerboundMessage<T>> Builder registerServerbound(Class<T> clazz);

        /**
         * Register a message that will be sent to clients.
         *
         * @param <T>     message implementation
         * @param clazz   message class type
         * @param factory message factory
         */
        default <T extends MessageV2<T>> Builder registerLegacyClientbound(Class<T> clazz, Supplier<T> factory) {
            return this.registerLegacyClientbound(clazz, (class_2540 friendlyByteBuf) -> {
                T message = factory.get();
                message.read(friendlyByteBuf);
                return message;
            });
        }

        /**
         * Register a message that will be sent to servers.
         *
         * @param <T>     message implementation
         * @param clazz   message class type
         * @param factory message factory
         */
        default <T extends MessageV2<T>> Builder registerLegacyServerbound(Class<T> clazz, Supplier<T> factory) {
            return this.registerLegacyServerbound(clazz, (class_2540 friendlyByteBuf) -> {
                T message = factory.get();
                message.read(friendlyByteBuf);
                return message;
            });
        }

        /**
         * Register a message that will be sent to clients.
         *
         * @param <T>     message implementation
         * @param clazz   message class type
         * @param factory message factory
         */
        <T extends MessageV2<T>> Builder registerLegacyClientbound(Class<T> clazz, class_9141<class_2540, T> factory);

        /**
         * Register a message that will be sent to servers.
         *
         * @param <T>     message implementation
         * @param clazz   message class type
         * @param factory message factory
         */
        <T extends MessageV2<T>> Builder registerLegacyServerbound(Class<T> clazz, class_9141<class_2540, T> factory);

        /**
         * Are clients &amp; servers without this mod or vanilla clients &amp; servers compatible.
         *
         * <p>Not supported on Fabric-like environments.
         *
         * @return this builder instance
         */
        Builder optional();
    }
}
