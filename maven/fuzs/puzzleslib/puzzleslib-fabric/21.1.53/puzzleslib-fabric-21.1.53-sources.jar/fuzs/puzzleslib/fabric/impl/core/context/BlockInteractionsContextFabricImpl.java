package fuzs.puzzleslib.fabric.impl.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.context.BlockInteractionsContext;
import net.fabricmc.fabric.api.registry.FlattenableBlockRegistry;
import net.fabricmc.fabric.api.registry.OxidizableBlocksRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.fabricmc.fabric.api.registry.TillableBlockRegistry;
import net.minecraft.class_1794;
import net.minecraft.class_1838;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Predicate;

@Deprecated
public final class BlockInteractionsContextFabricImpl implements BlockInteractionsContext {

    @Override
    public void registerStrippable(class_2248 strippedBlock, class_2248... unstrippedBlocks) {
        Objects.requireNonNull(strippedBlock, "stripped block is null");
        Objects.requireNonNull(unstrippedBlocks, "unstripped blocks is null");
        Preconditions.checkState(unstrippedBlocks.length > 0, "unstripped blocks is empty");
        for (class_2248 unstrippedBlock : unstrippedBlocks) {
            Objects.requireNonNull(unstrippedBlock, "unstripped block is null");
            StrippableBlockRegistry.register(unstrippedBlock, strippedBlock);
        }
    }

    @Override
    public void registerScrapeable(class_2248 scrapedBlock, class_2248... unscrapedBlocks) {
        Objects.requireNonNull(scrapedBlock, "scraped block is null");
        Objects.requireNonNull(unscrapedBlocks, "unscraped blocks is null");
        Preconditions.checkState(unscrapedBlocks.length > 0, "unscraped blocks is empty");
        for (class_2248 unscrapedBlock : unscrapedBlocks) {
            Objects.requireNonNull(unscrapedBlock, "unscraped block is null");
            OxidizableBlocksRegistry.registerOxidizableBlockPair(scrapedBlock, unscrapedBlock);
        }
    }

    @Override
    public void registerWaxable(class_2248 unwaxedBlock, class_2248... waxedBlocks) {
        Objects.requireNonNull(unwaxedBlock, "unwaxed block is null");
        Objects.requireNonNull(waxedBlocks, "waxed blocks is null");
        Preconditions.checkState(waxedBlocks.length > 0, "waxed blocks is empty");
        for (class_2248 waxedBlock : waxedBlocks) {
            Objects.requireNonNull(waxedBlock, "waxed block is null");
            OxidizableBlocksRegistry.registerWaxableBlockPair(unwaxedBlock, waxedBlock);
        }
    }

    @Override
    public void registerFlattenable(class_2680 flattenedBlock, class_2248... unflattenedBlocks) {
        Objects.requireNonNull(flattenedBlock, "flattened block is null");
        Objects.requireNonNull(unflattenedBlocks, "unflattened blocks is null");
        Preconditions.checkState(unflattenedBlocks.length > 0, "unflattened blocks is empty");
        for (class_2248 unflattenedBlock : unflattenedBlocks) {
            Objects.requireNonNull(unflattenedBlock, "unflattened block is null");
            FlattenableBlockRegistry.register(unflattenedBlock, flattenedBlock);
        }
    }

    @Override
    public void registerTillable(class_2680 tilledBlock, @Nullable class_1935 droppedItem, boolean onlyIfAirAbove, class_2248... untilledBlocks) {
        Objects.requireNonNull(tilledBlock, "tilled block is null");
        Objects.requireNonNull(untilledBlocks, "untilled blocks is null");
        Preconditions.checkState(untilledBlocks.length > 0, "untilled blocks is empty");
        Predicate<class_1838> usagePredicate = onlyIfAirAbove ? class_1794::method_36987 : $ -> true;
        Consumer<class_1838> tillingAction = droppedItem != null ? class_1794.method_36985(tilledBlock, droppedItem) : class_1794.method_36988(tilledBlock);
        for (class_2248 untilledBlock : untilledBlocks) {
            Objects.requireNonNull(untilledBlock, "untilled block is null");
            TillableBlockRegistry.register(untilledBlock, usagePredicate, tillingAction);
        }
    }
}
