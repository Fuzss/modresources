package fuzs.puzzleslib.api.item.v2;

import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5250;
import net.minecraft.class_9334;

/**
 * A simple utility for abstracting common {@link class_1799} functionality.
 */
public final class ItemHelper {

    private ItemHelper() {
        // NO-OP
    }

    /**
     * Called for damaging an item stack, potentially breaking it when it runs out of durability.
     *
     * @param itemStack       the item stack to be hurt
     * @param amount          the amount to damage the stack by
     * @param livingEntity    the entity using the stack
     * @param interactionHand the hand using the stack
     */
    public static void hurtAndBreak(class_1799 itemStack, int amount, class_1309 livingEntity, class_1268 interactionHand) {
        hurtAndBreak(itemStack, amount, livingEntity, class_1309.method_56079(interactionHand));
    }

    /**
     * Called for damaging an item stack, potentially breaking it when it runs out of durability.
     *
     * @param itemStack     the item stack to be hurt
     * @param amount        the amount to damage the stack by
     * @param livingEntity  the entity using the stack
     * @param equipmentSlot the slot the stack is present in
     */
    public static void hurtAndBreak(class_1799 itemStack, int amount, class_1309 livingEntity, class_1304 equipmentSlot) {
        if (livingEntity.method_37908() instanceof class_3218 serverLevel) {
            class_3222 serverPlayer = livingEntity instanceof class_3222 ? (class_3222) livingEntity : null;
            hurtAndBreak(itemStack, amount, serverLevel, serverPlayer, (class_1792 item) -> {
                livingEntity.method_20235(item, equipmentSlot);
            });
        }
    }

    /**
     * Called for damaging an item stack, potentially breaking it when it runs out of durability.
     *
     * @param itemStack    the item stack to be hurt
     * @param amount       the amount to damage the stack by
     * @param serverLevel  the level
     * @param serverPlayer the player using the stack
     * @param onBreak      what happens when the stack breaks, usually calls
     *                     {@link class_1309#method_20235(class_1792, class_1304)}
     */
    public static void hurtAndBreak(class_1799 itemStack, int amount, class_3218 serverLevel, @Nullable class_3222 serverPlayer, Consumer<class_1792> onBreak) {
        class_1799 originalItemStack = copyItemStackIfNecessary(itemStack, serverPlayer);
        itemStack.method_7956(amount, serverLevel, serverPlayer, (class_1792 item) -> {
            onBreak.accept(item);
            if (serverPlayer != null) {
                onPlayerDestroyItem(serverPlayer, originalItemStack, null);
            }
        });
    }

    private static class_1799 copyItemStackIfNecessary(class_1799 itemStack, @Nullable class_3222 serverPlayer) {
        // the NeoForge item destroy event uses a copy of the original item stack, so make sure we keep this here
        if (serverPlayer != null && ModLoaderEnvironment.INSTANCE.getModLoader().isForgeLike()) {
            return itemStack.method_7972();
        } else {
            return itemStack;
        }
    }

    /**
     * A trigger for running a NeoForge event for destroying an item.
     *
     * @param player            the player destroying the item
     * @param originalItemStack the item stack before being destroyed
     * @param interactionHand   the hand holding the destroyed stack
     */
    public static void onPlayerDestroyItem(class_1657 player, class_1799 originalItemStack, @Nullable class_1268 interactionHand) {
        Objects.requireNonNull(player, "player is null");
        Objects.requireNonNull(originalItemStack, "original item stack is null");
        ProxyImpl.get().onPlayerDestroyItem(player, originalItemStack, interactionHand);
    }

    /**
     * Creates a style for item names for a rarity.
     * <p>
     * Alternatively use {@link #getStyledHoverName(class_1799)} where possible.
     *
     * @param rarity the rarity
     * @return the style for this rarity, apply via {@link net.minecraft.class_5250#method_27696(class_2583)}
     *         or {@link class_2583#method_27702(class_2583)}
     */
    public static class_2583 getRarityStyle(class_1814 rarity) {
        Objects.requireNonNull(rarity, "rarity is null");
        return ProxyImpl.get().getRarityStyle(rarity);
    }

    /**
     * Creates the name component shown as part of the item tooltip.
     * <p>
     * Backported from Minecraft 1.21.2.
     *
     * @param itemStack the item
     * @return the hover name component
     */
    public class_2561 getStyledHoverName(class_1799 itemStack) {
        class_5250 hoverName = class_2561.method_43473()
                .method_10852(itemStack.method_7964())
                .method_27696(getRarityStyle(itemStack.method_7932()));
        if (itemStack.method_57826(class_9334.field_49631)) {
            return hoverName.method_27692(class_124.field_1056);
        } else {
            return hoverName;
        }
    }
}
