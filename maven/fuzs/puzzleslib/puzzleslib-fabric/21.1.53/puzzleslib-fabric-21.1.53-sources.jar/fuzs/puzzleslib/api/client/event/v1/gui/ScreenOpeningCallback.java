package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import net.minecraft.class_437;
import org.jetbrains.annotations.Nullable;

@FunctionalInterface
public interface ScreenOpeningCallback {
    EventInvoker<ScreenOpeningCallback> EVENT = EventInvoker.lookup(ScreenOpeningCallback.class);

    /**
     * Called just before a new screen is set to {@link net.minecraft.class_310#field_1755} in {@link net.minecraft.class_310#method_1507},
     * allows for exchanging the new screen with a different one, or can prevent a new screen from opening, effectively forcing the old screen to remain.
     * <p>Do not use {@link net.minecraft.class_310#method_1507} inside of this event callback, there will be an infinite loop!
     *
     * @param oldScreen the screen that is being removed, may be null when opening the screen from {@link net.minecraft.class_329}, like {@link net.minecraft.class_433}
     * @param newScreen the new screen that is being set, may be null when closing a screen and returning to {@link net.minecraft.class_329}, can be changed;
     *                  setting <code>oldScreen</code> enacts the same behavior as interrupting the callback by returning {@link EventResult#INTERRUPT}
     * @return {@link EventResult#INTERRUPT} to prevent the new screen from opening, the old screen will be kept and no call to {@link class_437#method_25432()} is made,
     * {@link EventResult#PASS} to allow a new screen to be set, potentially changed via <code>newScreen</code>
     */
    EventResult onScreenOpening(@Nullable class_437 oldScreen, DefaultedValue<class_437> newScreen);
}
