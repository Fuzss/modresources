package fuzs.puzzleslib.fabric.impl.biome;

import fuzs.puzzleslib.api.biome.v1.SpecialEffectsContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.class_3414;
import net.minecraft.class_4761;
import net.minecraft.class_4763;
import net.minecraft.class_4967;
import net.minecraft.class_4968;
import net.minecraft.class_5195;
import net.minecraft.class_6880;
import org.jetbrains.annotations.NotNull;

import java.util.Optional;

public record SpecialEffectsContextFabric(class_4763 specialEffects, BiomeModificationContext.EffectsContext context) implements SpecialEffectsContext {

    @Override
    public void setFogColor(int fogColor) {
        this.context.setFogColor(fogColor);
    }

    @Override
    public int getFogColor() {
        return this.specialEffects.method_24387();
    }

    @Override
    public void setWaterColor(int waterColor) {
        this.context.setWaterColor(waterColor);
    }

    @Override
    public int getWaterColor() {
        return this.specialEffects.method_24388();
    }

    @Override
    public void setWaterFogColor(int waterFogColor) {
        this.context.setWaterFogColor(waterFogColor);
    }

    @Override
    public int getWaterFogColor() {
        return this.specialEffects.method_24389();
    }

    @Override
    public void setSkyColor(int skyColor) {
        this.context.setSkyColor(skyColor);
    }

    @Override
    public int getSkyColor() {
        return this.specialEffects.method_30810();
    }

    @Override
    public void setFoliageColorOverride(Optional<Integer> foliageColorOverride) {
        this.context.setFoliageColor(foliageColorOverride);
    }

    @Override
    public Optional<Integer> getFoliageColorOverride() {
        return this.specialEffects.method_30811();
    }

    @Override
    public void setGrassColorOverride(Optional<Integer> grassColorOverride) {
        this.context.setGrassColor(grassColorOverride);
    }

    @Override
    public Optional<Integer> getGrassColorOverride() {
        return this.specialEffects.method_30812();
    }

    @Override
    public void setGrassColorModifier(@NotNull class_4763.class_5486 grassColorModifier) {
        this.context.setGrassColorModifier(grassColorModifier);
    }

    @Override
    public class_4763.class_5486 getGrassColorModifier() {
        return this.specialEffects.method_30814();
    }

    @Override
    public void setAmbientParticleSettings(Optional<class_4761> ambientParticleSettings) {
        this.context.setParticleConfig(ambientParticleSettings);
    }

    @Override
    public Optional<class_4761> getAmbientParticleSettings() {
        return this.specialEffects.method_24390();
    }

    @Override
    public void setAmbientLoopSoundEvent(Optional<class_6880<class_3414>> ambientLoopSoundEvent) {
        this.context.setAmbientSound(ambientLoopSoundEvent);
    }

    @Override
    public Optional<class_6880<class_3414>> getAmbientLoopSoundEvent() {
        return this.specialEffects.method_24939();
    }

    @Override
    public void setAmbientMoodSettings(Optional<class_4968> ambientMoodSettings) {
        this.context.setMoodSound(ambientMoodSettings);
    }

    @Override
    public Optional<class_4968> getAmbientMoodSettings() {
        return this.specialEffects.method_24940();
    }

    @Override
    public void setAmbientAdditionsSettings(Optional<class_4967> ambientAdditionsSettings) {
        this.context.setAdditionsSound(ambientAdditionsSettings);
    }

    @Override
    public Optional<class_4967> getAmbientAdditionsSettings() {
        return this.specialEffects.method_24941();
    }

    @Override
    public void setBackgroundMusic(Optional<class_5195> backgroundMusic) {
        this.context.setMusic(backgroundMusic);
    }

    @Override
    public Optional<class_5195> getBackgroundMusic() {
        return this.specialEffects.method_27345();
    }
}
