package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_2394;
import net.minecraft.class_2396;
import net.minecraft.class_702;
import net.minecraft.class_707;

/**
 * Register a particle provider for a particle type.
 */
public interface ParticleProvidersContext {

    /**
     * Register a client-side factory for a particle type.
     *
     * @param particleType     common particle type
     * @param particleProvider particle factory
     * @param <T>              type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707<T> particleProvider);

    /**
     * Register a client-side factory for a particle type.
     *
     * @param particleType     common particle type
     * @param particleProvider particle factory
     * @param <T>              type of particle
     */
    @Deprecated
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_707.class_8187<T> particleProvider);

    /**
     * Register a client-side sprite based factory for a particle type.
     *
     * @param particleType    common particle type
     * @param particleFactory particle factory
     * @param <T>             type of particle
     */
    <T extends class_2394> void registerParticleProvider(class_2396<T> particleType, class_702.class_4091<T> particleFactory);
}
