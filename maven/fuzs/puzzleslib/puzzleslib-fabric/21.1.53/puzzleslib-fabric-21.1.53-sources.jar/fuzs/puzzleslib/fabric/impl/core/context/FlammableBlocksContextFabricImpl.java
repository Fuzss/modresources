package fuzs.puzzleslib.fabric.impl.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.context.FlammableBlocksContext;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.minecraft.class_2248;
import java.util.Objects;

@Deprecated
public final class FlammableBlocksContextFabricImpl implements FlammableBlocksContext {

    @Override
    public void registerFlammable(int encouragement, int flammability, class_2248... blocks) {
        Preconditions.checkArgument(encouragement > 0, "encouragement is negative");
        Preconditions.checkArgument(flammability > 0, "flammability is negative");
        Objects.requireNonNull(blocks, "blocks is null");
        Preconditions.checkState(blocks.length > 0, "blocks is empty");
        for (class_2248 block : blocks) {
            Objects.requireNonNull(block, "block is null");
            // flammability == burn, encouragement == spread
            FlammableBlockRegistry.getDefaultInstance().add(block, flammability, encouragement);
        }
    }
}
