package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingChangeTargetCallback {
    EventInvoker<LivingChangeTargetCallback> EVENT = EventInvoker.lookup(LivingChangeTargetCallback.class);

    /**
     * Called when a {@link net.minecraft.class_1308} sets a new target.
     *
     * @param entity the entity setting a new target
     * @param target the target to be set, can be <code>null</code>
     * @return <ul>
     *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the target from changing</li>
     *         <li>{@link EventResult#PASS PASS} to allow the target to change to the set value</li>
     *         </ul>
     */
    EventResult onLivingChangeTarget(class_1309 entity, DefaultedValue<class_1309> target);
}
