package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingAttackCallback {
    EventInvoker<LivingAttackCallback> EVENT = EventInvoker.lookup(LivingAttackCallback.class);

    /**
     * Fires when a {@link class_1309} is attacked, allows for cancelling that attack.
     * <p>This event runs at the beginning of {@link class_1309#method_5643(class_1282, float)}.
     *
     * @param entity the entity that is attacked
     * @param source the {@link class_1282} {@code entity} has been attacked by
     * @param amount the amount of damage {@code entity} is attacked with
     * @return {@link EventResult#INTERRUPT} to prevent the attack from happening, dealing no damage,
     * {@link EventResult#PASS} to allow the entity to be attacked and to take damage
     */
    EventResult onLivingAttack(class_1309 entity, class_1282 source, float amount);
}
