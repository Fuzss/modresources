package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1923;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public final class ServerChunkEvents {
    public static final EventInvoker<Load> LOAD = EventInvoker.lookup(Load.class);
    public static final EventInvoker<Unload> UNLOAD = EventInvoker.lookup(Unload.class);
    public static final EventInvoker<Watch> WATCH = EventInvoker.lookup(Watch.class);
    public static final EventInvoker<Unwatch> UNWATCH = EventInvoker.lookup(Unwatch.class);

    private ServerChunkEvents() {

    }

    @FunctionalInterface
    public interface Load {

        /**
         * Fires before a server chunk is loaded.
         *
         * @param level the server level the chunk is in
         * @param chunk the chunk being loaded
         */
        void onChunkLoad(class_3218 level, class_2818 chunk);
    }

    @FunctionalInterface
    public interface Unload {

        /**
         * Fires before a server chunk is unloaded.
         *
         * @param level the server level the chunk is in
         * @param chunk the chunk being unloaded
         */
        void onChunkUnload(class_3218 level, class_2818 chunk);
    }

    @FunctionalInterface
    public interface Watch {

        /**
         * Fires when a server player begins watching a chunk, and it has just been sent to a client.
         * <p>Useful for syncing additional chunk data.
         *
         * @param player the player watching the chunk
         * @param chunk  the chunk
         * @param level  the level the chunk is in
         */
        void onChunkWatch(class_3222 player, class_2818 chunk, class_3218 level);
    }

    @FunctionalInterface
    public interface Unwatch {

        /**
         * Fires when a server player stops watching a chunk.
         *
         * @param player the player watching the chunk
         * @param chunkPos  the chunk position
         * @param level  the level the chunk is in
         */
        void onChunkUnwatch(class_3222 player, class_1923 chunkPos, class_3218 level);
    }
}
