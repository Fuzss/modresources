package fuzs.puzzleslib.fabric.impl.capability.data;

import fuzs.puzzleslib.api.capability.v3.data.CapabilityComponent;
import fuzs.puzzleslib.api.capability.v3.data.LevelCapabilityKey;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1937;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FabricLevelCapabilityKey<C extends CapabilityComponent<class_1937>> extends FabricCapabilityKey<class_1937, C> implements LevelCapabilityKey<C> {

    public FabricLevelCapabilityKey(AttachmentType<C> attachmentType, Predicate<Object> filter, Supplier<C> factory) {
        super(attachmentType, filter, factory);
    }
}
