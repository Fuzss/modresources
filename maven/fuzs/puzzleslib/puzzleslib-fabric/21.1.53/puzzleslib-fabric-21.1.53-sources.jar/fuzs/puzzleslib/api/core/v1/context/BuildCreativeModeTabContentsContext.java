package fuzs.puzzleslib.api.core.v1.context;

import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import net.minecraft.class_1761;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * Add items to a creative tab.
 */
@Deprecated
public interface BuildCreativeModeTabContentsContext {

    /**
     * Add items to a creative tab referenced by internal id.
     *
     * @param modId          the creative mode tab namespace to add items to, the default path 'main' will be used
     * @param itemsGenerator context for adding items to the creative mode tab
     */
    default void registerBuildListener(String modId, class_1761.class_7914 itemsGenerator) {
        class_2960 resourceLocation = ResourceLocationHelper.fromNamespaceAndPath(modId, "main");
        this.registerBuildListener(resourceLocation, itemsGenerator);
    }

    /**
     * Add items to a creative tab referenced by internal id.
     *
     * @param identifier     the creative mode tab to add items to
     * @param itemsGenerator context for adding items to the creative mode tab
     */
    default void registerBuildListener(class_2960 identifier, class_1761.class_7914 itemsGenerator) {
        class_5321<class_1761> resourceKey = class_5321.method_29179(class_7924.field_44688, identifier);
        this.registerBuildListener(resourceKey, itemsGenerator);
    }

    /**
     * Add items to a creative tab referenced by instance.
     *
     * @param resourceKey    the creative mode tab to add items to
     * @param itemsGenerator context for adding items to the creative mode tab
     */
    void registerBuildListener(class_5321<class_1761> resourceKey, class_1761.class_7914 itemsGenerator);
}
