package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedDouble;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingJumpCallback {
    EventInvoker<LivingJumpCallback> EVENT = EventInvoker.lookup(LivingJumpCallback.class);

    /**
     * Called when an entity is jumping, allows for modifying the jump height as well as preventing the jump.
     * <p>Additionally looks at {@link class_1309#method_6106()} and {@link class_1309#method_37416()} which are the two values that usually make up <code>jumpPower</code>.
     *
     * @param entity    the jumping entity
     * @param jumpPower the current jump power
     * @return {@link EventResult#INTERRUPT} to prevent the entity from jumping,
     * {@link EventResult#PASS} to allow the entity to jump with the value set in <code>jumpPower</code>
     */
    EventResult onLivingJump(class_1309 entity, DefaultedDouble jumpPower);
}
