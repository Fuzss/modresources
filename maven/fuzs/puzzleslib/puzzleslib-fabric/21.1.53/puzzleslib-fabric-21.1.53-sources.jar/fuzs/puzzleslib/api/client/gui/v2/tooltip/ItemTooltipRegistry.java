package fuzs.puzzleslib.api.client.gui.v2.tooltip;

import fuzs.puzzleslib.api.client.event.v1.gui.ItemTooltipCallback;
import org.jetbrains.annotations.Nullable;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

/**
 * A helper class for registering item tooltips for items and blocks.
 *
 * @param <T> the value type
 */
public abstract class ItemTooltipRegistry<T> {
    /**
     * The block registry.
     */
    public static final ItemTooltipRegistry<class_2248> BLOCK = new ItemTooltipRegistry<>() {
        @Override
        @Nullable class_2248 getFromItemStack(class_1799 itemStack) {
            return itemStack.method_7909() instanceof class_1747 blockItem ? blockItem.method_7711() : null;
        }

        @Override
        class_2378<class_2248> getRegistry() {
            return class_7923.field_41175;
        }
    };
    /**
     * The item registry.
     */
    public static final ItemTooltipRegistry<class_1792> ITEM = new ItemTooltipRegistry<>() {
        @Override
        class_1792 getFromItemStack(class_1799 itemStack) {
            return itemStack.method_7909();
        }

        @Override
        class_2378<class_1792> getRegistry() {
            return class_7923.field_41178;
        }
    };

    ItemTooltipRegistry() {
        // NO-OP
    }

    abstract @Nullable T getFromItemStack(class_1799 itemStack);

    abstract class_2378<T> getRegistry();

    /**
     * Register an item tooltip provider built from a component.
     *
     * @param value     the item / block
     * @param component the component
     * @param <V>       the value type
     */
    public <V extends T> void registerItemTooltip(V value, class_2561 component) {
        this.registerItemTooltip(value, new class_2561[]{component});
    }

    /**
     * Register an item tooltip provider built from a component.
     *
     * @param clazz     the item / block class
     * @param component the component
     * @param <V>       the value type
     */
    public <V extends T> void registerItemTooltip(Class<V> clazz, class_2561 component) {
        this.registerItemTooltip(clazz, new class_2561[]{component});
    }

    /**
     * Register an item tooltip provider built from a component.
     *
     * @param tagKey    the item / block tag key
     * @param component the components
     */
    public void registerItemTooltip(class_6862<T> tagKey, class_2561 component) {
        this.registerItemTooltip(tagKey, new class_2561[]{component});
    }

    /**
     * Register an item tooltip provider built from components.
     *
     * @param value      the item / block
     * @param components the component
     * @param <V>        the value type
     */
    public <V extends T> void registerItemTooltip(V value, class_2561... components) {
        this.registerItemTooltipLines(value, (V valueX) -> Arrays.asList(components));
    }

    /**
     * Register an item tooltip provider built from components.
     *
     * @param clazz      the item / block class
     * @param components the component
     * @param <V>        the value type
     */
    public <V extends T> void registerItemTooltip(Class<V> clazz, class_2561... components) {
        this.registerItemTooltipLines(clazz, (V valueX) -> Arrays.asList(components));
    }

    /**
     * Register an item tooltip provider built from components.
     *
     * @param tagKey     the item / block tag key
     * @param components the components
     */
    public void registerItemTooltip(class_6862<T> tagKey, class_2561... components) {
        this.registerItemTooltipLines(tagKey, (T valueX) -> Arrays.asList(components));
    }

    /**
     * Register an item tooltip provider built from extracting a component.
     *
     * @param value              the item / block
     * @param componentExtractor the component getter from the item / block
     * @param <V>                the value type
     */
    public <V extends T> void registerItemTooltip(V value, Function<V, @Nullable class_2561> componentExtractor) {
        this.registerItemTooltipLines(value, (V valueX) -> {
            return Collections.singletonList(componentExtractor.apply(valueX));
        });
    }

    /**
     * Register an item tooltip provider built from extracting a component.
     *
     * @param clazz              the item / block class
     * @param componentExtractor the component getter from the item / block
     * @param <V>                the value type
     */
    public <V extends T> void registerItemTooltip(Class<V> clazz, Function<V, @Nullable class_2561> componentExtractor) {
        this.registerItemTooltipLines(clazz, (V valueX) -> {
            return Collections.singletonList(componentExtractor.apply(valueX));
        });
    }

    /**
     * Register an item tooltip provider built from extracting a component.
     *
     * @param tagKey             the item / block tag key
     * @param componentExtractor the component getter from the item / block
     */
    public void registerItemTooltip(class_6862<T> tagKey, Function<T, @Nullable class_2561> componentExtractor) {
        this.registerItemTooltipLines(tagKey, (T valueX) -> {
            return Collections.singletonList(componentExtractor.apply(valueX));
        });
    }

    /**
     * Register an item tooltip provider built from extracting components.
     *
     * @param value              the item / block
     * @param componentExtractor the component getter from the item / block
     * @param <V>                the value type
     */
    public <V extends T> void registerItemTooltipLines(V value, Function<V, List<class_2561>> componentExtractor) {
        this.registerItemTooltip((class_1799 itemStack) -> this.getFromItemStack(itemStack) == value,
                (class_1799 itemStack, class_1792.class_9635 context, class_1836 tooltipFlag, @Nullable class_1657 player, Consumer<@Nullable class_2561> tooltipLineConsumer) -> {
                    componentExtractor.apply(value).forEach(tooltipLineConsumer);
                });
    }

    /**
     * Register an item tooltip provider built from extracting components.
     *
     * @param clazz              the item / block class
     * @param componentExtractor the component getter from the item / block
     * @param <V>                the value type
     */
    public <V extends T> void registerItemTooltipLines(Class<V> clazz, Function<V, List<class_2561>> componentExtractor) {
        this.registerItemTooltip(clazz,
                (class_1799 itemStack, class_1792.class_9635 context, class_1836 tooltipFlag, @Nullable class_1657 player, Consumer<@Nullable class_2561> tooltipLineConsumer) -> {
                    T value = this.getFromItemStack(itemStack);
                    Objects.requireNonNull(value, "value from item stack " + itemStack + " is null");
                    componentExtractor.apply((V) value).forEach(tooltipLineConsumer);
                });
    }

    /**
     * Register an item tooltip provider built from extracting components.
     *
     * @param tagKey             the item / block tag key
     * @param componentExtractor the component getter from the item / block
     */
    public void registerItemTooltipLines(class_6862<T> tagKey, Function<T, List<class_2561>> componentExtractor) {
        this.registerItemTooltip(tagKey,
                (class_1799 itemStack, class_1792.class_9635 context, class_1836 tooltipFlag, @Nullable class_1657 player, Consumer<@Nullable class_2561> tooltipLineConsumer) -> {
                    T value = this.getFromItemStack(itemStack);
                    Objects.requireNonNull(value, "value from item stack " + itemStack + " is null");
                    componentExtractor.apply(value).forEach(tooltipLineConsumer);
                });
    }

    /**
     * Register an item tooltip provider.
     *
     * @param clazz    the item / block class
     * @param provider the tooltip provider
     * @param <V>      the value type
     */
    public <V extends T> void registerItemTooltip(Class<V> clazz, Provider provider) {
        for (T value : this.getRegistry()) {
            if (clazz.isInstance(value)) {
                this.registerItemTooltip((class_1799 itemStack) -> {
                    return this.getFromItemStack(itemStack) == value;
                }, provider);
            }
        }
    }

    /**
     * Register an item tooltip provider.
     *
     * @param tagKey   the item / block tag key
     * @param provider the tooltip provider
     */
    public void registerItemTooltip(class_6862<T> tagKey, Provider provider) {
        this.registerItemTooltip((class_1799 itemStack) -> {
            T value = this.getFromItemStack(itemStack);
            return value != null && this.getRegistry().method_47983(value).method_40220(tagKey);
        }, provider);
    }

    /**
     * Register an item tooltip provider.
     *
     * @param itemStackFilter the filter for the valid item / block
     * @param provider        the tooltip provider
     */
    public void registerItemTooltip(Predicate<class_1799> itemStackFilter, Provider provider) {
        ItemTooltipCallback.EVENT.register((class_1799 itemStack, List<class_2561> tooltipLines, class_1792.class_9635 tooltipContext, @Nullable class_1657 player, class_1836 tooltipFlag) -> {
            if (tooltipContext != class_1792.class_9635.field_51353 && tooltipContext.method_59527() != null
                    && itemStackFilter.test(itemStack)) {
                int originalSize = tooltipLines.size();
                provider.appendHoverText(itemStack,
                        tooltipContext,
                        tooltipFlag,
                        player,
                        (@Nullable class_2561 component) -> {
                            if (component != null) {
                                // add lines directly below the item name
                                tooltipLines.addAll(tooltipLines.isEmpty() ? 0 : 1 + tooltipLines.size() - originalSize,
                                        ClientComponentSplitter.splitTooltipComponents(component));
                            }
                        });
            }
        });
    }

    @FunctionalInterface
    public interface Provider {

        /**
         * A tooltip provider for adding individual tooltip lines.
         *
         * @param itemStack           the item stack
         * @param tooltipContext      the tooltip item context
         * @param tooltipFlag         the tooltip flag context
         * @param player              the player viewing the tooltip
         * @param tooltipLineConsumer the tooltip line adder
         */
        void appendHoverText(class_1799 itemStack, class_1792.class_9635 tooltipContext, class_1836 tooltipFlag, @Nullable class_1657 player, Consumer<class_2561> tooltipLineConsumer);
    }
}
