package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1092;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_7775;
import net.minecraft.client.resources.model.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

public final class ModelEvents {
    public static final EventInvoker<ModifyUnbakedModel> MODIFY_UNBAKED_MODEL = EventInvoker.lookup(
            ModifyUnbakedModel.class);
    public static final EventInvoker<ModifyBakedModel> MODIFY_BAKED_MODEL = EventInvoker.lookup(ModifyBakedModel.class);
    public static final EventInvoker<AddAdditionalBakedModel> ADD_ADDITIONAL_BAKED_MODEL = EventInvoker.lookup(
            AddAdditionalBakedModel.class);
    public static final EventInvoker<CompleteModelLoading> COMPLETE_MODEL_LOADING = EventInvoker.lookup(
            CompleteModelLoading.class);

    private ModelEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface ModifyUnbakedModel {

        /**
         * An event that runs for every unbaked model to allow for replacing the model.
         * <p>
         * Only supports top level models (meaning mainly block state models and item inventory variants) on Forge.
         * <p>
         * It is recommended for callers to cache returned models themselves, as the event runs for every single model
         * location, even when the models would match per identity.
         *
         * @param modelLocation        identifier for the unbaked model
         * @param unbakedModelSupplier the unbaked model
         * @param modelGetter          get unbaked models from the model bakery
         * @param modelAdder           add additional unbaked models that are used in the returned model (like as part
         *                             of {@link net.minecraft.class_819}s in
         *                             {@link net.minecraft.class_816} models)
         * @return {@link EventResultHolder#interrupt(Object)} to replace the unbaked model,
         *         {@link EventResultHolder#pass()} to let the original unbaked model go ahead
         */
        EventResultHolder<class_1100> onModifyUnbakedModel(class_1091 modelLocation, Supplier<class_1100> unbakedModelSupplier, Function<class_1091, class_1100> modelGetter, BiConsumer<class_2960, class_1100> modelAdder);
    }

    @FunctionalInterface
    public interface ModifyBakedModel {

        /**
         * An event that runs for every baked model to allow for replacing the model.
         * <p>
         * Only supports top level models (meaning mainly block state models and item inventory variants) on Forge.
         * <p>
         * It is recommended for callers to cache returned models themselves, as the event runs for every single model
         * location, even when the models would match per identity.
         *
         * @param modelLocation      identifier for the baked model
         * @param bakedModelSupplier the baked model
         * @param modelBakerSupplier the model baker used for baking the model, allows for retrieving and baking unbaked
         *                           models
         * @param modelGetter        get baked models from the bakery, if only an unbaked model is present it will be
         *                           baked automatically
         * @param modelAdder         add a baked model to the bakery, existing models cannot be replaced
         * @return {@link EventResultHolder#interrupt(Object)} to replace the baked model,
         *         {@link EventResultHolder#pass()} to let the original baked model go ahead
         */
        EventResultHolder<class_1087> onModifyBakedModel(class_1091 modelLocation, Supplier<class_1087> bakedModelSupplier, Supplier<class_7775> modelBakerSupplier, Function<class_1091, class_1087> modelGetter, BiConsumer<class_1091, class_1087> modelAdder);
    }

    @FunctionalInterface
    public interface AddAdditionalBakedModel {

        /**
         * An event that allows for adding baked models that will be available via
         * {@link class_1092#method_4742(class_1091)} after baking has completed. Mainly useful for storing
         * custom baked models in the model manager.
         * <p>
         * Cannot be used for replacing baked models in the bakery, use {@link ModifyBakedModel} for that.
         *
         * @param modelAdder         add a baked model to the bakery, existing models cannot be replaced
         * @param modelGetter        get baked models from the bakery, if only an unbaked model is present it will be
         *                           baked automatically
         * @param modelBakerSupplier the model baker used for baking the model, allows for retrieving and baking unbaked
         *                           models
         */
        void onAddAdditionalBakedModel(BiConsumer<class_1091, class_1087> modelAdder, Function<class_1091, class_1087> modelGetter, Supplier<class_7775> modelBakerSupplier);
    }

    @FunctionalInterface
    public interface CompleteModelLoading {

        /**
         * Fired after the resource manager has reloaded models.
         * <p>
         * Use a {@link Supplier} for {@link class_1092} and {@link class_1088} to prevent an issue with loading the
         * {@link net.minecraft.class_4722} class too early on Fabric, preventing modded materials from
         * being added.
         *
         * @param modelManagerSupplier the model manager
         * @param modelBakerySupplier  the model bakery
         */
        void onCompleteModelLoading(Supplier<class_1092> modelManagerSupplier, Supplier<class_1088> modelBakerySupplier);
    }
}