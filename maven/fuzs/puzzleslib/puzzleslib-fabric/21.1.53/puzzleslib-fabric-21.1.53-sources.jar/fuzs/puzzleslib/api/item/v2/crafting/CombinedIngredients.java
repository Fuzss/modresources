package fuzs.puzzleslib.api.item.v2.crafting;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1935;
import net.minecraft.class_9326;

/**
 * A helper class for obtaining platform specific {@link class_1856} implementations.
 * <p>Note that when using those ingredients in recipes not all ingredients might serialize to a vanilla-compatible
 * format, meaning they will not be readable on other mod loaders as well.
 */
public interface CombinedIngredients {
    CombinedIngredients INSTANCE = ProxyImpl.get().getCombinedIngredients();

    /**
     * Creates an ingredient that matches when its sub-ingredients all match.
     *
     * @param ingredients the sub-ingredients
     * @return the compound ingredient
     */
    class_1856 all(class_1856... ingredients);

    /**
     * Creates an ingredient that matches when any of its sub-ingredients matches.
     *
     * @param ingredients the sub-ingredients
     * @return the compound ingredient
     */
    class_1856 any(class_1856... ingredients);

    /**
     * Creates an ingredient that matches if its base ingredient matches, and its subtracted ingredient <strong>does
     * not</strong> match.
     *
     * @param ingredient the ingredient that must match
     * @param subtracted the ingredient that cannot match
     * @return the compound ingredient
     */
    class_1856 difference(class_1856 ingredient, class_1856 subtracted);

    /**
     * Creates an ingredient that matches the passed template item and data components.
     *
     * @param item       the item to match
     * @param components the data components to match
     * @return the compound ingredient
     */
    default class_1856 components(class_1935 item, class_9326 components) {
        Objects.requireNonNull(item, "item is null");
        Objects.requireNonNull(components, "components is null");
        class_1799 itemStack = new class_1799(item);
        itemStack.method_57366(components);
        return this.components(itemStack);
    }

    /**
     * Creates an ingredient that matches the passed template item stack, including data components.
     * <p>
     * Note that the count of the stack is ignored.
     *
     * @param itemStack the item stack to construct an ingredient from
     * @return the compound ingredient
     */
    class_1856 components(class_1799 itemStack);
}
