package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import net.minecraft.class_1282;
import net.minecraft.class_1309;

@FunctionalInterface
public interface LivingHurtCallback {
    EventInvoker<LivingHurtCallback> EVENT = EventInvoker.lookup(LivingHurtCallback.class);

    /**
     * Called right before any reduction on damage due to e.g. armor are done, cancelling prevents any damage / armor
     * durability being taken.
     * <p>
     * This event runs at the beginning of {@link class_1309#method_6074(class_1282, float)}.
     *
     * @param entity       the entity being hurt
     * @param damageSource damage source entity is hurt by
     * @param damageAmount amount hurt, can be modified and will only be applied when the event is not interrupted
     * @return {@link EventResult#INTERRUPT} to prevent this entity from being hurt, {@link EventResult#PASS} will make
     *         vanilla continue to execute
     */
    EventResult onLivingHurt(class_1309 entity, class_1282 damageSource, MutableFloat damageAmount);
}
