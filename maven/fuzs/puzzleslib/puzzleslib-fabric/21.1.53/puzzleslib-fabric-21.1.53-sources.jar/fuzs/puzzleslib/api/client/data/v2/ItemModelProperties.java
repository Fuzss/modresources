package fuzs.puzzleslib.api.client.data.v2;

import com.google.common.collect.Maps;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4944;
import net.minecraft.class_4945;

public record ItemModelProperties(class_2960 modelLocation, Map<class_2960, Float> modelPredicates) {

    public ItemModelProperties(class_2960 modelLocation) {
        this(modelLocation, Maps.newLinkedHashMap());
    }

    public ItemModelProperties put(class_2960 modelPropertyLocation, float modelPropertyValue) {
        this.modelPredicates.put(modelPropertyLocation, modelPropertyValue);
        return this;
    }

    public static ItemModelProperties singleOverride(class_2960 modelLocation, class_2960 modelPropertyLocation, float modelPropertyValue) {
        return new ItemModelProperties(modelLocation).put(modelPropertyLocation, modelPropertyValue);
    }

    public static ItemModelProperties twoOverrides(class_2960 modelLocation, class_2960 modelPropertyLocation1, float modelPropertyValue1, class_2960 modelPropertyLocation2, float modelPropertyValue2) {
        return new ItemModelProperties(modelLocation).put(modelPropertyLocation1, modelPropertyValue1).put(modelPropertyLocation2, modelPropertyValue2);
    }

    public static ItemModelProperties threeOverrides(class_2960 modelLocation, class_2960 modelPropertyLocation1, float modelPropertyValue1, class_2960 modelPropertyLocation2, float modelPropertyValue2, class_2960 modelPropertyLocation3, float modelPropertyValue3) {
        return new ItemModelProperties(modelLocation).put(modelPropertyLocation1, modelPropertyValue1).put(modelPropertyLocation2, modelPropertyValue2).put(modelPropertyLocation3, modelPropertyValue3);
    }

    /**
     * Use in conjunction with {@link class_4942#method_48525(class_2960, class_4944, BiConsumer, class_4942.class_8073)}.
     */
    public static class_4942.class_8073 overridesFactory(class_4942 modelTemplate, ItemModelProperties... allItemModelOverrides) {
        return (class_2960 resourceLocation, Map<class_4945, class_2960> map) -> {
            JsonObject jsonObject = modelTemplate.method_48524(resourceLocation, map);
            JsonArray jsonArray = new JsonArray();
            for (ItemModelProperties itemModelProperties : allItemModelOverrides) {
                jsonArray.add(itemModelProperties.toJson());
            }
            jsonObject.add("overrides", jsonArray);
            return jsonObject;
        };
    }

    JsonElement toJson() {
        JsonObject jsonObject = new JsonObject();
        JsonObject predicates = new JsonObject();
        for (Map.Entry<class_2960, Float> entry : this.modelPredicates.entrySet()) {
            predicates.addProperty(entry.getKey().toString(), entry.getValue());
        }
        jsonObject.add("predicate", predicates);
        jsonObject.addProperty("model", this.modelLocation.toString());
        return jsonObject;
    }
}
