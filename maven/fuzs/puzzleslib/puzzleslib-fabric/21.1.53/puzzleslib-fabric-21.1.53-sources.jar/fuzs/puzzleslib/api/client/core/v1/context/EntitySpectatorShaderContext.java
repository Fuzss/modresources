package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_2960;

/**
 * register a custom shader that is applied when spectating a certain entity type
 */
@FunctionalInterface
public interface EntitySpectatorShaderContext {

    /**
     * Register the custom shader.
     *
     * @param shaderLocation location to the shader file, usually <code>shaders/post/&lt;file&gt;.json</code>
     * @param entityTypes        entity types being spectated
     */
    void registerSpectatorShader(class_2960 shaderLocation, class_1299<?>... entityTypes);
}
