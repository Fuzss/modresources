package fuzs.puzzleslib.api.util.v1;

import com.google.common.collect.Maps;
import org.joml.Quaternionf;
import org.joml.Vector3d;

import java.util.EnumMap;
import java.util.Map;
import java.util.function.IntFunction;
import java.util.stream.IntStream;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_259;
import net.minecraft.class_265;

/**
 * A simple helper class for {@link class_265}, mainly used for applying rotations.
 */
public final class ShapesHelper {

    private ShapesHelper() {
        // NO-OP
    }

    /**
     * Returns a map with the provided {@link class_265} rotated in all six {@link class_2350 Directions}.
     * <p>
     * Note that the provided shape is assumed to be facing {@link class_2350#field_11036}, meaning providing {@link class_2350#field_11036}
     * will return the original shape.
     *
     * @param voxelShape the voxel shape to rotate
     * @return the rotated shapes
     */
    public static Map<class_2350, class_265> rotate(class_265 voxelShape) {
        Map<class_2350, class_265> shapes = new EnumMap<>(class_2350.class);
        for (class_2350 direction : class_2350.values()) {
            shapes.put(direction, rotate(direction.method_23224(), voxelShape));
        }
        return Maps.immutableEnumMap(shapes);
    }

    /**
     * Returns a map with the provided {@link class_265} rotated in all four horizontal {@link class_2350 Directions}.
     * <p>
     * Note that the provided shape is assumed to be facing {@link class_2350#field_11035}, meaning providing
     * {@link class_2350#field_11035} will return the original shape.
     *
     * @param voxelShape the voxel shape to rotate
     * @return the rotated shapes
     */
    public static Map<class_2350, class_265> rotateHorizontally(class_265 voxelShape) {
        Map<class_2350, class_265> shapes = new EnumMap<>(class_2350.class);
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            Quaternionf rotation = getHorizontalRotation(direction);
            shapes.put(direction, rotate(rotation, voxelShape));
        }
        return Maps.immutableEnumMap(shapes);
    }

    /**
     * Computes a quaternion for a horizontal direction.
     * <p>
     * Providing {@link class_2350#field_11035} will return an identity.
     *
     * @param direction the direction
     * @return the quaternion
     */
    public static Quaternionf getHorizontalRotation(class_2350 direction) {
        return new Quaternionf().rotationY((float) Math.atan2(direction.method_10148(), direction.method_10165()));
    }

    /**
     * Rotates a provided {@link class_265} depending on the provided {@link Quaternionf}.
     * <p>
     * The implementation assumes the provided shape to be offset from the origin by {@code x=0.5}, {@code y=0.5},
     * {@code z=0.5}. This is the case for all block shapes.
     *
     * @param rotation   the rotation to apply
     * @param voxelShape the voxel shape to rotate to
     * @return the rotated shape
     */
    public static class_265 rotate(Quaternionf rotation, class_265 voxelShape) {
        return rotate(rotation, voxelShape, new Vector3d(0.5, 0.5, 0.5));
    }

    /**
     * Rotates a provided {@link class_265} depending on the provided {@link Quaternionf}.
     * <p>
     * Also for the algorithm to work the shape must be centered on the origin, if it is not already, the current offset
     * must be provided, which is {@code x=0.5}, {@code y=0.5}, {@code z=0.5} for block shapes.
     *
     * @param rotation     the rotation to apply
     * @param voxelShape   the voxel shape to rotate to
     * @param originOffset offset from the origin at {@code x=0.0}, {@code y=0.0}, {@code z=0.0}
     * @return the rotated shape
     */
    public static class_265 rotate(Quaternionf rotation, class_265 voxelShape, Vector3d originOffset) {
        class_265[] joinedVoxelShape = new class_265[]{class_259.method_1073()};
        voxelShape.method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
            Vector3d start = rotation.transform(new Vector3d(minX, minY, minZ).sub(originOffset)).add(originOffset);
            Vector3d end = rotation.transform(new Vector3d(maxX, maxY, maxZ).sub(originOffset)).add(originOffset);
            joinedVoxelShape[0] = class_259.method_1084(joinedVoxelShape[0], box(start.x, start.y, start.z, end.x, end.y, end.z));
        });
        return joinedVoxelShape[0];
    }

    /**
     * Constructs a new {@link class_265}, just like
     * {@link class_259#method_1081(double, double, double, double, double, double)}, but in contrast properly sorts start and end
     * coordinates automatically.
     * <p>
     * Values should ideally range from {@code 0.0} to {@code 1.0}.
     *
     * @param startX start x coordinate
     * @param startY start y coordinate
     * @param startZ start z coordinate
     * @param endX   end x coordinate
     * @param endY   end y coordinate
     * @param endZ   end z coordinate
     * @return the new shape
     */
    public static class_265 box(double startX, double startY, double startZ, double endX, double endY, double endZ) {
        return class_259.method_1081(Math.min(startX, endX),
                Math.min(startY, endY),
                Math.min(startZ, endZ),
                Math.max(startX, endX),
                Math.max(startY, endY),
                Math.max(startZ, endZ));
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265[] boxes(int endInclusive, IntFunction<class_265> voxelShapeFactory) {
        return IntStream.rangeClosed(0, endInclusive).mapToObj(voxelShapeFactory).toArray(class_265[]::new);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 cube(double size) {
        return cube(size, size, size);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 cube(double sizeX, double sizeY, double sizeZ) {
        double halfY = sizeY / 2.0;
        return column(sizeX, sizeZ, 8.0 - halfY, 8.0 + halfY);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 column(double sizeXZ, double minY, double maxY) {
        return column(sizeXZ, sizeXZ, minY, maxY);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 column(double sizeX, double sizeZ, double minY, double maxY) {
        double halfX = sizeX / 2.0;
        double halfZ = sizeZ / 2.0;
        return class_2248.method_9541(8.0 - halfX, minY, 8.0 - halfZ, 8.0 + halfX, maxY, 8.0 + halfZ);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 boxZ(double sizeXY, double minZ, double maxZ) {
        return boxZ(sizeXY, sizeXY, minZ, maxZ);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 boxZ(double sizeX, double sizeY, double minZ, double maxZ) {
        double halfY = sizeY / 2.0;
        return boxZ(sizeX, 8.0 - halfY, 8.0 + halfY, minZ, maxZ);
    }

    /**
     * Copied from Minecraft 26.1.
     */
    public static class_265 boxZ(double sizeX, double minY, double maxY, double minZ, double maxZ) {
        double halfX = sizeX / 2.0;
        return class_2248.method_9541(8.0 - halfX, minY, minZ, 8.0 + halfX, maxY, maxZ);
    }
}
