package fuzs.puzzleslib.api.client.renderer.v1.model.geom;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Copied from Minecraft 1.21.10.
 */
public class ModelPart extends net.minecraft.class_630 {

    public ModelPart(List<class_628> cubes, Map<String, ModelPart> children) {
        super(cubes, (Map<String, net.minecraft.class_630>) (Map<?, ?>) children);
    }

    public ModelPart(net.minecraft.class_630 modelPart) {
        this(modelPart.field_3663,
                modelPart.field_3661.entrySet()
                        .stream()
                        .collect(Collectors.toMap(Map.Entry::getKey,
                                (Map.Entry<String, net.minecraft.class_630> entry) -> {
                                    return new ModelPart(entry.getValue());
                                })));
    }

    @Override
    public PartPose method_32084() {
        return PartPose.method_32091(this.field_3657, this.field_3656, this.field_3655, this.field_3654, this.field_3675, this.field_3674);
    }

    @Override
    public PartPose method_41921() {
        return (PartPose) super.method_41921();
    }

    @Override
    public void method_41918(net.minecraft.class_5603 initialPose) {
        super.method_41918(initialPose instanceof PartPose ? initialPose : new PartPose(initialPose));
    }

    @Override
    public void method_32085(net.minecraft.class_5603 partPose) {
        super.method_32085(partPose);
        if (partPose instanceof PartPose) {
            this.field_37938 = ((PartPose) partPose).xScale;
            this.field_37939 = ((PartPose) partPose).yScale;
            this.field_37940 = ((PartPose) partPose).zScale;
        }
    }
}
