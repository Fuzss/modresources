package fuzs.puzzleslib.api.network.v3.codec;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.joml.Vector3f;

import java.time.Instant;
import java.util.BitSet;
import java.util.Date;
import java.util.function.IntFunction;
import java.util.function.ToIntFunction;
import net.minecraft.class_1799;
import net.minecraft.class_1923;
import net.minecraft.class_243;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3965;
import net.minecraft.class_5321;
import net.minecraft.class_7995;
import net.minecraft.class_8824;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

/**
 * A few additional more or less useful stream codecs.
 */
public final class ExtraStreamCodecs {
    /**
     * {@link Character} stream codec
     */
    public static final class_9139<ByteBuf, Character> CHAR = class_9139.method_56437((ByteBuf buf, Character character) -> {
        buf.writeChar(character);
    }, ByteBuf::readChar);
    /**
     * {@link Date} stream codec
     */
    public static final class_9139<class_2540, Date> DATE = class_9139.method_56437(class_2540::method_10796,
            class_2540::method_10802
    );
    /**
     * {@link Instant} stream codec
     */
    public static final class_9139<class_2540, Instant> INSTANT = class_9139.method_56437(class_2540::method_44115,
            class_2540::method_44118
    );
    /**
     * {@link class_1923} stream codec
     */
    public static final class_9139<class_2540, class_1923> CHUNK_POS = class_9139.method_56437(
            class_2540::method_36130, class_2540::method_36133);
    /**
     * {@link class_3965} stream codec
     */
    public static final class_9139<class_2540, class_3965> BLOCK_HIT_RESULT = class_9139.method_56437(
            class_2540::method_17813, class_2540::method_17814);
    /**
     * {@link BitSet} stream codec
     */
    public static final class_9139<class_2540, BitSet> BIT_SET = class_9139.method_56437(class_2540::method_33557,
            class_2540::method_33558
    );
    /**
     * {@link class_5321} stream codec
     */
    public static final class_9139<ByteBuf, class_5321<?>> DIRECT_RESOURCE_KEY = class_9139.method_56435(
            class_2960.field_48267, class_5321::method_41185, class_2960.field_48267, class_5321::method_29177,
            (class_2960 registry, class_2960 location) -> {
                return class_5321.method_29179(class_5321.method_29180(registry), location);
            }
    );
    /**
     * {@link class_243} stream codec
     */
    public static final class_9139<ByteBuf, class_243> VEC3 = class_9139.method_56436(class_9135.field_48553, class_243::method_10216,
            class_9135.field_48553, class_243::method_10214, class_9135.field_48553, class_243::method_10215, class_243::new
    );
    /**
     * {@link Vector3f} stream codec
     */
    public static final class_9139<ByteBuf, Vector3f> VECTOR3F = class_9139.method_56436(class_9135.field_48552,
            Vector3f::x, class_9135.field_48552, Vector3f::y, class_9135.field_48552, Vector3f::z, Vector3f::new
    );
    /**
     * {@link class_2540} stream codec
     */
    public static final class_9139<class_2540, class_2540> FRIENDLY_BYTE_BUF = new class_9139<>() {

        @Override
        public class_2540 decode(class_2540 buf) {
            class_2540 newBuf = new class_2540(Unpooled.buffer());
            newBuf.method_52975(buf.copy());
            buf.method_52994(buf.readableBytes());
            return newBuf;
        }

        @Override
        public void encode(class_2540 buf, class_2540 toEncode) {
            buf.method_52975(toEncode.copy());
            toEncode.release();
        }
    };
    /**
     * {@link class_9129} stream codec
     */
    public static final class_9139<class_9129, class_9129> REGISTRY_FRIENDLY_BYTE_BUF = new class_9139<>() {

        @Override
        public class_9129 decode(class_9129 buf) {
            class_9129 newBuf = new class_9129(Unpooled.buffer(), buf.method_56349());
            newBuf.method_52975(buf.copy());
            buf.method_52994(buf.readableBytes());
            return newBuf;
        }

        @Override
        public void encode(class_9129 buf, class_9129 toEncode) {
            buf.method_52975(toEncode.copy());
            toEncode.release();
        }
    };

    private ExtraStreamCodecs() {
        // NO-OP
    }

    /**
     * Create an {@link Enum} stream codec.
     *
     * @param clazz the enum class
     * @param <E>   the enum type
     * @return the stream codec
     */
    public static <E extends Enum<E>> class_9139<ByteBuf, E> fromEnum(Class<E> clazz) {
        return fromEnum(clazz, E::ordinal);
    }

    /**
     * Create an {@link Enum} stream codec.
     *
     * @param clazz        the enum class
     * @param keyExtractor the numeric key extractor
     * @param <E>          the enum type
     * @return the stream codec
     */
    public static <E extends Enum<E>> class_9139<ByteBuf, E> fromEnum(Class<E> clazz, ToIntFunction<E> keyExtractor) {
        IntFunction<E> idMapper = class_7995.method_47914(keyExtractor, clazz.getEnumConstants(),
                class_7995.class_7996.field_41664
        );
        return class_9135.method_56375(idMapper, keyExtractor);
    }

    /**
     * read {@link class_2561}
     */
    public static class_2561 readComponent(class_2540 buf) {
        return class_8824.field_49666.decode((class_9129) buf);
    }

    /**
     * write {@link class_2561}
     */
    public static void writeComponent(class_2540 buf, class_2561 component) {
        class_8824.field_49666.encode((class_9129) buf, component);
    }

    /**
     * read {@link class_1799}
     */
    public static class_1799 readItem(class_2540 buf) {
        return class_1799.field_49268.decode((class_9129) buf);
    }

    /**
     * write {@link class_1799}
     */
    public static void writeItem(class_2540 buf, class_1799 itemStack) {
        class_1799.field_49268.encode((class_9129) buf, itemStack);
    }
}
