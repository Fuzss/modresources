package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;

/**
 * Provides {@link net.minecraft.class_756#method_3166} as a functional
 * interface.
 */
@FunctionalInterface
public interface BuiltinItemRenderer {

    /**
     * Renders an item stack.
     * <p>
     * Kindly copied from Fabric Api :)
     *
     * @param itemStack          the rendered item stack
     * @param itemDisplayContext the model transformation mode
     * @param poseStack          the matrix stack
     * @param multiBufferSource  the vertex consumer provider
     * @param packedLight        packed light map coordinates
     * @param packedOverlay      the overlay UV
     */
    void renderByItem(class_1799 itemStack, class_811 itemDisplayContext, class_4587 poseStack, class_4597 multiBufferSource, int packedLight, int packedOverlay);
}
