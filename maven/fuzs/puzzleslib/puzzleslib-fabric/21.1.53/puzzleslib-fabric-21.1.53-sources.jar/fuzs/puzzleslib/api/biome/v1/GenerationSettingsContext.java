package fuzs.puzzleslib.api.biome.v1;

import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_5321;
import net.minecraft.class_6796;
import net.minecraft.class_6880;

/**
 * The modification context for the biomes generation settings.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext$WeatherContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
public interface GenerationSettingsContext {
    /**
     * Removes a feature from one of this biomes generation steps, and returns if any features were removed.
     */
    boolean removeFeature(class_2893.class_2895 step, class_5321<class_6796> featureKey);

    /**
     * Removes a feature from all of this biomes generation steps, and returns if any features were removed.
     */
    default boolean removeFeature(class_5321<class_6796> featureKey) {
        boolean anyFound = false;

        for (class_2893.class_2895 step : class_2893.class_2895.values()) {
            if (this.removeFeature(step, featureKey)) {
                anyFound = true;
            }
        }

        return anyFound;
    }

    /**
     * Adds a feature to one of this biomes generation steps, identified by the placed feature's registry key.
     */
    void addFeature(class_2893.class_2895 step, class_5321<class_6796> featureKey);

    /**
     * Adds a configured carver to one of this biomes generation steps.
     */
    void addCarver(class_2893.class_2894 step, class_5321<class_2922<?>> carverKey);

    /**
     * Removes all carvers with the given key from one of this biomes generation steps.
     *
     * @return True if any carvers were removed.
     */
    boolean removeCarver(class_2893.class_2894 step, class_5321<class_2922<?>> carverKey);

    /**
     * Removes all carvers with the given key from all of this biomes generation steps.
     *
     * @return True if any carvers were removed.
     */
    default boolean removeCarver(class_5321<class_2922<?>> carverKey) {
        boolean anyFound = false;

        for (class_2893.class_2894 step : class_2893.class_2894.values()) {
            if (this.removeCarver(step, carverKey)) {
                anyFound = true;
            }
        }

        return anyFound;
    }

    /**
     * @param stage decoration stage
     * @return all features registered for the given <code>stage</code>
     */
    Iterable<class_6880<class_6796>> getFeatures(class_2893.class_2895 stage);

    /**
     * @param stage carving stage
     * @return all carvers registered for the given <code>stage</code>
     */
    Iterable<class_6880<class_2922<?>>> getCarvers(class_2893.class_2894 stage);
}
