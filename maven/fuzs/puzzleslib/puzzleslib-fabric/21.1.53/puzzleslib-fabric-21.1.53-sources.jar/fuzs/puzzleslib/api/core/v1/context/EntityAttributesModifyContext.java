package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_6880;

/**
 * Registers modifications to attributes of already existing entities.
 */
@Deprecated
public interface EntityAttributesModifyContext {

    /**
     * Modify attributes of existing entity types.
     * <p>
     * This overrides or adds attributes individually.
     *
     * @param entityType the entity type
     * @param attribute  attribute to override or add
     */
    default void registerAttributeModification(class_1299<? extends class_1309> entityType, class_6880<class_1320> attribute) {
        this.registerAttributeModification(entityType, attribute, attribute.comp_349().method_6169());
    }

    /**
     * Modify attributes of existing entity types.
     * <p>
     * This overrides or adds attributes individually.
     *
     * @param entityType     the entity type
     * @param attribute      attribute to override or add
     * @param attributeValue new value, possibly {@link class_1320#method_6169()}
     */
    void registerAttributeModification(class_1299<? extends class_1309> entityType, class_6880<class_1320> attribute, double attributeValue);
}
