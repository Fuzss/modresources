package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;

/**
 * Register various block transformations triggered by right-clicking with certain vanilla tools.
 */
@Deprecated
public interface BlockInteractionsContext {

    /**
     * A conversion usually used for removing the bark from log or wood blocks. Requires an axe.
     *
     * @param strippedBlock    the block after stripping
     * @param unstrippedBlocks the block before stripping
     */
    void registerStrippable(class_2248 strippedBlock, class_2248... unstrippedBlocks);

    /**
     * A conversion usually used for removing oxidation from copper blocks. Requires an axe.
     *
     * @param scrapedBlock    the block after scraping
     * @param unscrapedBlocks the block before scraping
     */
    void registerScrapeable(class_2248 scrapedBlock, class_2248... unscrapedBlocks);

    /**
     * A conversion usually used for removing wax from copper blocks. Requires an axe.
     *
     * @param unwaxedBlock the block before waxing
     * @param waxedBlocks  the block after waxing
     */
    void registerWaxable(class_2248 unwaxedBlock, class_2248... waxedBlocks);

    /**
     * A conversion usually used for turning dirt blocks into dirt path. Requires a shovel.
     *
     * @param flattenedBlock    the block after flattening
     * @param unflattenedBlocks the block before flattening
     */
    default void registerFlattenable(class_2248 flattenedBlock, class_2248... unflattenedBlocks) {
        this.registerFlattenable(flattenedBlock.method_9564(), unflattenedBlocks);
    }

    /**
     * A conversion usually used for turning dirt-like blocks into dirt path. Requires a shovel.
     *
     * @param flattenedBlock    the block after flattening
     * @param unflattenedBlocks the block before flattening
     */
    void registerFlattenable(class_2680 flattenedBlock, class_2248... unflattenedBlocks);

    /**
     * A conversion usually used for turning dirt-like blocks into farmland. Requires a hoe.
     * <p>An air block is required above the untilled block.
     *
     * @param tilledBlock    the block after tilling
     * @param untilledBlocks the block before tilling
     */
    default void registerTillable(class_2248 tilledBlock, class_2248... untilledBlocks) {
        this.registerTillable(tilledBlock.method_9564(), null, true, untilledBlocks);
    }

    /**
     * A conversion usually used for turning dirt-like blocks into farmland. Requires a hoe.
     * <p>No air block is required above the untilled block.
     *
     * @param tilledBlock    the block after tilling
     * @param droppedItem    a potential item dropped during the tilling interaction
     * @param untilledBlocks the block before tilling
     */
    default void registerTillable(class_2248 tilledBlock, @Nullable class_1935 droppedItem, class_2248... untilledBlocks) {
        this.registerTillable(tilledBlock.method_9564(), droppedItem, false, untilledBlocks);
    }

    /**
     * A conversion usually used for turning dirt-like blocks into farmland. Requires a hoe.
     *
     * @param tilledBlock    the block after tilling
     * @param droppedItem    a potential item dropped during the tilling interaction
     * @param onlyIfAirAbove is an air block required above the untilled block for the interaction to be possible
     * @param untilledBlocks the block before tilling
     */
    void registerTillable(class_2680 tilledBlock, @Nullable class_1935 droppedItem, boolean onlyIfAirAbove, class_2248... untilledBlocks);
}
