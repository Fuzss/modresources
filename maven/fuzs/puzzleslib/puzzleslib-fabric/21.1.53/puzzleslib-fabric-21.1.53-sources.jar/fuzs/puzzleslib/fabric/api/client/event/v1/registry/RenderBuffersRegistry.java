package fuzs.puzzleslib.fabric.api.client.event.v1.registry;

import fuzs.puzzleslib.fabric.impl.client.event.RenderBuffersRegistryImpl;
import net.minecraft.class_1921;
import net.minecraft.class_9799;

/**
 * Register a render buffer for a {@link class_1921} that is added in {@link net.minecraft.class_4599#class_4599(int)}.
 */
public interface RenderBuffersRegistry {
    /**
     * The singleton instance of the decorator registry.
     * Use this instance to call the methods in this interface.
     */
    RenderBuffersRegistry INSTANCE = new RenderBuffersRegistryImpl();

    /**
     * Registers a render buffer for the specified render type.
     *
     * @param renderType a render type of the render buffer
     */
    default void register(class_1921 renderType) {
        this.register(renderType, new class_9799(renderType.method_22722()));
    }

    /**
     * Registers a render buffer for the specified render type.
     *
     * @param renderType   a render type of the render buffer
     * @param renderBuffer a render buffer to register
     */
    void register(class_1921 renderType, class_9799 renderBuffer);
}
