package fuzs.puzzleslib.api.client.gui.v2.components;

import net.minecraft.class_2561;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_5244;

/**
 * An extension to {@link class_357} that supports values within any range, therefore requiring minimum and
 * maximum bounds to be specified.
 */
public abstract class RangedSliderButton extends class_357 {
    /**
     * Lower value bound.
     */
    protected final double minValue;
    /**
     * Upper value bound.
     */
    protected final double maxValue;

    /**
     * @param x        x position on the screen
     * @param y        y position on the screen
     * @param width    slider width
     * @param height   slider height
     * @param value    initial slider value
     * @param minValue lower value bound, used for scaling the value
     * @param maxValue upper value bound, used for scaling the value
     */
    public RangedSliderButton(int x, int y, int width, int height, double value, double minValue, double maxValue) {
        super(x, y, width, height, class_5244.field_39003, 0.0);
        this.minValue = minValue;
        this.maxValue = maxValue;
        this.setScaledValue(value);
    }

    /**
     * Gets the value adjusted for the full range of the slider.
     *
     * @return current value
     */
    public double getScaledValue() {
        return this.getValue() * (this.maxValue - this.minValue) + this.minValue;
    }

    /**
     * Sets a new unscaled value, which is then scaled down to a percentage internally.
     *
     * @param value new value to set
     */
    public void setScaledValue(double value) {
        this.method_25347((value - this.minValue) / (this.maxValue - this.minValue));
    }

    /**
     * Gets the raw value for this slider (as a percentage), always between <code>0.0</code> and <code>1.0</code>.
     *
     * @return current value
     */
    public double getValue() {
        return this.field_22753;
    }

    /**
     * Sets the raw value for this slider (as a percentage), must be between <code>0.0</code> and <code>1.0</code>.
     * <p>
     * Copied from super class.
     *
     * @param value new value to set
     */
    private void method_25347(double value) {
        double oldValue = this.field_22753;
        this.field_22753 = class_3532.method_15350(value, 0.0F, 1.0F);
        if (oldValue != this.field_22753) {
            this.method_25344();
        }

        this.method_25346();
    }

    @Override
    protected void method_25346() {
        this.method_25355(this.getMessageFromValue(this.getScaledValue()));
    }

    @Override
    protected void method_25344() {
        this.applyValue(this.getScaledValue());
    }

    /**
     * Update the slider message after the value has changed.
     * <p>
     * Like {@link #method_25346()}, but directly sets the new message.
     *
     * @param value new value after it has changed, obtained from {@link #getValue()}
     * @return the new component to set to {@link #method_25355(class_2561)}
     */
    protected abstract class_2561 getMessageFromValue(double value);

    /**
     * Apply the value after it has changed to wherever it is being tracked.
     * <p>
     * Like {@link #method_25344()}, but with additional parameter.
     *
     * @param value new value after it has changed, obtained from {@link #getValue()}
     */
    protected abstract void applyValue(double value);
}
