package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_1657;
import net.minecraft.class_1706;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public final class AnvilEvents {
    public static final EventInvoker<Update> UPDATE = EventInvoker.lookup(Update.class);
    public static final EventInvoker<Use> USE = EventInvoker.lookup(Use.class);

    private AnvilEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Update {

        /**
         * Called before a result item is generated from the two input slots in an anvil in
         * {@link class_1706#method_24928()}.
         *
         * @param primaryItem     the item stack placed in the left anvil input slot
         * @param secondaryItem   the item stack placed in the right anvil input slot
         * @param outputItem      access to the item that will be placed in the result slot, always empty by default,
         *                        vanilla logic will be cancelled when this is no longer empty
         * @param itemName        item name entered into the anvil name text box
         * @param enchantmentCost level cost for this operation
         * @param materialCost    material repair cost for this operation
         * @param player          the player interacting with the menu
         * @return {@link EventResult#ALLOW} to set a custom result from the specified output item stack with the values
         *         specified for enchantment cost and material cost, {@link EventResult#DENY} to prevent vanilla logic
         *         from running, the output item stack will not be updated, {@link EventResult#PASS} to only listen to
         *         the event without applying any changes made to mutable value provided by the event
         */
        EventResult onAnvilUpdate(class_1799 primaryItem, class_1799 secondaryItem, MutableValue<class_1799> outputItem, @Nullable String itemName, MutableInt enchantmentCost, MutableInt materialCost, class_1657 player);
    }

    @FunctionalInterface
    public interface Use {

        /**
         * Called when the player takes the output item from an anvil, used to determine the chance by which the anvil
         * will break down one stage.
         *
         * @param player        the player interacting with the anvil
         * @param primaryItem   left input item stack
         * @param secondaryItem right input item stack
         * @param outputItem    the output stack the player is about to take
         * @param breakChance   chance for the anvil to break down one stage
         */
        void onAnvilUse(class_1657 player, class_1799 primaryItem, class_1799 secondaryItem, class_1799 outputItem, MutableFloat breakChance);
    }
}
