package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1007;
import net.minecraft.class_1299;
import net.minecraft.class_5617;
import net.minecraft.class_8685;
import net.minecraft.class_922;

@FunctionalInterface
public interface AddLivingEntityRenderLayersCallback {
    EventInvoker<AddLivingEntityRenderLayersCallback> EVENT = EventInvoker.lookup(AddLivingEntityRenderLayersCallback.class);

    /**
     * Called after entity renderers have been created, and allows for attaching new
     * {@link net.minecraft.class_3887 RenderLayers}.
     *
     * @param entityType     the entity type
     * @param entityRenderer the entity renderer
     * @param context        the entity renderer provider context
     */
    void addLivingEntityRenderLayers(class_1299<?> entityType, class_922<?, ?> entityRenderer, class_5617.class_5618 context);

    /**
     * A helper for identifying the model type of {@link class_1007}.
     *
     * @param playerRenderer the avatar renderer
     * @return the model type
     */
    static class_8685.class_7920 getPlayerModelType(class_1007 playerRenderer) {
        return playerRenderer.method_4038().field_3480 ? class_8685.class_7920.field_41122 : class_8685.class_7920.field_41123;
    }
}
