package fuzs.puzzleslib.api.item.v2;

import com.google.common.base.Suppliers;
import com.google.common.collect.Maps;
import fuzs.puzzleslib.impl.item.TierImpl;
import java.util.EnumMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_1738;
import net.minecraft.class_1741;
import net.minecraft.class_1832;
import net.minecraft.class_1856;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;

/**
 * A class containing factory methods for default {@link class_1832} and {@link class_1741} implementations.
 */
@Deprecated
public final class ItemEquipmentFactories {
    private static final class_1738.class_8051[] ARMOR_TYPES = {
            class_1738.class_8051.field_41937,
            class_1738.class_8051.field_41936,
            class_1738.class_8051.field_41935,
            class_1738.class_8051.field_41934,
            class_1738.class_8051.field_48838
    };

    private ItemEquipmentFactories() {
        // NO-OP
    }

    /**
     * Creates a new {@link class_1832}.
     *
     * @param miningLevel       the mining level of the tier, wood / gold is 0, stone is 1, iron is 2, diamond is 3,
     *                          netherite is 4
     * @param itemDurability    tool durability for this tier
     * @param miningSpeed       speed for mining blocks, wood is 2, gold is 12, stone is 4, iron is 6, diamond is 8,
     *                          netherite is 9
     * @param attackDamageBonus attack damage bonus for added on top of base item damage; this mostly depends on the
     *                          specific item, as the base value is different for each one since Minecraft 1.9
     * @param enchantability    enchantment value, wood is 15, gold is 22, stone is 5, iron is 14, diamond is 14,
     *                          netherite is 15
     * @param repairIngredient  the repair material used in an anvil for restoring item durability
     * @return the new {@link class_1832}
     */
    public static class_1832 registerTier(int miningLevel, int itemDurability, float miningSpeed, float attackDamageBonus, int enchantability, Supplier<class_1856> repairIngredient) {
        return registerTier(getVanillaMiningLevelBlockTag(miningLevel),
                itemDurability,
                miningSpeed,
                attackDamageBonus,
                enchantability,
                repairIngredient
        );
    }

    /**
     * Converts the legacy mining level value to corresponding block tag.
     * <p>
     * Supported values are as follows:
     * <ul>
     *     <li>0: Wood / Gold</li>
     *     <li>1: Stone</li>
     *     <li>2: Iron</li>
     *     <li>3: Diamond</li>
     *     <li>4: Netherite</li>
     * </ul>
     *
     * @param miningLevel legacy mining level value
     * @return incorrect for tool block tag
     */
    public static class_6862<class_2248> getVanillaMiningLevelBlockTag(int miningLevel) {
        return switch (miningLevel) {
            case 0 -> class_3481.field_49930;
            case 1 -> class_3481.field_49928;
            case 2 -> class_3481.field_49927;
            case 3 -> class_3481.field_49926;
            case 4 -> class_3481.field_49925;
            default -> throw new IllegalArgumentException("Unsupported mining level: " + miningLevel);
        };
    }

    /**
     * Creates a new {@link class_1832}.
     *
     * @param incorrectBlocksForDrops the mining level of the tier as a block tag
     * @param itemDurability          tool durability for this tier
     * @param miningSpeed             speed for mining blocks, wood is 2, gold is 12, stone is 4, iron is 6, diamond is
     *                                8, netherite is 9
     * @param attackDamageBonus       attack damage bonus for added on top of base item damage; this mostly depends on
     *                                the specific item, as the base value is different for each one since Minecraft
     *                                1.9
     * @param enchantability          enchantment value, wood is 15, gold is 22, stone is 5, iron is 14, diamond is 14,
     *                                netherite is 15
     * @param repairIngredient        the repair material used in an anvil for restoring item durability
     * @return the new {@link class_1832}
     */
    public static class_1832 registerTier(class_6862<class_2248> incorrectBlocksForDrops, int itemDurability, float miningSpeed, float attackDamageBonus, int enchantability, Supplier<class_1856> repairIngredient) {
        return new TierImpl(incorrectBlocksForDrops,
                itemDurability,
                miningSpeed,
                attackDamageBonus,
                enchantability,
                Suppliers.memoize(repairIngredient::get)
        );
    }

    /**
     * Converts the legacy protection amount values array to an armor type defense values map.
     *
     * @param protectionAmounts protection value for each slot type; order is boots, leggings, chest plate, helmet,
     *                          body
     * @return armor type defense values map
     */
    public static Map<class_1738.class_8051, Integer> toArmorTypeMap(int... protectionAmounts) {
        return toArmorTypeMapWithFallback(0, protectionAmounts);
    }

    /**
     * Converts the legacy protection amount values array to an armor type defense values map.
     *
     * @param protectionAmountFallback fallback value used when armor type index is not present in proved array
     * @param protectionAmounts        protection value for each slot type; order is boots, leggings, chest plate,
     *                                 helmet, body
     * @return armor type defense values map
     */
    public static Map<class_1738.class_8051, Integer> toArmorTypeMapWithFallback(int protectionAmountFallback, int... protectionAmounts) {
        Map<class_1738.class_8051, Integer> map = new EnumMap<>(class_1738.class_8051.class);
        for (int i = 0; i < ARMOR_TYPES.length; i++) {
            map.put(ARMOR_TYPES[i], i < protectionAmounts.length ? protectionAmounts[i] : protectionAmountFallback);
        }

        return Maps.immutableEnumMap(map);
    }
}
