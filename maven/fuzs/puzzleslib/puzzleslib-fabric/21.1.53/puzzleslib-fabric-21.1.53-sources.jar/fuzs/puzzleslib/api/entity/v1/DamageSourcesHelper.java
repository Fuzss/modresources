package fuzs.puzzleslib.api.entity.v1;

import fuzs.puzzleslib.api.util.v1.DamageHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_4538;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_8110;
import org.jetbrains.annotations.Nullable;

/**
 * A small helper class for creating new {@link class_1282} instances, as vanilla's
 * {@link net.minecraft.class_8109} does not allow for creating custom damage types.
 */
@Deprecated
public final class DamageSourcesHelper {

    private DamageSourcesHelper() {
        // NO-OP
    }

    /**
     * Creates a new {@link class_1282} instance.
     *
     * @param level      registry access for retrieving dynamic {@link class_8110} registry
     * @param damageType key for finding the {@link class_8110}
     * @return new {@link class_1282} instance
     */
    public static class_1282 source(class_4538 level, class_5321<class_8110> damageType) {
        return DamageHelper.damageSource(level, damageType);
    }

    /**
     * Creates a new {@link class_1282} instance.
     *
     * @param level        registry access for retrieving dynamic {@link class_8110} registry
     * @param damageType   key for finding the {@link class_8110}
     * @param directEntity the entity directly responsible for causing damage, like the mob attacking the player, or the
     *                     arrow hitting the target
     * @return new {@link class_1282} instance
     */
    public static class_1282 source(class_4538 level, class_5321<class_8110> damageType, @Nullable class_1297 directEntity) {
        return DamageHelper.damageSource(level, damageType, directEntity);
    }

    /**
     * Creates a new {@link class_1282} instance.
     *
     * @param level         registry access for retrieving dynamic {@link class_8110} registry
     * @param damageType    key for finding the {@link class_8110}
     * @param directEntity  the entity directly responsible for causing damage, like the mob attacking the player, or
     *                      the arrow hitting the target
     * @param causingEntity the entity that is responsible for <code>directEntity</code> to cause damage to the target,
     *                      like the player that shot the arrow
     * @return new {@link class_1282} instance
     */
    public static class_1282 source(class_4538 level, class_5321<class_8110> damageType, @Nullable class_1297 directEntity, @Nullable class_1297 causingEntity) {
        return DamageHelper.damageSource(level, damageType, directEntity, causingEntity);
    }

    /**
     * Creates a new {@link class_1282} instance.
     *
     * @param registryAccess registry access for retrieving dynamic {@link class_8110} registry
     * @param damageType     key for finding the {@link class_8110}
     * @param directEntity   the entity directly responsible for causing damage, like the mob attacking the player, or
     *                       the arrow hitting the target
     * @param causingEntity  the entity that is responsible for <code>directEntity</code> to cause damage to the target,
     *                       like the player that shot the arrow
     * @return new {@link class_1282} instance
     */
    public static class_1282 source(class_5455 registryAccess, class_5321<class_8110> damageType, @Nullable class_1297 directEntity, @Nullable class_1297 causingEntity) {
        return DamageHelper.damageSource(registryAccess, damageType, directEntity, causingEntity);
    }
}
