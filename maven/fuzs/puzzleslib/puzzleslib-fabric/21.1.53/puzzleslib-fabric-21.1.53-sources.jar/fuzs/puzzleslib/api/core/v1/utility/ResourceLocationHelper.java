package fuzs.puzzleslib.api.core.v1.utility;

import net.minecraft.class_2960;
import org.jetbrains.annotations.Nullable;

/**
 * A utility class providing an abstraction for {@link class_2960} creation changes in Minecraft 1.21+.
 */
@Deprecated
public final class ResourceLocationHelper {

    private ResourceLocationHelper() {
        // NO-OP
    }

    /**
     * Creates a new resource location from the provided namespace and path.
     *
     * @param namespace the namespace
     * @param path      the path
     * @return the new resource location
     */
    public static class_2960 fromNamespaceAndPath(String namespace, String path) {
        return class_2960.method_60655(namespace, path);
    }

    /**
     * Creates a new resource location from the provided path for the <code>minecraft</code> namespace.
     *
     * @param path the path
     * @return the new resource location
     */
    public static class_2960 withDefaultNamespace(String path) {
        return class_2960.method_60656(path);
    }

    /**
     * Creates a new resource location from parsing the provided input. Throws an exception when invalid characters are
     * present.
     *
     * @param location the location input
     * @return the new resource location
     */
    public static class_2960 parse(String location) {
        return class_2960.method_60654(location);
    }

    /**
     * Creates a new resource location from parsing the provided input. Returns <code>null</code> when invalid
     * characters are present.
     *
     * @param location the location input
     * @return the new resource location or null
     */
    @Nullable
    public static class_2960 tryParse(String location) {
        return class_2960.method_12829(location);
    }
}
