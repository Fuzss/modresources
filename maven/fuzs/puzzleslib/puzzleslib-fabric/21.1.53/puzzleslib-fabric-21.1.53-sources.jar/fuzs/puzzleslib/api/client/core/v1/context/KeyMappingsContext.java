package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.key.v1.KeyActivationContext;
import fuzs.puzzleslib.api.client.key.v1.KeyActivationHandler;
import net.minecraft.class_304;

/**
 * Register a {@link class_304} so it can be saved to and loaded from game options.
 */
@FunctionalInterface
public interface KeyMappingsContext {

    /**
     * Register a key mapping together for the universal activation context.
     *
     * @param keyMapping the key mapping
     */
    default void registerKeyMapping(class_304 keyMapping) {
        this.registerKeyMapping(keyMapping, KeyActivationContext.UNIVERSAL);
    }

    /**
     * Register a key mapping together with an activation context.
     *
     * @param keyMapping        the key mapping
     * @param activationContext an activation context for key mappings
     */
    default void registerKeyMapping(class_304 keyMapping, KeyActivationContext activationContext) {
        this.registerKeyMapping(keyMapping, KeyActivationHandler.direct(activationContext));
    }

    /**
     * Register a key mapping together with an activation handler.
     *
     * @param keyMapping        the key mapping
     * @param activationHandler an activation handler for key mappings
     */
    void registerKeyMapping(class_304 keyMapping, KeyActivationHandler activationHandler);
}
