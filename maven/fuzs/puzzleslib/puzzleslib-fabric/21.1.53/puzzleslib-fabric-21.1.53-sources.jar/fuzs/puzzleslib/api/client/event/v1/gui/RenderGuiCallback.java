package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

@Deprecated
@FunctionalInterface
public interface RenderGuiCallback {
    EventInvoker<RenderGuiCallback> EVENT = EventInvoker.lookup(RenderGuiCallback.class);

    /**
     * Called at the end of {@link net.minecraft.class_329#method_1753(class_332, class_9779)} after vanilla has
     * drawn all elements. Allows for rendering additional elements on the screen.
     *
     * @param minecraft    the minecraft instance
     * @param guiGraphics  the gui graphics component
     * @param deltaTracker the delta tracker, get the partial tick via
     *                     {@link class_9779#method_60637(boolean)} by passing {@code false}
     */
    void onRenderGui(class_310 minecraft, class_332 guiGraphics, class_9779 deltaTracker);
}
