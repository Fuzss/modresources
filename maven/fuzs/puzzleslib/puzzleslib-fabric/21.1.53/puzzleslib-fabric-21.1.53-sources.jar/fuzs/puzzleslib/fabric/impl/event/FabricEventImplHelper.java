package fuzs.puzzleslib.fabric.impl.event;

import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_181;
import net.minecraft.class_1887;
import net.minecraft.class_47;
import net.minecraft.class_6880;

public final class FabricEventImplHelper {

    private FabricEventImplHelper() {
        // NO-OP
    }

    public static int onAnimalTame(class_1429 animal, class_1657 player, int intValue) {
        return onAnimalTame(animal, player, intValue, 1, intValue == 0);
    }

    public static int onAnimalTame(class_1429 animal, class_1657 player, int intValue, int returnValue, boolean tameCondition) {
        if (tameCondition && FabricLivingEvents.ANIMAL_TAME.invoker().onAnimalTame(animal, player).isInterrupt()) {
            return returnValue;
        } else {
            return intValue;
        }
    }

    public static int onComputeEnchantedLootBonus(class_6880<class_1887> enchantment, int enchantmentLevel, class_47 lootContext) {
        class_1297 entity = lootContext.method_296(class_181.field_1226);
        if (!(entity instanceof class_1309 livingEntity)) return enchantmentLevel;
        class_1282 damageSource = lootContext.method_296(class_181.field_1231);
        return onComputeEnchantedLootBonus(enchantment, enchantmentLevel, livingEntity, damageSource);
    }

    public static int onComputeEnchantedLootBonus(class_6880<class_1887> enchantment, int enchantmentLevel, class_1309 livingEntity, @Nullable class_1282 damageSource) {
        MutableInt mutableInt = MutableInt.fromValue(enchantmentLevel);
        FabricLivingEvents.COMPUTE_ENCHANTED_LOOT_BONUS.invoker()
                .onComputeEnchantedLootBonus(livingEntity, damageSource, enchantment, mutableInt);
        return mutableInt.getAsInt();
    }

    public static boolean tryOnLivingDrops(class_1309 entity, class_1282 damageSource, int lastHurtByPlayerTime) {
        Collection<class_1542> capturedDrops = ((CapturedDropsEntity) entity).puzzleslib$acceptCapturedDrops(null);
        if (capturedDrops != null) {
            EventResult result = FabricLivingEvents.LIVING_DROPS.invoker()
                    .onLivingDrops(entity, damageSource, capturedDrops, lastHurtByPlayerTime > 0);
            if (result.isPass()) capturedDrops.forEach(itemEntity -> entity.method_37908().method_8649(itemEntity));
            return true;
        } else {
            return false;
        }
    }
}
