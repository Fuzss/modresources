package fuzs.puzzleslib.api.client.init.v1;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import net.minecraft.class_1091;
import net.minecraft.class_2960;
import net.minecraft.class_811;

/**
 * Allows for registering model overrides for items that have a different model in
 * {@link net.minecraft.class_918} depending on {@link class_811}. Vanilla examples:
 * <ul>
 *     <li>{@link net.minecraft.class_1802#field_8547}</li>
 *     <li>{@link net.minecraft.class_1802#field_27070}</li>
 * </ul>
 */
public interface ItemModelDisplayOverrides {
    ItemModelDisplayOverrides INSTANCE = ClientProxyImpl.get().getItemModelDisplayOverrides();

    /**
     * Register vanilla item model overrides for an item.
     * <p>
     * All display contexts except {@link class_811#field_4317 GUI}, {@link class_811#field_4318 GROUND}, and
     * {@link class_811#field_4319 FIXED} will use the override model.
     *
     * @param itemModel         the vanilla item model location
     * @param itemModelOverride the custom item model location
     */
    void register(class_1091 itemModel, class_1091 itemModelOverride);

    /**
     * Register item model overrides for an item.
     *
     * @param itemModel           the vanilla item model location
     * @param itemModelOverride   the custom item model location
     * @param itemDisplayContexts the item display contexts to use the override model for
     */
    void register(class_1091 itemModel, class_1091 itemModelOverride, class_811... itemDisplayContexts);

    /**
     * Register vanilla item model overrides for an item.
     * <p>
     * All display contexts except {@link class_811#field_4317 GUI}, {@link class_811#field_4318 GROUND}, and
     * {@link class_811#field_4319 FIXED} will use the override model.
     *
     * @param itemModel         the vanilla item model location
     * @param itemModelOverride the custom item model location
     */
    void register(class_1091 itemModel, class_2960 itemModelOverride);

    /**
     * Register item model overrides for an item.
     *
     * @param itemModel           the vanilla item model location
     * @param itemModelOverride   the custom item model location
     * @param itemDisplayContexts the item display contexts to use the override model for
     */
    void register(class_1091 itemModel, class_2960 itemModelOverride, class_811... itemDisplayContexts);
}
