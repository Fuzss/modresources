package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.RenderBuffersContext;
import fuzs.puzzleslib.fabric.api.client.event.v1.registry.RenderBuffersRegistry;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_9799;

public final class RenderBuffersContextFabricImpl implements RenderBuffersContext {

    @Override
    public void registerRenderBuffer(class_1921 renderType, class_9799 renderBuffer) {
        Objects.requireNonNull(renderType, "render type is null");
        Objects.requireNonNull(renderBuffer, "render buffer is null");
        RenderBuffersRegistry.INSTANCE.register(renderType, renderBuffer);
    }
}
