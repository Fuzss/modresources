package fuzs.puzzleslib.api.client.init.v1;

import com.google.common.collect.ImmutableMap.Builder;
import java.util.function.Function;
import net.minecraft.class_1304;
import net.minecraft.class_5599;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_572;
import net.minecraft.class_630;

public record ArmorModelSet<T>(T head, T chest, T legs, T feet) {

    public T get(class_1304 slot) {
        return (switch (slot) {
            case field_6169 -> this.head;
            case field_6174 -> this.chest;
            case field_6172 -> this.legs;
            case field_6166 -> this.feet;
            default -> throw new IllegalStateException("No model for slot: " + slot);
        });
    }

    public <U> ArmorModelSet<U> map(Function<? super T, ? extends U> mapper) {
        return new ArmorModelSet<>(mapper.apply(this.head),
                mapper.apply(this.chest),
                mapper.apply(this.legs),
                mapper.apply(this.feet));
    }

    public void putFrom(ArmorModelSet<class_5607> other, Builder<T, class_5607> builder) {
        builder.put(this.head, other.head);
        builder.put(this.chest, other.chest);
        builder.put(this.legs, other.legs);
        builder.put(this.feet, other.feet);
    }

    public static <M extends class_572<?>> ArmorModelSet<M> bake(ArmorModelSet<class_5601> armorModelSet, class_5599 entityModelSet, Function<class_630, M> baker) {
        return armorModelSet.map((class_5601 modelLayerLocation) -> {
            return baker.apply(entityModelSet.method_32072(modelLayerLocation));
        });
    }
}
