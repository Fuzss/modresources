package fuzs.puzzleslib.fabric.impl.client.core;

import fuzs.forgeconfigapiport.fabric.api.neoforge.v4.client.ConfigScreenFactoryRegistry;
import fuzs.puzzleslib.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.api.core.v1.context.PayloadTypesContext;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import fuzs.puzzleslib.fabric.impl.client.config.FabricConfigurationScreen;
import fuzs.puzzleslib.fabric.impl.client.event.FabricClientEventInvokers;
import fuzs.puzzleslib.fabric.impl.client.event.FabricGuiEventHelper;
import fuzs.puzzleslib.fabric.impl.client.init.FabricItemDisplayOverrides;
import fuzs.puzzleslib.fabric.impl.client.key.FabricKeyMappingHelper;
import fuzs.puzzleslib.fabric.impl.core.FabricCommonProxy;
import fuzs.puzzleslib.fabric.impl.core.context.PayloadTypesContextFabricImpl;
import fuzs.puzzleslib.fabric.mixin.client.accessor.MultiPlayerGameModeFabricAccessor;
import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import fuzs.puzzleslib.impl.client.init.ItemDisplayOverridesImpl;
import fuzs.puzzleslib.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.impl.network.codec.CustomPacketPayloadAdapter;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientConfigurationNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback;
import net.minecraft.class_1087;
import net.minecraft.class_1092;
import net.minecraft.class_1293;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2792;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3611;
import net.minecraft.class_437;
import net.minecraft.class_4696;
import net.minecraft.class_4719;
import net.minecraft.class_4722;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_777;
import net.minecraft.class_8000;
import net.minecraft.class_8673;
import net.minecraft.class_8674;
import net.minecraft.class_8709;
import net.minecraft.class_8710;
import org.jetbrains.annotations.MustBeInvokedByOverriders;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntFunction;

public class FabricClientProxy extends FabricCommonProxy implements ClientProxyImpl {

    @Override
    public void registerAllLoadingHandlers() {
        super.registerAllLoadingHandlers();
        FabricClientEventInvokers.registerLoadingHandlers();
    }

    @Override
    public void registerAllEventHandlers() {
        super.registerAllEventHandlers();
        FabricClientEventInvokers.registerEventHandlers();
    }

    @Override
    public boolean hasChannel(class_2547 packetListener, class_8710.class_9154<?> type) {
        if (super.hasChannel(packetListener, type)) {
            return true;
        } else if (packetListener instanceof class_8674) {
            return ClientConfigurationNetworking.canSend(type);
        } else if (packetListener instanceof class_634) {
            return ClientPlayNetworking.canSend(type);
        } else {
            return false;
        }
    }

    @Override
    public class_2535 getConnection(class_2547 packetListener) {
        return packetListener instanceof class_8673 clientPacketListener ?
                clientPacketListener.field_45589 : super.getConnection(packetListener);
    }

    @Override
    public PayloadTypesContext createPayloadTypesContext(String modId) {
        return new PayloadTypesContextFabricImpl.ClientImpl(modId);
    }

    @Override
    public <M1, M2> void registerClientReceiver(class_8710.class_9154<CustomPacketPayloadAdapter<M1>> type, BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally, Function<M1, ClientboundMessage<M2>> messageAdapter) {
        ClientPlayNetworking.registerGlobalReceiver(type,
                (CustomPacketPayloadAdapter<M1> payload, ClientPlayNetworking.Context context) -> {
                    try {
                        Objects.requireNonNull(context.player(), "player is null");
                        ClientboundMessage<M2> message = messageAdapter.apply(payload.unwrap());
                        message.getHandler()
                                .handle(message.unwrap(),
                                        context.client(),
                                        context.player().field_3944,
                                        context.player(),
                                        context.client().field_1687);
                    } catch (Throwable throwable) {
                        disconnectExceptionally.accept(throwable, context.responseSender()::disconnect);
                    }
                });
    }

    @Override
    public void setupHandshakePayload(class_8710.class_9154<class_8709> payloadType) {
        super.setupHandshakePayload(payloadType);
        ClientPlayNetworking.registerGlobalReceiver(payloadType,
                (class_8709 payload, ClientPlayNetworking.Context context) -> {
                    // NO-OP
                });
    }

    @Override
    public boolean shouldStartDestroyBlock(class_2338 blockPos) {
        MultiPlayerGameModeFabricAccessor gameMode = (MultiPlayerGameModeFabricAccessor) class_310.method_1551().field_1761;
        return !gameMode.puzzleslib$getIsDestroying() || !gameMode.puzzleslib$callSameDestroyTarget(blockPos);
    }

    @Override
    public void startClientPrediction(class_1937 level, IntFunction<class_2596<class_2792>> predictiveAction) {
        ((MultiPlayerGameModeFabricAccessor) class_310.method_1551().field_1761).puzzleslib$callStartPrediction((class_638) level,
                predictiveAction::apply);
    }

    @Override
    public ModConstructorImpl<ClientModConstructor> getClientModConstructorImpl() {
        return new FabricClientModConstructor();
    }

    @Override
    public ItemDisplayOverridesImpl<?> getItemModelDisplayOverrides() {
        return new FabricItemDisplayOverrides();
    }

    @Override
    public KeyMappingHelper getKeyMappingActivationHelper() {
        return new FabricKeyMappingHelper();
    }

    @Override
    public boolean isKeyActiveAndMatches(class_304 keyMapping, int keyCode, int scanCode) {
        return keyMapping.method_1417(keyCode, scanCode);
    }

    @Override
    public class_5684 createImageComponent(class_5632 imageComponent) {
        class_5684 component = TooltipComponentCallback.EVENT.invoker().getComponent(imageComponent);
        return Objects.requireNonNullElseGet(component, () -> class_5684.method_32663(imageComponent));
    }

    @Override
    public boolean onRenderTooltip(class_332 guiGraphics, class_327 font, int mouseX, int mouseY, List<class_5684> components, class_8000 positioner) {
        return FabricGuiEvents.RENDER_TOOLTIP.invoker()
                .onRenderTooltip(guiGraphics, font, mouseX, mouseY, components, positioner)
                .isInterrupt();
    }

    @Override
    public class_777 copyBakedQuad(class_777 bakedQuad) {
        int[] vertices = bakedQuad.method_3357();
        return new class_777(Arrays.copyOf(vertices, vertices.length),
                bakedQuad.method_3359(),
                bakedQuad.method_3358(),
                bakedQuad.method_35788(),
                bakedQuad.method_24874());
    }

    @Override
    public boolean isEffectVisibleInInventory(class_1293 mobEffect) {
        return true;
    }

    @Override
    public boolean isEffectVisibleInGui(class_1293 mobEffect) {
        return true;
    }

    @Override
    public void registerWoodType(class_4719 woodType) {
        // this might register fine, but if another mod loads the Sheets class too early it will be missing
        // also wrap this in the event, so we ourselves do not load the Sheets class too early
        ClientLifecycleEvents.CLIENT_STARTED.register((class_310 minecraft) -> {
            class_4722.field_21712.put(woodType, class_4722.method_24064(woodType));
            class_4722.field_40515.put(woodType, class_4722.method_45782(woodType));
        });
    }

    @Override
    public class_1087 getBakedModel(class_1092 modelManager, class_2960 resourceLocation) {
        return modelManager.getModel(resourceLocation);
    }

    @Override
    public class_1921 getRenderType(class_2248 block) {
        return class_4696.method_23679(block.method_9564());
    }

    @Override
    public void registerRenderType(class_2248 block, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putBlock(block, renderType);
    }

    @Override
    public void registerRenderType(class_3611 fluid, class_1921 renderType) {
        BlockRenderLayerMap.INSTANCE.putFluid(fluid, renderType);
    }

    @Override
    public int getGuiLeftHeight(class_329 gui) {
        return FabricGuiEventHelper.getGuiLeftHeight();
    }

    @Override
    public int getGuiRightHeight(class_329 gui) {
        return FabricGuiEventHelper.getGuiRightHeight();
    }

    @Override
    public void addGuiLeftHeight(class_329 gui, int leftHeight) {
        FabricGuiEventHelper.setGuiLeftHeight(this.getGuiLeftHeight(gui) + leftHeight);
    }

    @Override
    public void addGuiRightHeight(class_329 gui, int rightHeight) {
        FabricGuiEventHelper.setGuiRightHeight(this.getGuiRightHeight(gui) + rightHeight);
    }

    @Override
    public void registerConfigurationScreen(String modId, String... otherModIds) {
        ConfigScreenFactoryRegistry.INSTANCE.register(modId, (String string, class_437 screen) -> {
            return new FabricConfigurationScreen(string, screen, otherModIds);
        });
    }

    @MustBeInvokedByOverriders
    @Override
    public void registerEventHandlers() {
        super.registerEventHandlers();
        FabricGuiEventHelper.registerEventHandlers();
    }
}
