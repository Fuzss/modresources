package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public final class RenderGuiEvents {
    public static final EventInvoker<Before> BEFORE = EventInvoker.lookup(Before.class);
    public static final EventInvoker<After> AFTER = EventInvoker.lookup(After.class);

    private RenderGuiEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Before {

        /**
         * Called at the beginning of {@link net.minecraft.class_329#method_1753(class_332, class_9779)}, before
         * vanilla has drawn any gui elements. Allows for rendering additional elements on the screen.
         *
         * @param gui          the gui instance
         * @param guiGraphics  the gui graphics component
         * @param deltaTracker the delta tracker, get the partial tick via
         *                     {@link class_9779#method_60637(boolean)} by passing {@code false}
         */
        void onBeforeRenderGui(class_329 gui, class_332 guiGraphics, class_9779 deltaTracker);
    }

    @FunctionalInterface
    public interface After {

        /**
         * Called at the end of {@link net.minecraft.class_329#method_1753(class_332, class_9779)}, after vanilla
         * has drawn all gui elements. Allows for rendering additional elements on the screen.
         *
         * @param gui          the gui instance
         * @param guiGraphics  the gui graphics component
         * @param deltaTracker the delta tracker, get the partial tick via
         *                     {@link class_9779#method_60637(boolean)} by passing {@code false}
         */
        void onAfterRenderGui(class_329 gui, class_332 guiGraphics, class_9779 deltaTracker);
    }
}
