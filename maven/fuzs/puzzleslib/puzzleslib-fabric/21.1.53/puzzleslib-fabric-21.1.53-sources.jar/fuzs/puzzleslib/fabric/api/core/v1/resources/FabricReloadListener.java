package fuzs.puzzleslib.fabric.api.core.v1.resources;

import com.google.common.collect.ImmutableSet;
import fuzs.puzzleslib.api.core.v1.resources.NamedReloadListener;
import net.fabricmc.fabric.api.resource.IdentifiableResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_3695;
import net.minecraft.class_4013;
import net.minecraft.class_4080;
import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * A helper class for registering a {@link class_3302} on Fabric without the need for it to implement {@link IdentifiableResourceReloadListener}.
 *
 * @param identifier     identifier for this reload listener
 * @param reloadListener the reload listener
 */
public record FabricReloadListener(class_2960 identifier,
                                   class_3302 reloadListener, Collection<class_2960> dependencies) implements NamedReloadListener, IdentifiableResourceReloadListener {

    public FabricReloadListener(class_2960 identifier, class_3302 reloadListener) {
        this(identifier, reloadListener, Collections.emptySet());
    }

    public FabricReloadListener(class_2960 identifier, class_4013 reloadListener) {
        this(identifier, reloadListener, Collections.emptySet());
    }

    public <T> FabricReloadListener(class_2960 identifier, class_4080<T> reloadListener) {
        this(identifier, reloadListener, Collections.emptySet());
    }

    public FabricReloadListener(NamedReloadListener reloadListener) {
        this(reloadListener, new class_2960[0]);
    }

    public FabricReloadListener(class_2960 identifier, class_3302 reloadListener, class_2960... dependencies) {
        this(identifier, reloadListener, ImmutableSet.copyOf(dependencies));
    }

    public FabricReloadListener(class_2960 identifier, class_4013 reloadListener, class_2960... dependencies) {
        this(identifier, reloadListener, ImmutableSet.copyOf(dependencies));
    }

    public <T> FabricReloadListener(class_2960 identifier, class_4080<T> reloadListener, class_2960... dependencies) {
        this(identifier, reloadListener, ImmutableSet.copyOf(dependencies));
    }

    public FabricReloadListener(NamedReloadListener reloadListener, class_2960... dependencies) {
        this(reloadListener.identifier(), reloadListener, ImmutableSet.copyOf(dependencies));
    }

    @Override
    public CompletableFuture<Void> method_25931(class_4045 preparationBarrier, class_3300 resourceManager, class_3695 preparationsProfiler, class_3695 reloadProfiler, Executor backgroundExecutor, Executor gameExecutor) {
        return this.reloadListener.method_25931(preparationBarrier, resourceManager, preparationsProfiler, reloadProfiler, backgroundExecutor, gameExecutor);
    }

    @Override
    public class_2960 getFabricId() {
        return this.identifier;
    }
}
