package fuzs.puzzleslib.fabric.impl.biome;

import com.google.common.collect.ImmutableSet;
import fuzs.puzzleslib.api.biome.v1.MobSpawnSettingsContext;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.core.v1.utility.ReflectionHelper;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

import java.lang.reflect.Field;
import java.util.*;
import java.util.function.BiPredicate;
import java.util.stream.Stream;

public record MobSpawnSettingsContextFabric(class_5483 mobSpawnSettings, BiomeModificationContext.SpawnSettingsContext context) implements MobSpawnSettingsContext {

    @Override
    public void setCreatureGenerationProbability(float probability) {
        this.context.setCreatureSpawnProbability(probability);
    }

    @Override
    public void addSpawn(class_1311 spawnGroup, class_5483.class_1964 spawnEntry) {
        this.context.addSpawn(spawnGroup, spawnEntry);
    }

    @Override
    public boolean removeSpawns(BiPredicate<class_1311, class_5483.class_1964> predicate) {
        return this.context.removeSpawns(predicate);
    }

    @Override
    public void setSpawnCost(class_1299<?> entityType, double energyBudget, double charge) {
        this.context.setSpawnCost(entityType, charge, energyBudget);
    }

    @Override
    public boolean clearSpawnCost(class_1299<?> entityType) {
        if (this.mobSpawnSettings.method_31003(entityType) != null) {
            this.context.clearSpawnCost(entityType);
            return true;
        }
        return false;
    }

    @Override
    public Set<class_1311> getMobCategoriesWithSpawns() {
        // Fabric handles MobSpawnSettings$SpawnerData in its own map, use vanilla only as a fallback in case something with the api implementation changes.
        // Also note that vanilla only represents the initial state and does not reflect any changes made while the builder is 'active', so using the fallback is not desirable (it's not a view).
        // The implementation based on the fabricSpawners field also does not provide a view, which is necessary to be able to filter out empty mob categories.
        // Otherwise, the implementation would simply return MobCategory::values.
        Optional<EnumMap<class_1311, List<class_5483.class_1964>>> optional = this.findFabricSpawners();
        return optional.map(map -> map.entrySet().stream().filter(e -> !e.getValue().isEmpty()).map(Map.Entry::getKey)).orElseGet(() -> Stream.of(class_1311.values()).filter(mobCategory -> !this.mobSpawnSettings.method_31004(mobCategory).method_34993())).collect(ImmutableSet.toImmutableSet());
    }

    @Override
    public List<class_5483.class_1964> getSpawnerData(class_1311 type) {
        // Fabric handles MobSpawnSettings$SpawnerData in its own map, use vanilla only as a fallback in case something with the api implementation changes.
        // Also note that vanilla only represents the initial state and does not reflect any changes made while the builder is 'active', so using the fallback is not desirable (it's not a view).
        Optional<EnumMap<class_1311, List<class_5483.class_1964>>> optional = this.findFabricSpawners();
        return optional.map(map -> Collections.unmodifiableList(map.get(type))).orElseGet(() -> this.mobSpawnSettings.method_31004(type).method_34994());
    }

    private Optional<EnumMap<class_1311, List<class_5483.class_1964>>> findFabricSpawners() {
        if (!ModLoaderEnvironment.INSTANCE.getModLoader().isFabric()) return Optional.empty();
        Field field = ReflectionHelper.findField("net.fabricmc.fabric.impl.biome.modification.BiomeModificationContextImpl$SpawnSettingsContextImpl", "fabricSpawners", true);
        return ReflectionHelper.getValue(field, this.context);
    }

    @Override
    public Set<class_1299<?>> getEntityTypesWithSpawnCost() {
        // be careful: does not provide a view, but a copy, so avoid caching this result
        return class_7923.field_41177.method_10220().filter(entityType -> this.mobSpawnSettings.method_31003(entityType) != null).collect(ImmutableSet.toImmutableSet());
    }

    @Override
    public @Nullable class_5483.class_5265 getSpawnCost(class_1299<?> type) {
        return this.mobSpawnSettings.method_31003(type);
    }

    @Override
    public float getCreatureGenerationProbability() {
        return this.mobSpawnSettings.method_31002();
    }
}
