package fuzs.puzzleslib.api.client.renderer.v1.model.geom.builders;

import net.minecraft.class_5608;

/**
 * Copied from Minecraft 1.21.10.
 */
public class LayerDefinition extends net.minecraft.class_5607 {
    public final MeshDefinition mesh;

    public LayerDefinition(net.minecraft.class_5607 other) {
        this(other.field_27723, other.field_27724);
    }

    public LayerDefinition(net.minecraft.class_5609 mesh, class_5608 material) {
        this(new MeshDefinition(mesh), material);
    }

    private LayerDefinition(MeshDefinition mesh, class_5608 material) {
        super(mesh, material);
        this.mesh = mesh;
    }

    public LayerDefinition apply(MeshTransformer transformer) {
        return new LayerDefinition(transformer.apply(this.mesh), this.field_27724);
    }

    public static LayerDefinition method_32110(net.minecraft.class_5609 mesh, int texWidth, int texHeight) {
        return new LayerDefinition(mesh, new class_5608(texWidth, texHeight));
    }
}
