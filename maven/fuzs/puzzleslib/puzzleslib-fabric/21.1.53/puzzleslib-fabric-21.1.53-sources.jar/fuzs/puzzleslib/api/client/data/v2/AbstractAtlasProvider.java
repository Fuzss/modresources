package fuzs.puzzleslib.api.client.data.v2;

import fuzs.puzzleslib.api.client.data.v2.models.MaterialMapper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1092;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_4730;
import net.minecraft.class_5455;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7948;
import net.minecraft.class_7952;
import net.minecraft.class_7954;
import net.minecraft.class_7955;

public abstract class AbstractAtlasProvider implements class_2405 {
    private final Map<class_2960, List<class_7948>> values = new LinkedHashMap<>();
    private final class_7784.class_7489 pathProvider;

    public AbstractAtlasProvider(DataProviderContext context) {
        this(context.getPackOutput());
    }

    public AbstractAtlasProvider(class_7784 packOutput) {
        this.pathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "atlases");
    }

    public static class_7948 forMaterial(class_4730 material) {
        return new class_7955(material.method_24147(), Optional.empty());
    }

    public static class_7948 forMapper(MaterialMapper mapper) {
        return new class_7954(mapper.prefix(), mapper.prefix() + "/");
    }

    public static List<class_7948> simpleMapper(MaterialMapper mapper) {
        return List.of(forMapper(mapper));
    }

    public static List<class_7948> noPrefixMapper(String path) {
        return List.of(new class_7954(path, ""));
    }

    @Override
    public final CompletableFuture<?> method_10319(class_7403 output) {
        this.addAtlases();
        return CompletableFuture.allOf(this.values.entrySet()
                .stream()
                .map((Map.Entry<class_2960, List<class_7948>> entry) -> {
                    return this.storeAtlas(output, entry.getKey(), entry.getValue());
                })
                .toArray(CompletableFuture[]::new));
    }

    public final CompletableFuture<?> storeAtlas(class_7403 output, class_2960 atlasId, List<class_7948> sources) {
        return class_2405.method_53496(output,
                class_5455.field_40585,
                class_7952.field_41397,
                sources,
                this.pathProvider.method_44107(atlasId));
    }

    public abstract void addAtlases();

    protected void addMaterial(class_4730 material) {
        this.add(class_1092.field_40574.get(material.method_24144()), forMaterial(material));
    }

    protected void add(class_2960 resourceLocation, class_7948... spriteSources) {
        this.add(resourceLocation, Arrays.asList(spriteSources));
    }

    protected void add(class_2960 resourceLocation, List<class_7948> spriteSources) {
        this.values.computeIfAbsent(resourceLocation, (class_2960 resourceLocationX) -> new ArrayList<>())
                .addAll(spriteSources);
    }

    @Override
    public String method_10321() {
        return "Atlas Definitions";
    }
}
