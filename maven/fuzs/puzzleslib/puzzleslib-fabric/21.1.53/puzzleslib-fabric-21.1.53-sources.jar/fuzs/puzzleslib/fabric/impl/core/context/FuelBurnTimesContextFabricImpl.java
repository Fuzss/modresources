package fuzs.puzzleslib.fabric.impl.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.context.FuelBurnTimesContext;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.class_1935;
import java.util.Objects;

@Deprecated
public final class FuelBurnTimesContextFabricImpl implements FuelBurnTimesContext {

    @Override
    public void registerFuel(int burnTime, class_1935... items) {
        Preconditions.checkArgument(burnTime >= 0, "burn time is negative");
        Preconditions.checkArgument(burnTime <= 32767, "burn time is too high");
        Objects.requireNonNull(items, "items is null");
        Preconditions.checkState(items.length > 0, "items is empty");
        for (class_1935 item : items) {
            Objects.requireNonNull(item, "item is null");
            FuelRegistry.INSTANCE.add(item.method_8389(), burnTime);
        }
    }
}
