package fuzs.puzzleslib.api.client.packs.v1;

import java.io.IOException;
import net.minecraft.class_1011;

/**
 * A helper class containing legacy {@link class_1011} methods.
 */
public final class NativeImageHelper {

    private NativeImageHelper() {
        // NO-OP
    }

    /**
     * Writes the native image data to a byte array.
     *
     * @param nativeImage the native image
     * @return the native image data as byte array
     *
     * @throws IOException thrown when writing fails
     */
    public static byte[] asByteArray(class_1011 nativeImage) throws IOException {
        return nativeImage.method_24036();
    }
}
