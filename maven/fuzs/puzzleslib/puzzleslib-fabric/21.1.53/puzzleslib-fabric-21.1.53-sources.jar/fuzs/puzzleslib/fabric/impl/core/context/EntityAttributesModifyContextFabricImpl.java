package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.EntityAttributesModifyContext;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1320;
import net.minecraft.class_1324;
import net.minecraft.class_5132;
import net.minecraft.class_5135;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import org.apache.commons.lang3.function.Consumers;

import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

@Deprecated
public final class EntityAttributesModifyContextFabricImpl implements EntityAttributesModifyContext {

    @Override
    public void registerAttributeModification(class_1299<? extends class_1309> entityType, class_6880<class_1320> attribute, double attributeValue) {
        // Forge makes this very simple by patching in a couple of helper methods, but Fabric should work like this
        class_5132 attributeSupplier = class_5135.method_26873(entityType);
        // there aren't many attributes anyway, so iterating the whole registry isn't costly
        Map<class_6880<class_1320>, Double> attributeToBaseValueMap = class_7923.field_41190.method_40270()
                .filter(attributeSupplier::method_27310)
                .map(holder -> attributeSupplier.method_26863(Consumers.nop(), holder))
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(class_1324::method_6198, class_1324::method_6201));
        attributeToBaseValueMap.put(attribute, attributeValue);
        class_5132.class_5133 builder = class_5132.method_26861();
        attributeToBaseValueMap.forEach(builder::method_26868);
        FabricDefaultAttributeRegistry.register(entityType, builder);
    }
}
