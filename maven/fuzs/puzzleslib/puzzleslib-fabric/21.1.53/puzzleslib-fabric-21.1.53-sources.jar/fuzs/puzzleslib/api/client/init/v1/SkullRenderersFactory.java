package fuzs.puzzleslib.api.client.init.v1;

import java.util.function.BiConsumer;
import net.minecraft.class_2484;
import net.minecraft.class_5598;
import net.minecraft.class_5599;

/**
 * Provides a way for adding custom skull type models to the immutable skull type map when it is created.
 */
@FunctionalInterface
public interface SkullRenderersFactory {

    /**
     * Adds the baked model to the context.
     *
     * @param entityModelSet model set for retrieving baked models
     * @param consumer        add model to context
     */
    void createSkullRenderers(class_5599 entityModelSet, BiConsumer<class_2484.class_2485, class_5598> consumer);
}
