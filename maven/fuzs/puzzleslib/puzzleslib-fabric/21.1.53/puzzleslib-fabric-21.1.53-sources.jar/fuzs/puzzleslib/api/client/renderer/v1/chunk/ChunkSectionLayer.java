package fuzs.puzzleslib.api.client.renderer.v1.chunk;

import net.minecraft.class_1921;

/**
 * Copied from Minecraft 1.21.11.
 */
public enum ChunkSectionLayer {
    SOLID(class_1921.method_23577()),
    CUTOUT(class_1921.method_23581()),
    CUTOUT_MIPPED(class_1921.method_23579()),
    TRANSLUCENT(class_1921.method_23583()),
    TRIPWIRE(class_1921.method_29997());

    public final class_1921 renderType;

    ChunkSectionLayer(class_1921 renderType) {
        this.renderType = renderType;
    }
}
