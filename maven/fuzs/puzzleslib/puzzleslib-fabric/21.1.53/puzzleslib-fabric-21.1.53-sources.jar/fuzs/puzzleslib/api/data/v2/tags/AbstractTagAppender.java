package fuzs.puzzleslib.api.data.v2.tags;

import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;

@Deprecated
public abstract class AbstractTagAppender<T> {
    protected final class_3495 tagBuilder;
    @Nullable
    private final Function<T, class_5321<T>> keyExtractor;

    protected AbstractTagAppender(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        this.tagBuilder = tagBuilder;
        this.keyExtractor = keyExtractor;
    }

    public AbstractTagAppender<T> setReplace(boolean replace) {
        ProxyImpl.get().setTagBuilderReplace(this.tagBuilder, replace);
        return this;
    }

    public AbstractTagAppender<T> setReplace() {
        return this.setReplace(true);
    }

    public AbstractTagAppender<T> add(String string) {
        return this.add(ResourceLocationHelper.parse(string));
    }

    public AbstractTagAppender<T> add(String... strings) {
        for (String string : strings) {
            this.add(string);
        }
        return this;
    }

    public AbstractTagAppender<T> add(class_2960 resourceLocation) {
        this.tagBuilder.method_26784(resourceLocation);
        return this;
    }

    public AbstractTagAppender<T> add(class_2960... resourceLocations) {
        for (class_2960 resourceLocation : resourceLocations) {
            this.add(resourceLocation);
        }
        return this;
    }

    public AbstractTagAppender<T> add(class_5321<? extends T> resourceKey) {
        return this.add(resourceKey.method_29177());
    }

    public AbstractTagAppender<T> add(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.add(resourceKey);
        }
        return this;
    }

    public AbstractTagAppender<T> add(T value) {
        return this.add(this.keyExtractor().apply(value));
    }

    public AbstractTagAppender<T> add(T... values) {
        for (T value : values) {
            this.add(value);
        }
        return this;
    }

    public AbstractTagAppender<T> add(class_6880.class_6883<? extends T> holder) {
        return this.add(holder.method_40237());
    }

    public AbstractTagAppender<T> add(class_6880.class_6883<? extends T>... holders) {
        for (class_6880.class_6883<? extends T> holder : holders) {
            this.add(holder);
        }
        return this;
    }

    public AbstractTagAppender<T> addOptional(String string) {
        return this.addOptional(ResourceLocationHelper.parse(string));
    }

    public AbstractTagAppender<T> addOptional(String... strings) {
        for (String string : strings) {
            this.addOptional(string);
        }
        return this;
    }

    public AbstractTagAppender<T> addOptional(class_2960 resourceLocation) {
        this.tagBuilder.method_34891(resourceLocation);
        return this;
    }

    public AbstractTagAppender<T> addOptional(class_2960... resourceLocations) {
        for (class_2960 resourceLocation : resourceLocations) {
            this.add(resourceLocation);
        }
        return this;
    }

    public AbstractTagAppender<T> addOptional(class_5321<? extends T> resourceKey) {
        return this.addOptional(resourceKey.method_29177());
    }

    public AbstractTagAppender<T> addOptional(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.addOptional(resourceKey);
        }
        return this;
    }

    public AbstractTagAppender<T> addTag(String string) {
        return this.addTag(ResourceLocationHelper.parse(string));
    }

    public AbstractTagAppender<T> addTag(String... strings) {
        for (String string : strings) {
            this.addTag(string);
        }
        return this;
    }

    public AbstractTagAppender<T> addTag(class_2960 resourceLocation) {
        this.tagBuilder.method_26787(resourceLocation);
        return this;
    }

    public AbstractTagAppender<T> addTag(class_2960... resourceLocations) {
        for (class_2960 resourceLocation : resourceLocations) {
            this.addTag(resourceLocation);
        }
        return this;
    }

    public AbstractTagAppender<T> addTag(class_6862<T> tagKey) {
        return this.addTag(tagKey.comp_327());
    }

    public AbstractTagAppender<T> addTag(class_6862<T>... tagKeys) {
        for (class_6862<T> tagKey : tagKeys) {
            this.addTag(tagKey);
        }
        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(String string) {
        return this.addOptionalTag(ResourceLocationHelper.parse(string));
    }

    public AbstractTagAppender<T> addOptionalTag(String... strings) {
        for (String string : strings) {
            this.addOptionalTag(string);
        }
        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_2960 resourceLocation) {
        this.tagBuilder.method_34892(resourceLocation);
        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_2960... resourceLocations) {
        for (class_2960 resourceLocation : resourceLocations) {
            this.addOptionalTag(resourceLocation);
        }
        return this;
    }

    public AbstractTagAppender<T> addOptionalTag(class_6862<T> tagKey) {
        return this.addOptionalTag(tagKey.comp_327());
    }

    public AbstractTagAppender<T> addOptionalTag(class_6862<T>... tagKeys) {
        for (class_6862<T> tagKey : tagKeys) {
            this.addOptionalTag(tagKey);
        }
        return this;
    }

    public AbstractTagAppender<T> remove(String string) {
        return this.remove(ResourceLocationHelper.parse(string));
    }

    public AbstractTagAppender<T> remove(String... strings) {
        for (String string : strings) {
            this.remove(string);
        }
        return this;
    }

    public abstract AbstractTagAppender<T> remove(class_2960 resourceLocation);

    public AbstractTagAppender<T> remove(class_2960... resourceLocations) {
        for (class_2960 resourceLocation : resourceLocations) {
            this.remove(resourceLocation);
        }
        return this;
    }

    public AbstractTagAppender<T> remove(class_5321<? extends T> resourceKey) {
        return this.remove(resourceKey.method_29177());
    }

    public AbstractTagAppender<T> remove(class_5321<? extends T>... resourceKeys) {
        for (class_5321<? extends T> resourceKey : resourceKeys) {
            this.remove(resourceKey);
        }
        return this;
    }

    public AbstractTagAppender<T> remove(T value) {
        return this.remove(this.keyExtractor().apply(value));
    }

    public AbstractTagAppender<T> remove(T... values) {
        for (T value : values) {
            this.remove(value);
        }
        return this;
    }

    public AbstractTagAppender<T> removeTag(String string) {
        return this.removeTag(ResourceLocationHelper.parse(string));
    }

    public AbstractTagAppender<T> removeTag(String... strings) {
        for (String string : strings) {
            this.removeTag(string);
        }
        return this;
    }

    public abstract AbstractTagAppender<T> removeTag(class_2960 resourceLocation);

    public AbstractTagAppender<T> removeTag(class_2960... resourceLocations) {
        for (class_2960 resourceLocation : resourceLocations) {
            this.removeTag(resourceLocation);
        }
        return this;
    }

    public AbstractTagAppender<T> removeTag(class_6862<T> tagKey) {
        return this.removeTag(tagKey.comp_327());
    }

    public AbstractTagAppender<T> removeTag(class_6862<T>... tagKeys) {
        for (class_6862<T> tagKey : tagKeys) {
            this.removeTag(tagKey);
        }
        return this;
    }

    private Function<T, class_5321<T>> keyExtractor() {
        Objects.requireNonNull(this.keyExtractor, "key extractor is null");
        return this.keyExtractor;
    }

    public abstract List<String> asStringList();
}
