package fuzs.puzzleslib.api.data.v2;

import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.data.v2.core.RegistriesDataProvider;
import fuzs.puzzleslib.api.init.v3.registry.ResourceKeyHelper;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_3414;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5475;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7444;
import net.minecraft.class_7784;
import net.minecraft.class_7877;
import net.minecraft.class_7891;
import net.minecraft.class_8054;
import net.minecraft.class_8107;
import net.minecraft.class_8110;
import net.minecraft.class_8931;
import net.minecraft.class_9793;
import net.minecraft.core.*;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public abstract class AbstractDatapackRegistriesProvider extends class_5475 implements RegistriesDataProvider {
    private final CompletableFuture<class_7225.class_7874> fullRegistries;

    public AbstractDatapackRegistriesProvider(DataProviderContext context) {
        this(context.getPackOutput(), context.getRegistries());
    }

    public AbstractDatapackRegistriesProvider(class_7784 output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, CompletableFuture.completedFuture(class_5455.field_40585));
        CompletableFuture<class_7877.class_8993> patchedRegistries = class_8931.method_54840(
                registries,
                class_156.method_654(new class_7877(), (class_7877 registrySetBuilder) -> {
                    this.addBootstrap(registrySetBuilder::method_46777);
                }));
        this.field_40952 = patchedRegistries.thenApply(class_7877.class_8993::comp_2114);
        this.fullRegistries = patchedRegistries.thenApply(class_7877.class_8993::comp_2113);
    }

    public abstract void addBootstrap(RegistryBoostrapConsumer consumer);

    @Override
    public CompletableFuture<class_7225.class_7874> getRegistries() {
        return this.fullRegistries;
    }

    public static void registerEnchantment(class_7891<class_1887> context, class_5321<class_1887> resourceKey, class_1887.class_9700 builder) {
        context.method_46838(resourceKey, builder.method_60060(resourceKey.method_29177()));
    }

    public static void registerDamageType(class_7891<class_8110> context, class_5321<class_8110> resourceKey) {
        context.method_46838(resourceKey, new class_8110(resourceKey.method_29177().method_12832(), 0.1F));
    }

    public static void registerDamageType(class_7891<class_8110> context, class_5321<class_8110> resourceKey, class_8107 damageEffects) {
        context.method_46838(resourceKey, new class_8110(resourceKey.method_29177().method_12832(), 0.1F, damageEffects));
    }

    public static void registerTrimMaterial(class_7891<class_8054> context, class_5321<class_8054> resourceKey, class_1792 ingredient, int descriptionColor, float itemModelIndex) {
        registerTrimMaterial(context,
                resourceKey,
                ingredient,
                descriptionColor,
                itemModelIndex,
                Collections.emptyMap());
    }

    public static void registerTrimMaterial(class_7891<class_8054> context, class_5321<class_8054> resourceKey, class_1792 ingredient, int descriptionColor, float itemModelIndex, Map<class_6880<class_1741>, String> overrideArmorMaterials) {
        class_2561 component = ResourceKeyHelper.getComponent(resourceKey)
                .method_27696(class_2583.field_24360.method_36139(descriptionColor));
        class_8054 trimMaterial = class_8054.method_48438(resourceKey.method_29177().method_12832(),
                ingredient,
                itemModelIndex,
                component,
                overrideArmorMaterials);
        context.method_46838(resourceKey, trimMaterial);
    }

    public static void registerInstrument(class_7891<class_7444> context, class_5321<class_7444> resourceKey, class_6880<class_3414> soundEvent, float useDuration, float range) {
        context.method_46838(resourceKey, new class_7444(soundEvent, (int) useDuration, range));
    }

    public static void registerJukeboxSong(class_7891<class_9793> context, class_5321<class_9793> resourceKey, class_6880<class_3414> soundEvent, float lengthInSeconds, int comparatorOutput) {
        context.method_46838(resourceKey,
                new class_9793(soundEvent,
                        ResourceKeyHelper.getComponent(resourceKey),
                        lengthInSeconds,
                        comparatorOutput));
    }

    @FunctionalInterface
    public interface RegistryBoostrapConsumer {

        <T> void add(class_5321<? extends class_2378<T>> key, class_7877.class_7882<T> bootstrap);
    }
}
