package fuzs.puzzleslib.api.client.renderer.v1.model;

import org.jetbrains.annotations.MustBeInvokedByOverriders;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5597;
import net.minecraft.class_630;

/**
 * A backport of the modern {@link class_3879} class.
 */
public abstract class RootedEntityModel<E extends class_1297> extends class_5597<E> {
    protected final class_630 root;
    private final List<class_630> allParts;

    public RootedEntityModel(class_630 root) {
        super();
        this.root = root;
        this.allParts = root.method_32088().toList();
    }

    public RootedEntityModel(class_630 root, Function<class_2960, class_1921> renderType) {
        super(renderType);
        this.root = root;
        this.allParts = root.method_32088().toList();
    }

    @Override
    public final void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        super.method_2828(poseStack, buffer, packedLight, packedOverlay, color);
    }

    @Override
    public final class_630 method_32008() {
        return this.root;
    }

    public final List<class_630> allParts() {
        return this.allParts;
    }

    @MustBeInvokedByOverriders
    @Override
    public void method_2819(E entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.resetPose();
    }

    public final void resetPose() {
        for (class_630 modelPart : this.allParts) {
            modelPart.method_41923();
        }
    }
}
