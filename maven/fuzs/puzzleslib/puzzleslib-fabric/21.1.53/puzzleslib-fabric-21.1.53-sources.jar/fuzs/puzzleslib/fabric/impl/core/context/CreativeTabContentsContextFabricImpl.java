package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.BuildCreativeModeTabContentsContext;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_5321;
import java.util.Objects;

@Deprecated
public final class CreativeTabContentsContextFabricImpl implements BuildCreativeModeTabContentsContext {

    @Override
    public void registerBuildListener(class_5321<class_1761> resourceKey, class_1761.class_7914 itemsGenerator) {
        Objects.requireNonNull(resourceKey, "resource key is null");
        Objects.requireNonNull(itemsGenerator, "display items generator is null");
        ItemGroupEvents.modifyEntriesEvent(resourceKey).register(entries -> itemsGenerator.accept(entries.getContext(), entries));
    }
}
