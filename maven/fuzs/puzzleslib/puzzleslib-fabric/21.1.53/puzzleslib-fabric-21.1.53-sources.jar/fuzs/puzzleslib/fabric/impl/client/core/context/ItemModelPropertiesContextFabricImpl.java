package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.ItemModelPropertiesContext;
import java.util.Objects;
import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_5272;
import net.minecraft.class_6395;

public final class ItemModelPropertiesContextFabricImpl implements ItemModelPropertiesContext {

    @Override
    public void registerGlobalProperty(class_2960 identifier, class_6395 function) {
        Objects.requireNonNull(identifier, "property name is null");
        Objects.requireNonNull(function, "property function is null");
        class_5272.method_27881(identifier, function);
    }

    @Override
    public void registerItemProperty(class_2960 identifier, class_6395 function, class_1935... items) {
        Objects.requireNonNull(identifier, "property name is null");
        Objects.requireNonNull(function, "property function is null");
        Objects.requireNonNull(items, "items is null");
        Preconditions.checkState(items.length > 0, "items is empty");
        for (class_1935 item : items) {
            Objects.requireNonNull(item, "items is null");
            class_5272.method_27879(item.method_8389(), identifier, function);
        }
    }
}
