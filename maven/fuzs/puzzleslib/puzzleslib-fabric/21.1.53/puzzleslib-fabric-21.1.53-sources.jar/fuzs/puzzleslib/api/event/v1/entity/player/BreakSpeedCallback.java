package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import net.minecraft.class_1657;
import net.minecraft.class_2680;

@FunctionalInterface
public interface BreakSpeedCallback {
    EventInvoker<BreakSpeedCallback> EVENT = EventInvoker.lookup(BreakSpeedCallback.class);

    /**
     * Called when the player attempts to harvest a block in {@link class_1657#method_7351(class_2680)}.
     *
     * @param player     the player breaking <code>state</code>
     * @param state      the block state being broken
     * @param breakSpeed the speed at which the block is broken, usually a value around 1.0
     * @return {@link EventResult#INTERRUPT} to prevent the block from breaking, effectively setting the break speed to -1.0,
     * {@link EventResult#PASS} to allow the block to be broken at the defined break speed
     */
    EventResult onBreakSpeed(class_1657 player, class_2680 state, DefaultedFloat breakSpeed);
}
