package fuzs.puzzleslib.fabric.api.client.event.v1.registry;

import fuzs.puzzleslib.fabric.api.event.v1.registry.DataPackFinderRegistry;
import fuzs.puzzleslib.fabric.impl.client.event.ResourcePackFinderRegistryImpl;
import net.minecraft.class_310;
import net.minecraft.class_3285;
import net.minecraft.class_3288;

/**
 * Allows for adding mod provided built-in resource packs.
 * <p>The equivalent for data packs is implemented via {@link DataPackFinderRegistry}.
 * <p>In contrast to {@link net.fabricmc.fabric.api.resource.ResourceManagerHelper} this implementation also supports virtual / runtime generated packs,
 * not just physical packs located in the mod jar.
 */
public interface ResourcePackFinderRegistry {
    /**
     * The singleton instance of the decorator registry.
     * Use this instance to call the methods in this interface.
     */
    ResourcePackFinderRegistry INSTANCE = new ResourcePackFinderRegistryImpl();

    /**
     * Adds a new repository source to the client resource pack repository.
     * <p>The source is added instantly to {@link class_310#method_1520()},
     * since the corresponding {@link net.minecraft.class_3283} has already been created.
     * <p>Packs that are enabled by default must return <code>true</code> for {@link class_3288#method_14464()}.
     * Registering built-in packs that are not required, but should be enabled by default are not supported.
     *
     * @param repositorySource the repository source
     */
    void register(class_3285 repositorySource);
}
