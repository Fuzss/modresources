package fuzs.puzzleslib.api.client.gui.v2.components;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.client.core.v1.ClientAbstractions;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5632;
import net.minecraft.class_5684;
import net.minecraft.class_8001;
import net.minecraft.class_8002;

/**
 * A helper class for rendering tooltips without a screen, additionally allows for rendering multiple image components
 * whereas vanilla only supports one.
 * <p>
 * Note that the implementation is directly copied from vanilla, all caveats apply. This is done to circumvent other
 * mods that interfere with tooltip rendering (such as Adaptive Tooltips and ToolTipFix), since they otherwise cause an
 * implementation such as this one without a proper valid screen to fail or even crash.
 */
@Deprecated
public final class TooltipRenderHelper {

    private TooltipRenderHelper() {
        // NO-OP
    }

    /**
     * Creates individual tooltip lines from an item stack.
     * <p>{@link class_1836} defaults to the value set in <code>options.txt</code>.
     * <p>This only includes text tooltip components, for the image component an item may provide see
     * {@link #getTooltip}.
     *
     * @param itemStack the item stack to retrieve the tooltip from
     * @return the tooltip lines as list
     */
    public static List<class_2561> getTooltipLines(class_1799 itemStack) {
        return getTooltipLines(itemStack,
                class_310.method_1551().field_1690.field_1827 ? class_1836.class_1837.field_41071 :
                        class_1836.class_1837.field_41070
        );
    }

    /**
     * Creates individual tooltip lines from an item stack.
     * <p>This only includes text tooltip components, for the image component an item may provide see
     * {@link #getTooltip}.
     *
     * @param itemStack   the item stack to retrieve the tooltip from
     * @param tooltipFlag the tooltip flag to use
     * @return the tooltip lines as list
     */
    public static List<class_2561> getTooltipLines(class_1799 itemStack, class_1836 tooltipFlag) {
        Objects.requireNonNull(itemStack, "item stack is null");
        Objects.requireNonNull(tooltipFlag, "tooltip flag is null");
        class_310 minecraft = class_310.method_1551();
        return itemStack.method_7950(class_1792.class_9635.method_59528(minecraft.field_1687), minecraft.field_1724, tooltipFlag);
    }

    /**
     * Creates all client tooltip components for an item stack, including a possibly present image component.
     * <p>{@link class_1836} defaults to the value set in <code>options.txt</code>.
     *
     * @param itemStack the item stack to retrieve the tooltip from
     * @return client tooltip components
     */
    public static List<class_5684> getTooltip(class_1799 itemStack) {
        return getTooltip(itemStack,
                class_310.method_1551().field_1690.field_1827 ? class_1836.class_1837.field_41071 :
                        class_1836.class_1837.field_41070
        );
    }

    /**
     * Creates all client tooltip components for an item stack, including a possibly present image component.
     *
     * @param itemStack   the item stack to retrieve the tooltip from
     * @param tooltipFlag the tooltip flag to use
     * @return client tooltip components
     */
    public static List<class_5684> getTooltip(class_1799 itemStack, class_1836 tooltipFlag) {
        Objects.requireNonNull(itemStack, "item stack is null");
        Objects.requireNonNull(tooltipFlag, "tooltip flag is null");
        List<class_2561> components = getTooltipLines(itemStack, tooltipFlag);
        List<class_5632> imageComponents = itemStack.method_32347().map(List::of).orElse(List.of());
        return createClientComponents(components, imageComponents);
    }

    /**
     * Renders a tooltip, accepts an item stack.
     *
     * @param guiGraphics the gui graphics component
     * @param posX        position on x-axis, would be mouse cursor x for vanilla
     * @param posY        position on y-axis, would be mouse cursor y for vanilla
     * @param itemStack   the item stack to retrieve the tooltip from
     */
    public static void renderTooltip(class_332 guiGraphics, int posX, int posY, class_1799 itemStack) {
        Objects.requireNonNull(itemStack, "item stack is null");
        renderTooltipComponents(guiGraphics, posX, posY, getTooltip(itemStack));
    }

    /**
     * Renders a tooltip, accepts a single text component and a single image component.
     *
     * @param guiGraphics    the gui graphics component
     * @param posX           position on x-axis, would be mouse cursor x for vanilla
     * @param posY           position on y-axis, would be mouse cursor y for vanilla
     * @param component      component to render in the tooltip
     * @param imageComponent image component to render in the tooltip
     */
    public static void renderTooltip(class_332 guiGraphics, int posX, int posY, class_2561 component, class_5632 imageComponent) {
        Objects.requireNonNull(component, "component is null");
        Objects.requireNonNull(imageComponent, "image component is null");
        renderTooltip(guiGraphics, posX, posY, List.of(component), imageComponent);
    }

    /**
     * Renders a tooltip, accepts text components and a single image component, just like vanilla.
     *
     * @param guiGraphics    the gui graphics component
     * @param posX           position on x-axis, would be mouse cursor x for vanilla
     * @param posY           position on y-axis, would be mouse cursor y for vanilla
     * @param components     components to render in the tooltip
     * @param imageComponent image component to render in the tooltip
     */
    public static void renderTooltip(class_332 guiGraphics, int posX, int posY, List<class_2561> components, class_5632 imageComponent) {
        Objects.requireNonNull(imageComponent, "image component is null");
        renderTooltip(guiGraphics, posX, posY, components, List.of(imageComponent));
    }

    /**
     * Renders a tooltip, accepts text components and does not include any image components.
     *
     * @param guiGraphics the gui graphics component
     * @param posX        position on x-axis, would be mouse cursor x for vanilla
     * @param posY        position on y-axis, would be mouse cursor y for vanilla
     * @param components  components to render in the tooltip
     */
    public static void renderTooltip(class_332 guiGraphics, int posX, int posY, List<class_2561> components) {
        renderTooltip(guiGraphics, posX, posY, components, List.of());
    }

    /**
     * Renders a tooltip, accepts text components and multiple image components.
     *
     * @param guiGraphics     the gui graphics component
     * @param posX            position on x-axis, would be mouse cursor x for vanilla
     * @param posY            position on y-axis, would be mouse cursor y for vanilla
     * @param components      components to render in the tooltip
     * @param imageComponents image components to render in the tooltip
     */
    public static void renderTooltip(class_332 guiGraphics, int posX, int posY, List<class_2561> components, List<class_5632> imageComponents) {
        renderTooltipComponents(guiGraphics, posX, posY, createClientComponents(components, imageComponents));
    }

    /**
     * Creates a list of {@link class_5684}s from text and image components to be rendered on a tooltip.
     * <p><code>imageComponents</code> are inserted into <code>components</code> at index <code>1</code>, just like
     * vanilla.
     *
     * @param components      components to render on the tooltip
     * @param imageComponents image components to render on the tooltip
     * @return the client tooltip components
     */
    public static List<class_5684> createClientComponents(List<class_2561> components, List<class_5632> imageComponents) {
        return createClientComponents(components, imageComponents, 1);
    }

    /**
     * Creates a list of {@link class_5684}s from text and image components to be rendered on a tooltip.
     *
     * @param components      components to render on the tooltip
     * @param imageComponents image components to render on the tooltip
     * @param insertAt        index to insert <code>imageComponents</code> into <code>components</code>, set to
     *                        <code>-1</code> to insert at the end
     * @return the client tooltip components
     */
    public static List<class_5684> createClientComponents(List<class_2561> components, List<class_5632> imageComponents, int insertAt) {
        List<class_5684> clientComponents = components.stream().map(class_2561::method_30937).map(
                class_5684::method_32662).collect(Collectors.toList());
        List<class_5684> clientImageComponents = imageComponents.stream().map(
                ClientAbstractions.INSTANCE::createImageComponent).toList();
        if (insertAt == -1) {
            clientComponents.addAll(clientImageComponents);
        } else {
            clientComponents.addAll(Math.min(clientComponents.size(), insertAt), clientImageComponents);
        }
        return ImmutableList.copyOf(clientComponents);
    }

    /**
     * Finally renders the tooltip, simply copied from the vanilla implementation.
     * <p>
     * Note that this method also offsets the position by +12 / -12 (x / y), just like vanilla.
     * <p>
     * Also, the tooltip is guaranteed to be placed at the specified position, no attempts at wrapping / repositioning
     * to avoid running offscreen are made.
     * <p>
     * The behavior is like using {@link class_8001#field_41687}.
     *
     * @param guiGraphics the gui graphics component
     * @param posX        position on x-axis, would be mouse cursor x for vanilla
     * @param posY        position on y-axis, would be mouse cursor y for vanilla
     * @param components  components to render in the tooltip
     */
    public static void renderTooltipComponents(class_332 guiGraphics, int posX, int posY, List<? extends class_5684> components) {

        if (components.isEmpty()) return;

        class_310 minecraft = class_310.method_1551();
        boolean result = ClientAbstractions.INSTANCE.onRenderTooltip(guiGraphics, minecraft.field_1772, posX, posY,
                (List<class_5684>) components, class_8001.field_41687
        );

        if (result) return;

        int lineWidth = 0;
        int lineHeight = components.size() == 1 ? -2 : 0;

        for (class_5684 component : components) {
            int width = component.method_32664(minecraft.field_1772);
            if (width > lineWidth) {
                lineWidth = width;
            }
            lineHeight += component.method_32661();
        }

        posX += 12;
        posY -= 12;

        guiGraphics.method_51448().method_22903();
        renderTooltipBackground(guiGraphics, posX, posY, lineWidth, lineHeight);
        guiGraphics.method_51448().method_46416(0.0F, 0.0F, 400.0F);

        int currentPosY = posY;
        for (int i = 0; i < components.size(); ++i) {
            class_5684 component = components.get(i);
            component.method_32665(minecraft.field_1772, posX, currentPosY, guiGraphics.method_51448().method_23760().method_23761(),
                    guiGraphics.method_51450()
            );
            currentPosY += component.method_32661() + (i == 0 ? 2 : 0);
        }

        currentPosY = posY;
        for (int i = 0; i < components.size(); ++i) {
            class_5684 component = components.get(i);
            component.method_32666(minecraft.field_1772, posX, currentPosY, guiGraphics);
            currentPosY += component.method_32661() + (i == 0 ? 2 : 0);
        }

        // we need this as opposed to the renderer in GuiGraphics, otherwise tooltip text leaks through screens
        guiGraphics.method_51452();
        guiGraphics.method_51448().method_22909();
    }

    @SuppressWarnings("deprecation")
    private static void renderTooltipBackground(class_332 guiGraphics, int posX, int posY, int lineWidth, int lineHeight) {
        guiGraphics.method_51741(
                () -> class_8002.method_47946(guiGraphics, posX, posY, lineWidth, lineHeight, 400));
    }
}
