package fuzs.puzzleslib.api.core.v1.context;

import fuzs.puzzleslib.api.item.v2.CreativeModeTabConfigurator;

/**
 * Register new creative mode tabs via the respective builder.
 */
@Deprecated
@FunctionalInterface
public interface CreativeModeTabContext {

    /**
     * Register a {@link CreativeModeTabConfigurator} which is used to configure a {@link net.minecraft.class_1761.class_7913}
     *
     * @param configurator the configurator instance
     */
    void registerCreativeModeTab(CreativeModeTabConfigurator configurator);
}
