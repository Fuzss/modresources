package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.Collection;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;

public interface LivingDropsCallback {
    EventInvoker<LivingDropsCallback> EVENT = EventInvoker.lookup(LivingDropsCallback.class);

    /**
     * Called right before drops from a killed entity are spawned in the world.
     * <p>
     * This allows to change the loot that is dropped.
     * <p>
     * The looting level can be obtained via
     * {@link fuzs.puzzleslib.api.core.v1.CommonAbstractions#getMobLootingLevel(class_1297, class_1297, class_1282)}.
     *
     * @param entity       the entity that has been killed
     * @param damageSource damage source that killed the entity
     * @param itemDrops    all drops, including equipment, so not just drops from the entity's loot table; this can be
     *                     modified
     * @param recentlyHit  does this count as a player kill, meaning {@link class_1309#lastHurtByPlayerTime} is not
     *                     zero
     * @return {@link EventResult#INTERRUPT} to prevent any drops from spawning, {@link EventResult#PASS} to allow drops
     *         to be spawned in the world; will have the same result as {@link EventResult#INTERRUPT} if drops are
     *         empty
     */
    EventResult onLivingDrops(class_1309 entity, class_1282 damageSource, Collection<class_1542> itemDrops, boolean recentlyHit);
}
