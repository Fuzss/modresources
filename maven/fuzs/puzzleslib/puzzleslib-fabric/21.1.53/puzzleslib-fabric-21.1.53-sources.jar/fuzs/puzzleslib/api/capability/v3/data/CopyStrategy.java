package fuzs.puzzleslib.api.capability.v3.data;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_7225;

/**
 * Controls how capability data should be handled when entity data is copied.
 * <p>This happens in {@link net.minecraft.class_1308#method_29243(class_1299, boolean)} and when the player is being respawned.
 */
public enum CopyStrategy {
    /**
     * Always copy capability data when copying other entity data, independently of the cause.
     */
    ALWAYS {
        @Override
        public void copy(class_1297 oldEntity, CapabilityComponent<?> oldCapability, class_1297 newEntity, CapabilityComponent<?> newCapability, boolean originalStillAlive) {
            this.copy(newEntity.method_56673(), oldCapability, newCapability);
        }
    },
    /**
     * Do not copy entity data, allows for manual handling if desired. Data is still copied for players returning from the End dimension.
     */
    NEVER {
        @Override
        public void copy(class_1297 oldEntity, CapabilityComponent<?> oldCapability, class_1297 newEntity, CapabilityComponent<?> newCapability, boolean originalStillAlive) {
            if (originalStillAlive) this.copy(newEntity.method_56673(), oldCapability, newCapability);
        }
    },
    /**
     * Copy entity data when inventory contents of a player are copied, which is the case after dying when the <code>keepInventory</code> game rule is active.
     *
     * @deprecated will no longer be supported in upcoming versions to allow migrating to Fabric Api's / NeoForge's native implementation
     */
    @Deprecated
    KEEP_PLAYER_INVENTORY {
        @Override
        public void copy(class_1297 oldEntity, CapabilityComponent<?> oldCapability, class_1297 newEntity, CapabilityComponent<?> newCapability, boolean originalStillAlive) {
            NEVER.copy(oldEntity, oldCapability, newEntity, newCapability, originalStillAlive);
        }
    };

    /**
     * Determines whether capability data should be copied.
     *
     * @param oldEntity          source entity
     * @param oldCapability      source capability component
     * @param newEntity          target entity
     * @param newCapability      target capability component
     * @param originalStillAlive is the entity still alive or has it died
     */
    public abstract void copy(class_1297 oldEntity, CapabilityComponent<?> oldCapability, class_1297 newEntity, CapabilityComponent<?> newCapability, boolean originalStillAlive);

    void copy(class_7225.class_7874 registries, CapabilityComponent<?> oldCapability, CapabilityComponent<?> newCapability) {
        newCapability.read(oldCapability.toCompoundTag(registries), registries);
    }
}
