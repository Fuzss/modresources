package fuzs.puzzleslib.api.util.v1;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.MapCodec;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;

/**
 * Helper methods for handling storing via {@link Codec Codecs} in {@link class_2487 CompoundTags}.
 */
public final class CompoundTagHelper {

    private CompoundTagHelper() {
        // NO-OP
    }

    public static <T> void store(class_2487 compoundTag, String key, Codec<T> codec, T data) {
        store(compoundTag, key, codec, class_2509.field_11560, data);
    }

    public static <T> void storeNullable(class_2487 compoundTag, String key, Codec<T> codec, @Nullable T data) {
        if (data != null) {
            store(compoundTag, key, codec, data);
        }
    }

    public static <T> void store(class_2487 compoundTag, String key, Codec<T> codec, DynamicOps<class_2520> ops, T data) {
        compoundTag.method_10566(key, codec.encodeStart(ops, data).getOrThrow());
    }

    public static <T> void storeNullable(class_2487 compoundTag, String key, Codec<T> codec, DynamicOps<class_2520> ops, @Nullable T data) {
        if (data != null) {
            store(compoundTag, key, codec, ops, data);
        }
    }

    public static <T> void store(class_2487 compoundTag, MapCodec<T> mapCodec, T data) {
        store(compoundTag, mapCodec, class_2509.field_11560, data);
    }

    public static <T> void store(class_2487 compoundTag, MapCodec<T> mapCodec, DynamicOps<class_2520> ops, T data) {
        compoundTag.method_10543((class_2487) mapCodec.encoder().encodeStart(ops, data).getOrThrow());
    }

    public static <T> Optional<T> read(class_2487 compoundTag, String key, Codec<T> codec) {
        return read(compoundTag, key, codec, class_2509.field_11560);
    }

    public static <T> Optional<T> read(class_2487 compoundTag, String key, Codec<T> codec, DynamicOps<class_2520> ops) {
        class_2520 tag = compoundTag.method_10580(key);
        return tag == null ? Optional.empty() : codec.parse(ops, tag)
                .resultOrPartial((String string) -> PuzzlesLib.LOGGER.error("Failed to read field ({}={}): {}",
                        key,
                        tag,
                        string));
    }

    public static <T> Optional<T> read(class_2487 compoundTag, MapCodec<T> mapCodec) {
        return read(compoundTag, mapCodec, class_2509.field_11560);
    }

    public static <T> Optional<T> read(class_2487 compoundTag, MapCodec<T> mapCodec, DynamicOps<class_2520> ops) {
        return mapCodec.decode(ops, ops.getMap(compoundTag).getOrThrow())
                .resultOrPartial((String string) -> PuzzlesLib.LOGGER.error("Failed to read value ({}): {}",
                        compoundTag,
                        string));
    }
}
