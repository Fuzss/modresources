package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import net.minecraft.class_1282;
import net.minecraft.class_1309;
import net.minecraft.class_1887;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

@FunctionalInterface
public interface ComputeEnchantedLootBonusCallback {
    EventInvoker<ComputeEnchantedLootBonusCallback> EVENT = EventInvoker.lookup(
            ComputeEnchantedLootBonusCallback.class);

    /**
     * Called just before a {@link class_1309} drops all its loot for determining the level of a loot bonus
     * enchantment such as {@link net.minecraft.class_1893#field_9110} that should be applied to
     * the drops.
     * <p>
     * Specifically the event allows for controlling the enchantment level when applying the:
     * <ul>
     *     <li>loot item function <code>minecraft:enchanted_count_increase</code></li>
     *     <li>loot item condition <code>minecraft:random_chance_with_enchanted_bonus</code></li>
     *     <li>enchantment effect component <code>minecraft:equipment_drops</code></li>
     * </ul>
     *
     * @param entity           the entity that is about to drop all its loot
     * @param damageSource     the damage source that caused the entity to drop its loot
     * @param enchantment      the enchantment
     * @param enchantmentLevel the current enchantment level
     */
    void onComputeEnchantedLootBonus(class_1309 entity, @Nullable class_1282 damageSource, class_6880<class_1887> enchantment, MutableInt enchantmentLevel);
}
