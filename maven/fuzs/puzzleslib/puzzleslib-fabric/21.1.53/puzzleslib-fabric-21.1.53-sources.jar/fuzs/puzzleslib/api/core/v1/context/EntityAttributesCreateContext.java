package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_5132;

/**
 * register default attributes for our own entities
 */
@Deprecated
public interface EntityAttributesCreateContext {

    /**
     * register attributes for our own entities, modifying attributes for any other entity (vanilla or modded) should be done using {@link EntityAttributesModifyContext}
     *
     * @param entityType type of entity
     * @param builder    the attribute supplier builder
     */
    void registerEntityAttributes(class_1299<? extends class_1309> entityType, class_5132.class_5133 builder);
}
