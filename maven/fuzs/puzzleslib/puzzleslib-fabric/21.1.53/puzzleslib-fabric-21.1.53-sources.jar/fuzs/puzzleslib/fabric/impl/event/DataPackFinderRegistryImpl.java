package fuzs.puzzleslib.fabric.impl.event;

import com.google.common.collect.Sets;
import fuzs.puzzleslib.fabric.api.event.v1.registry.DataPackFinderRegistry;
import fuzs.puzzleslib.fabric.mixin.accessor.PackRepositoryFabricAccessor;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_3283;
import net.minecraft.class_3285;

public final class DataPackFinderRegistryImpl implements DataPackFinderRegistry {
    private static final Set<class_3285> SOURCES = Sets.newLinkedHashSet();

    public static void addAllRepositorySources(class_3283 packRepository) {
        SOURCES.forEach(repositorySource -> addRepositorySource(packRepository, repositorySource));
    }

    public static synchronized void addRepositorySource(class_3283 packRepository, class_3285 repositorySource) {
        Set<class_3285> repositorySources = ((PackRepositoryFabricAccessor) packRepository).puzzleslib$getSources();
        // Fabric Api internally replaces the immutable set already and leaves it like that, just verify in case internal implementation changes
        if (!(repositorySources instanceof LinkedHashSet<class_3285>)) {
            repositorySources = new LinkedHashSet<>(repositorySources);
            ((PackRepositoryFabricAccessor) packRepository).puzzleslib$setSources(repositorySources);
        }
        repositorySources.add(repositorySource);
    }

    @Override
    public void register(class_3285 repositorySource) {
        Objects.requireNonNull(repositorySource, "repository source is null");
        SOURCES.add(repositorySource);
    }
}
