package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1799;

@FunctionalInterface
public interface LivingEquipmentChangeCallback {
    EventInvoker<LivingEquipmentChangeCallback> EVENT = EventInvoker.lookup(LivingEquipmentChangeCallback.class);

    /**
     * Fires whenever equipment changes are detected on an entity in {@link class_1309#method_30129()} from {@link class_1309#method_5773()}.
     * This runs before attributes supplied by the equipment are updated on the entity and before the changed equipment is synced to clients.
     *
     * <p>Note that the callback does <b>NOT</b> run immediately when the equipment actually changes like in {@link class_1309#method_6116(class_1304, class_1799, class_1799)}.
     *
     * @param entity        the entity changing its equipment
     * @param equipmentSlot the equipment slot that is changed
     * @param oldItemStack  the item stack previously found in the slot
     * @param newItemStack  the new item stack placed into the slot
     */
    void onLivingEquipmentChange(class_1309 entity, class_1304 equipmentSlot, class_1799 oldItemStack, class_1799 newItemStack);
}
