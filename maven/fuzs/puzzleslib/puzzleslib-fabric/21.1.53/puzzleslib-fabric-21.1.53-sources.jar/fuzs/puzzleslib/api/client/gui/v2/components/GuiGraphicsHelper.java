package fuzs.puzzleslib.api.client.gui.v2.components;

import fuzs.puzzleslib.impl.client.gui.SingleTextureAtlasSprite;
import net.minecraft.class_1058;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_8690;
import org.joml.Matrix4f;

/**
 * A helper class for extending the functionality of {@link class_332}. Especially useful for drawing
 * {@link class_1058 TextureAtlasSprites} with a different {@link class_8690} than is defined by the
 * resource pack.
 */
public final class GuiGraphicsHelper {

    private GuiGraphicsHelper() {
        // NO-OP
    }

    /**
     * Creates an on demand {@link class_332} instance from a provided {@link class_4587}.
     *
     * @param poseStack the pose stack
     * @return the gui graphics instance
     */
    public static class_332 create(class_4587 poseStack) {
        return create(poseStack.method_23760().method_23761());
    }

    /**
     * Creates an on demand {@link class_332} instance from a provided {@link class_4587}.
     *
     * @param matrix4f the matrix backing the pose stack
     * @return the gui graphics instance
     */
    public static class_332 create(Matrix4f matrix4f) {
        class_310 minecraft = class_310.method_1551();
        class_332 guiGraphics = new class_332(minecraft, minecraft.method_22940().method_23000());
        guiGraphics.method_51448().method_34425(matrix4f);
        return guiGraphics;
    }

    /**
     * Draws a rectangular border frame, the inside of the shape is left untouched.
     *
     * @param guiGraphics gui graphics instance
     * @param posX        start x
     * @param posY        start y
     * @param width       rectangle width
     * @param height      rectangle height
     * @param borderSize  width of the border on all sides, goes inwards
     * @param color       color to fill with
     */
    public static void fillFrame(class_332 guiGraphics, int posX, int posY, int width, int height, int borderSize, int color) {
        fillFrame(guiGraphics, posX, posY, width, height, borderSize, 0, color);
    }

    /**
     * Draws a rectangular border frame, the inside of the shape is left untouched.
     *
     * @param guiGraphics gui graphics instance
     * @param posX        start x
     * @param posY        start y
     * @param width       rectangle width
     * @param height      rectangle height
     * @param borderSize  width of the border on all sides, goes inwards
     * @param z           z offset
     * @param color       color to fill with
     */
    public static void fillFrame(class_332 guiGraphics, int posX, int posY, int width, int height, int borderSize, int z, int color) {
        fillFrameArea(guiGraphics, posX, posY, posX + width, posY + height, borderSize, z, color);
    }

    /**
     * Draws a rectangular border frame, the inside of the shape is left untouched.
     *
     * @param guiGraphics gui graphics instance
     * @param minX        start x
     * @param minY        start y
     * @param maxX        end x
     * @param maxY        end y
     * @param borderSize  width of the border on all sides, goes inwards
     * @param z           z offset
     * @param color       color to fill with
     */
    public static void fillFrameArea(class_332 guiGraphics, int minX, int minY, int maxX, int maxY, int borderSize, int z, int color) {
        // top
        guiGraphics.method_51737(minX, minY, maxX, minY + borderSize, z, color);
        // bottom
        guiGraphics.method_51737(minX, maxY - borderSize, maxX, maxY, z, color);
        // left
        guiGraphics.method_51737(minX, minY + borderSize, minX + borderSize, maxY - borderSize, z, color);
        // right
        guiGraphics.method_51737(maxX - borderSize, minY + borderSize, maxX, maxY - borderSize, z, color);
    }

    /**
     * Draws a rectangular border frame, the inside of the shape is left untouched.
     *
     * @param guiGraphics gui graphics instance
     * @param minX        start x
     * @param minY        start y
     * @param maxX        end x
     * @param maxY        end y
     * @param borderSize  width of the border on all sides, goes inwards
     * @param color       color to fill with
     */
    public static void fillFrameArea(class_332 guiGraphics, int minX, int minY, int maxX, int maxY, int borderSize, int color) {
        fillFrameArea(guiGraphics, minX, minY, maxX, maxY, borderSize, 0, color);
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics      the gui graphics instance
     * @param resourceLocation the texture sheet resource location
     * @param x                the x-position on the screen
     * @param y                the y-position on the screen
     * @param width            the width to draw
     * @param height           the height to draw
     * @param borderSize       the border width &amp; height on the sides of the sprite, for drawing the frame
     * @param spriteWidth      the sprite texture width
     * @param spriteHeight     the sprite texture height
     * @param uOffset          the sprite u-offset on the texture sheet
     * @param vOffset          the sprite v-offset on the texture sheet
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 resourceLocation, int x, int y, int width, int height, int borderSize, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        blitNineSliced(guiGraphics, resourceLocation, x, y, width, height, borderSize, borderSize, spriteWidth,
                spriteHeight, uOffset, vOffset
        );
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics      the gui graphics instance
     * @param resourceLocation the texture sheet resource location
     * @param x                the x-position on the screen
     * @param y                the y-position on the screen
     * @param width            the width to draw
     * @param height           the height to draw
     * @param borderWidth      the border width on the sides of the sprite, for drawing the frame
     * @param borderHeight     the border height on the sides of the sprite, for drawing the frame
     * @param spriteWidth      the sprite texture width
     * @param spriteHeight     the sprite texture height
     * @param uOffset          the sprite u-offset on the texture sheet
     * @param vOffset          the sprite v-offset on the texture sheet
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 resourceLocation, int x, int y, int width, int height, int borderWidth, int borderHeight, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        blitNineSliced(guiGraphics, resourceLocation, x, y, width, height, borderWidth, borderHeight, borderWidth,
                borderHeight, spriteWidth, spriteHeight, uOffset, vOffset
        );
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics      the gui graphics instance
     * @param resourceLocation the texture sheet resource location
     * @param x                the x-position on the screen
     * @param y                the y-position on the screen
     * @param width            the width to draw
     * @param height           the height to draw
     * @param borderLeft       the border width on the left side of the sprite, for drawing the frame
     * @param borderTop        the border height on the top side of the sprite, for drawing the frame
     * @param borderRight      the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom     the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth      the sprite texture width
     * @param spriteHeight     the sprite texture height
     * @param uOffset          the sprite u-offset on the texture sheet
     * @param vOffset          the sprite v-offset on the texture sheet
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 resourceLocation, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        blitNineSliced(guiGraphics, resourceLocation, x, y, 0, width, height, borderLeft, borderTop, borderRight,
                borderBottom, spriteWidth, spriteHeight, uOffset, vOffset, 256, 256
        );
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics      the gui graphics instance
     * @param resourceLocation the texture sheet resource location
     * @param x                the x-position on the screen
     * @param y                the y-position on the screen
     * @param width            the width to draw
     * @param height           the height to draw
     * @param borderLeft       the border width on the left side of the sprite, for drawing the frame
     * @param borderTop        the border height on the top side of the sprite, for drawing the frame
     * @param borderRight      the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom     the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth      the sprite texture width
     * @param spriteHeight     the sprite texture height
     * @param uOffset          the sprite u-offset on the texture sheet
     * @param vOffset          the sprite v-offset on the texture sheet
     * @param textureWidth     the texture sheet width
     * @param textureHeight    the texture sheet height
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 resourceLocation, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int textureWidth, int textureHeight) {
        blitNineSliced(guiGraphics, resourceLocation, x, y, 0, width, height, borderLeft, borderTop, borderRight,
                borderBottom, spriteWidth, spriteHeight, uOffset, vOffset, textureWidth, textureHeight
        );
    }

    /**
     * Allows for drawing any sprite from a texture sheet in nine-sliced mode. This does not require the sprite to be
     * stitched onto an atlas.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics      the gui graphics instance
     * @param resourceLocation the texture sheet resource location
     * @param x                the x-position on the screen
     * @param y                the y-position on the screen
     * @param blitOffset       the z-level offset
     * @param width            the width to draw
     * @param height           the height to draw
     * @param borderLeft       the border width on the left side of the sprite, for drawing the frame
     * @param borderTop        the border height on the top side of the sprite, for drawing the frame
     * @param borderRight      the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom     the border height on the bottom side of the sprite, for drawing the frame
     * @param spriteWidth      the sprite texture width
     * @param spriteHeight     the sprite texture height
     * @param uOffset          the sprite u-offset on the texture sheet
     * @param vOffset          the sprite v-offset on the texture sheet
     * @param textureWidth     the texture sheet width
     * @param textureHeight    the texture sheet height
     */
    public static void blitNineSliced(class_332 guiGraphics, class_2960 resourceLocation, int x, int y, int blitOffset, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom, int spriteWidth, int spriteHeight, int uOffset, int vOffset, int textureWidth, int textureHeight) {
        SingleTextureAtlasSprite textureAtlasSprite = new SingleTextureAtlasSprite(resourceLocation, spriteWidth,
                spriteHeight, uOffset, vOffset, textureWidth, textureHeight
        );
        class_8690.class_8691 nineSlice = new class_8690.class_8691(spriteWidth, spriteHeight,
                new class_8690.class_8691.class_8692(borderLeft, borderTop, borderRight, borderBottom)
        );
        guiGraphics.method_52713(textureAtlasSprite, nineSlice, x, y, blitOffset, width, height);
    }

    /**
     * Allows for manually drawing any sprite using nine-sliced mode.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics the gui graphics instance
     * @param sprite      the sprite resource location
     * @param x           the x-position on the screen
     * @param y           the y-position on the screen
     * @param width       the width to draw
     * @param height      the height to draw
     * @param borderSize  the border width &amp; height on the sides of the sprite, for drawing the frame
     */
    public static void blitNineSlicedSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int borderSize) {
        blitNineSlicedSprite(guiGraphics, sprite, x, y, 0, width, height, borderSize, borderSize, borderSize,
                borderSize
        );
    }

    /**
     * Allows for manually drawing any sprite using nine-sliced mode.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite resource location
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderLeft   the border width on the left side of the sprite, for drawing the frame
     * @param borderTop    the border height on the top side of the sprite, for drawing the frame
     * @param borderRight  the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom the border height on the bottom side of the sprite, for drawing the frame
     */
    public static void blitNineSlicedSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom) {
        blitNineSlicedSprite(guiGraphics, sprite, x, y, 0, width, height, borderLeft, borderTop, borderRight,
                borderBottom
        );
    }

    /**
     * Allows for manually drawing any sprite using nine-sliced mode.
     * <p>
     * The width &amp; height dimensions are filled by repeatedly drawing pre-defined slices of the original sprite.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite resource location
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param blitOffset   the z-level offset
     * @param width        the width to draw
     * @param height       the height to draw
     * @param borderLeft   the border width on the left side of the sprite, for drawing the frame
     * @param borderTop    the border height on the top side of the sprite, for drawing the frame
     * @param borderRight  the border width on the right side of the sprite, for drawing the frame
     * @param borderBottom the border height on the bottom side of the sprite, for drawing the frame
     */
    public static void blitNineSlicedSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int blitOffset, int width, int height, int borderLeft, int borderTop, int borderRight, int borderBottom) {
        class_1058 textureAtlasSprite = class_310.method_1551().method_52699().method_18667(sprite);
        class_8690.class_8691 nineSlice = new class_8690.class_8691(textureAtlasSprite.method_45851().method_45807(),
                textureAtlasSprite.method_45851().method_45815(),
                new class_8690.class_8691.class_8692(borderLeft, borderTop, borderRight, borderBottom)
        );
        guiGraphics.method_52713(textureAtlasSprite, nineSlice, x, y, blitOffset, width, height);
    }

    /**
     * Manually draws a sprite using tile mode. Width &amp; height portions outside the texture dimensions are filled by
     * repeating the original texture.
     * <p>
     * Most sprites by default use the stretch mode, which squeezes them into the provided width &amp; height.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite resource location
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param width        the width to draw
     * @param height       the height to draw
     * @param spriteWidth  the sprite texture file width
     * @param spriteHeight the sprite texture file height
     */
    public static void blitTiledSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int width, int height, int spriteWidth, int spriteHeight) {
        blitTiledSprite(guiGraphics, sprite, x, y, 0, width, height, spriteWidth, spriteHeight);
    }

    /**
     * Manually draws a sprite using tile mode. Width &amp; height portions outside the texture dimensions are filled by
     * repeating the original texture.
     * <p>
     * Most sprites by default use the stretch mode, which squeezes them into the provided width &amp; height.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite resource location
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param blitOffset   the z-level offset
     * @param width        the width to draw
     * @param height       the height to draw
     * @param spriteWidth  the sprite texture file width
     * @param spriteHeight the sprite texture file height
     */
    public static void blitTiledSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int blitOffset, int width, int height, int spriteWidth, int spriteHeight) {
        blitTiledSprite(guiGraphics, sprite, x, y, blitOffset, width, height, spriteWidth, spriteHeight, 0, 0);
    }

    /**
     * Manually draws a sprite using tile mode. Width &amp; height portions outside the texture dimensions are filled by
     * repeating the original texture.
     * <p>
     * Most sprites by default use the stretch mode, which squeezes them into the provided width &amp; height.
     *
     * @param guiGraphics  the gui graphics instance
     * @param sprite       the sprite resource location
     * @param x            the x-position on the screen
     * @param y            the y-position on the screen
     * @param blitOffset   the z-level offset
     * @param width        the width to draw
     * @param height       the height to draw
     * @param spriteWidth  the sprite texture file width
     * @param spriteHeight the sprite texture file height
     * @param uOffset      the sprite u-offset on the texture sheet
     * @param vOffset      the sprite v-offset on the texture sheet
     */
    public static void blitTiledSprite(class_332 guiGraphics, class_2960 sprite, int x, int y, int blitOffset, int width, int height, int spriteWidth, int spriteHeight, int uOffset, int vOffset) {
        class_310 minecraft = class_310.method_1551();
        class_1058 textureatlassprite = minecraft.method_52699().method_18667(sprite);
        guiGraphics.method_52712(textureatlassprite, x, y, blitOffset, width, height, uOffset, vOffset, spriteWidth,
                spriteHeight, spriteWidth, spriteHeight
        );
    }
}
