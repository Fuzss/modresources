package fuzs.puzzleslib.api.util.v1;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1266;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1799;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * A helper class containing entity related methods.
 */
public final class EntityHelper {

    private EntityHelper() {
        // NO-OP
    }

    /**
     * Returns if an entity can equip some form of item in a certain slot.
     *
     * @param itemStack     the item stack to be equipped
     * @param equipmentSlot the slot the stack is trying to be equipped to
     * @param livingEntity  the entity trying to equip
     * @return is equipping the item stack allowed for the provided slot
     */
    public static boolean canEquip(class_1799 itemStack, class_1304 equipmentSlot, class_1309 livingEntity) {
        Objects.requireNonNull(itemStack, "item stack is null");
        Objects.requireNonNull(equipmentSlot, "equipment slot is null");
        Objects.requireNonNull(livingEntity, "living entity is null");
        return ProxyImpl.get().canEquip(itemStack, equipmentSlot, livingEntity);
    }

    /**
     * Retrieves a {@link class_3730} from a {@link class_1308} if it has been set during
     * {@link class_1308#method_5943(class_5425, class_1266, class_3730, class_1315)}.
     * <p>
     * Note that the spawn type is saved with the mob, so it persists across chunk and level reloads.
     *
     * @param entity the entity
     * @return the spawn type or null if none has been set or the entity is no {@link class_1308}
     */
    @Deprecated
    public static @Nullable class_3730 getMobSpawnReason(class_1297 entity) {
        Objects.requireNonNull(entity, "entity is null");
        return entity instanceof class_1308 mob ? ProxyImpl.get().getMobSpawnReason(mob) : null;
    }

    /**
     * Called instead of directly checking {@link net.minecraft.class_1928#field_19388}, allows for a
     * dedicated NeoForge event to run.
     *
     * @param serverLevel the level mob griefing is happening in
     * @param entity      the entity responsible for triggering the game rule check
     * @return is mob griefing allowed to happen
     */
    public static boolean isMobGriefingAllowed(class_3218 serverLevel, @Nullable class_1297 entity) {
        Objects.requireNonNull(serverLevel, "server level is null");
        return ProxyImpl.get().isMobGriefingAllowed(serverLevel, entity);
    }

    /**
     * Get the parent mob from a possible mob part entity, like
     * {@link net.minecraft.class_1508}.
     * <p>
     * NeoForge allows extending this, so we need this abstraction.
     *
     * @param entity the mob, possibly a mob part
     * @return the parent mob for the part, otherwise the original entity
     */
    public static class_1297 getPartEntityParent(class_1297 entity) {
        Objects.requireNonNull(entity, "entity is null");
        return ProxyImpl.get().getPartEntityParent(entity);
    }

    /**
     * Checks if the provided player is a fake player.
     *
     * @param serverPlayer the server player
     * @return is the provided player a fake player
     */
    public static boolean isFakePlayer(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return ProxyImpl.get().isFakePlayer(serverPlayer);
    }

    /**
     * Will {@link net.minecraft.class_4836 Piglins} give something back in exchange when given
     * this item.
     *
     * @param itemStack the item stack
     * @return is the item valid for bartering
     */
    public static boolean isPiglinCurrency(class_1799 itemStack) {
        return ProxyImpl.get().isPiglinCurrency(itemStack);
    }
}
