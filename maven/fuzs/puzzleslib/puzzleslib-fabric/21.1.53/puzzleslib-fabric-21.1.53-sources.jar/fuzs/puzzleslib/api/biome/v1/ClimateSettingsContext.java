package fuzs.puzzleslib.api.biome.v1;

import net.minecraft.class_1959;
import org.jetbrains.annotations.NotNull;

/**
 * The modification context for the biomes weather properties.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext$WeatherContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
public interface ClimateSettingsContext {

    /**
     * @see class_1959#method_48163()
     * @see class_1959.class_1960#method_48164(boolean)
     */
    void hasPrecipitation(boolean hasPrecipitation);

    /**
     * @see class_1959#method_48163()
     * @see class_1959.class_1960#method_48164(boolean)
     */
    boolean hasPrecipitation();

    /**
     * @see class_1959#method_8712()
     * @see class_1959.class_1960#method_8747(float)
     */
    void setTemperature(float temperature);

    /**
     * @see class_1959#method_8712()
     * @see class_1959.class_1960#method_8747(float)
     */
    float getTemperature();

    /**
     * @see class_1959.class_1960#method_30777(class_1959.class_5484)
     */
    void setTemperatureModifier(@NotNull class_1959.class_5484 temperatureModifier);

    /**
     * @see class_1959.class_1960#method_8727(float)
     */
    void setDownfall(float downfall);
}
