package fuzs.puzzleslib.api.client.core.v1.context;

import com.google.common.base.Predicates;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_5617;
import net.minecraft.class_583;

/**
 * Register additional {@link class_3887 RenderLayer} for any living entity, including players.
 */
@Deprecated
@FunctionalInterface
public interface LivingEntityRenderLayersContext {

    /**
     * Registers a render layer for all living entities.
     *
     * @param factory the new layer factory
     * @param <E>     the entity type
     * @param <T>     the entity type used for the model
     * @param <M>     the entity model
     */
    default <E extends class_1309, T extends E, M extends class_583<T>> void registerRenderLayer(BiFunction<class_3883<T, M>, class_5617.class_5618, class_3887<T, M>> factory) {
        this.registerRenderLayer(Predicates.alwaysTrue(), factory);
    }

    /**
     * Registers a render layer for a specific entity type.
     *
     * @param entityType the entity type to register for
     * @param factory    the new layer factory
     * @param <E>        the entity type
     * @param <T>        the entity type used for the model
     * @param <M>        the entity model
     */
    default <E extends class_1309, T extends E, M extends class_583<T>> void registerRenderLayer(class_1299<E> entityType, BiFunction<class_3883<T, M>, class_5617.class_5618, class_3887<T, M>> factory) {
        Objects.requireNonNull(entityType, "entity type is null");
        this.registerRenderLayer((class_1299<T> entityTypeX) -> {
            return entityTypeX == entityType;
        }, factory);
    }

    /**
     * Registers a render layer.
     *
     * @param filter  the filter for controlling affected entity types
     * @param factory the new layer factory
     * @param <E>     the entity type
     * @param <T>     the entity type used for the model
     * @param <M>     the entity model
     */
    <E extends class_1309, T extends E, M extends class_583<T>> void registerRenderLayer(Predicate<class_1299<E>> filter, BiFunction<class_3883<T, M>, class_5617.class_5618, class_3887<T, M>> factory);
}
