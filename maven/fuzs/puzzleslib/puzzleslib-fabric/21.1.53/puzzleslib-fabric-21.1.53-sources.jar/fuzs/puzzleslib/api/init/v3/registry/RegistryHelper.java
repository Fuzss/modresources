package fuzs.puzzleslib.api.init.v3.registry;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;

/**
 * A helper class for Minecraft's registries.
 */
@Deprecated
public final class RegistryHelper {

    private RegistryHelper() {
        // NO-OP
    }

    /**
     * Finds a registry for the provided {@link class_5321} from searching in {@link class_7923#field_41167}.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    public static <T> class_2378<T> findBuiltInRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        class_2378<T> registry = findNullableBuiltInRegistry(registryKey);
        Objects.requireNonNull(registry, () -> "registry for %s is null".formatted(registryKey));
        return registry;
    }

    /**
     * Finds a registry for the provided {@link class_5321} from searching in {@link class_7923#field_41167}.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    @SuppressWarnings("unchecked")
    @Nullable
    public static <T> class_2378<T> findNullableBuiltInRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        Objects.requireNonNull(registryKey, "registry key is null");
        return ((class_2378<class_2378<T>>) class_7923.field_41167).method_29107((class_5321<class_2378<T>>) registryKey);
    }

    /**
     * Finds a registry for the provided {@link class_5321}.
     * <p>
     * Dynamic registries are supported while a game server is already running.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    public static <T> class_2378<T> findGameRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        class_2378<T> registry = findNullableGameRegistry(registryKey);
        Objects.requireNonNull(registry, () -> "registry for %s is null".formatted(registryKey));
        return registry;
    }

    /**
     * Finds a registry for the provided {@link class_5321}.
     * <p>
     * Dynamic registries are supported while a game server is already running.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the corresponding registry
     */
    @SuppressWarnings("unchecked")
    public static <T> class_2378<T> findNullableGameRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Optional<class_2378<T>> registry = Optional.empty();
        MinecraftServer minecraftServer = CommonAbstractions.INSTANCE.getMinecraftServer();
        if (minecraftServer != null) {
            registry = minecraftServer.method_30611().method_33310((class_5321<class_2378<T>>) registryKey);
        }
        if (registry.isEmpty()) {
            registry = Optional.ofNullable(findNullableBuiltInRegistry(registryKey));
        }

        return registry.orElse(null);
    }

    /**
     * Retrieves the {@link class_5321} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the resource key for this game object
     */
    public static <T> Optional<class_5321<T>> getResourceKey(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return getHolderReference(registryKey, object).map(class_6880.class_6883::method_40237);
    }

    /**
     * Retrieves the {@link class_5321} for a game object from a {@link class_2378}.
     *
     * @param registry the registry
     * @param object   the game object to retrieve
     * @param <T>      registry and game object type
     * @return the resource key for this game object
     */
    public static <T> Optional<class_5321<T>> getResourceKey(class_2378<T> registry, T object) {
        return getHolderReference(registry, object).map(class_6880.class_6883::method_40237);
    }

    /**
     * Retrieves the {@link class_5321} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the resource key for this game object
     */
    public static <T> class_5321<T> getResourceKeyOrThrow(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return getResourceKey(registryKey, object).orElseThrow(() -> {
            return new IllegalStateException("Missing object in " + registryKey + ": " + object);
        });
    }

    /**
     * Retrieves the {@link class_5321} for a game object from a {@link class_2378}.
     *
     * @param registry the registry
     * @param object   the game object to retrieve
     * @param <T>      registry and game object type
     * @return the resource key for this game object
     */
    public static <T> class_5321<T> getResourceKeyOrThrow(class_2378<T> registry, T object) {
        return getResourceKey(registry, object).orElseThrow(() -> {
            return new IllegalStateException("Missing object in " + registry.method_30517() + ": " + object);
        });
    }

    /**
     * Retrieves the {@link class_6880.class_6883} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the holder reference for this game object
     */
    public static <T> Optional<class_6880.class_6883<T>> getHolderReference(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return Optional.ofNullable(getBuiltInRegistryHolder(object)).or(() -> {
            class_2378<T> registry = findGameRegistry(registryKey);
            return registry.method_29113(object).flatMap(registry::method_40264);
        });
    }

    /**
     * Retrieves the {@link class_6880.class_6883} for a game object from a {@link class_2378}.
     *
     * @param registry the registry
     * @param object   the game object to retrieve
     * @param <T>      registry and game object type
     * @return the holder reference for this game object
     */
    public static <T> Optional<class_6880.class_6883<T>> getHolderReference(class_2378<T> registry, T object) {
        return Optional.ofNullable(getBuiltInRegistryHolder(object)).or(() -> {
            return registry.method_29113(object).flatMap(registry::method_40264);
        });
    }

    /**
     * Retrieves the {@link class_6880.class_6883} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the holder reference for this game object
     */
    public static <T> class_6880.class_6883<T> getHolderOrThrow(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return getHolderReference(registryKey, object).orElseThrow(() -> {
            return new IllegalStateException("Missing object in " + registryKey + ": " + object);
        });
    }

    /**
     * Retrieves the {@link class_6880.class_6883} for a game object from a {@link class_2378}.
     *
     * @param registry the registry
     * @param object   the game object to retrieve
     * @param <T>      registry and game object type
     * @return the holder reference for this game object
     */
    public static <T> class_6880.class_6883<T> getHolderOrThrow(class_2378<T> registry, T object) {
        return getHolderReference(registry, object).orElseThrow(() -> {
            return new IllegalStateException("Missing object in " + registry.method_30517() + ": " + object);
        });
    }

    /**
     * Retrieves the {@link class_6880} for a game object from a {@link class_2378}.
     *
     * @param registryKey the registry key
     * @param object      the game object to retrieve
     * @param <T>         registry and game object type
     * @return the holder for this game object
     */
    public static <T> class_6880<T> wrapAsHolder(class_5321<? extends class_2378<? super T>> registryKey, T object) {
        return findGameRegistry(registryKey).method_47983(object);
    }

    /**
     * Checks if a certain tag contains a given value.
     *
     * @param tagKey the tag key
     * @param object the game object to check the tag key for
     * @param <T>    tag and game object type
     * @return is the game object contained in the tag
     */
    public static <T> boolean is(class_6862<T> tagKey, T object) {
        class_6880.class_6883<T> holder = getBuiltInRegistryHolder(object);
        if (holder != null) {
            return holder.method_40220(tagKey);
        } else {
            class_2378<T> registry = findGameRegistry(tagKey.comp_326());
            return tagKey.method_41007(registry.method_30517()) && registry.method_47983(object).method_40220(tagKey);
        }
    }

    /**
     * Get the built-in registry holder from a game object if available.
     *
     * @param object the game object to get the built-in registry holder from
     * @param <T>    game object type
     * @return the built-in holder for this game object if available
     */
    @SuppressWarnings({"deprecation", "unchecked"})
    @Nullable
    public static <T> class_6880.class_6883<T> getBuiltInRegistryHolder(T object) {
        return (class_6880.class_6883<T>) switch (object) {
            case class_2248 block -> block.method_40142();
            case class_1792 item -> item.method_40131();
            case class_1299<?> entityType -> entityType.method_40124();
            case class_3611 fluid -> fluid.method_40178();
            case class_2591<?> blockEntityType -> blockEntityType.method_53254();
            default -> null;
        };
    }
}
