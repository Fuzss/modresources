package fuzs.puzzleslib.fabric.impl.client.event;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.fabric.api.client.event.v1.registry.EntitySpectatorShaderRegistry;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public final class EntitySpectatorShaderRegistryImpl implements EntitySpectatorShaderRegistry {
    private static final Map<class_1299<?>, class_2960> SHADER_LOCATIONS = Maps.newLinkedHashMap();

    @Override
    public void register(class_1299<?> entityType, class_2960 shaderLocation) {
        Objects.requireNonNull(entityType, "entity type is null");
        Objects.requireNonNull(shaderLocation, "shader location is null");
        SHADER_LOCATIONS.put(entityType, shaderLocation);
    }

    public static Optional<class_2960> getEntityShader(@Nullable class_1297 entity) {
        if (entity != null && SHADER_LOCATIONS.containsKey(entity.method_5864())) {
            return Optional.of(SHADER_LOCATIONS.get(entity.method_5864()));
        } else {
            return Optional.empty();
        }
    }
}
