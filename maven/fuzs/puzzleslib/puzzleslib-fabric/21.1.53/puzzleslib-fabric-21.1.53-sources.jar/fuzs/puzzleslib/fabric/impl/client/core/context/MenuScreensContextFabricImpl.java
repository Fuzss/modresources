package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.MenuScreensContext;
import java.util.Objects;
import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_437;

public final class MenuScreensContextFabricImpl implements MenuScreensContext {

    @Override
    public <M extends class_1703, S extends class_437 & class_3936<M>> void registerMenuScreen(class_3917<? extends M> menuType, class_3929.class_3930<M, S> factory) {
        Objects.requireNonNull(menuType, "menu type is null");
        Objects.requireNonNull(factory, "factory is null");
        class_3929.method_17542(menuType, factory);
    }
}
