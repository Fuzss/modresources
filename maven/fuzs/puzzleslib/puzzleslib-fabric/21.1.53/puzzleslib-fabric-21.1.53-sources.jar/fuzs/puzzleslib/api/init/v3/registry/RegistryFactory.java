package fuzs.puzzleslib.api.init.v3.registry;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

/**
 * Create and register new {@link class_2378 Registries}.
 */
public interface RegistryFactory {
    /**
     * the instance
     */
    RegistryFactory INSTANCE = ProxyImpl.get().getRegistryFactoryV3();

    /**
     * Create and register a {@link net.minecraft.class_2370}.
     * <p>
     * Calls {@link #register(class_2378)} as part of the implementation.
     * <p>
     * Registry contents are synced to clients.
     *
     * @param registryKey the registry key
     * @param <T>         registry values type
     * @return the new registry
     */
    default <T> class_2378<T> create(class_5321<class_2378<T>> registryKey) {
        return this.create(registryKey, true);
    }

    /**
     * Create and register a {@link net.minecraft.class_2370}.
     * <p>
     * Calls {@link #register(class_2378)} as part of the implementation.
     *
     * @param registryKey the registry key
     * @param synced      sync registry contents to clients, so that numeric registry ids can be used in networking
     * @param <T>         registry values type
     * @return the new registry
     */
    <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, boolean synced);

    /**
     * Create and register a {@link net.minecraft.class_2348}.
     * <p>
     * Calls {@link #register(class_2378)} as part of the implementation.
     * <p>
     * Registry contents are synced to clients.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param <T>         registry values type
     * @return the new registry
     */
    default <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, String defaultKey) {
        return this.create(registryKey, defaultKey, true);
    }

    /**
     * Create and register a {@link net.minecraft.class_2348}.
     * <p>
     * Calls {@link #register(class_2378)} as part of the implementation.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param synced      sync registry contents to clients, so that numeric registry ids can be used in networking
     * @param <T>         registry values type
     * @return the new registry
     */
    default <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, String defaultKey, boolean synced) {
        return this.create(registryKey, registryKey.method_29177().method_45136(defaultKey), synced);
    }

    /**
     * Create and register a {@link net.minecraft.class_2348}.
     * <p>
     * Calls {@link #register(class_2378)} as part of the implementation.
     *
     * @param registryKey the registry key
     * @param defaultKey  the default value key
     * @param synced      sync registry contents to clients, so that numeric registry ids can be used in networking
     * @param <T>         registry values type
     * @return the new registry
     */
    <T> class_2378<T> create(class_5321<class_2378<T>> registryKey, class_2960 defaultKey, boolean synced);

    /**
     * Register an already constructed {@link class_2378}.
     *
     * @param registry the registry
     * @param <T>      registry values type
     * @return the registry
     */
    <T> class_2378<T> register(class_2378<T> registry);
}
