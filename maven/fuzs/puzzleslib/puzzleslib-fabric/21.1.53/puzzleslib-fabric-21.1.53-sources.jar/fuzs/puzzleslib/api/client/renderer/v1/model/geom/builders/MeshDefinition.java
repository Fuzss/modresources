package fuzs.puzzleslib.api.client.renderer.v1.model.geom.builders;

import com.google.common.collect.ImmutableList;
import fuzs.puzzleslib.api.client.renderer.v1.model.geom.PartPose;

import java.util.function.UnaryOperator;

/**
 * Copied from Minecraft 1.21.10.
 */
public class MeshDefinition extends net.minecraft.class_5609 {
    private final PartDefinition root;

    public MeshDefinition() {
        this(new PartDefinition(ImmutableList.of(), PartPose.ZERO));
    }

    public MeshDefinition(net.minecraft.class_5609 meshDefinition) {
        this(new PartDefinition(meshDefinition.method_32111()));
    }

    private MeshDefinition(PartDefinition root) {
        this.root = root;
    }

    @Override
    public PartDefinition method_32111() {
        return this.root;
    }

    public MeshDefinition transformed(UnaryOperator<PartPose> transformer) {
        return new MeshDefinition(this.root.transformed(transformer));
    }

    public MeshDefinition apply(MeshTransformer transformer) {
        return transformer.apply(this);
    }
}
