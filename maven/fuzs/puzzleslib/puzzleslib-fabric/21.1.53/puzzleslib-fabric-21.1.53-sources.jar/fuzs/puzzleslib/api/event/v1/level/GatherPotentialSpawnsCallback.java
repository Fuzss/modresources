package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.List;
import net.minecraft.class_1311;
import net.minecraft.class_2338;
import net.minecraft.class_2794;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_5138;
import net.minecraft.class_5483;
import net.minecraft.class_6880;

@FunctionalInterface
public interface GatherPotentialSpawnsCallback {
    EventInvoker<GatherPotentialSpawnsCallback> EVENT = EventInvoker.lookup(GatherPotentialSpawnsCallback.class);

    /**
     * Fires when building a list of all possible entities that can spawn at the specified location.
     *
     * @param level            the current level instance
     * @param structureManager the structure manager, used for applying {@link class_3195#method_41615()}
     * @param chunkGenerator   the chunk generator for calling
     *                         {@link class_2794#method_12113(class_6880, class_5138, class_1311, class_2338)}
     * @param mobCategory      the mob category to retrieve potential spawns for
     * @param blockPos         the block position the spawn attempt is made at
     * @param mobs             the vanilla list of mobs available for the given position
     */
    void onGatherPotentialSpawns(class_3218 level, class_5138 structureManager, class_2794 chunkGenerator, class_1311 mobCategory, class_2338 blockPos, List<class_5483.class_1964> mobs);
}
