package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import fuzs.puzzleslib.api.resources.v1.PackResourcesHelper;
import fuzs.puzzleslib.fabric.api.event.v1.registry.DataPackFinderRegistry;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.fabric.impl.resource.loader.ResourceManagerHelperImpl;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3285;
import java.util.Objects;

public final class DataPackSourcesContextFabricImpl implements PackRepositorySourcesContext {

    @Override
    public void registerRepositorySource(class_3285 repositorySource) {
        Objects.requireNonNull(repositorySource, "repository source is null");
        DataPackFinderRegistry.INSTANCE.register(repositorySource);
    }

    @Override
    public void registerBuiltInPack(class_2960 resourceLocation, class_2561 displayName, boolean shouldAddAutomatically) {
        Objects.requireNonNull(resourceLocation, "resource location is null");
        Objects.requireNonNull(displayName, "display name is null");
        registerBuiltInPack(resourceLocation, displayName, shouldAddAutomatically, class_3264.field_14190);
    }

    @SuppressWarnings("UnstableApiUsage")
    public static void registerBuiltInPack(class_2960 resourceLocation, class_2561 displayName, boolean shouldAddAutomatically, class_3264 packType) {
        ModContainer modContainer = FabricLoader.getInstance()
                .getModContainer(resourceLocation.method_12836())
                .orElseThrow();
        ResourceManagerHelperImpl.registerBuiltinResourcePack(resourceLocation,
                PackResourcesHelper.getBuiltInPack(resourceLocation, packType).method_12832(),
                modContainer,
                displayName,
                shouldAddAutomatically ? ResourcePackActivationType.DEFAULT_ENABLED :
                        ResourcePackActivationType.NORMAL);
    }
}
