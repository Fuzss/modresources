package fuzs.puzzleslib.api.client.data.v2;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonElement;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4910.class_4912;
import net.minecraft.class_4915;
import net.minecraft.class_4917;
import net.minecraft.class_4940;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;
import net.minecraft.class_5794;
import net.minecraft.class_6880;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import net.minecraft.data.models.model.*;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.*;

public abstract class AbstractModelProvider implements class_2405 {
    /**
     * @see #generateForItems(class_4915, BlockSetFamily, Map)
     */
    public static final Map<BlockSetVariant, BiConsumer<class_4915, class_1792>> VARIANT_WOOD_ITEM_PROVIDERS = ImmutableMap.<BlockSetVariant, BiConsumer<class_4915, class_1792>>builder()
            .put(BlockSetVariant.BOAT, (class_4915 itemModelGenerators, class_1792 item) -> {
                itemModelGenerators.method_25733(item, class_4943.field_22938);
            })
            .put(BlockSetVariant.CHEST_BOAT, (class_4915 itemModelGenerators, class_1792 item) -> {
                itemModelGenerators.method_25733(item, class_4943.field_22938);
            })
            .build();

    public static final String BLOCK_PATH = "block";
    public static final String ITEM_PATH = "item";
    public static final class_4942 SPAWN_EGG = class_4943.method_25859("template_spawn_egg");

    private final String modId;
    private final class_7784.class_7489 blockStatePathProvider;
    private final class_7784.class_7489 modelPathProvider;
    private final Set<Object> skipValidation = Sets.newHashSet();

    public AbstractModelProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput());
    }

    public AbstractModelProvider(String modId, class_7784 packOutput) {
        this.modId = modId;
        this.blockStatePathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "blockstates");
        this.modelPathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "models");
    }

    /**
     * @see #generateForBlocks(class_4910, BlockSetFamily, Map)
     */
    public static Map<BlockSetVariant, BiConsumer<class_4910, class_2248>> createVariantWoodBlockProviders(BlockSetFamily blockSetFamily, class_2248 strippedBlock) {
        return ImmutableMap.<BlockSetVariant, BiConsumer<class_4910, class_2248>>builder()
                .put(BlockSetVariant.HANGING_SIGN, (class_4910 blockModelGenerators, class_2248 block) -> {
                    class_6880.class_6883<class_2248> wallHangingSign = blockSetFamily.getBlock(BlockSetVariant.WALL_HANGING_SIGN);
                    Objects.requireNonNull(wallHangingSign, "wall hanging sign is null");
                    blockModelGenerators.method_46190(strippedBlock, block, wallHangingSign.comp_349());
                })
                .build();
    }

    public void addBlockModels(class_4910 builder) {
        // NO-OP
    }

    public void addItemModels(class_4915 builder) {
        // NO-OP
    }

    /**
     * @see class_4910#method_25650(class_2248)
     */
    public void generateForBlocks(class_4910 blockModelGenerators, BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<class_4910, class_2248>> variants) {
        this.generateForBlocks(blockModelGenerators,
                blockSetFamily,
                variants,
                class_4946.field_23036.get(blockSetFamily.getBaseBlock().comp_349()));
    }

    /**
     * @see class_4910#method_25650(class_2248)
     */
    public void generateForBlocks(class_4910 blockModelGenerators, BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<class_4910, class_2248>> variants, class_4946 texturedModel) {
        class_5794 blockFamily = blockSetFamily.getBlockFamily();
        if (blockFamily.method_33477()) {
            class_4910.class_4912 familyProvider = blockModelGenerators.new class_4912(
                    texturedModel.method_25921());
            familyProvider.field_22838 = texturedModel.method_25914().method_54828(blockFamily.method_33469());
            familyProvider.method_33522(blockFamily);
            blockSetFamily.getBlockVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_2248> holder) -> {
                BiConsumer<class_4910, class_2248> modelProvider = variants.get(variant);
                if (modelProvider != null) {
                    modelProvider.accept(blockModelGenerators, holder.comp_349());
                }
            });
        }
    }

    public void generateForItems(class_4915 itemModelGenerators, BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<class_4915, class_1792>> variants) {
        class_5794 blockFamily = blockSetFamily.getBlockFamily();
        if (blockFamily.method_33477()) {
            blockSetFamily.getItemVariants().forEach((BlockSetVariant variant, class_6880.class_6883<class_1792> holder) -> {
                BiConsumer<class_4915, class_1792> modelProvider = variants.get(variant);
                if (modelProvider != null) {
                    modelProvider.accept(itemModelGenerators, holder.comp_349());
                }
            });
        }
    }

    protected boolean skipValidation() {
        return false;
    }

    protected void skipBlock(class_2248 block) {
        this.skipValidation.add(block);
    }

    protected void skipItem(class_1792 item) {
        this.skipValidation.add(item);
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 output) {
        Map<class_2248, class_4917> generators = Maps.newHashMap();
        Consumer<class_4917> blockStateOutput = generator -> {
            class_2248 block = generator.method_25743();
            class_4917 blockstategenerator = generators.put(block, generator);
            if (blockstategenerator != null) {
                throw new IllegalStateException("Duplicate block state definition for " + block);
            }
        };
        Map<class_2960, Supplier<JsonElement>> models = Maps.newHashMap();
        Set<class_1792> skippedAutoModels = Sets.newHashSet();
        BiConsumer<class_2960, Supplier<JsonElement>> modelOutput = (resourceLocation, supplier) -> {
            if (models.put(resourceLocation, supplier) != null) {
                throw new IllegalStateException("Duplicate model definition for " + resourceLocation);
            }
        };
        this.addBlockModels(new class_4910(blockStateOutput, modelOutput, skippedAutoModels::add));
        this.addItemModels(new class_4915(modelOutput));
        List<class_2248> missingBlocks;
        if (!this.skipValidation()) {
            missingBlocks = class_7923.field_41175.method_29722().stream().filter(entry -> {
                return entry.getKey().method_29177().method_12836().equals(this.modId)
                        && !generators.containsKey(entry.getValue());
            }).map(Map.Entry::getValue).filter(Predicate.not(this.skipValidation::contains)).toList();
        } else {
            missingBlocks = Collections.emptyList();
        }
        if (!missingBlocks.isEmpty()) {
            throw new IllegalStateException("Missing block state definitions for " + missingBlocks);
        } else {
            class_7923.field_41175.method_29722().forEach(entry -> {
                class_1792 item = class_1792.field_8003.get(entry.getValue());
                if (item != null) {
                    if (!entry.getKey().method_29177().method_12836().equals(this.modId)
                            || skippedAutoModels.contains(item)) {
                        return;
                    }

                    class_2960 resourcelocation = class_4941.method_25840(item);
                    if (!models.containsKey(resourcelocation)) {
                        models.put(resourcelocation,
                                new class_4940(class_4941.method_25842(entry.getValue())));
                    }
                }
            });
            List<class_1792> missingItems;
            if (!this.skipValidation()) {
                missingItems = class_7923.field_41178.method_29722().stream().filter(entry -> {
                    return entry.getKey().method_29177().method_12836().equals(this.modId) && !models.containsKey(
                            decorateItemModelLocation(entry.getKey().method_29177()));
                }).map(Map.Entry::getValue).filter(Predicate.not(this.skipValidation::contains)).toList();
            } else {
                missingItems = Collections.emptyList();
            }
            if (!missingItems.isEmpty()) {
                throw new IllegalStateException("Missing item models for " + missingItems);
            } else {
                return CompletableFuture.allOf(saveCollection(output, generators, block -> {
                    return this.blockStatePathProvider.method_44107(block.method_40142().method_40237().method_29177());
                }), saveCollection(output, models, this.modelPathProvider::method_44107));
            }
        }
    }

    @Override
    public final String method_10321() {
        return "Model Definitions";
    }

    private static <T> CompletableFuture<?> saveCollection(class_7403 output, Map<T, ? extends Supplier<JsonElement>> map, Function<T, Path> pathExtractor) {
        return CompletableFuture.allOf(map.entrySet().stream().map((entry) -> {
            Path path = pathExtractor.apply(entry.getKey());
            JsonElement jsonElement = entry.getValue().get();
            return class_2405.method_10320(output, jsonElement, path);
        }).toArray(CompletableFuture[]::new));
    }

    public static class_2960 getModelLocation(class_2248 block) {
        return decorateBlockModelLocation(getLocation(block));
    }

    public static class_2960 decorateBlockModelLocation(class_2960 resourceLocation) {
        return resourceLocation.method_45138(BLOCK_PATH + "/");
    }

    public static class_2960 getLocation(class_2248 block) {
        return class_7923.field_41175.method_10221(block);
    }

    public static String getName(class_2248 block) {
        return getLocation(block).method_12832();
    }

    public static class_2960 getModelLocation(class_1792 item) {
        return decorateItemModelLocation(getLocation(item));
    }

    public static class_2960 decorateItemModelLocation(class_2960 resourceLocation) {
        return resourceLocation.method_45138(ITEM_PATH + "/");
    }

    public static class_2960 getLocation(class_1792 item) {
        return class_7923.field_41178.method_10221(item);
    }

    public static String getName(class_1792 item) {
        return getLocation(item).method_12832();
    }

    /**
     * Removes everything from the beginning of a resource location path up until and including the last occurrence of
     * the specified string.
     * <p>
     * Useful for e.g. removing directories from a path, like <code>minecraft:item/stick</code> ->
     * <code>minecraft:stick</code> by passing <code>/</code>.
     */
    public static class_2960 stripUntil(class_2960 resourceLocation, String s) {
        String path = resourceLocation.method_12832();
        if (path.contains(s)) {
            path = path.substring(path.lastIndexOf(s) + 1);
            return ResourceLocationHelper.fromNamespaceAndPath(resourceLocation.method_12836(), path);
        } else {
            return resourceLocation;
        }
    }

    public static class_4942 createBlockModelTemplate(class_2960 blockModelLocation, class_4945... requiredSlots) {
        return createBlockModelTemplate(blockModelLocation, "", requiredSlots);
    }

    public static class_4942 createBlockModelTemplate(class_2960 blockModelLocation, String suffix, class_4945... requiredSlots) {
        return new class_4942(Optional.of(decorateBlockModelLocation(blockModelLocation)),
                Optional.of(suffix),
                requiredSlots);
    }

    public static class_4942 createItemModelTemplate(class_2960 itemModelLocation, class_4945... requiredSlots) {
        return createItemModelTemplate(itemModelLocation, "", requiredSlots);
    }

    public static class_4942 createItemModelTemplate(class_2960 itemModelLocation, String suffix, class_4945... requiredSlots) {
        return new class_4942(Optional.of(decorateItemModelLocation(itemModelLocation)),
                Optional.of(suffix),
                requiredSlots);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return modelTemplate.method_25852(decorateItemModelLocation(resourceLocation),
                class_4944.method_25895(decorateItemModelLocation(resourceLocation)),
                modelOutput);
    }

    public static class_2960 generateFlatItem(class_1792 item, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return modelTemplate.method_48525(class_4941.method_25840(item),
                class_4944.method_25871(item),
                modelOutput,
                factory);
    }
}
