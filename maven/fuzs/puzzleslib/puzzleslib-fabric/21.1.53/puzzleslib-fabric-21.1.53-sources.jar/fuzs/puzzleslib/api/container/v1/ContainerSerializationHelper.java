package fuzs.puzzleslib.api.container.v1;

import java.util.function.IntFunction;
import java.util.function.ObjIntConsumer;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_7225;

/**
 * An adjusted version of {@link net.minecraft.class_1262} that allows for using {@link class_1263} instead of
 * {@link net.minecraft.class_2371}.
 * <p>
 * Also allows for changing the nbt key which is usually <code>Items</code>.
 */
public final class ContainerSerializationHelper extends class_1262 {
    public static final String TAG_ITEMS = "Items";
    public static final String TAG_SLOT = "Slot";

    private ContainerSerializationHelper() {
        // NO-OP
    }

    /**
     * Save items to a given tag, reading from an item list.
     * <p>
     * Equivalent to {@link class_1262#method_5426(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tag   tag to save to
     * @param items item list to save
     * @return the original tag
     */
    public static class_2487 method_5426(class_2487 tag, class_2371<class_1799> items, class_7225.class_7874 lookupProvider) {
        return class_1262.method_5426(tag, items, lookupProvider);
    }

    /**
     * Save items to a given tag, reading from a container.
     * <p>
     * Similar to {@link class_1262#method_5426(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tag       tag to save to
     * @param container container to save
     * @return the original tag
     */
    public static class_2487 saveAllItems(class_2487 tag, class_1263 container, class_7225.class_7874 lookupProvider) {
        return saveAllItems(tag, container, true, lookupProvider);
    }

    /**
     * Save items to a given tag, reading from an item list.
     * <p>
     * Similar to {@link class_1262#method_5426(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tagKey nbt tag key
     * @param tag    tag to save to
     * @param items  item list to save
     * @return the original tag
     */
    public static class_2487 saveAllItems(String tagKey, class_2487 tag, class_2371<class_1799> items, class_7225.class_7874 lookupProvider) {
        return saveAllItems(tagKey, tag, items, true, lookupProvider);
    }

    /**
     * Save items to a given tag, reading from a container.
     * <p>
     * Similar to {@link class_1262#method_5427(class_2487, class_2371, boolean, class_7225.class_7874)}.
     *
     * @param tag       tag to save to
     * @param container container to save
     * @param saveEmpty save to tag if completely empty
     * @return the original tag
     */
    public static class_2487 saveAllItems(class_2487 tag, class_1263 container, boolean saveEmpty, class_7225.class_7874 lookupProvider) {
        return saveAllItems(field_49719,
                tag,
                container.method_5439(),
                container::method_5438,
                saveEmpty,
                lookupProvider
        );
    }

    /**
     * Save items to a given tag, reading from an item list.
     * <p>
     * Equivalent to {@link class_1262#method_5427(class_2487, class_2371, boolean, class_7225.class_7874)}.
     *
     * @param tag       tag to save to
     * @param items     item list to save
     * @param saveEmpty save to tag if completely empty
     * @return the original tag
     */
    public static class_2487 method_5427(class_2487 tag, class_2371<class_1799> items, boolean saveEmpty, class_7225.class_7874 lookupProvider) {
        return class_1262.method_5427(tag, items, saveEmpty, lookupProvider);
    }

    /**
     * Save items to a given tag, reading from an item list.
     * <p>
     * Similar to {@link class_1262#method_5427(class_2487, class_2371, boolean, class_7225.class_7874)}.
     *
     * @param tagKey    nbt tag key
     * @param tag       tag to save to
     * @param items     item list to save
     * @param saveEmpty save to tag if completely empty
     * @return the original tag
     */
    public static class_2487 saveAllItems(String tagKey, class_2487 tag, class_2371<class_1799> items, boolean saveEmpty, class_7225.class_7874 lookupProvider) {
        return saveAllItems(tagKey, tag, items.size(), items::get, saveEmpty, lookupProvider);
    }

    /**
     * Save items to a given tag, reading from a provider.
     * <p>
     * Similar to {@link class_1262#method_5427(class_2487, class_2371, boolean, class_7225.class_7874)}.
     *
     * @param tagKey     nbt tag key
     * @param tag        tag to save to
     * @param size       item provider size
     * @param itemGetter get items from the provider
     * @param saveEmpty  save to tag if completely empty
     * @return the original tag
     */
    public static class_2487 saveAllItems(String tagKey, class_2487 tag, int size, IntFunction<class_1799> itemGetter, boolean saveEmpty, class_7225.class_7874 lookupProvider) {
        class_2499 listTag = createTag(size, itemGetter, lookupProvider);
        if (!listTag.isEmpty() || saveEmpty) {
            tag.method_10566(tagKey, listTag);
        }

        return tag;
    }

    /**
     * Create a list tag with all items from the provider. The tag is not saved anywhere yet.
     * <p>
     * Equivalent to {@link class_1277#method_7660(class_7225.class_7874)}.
     *
     * @param size       item provider size
     * @param itemGetter get items from the provider
     * @return the list tag
     */
    public static class_2499 createTag(int size, IntFunction<class_1799> itemGetter, class_7225.class_7874 lookupProvider) {
        class_2499 listTag = new class_2499();
        for (int i = 0; i < size; ++i) {
            class_1799 itemStack = itemGetter.apply(i);
            if (!itemStack.method_7960()) {
                class_2487 compoundTag = new class_2487();
                compoundTag.method_10567(TAG_SLOT, (byte) i);
                listTag.add(itemStack.method_57376(lookupProvider, compoundTag));
            }
        }
        return listTag;
    }

    /**
     * Read items from a given tag, saving them to an item list.
     * <p>
     * Equivalent to {@link class_1262#method_5429(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tag   tag to read from
     * @param items item list to fill
     */
    public static void method_5429(class_2487 tag, class_2371<class_1799> items, class_7225.class_7874 lookupProvider) {
        class_1262.method_5429(tag, items, lookupProvider);
    }

    /**
     * Read items from a given tag, saving them to a container.
     * <p>
     * Similar to {@link class_1262#method_5429(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tag       tag to read from
     * @param container container to fill
     */
    public static void loadAllItems(class_2487 tag, class_1263 container, class_7225.class_7874 lookupProvider) {
        loadAllItems(field_49719, tag, container.method_5439(), (class_1799 stack, int value) -> {
            container.method_5447(value, stack);
        }, lookupProvider);
    }

    /**
     * Read items from a given tag, saving them to an item list.
     * <p>
     * Similar to {@link class_1262#method_5429(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tagKey nbt tag key
     * @param tag    tag to read from
     * @param items  item list to fill
     */
    public static void loadAllItems(String tagKey, class_2487 tag, class_2371<class_1799> items, class_7225.class_7874 lookupProvider) {
        loadAllItems(tagKey, tag, items.size(), (class_1799 stack, int value) -> {
            items.set(value, stack);
        }, lookupProvider);
    }

    /**
     * Read items from a given tag, saving to a provider.
     * <p>
     * Similar to {@link class_1262#method_5429(class_2487, class_2371, class_7225.class_7874)}.
     *
     * @param tagKey     nbt tag key
     * @param tag        tag to read from
     * @param size       item provider size
     * @param itemSetter set items to the provider
     */
    public static void loadAllItems(String tagKey, class_2487 tag, int size, ObjIntConsumer<class_1799> itemSetter, class_7225.class_7874 lookupProvider) {
        class_2499 listTag = tag.method_10554(tagKey, class_2520.field_33260);
        fromTag(listTag, size, itemSetter, lookupProvider);
    }

    /**
     * Read items from a given tag, saving to a provider.
     * <p>
     * Equivalent to {@link net.minecraft.class_1277#method_7659(class_2499, class_7225.class_7874)}.
     *
     * @param listTag    the list tag
     * @param size       item provider size
     * @param itemSetter set items to the provider
     */
    public static void fromTag(class_2499 listTag, int size, ObjIntConsumer<class_1799> itemSetter, class_7225.class_7874 lookupProvider) {
        for (int i = 0; i < listTag.size(); ++i) {
            class_2487 compoundTag = listTag.method_10602(i);
            int slot = compoundTag.method_10571(TAG_SLOT) & 255;
            if (slot < size) {
                itemSetter.accept(class_1799.method_57360(lookupProvider, compoundTag).orElse(class_1799.field_8037), slot);
            }
        }
    }
}
