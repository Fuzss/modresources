package fuzs.puzzleslib.fabric.impl.client.event;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.mojang.blaze3d.systems.RenderSystem;
import fuzs.puzzleslib.fabric.api.client.event.v1.registry.ItemDecoratorRegistry;
import fuzs.puzzleslib.api.client.init.v1.DynamicItemDecorator;
import java.util.Collection;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1935;
import net.minecraft.class_327;
import net.minecraft.class_332;

public final class ItemDecoratorRegistryImpl implements ItemDecoratorRegistry {
    private static final Multimap<class_1792, DynamicItemDecorator> DECORATORS = HashMultimap.create();

    @Override
    public void register(class_1935 item, DynamicItemDecorator itemDecorator) {
        Objects.requireNonNull(item, "item is null");
        Objects.requireNonNull(item.method_8389(), "item is null");
        Objects.requireNonNull(itemDecorator, "decorator is null");
        DECORATORS.put(item.method_8389(), itemDecorator);
    }

    public static void render(class_332 guiGraphics, class_327 font, class_1799 stack, int itemPosX, int itemPosY) {
        Collection<DynamicItemDecorator> dynamicItemDecorators = DECORATORS.get(stack.method_7909());
        if (!dynamicItemDecorators.isEmpty()) {
            resetRenderState();
            for (DynamicItemDecorator itemDecorator : dynamicItemDecorators) {
                if (itemDecorator.renderItemDecorations(guiGraphics, font, stack, itemPosX, itemPosY)) {
                    resetRenderState();
                }
            }
        }
    }

    private static void resetRenderState() {
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }
}
