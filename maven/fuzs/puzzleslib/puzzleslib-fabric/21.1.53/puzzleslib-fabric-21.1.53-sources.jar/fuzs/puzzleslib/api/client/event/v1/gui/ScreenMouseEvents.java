package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.Objects;
import net.minecraft.class_437;

/**
 * Some javadoc has been copied from <code>net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents</code>.
 */
@SuppressWarnings("unchecked")
public final class ScreenMouseEvents {

    private ScreenMouseEvents() {
        // NO-OP
    }

    public static <T extends class_437> EventInvoker<BeforeMouseClick<T>> beforeMouseClick(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseClick<T>>) (Class<?>) BeforeMouseClick.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseClick<T>> afterMouseClick(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseClick<T>>) (Class<?>) AfterMouseClick.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeMouseRelease<T>> beforeMouseRelease(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseRelease<T>>) (Class<?>) BeforeMouseRelease.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseRelease<T>> afterMouseRelease(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseRelease<T>>) (Class<?>) AfterMouseRelease.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeMouseScroll<T>> beforeMouseScroll(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseScroll<T>>) (Class<?>) BeforeMouseScroll.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseScroll<T>> afterMouseScroll(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseScroll<T>>) (Class<?>) AfterMouseScroll.class, screen);
    }

    public static <T extends class_437> EventInvoker<BeforeMouseDrag<T>> beforeMouseDrag(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeMouseDrag<T>>) (Class<?>) BeforeMouseDrag.class, screen);
    }

    public static <T extends class_437> EventInvoker<AfterMouseDrag<T>> afterMouseDrag(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterMouseDrag<T>>) (Class<?>) AfterMouseDrag.class, screen);
    }

    @FunctionalInterface
    public interface BeforeMouseClick<T extends class_437> {

        /**
         * Called before a mouse button is pressed in a screen.
         *
         * @param screen      the currently displayed screen
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param mouseButton the button input code, see {@link net.minecraft.class_3675}
         * @return {@link EventResult#INTERRUPT} for marking the click event as handled, it will not be passed to other
         *         listeners and vanilla behavior will not run, {@link EventResult#PASS} for letting other listeners as
         *         well as vanilla process this event
         */
        EventResult onBeforeMouseClick(T screen, double mouseX, double mouseY, int mouseButton);
    }

    @FunctionalInterface
    public interface AfterMouseClick<T extends class_437> {

        /**
         * Called after a mouse button is pressed in a screen.
         *
         * @param screen      the currently displayed screen
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param mouseButton the button input code, see {@link net.minecraft.class_3675}
         */
        void onAfterMouseClick(T screen, double mouseX, double mouseY, int mouseButton);
    }

    @FunctionalInterface
    public interface BeforeMouseRelease<T extends class_437> {

        /**
         * Called before a mouse click has released in a screen.
         *
         * @param screen      the currently displayed screen
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param mouseButton the button input code, see {@link net.minecraft.class_3675}
         * @return {@link EventResult#INTERRUPT} for marking the release event as handled, it will not be passed to
         *         other listeners and vanilla behavior will not run, {@link EventResult#PASS} for letting other
         *         listeners as well as vanilla process this event
         */
        EventResult onBeforeMouseRelease(T screen, double mouseX, double mouseY, int mouseButton);
    }

    @FunctionalInterface
    public interface AfterMouseRelease<T extends class_437> {

        /**
         * Called after a mouse click has released in a screen.
         *
         * @param screen      the currently displayed screen
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param mouseButton the button input code, see {@link net.minecraft.class_3675}
         */
        void onAfterMouseRelease(T screen, double mouseX, double mouseY, int mouseButton);
    }

    @FunctionalInterface
    public interface BeforeMouseScroll<T extends class_437> {

        /**
         * Called before a mouse has scrolled on a screen.
         *
         * @param screen           the screen the mouse is scrolling on
         * @param mouseX           x-position of the mouse cursor
         * @param mouseY           y-position of the mouse cursor
         * @param horizontalAmount horizontal scroll amount
         * @param verticalAmount   vertical scroll amount
         * @return {@link EventResult#INTERRUPT} for marking the scroll event as handled, it will not be passed to other
         *         listeners and vanilla behavior will not run, {@link EventResult#PASS} for letting other listeners as
         *         well as vanilla process this event
         */
        EventResult onBeforeMouseScroll(T screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount);
    }

    @FunctionalInterface
    public interface AfterMouseScroll<T extends class_437> {

        /**
         * Called after a mouse has scrolled on a screen.
         *
         * @param screen           the screen the mouse is scrolling on
         * @param mouseX           x-position of the mouse cursor
         * @param mouseY           y-position of the mouse cursor
         * @param horizontalAmount horizontal scroll amount
         * @param verticalAmount   vertical scroll amount
         */
        void onAfterMouseScroll(T screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount);
    }

    @FunctionalInterface
    public interface BeforeMouseDrag<T extends class_437> {

        /**
         * Called before a mouse is dragged on screen.
         *
         * @param screen      the currently displayed screen
         * @param mouseX      mouse x-position
         * @param mouseY      mouse y-position
         * @param mouseButton mouse button that was clicked
         * @param dragX       how far the cursor has been dragged since last calling this on x
         * @param dragY       how far the cursor has been dragged since last calling this on y
         * @return {@link EventResult#INTERRUPT} for marking the drag event as handled, it will not be passed to other
         *         listeners and vanilla behavior will not run, {@link EventResult#PASS} for letting other listeners as
         *         well as vanilla process this event
         */
        EventResult onBeforeMouseDrag(T screen, double mouseX, double mouseY, int mouseButton, double dragX, double dragY);
    }

    @FunctionalInterface
    public interface AfterMouseDrag<T extends class_437> {

        /**
         * Called after a mouse is dragged on screen.
         *
         * @param screen      the currently displayed screen
         * @param mouseX      mouse x-position
         * @param mouseY      mouse y-position
         * @param mouseButton mouse button that was clicked
         * @param dragX       how far the cursor has been dragged since last calling this on x
         * @param dragY       how far the cursor has been dragged since last calling this on y
         */
        void onAfterMouseDrag(T screen, double mouseX, double mouseY, int mouseButton, double dragX, double dragY);
    }
}
