package fuzs.puzzleslib.api.client.renderer.v1.model.geom;

/**
 * Copied from Minecraft 1.21.10.
 */
public class PartPose extends net.minecraft.class_5603 {
    public static final PartPose ZERO = new PartPose(net.minecraft.class_5603.field_27701);

    public final float xScale;
    public final float yScale;
    public final float zScale;

    public PartPose(float x, float y, float z, float xRot, float yRot, float zRot, float xScale, float yScale, float zScale) {
        super(x, y, z, xRot, yRot, zRot);
        this.xScale = xScale;
        this.yScale = yScale;
        this.zScale = zScale;
    }

    public PartPose(net.minecraft.class_5603 partPose) {
        this(partPose.field_27702,
                partPose.field_27703,
                partPose.field_27704,
                partPose.field_27705,
                partPose.field_27706,
                partPose.field_27707,
                partPose instanceof PartPose pose ? pose.xScale : 1.0F,
                partPose instanceof PartPose pose ? pose.yScale : 1.0F,
                partPose instanceof PartPose pose ? pose.zScale : 1.0F);
    }

    public static PartPose method_32090(float x, float y, float z) {
        return new PartPose(net.minecraft.class_5603.method_32090(x, y, z));
    }

    public static PartPose method_32092(float xRot, float yRot, float zRot) {
        return new PartPose(net.minecraft.class_5603.method_32092(xRot, yRot, zRot));
    }

    public static PartPose method_32091(float x, float y, float z, float xRot, float yRot, float zRot) {
        return new PartPose(net.minecraft.class_5603.method_32091(x, y, z, xRot, yRot, zRot));
    }

    public PartPose translated(float x, float y, float z) {
        return new PartPose(this.field_27702 + x,
                this.field_27703 + y,
                this.field_27704 + z,
                this.field_27705,
                this.field_27706,
                this.field_27707,
                this.xScale,
                this.yScale,
                this.zScale);
    }

    public PartPose withScale(float scale) {
        return new PartPose(this.field_27702, this.field_27703, this.field_27704, this.field_27705, this.field_27706, this.field_27707, scale, scale, scale);
    }

    public PartPose scaled(float scale) {
        return scale == 1.0F ? this : this.scaled(scale, scale, scale);
    }

    public PartPose scaled(float x, float y, float z) {
        return new PartPose(this.field_27702 * x,
                this.field_27703 * y,
                this.field_27704 * z,
                this.field_27705,
                this.field_27706,
                this.field_27707,
                this.xScale * x,
                this.yScale * y,
                this.zScale * z);
    }
}
