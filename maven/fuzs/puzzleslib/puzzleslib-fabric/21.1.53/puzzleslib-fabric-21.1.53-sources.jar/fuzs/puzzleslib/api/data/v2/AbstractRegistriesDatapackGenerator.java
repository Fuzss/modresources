package fuzs.puzzleslib.api.data.v2;

import com.google.common.base.CaseFormat;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.data.v2.core.RegistriesDataProvider;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5475;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7877;
import net.minecraft.class_7891;
import net.minecraft.class_8054;
import net.minecraft.class_8107;
import net.minecraft.class_8110;
import net.minecraft.class_8931;
import net.minecraft.core.*;
import org.apache.commons.lang3.StringUtils;

import java.util.Collections;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public abstract class AbstractRegistriesDatapackGenerator<T> extends class_5475 implements RegistriesDataProvider {
    private final CompletableFuture<class_7225.class_7874> fullRegistries;
    private final class_5321<? extends class_2378<T>> registryKey;

    public AbstractRegistriesDatapackGenerator(class_5321<? extends class_2378<T>> registryKey, DataProviderContext context) {
        this(registryKey, context.getPackOutput(), context.getRegistries());
    }

    public AbstractRegistriesDatapackGenerator(class_5321<? extends class_2378<T>> registryKey, class_7784 output, CompletableFuture<class_7225.class_7874> registries) {
        super(output, CompletableFuture.completedFuture(class_5455.field_40585));
        CompletableFuture<class_7877.class_8993> patchedRegistries = class_8931.method_54840(
                registries,
                new class_7877().method_46777(registryKey, AbstractRegistriesDatapackGenerator.this::addBootstrap)
        );
        this.field_40952 = patchedRegistries.thenApply(class_7877.class_8993::comp_2114);
        this.fullRegistries = patchedRegistries.thenApply(class_7877.class_8993::comp_2113);
        this.registryKey = registryKey;
    }

    public abstract void addBootstrap(class_7891<T> context);

    @Override
    public String method_10321() {
        return getNameFromRegistryPath(this.registryKey.method_29177().method_12832()) + " Registry";
    }

    static String getNameFromRegistryPath(String registryPath) {
        String registryName = registryPath.replaceAll("\\W", "_");
        registryName = CaseFormat.LOWER_UNDERSCORE.converterTo(CaseFormat.UPPER_CAMEL).convert(registryName);
        return StringUtils.join(StringUtils.splitByCharacterTypeCamelCase(registryName), ' ');
    }

    @Override
    public CompletableFuture<class_7225.class_7874> getRegistries() {
        return this.fullRegistries;
    }

    protected static void registerEnchantment(class_7891<class_1887> context, class_5321<class_1887> resourceKey, class_1887.class_9700 builder) {
        context.method_46838(resourceKey, builder.method_60060(resourceKey.method_29177()));
    }

    protected static void registerDamageType(class_7891<class_8110> context, class_5321<class_8110> resourceKey) {
        context.method_46838(resourceKey, new class_8110(resourceKey.method_29177().method_12832(), 0.1F));
    }

    protected static void registerDamageType(class_7891<class_8110> context, class_5321<class_8110> resourceKey, class_8107 damageEffects) {
        context.method_46838(resourceKey, new class_8110(resourceKey.method_29177().method_12832(), 0.1F, damageEffects));
    }

    protected static void registerTrimMaterial(class_7891<class_8054> context, class_5321<class_8054> resourceKey, class_1792 ingredient, int descriptionColor, float itemModelIndex) {
        registerTrimMaterial(context,
                resourceKey,
                ingredient,
                descriptionColor,
                itemModelIndex,
                Collections.emptyMap()
        );
    }

    protected static void registerTrimMaterial(class_7891<class_8054> context, class_5321<class_8054> resourceKey, class_1792 ingredient, int descriptionColor, float itemModelIndex, Map<class_6880<class_1741>, String> overrideArmorMaterials) {
        class_2561 component = class_2561.method_43471(class_156.method_646("trim_material", resourceKey.method_29177()))
                .method_27696(class_2583.field_24360.method_36139(descriptionColor));
        class_8054 trimMaterial = class_8054.method_48438(resourceKey.method_29177().method_12832(),
                ingredient,
                itemModelIndex,
                component,
                overrideArmorMaterials
        );
        context.method_46838(resourceKey, trimMaterial);
    }
}
