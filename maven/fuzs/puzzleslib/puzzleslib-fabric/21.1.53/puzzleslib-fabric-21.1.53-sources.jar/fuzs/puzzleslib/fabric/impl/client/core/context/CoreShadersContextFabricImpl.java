package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.CoreShadersContext;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5944;
import java.io.IOException;
import java.util.Objects;
import java.util.function.Consumer;

public record CoreShadersContextFabricImpl(
        CoreShaderRegistrationCallback.RegistrationContext context) implements CoreShadersContext {

    @Override
    public void registerCoreShader(class_2960 id, class_293 vertexFormat, Consumer<class_5944> loadCallback) {
        Objects.requireNonNull(id, "id is null");
        Objects.requireNonNull(vertexFormat, "vertex format is null");
        Objects.requireNonNull(loadCallback, "load callback is null");
        try {
            this.context.register(id, vertexFormat, loadCallback);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
