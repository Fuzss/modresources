package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.init.v1.SkullRenderersFactory;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Function;
import net.minecraft.class_2484;
import net.minecraft.class_2960;
import net.minecraft.class_5598;
import net.minecraft.class_5599;
import net.minecraft.class_836;

/**
 * register models for custom {@link net.minecraft.class_2484.class_2485} implementations
 */
@FunctionalInterface
public interface SkullRenderersContext {

    /**
     * add models for specific skull types
     *
     * @param factory factory for the model(s)
     */
    @Deprecated
    void registerSkullRenderer(SkullRenderersFactory factory);

    /**
     * @param skullBlockType    the skull block type
     * @param textureLocation   the texture location, usually for the corresponding entity
     * @param skullModelFactory the skull model factory
     */
    default void registerSkullRenderer(class_2484.class_2485 skullBlockType, class_2960 textureLocation, Function<class_5599, class_5598> skullModelFactory) {
        Objects.requireNonNull(skullBlockType, "skull block type is null");
        Objects.requireNonNull(textureLocation, "texture location is null");
        Objects.requireNonNull(skullModelFactory, "skull model factory is null");
        // This is fine on NeoForge regarding a ConcurrentModificationException, as the event is fired sequentially.
        class_836.field_4390.put(skullBlockType, textureLocation);
        this.registerSkullRenderer((class_5599 entityModelSet, BiConsumer<class_2484.class_2485, class_5598> consumer) -> {
            consumer.accept(skullBlockType, skullModelFactory.apply(entityModelSet));
        });
    }
}
