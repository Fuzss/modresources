package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1921;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_9779;
import org.joml.Matrix4f;

public final class RenderLevelEvents {
    public static final EventInvoker<AfterTerrain> AFTER_TERRAIN = EventInvoker.lookup(AfterTerrain.class);
    public static final EventInvoker<AfterEntities> AFTER_ENTITIES = EventInvoker.lookup(AfterEntities.class);
    public static final EventInvoker<AfterTranslucent> AFTER_TRANSLUCENT = EventInvoker.lookup(AfterTranslucent.class);
    public static final EventInvoker<AfterLevel> AFTER_LEVEL = EventInvoker.lookup(AfterLevel.class);

    private RenderLevelEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface AfterTerrain {

        /**
         * Fires after all three solid block render types ({@link class_1921#method_23577()},
         * {@link class_1921#method_23579()}, and {@link class_1921#method_23581()}) have been rendered in a level.
         *
         * @param levelRenderer    the level renderer instance
         * @param camera           the camera instance
         * @param gameRenderer     the game renderer instance
         * @param deltaTracker     partial tick time
         * @param poseStack        current pose stack
         * @param projectionMatrix the projection matrix from the pose stack
         * @param frustum          frustum instance
         * @param level            the current client level
         */
        void onRenderLevelAfterTerrain(class_761 levelRenderer, class_4184 camera, class_757 gameRenderer, class_9779 deltaTracker, class_4587 poseStack, Matrix4f projectionMatrix, class_4604 frustum, class_638 level);
    }

    @FunctionalInterface
    public interface AfterEntities {

        /**
         * Fires after entities have been rendered in a level.
         *
         * @param levelRenderer    the level renderer instance
         * @param camera           the camera instance
         * @param gameRenderer     the game renderer instance
         * @param deltaTracker     partial tick time
         * @param poseStack        current pose stack
         * @param projectionMatrix the projection matrix from the pose stack
         * @param frustum          frustum instance
         * @param level            the current client level
         */
        void onRenderLevelAfterEntities(class_761 levelRenderer, class_4184 camera, class_757 gameRenderer, class_9779 deltaTracker, class_4587 poseStack, Matrix4f projectionMatrix, class_4604 frustum, class_638 level);
    }

    @FunctionalInterface
    public interface AfterTranslucent {

        /**
         * Fires after translucent objects ({@link class_1921#method_23583()}, {@link class_1921#method_29997()}, and
         * particles) have been rendered in a level.
         *
         * @param levelRenderer    the level renderer instance
         * @param camera           the camera instance
         * @param gameRenderer     the game renderer instance
         * @param deltaTracker     partial tick time
         * @param poseStack        current pose stack
         * @param projectionMatrix the projection matrix from the pose stack
         * @param frustum          frustum instance
         * @param level            the current client level
         */
        void onRenderLevelAfterTranslucent(class_761 levelRenderer, class_4184 camera, class_757 gameRenderer, class_9779 deltaTracker, class_4587 poseStack, Matrix4f projectionMatrix, class_4604 frustum, class_638 level);
    }

    @FunctionalInterface
    public interface AfterLevel {

        /**
         * Fires after a level has been fully rendered.
         *
         * @param levelRenderer    the level renderer instance
         * @param camera           the camera instance
         * @param gameRenderer     the game renderer instance
         * @param deltaTracker     partial tick time
         * @param poseStack        current pose stack
         * @param projectionMatrix the projection matrix from the pose stack
         * @param frustum          frustum instance
         * @param level            the current client level
         */
        void onRenderLevelAfterLevel(class_761 levelRenderer, class_4184 camera, class_757 gameRenderer, class_9779 deltaTracker, class_4587 poseStack, Matrix4f projectionMatrix, class_4604 frustum, class_638 level);
    }
}
