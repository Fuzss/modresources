package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.ColorProvidersContext;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_322;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public final class BlockColorProvidersContextFabricImpl implements ColorProvidersContext<class_2248, class_322> {

    @Override
    public void registerColorProvider(class_322 provider, class_2248... blocks) {
        Objects.requireNonNull(provider, "provider is null");
        Objects.requireNonNull(blocks, "blocks is null");
        Preconditions.checkState(blocks.length > 0, "blocks is empty");
        for (class_2248 block : blocks) {
            Objects.requireNonNull(block, "block is null");
            ColorProviderRegistry.BLOCK.register(provider, block);
        }
    }

    @Override
    public @Nullable class_322 getProvider(class_2248 block) {
        return ColorProviderRegistry.BLOCK.get(block);
    }
}
