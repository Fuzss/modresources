package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_6880;

public final class PlayLevelSoundEvents {
    public static final EventInvoker<AtPosition> POSITION = EventInvoker.lookup(AtPosition.class);
    public static final EventInvoker<AtEntity> ENTITY = EventInvoker.lookup(AtEntity.class);

    private PlayLevelSoundEvents() {

    }

    @FunctionalInterface
    public interface AtPosition {

        /**
         * Called when a sound event is played at a specific position in the world, allows for cancelling the sound.
         *
         * @param level         the current level
         * @param position      the position the sound is to be played at
         * @param sound         the sound event, can be exchanged here
         * @param source        sound category
         * @param volume        volume
         * @param pitch         pitch
         * @return              if present the sound will be cancelled
         */
        EventResult onPlaySoundAtPosition(class_1937 level, class_243 position, MutableValue<class_6880<class_3414>> sound, MutableValue<class_3419> source, DefaultedFloat volume, DefaultedFloat pitch);
    }

    @FunctionalInterface
    public interface AtEntity {

        /**
         * Called when a sound event is played at a specific entity, allows for cancelling the sound.
         *
         * @param level         the current level
         * @param entity        the entity the sound is playing from
         * @param sound         the sound event, can be exchanged here
         * @param source        sound category
         * @param volume        volume
         * @param pitch         pitch
         * @return              if present the sound will be cancelled
         */
        EventResult onPlaySoundAtEntity(class_1937 level, class_1297 entity, MutableValue<class_6880<class_3414>> sound, MutableValue<class_3419> source, DefaultedFloat volume, DefaultedFloat pitch);
    }
}
