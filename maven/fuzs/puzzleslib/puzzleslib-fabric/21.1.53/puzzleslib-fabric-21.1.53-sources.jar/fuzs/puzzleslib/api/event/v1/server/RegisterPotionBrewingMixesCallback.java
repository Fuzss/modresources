package fuzs.puzzleslib.api.event.v1.server;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_1792;
import net.minecraft.class_1812;
import net.minecraft.class_1842;
import net.minecraft.class_1847;
import net.minecraft.class_1856;
import net.minecraft.class_6880;

@FunctionalInterface
public interface RegisterPotionBrewingMixesCallback {
    EventInvoker<RegisterPotionBrewingMixesCallback> EVENT = EventInvoker.lookup(RegisterPotionBrewingMixesCallback.class);

    /**
     * Called when potion brewing recipes are set up in {@link net.minecraft.class_1845}.
     *
     * @param builder a builder instance wrapping {@link net.minecraft.class_1845.class_9665}
     */
    void onRegisterPotionBrewingMixes(Builder builder);

    /**
     * A registry for adding new recipes valid for the brewing stand.
     * <p>
     * The implementation also supports {@link class_1856} in addition to {@link class_1792}.
     */
    interface Builder {

        /**
         * Register an item that can hold potions.
         *
         * @param item the potion container item
         */
        void registerPotionContainer(class_1812 item);

        /**
         * Register a brewing stand recipe that converts a potion item container to another form, the potion inside will
         * stay the same. E.g. in vanilla convert a normal potion to a splash potion by adding gunpowder.
         *
         * @param from the base potion container item
         * @param item ingredient used for the conversion
         * @param to   the output potion container item
         */
        default void registerContainerRecipe(class_1812 from, class_1792 item, class_1812 to) {
            this.registerContainerRecipe(from, class_1856.method_8091(item), to);
        }

        /**
         * Register a brewing stand recipe that converts a potion item container to another form, the potion inside will
         * stay the same. E.g. in vanilla convert a normal potion to a splash potion by adding gunpowder.
         *
         * @param from       the base potion container item
         * @param ingredient ingredient used for the conversion
         * @param to         the output potion container item
         */
        void registerContainerRecipe(class_1812 from, class_1856 ingredient, class_1812 to);

        /**
         * Register a brewing stand recipe that converts a potion to another potion, the potion item container will stay the
         * same. E.g. in vanilla convert a night vision potion to an invisibility potion by adding fermented spider eye.
         *
         * @param from the base potion
         * @param item ingredient used for the conversion
         * @param to   the output potion
         */
        default void registerPotionRecipe(class_6880<class_1842> from, class_1792 item, class_6880<class_1842> to) {
            this.registerPotionRecipe(from, class_1856.method_8091(item), to);
        }

        /**
         * Register a brewing stand recipe that converts a potion to another potion, the potion item container will stay the
         * same. E.g. in vanilla convert a night vision potion to an invisibility potion by adding fermented spider eye.
         *
         * @param from       the base potion
         * @param ingredient ingredient used for the conversion
         * @param to         the output potion
         */
        void registerPotionRecipe(class_6880<class_1842> from, class_1856 ingredient, class_6880<class_1842> to);

        /**
         * Register a brewing stand recipe that converts an awkward potion to another potion. E.g. in vanilla convert an
         * awkward potion to a strength potion by adding blaze powder.
         * <p>
         * Additionally, registers a recipe for converting a water potion to a mundane potion using the provided ingredient,
         * as is possible for all vanilla ingredients.
         *
         * @param item ingredient used for the conversion
         * @param to   the output potion
         */
        default void registerStartPotionRecipe(class_1792 item, class_6880<class_1842> to) {
            this.registerStartPotionRecipe(class_1856.method_8091(item), to);
        }

        /**
         * Register a brewing stand recipe that converts an awkward potion to another potion. E.g. in vanilla convert an
         * awkward potion to a strength potion by adding blaze powder.
         * <p>
         * Additionally, registers a recipe for converting a water potion to a mundane potion using the provided ingredient,
         * as is possible for all vanilla ingredients.
         *
         * @param ingredient ingredient used for the conversion
         * @param to         the output potion
         */
        default void registerStartPotionRecipe(class_1856 ingredient, class_6880<class_1842> to) {
            this.registerPotionRecipe(class_1847.field_8991, ingredient, class_1847.field_8967);
            this.registerPotionRecipe(class_1847.field_8999, ingredient, to);
        }
    }
}
