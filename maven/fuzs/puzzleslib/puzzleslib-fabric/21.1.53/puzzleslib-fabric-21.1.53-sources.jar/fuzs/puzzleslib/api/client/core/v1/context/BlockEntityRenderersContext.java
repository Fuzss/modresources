package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_5614;

/**
 * register a renderer for a block entity
 */
@FunctionalInterface
public interface BlockEntityRenderersContext {

    /**
     * registers an {@link net.minecraft.class_827} for a given block entity
     *
     * @param blockEntityType             block entity type token to render for
     * @param blockEntityRendererProvider block entity renderer provider
     * @param <T>                         type of entity
     */
    <T extends class_2586> void registerBlockEntityRenderer(class_2591<? extends T> blockEntityType, class_5614<T> blockEntityRendererProvider);
}
