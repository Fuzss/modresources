package fuzs.puzzleslib.api.init.v3;

import fuzs.puzzleslib.impl.init.MinecartTypeRegistryImpl;
import net.minecraft.class_1688;
import net.minecraft.class_1937;

/**
 * Register a {@link class_1688} factory for a custom {@link class_1688.class_1689} that is created when an
 * instance of {@link net.minecraft.class_1808} is placed in the world by a player or dispenser.
 * <p>
 * The type must be created separately, e.g. using <a href="https://github.com/Fuzss/extensibleenums">Extensible Enums</a>.
 */
public interface MinecartTypeRegistry {
    /**
     * The singleton instance of the decorator registry.
     * Use this instance to call the methods in this interface.
     */
    MinecartTypeRegistry INSTANCE = new MinecartTypeRegistryImpl();

    /**
     * Register the custom minecart type.
     *
     * @param type    minecart type
     * @param factory minecart entity factory
     */
    void register(class_1688.class_1689 type, Factory factory);

    /**
     * Factory for creating a custom minecart entity.
     */
    interface Factory {

        /**
         * @param level level to spawn the entity in
         * @param x     x-position to place the entity at
         * @param y     y-position to place the entity at
         * @param z     z-position to place the entity at
         * @return minecart entity
         */
        class_1688 create(class_1937 level, double x, double y, double z);
    }
}
