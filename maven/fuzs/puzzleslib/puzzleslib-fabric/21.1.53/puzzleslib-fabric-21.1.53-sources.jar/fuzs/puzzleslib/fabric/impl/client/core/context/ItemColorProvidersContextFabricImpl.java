package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.ColorProvidersContext;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_1792;
import net.minecraft.class_1935;
import net.minecraft.class_326;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

public final class ItemColorProvidersContextFabricImpl implements ColorProvidersContext<class_1792, class_326> {

    @Override
    public void registerColorProvider(class_326 provider, class_1792... items) {
        Objects.requireNonNull(provider, "provider is null");
        Objects.requireNonNull(items, "items is null");
        Preconditions.checkState(items.length > 0, "items is empty");
        for (class_1935 item : items) {
            Objects.requireNonNull(item, "item is null");
            ColorProviderRegistry.ITEM.register(provider, item);
        }
    }

    @Override
    public @Nullable class_326 getProvider(class_1792 item) {
        return ColorProviderRegistry.ITEM.get(item);
    }
}
