package fuzs.puzzleslib.fabric.impl.attachment.builder;

import com.mojang.serialization.Codec;
import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import fuzs.puzzleslib.api.network.v3.PlayerSet;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_2586;
import net.minecraft.class_5455;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public final class FabricBlockEntityDataAttachmentBuilder<V> extends FabricDataAttachmentBuilder<class_2586, V> implements DataAttachmentRegistry.BlockEntityBuilder<V> {

    @Override
    public DataAttachmentRegistry.BlockEntityBuilder<V> defaultValue(Predicate<class_2586> defaultFilter, Function<class_5455, V> defaultValueProvider) {
        Objects.requireNonNull(defaultFilter, "default filter is null");
        Objects.requireNonNull(defaultValueProvider, "default value provider is null");
        this.defaultValues.put(defaultFilter, defaultValueProvider);
        return this;
    }

    @Override
    protected class_5455 getRegistryAccess(class_2586 holder) {
        return holder.method_10997().method_30349();
    }

    @Override
    public DataAttachmentRegistry.BlockEntityBuilder<V> defaultValue(Function<class_5455, V> defaultValueProvider) {
        return (DataAttachmentRegistry.BlockEntityBuilder<V>) super.defaultValue(defaultValueProvider);
    }

    @Override
    public DataAttachmentRegistry.BlockEntityBuilder<V> persistent(Codec<V> codec) {
        return (DataAttachmentRegistry.BlockEntityBuilder<V>) super.persistent(codec);
    }

    @Override
    public DataAttachmentRegistry.BlockEntityBuilder<V> networkSynchronized(class_9139<? super class_9129, V> streamCodec, Function<class_2586, PlayerSet> targetSelector) {
        return (DataAttachmentRegistry.BlockEntityBuilder<V>) super.networkSynchronized(streamCodec, targetSelector);
    }
}
