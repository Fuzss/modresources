package fuzs.puzzleslib.api.codec.v1;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;
import java.util.function.Predicate;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_5699;

/**
 * Additional codecs similar to {@link class_5699}.
 */
@Deprecated
public final class CodecExtras {
    /**
     * A codec version of the serialization methods in {@link net.minecraft.class_1262}.
     */
    public static final Codec<class_2371<class_1799>> NON_NULL_ITEM_STACK_LIST_CODEC = fuzs.puzzleslib.api.util.v1.CodecExtras.NON_NULL_ITEM_STACK_LIST_CODEC;

    private CodecExtras() {
        // NO-OP
    }

    /**
     * Creates a codec for {@link class_2371}. List elements are stored together with their index.
     *
     * @param codec        the list element codec
     * @param filter       a filter for skipping empty elements, like empty item stacks
     * @param defaultValue the default empty value for the list
     * @param <T>          the list element type
     * @return the codec
     */
    public static <T> Codec<class_2371<T>> nonNullList(Codec<T> codec, Predicate<T> filter, @Nullable T defaultValue) {
        return fuzs.puzzleslib.api.util.v1.CodecExtras.nonNullList(codec, filter, defaultValue);
    }

    /**
     * A helper for turning results from {@link com.mojang.serialization.Encoder#encode(Object, DynamicOps, Object)} and
     * {@link com.mojang.serialization.Encoder#encodeStart(DynamicOps, Object)} into {@link class_2487} when
     * serializing using {@link net.minecraft.class_2509}.
     * <p>
     * To be used with {@link Codec#flatMap(Function)}.
     *
     * @return the mapping function
     */
    public static Function<class_2520, DataResult<class_2487>> mapCompoundTag() {
        return fuzs.puzzleslib.api.util.v1.CodecExtras.mapCompoundTag();
    }
}
