package fuzs.puzzleslib.api.event.v1.entity;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.jetbrains.annotations.Nullable;

public final class ServerEntityEvents {
    public static final EventInvoker<Join> JOIN = EventInvoker.lookup(Join.class);
    public static final EventInvoker<Load> LOAD = EventInvoker.lookup(Load.class);
    public static final EventInvoker<Unload> UNLOAD = EventInvoker.lookup(Unload.class);

    private ServerEntityEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Join {

        /**
         * Fired before an entity is added to the level on the server, allowing it to be prevented from loading in.
         * <p>
         * Accessing chunks here (e.g. {@link class_5425#method_8404(class_2338)}) can deadlock the
         * game. Use {@link Load} instead when chunk access is needed.
         *
         * @param entity           the entity being added
         * @param serverLevel      the level the entity is added to
         * @param isLoadedFromDisk the entity was loaded from storage rather than spawned
         * @param spawnReason      the spawn reason, if captured
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to discard the entity</li>
         *         <li>{@link EventResult#PASS PASS} to add it normally</li>
         *         </ul>
         */
        EventResult onEntityJoin(class_1297 entity, class_3218 serverLevel, boolean isLoadedFromDisk, @Nullable class_3730 spawnReason);
    }

    @FunctionalInterface
    public interface Load {

        /**
         * Fired after an entity has been added to the level on the server in a state safe to modify.
         *
         * @param entity           the entity that was added
         * @param serverLevel      the level the entity was added to
         * @param isLoadedFromDisk the entity was loaded from storage rather than spawned
         * @param spawnReason      the spawn reason, if captured
         */
        void onEntityLoad(class_1297 entity, class_3218 serverLevel, boolean isLoadedFromDisk, @Nullable class_3730 spawnReason);
    }

    @FunctionalInterface
    public interface Unload {

        /**
         * Fired when an entity is removed from the level on the server.
         *
         * @param entity      the entity that is being unloaded
         * @param serverLevel the level the entity is unloaded in
         */
        void onEntityUnload(class_1297 entity, class_3218 serverLevel);
    }
}
