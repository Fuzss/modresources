package fuzs.puzzleslib.api.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;

@FunctionalInterface
public interface RegistryEntryAddedCallback<T> {

    @SuppressWarnings("unchecked")
    static <T> EventInvoker<RegistryEntryAddedCallback<T>> registryEntryAdded(class_5321<? extends class_2378<T>> resourceKey) {
        Objects.requireNonNull(resourceKey, "resource key is null");
        return EventInvoker.lookup((Class<RegistryEntryAddedCallback<T>>) (Class<?>) RegistryEntryAddedCallback.class, resourceKey);
    }

    /**
     * A callback that runs whenever a new entry is added to a {@link class_2378}.
     * <p>Note that the implementation is only designed for built-in registries and probably will not work with dynamic registries.
     *
     * @param registry  the read-only registry
     * @param id        the identifier for the added entry
     * @param entry     the added entry
     * @param registrar access to the registry for adding additional entries
     */
    void onRegistryEntryAdded(class_2378<T> registry, class_2960 id, T entry, BiConsumer<class_2960, Supplier<T>> registrar);
}
