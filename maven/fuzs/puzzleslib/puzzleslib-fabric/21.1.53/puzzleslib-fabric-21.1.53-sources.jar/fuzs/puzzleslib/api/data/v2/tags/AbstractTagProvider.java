package fuzs.puzzleslib.api.data.v2.tags;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.api.config.v3.serialization.KeyedValueProvider;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.api.init.v3.family.BlockSetVariant;
import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.api.init.v3.registry.RegistryHelper;
import fuzs.puzzleslib.api.init.v3.tags.TagFactory;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import fuzs.puzzleslib.impl.data.SortingTagBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2474;
import net.minecraft.class_2960;
import net.minecraft.class_3481;
import net.minecraft.class_3489;
import net.minecraft.class_3495;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7784;

public abstract class AbstractTagProvider<T> extends class_2474<T> {
    private static final class_3495 STATIC_TAG_BUILDER = class_3495.method_26778();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_2248>> VARIANT_BLOCK_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_2248>>builder()
            .put(BlockSetVariant.BUTTON, class_3481.field_15493)
            .put(BlockSetVariant.DOOR, class_3481.field_15495)
            .put(BlockSetVariant.FENCE, class_3481.field_16584)
            .put(BlockSetVariant.FENCE_GATE, class_3481.field_25147)
            .put(BlockSetVariant.SIGN, class_3481.field_15472)
            .put(BlockSetVariant.SLAB, class_3481.field_15469)
            .put(BlockSetVariant.STAIRS, class_3481.field_15459)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3481.field_24076)
            .put(BlockSetVariant.TRAPDOOR, class_3481.field_15487)
            .put(BlockSetVariant.WALL, class_3481.field_15504)
            .put(BlockSetVariant.WALL_SIGN, class_3481.field_15492)
            .put(BlockSetVariant.HANGING_SIGN, class_3481.field_40103)
            .put(BlockSetVariant.WALL_HANGING_SIGN, class_3481.field_40104)
            .build();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_2248>> VARIANT_STONE_BLOCK_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_2248>>builder()
            .putAll(VARIANT_BLOCK_TAGS)
            .put(BlockSetVariant.BUTTON, class_3481.field_44590)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3481.field_24077)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_2248>> VARIANT_WOODEN_BLOCK_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_2248>>builder()
            .putAll(VARIANT_BLOCK_TAGS)
            .put(BlockSetVariant.BUTTON, class_3481.field_15499)
            .put(BlockSetVariant.DOOR, class_3481.field_15494)
            .put(BlockSetVariant.FENCE, class_3481.field_17619)
            .put(BlockSetVariant.SLAB, class_3481.field_15468)
            .put(BlockSetVariant.STAIRS, class_3481.field_15502)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3481.field_15477)
            .put(BlockSetVariant.TRAPDOOR, class_3481.field_15491)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1792>> VARIANT_ITEM_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1792>>builder()
            .put(BlockSetVariant.BUTTON, class_3489.field_15551)
            .put(BlockSetVariant.DOOR, class_3489.field_15553)
            .put(BlockSetVariant.FENCE, class_3489.field_16585)
            .put(BlockSetVariant.FENCE_GATE, class_3489.field_40858)
            .put(BlockSetVariant.SLAB, class_3489.field_15535)
            .put(BlockSetVariant.STAIRS, class_3489.field_15526)
            .put(BlockSetVariant.TRAPDOOR, class_3489.field_15548)
            .put(BlockSetVariant.WALL, class_3489.field_15560)
            .put(BlockSetVariant.SIGN, class_3489.field_15533)
            .put(BlockSetVariant.HANGING_SIGN, class_3489.field_40108)
            .put(BlockSetVariant.BOAT, class_3489.field_15536)
            .put(BlockSetVariant.CHEST_BOAT, class_3489.field_38080)
            .build();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1792>> VARIANT_STONE_ITEM_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1792>>builder()
            .putAll(VARIANT_ITEM_TAGS)
            .put(BlockSetVariant.BUTTON, class_3489.field_44592)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1792>> VARIANT_WOODEN_ITEM_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1792>>builder()
            .putAll(VARIANT_ITEM_TAGS)
            .put(BlockSetVariant.BUTTON, class_3489.field_15555)
            .put(BlockSetVariant.DOOR, class_3489.field_15552)
            .put(BlockSetVariant.FENCE, class_3489.field_17620)
            .put(BlockSetVariant.SLAB, class_3489.field_15534)
            .put(BlockSetVariant.STAIRS, class_3489.field_15557)
            .put(BlockSetVariant.PRESSURE_PLATE, class_3489.field_15540)
            .put(BlockSetVariant.TRAPDOOR, class_3489.field_15550)
            .buildKeepingLast();
    /**
     * @see #generateFor(Map, Map)
     */
    public static final Map<BlockSetVariant, class_6862<class_1299<?>>> VARIANT_ENTITY_TYPE_TAGS = ImmutableMap.<BlockSetVariant, class_6862<class_1299<?>>>builder()
            .put(BlockSetVariant.BOAT, TagFactory.COMMON.registerEntityTypeTag("boats"))
            .put(BlockSetVariant.CHEST_BOAT, TagFactory.COMMON.registerEntityTypeTag("boats"))
            .build();

    protected final String modId;
    @Nullable
    private final class_2378<T> registry;
    @Nullable
    private final Function<T, class_5321<T>> keyExtractor;

    public AbstractTagProvider(class_5321<? extends class_2378<T>> registryKey, DataProviderContext context) {
        this(registryKey, context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractTagProvider(class_5321<? extends class_2378<T>> registryKey, String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
        super(packOutput, registryKey, registries, CompletableFuture.completedFuture((class_6862<T> tagKey) -> {
            return Objects.equals(tagKey.comp_327().method_12836(), modId) ? Optional.empty() :
                    Optional.of(STATIC_TAG_BUILDER);
        }));
        this.modId = modId;
        this.registry = LookupHelper.getRegistry(registryKey).orElse(null);
        this.keyExtractor =
                this.registry != null ? (T t) -> RegistryHelper.getResourceKeyOrThrow(this.registry, t) : null;
    }

    @Override
    public abstract void method_10514(class_7225.class_7874 registries);

    @Override
    protected class_3495 method_27169(class_6862<T> tag) {
        return this.field_11481.computeIfAbsent(tag.comp_327(), (class_2960 id) -> new SortingTagBuilder());
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(String id) {
        return this.tag(class_2960.method_60654(id));
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(String id, boolean replace) {
        return this.tag(class_2960.method_60654(id), replace);
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(class_2960 id) {
        return this.method_10512(class_6862.method_40092(this.field_40957, id));
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(class_2960 id, boolean replace) {
        return this.tag(class_6862.method_40092(this.field_40957, id), replace);
    }

    @Override
    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> method_10512(class_6862<T> tag) {
        class_3495 builder = this.method_27169(tag);
        return KeyedValueProvider.tags(builder, this.field_40957);
    }

    public fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tag(class_6862<T> tag, boolean replace) {
        class_3495 builder = this.method_27169(tag);
        ProxyImpl.get().setTagBuilderReplace(builder, replace);
        return KeyedValueProvider.tags(builder, this.field_40957);
    }

    public final void generateFor(Map<BlockSetVariant, class_6880.class_6883<T>> variants, Map<BlockSetVariant, class_6862<T>> variantTags) {
        variants.forEach((BlockSetVariant variant, class_6880.class_6883<T> holder) -> {
            class_6862<T> tagKey = variantTags.get(variant);
            if (tagKey != null) {
                this.method_10512(tagKey).add(holder);
            }
        });
    }

    @Deprecated
    public AbstractTagAppender<T> add(String string) {
        return this.add(class_2960.method_60654(string));
    }

    @Deprecated
    public AbstractTagAppender<T> add(class_2960 resourceLocation) {
        return this.add(class_6862.method_40092(this.field_40957, resourceLocation));
    }

    @Deprecated
    public AbstractTagAppender<T> add(class_6862<T> tagKey) {
        return ProxyImpl.get().getTagAppenderV2(this.method_27169(tagKey), this.keyExtractor);
    }

    @Deprecated
    protected class_2378<T> registry() {
        Objects.requireNonNull(this.registry, "registry is null");
        return this.registry;
    }

    @Deprecated
    protected Function<T, class_5321<T>> keyExtractor() {
        Objects.requireNonNull(this.keyExtractor, "key extractor is null");
        return this.keyExtractor;
    }
}
