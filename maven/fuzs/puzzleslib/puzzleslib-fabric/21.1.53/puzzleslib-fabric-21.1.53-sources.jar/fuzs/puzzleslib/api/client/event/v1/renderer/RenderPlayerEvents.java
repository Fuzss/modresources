package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;

public final class RenderPlayerEvents {
    public static final EventInvoker<Before> BEFORE = EventInvoker.lookup(Before.class);
    public static final EventInvoker<After> AFTER = EventInvoker.lookup(After.class);

    private RenderPlayerEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Before {

        /**
         * Called before the player model is rendered, allows for applying transformations to the {@link class_4587}, or
         * for completely taking over rendering as a whole.
         *
         * @param player            the player that is rendering, either {@link net.minecraft.class_746}
         *                          or {@link net.minecraft.class_745}
         * @param renderer          the used {@link class_1007} instance
         * @param partialTick       current partial tick time
         * @param poseStack         the current {@link class_4587}
         * @param multiBufferSource the current {@link class_4597}
         * @param packedLight       packet light the entity is rendered with
         * @return {@link EventResult#INTERRUPT} to prevent the player model from rendering, this allows for taking over
         *         complete player rendering,
         *         <p>
         *         {@link EventResult#PASS} to allow the player model to render
         */
        EventResult onBeforeRenderPlayer(class_742 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight);
    }

    @FunctionalInterface
    public interface After {

        /**
         * Called after the player model is rendered, allows for cleaning up transformations applied to the
         * {@link class_4587}.
         *
         * @param player            the player that is rendering, either {@link net.minecraft.class_746}
         *                          or {@link net.minecraft.class_745}
         * @param renderer          the used {@link class_1007} instance
         * @param partialTick       current partial tick time
         * @param poseStack         the current {@link class_4587}
         * @param multiBufferSource the current {@link class_4597}
         * @param packedLight       packet light the entity is rendered with
         */
        void onAfterRenderPlayer(class_742 player, class_1007 renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight);
    }
}
