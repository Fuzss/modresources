package fuzs.puzzleslib.api.event.v1.server;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableValue;
import java.util.function.Consumer;
import java.util.function.IntPredicate;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_55;

@Deprecated
public final class LootTableLoadEvents {
    public static final EventInvoker<Replace> REPLACE = EventInvoker.lookup(Replace.class);
    public static final EventInvoker<Modify> MODIFY = EventInvoker.lookup(Modify.class);

    private LootTableLoadEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Replace {

        /**
         * Allows for replacing {@link class_52 LootTables} on loading.
         * <p>To remove a loot table completely pass in {@link class_52#field_948}.
         *
         * @param resourceLocation the loot table id
         * @param lootTable        the loot table that can be replaced
         */
        void onReplaceLootTable(class_2960 resourceLocation, MutableValue<class_52> lootTable);
    }

    @FunctionalInterface
    public interface Modify {

        /**
         * Allows changing of {@link class_55 LootPools} in a {@link class_52}.
         *
         * @param resourceLocation the loot table id
         * @param addLootPool      add a {@link class_55}
         * @param removeLootPool   removes a pool at a given index, pools are indexed starting from 0, succeeds if the
         *                         pool was removed at the given index, also note that indices are consistent and will
         *                         not update when other indices are removed
         */
        void onModifyLootTable(class_2960 resourceLocation, Consumer<class_55> addLootPool, IntPredicate removeLootPool);
    }
}
