package fuzs.puzzleslib.api.chat.v1;

import net.minecraft.class_2561;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/**
 * A helper class for converting various text representations.
 * <p>
 * Useful for text instances returned from {@link net.minecraft.class_5225} and
 * {@link class_2561#method_30937()}.
 */
@Deprecated
public class ComponentHelper {

    /**
     * Converts an instance of {@link class_5348} to a {@link class_2561}.
     *
     * @param formattedText the text to convert
     * @return the new component
     */
    public static class_2561 toComponent(class_5348 formattedText) {
        return fuzs.puzzleslib.api.util.v1.ComponentHelper.getAsComponent(formattedText);
    }

    /**
     * Converts an instance of {@link class_5481} to a {@link class_2561}.
     *
     * @param formattedCharSequence the text to convert
     * @return the new component
     */
    public static class_2561 toComponent(class_5481 formattedCharSequence) {
        return fuzs.puzzleslib.api.util.v1.ComponentHelper.getAsComponent(formattedCharSequence);
    }

    /**
     * Converts an instance of {@link class_5348} to a string which includes formatting codes supplied via configured
     * {@link net.minecraft.class_2583 Styles}.
     * <p>
     * This is mostly useful when working with instances where vanilla still renders raw strings, which inherently
     * support the old chat formatting system, such as in
     * {@link net.minecraft.class_340}.
     *
     * @param formattedText the text to convert
     * @return the string
     */
    public static String toString(class_5348 formattedText) {
        return fuzs.puzzleslib.api.util.v1.ComponentHelper.getAsString(formattedText);
    }

    /**
     * Converts an instance of {@link class_5481} to a string which includes formatting codes supplied via
     * configured {@link net.minecraft.class_2583 Styles}.
     * <p>
     * This is mostly useful when working with instances where vanilla still renders raw strings, which inherently
     * support the old chat formatting system, such as in
     * {@link net.minecraft.class_340}.
     *
     * @param formattedCharSequence the text to convert
     * @return the string
     */
    public static String toString(class_5481 formattedCharSequence) {
        return fuzs.puzzleslib.api.util.v1.ComponentHelper.getAsString(formattedCharSequence);
    }
}
