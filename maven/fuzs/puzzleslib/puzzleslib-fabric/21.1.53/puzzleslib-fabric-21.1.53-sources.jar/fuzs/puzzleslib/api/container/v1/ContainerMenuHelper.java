package fuzs.puzzleslib.api.container.v1;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import net.minecraft.class_1263;
import net.minecraft.class_1265;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3908;
import net.minecraft.class_8883;

/**
 * Small helper class related to working with implementations of {@link class_1703}.
 */
public final class ContainerMenuHelper {

    private ContainerMenuHelper() {
        // NO-OP
    }

    /**
     * Opens a menu on both client and server while also providing additional data.
     *
     * @param player       the player opening the menu
     * @param menuProvider the menu factory
     * @param data         the additional data to be sent to the client
     */
    public static <T> void openMenu(class_1657 player, class_3908 menuProvider, T data) {
        Objects.requireNonNull(player, "player is null");
        Objects.requireNonNull(menuProvider, "menu provider is null");
        Objects.requireNonNull(data, "data is null");
        ProxyImpl.get().openMenu(player, menuProvider, data);
    }

    /**
     * Replace the container slot representing the currently selected hotbar slot with a non-interactive variant.
     * <p>
     * Useful for handheld container items such as bags while their menu is open.
     *
     * @param containerMenu the container menu
     */
    public static void setSelectedSlotLocked(class_1703 containerMenu) {
        for (int i = 0; i < containerMenu.field_7761.size(); i++) {
            class_1735 slot = containerMenu.field_7761.get(i);
            if (slot.field_7871 instanceof class_1661 inventory && inventory.field_7545 == slot.method_34266()) {
                class_8883 newSlot = new class_8883(slot.field_7871,
                        slot.method_34266(),
                        slot.field_7873,
                        slot.field_7872) {
                    @Override
                    public boolean method_55059() {
                        return false;
                    }
                };
                newSlot.field_7874 = slot.field_7874;
                containerMenu.field_7761.set(i, newSlot);
                break;
            }
        }
    }

    /**
     * Adds the player inventory slots to an {@link class_1703}.
     *
     * @param abstractContainerMenu menu to add slots to
     * @param inventory             player inventory instance
     * @param offsetY               vertical offset
     */
    @Deprecated
    public static void addInventorySlots(class_1703 abstractContainerMenu, class_1661 inventory, int offsetY) {
        addInventorySlots(abstractContainerMenu, inventory, 8, offsetY);
    }

    /**
     * Adds the player inventory slots to an {@link class_1703}.
     *
     * @param abstractContainerMenu menu to add slots to
     * @param inventory             player inventory instance
     * @param offsetX               horizontal offset
     * @param offsetY               vertical offset
     */
    @Deprecated
    public static void addInventorySlots(class_1703 abstractContainerMenu, class_1661 inventory, int offsetX, int offsetY) {
        addStandardInventorySlots(abstractContainerMenu, inventory, offsetX, offsetY);
    }

    public static void addInventoryHotbarSlots(class_1703 abstractContainerMenu, class_1263 container, int offsetX, int offsetY) {
        for (int i = 0; i < 9; i++) {
            abstractContainerMenu.method_7621(new class_1735(container, i, offsetX + i * 18, offsetY));
        }
    }

    public static void addInventoryExtendedSlots(class_1703 abstractContainerMenu, class_1263 container, int offsetX, int offsetY) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                abstractContainerMenu.method_7621(new class_1735(container, j + (i + 1) * 9, offsetX + j * 18, offsetY + i * 18));
            }
        }
    }

    public static void addStandardInventorySlots(class_1703 abstractContainerMenu, class_1263 container, int offsetX, int offsetY) {
        addInventoryExtendedSlots(abstractContainerMenu, container, offsetX, offsetY);
        addInventoryHotbarSlots(abstractContainerMenu, container, offsetX, offsetY + 58);
    }

    /**
     * Allows for creating a container backed by a list of items.
     * <p>
     * Useful for items that are stored on e.g. a block entity, but not accessible via a container, but should be
     * accessible via a menu implementation.
     * <p>
     * An example would be a slot for setting a filter item that is kept separate from the main container inventory.
     *
     * @param items    list of items
     * @param listener listener for changes to the item list
     * @return the created container
     */
    public static class_1277 createListBackedContainer(class_2371<class_1799> items, @Nullable class_1263 listener) {
        return createListBackedContainer(items, listener != null ? $ -> listener.method_5431() : null);
    }

    /**
     * Allows for creating a container backed by a list of items.
     * <p>
     * Useful for items that are stored on e.g. a block entity, but not accessible via a container, but should be
     * accessible via a menu implementation.
     * <p>
     * An example would be a slot for setting a filter item that is kept separate from the main container inventory.
     *
     * @param items    list of items
     * @param listener listener for changes to the item list
     * @return the created container
     */
    public static class_1277 createListBackedContainer(class_2371<class_1799> items, @Nullable class_1265 listener) {
        class_1277 simpleContainer = new class_1277();
        simpleContainer.field_5831 = items.size();
        simpleContainer.field_5828 = items;
        if (listener != null) {
            simpleContainer.method_5489(listener);
        }

        return simpleContainer;
    }

    /**
     * Writes contents from a list of items to a container.
     * <p>
     * Intended to be used with
     * {@link net.minecraft.class_2624#method_11281(class_2371)} to be able to keep
     * the internal items list final.
     *
     * @param from the source item list
     * @param to   the target container
     */
    public static void copyItemsIntoContainer(class_2371<class_1799> from, class_1263 to) {
        for (int i = 0; i < from.size(); i++) {
            if (i < to.method_5439()) {
                to.method_5447(i, from.get(i));
            }
        }
    }

    /**
     * Writes contents from a list of items to another list of items.
     * <p>
     * Intended to be used with
     * {@link net.minecraft.class_2624#method_11281(class_2371)} to be able to keep
     * the internal items list final.
     *
     * @param from the source item list
     * @param to   the target item list
     */
    public static void copyItemsIntoList(class_2371<class_1799> from, class_2371<class_1799> to) {
        for (int i = 0; i < from.size(); i++) {
            if (i < to.size()) {
                to.set(i, from.get(i));
            }
        }
    }
}
