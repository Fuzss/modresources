package fuzs.puzzleslib.api.event.v1.server;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_2960;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_7225;

@FunctionalInterface
public interface LootTableLoadCallback {
    EventInvoker<LootTableLoadCallback> EVENT = EventInvoker.lookup(LootTableLoadCallback.class);

    /**
     * Runs for every loot table upon loading, allows for modifying the loot table.
     *
     * @param resourceLocation the loot table id
     * @param lootTable        the loot table builder instance
     * @param registries       the registry access
     */
    void onLootTableLoad(class_2960 resourceLocation, class_52.class_53 lootTable, class_7225.class_7874 registries);

    /**
     * Allows for modifying each existing loot pool in a loot table.
     * <p>
     * Can only be used inside {@link LootTableLoadCallback}.
     *
     * @param lootTable        the loot table builder instance
     * @param lootPoolConsumer the consumer to apply to each loot pool inside
     */
    static void forEachPool(class_52.class_53 lootTable, Consumer<? super class_55.class_56> lootPoolConsumer) {
        Objects.requireNonNull(lootTable, "loot table is null");
        Objects.requireNonNull(lootPoolConsumer, "loot pool consumer is null");
        ProxyImpl.get().forEachPool(lootTable, lootPoolConsumer);
    }
}
