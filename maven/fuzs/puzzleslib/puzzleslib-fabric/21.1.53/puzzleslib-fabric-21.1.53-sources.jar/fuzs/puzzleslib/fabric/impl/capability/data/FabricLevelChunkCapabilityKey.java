package fuzs.puzzleslib.fabric.impl.capability.data;

import fuzs.puzzleslib.api.capability.v3.data.CapabilityComponent;
import fuzs.puzzleslib.api.capability.v3.data.LevelChunkCapabilityKey;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_2818;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FabricLevelChunkCapabilityKey<C extends CapabilityComponent<class_2818>> extends FabricCapabilityKey<class_2818, C> implements LevelChunkCapabilityKey<C> {

    public FabricLevelChunkCapabilityKey(AttachmentType<C> attachmentType, Predicate<Object> filter, Supplier<C> factory) {
        super(attachmentType, filter, factory);
    }
}
