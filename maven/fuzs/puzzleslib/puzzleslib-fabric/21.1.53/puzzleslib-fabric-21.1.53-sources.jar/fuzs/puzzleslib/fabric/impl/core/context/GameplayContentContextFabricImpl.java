package fuzs.puzzleslib.fabric.impl.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.context.GameplayContentContext;
import net.fabricmc.fabric.api.registry.*;
import net.minecraft.class_1794;
import net.minecraft.class_1935;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_6880;
import org.apache.commons.lang3.math.Fraction;

import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public final class GameplayContentContextFabricImpl implements GameplayContentContext {
    /**
     * @see net.minecraft.class_1743#STRIPPABLES
     */
    private static final Map<class_2248, class_2248> STRIPPABLES_WITHOUT_AXIS = new IdentityHashMap<>();

    /**
     * @see net.minecraft.class_1743#method_34716(class_2680)
     */
    public static Optional<class_2680> getStripped(class_2680 state) {
        return Optional.ofNullable(STRIPPABLES_WITHOUT_AXIS.get(state.method_26204()))
                .map((class_2248 block) -> block.method_34725(state));
    }

    @Override
    public void registerFuel(class_6880<? extends class_1935> fuelItem, Fraction fuelValue) {
        Objects.requireNonNull(fuelItem, "fuel item is null");
        Objects.requireNonNull(fuelValue, "fuel value is null");
        Fraction fuelBaseValue = Fraction.getFraction(200, 1);
        FuelRegistry.INSTANCE.add(fuelItem.comp_349(), fuelValue.multiplyBy(fuelBaseValue).intValue());
    }

    @Override
    public void registerFlammable(class_6880<class_2248> flammableBlock, int encouragement, int flammability) {
        Preconditions.checkArgument(encouragement > 0, "encouragement is non-positive");
        Preconditions.checkArgument(flammability > 0, "flammability is non-positive");
        Objects.requireNonNull(flammableBlock, "flammable block is null");
        // flammability == burn, encouragement == spread
        FlammableBlockRegistry.getDefaultInstance().add(flammableBlock.comp_349(), flammability, encouragement);
    }

    @Override
    public void registerCompostable(class_6880<? extends class_1935> compostableItem, float compostingChance) {
        Preconditions.checkArgument(compostingChance >= 0.0F && compostingChance <= 1.0F,
                "Value " + compostingChance + " outside of range 0.0 -> 1.0");
        Objects.requireNonNull(compostableItem, "compostable item is null");
        CompostingChanceRegistry.INSTANCE.add(compostableItem.comp_349(), compostingChance);
    }

    @Override
    public void registerStrippable(class_6880<class_2248> unstrippedBlock, class_6880<class_2248> strippedBlock) {
        Objects.requireNonNull(unstrippedBlock, "unstripped block is null");
        Objects.requireNonNull(strippedBlock, "stripped block is null");
        // Fabric does not support registering strippable blocks without an axis property in 1.21.1.
        if (this.hasAxisProperty(unstrippedBlock.comp_349()) && this.hasAxisProperty(strippedBlock.comp_349())) {
            StrippableBlockRegistry.register(unstrippedBlock.comp_349(), strippedBlock.comp_349());
        } else {
            // We add these to our own map, as values from the vanilla map are used to copy the axis property directly.
            STRIPPABLES_WITHOUT_AXIS.put(unstrippedBlock.comp_349(), strippedBlock.comp_349());
        }
    }

    private boolean hasAxisProperty(class_2248 block) {
        return block.method_9595().method_11659().contains(class_2741.field_12496);
    }

    @Override
    public void registerFlattenable(class_6880<class_2248> unflattenedBlock, class_6880<class_2248> flattenedBlock) {
        Objects.requireNonNull(unflattenedBlock, "unflattened block is null");
        Objects.requireNonNull(flattenedBlock, "flattened block is null");
        FlattenableBlockRegistry.register(unflattenedBlock.comp_349(), flattenedBlock.comp_349().method_9564());
    }

    @Override
    public void registerTillable(class_6880<class_2248> untilledBlock, class_6880<class_2248> tilledBlock) {
        Objects.requireNonNull(untilledBlock, "untilled block is null");
        Objects.requireNonNull(tilledBlock, "tilled block is null");
        TillableBlockRegistry.register(untilledBlock.comp_349(),
                class_1794::method_36987,
                tilledBlock.comp_349().method_9564());
    }

    @Override
    public void registerOxidizable(class_6880<class_2248> unoxidizedBlock, class_6880<class_2248> oxidizedBlock) {
        Objects.requireNonNull(unoxidizedBlock, "unoxidized block is null");
        Objects.requireNonNull(oxidizedBlock, "oxidized block is null");
        OxidizableBlocksRegistry.registerOxidizableBlockPair(unoxidizedBlock.comp_349(), oxidizedBlock.comp_349());
    }

    @Override
    public void registerWaxable(class_6880<class_2248> unwaxedBlock, class_6880<class_2248> waxedBlock) {
        Objects.requireNonNull(unwaxedBlock, "unwaxed block is null");
        Objects.requireNonNull(waxedBlock, "waxed block is null");
        OxidizableBlocksRegistry.registerWaxableBlockPair(unwaxedBlock.comp_349(), waxedBlock.comp_349());
    }
}
