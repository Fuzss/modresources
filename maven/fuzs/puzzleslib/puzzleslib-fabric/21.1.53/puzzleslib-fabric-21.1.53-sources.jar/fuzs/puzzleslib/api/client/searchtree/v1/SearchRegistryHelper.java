package fuzs.puzzleslib.api.client.searchtree.v1;

import fuzs.puzzleslib.api.core.v1.Proxy;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_1124;
import net.minecraft.class_1129;
import net.minecraft.class_156;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_5455;

/**
 * A helper for dealing with {@link class_1129}.
 */
public final class SearchRegistryHelper {
    private static final Map<SearchTreeType<?>, Entry<?>> SEARCH_TREES = new IdentityHashMap<>();

    private SearchRegistryHelper() {
        // NO-OP
    }

    /**
     * Register a search tree factory for a type.
     *
     * @param type    search tree type token
     * @param factory tree factory for recreating when populating values
     * @param <T>     search item type
     */
    public static <T> void register(SearchTreeType<T> type, Function<List<T>, class_1129<T>> factory) {
        SEARCH_TREES.put(type, new Entry<>(factory));
    }

    /**
     * Collects all tooltip lines from an item stack.
     *
     * @param itemStack the item stack
     * @return all tooltip lines from the item stack
     */
    public static Stream<String> getTooltipLines(class_1799 itemStack) {
        return getTooltipLines(Stream.of(itemStack), class_1836.field_41070);
    }

    /**
     * Collects all tooltip lines from item stacks.
     *
     * @param stream      the item stacks
     * @param tooltipFlag the tooltip flag
     * @return all tooltip lines from the item stacks
     */
    public static Stream<String> getTooltipLines(Stream<class_1799> stream, class_1836 tooltipFlag) {
        class_5455.class_6890 registries = Proxy.INSTANCE.getClientPacketListener().method_29091();
        return class_1124.method_60356(stream, class_1792.class_9635.method_59530(registries), tooltipFlag);
    }

    /**
     * Populates a search tree with new values.
     *
     * @param type   search tree type token
     * @param values value for populating the tree
     * @param <T>    search item type
     */
    public static <T> void populateSearchTree(SearchTreeType<T> type, List<T> values) {
        Entry<T> entry = lookupEntry(type);
        Proxy.INSTANCE.getClientPacketListener().method_60347().method_60353(entry.key, () -> {
            CompletableFuture<class_1129<T>> searchTree = entry.searchTree;
            entry.searchTree = CompletableFuture.supplyAsync(() -> {
                return entry.factory.apply(values);
            }, class_156.method_18349());
            searchTree.cancel(true);
        });
    }

    /**
     * Get the current search tree for a type.
     *
     * @param type search tree type token
     * @param <T>  search item type
     * @return the search tree
     */
    public static <T> class_1129<T> getSearchTree(SearchTreeType<T> type) {
        return lookupEntry(type).searchTree.join();
    }

    private static <T> Entry<T> lookupEntry(SearchTreeType<T> type) {
        Entry<?> entry = SEARCH_TREES.get(type);
        Objects.requireNonNull(entry, () -> "Search tree type " + type.resourceLocation() + " is not registered");
        return (Entry<T>) entry;
    }

    private static class Entry<T> {
        public final class_1124.class_1125 key = new class_1124.class_1125();
        public final Function<List<T>, class_1129<T>> factory;
        public CompletableFuture<class_1129<T>> searchTree = CompletableFuture.completedFuture(class_1129.empty());

        Entry(Function<List<T>, class_1129<T>> factory) {
            this.factory = factory;
        }
    }
}
