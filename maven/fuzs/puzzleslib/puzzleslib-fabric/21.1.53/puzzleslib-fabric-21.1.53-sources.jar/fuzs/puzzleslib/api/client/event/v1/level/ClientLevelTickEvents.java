package fuzs.puzzleslib.api.client.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_310;
import net.minecraft.class_638;

public final class ClientLevelTickEvents {
    public static final EventInvoker<Start> START = EventInvoker.lookup(Start.class);
    public static final EventInvoker<End> END = EventInvoker.lookup(End.class);

    private ClientLevelTickEvents() {

    }

    @FunctionalInterface
    public interface Start {

        /**
         * Fires before ticking the server level in {@link class_310#method_1574()}.
         *
         * @param minecraft minecraft singleton instance
         * @param level     the client level that is being ticked
         */
        void onStartLevelTick(class_310 minecraft, class_638 level);
    }

    @FunctionalInterface
    public interface End {

        /**
         * Fires after ticking the server level in {@link class_310#method_1574()}.
         *
         * @param minecraft minecraft singleton instance
         * @param level     the client level that is being ticked
         */
        void onEndLevelTick(class_310 minecraft, class_638 level);
    }
}
