package fuzs.puzzleslib.api.client.gui.v2.components;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_2588;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_7417;
import net.minecraft.class_8021;

/**
 * A small helper class for positioning a new {@link class_339} on a screen next to an already existing widget.
 * <p>
 * The implementation is able to locate the existing widget as indicated by provided translation keys, and then only
 * positions the new widget if it does not overlap with another already existing widget.
 * <p>
 * This class is mainly intended for placing {@link net.minecraft.class_344} instances on
 * {@link net.minecraft.class_442} and {@link net.minecraft.class_433}, as
 * it's rather likely for other mods to interfere, introducing a necessity to check for possible overlap.
 * <p>
 * Also, when using this class during init events it is recommended to run the init events during a phase later than the
 * normal event phase, to possibly run after other mods have added their own widgets, so they can be taken into account
 * when checking for overlap.
 */
public final class ScreenElementPositioner {

    private ScreenElementPositioner() {
        // NO-OP
    }

    /**
     * Attempts to position element next to other widgets, located via the provided translation keys.
     * <p>
     * When successful the element position has already been changed, all that's left to the caller is actually adding
     * the element to the current screen.
     *
     * @param element         the element to position next to another element already present on the screen
     * @param widgets         a view of all widgets on the current screen
     * @param translationKeys the translation keys to use for locating other widgets to place <code>element</code> next
     *                        to, the key is retrieved from {@link class_339#method_25369()}; note that for widgets
     *                        without a displayed {@link net.minecraft.class_2561} (such as
     *                        {@link net.minecraft.class_344}) the narration key usually works,
     *                        too
     * @return was positioning <code>element</code> successful; the element position has already been changed, all
     *         that's left to the caller is actually adding the element to the current screen; otherwise if positioning
     *         has failed <code>element</code> is unchanged
     */
    public static boolean tryPositionElement(class_8021 element, List<? extends class_364> widgets, String... translationKeys) {
        return tryPositionElement(element, widgets, false, translationKeys);
    }

    /**
     * Attempts to position element next to other widgets, located via the provided translation keys.
     * <p>
     * When successful the element position has already been changed, all that's left to the caller is actually adding
     * the element to the current screen.
     *
     * @param element               the element to position next to another element already present on the screen
     * @param widgets               a view of all widgets on the current screen
     * @param tryPositionRightFirst by default <code>element</code> will be tried to be placed on the left side of a
     *                              found other element, only if that does not work placing on the right side is
     *                              attempted; this option inverts that and tries to place to the right side first
     * @param translationKeys       the translation keys to use for locating other widgets to place <code>element</code>
     *                              next to, the key is retrieved from {@link class_339#method_25369()}; note that
     *                              for widgets without a displayed {@link net.minecraft.class_2561} (such
     *                              as {@link net.minecraft.class_344}) the narration key
     *                              usually works, too
     * @return was positioning <code>element</code> successful; the element position has already been changed, all
     *         that's left to the caller is actually adding the element to the current screen; otherwise if positioning
     *         has failed <code>element</code> is unchanged
     */
    public static boolean tryPositionElement(class_8021 element, List<? extends class_364> widgets, boolean tryPositionRightFirst, String... translationKeys) {
        return tryPositionElement(element, widgets, tryPositionRightFirst, 4, translationKeys);
    }

    /**
     * Attempts to position element next to other widgets, located via the provided translation keys.
     * <p>
     * When successful the element position has already been changed, all that's left to the caller is actually adding
     * the element to the current screen.
     *
     * @param element               the element to position next to another element already present on the screen
     * @param widgets               a view of all widgets on the current screen
     * @param tryPositionRightFirst by default <code>element</code> will be tried to be placed on the left side of a
     *                              found other element, only if that does not work placing on the right side is
     *                              attempted; this option inverts that and tries to place to the right side first
     * @param horizontalOffset      the horizontal distance between <code>element</code> and the other element it is
     *                              placed next to
     * @param translationKeys       the translation keys to use for locating other widgets to place <code>element</code>
     *                              next to, the key is retrieved from {@link class_339#method_25369()}; note that
     *                              for widgets without a displayed {@link net.minecraft.class_2561} (such
     *                              as {@link net.minecraft.class_344}) the narration key
     *                              usually works, too
     * @return was positioning <code>element</code> successful; the element position has already been changed, all
     *         that's left to the caller is actually adding the element to the current screen; otherwise if positioning
     *         has failed <code>element</code> is unchanged
     */
    public static boolean tryPositionElement(class_8021 element, List<? extends class_364> widgets, boolean tryPositionRightFirst, int horizontalOffset, String... translationKeys) {
        final int originalX = element.method_46426();
        final int originalY = element.method_46427();
        for (String translationKey : translationKeys) {
            class_8021 otherElement = findElement(widgets, translationKey);
            if (otherElement != null) {
                moveElementToOther(element, otherElement, tryPositionRightFirst, horizontalOffset);
                if (noOverlapWithExisting(widgets, element)) {
                    return true;
                } else {
                    moveElementToOther(element, otherElement, !tryPositionRightFirst, horizontalOffset);
                    if (noOverlapWithExisting(widgets, element)) {
                        return true;
                    }
                }
            }
        }

        // reset if we were not successful in finding a position next to another widget
        element.method_48229(originalX, originalY);
        return false;
    }

    private static void moveElementToOther(class_8021 element, class_8021 otherElement, boolean tryPositionRightFirst, int horizontalOffset) {
        if (tryPositionRightFirst) {
            moveToRight(element, otherElement, horizontalOffset);
        } else {
            moveToLeft(element, otherElement, horizontalOffset);
        }
    }

    private static void moveToLeft(class_8021 element, class_8021 otherElement, int horizontalOffset) {
        element.method_48229(otherElement.method_46426() - element.method_25368() - horizontalOffset, otherElement.method_46427());
    }

    private static void moveToRight(class_8021 element, class_8021 otherElement, int horizontalOffset) {
        element.method_48229(otherElement.method_46426() + otherElement.method_25368() + horizontalOffset, otherElement.method_46427());
    }

    private static boolean noOverlapWithExisting(List<? extends class_364> widgets, class_8021 element) {
        for (class_364 widget : widgets) {
            if (widget instanceof class_8021 otherElement) {
                if (element.method_48202().method_49701(otherElement.method_48202()) != null) {
                    return false;
                }
            }
        }

        return true;
    }

    @Nullable
    private static class_8021 findElement(List<? extends class_364> widgets, String translationKey) {
        for (class_364 listener : widgets) {
            if (listener instanceof class_339 widget) {
                if (matchesTranslationKey(widget, translationKey)) {
                    return widget;
                }
            }
        }
        return null;
    }

    private static boolean matchesTranslationKey(class_339 widget, String translationKey) {
        final class_7417 message = widget.method_25369().method_10851();
        return message instanceof class_2588 contents && contents.method_11022().equals(translationKey);
    }
}
