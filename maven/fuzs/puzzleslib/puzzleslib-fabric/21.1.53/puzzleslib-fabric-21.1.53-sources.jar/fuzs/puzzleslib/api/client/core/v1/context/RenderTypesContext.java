package fuzs.puzzleslib.api.client.core.v1.context;

import fuzs.puzzleslib.api.client.renderer.v1.chunk.ChunkSectionLayer;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_3611;

/**
 * Register custom {@link class_1921}s for blocks and fluids.
 *
 * @param <T> object type supported by provider, either {@link class_2248} or {@link class_3611}
 */
public interface RenderTypesContext<T> {

    /**
     * Register a {@link class_1921}.
     *
     * @param object     the object
     * @param renderType the render type
     */
    void registerRenderType(T object, class_1921 renderType);

    /**
     * Register a {@link ChunkSectionLayer}.
     *
     * @param object            the object
     * @param chunkSectionLayer the chunk section layer
     */
    default void registerChunkRenderType(T object, ChunkSectionLayer chunkSectionLayer) {
        this.registerRenderType(object, chunkSectionLayer.renderType);
    }

    @Deprecated
    @SuppressWarnings("unchecked")
    default void registerRenderType(class_1921 renderType, T... objects) {
        Objects.requireNonNull(objects, "objects is null");
        for (T object : objects) {
            this.registerRenderType(object, renderType);
        }
    }

    /**
     * Allows for retrieving the {@link class_1921} that has been registered for an object type.
     * <p>When not render type is registered {@link class_1921#method_23577()} is returned.
     *
     * @param object the object type to get the render type for
     * @return the render type
     */
    class_1921 getRenderType(T object);
}
