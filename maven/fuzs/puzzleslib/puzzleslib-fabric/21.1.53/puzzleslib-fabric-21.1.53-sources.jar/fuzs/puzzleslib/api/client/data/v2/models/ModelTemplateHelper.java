package fuzs.puzzleslib.api.client.data.v2.models;

import com.google.gson.JsonElement;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;

public final class ModelTemplateHelper {

    private ModelTemplateHelper() {
        // NO-OP
    }

    public static class_4942 createBlockModelTemplate(class_2960 resourceLocation, class_4945... requiredSlots) {
        return createBlockModelTemplate(resourceLocation, "", requiredSlots);
    }

    public static class_4942 createBlockModelTemplate(class_2960 resourceLocation, String suffix, class_4945... requiredSlots) {
        return new class_4942(Optional.of(ModelLocationHelper.getBlockModel(resourceLocation)),
                Optional.of(suffix),
                requiredSlots);
    }

    public static class_4942 createItemModelTemplate(class_2960 resourceLocation, class_4945... requiredSlots) {
        return createItemModelTemplate(resourceLocation, "", requiredSlots);
    }

    public static class_4942 createItemModelTemplate(class_2960 resourceLocation, String suffix, class_4945... requiredSlots) {
        return new class_4942(Optional.of(ModelLocationHelper.getItemModel(resourceLocation)),
                Optional.of(suffix),
                requiredSlots);
    }

    public static class_2960 generateFlatItem(class_1792 item, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(ModelLocationHelper.getItemLocation(item), modelOutput);
    }

    public static class_2960 generateFlatItem(class_1792 item, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(ModelLocationHelper.getItemLocation(item), modelTemplate, modelOutput);
    }

    public static class_2960 generateFlatItem(class_1792 item, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return generateFlatItem(ModelLocationHelper.getItemLocation(item), modelTemplate, modelOutput, factory);
    }

    public static class_2960 generateFlatItem(class_1792 item, class_1792 layerItem, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(ModelLocationHelper.getItemLocation(item),
                ModelLocationHelper.getItemLocation(layerItem),
                modelOutput);
    }

    public static class_2960 generateFlatItem(class_1792 item, class_1792 layerItem, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(ModelLocationHelper.getItemLocation(item),
                ModelLocationHelper.getItemLocation(layerItem),
                modelTemplate,
                modelOutput);
    }

    public static class_2960 generateFlatItem(class_1792 item, class_1792 layerItem, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return generateFlatItem(ModelLocationHelper.getItemLocation(item),
                ModelLocationHelper.getItemLocation(layerItem),
                modelTemplate,
                modelOutput,
                factory);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(resourceLocation, resourceLocation, modelOutput);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(resourceLocation, resourceLocation, modelTemplate, modelOutput);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return generateFlatItem(resourceLocation, resourceLocation, modelTemplate, modelOutput, factory);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, class_2960 layer0, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(resourceLocation, layer0, class_4943.field_22938, modelOutput);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, class_2960 layer0, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateFlatItem(resourceLocation,
                layer0,
                modelTemplate,
                modelOutput,
                modelTemplate::method_48524);
    }

    public static class_2960 generateFlatItem(class_2960 resourceLocation, class_2960 layer0, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return modelTemplate.method_48525(ModelLocationHelper.getItemModel(resourceLocation),
                class_4944.method_25895(ModelLocationHelper.getItemTexture(layer0)),
                modelOutput,
                factory);
    }

    public static class_2960 generateLayeredItem(class_1792 item, class_2960 layer0, class_2960 layer1, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateLayeredItem(ModelLocationHelper.getItemLocation(item), layer0, layer1, modelOutput);
    }

    public static class_2960 generateLayeredItem(class_1792 item, class_2960 layer0, class_2960 layer1, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateLayeredItem(ModelLocationHelper.getItemLocation(item),
                layer0,
                layer1,
                modelTemplate,
                modelOutput);
    }

    public static class_2960 generateLayeredItem(class_1792 item, class_2960 layer0, class_2960 layer1, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return generateLayeredItem(ModelLocationHelper.getItemLocation(item),
                layer0,
                layer1,
                modelTemplate,
                modelOutput,
                factory);
    }

    public static class_2960 generateLayeredItem(class_2960 resourceLocation, class_2960 layer0, class_2960 layer1, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateLayeredItem(resourceLocation, layer0, layer1, class_4943.field_42232, modelOutput);
    }

    public static class_2960 generateLayeredItem(class_2960 resourceLocation, class_2960 layer0, class_2960 layer1, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput) {
        return generateLayeredItem(resourceLocation,
                layer0,
                layer1,
                modelTemplate,
                modelOutput,
                modelTemplate::method_48524);
    }

    public static class_2960 generateLayeredItem(class_2960 resourceLocation, class_2960 layer0, class_2960 layer1, class_4942 modelTemplate, BiConsumer<class_2960, Supplier<JsonElement>> modelOutput, class_4942.class_8073 factory) {
        return modelTemplate.method_48525(ModelLocationHelper.getItemModel(resourceLocation),
                class_4944.method_48529(ModelLocationHelper.getItemTexture(layer0),
                        ModelLocationHelper.getItemTexture(layer1)),
                modelOutput,
                factory);
    }
}
