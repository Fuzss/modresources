package fuzs.puzzleslib.api.client.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.DefaultedFloat;
import net.minecraft.class_1657;
import net.minecraft.class_5134;

public interface ComputeFovModifierCallback {
    EventInvoker<ComputeFovModifierCallback> EVENT = EventInvoker.lookup(ComputeFovModifierCallback.class);

    /**
     * Called when computing the field of view modifier on the client, mostly depending on
     * {@link class_5134#field_23719}, but also changes for certain actions such as when drawing a bow.
     * <p>
     * The modifier value is the actual raw value, effects from the <code>fovEffectScale</code> option are applied
     * afterward by the callback implementation.
     *
     * @param player              the client player this is calculated for
     * @param fieldOfViewModifier modifier as calculated by vanilla, can be modified
     */
    void onComputeFovModifier(class_1657 player, DefaultedFloat fieldOfViewModifier);
}
