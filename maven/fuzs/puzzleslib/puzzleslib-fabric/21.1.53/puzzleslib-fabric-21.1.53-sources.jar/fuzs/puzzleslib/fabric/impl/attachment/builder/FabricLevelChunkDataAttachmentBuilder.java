package fuzs.puzzleslib.fabric.impl.attachment.builder;

import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import net.minecraft.class_2818;
import net.minecraft.class_5455;

public final class FabricLevelChunkDataAttachmentBuilder<V> extends FabricDataAttachmentBuilder<class_2818, V> implements DataAttachmentRegistry.Builder<class_2818, V> {

    @Override
    protected class_5455 getRegistryAccess(class_2818 holder) {
        return holder.method_12200().method_30349();
    }
}
