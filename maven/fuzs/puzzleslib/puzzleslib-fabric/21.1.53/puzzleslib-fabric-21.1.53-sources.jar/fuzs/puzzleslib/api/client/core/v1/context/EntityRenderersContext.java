package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_5617;

/**
 * register a renderer for an entity
 */
@FunctionalInterface
public interface EntityRenderersContext {

    /**
     * registers an {@link net.minecraft.class_897} for a given entity
     *
     * @param entityType             entity type token to render for
     * @param entityRendererProvider entity renderer provider
     * @param <T>                    type of entity
     */
    <T extends class_1297> void registerEntityRenderer(class_1299<? extends T> entityType, class_5617<T> entityRendererProvider);
}
