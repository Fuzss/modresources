package fuzs.puzzleslib.api.biome.v1;

import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Set;
import java.util.function.BiPredicate;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_5483;

/**
 * The modification context for the biomes spawn settings.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext$SpawnSettingsContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
public interface MobSpawnSettingsContext {

    /**
     * Associated JSON property: <code>spawners</code>.
     *
     * @see class_5483#method_31004(class_1311)
     * @see class_5483.class_5496#method_31011(class_1311, class_5483.class_1964)
     */
    void addSpawn(class_1311 spawnGroup, class_5483.class_1964 spawnEntry);

    /**
     * Removes any spawns matching the given predicate from this biome, and returns true if any matched.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     */
    boolean removeSpawns(BiPredicate<class_1311, class_5483.class_1964> predicate);

    /**
     * Removes all spawns of the given entity type.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     *
     * @return True if any spawns were removed.
     */
    default boolean removeSpawnsOfEntityType(class_1299<?> entityType) {
        return this.removeSpawns((spawnGroup, spawnEntry) -> spawnEntry.field_9389 == entityType);
    }

    /**
     * Removes all spawns of the given spawn group.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     */
    default void clearSpawns(class_1311 group) {
        this.removeSpawns((spawnGroup, spawnEntry) -> spawnGroup == group);
    }

    /**
     * Removes all spawns.
     *
     * <p>Associated JSON property: <code>spawners</code>.
     */
    default void clearSpawns() {
        this.removeSpawns((spawnGroup, spawnEntry) -> true);
    }

    /**
     * Associated JSON property: <code>spawn_costs</code>.
     *
     * @param entityType   the entity type
     * @param energyBudget a tolerance level for how close other spawns can happen nearby, like an aura;
     *                     the higher this value is the closer mobs can spawn together, usually <code>0.15</code> in vanilla
     * @param charge       the strength of a spawn aura, defines how far away other spawn attempts are affected, usually <code>0.7</code> in vanilla
     * @see class_5483#method_31003(class_1299)
     * @see class_5483.class_5496#method_31009(class_1299, double, double)
     * @see <a href="https://www.reddit.com/r/minecraft_configs/comments/idmyyr/so_how_does_spawn_costs_actuallywork/">Reddit: So how does spawn_costs actually...work?</a>
     */
    void setSpawnCost(class_1299<?> entityType, double energyBudget, double charge);

    /**
     * Removes a spawn cost entry for a given entity type.
     *
     * <p>Associated JSON property: <code>spawn_costs</code>.
     */
    boolean clearSpawnCost(class_1299<?> entityType);

    /**
     * @return all {@link class_1311}s that have any spawns registered for them
     */
    Set<class_1311> getMobCategoriesWithSpawns();

    /**
     * @param type mob category
     * @return all {@link net.minecraft.class_5483.class_1964} registered for the given <code>type</code>
     */
    List<class_5483.class_1964> getSpawnerData(class_1311 type);

    /**
     * @return all {@link class_1299}s with a registered spawn cost
     */
    Set<class_1299<?>> getEntityTypesWithSpawnCost();

    /**
     * @param type entity type
     * @return the {@link net.minecraft.class_5483.class_5265} for the given <code>type</code>
     */
    @Nullable class_5483.class_5265 getSpawnCost(class_1299<?> type);

    /**
     * Associated JSON property: <code>creature_spawn_probability</code>.
     *
     * @see class_5483#method_31002()
     * @see class_5483.class_5496#method_31008(float)
     */
    float getCreatureGenerationProbability();

    /**
     * Associated JSON property: <code>creature_spawn_probability</code>.
     *
     * @see class_5483#method_31002()
     * @see class_5483.class_5496#method_31008(float)
     */
    void setCreatureGenerationProbability(float probability);
}
