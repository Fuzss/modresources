package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import fuzs.puzzleslib.fabric.api.client.event.v1.registry.ResourcePackFinderRegistry;
import fuzs.puzzleslib.fabric.impl.core.context.DataPackSourcesContextFabricImpl;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3285;

public final class ResourcePackSourcesContextFabricImpl implements PackRepositorySourcesContext {

    @Override
    public void registerRepositorySource(class_3285 repositorySource) {
        Objects.requireNonNull(repositorySource, "repository source is null");
        ResourcePackFinderRegistry.INSTANCE.register(repositorySource);
    }

    @Override
    public void registerBuiltInPack(class_2960 resourceLocation, class_2561 displayName, boolean shouldAddAutomatically) {
        Objects.requireNonNull(resourceLocation, "resource location is null");
        Objects.requireNonNull(displayName, "display name is null");
        DataPackSourcesContextFabricImpl.registerBuiltInPack(resourceLocation,
                displayName, shouldAddAutomatically,
                class_3264.field_14188);
    }
}
