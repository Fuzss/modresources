package fuzs.puzzleslib.api.init.v3.family;

import fuzs.puzzleslib.impl.init.VanillaBlockSetVariant;
import fuzs.puzzleslib.impl.init.boat.TypedBoat;
import fuzs.puzzleslib.impl.init.boat.TypedBoatItem;
import fuzs.puzzleslib.impl.init.boat.TypedChestBoat;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1690;
import net.minecraft.class_1765;
import net.minecraft.class_1792;
import net.minecraft.class_1822;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2440;
import net.minecraft.class_2482;
import net.minecraft.class_2508;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_2551;
import net.minecraft.class_3542;
import net.minecraft.class_3619;
import net.minecraft.class_4970;
import net.minecraft.class_5794;
import net.minecraft.class_6880;
import net.minecraft.class_7264;
import net.minecraft.class_7707;
import net.minecraft.class_7713;
import net.minecraft.class_7715;
import net.minecraft.world.level.block.*;
import org.jetbrains.annotations.Nullable;

public interface BlockSetVariant extends class_3542 {
    BlockSetVariant CHISELED = new VanillaBlockSetVariant.Direct(class_5794.class_5796.field_28534,
            class_5794.class_5795::method_33486);
    BlockSetVariant CRACKED = new VanillaBlockSetVariant.Direct(class_5794.class_5796.field_29503,
            class_5794.class_5795::method_34593);
    BlockSetVariant POLISHED = new VanillaBlockSetVariant.Direct(class_5794.class_5796.field_28542,
            class_5794.class_5795::method_33495);
    BlockSetVariant CUT = new VanillaBlockSetVariant.Direct(class_5794.class_5796.field_33689, class_5794.class_5795::method_36544);
    BlockSetVariant MOSAIC = new VanillaBlockSetVariant.Direct(class_5794.class_5796.field_40594, class_5794.class_5795::method_45965);
    BlockSetVariant STAIRS = new VanillaBlockSetVariant(class_5794.class_5796.field_28540, class_5794.class_5795::method_33493) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("stairs"),
                                    (class_4970.class_2251 properties) -> new class_2510(context.getBaseBlock()
                                            .comp_349()
                                            .method_9564(), properties),
                                    () -> {
                                        return class_4970.class_2251.method_55226(context.getBaseBlock().comp_349());
                                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant SLAB = new VanillaBlockSetVariant(class_5794.class_5796.field_28539, class_5794.class_5795::method_33492) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries().registerBlock(context.getNameWithSuffix("slab"), class_2482::new, () -> {
                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349());
                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant WALL = new VanillaBlockSetVariant(class_5794.class_5796.field_28544, class_5794.class_5795::method_33497) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries().registerBlock(context.getNameWithSuffix("wall"), class_2544::new, () -> {
                        return class_4970.class_2251.method_55226(context.getBaseBlock().comp_349()).method_51369();
                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant FENCE = new VanillaBlockSetVariant(class_5794.class_5796.field_28536, class_5794.class_5795::method_33490) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries().registerBlock(context.getNameWithSuffix("fence"), class_2354::new, () -> {
                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349());
                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant FENCE_GATE = new VanillaBlockSetVariant(class_5794.class_5796.field_28537,
            class_5794.class_5795::method_33491) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("fence_gate"),
                                    (class_4970.class_2251 properties) -> new class_2349(context.getWoodType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_51369();
                                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant DOOR = new VanillaBlockSetVariant(class_5794.class_5796.field_28535, class_5794.class_5795::method_33489) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("door"),
                                    (class_4970.class_2251 properties) -> new class_2323(context.getBlockSetType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_22488()
                                                .method_50012(class_3619.field_15971);
                                    }));
            context.registerItem(this,
                    context.getRegistries().registerBlockItem(context.getBlock(this), class_1765::new));
        }
    };
    BlockSetVariant TRAPDOOR = new VanillaBlockSetVariant(class_5794.class_5796.field_28543, class_5794.class_5795::method_33496) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("trapdoor"),
                                    (class_4970.class_2251 properties) -> new class_2533(context.getBlockSetType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_22488()
                                                .method_26235(class_2246::method_26114);
                                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant BUTTON = new VanillaBlockSetVariant(class_5794.class_5796.field_28533, class_5794.class_5795::method_33482) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("button"),
                                    (class_4970.class_2251 properties) -> new class_2269(context.getBlockSetType(),
                                            30,
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_9634()
                                                .method_50012(class_3619.field_15971);
                                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant PRESSURE_PLATE = new VanillaBlockSetVariant(class_5794.class_5796.field_28541,
            class_5794.class_5795::method_33494) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("pressure_plate"),
                                    (class_4970.class_2251 properties) -> new class_2440(context.getBlockSetType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_51369()
                                                .method_9634()
                                                .method_50012(class_3619.field_15971);
                                    }));
            context.registerItem(this, context.getRegistries().registerBlockItem(context.getBlock(this)));
        }
    };
    BlockSetVariant SIGN = new StandaloneBlockSetVariant(class_5794.class_5796.field_28538) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("sign"),
                                    (class_4970.class_2251 properties) -> new class_2508(context.getWoodType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_51369()
                                                .method_9634();
                                    }));
            class_6880<class_2248> signHolder = context.getBlock(this);
            context.registerBlock(WALL_SIGN,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("wall_sign"),
                                    (class_4970.class_2251 properties) -> new class_2551(context.getWoodType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_16228(signHolder.comp_349())
                                                .method_51369()
                                                .method_9634();
                                    }));
            context.registerItem(this,
                    context.getRegistries()
                            .registerBlockItem(signHolder,
                                    (class_2248 block, class_1792.class_1793 properties) -> new class_1822(properties,
                                            block,
                                            context.getBlock(WALL_SIGN).comp_349()),
                                    () -> new class_1792.class_1793().method_7889(16)));
        }
    };
    BlockSetVariant WALL_SIGN = new StandaloneBlockSetVariant(class_5794.class_5796.field_28545) {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            throw new UnsupportedOperationException();
        }
    };
    BlockSetVariant HANGING_SIGN = new StandaloneBlockSetVariant("hanging_sign") {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerBlock(this,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("hanging_sign"),
                                    (class_4970.class_2251 properties) -> new class_7713(context.getWoodType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_51369()
                                                .method_9634();
                                    }));
            class_6880<class_2248> hangingSignHolder = context.getBlock(this);
            context.registerBlock(WALL_HANGING_SIGN,
                    context.getRegistries()
                            .registerBlock(context.getNameWithSuffix("wall_hanging_sign"),
                                    (class_4970.class_2251 properties) -> new class_7715(context.getWoodType(),
                                            properties),
                                    () -> {
                                        return class_4970.class_2251.method_9630(context.getBaseBlock().comp_349())
                                                .method_16228(hangingSignHolder.comp_349())
                                                .method_51369()
                                                .method_9634();
                                    }));
            context.registerItem(this,
                    context.getRegistries()
                            .registerBlockItem(hangingSignHolder,
                                    (class_2248 block, class_1792.class_1793 properties) -> new class_7707(block,
                                            context.getBlock(WALL_HANGING_SIGN).comp_349(),
                                            properties),
                                    () -> new class_1792.class_1793().method_7889(16)));
        }
    };
    BlockSetVariant WALL_HANGING_SIGN = new StandaloneBlockSetVariant("wall_hanging_sign") {
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            throw new UnsupportedOperationException();
        }
    };
    BlockSetVariant BOAT = new StandaloneBlockSetVariant("boat") {
        @SuppressWarnings("unchecked")
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerEntityType(this,
                    (class_6880.class_6883<class_1299<?>>) (class_6880.class_6883<?>) context.getRegistries()
                            .registerEntityType(context.getNameWithSuffix("boat"),
                                    () -> class_1299.class_1300.method_5903((class_1299<class_1690> entityType, class_1937 level) -> {
                                                return new TypedBoat(entityType, level, () -> context.getItem(this).comp_349());
                                            }, class_1311.field_17715)
                                            .method_17687(1.375F, 0.5625F)
                                            .method_55687(0.5625F)
                                            .method_27299(10)));
            context.registerItem(this,
                    context.getRegistries()
                            .registerItem(context.getNameWithSuffix("boat"),
                                    (class_1792.class_1793 properties) -> new TypedBoatItem((class_1299<? extends class_1690>) context.getEntityType(
                                            this).comp_349(), properties),
                                    () -> new class_1792.class_1793().method_7889(1)));
        }
    };
    BlockSetVariant CHEST_BOAT = new StandaloneBlockSetVariant("chest_boat") {
        @SuppressWarnings("unchecked")
        @Override
        public void generateFor(BlockSetFamily.Context context) {
            context.registerEntityType(this,
                    (class_6880.class_6883<class_1299<?>>) (class_6880.class_6883<?>) context.getRegistries()
                            .registerEntityType(context.getNameWithSuffix("chest_boat"),
                                    () -> class_1299.class_1300.method_5903((class_1299<class_7264> entityType, class_1937 level) -> {
                                                return new TypedChestBoat(entityType,
                                                        level,
                                                        () -> context.getItem(this).comp_349());
                                            }, class_1311.field_17715)
                                            .method_17687(1.375F, 0.5625F)
                                            .method_55687(0.5625F)
                                            .method_27299(10)));
            context.registerItem(this,
                    context.getRegistries()
                            .registerItem(context.getNameWithSuffix("chest_boat"),
                                    (class_1792.class_1793 properties) -> new TypedBoatItem((class_1299<? extends class_1690>) context.getEntityType(
                                            this).comp_349(), properties),
                                    () -> new class_1792.class_1793().method_7889(1)));
        }
    };

    void generateFor(BlockSetFamily.Context context);

    class_5794.@Nullable class_5796 toVanilla();
}
