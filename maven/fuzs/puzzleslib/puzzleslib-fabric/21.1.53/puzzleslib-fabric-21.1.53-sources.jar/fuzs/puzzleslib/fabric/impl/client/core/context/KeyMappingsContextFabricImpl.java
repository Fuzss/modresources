package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.KeyMappingsContext;
import fuzs.puzzleslib.api.client.key.v1.KeyActivationHandler;
import fuzs.puzzleslib.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.fabric.impl.client.key.FabricKeyMappingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_6599;
import java.util.Objects;
import java.util.function.Consumer;

public final class KeyMappingsContextFabricImpl implements KeyMappingsContext {

    @Override
    public void registerKeyMapping(class_304 keyMapping, KeyActivationHandler activationHandler) {
        Objects.requireNonNull(keyMapping, "key mapping is null");
        Objects.requireNonNull(activationHandler, "activation handler is null");
        KeyBindingHelper.registerKeyBinding(keyMapping);
        ((FabricKeyMappingHelper) KeyMappingHelper.INSTANCE).setKeyActivationContext(keyMapping,
                activationHandler.getActivationContext()
        );
        registerKeyActivationHandles(keyMapping, activationHandler);
    }

    private static void registerKeyActivationHandles(class_304 keyMapping, KeyActivationHandler activationHandler) {
        if (activationHandler.gameHandler() != null) {
            ClientTickEvents.START_CLIENT_TICK.register((class_310 minecraft) -> {
                if (minecraft.field_1724 != null) {
                    while (keyMapping.method_1436()) {
                        activationHandler.gameHandler().accept(minecraft);
                    }
                }
            });
        }
        if (activationHandler.screenHandler() != null) {
            ScreenEvents.BEFORE_INIT.register(
                    (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (activationHandler.screenType().isInstance(screen)) {
                            ScreenKeyboardEvents.allowKeyPress(screen).register(
                                    (class_437 currentScreen, int key, int scancode, int modifiers) -> {
                                        if (!(minecraft.field_1755 instanceof class_6599) && keyMapping.method_1417(key,
                                                scancode
                                        )) {
                                            ((Consumer<class_437>) activationHandler.screenHandler()).accept(
                                                    currentScreen);
                                            return false;
                                        } else {
                                            return true;
                                        }
                                    });
                        }
                    });
        }
    }
}
