package fuzs.puzzleslib.api.container.v1;

import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2624;

/**
 * A simple {@link class_1263} implementation with only default methods and an item list getter.
 */
@FunctionalInterface
public interface ListBackedContainer extends class_1263 {

    /**
     * Creates a container backed by the item list.
     */
    static ListBackedContainer of(class_2371<class_1799> items) {
        return () -> items;
    }

    /**
     * Creates a new empty container with the specified size.
     */
    static ListBackedContainer of(int size) {
        return of(class_2371.method_10213(size, class_1799.field_8037));
    }

    /**
     * Retrieves the item list backing this inventory.
     * <p>
     * Must not be called <code>getItems</code> as it clashes with {@link class_2624#method_11282()} causing
     * remapping issues.
     */
    class_2371<class_1799> getContainerItems();

    @Override
    default int method_5439() {
        return this.getContainerItems().size();
    }

    @Override
    default boolean method_5442() {
        for (class_1799 stack : this.getContainerItems()) {
            if (!stack.method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    default class_1799 method_5438(int slot) {
        return slot >= 0 && slot < this.method_5439() ? this.getContainerItems().get(slot) : class_1799.field_8037;
    }

    @Override
    default class_1799 method_5434(int slot, int count) {
        class_1799 result = class_1262.method_5430(this.getContainerItems(), slot, count);
        if (!result.method_7960()) this.method_5431();
        return result;
    }

    @Override
    default class_1799 method_5441(int slot) {
        return class_1262.method_5428(this.getContainerItems(), slot);
    }

    @Override
    default void method_5447(int slot, class_1799 stack) {
        if (slot >= 0 && slot < this.method_5439()) {
            this.getContainerItems().set(slot, stack);
            if (!stack.method_7960() && stack.method_7947() > this.method_5444()) {
                stack.method_7939(this.method_5444());
            }
            this.method_5431();
        }
    }

    @Override
    default void method_5448() {
        this.getContainerItems().clear();
        this.method_5431();
    }

    @Override
    default void method_5431() {
        // NO-OP
    }

    @Override
    default boolean method_5443(class_1657 player) {
        return true;
    }
}
