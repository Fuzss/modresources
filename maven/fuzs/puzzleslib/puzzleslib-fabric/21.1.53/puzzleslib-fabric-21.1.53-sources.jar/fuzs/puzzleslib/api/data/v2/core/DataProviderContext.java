package fuzs.puzzleslib.api.data.v2.core;

import com.google.common.base.Suppliers;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_2405;
import net.minecraft.class_3300;
import net.minecraft.class_7225;
import net.minecraft.class_7784;
import net.minecraft.class_7887;

/**
 * A context class for providing instances required by a {@link class_2405}.
 * <p>
 * Very similar to Forge's <code>net.minecraftforge.data.event.GatherDataEvent</code>.
 */
public class DataProviderContext {
    /**
     * The generating mod id.
     */
    private final String modId;
    /**
     * The pack output instance.
     */
    private final class_7784 packOutput;
    /**
     * Registry lookup provider.
     */
    private final Supplier<CompletableFuture<class_7225.class_7874>> registries;

    /**
     * @param modId      the generating mod id
     * @param packOutput the pack output instance
     * @param registries registry lookup provider
     */
    public DataProviderContext(String modId, class_7784 packOutput, CompletableFuture<class_7225.class_7874> registries) {
        this(modId, packOutput, () -> registries);
    }

    /**
     * @param modId      the generating mod id
     * @param packOutput the pack output instance
     * @param registries registry lookup provider
     */
    private DataProviderContext(String modId, class_7784 packOutput, Supplier<CompletableFuture<class_7225.class_7874>> registries) {
        this.modId = modId;
        this.packOutput = packOutput;
        this.registries = registries;
    }

    /**
     * Creates a dummy-like context instance useful for runtime generation in conjunction with
     * {@link fuzs.puzzleslib.api.resources.v1.DynamicPackResources}.
     *
     * @param modId the generating mod id
     * @return new context instance
     */
    public static DataProviderContext fromModId(String modId) {
        return fromModId(modId, Path.of(""));
    }

    /**
     * Creates a dummy-like context instance useful for runtime generation in conjunction with
     * {@link fuzs.puzzleslib.api.resources.v1.DynamicPackResources}.
     *
     * @param modId the generating mod id
     * @param path  output path
     * @return new context instance
     */
    public static DataProviderContext fromModId(String modId, Path path) {
        return new DataProviderContext(modId,
                new class_7784(path),
                Suppliers.memoize(() -> CompletableFuture.supplyAsync(class_7887::method_46817,
                        class_156.method_18349())));
    }

    /**
     * @return the generating mod id
     */
    public String getModId() {
        return this.modId;
    }

    /**
     * @return the pack output instance
     */
    public class_7784 getPackOutput() {
        return this.packOutput;
    }

    /**
     * @return registry lookup provider
     */
    public CompletableFuture<class_7225.class_7874> getRegistries() {
        return this.registries.get();
    }

    /**
     * @return the client resource manager
     */
    @Nullable
    public class_3300 getClientResourceManager() {
        return null;
    }

    /**
     * @return the server resource manager
     */
    @Nullable
    public class_3300 getServerResourceManager() {
        return null;
    }

    /**
     * Creates a new data provider context instance with a different set of registries.
     *
     * @param registries registry lookup provider
     * @return new data provider context instance
     */
    public DataProviderContext withRegistries(CompletableFuture<class_7225.class_7874> registries) {
        return new DataProviderContext(this.modId, this.packOutput, registries);
    }

    /**
     * A simple shortcut for a data provider factory requiring an instance of this context, helps with complaints about
     * parametrized varargs.
     */
    @FunctionalInterface
    public interface Factory extends Function<DataProviderContext, class_2405> {
        // NO-OP
    }
}
