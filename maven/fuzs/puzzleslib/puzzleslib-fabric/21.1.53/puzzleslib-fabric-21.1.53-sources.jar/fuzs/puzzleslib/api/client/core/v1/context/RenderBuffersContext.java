package fuzs.puzzleslib.api.client.core.v1.context;

import com.google.common.base.Preconditions;
import java.util.Objects;
import net.minecraft.class_1921;
import net.minecraft.class_9799;

/**
 * Register a render buffer for a {@link class_1921} that is added in {@link net.minecraft.class_4599#class_4599(int)}.
 */
public interface RenderBuffersContext {

    /**
     * Registers a render buffer for the specified render type.
     *
     * @param renderTypes a render type of the render buffer
     */
    default void registerRenderBuffer(class_1921... renderTypes) {
        Objects.requireNonNull(renderTypes, "render types is null");
        Preconditions.checkState(renderTypes.length > 0, "render types is empty");
        for (class_1921 renderType : renderTypes) {
            Objects.requireNonNull(renderType, "render type is null");
            this.registerRenderBuffer(renderType, new class_9799(renderType.method_22722()));
        }
    }

    /**
     * Registers a render buffer for the specified render type.
     *
     * @param renderType   a render type of the render buffer
     * @param renderBuffer a render buffer to register
     */
    void registerRenderBuffer(class_1921 renderType, class_9799 renderBuffer);
}
