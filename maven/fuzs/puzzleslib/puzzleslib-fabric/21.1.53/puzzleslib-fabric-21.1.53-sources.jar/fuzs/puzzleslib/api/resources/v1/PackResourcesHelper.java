package fuzs.puzzleslib.api.resources.v1;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import fuzs.puzzleslib.api.core.v1.ModContainer;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3281;
import net.minecraft.class_3285;
import net.minecraft.class_3288;
import net.minecraft.class_7699;

/**
 * This class provides some simple helper methods for constructing simple
 * {@link net.minecraft.class_3262} implementation for either the client or server.
 */
public final class PackResourcesHelper {

    private PackResourcesHelper() {
        // NO-OP
    }

    /**
     * Create a simple pack title for a {@link class_3264}.
     *
     * @param packType the pack type
     * @return the title component
     */
    public static class_2561 getPackTitle(class_3264 packType) {
        return class_2561.method_43470(
                "Generated " + (packType == class_3264.field_14188 ? "Resource" : "Data") + " Pack");
    }

    /**
     * Create a fancy pack description for dynamic resources from a mod.
     *
     * @param modId the source mod for the pack
     * @return the description component
     */
    public static class_2561 getPackDescription(String modId) {
        return ModLoaderEnvironment.INSTANCE.getModContainer(modId)
                .map(ModContainer::getDisplayName)
                .map((String name) -> {
                    return class_2561.method_43470("Resources for " + name);
                })
                .orElseGet(() -> class_2561.method_43470("Resources (" + modId + ")"));
    }

    /**
     * Creates the location for a built-in pack bundled in the mod jar.
     * <ul>
     *     <li>Data pack path: {@code data/<modId>/datapacks/<path>}</li>
     *     <li>Resource pack path: {@code assets/<modId>/resourcepacks/<path>}</li>
     * </ul>
     *
     * @param resourceLocation the resource location for the pack
     * @param packType         the pack type
     * @return the pack location inside {@code resources}
     */
    public static class_2960 getBuiltInPack(class_2960 resourceLocation, class_3264 packType) {
        return resourceLocation.method_45138(packType.method_14413() + "/" + resourceLocation.method_12836() + "/" + (
                packType == class_3264.field_14188 ? "resourcepacks" : "datapacks") + "/");
    }

    /**
     * Creates a new resource pack repository source (for the client).
     * <p>
     * Can be added via {@link fuzs.puzzleslib.api.client.event.v1.AddResourcePackReloadListenersCallback}.
     *
     * @param id      id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory {@link net.minecraft.class_3262} implementation supplier
     * @param hidden  controls whether the pack is hidden from user-facing screens like the resource pack and data pack
     *                selection screens
     * @return the {@link class_3285} to be added to the
     *         {@link net.minecraft.class_3283}
     */
    public static class_3285 buildClientPack(class_2960 id, Supplier<AbstractModPackResources> factory, boolean hidden) {
        return buildClientPack(id, factory, true, class_3288.class_3289.field_14280, hidden, hidden);
    }

    /**
     * Creates a new resource pack repository source (for the client).
     * <p>
     * Can be added via {@link fuzs.puzzleslib.api.client.event.v1.AddResourcePackReloadListenersCallback}.
     *
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be
     *                      moved to the left side; this is used for the vanilla resource pack
     * @param position      insertion end in the pack list, new packs are usually inserted at the top above vanilla
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden        controls whether the pack is hidden from user-facing screens like the resource pack and data
     *                      pack selection screens
     * @return the {@link class_3285} to be added to the
     *         {@link net.minecraft.class_3283}
     */
    public static class_3285 buildClientPack(class_2960 id, Supplier<AbstractModPackResources> factory, boolean required, class_3288.class_3289 position, boolean fixedPosition, boolean hidden) {
        return (Consumer<class_3288> consumer) -> {
            consumer.accept(AbstractModPackResources.buildPack(class_3264.field_14188,
                    id,
                    factory,
                    getPackTitle(class_3264.field_14188),
                    getPackDescription(id.method_12836()),
                    required,
                    position,
                    fixedPosition,
                    hidden,
                    class_7699.method_45397()));
        };
    }

    /**
     * Creates a new resource pack repository source (for the client).
     * <p>
     * Can be added via {@link fuzs.puzzleslib.api.client.event.v1.AddResourcePackReloadListenersCallback}.
     *
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param title         the title of this pack shown in the pack selection screen
     * @param description   the description for this pack shown in the pack selection screen
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be
     *                      moved to the left side; this is used for the vanilla resource pack
     * @param position      insertion end in the pack list, new packs are usually inserted at the top above vanilla
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden        controls whether the pack is hidden from user-facing screens like the resource pack and data
     *                      pack selection screens
     * @return the {@link class_3285} to be added to the
     *         {@link net.minecraft.class_3283}
     */
    public static class_3285 buildClientPack(class_2960 id, Supplier<AbstractModPackResources> factory, class_2561 title, class_2561 description, boolean required, class_3288.class_3289 position, boolean fixedPosition, boolean hidden) {
        return (Consumer<class_3288> consumer) -> {
            consumer.accept(AbstractModPackResources.buildPack(class_3264.field_14188,
                    id,
                    factory,
                    title,
                    description,
                    required,
                    position,
                    fixedPosition,
                    hidden,
                    class_7699.method_45397()));
        };
    }

    /**
     * Creates a new hidden data pack repository source (for the server).
     * <p>
     * Can be added via {@link fuzs.puzzleslib.api.event.v1.server.AddDataPackReloadListenersCallback}.
     *
     * @param id      id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory {@link net.minecraft.class_3262} implementation supplier
     * @param hidden  controls whether the pack is hidden from user-facing screens like the resource pack and data pack
     *                selection screens
     * @return the {@link class_3285} to be added to the
     *         {@link net.minecraft.class_3283}
     */
    public static class_3285 buildServerPack(class_2960 id, Supplier<AbstractModPackResources> factory, boolean hidden) {
        return buildServerPack(id, factory, true, class_3288.class_3289.field_14280, hidden, hidden);
    }

    /**
     * Creates a new data pack repository source (for the server).
     * <p>
     * Can be added via {@link fuzs.puzzleslib.api.event.v1.server.AddDataPackReloadListenersCallback}.
     *
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be
     *                      moved to the left side; this is used for the vanilla resource pack
     * @param position      insertion end in the pack list, new packs are usually inserted at the top above vanilla
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden        controls whether the pack is hidden from user-facing screens like the resource pack and data
     *                      pack selection screens, only available on Forge
     * @return the {@link class_3285} to be added to the
     *         {@link net.minecraft.class_3283}
     */
    public static class_3285 buildServerPack(class_2960 id, Supplier<AbstractModPackResources> factory, boolean required, class_3288.class_3289 position, boolean fixedPosition, boolean hidden) {
        return (Consumer<class_3288> consumer) -> {
            consumer.accept(AbstractModPackResources.buildPack(class_3264.field_14190,
                    id,
                    factory,
                    getPackTitle(class_3264.field_14190),
                    getPackDescription(id.method_12836()),
                    required,
                    position,
                    fixedPosition,
                    hidden,
                    class_7699.method_45397()));
        };
    }

    /**
     * Creates a new data pack repository source (for the server).
     * <p>
     * Can be added via {@link fuzs.puzzleslib.api.event.v1.server.AddDataPackReloadListenersCallback}.
     *
     * @param id            id for the pack, used for internal references and is stored in <code>options.txt</code>
     * @param factory       {@link net.minecraft.class_3262} implementation supplier
     * @param title         the title of this pack shown in the pack selection screen
     * @param description   the description for this pack shown in the pack selection screen
     * @param required      a required pack cannot be disabled, like in the pack selection screen the pack cannot be
     *                      moved to the left side; this is used for the vanilla resource pack
     * @param position      insertion end in the pack list, new packs are usually inserted at the top above vanilla
     * @param fixedPosition a fixed pack cannot be moved up or down, like a server or world resource pack
     * @param hidden        controls whether the pack is hidden from user-facing screens like the resource pack and data
     *                      pack selection screens, only available on Forge
     * @return the {@link class_3285} to be added to the
     *         {@link net.minecraft.class_3283}
     */
    public static class_3285 buildServerPack(class_2960 id, Supplier<AbstractModPackResources> factory, class_2561 title, class_2561 description, boolean required, class_3288.class_3289 position, boolean fixedPosition, boolean hidden) {
        return (Consumer<class_3288> consumer) -> {
            consumer.accept(AbstractModPackResources.buildPack(class_3264.field_14190,
                    id,
                    factory,
                    title,
                    description,
                    required,
                    position,
                    fixedPosition,
                    hidden,
                    class_7699.method_45397()));
        };
    }

    /**
     * Creates a new {@link class_3288.class_7679} instance with additional parameters only supported on NeoForge.
     *
     * @param resourceLocation     the pack identifier
     * @param descriptionComponent the pack description component
     * @param packCompatibility    the pack version, ideally retrieved from
     *                             {@link net.minecraft.class_6489#method_48017(class_3264)}
     * @param featureFlagSet       the feature flags provided by this pack
     * @param hidden               controls whether the pack is hidden from user-facing screens like the resource pack
     *                             and data pack selection screens
     * @return the created pack info instance
     */
    public static class_3288.class_7679 createPackInfo(class_2960 resourceLocation, class_2561 descriptionComponent, class_3281 packCompatibility, class_7699 featureFlagSet, boolean hidden) {
        return CommonAbstractions.INSTANCE.createPackInfo(resourceLocation,
                descriptionComponent,
                packCompatibility,
                featureFlagSet,
                hidden);
    }
}
