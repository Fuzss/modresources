package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_368;
import net.minecraft.class_374;

@FunctionalInterface
public interface AddToastCallback {
    EventInvoker<AddToastCallback> EVENT = EventInvoker.lookup(AddToastCallback.class);

    /**
     * Fires when a {@link class_368} is about to be queued in {@link net.minecraft.class_374#method_1999(class_368)}.
     *
     * @param toastManager the {@link class_374} instance
     * @param toast        the toast instance being queued
     * @return {@link EventResult#INTERRUPT} to prevent the toast from being queued, it will never render,
     * {@link EventResult#PASS} to allow queueing the toast normally
     */
    EventResult onAddToast(class_374 toastManager, class_368 toast);
}
