package fuzs.puzzleslib.api.biome.v1;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_3414;
import net.minecraft.class_4761;
import net.minecraft.class_4763;
import net.minecraft.class_4967;
import net.minecraft.class_4968;
import net.minecraft.class_5195;
import net.minecraft.class_6880;

/**
 * The modification context for the biomes effects.
 *
 * <p>Mostly copied from Fabric API's Biome API, specifically <code>net.fabricmc.fabric.api.biome.v1.BiomeModificationContext$GenerationSettingsContext</code>
 * to allow for use in common project and to allow reimplementation on Forge using Forge's native biome modification system.
 *
 * <p>Copyright (c) FabricMC
 * <p>SPDX-License-Identifier: Apache-2.0
 */
@SuppressWarnings("OptionalUsedAsFieldOrParameterType")
public interface SpecialEffectsContext {

    /**
     * @see class_4763#method_24387()
     * @see class_4763.class_4764#method_24392(int)
     */
    void setFogColor(int fogColor);

    /**
     * @see class_4763#method_24387()
     * @see class_4763.class_4764#method_24392(int)
     */
    int getFogColor();

    /**
     * @see class_4763#method_24388()
     * @see class_4763.class_4764#method_24395(int)
     */
    void setWaterColor(int waterColor);

    /**
     * @see class_4763#method_24388()
     * @see class_4763.class_4764#method_24395(int)
     */
    int getWaterColor();

    /**
     * @see class_4763#method_24389()
     * @see class_4763.class_4764#method_24397(int)
     */
    void setWaterFogColor(int waterFogColor);

    /**
     * @see class_4763#method_24389()
     * @see class_4763.class_4764#method_24397(int)
     */
    int getWaterFogColor();

    /**
     * @see class_4763#method_30810()
     * @see class_4763.class_4764#method_30820(int)
     */
    void setSkyColor(int skyColor);

    /**
     * @see class_4763#method_30810()
     * @see class_4763.class_4764#method_30820(int)
     */
    int getSkyColor();

    /**
     * @see class_4763#method_30811()
     * @see class_4763.class_4764#method_30821(int)
     */
    void setFoliageColorOverride(Optional<Integer> foliageColorOverride);

    /**
     * @see class_4763#method_30811()
     * @see class_4763.class_4764#method_30821(int)
     */
    Optional<Integer> getFoliageColorOverride();

    /**
     * @see class_4763#method_30811()
     * @see class_4763.class_4764#method_30821(int)
     */
    default void setFoliageColorOverride(int foliageColorOverride) {
        this.setFoliageColorOverride(Optional.of(foliageColorOverride));
    }

    /**
     * @see class_4763#method_30811()
     * @see class_4763.class_4764#method_30821(int)
     */
    default void clearFoliageColorOverride() {
        this.setFoliageColorOverride(Optional.empty());
    }

    /**
     * @see class_4763#method_30812()
     * @see class_4763.class_4764#method_30822(int)
     */
    void setGrassColorOverride(Optional<Integer> grassColorOverride);

    /**
     * @see class_4763#method_30812()
     * @see class_4763.class_4764#method_30822(int)
     */
    Optional<Integer> getGrassColorOverride();

    /**
     * @see class_4763#method_30812()
     * @see class_4763.class_4764#method_30822(int)
     */
    default void setGrassColorOverride(int grassColorOverride) {
        this.setGrassColorOverride(Optional.of(grassColorOverride));
    }

    /**
     * @see class_4763#method_30812()
     * @see class_4763.class_4764#method_30822(int)
     */
    default void clearGrassColorOverride() {
        this.setGrassColorOverride(Optional.empty());
    }

    /**
     * @see class_4763#method_30814()
     * @see class_4763.class_4764#method_30818(class_4763.class_5486)
     */
    void setGrassColorModifier(@NotNull class_4763.class_5486 grassColorModifier);

    /**
     * @see class_4763#method_30814()
     * @see class_4763.class_4764#method_30818(class_4763.class_5486)
     */
    class_4763.class_5486 getGrassColorModifier();

    /**
     * @see class_4763#method_24390()
     * @see class_4763.class_4764#method_24393(class_4761)
     */
    void setAmbientParticleSettings(Optional<class_4761> ambientParticleSettings);

    /**
     * @see class_4763#method_24390()
     * @see class_4763.class_4764#method_24393(class_4761)
     */
    Optional<class_4761> getAmbientParticleSettings();

    /**
     * @see class_4763#method_24390()
     * @see class_4763.class_4764#method_24393(class_4761)
     */
    default void setAmbientParticleSettings(@NotNull class_4761 ambientParticleSettings) {
        Objects.requireNonNull(ambientParticleSettings, "ambient particle settings is null");
        this.setAmbientParticleSettings(Optional.of(ambientParticleSettings));
    }

    /**
     * @see class_4763#method_24390()
     * @see class_4763.class_4764#method_24393(class_4761)
     */
    default void clearAmbientParticleSettings() {
        this.setAmbientParticleSettings(Optional.empty());
    }

    /**
     * @see class_4763#method_24939()
     * @see class_4763.class_4764#method_24942(class_6880)
     */
    void setAmbientLoopSoundEvent(Optional<class_6880<class_3414>> ambientLoopSoundEvent);

    /**
     * @see class_4763#method_24939()
     * @see class_4763.class_4764#method_24942(class_6880)
     */
    Optional<class_6880<class_3414>> getAmbientLoopSoundEvent();

    /**
     * @see class_4763#method_24939()
     * @see class_4763.class_4764#method_24942(class_6880)
     */
    default void setAmbientLoopSoundEvent(@NotNull class_6880<class_3414> ambientLoopSoundEvent) {
        Objects.requireNonNull(ambientLoopSoundEvent, "ambient loop sound event is null");
        this.setAmbientLoopSoundEvent(Optional.of(ambientLoopSoundEvent));
    }

    /**
     * @see class_4763#method_24939()
     * @see class_4763.class_4764#method_24942(class_6880)
     */
    default void clearAmbientLoopSoundEvent() {
        this.setAmbientLoopSoundEvent(Optional.empty());
    }

    /**
     * @see class_4763#method_24940()
     * @see class_4763.class_4764#method_24943(class_4968)
     */
    void setAmbientMoodSettings(Optional<class_4968> ambientMoodSettings);

    /**
     * @see class_4763#method_24940()
     * @see class_4763.class_4764#method_24943(class_4968)
     */
    Optional<class_4968> getAmbientMoodSettings();

    /**
     * @see class_4763#method_24940()
     * @see class_4763.class_4764#method_24943(class_4968)
     */
    default void setAmbientMoodSettings(@NotNull class_4968 ambientMoodSettings) {
        Objects.requireNonNull(ambientMoodSettings, "ambient mood settings is null");
        this.setAmbientMoodSettings(Optional.of(ambientMoodSettings));
    }

    /**
     * @see class_4763#method_24940()
     * @see class_4763.class_4764#method_24943(class_4968)
     */
    default void clearAmbientMoodSettings() {
        this.setAmbientMoodSettings(Optional.empty());
    }

    /**
     * @see class_4763#method_24941()
     * @see class_4763.class_4764#method_24944(class_4967)
     */
    void setAmbientAdditionsSettings(Optional<class_4967> ambientAdditionsSettings);

    /**
     * @see class_4763#method_24941()
     * @see class_4763.class_4764#method_24944(class_4967)
     */
    Optional<class_4967> getAmbientAdditionsSettings();

    /**
     * @see class_4763#method_24941()
     * @see class_4763.class_4764#method_24944(class_4967)
     */
    default void setAmbientAdditionsSettings(@NotNull class_4967 ambientAdditionsSettings) {
        Objects.requireNonNull(ambientAdditionsSettings, "ambient additions settings is null");
        this.setAmbientAdditionsSettings(Optional.of(ambientAdditionsSettings));
    }

    /**
     * @see class_4763#method_24941()
     * @see class_4763.class_4764#method_24944(class_4967)
     */
    default void clearAmbientAdditionsSettings() {
        this.setAmbientAdditionsSettings(Optional.empty());
    }

    /**
     * @see class_4763#method_27345()
     * @see class_4763.class_4764#method_27346(class_5195)
     */
    void setBackgroundMusic(Optional<class_5195> backgroundMusic);

    /**
     * @see class_4763#method_27345()
     * @see class_4763.class_4764#method_27346(class_5195)
     */
    Optional<class_5195> getBackgroundMusic();

    /**
     * @see class_4763#method_27345()
     * @see class_4763.class_4764#method_27346(class_5195)
     */
    default void setBackgroundMusic(@NotNull class_5195 backgroundMusic) {
        Objects.requireNonNull(backgroundMusic, "background music is null");
        this.setBackgroundMusic(Optional.of(backgroundMusic));
    }

    /**
     * @see class_4763#method_27345()
     * @see class_4763.class_4764#method_27346(class_5195)
     */
    default void clearBackgroundMusic() {
        this.setBackgroundMusic(Optional.empty());
    }
}
