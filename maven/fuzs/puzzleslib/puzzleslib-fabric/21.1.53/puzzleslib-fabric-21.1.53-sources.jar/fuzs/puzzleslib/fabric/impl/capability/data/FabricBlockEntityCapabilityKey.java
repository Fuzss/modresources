package fuzs.puzzleslib.fabric.impl.capability.data;

import fuzs.puzzleslib.api.capability.v3.data.BlockEntityCapabilityKey;
import fuzs.puzzleslib.api.capability.v3.data.CapabilityComponent;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_2586;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class FabricBlockEntityCapabilityKey<T extends class_2586, C extends CapabilityComponent<T>> extends FabricCapabilityKey<T, C> implements BlockEntityCapabilityKey<T, C> {

    public FabricBlockEntityCapabilityKey(AttachmentType<C> attachmentType, Predicate<Object> filter, Supplier<C> factory) {
        super(attachmentType, filter, factory);
    }
}
