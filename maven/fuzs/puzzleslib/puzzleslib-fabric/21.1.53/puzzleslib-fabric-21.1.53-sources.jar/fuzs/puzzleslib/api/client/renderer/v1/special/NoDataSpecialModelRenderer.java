package fuzs.puzzleslib.api.client.renderer.v1.special;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import org.jetbrains.annotations.Nullable;

/**
 * Copied from Minecraft 1.21.8.
 */
public interface NoDataSpecialModelRenderer extends SpecialModelRenderer<Void> {
    @Override
    default @Nullable Void extractArgument(class_1799 stack) {
        return null;
    }

    @Override
    default void render(@Nullable Void argument, class_4587 poseStack, class_4597 bufferSource, int lightCoords, int overlayCoords, boolean hasFoil) {
        this.render(poseStack, bufferSource, lightCoords, overlayCoords, hasFoil);
    }

    void render(class_4587 poseStack, class_4597 bufferSource, int lightCoords, int overlayCoords, boolean hasFoil);

    interface Unbaked extends SpecialModelRenderer.Unbaked<Void> {
        @Override
        MapCodec<? extends fuzs.puzzleslib.api.client.renderer.v1.special.NoDataSpecialModelRenderer.Unbaked> type();
    }
}
