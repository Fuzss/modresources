package fuzs.puzzleslib.api.event.v1.entity.living;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

public final class MobEffectEvents {
    public static final EventInvoker<Affects> AFFECTS = EventInvoker.lookup(Affects.class);
    public static final EventInvoker<Apply> APPLY = EventInvoker.lookup(Apply.class);
    public static final EventInvoker<Remove> REMOVE = EventInvoker.lookup(Remove.class);
    public static final EventInvoker<Expire> EXPIRE = EventInvoker.lookup(Expire.class);

    private MobEffectEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Affects {

        /**
         * Called when the game checks whether a new {@link class_1293} can be applied to a {@link class_1309}
         * in {@link class_1309#method_6049(class_1293)}.
         * <p>
         * This is used for mobs such as spiders to make them immune to poison, or wither mobs to make them immune to
         * the wither effect.
         *
         * @param entity the entity the check is run for
         * @param effect the effect instance to check
         * @return {@link EventResult#ALLOW} to allow this effect to be applied to the entity, {@link EventResult#DENY}
         *         to prevent this effect from being applied to the entity, {@link EventResult#PASS} to let vanilla
         *         logic handle this case
         */
        EventResult onMobEffectAffects(class_1309 entity, class_1293 effect);
    }

    @FunctionalInterface
    public interface Apply {

        /**
         * Called when a new {@link class_1293} is added to a {@link class_1309} in
         * {@link class_1309#method_37222(class_1293, class_1297)}.
         * <p>
         * If another effect with the same {@link net.minecraft.class_1291} is already present, the existing
         * effect instance will be updated.
         *
         * @param entity       the living entity the effect instance is added to
         * @param effect       the effect instance being added
         * @param oldEffect    a potentially already existing effect instance with the same mob effect type
         * @param effectSource a potential other entity responsible for inflicting this new effect
         */
        void onMobEffectApply(class_1309 entity, class_1293 effect, @Nullable class_1293 oldEffect, @Nullable class_1297 effectSource);
    }

    @FunctionalInterface
    public interface Remove {

        /**
         * Called when a {@link class_1293} is removed from a {@link class_1309} in
         * {@link class_1309#method_6016(class_6880)}.
         * <p>
         * Most notable this event runs when finishing drinking milk, and allows for preventing certain effects from
         * being removed as a result.
         *
         * @param entity the entity the effect instance is to be removed from
         * @param effect the effect instance to remove
         * @return {@link EventResult#INTERRUPT} to prevent this effect instance from being removed,
         *         {@link EventResult#PASS} to let vanilla logic handle this case
         */
        EventResult onMobEffectRemove(class_1309 entity, class_1293 effect);
    }

    @FunctionalInterface
    public interface Expire {

        /**
         * Called when a {@link class_1293} is removed from a {@link class_1309} in
         * <code>net.minecraft.world.entity.LivingEntity#tickEffects</code> due to the instance duration having run
         * out.
         * <p>
         * This is the case when <code>net.minecraft.world.effect.MobEffectInstance#hasRemainingDuration()</code>
         * returns <code>false</code>.
         *
         * @param entity the living entity the effect instance has run out on
         * @param effect the mob effect instance that has run out
         */
        void onMobEffectExpire(class_1309 entity, class_1293 effect);
    }
}
