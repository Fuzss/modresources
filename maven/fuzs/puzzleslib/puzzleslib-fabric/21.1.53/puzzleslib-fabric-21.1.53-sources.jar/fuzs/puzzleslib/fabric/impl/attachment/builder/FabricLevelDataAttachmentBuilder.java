package fuzs.puzzleslib.fabric.impl.attachment.builder;

import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import net.minecraft.class_1937;
import net.minecraft.class_5455;

public final class FabricLevelDataAttachmentBuilder<V> extends FabricDataAttachmentBuilder<class_1937, V> implements DataAttachmentRegistry.Builder<class_1937, V> {

    @Override
    protected class_5455 getRegistryAccess(class_1937 holder) {
        return holder.method_30349();
    }
}
