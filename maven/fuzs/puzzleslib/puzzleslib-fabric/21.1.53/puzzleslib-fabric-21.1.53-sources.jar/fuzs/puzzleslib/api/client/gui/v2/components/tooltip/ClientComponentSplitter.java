package fuzs.puzzleslib.api.client.gui.v2.components.tooltip;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;
import net.minecraft.class_1078;
import net.minecraft.class_310;
import net.minecraft.class_5348;
import net.minecraft.class_5481;

/**
 * A small helper class for splitting instance of {@link class_5348}. Useful for splitting tooltip components.
 */
@Deprecated
public final class ClientComponentSplitter {

    private ClientComponentSplitter() {
        // NO-OP
    }

    /**
     * Split formatted text instances according to a max width.
     *
     * @param tooltipLines components for building the tooltip
     * @return stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(class_5348... tooltipLines) {
        return splitTooltipLines(170, Arrays.asList(tooltipLines));
    }

    /**
     * Split formatted text instances according to a max width.
     *
     * @param maxWidth     the maximum text width for the line splitter
     * @param tooltipLines components for building the tooltip
     * @return stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(int maxWidth, class_5348... tooltipLines) {
        return splitTooltipLines(maxWidth, Arrays.asList(tooltipLines));
    }

    /**
     * Split formatted text instances according to a max width.
     *
     * @param tooltipLines components for building the tooltip
     * @return stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(List<? extends class_5348> tooltipLines) {
        return splitTooltipLines(170, tooltipLines);
    }

    /**
     * Split formatted text instances according to a max width.
     *
     * @param maxWidth     the maximum text width for the line splitter
     * @param tooltipLines components for building the tooltip
     * @return stream of split char sequences
     */
    public static Stream<class_5481> splitTooltipLines(int maxWidth, List<? extends class_5348> tooltipLines) {
        return tooltipLines.stream().flatMap((class_5348 formattedText) -> {
            List<class_5481> lines = class_310.method_1551().field_1772.method_1728(formattedText, maxWidth);
            if (lines.isEmpty()) {
                // empty components yield an empty list
                // since empty lines are desired on tooltips make sure they don't go missing
                return Stream.of(class_5481.field_26385);
            } else {
                return lines.stream();
            }
        });
    }

    /**
     * Process formatted text instances into char sequences.
     *
     * @param tooltipLines components for building the tooltip
     * @return stream of char sequences
     */
    public static Stream<class_5481> processTooltipLines(class_5348... tooltipLines) {
        return processTooltipLines(Arrays.asList(tooltipLines));
    }

    /**
     * Process formatted text instances into char sequences.
     *
     * @param tooltipLines components for building the tooltip
     * @return stream of char sequences
     */
    public static Stream<class_5481> processTooltipLines(List<? extends class_5348> tooltipLines) {
        return tooltipLines.stream().map((class_5348 formattedText) -> {
            return class_1078.method_10517().method_30934(formattedText);
        });
    }
}
