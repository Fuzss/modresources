package fuzs.puzzleslib.api.client.core.v1.context;

import java.util.function.Consumer;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5944;

/**
 * Allows for registering new resource pack provided shaders for use in e.g. {@link net.minecraft.class_1921}.
 */
@FunctionalInterface
public interface CoreShadersContext {

    /**
     * Registers a shader.
     *
     * @param id           shader identifier
     * @param vertexFormat one of {@link net.minecraft.class_290}
     * @param callback     access to the shader instance for storage
     */
    void registerCoreShader(class_2960 id, class_293 vertexFormat, Consumer<class_5944> callback);
}
