package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.function.BiConsumer;
import net.minecraft.class_2960;
import net.minecraft.class_3302;

@FunctionalInterface
public interface AddResourcePackReloadListenersCallback {
    EventInvoker<AddResourcePackReloadListenersCallback> EVENT = EventInvoker.lookup(
            AddResourcePackReloadListenersCallback.class);

    /**
     * Adds a listener to the client resource manager (for resource packs) to reload at the end of all resources.
     *
     * @param consumer registers a reload listener with an id for debugging, common listener types include:
     *                 <ul>
     *                 <li>{@link class_3302}</li>
     *                 <li>{@link net.minecraft.class_4013}</li>
     *                 <li>{@link net.minecraft.class_4080}</li>
     *                 </ul>
     */
    void onAddResourcePackReloadListeners(BiConsumer<class_2960, class_3302> consumer);
}
