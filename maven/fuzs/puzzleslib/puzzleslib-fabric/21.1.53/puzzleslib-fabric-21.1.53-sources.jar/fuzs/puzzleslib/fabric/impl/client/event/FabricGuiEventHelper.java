package fuzs.puzzleslib.fabric.impl.client.event;

import fuzs.puzzleslib.api.client.event.v1.gui.RenderGuiEvents;
import fuzs.puzzleslib.api.client.event.v1.gui.RenderGuiLayerEvents;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_3486;
import net.minecraft.class_3532;
import net.minecraft.class_5134;
import net.minecraft.class_9080;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.function.Supplier;

/**
 * The keys are to be used with Fabric's {@link net.fabricmc.loader.api.ObjectShare}.
 * <p>
 * Contains the current render height of hotbar decorations as an {@link Integer}.
 * <p>
 * When rendering additional hotbar decorations on the screen make sure to update the value by adding the height of the
 * decorations, which is usually {@code 10}.
 * <p>
 * The implementation is meant to be similar to NeoForge's {@code Gui#leftHeight} &amp; {@code Gui#rightHeight}.
 */
public final class FabricGuiEventHelper {
    private static final String KEY_GUI_LEFT_HEIGHT = PuzzlesLibMod.id("left_height").toString();
    private static final String KEY_GUI_RIGHT_HEIGHT = PuzzlesLibMod.id("right_height").toString();
    private static final Set<class_2960> CANCELLED_GUI_LAYERS = new HashSet<>();

    private FabricGuiEventHelper() {
        // NO-OP
    }

    private static void invokeGuiLayerEvents(class_329 gui, class_332 guiGraphics, class_9779 deltaTracker) {
        if (gui.field_2035.field_1690.field_1842) return;
        guiGraphics.method_51448().method_22903();
        guiGraphics.method_51448().method_46416(0.0F, 0.0F, 50.0F);
        for (class_2960 resourceLocation : RenderGuiLayerEvents.VANILLA_GUI_LAYERS_VIEW) {
            if (FabricGuiEvents.beforeRenderGuiElement(resourceLocation).invoker().onBeforeRenderGuiLayer(gui.field_2035,
                    guiGraphics, deltaTracker
            ).isInterrupt()) {
                CANCELLED_GUI_LAYERS.add(resourceLocation);
            } else {
                FabricGuiEvents.afterRenderGuiElement(resourceLocation).invoker().onAfterRenderGuiLayer(gui.field_2035,
                        guiGraphics, deltaTracker
                );
            }
            guiGraphics.method_51448().method_46416(0.0F, 0.0F, class_9080.field_47848);
        }
        guiGraphics.method_51448().method_22909();
    }

    public static void cancelIfNecessary(class_2960 resourceLocation, CallbackInfo callback) {
        cancelIfNecessary(resourceLocation, () -> {
            callback.cancel();
            return Optional.empty();
        });
    }

    public static <T> Optional<T> cancelIfNecessary(class_2960 resourceLocation, Supplier<Optional<T>> supplier) {
        return CANCELLED_GUI_LAYERS.contains(resourceLocation) ? supplier.get() : Optional.empty();
    }

    public static int getGuiLeftHeight() {
        return FabricLoader.getInstance().getObjectShare().get(KEY_GUI_LEFT_HEIGHT) instanceof Integer i ? i : 0;
    }

    public static int getGuiRightHeight() {
        return FabricLoader.getInstance().getObjectShare().get(KEY_GUI_RIGHT_HEIGHT) instanceof Integer i ? i : 0;
    }

    public static void setGuiLeftHeight(int leftHeight) {
        FabricLoader.getInstance().getObjectShare().put(KEY_GUI_LEFT_HEIGHT, leftHeight);
    }

    public static void setGuiRightHeight(int rightHeight) {
        FabricLoader.getInstance().getObjectShare().put(KEY_GUI_RIGHT_HEIGHT, rightHeight);
    }

    public static void registerEventHandlers() {
        RenderGuiEvents.BEFORE.register(EventPhase.FIRST, (minecraft, guiGraphics, deltaTracker) -> {
            CANCELLED_GUI_LAYERS.clear();
            setGuiLeftHeight(39);
            setGuiRightHeight(39);
        });
        RenderGuiEvents.BEFORE.register(EventPhase.AFTER, FabricGuiEventHelper::invokeGuiLayerEvents);
        RenderGuiLayerEvents.after(RenderGuiLayerEvents.PLAYER_HEALTH).register(EventPhase.FIRST,
                (minecraft, guiGraphics, deltaTracker) -> {
                    if (minecraft.method_1560() instanceof class_1657 player) {
                        int playerHealth = class_3532.method_15386(player.method_6032());
                        float maxHealth = Math.max((float) player.method_45325(class_5134.field_23716),
                                (float) Math.max(minecraft.field_1705.field_2033, playerHealth)
                        );
                        int absorptionAmount = class_3532.method_15386(player.method_6067());
                        int healthRows = class_3532.method_15386((maxHealth + (float) absorptionAmount) / 2.0F / 10.0F);
                        int healthRowShift = Math.max(10 - (healthRows - 2), 3);
                        setGuiLeftHeight(getGuiLeftHeight() + 10 + (healthRows - 1) * healthRowShift);
                    }
                }
        );
        RenderGuiLayerEvents.after(RenderGuiLayerEvents.ARMOR_LEVEL).register(EventPhase.FIRST,
                (minecraft, guiGraphics, deltaTracker) -> {
                    if (minecraft.method_1560() instanceof class_1657 player && player.method_6096() > 0) {
                        setGuiLeftHeight(getGuiLeftHeight() + 10);
                    }
                }
        );
        RenderGuiLayerEvents.after(RenderGuiLayerEvents.FOOD_LEVEL).register(EventPhase.FIRST,
                (minecraft, guiGraphics, deltaTracker) -> {
                    if (minecraft.method_1560() instanceof class_1657) {
                        class_1309 livingEntity = minecraft.field_1705.method_1734();
                        if (minecraft.field_1705.method_1744(livingEntity) == 0) {
                            setGuiRightHeight(getGuiRightHeight() + 10);
                        }
                    }
                }
        );
        RenderGuiLayerEvents.after(RenderGuiLayerEvents.AIR_LEVEL).register(EventPhase.FIRST,
                (minecraft, guiGraphics, deltaTracker) -> {
                    if (minecraft.method_1560() instanceof class_1657 player) {
                        int maxAirSupply = player.method_5748();
                        int airSupply = Math.min(player.method_5669(), maxAirSupply);
                        if (player.method_5777(class_3486.field_15517) || airSupply < maxAirSupply) {
                            setGuiRightHeight(getGuiRightHeight() + 10);
                        }
                    }
                }
        );
        RenderGuiLayerEvents.after(RenderGuiLayerEvents.VEHICLE_HEALTH).register(EventPhase.FIRST,
                (minecraft, guiGraphics, deltaTracker) -> {
                    if (minecraft.method_1560() instanceof class_1657) {
                        class_1309 livingEntity = minecraft.field_1705.method_1734();
                        int maxHearts = minecraft.field_1705.method_1744(livingEntity);
                        setGuiRightHeight(getGuiRightHeight() + 10 * class_3532.method_15386(maxHearts / 10.0F));
                    }
                }
        );
    }
}
