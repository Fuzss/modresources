package fuzs.puzzleslib.fabric.impl.attachment;

import fuzs.puzzleslib.api.attachment.v4.DataAttachmentRegistry;
import fuzs.puzzleslib.fabric.impl.attachment.builder.FabricBlockEntityDataAttachmentBuilder;
import fuzs.puzzleslib.fabric.impl.attachment.builder.FabricEntityDataAttachmentBuilder;
import fuzs.puzzleslib.fabric.impl.attachment.builder.FabricLevelChunkDataAttachmentBuilder;
import fuzs.puzzleslib.fabric.impl.attachment.builder.FabricLevelDataAttachmentBuilder;
import fuzs.puzzleslib.impl.attachment.DataAttachmentRegistryImpl;
import net.minecraft.class_1937;
import net.minecraft.class_2818;

public final class FabricDataAttachmentRegistryImpl implements DataAttachmentRegistryImpl {

    @Override
    public <V> DataAttachmentRegistry.EntityBuilder<V> getEntityTypeBuilder() {
        return new FabricEntityDataAttachmentBuilder<>();
    }

    @Override
    public <V> DataAttachmentRegistry.BlockEntityBuilder<V> getBlockEntityTypeBuilder() {
        return new FabricBlockEntityDataAttachmentBuilder<>();
    }

    @Override
    public <V> DataAttachmentRegistry.Builder<class_2818, V> getLevelChunkBuilder() {
        return new FabricLevelChunkDataAttachmentBuilder<>();
    }

    @Override
    public <V> DataAttachmentRegistry.Builder<class_1937, V> getLevelBuilder() {
        return new FabricLevelDataAttachmentBuilder<>();
    }
}
