package fuzs.puzzleslib.fabric.impl.core;

import fuzs.puzzleslib.api.core.v1.context.PayloadTypesContext;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import fuzs.puzzleslib.impl.network.codec.CustomPacketPayloadAdapter;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntFunction;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2596;
import net.minecraft.class_2792;
import net.minecraft.class_8709;
import net.minecraft.class_8710;

public interface FabricProxy extends ProxyImpl {

    static FabricProxy get() {
        return (FabricProxy) ProxyImpl.INSTANCE;
    }

    boolean notHidden(String id);

    PayloadTypesContext createPayloadTypesContext(String modId);

    @Deprecated
    <M1, M2> void registerClientReceiver(class_8710.class_9154<CustomPacketPayloadAdapter<M1>> type, BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally, Function<M1, ClientboundMessage<M2>> messageAdapter);

    @Deprecated
    <M1, M2> void registerServerReceiver(class_8710.class_9154<CustomPacketPayloadAdapter<M1>> type, BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally, Function<M1, ServerboundMessage<M2>> messageAdapter);

    void setupHandshakePayload(class_8710.class_9154<class_8709> payloadType);

    default boolean shouldStartDestroyBlock(class_2338 blockPos) {
        throw new RuntimeException("Should start destroy block accessed for wrong side!");
    }

    default void startClientPrediction(class_1937 level, IntFunction<class_2596<class_2792>> predictiveAction) {
        throw new RuntimeException("Start client prediction accessed for wrong side!");
    }
}
