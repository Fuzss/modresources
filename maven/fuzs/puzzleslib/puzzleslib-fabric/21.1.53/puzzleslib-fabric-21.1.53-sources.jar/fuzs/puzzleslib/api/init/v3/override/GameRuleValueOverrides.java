package fuzs.puzzleslib.api.init.v3.override;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1928;

/**
 * Allows for setting new default values to game rules in a development environment.
 * <p>Will not apply any changes in a production environment.
 */
@Deprecated
public final class GameRuleValueOverrides {

    private GameRuleValueOverrides() {

    }

    /**
     * Set a default value for a {@link net.minecraft.class_1928.class_4310}.
     *
     * @param key   game rule key
     * @param value new default value
     */
    public static void setValue(class_1928.class_4313<class_1928.class_4310> key, boolean value) {
        setValue(key, (class_1928.class_4310 booleanValue) -> {
            booleanValue.method_20758(value, null);
        });
    }

    /**
     * Set a default value for an {@link net.minecraft.class_1928.class_4312}.
     *
     * @param key   game rule key
     * @param value new default value
     */
    public static void setValue(class_1928.class_4313<class_1928.class_4312> key, int value) {
        setValue(key, (class_1928.class_4312 integerValue) -> {
            integerValue.method_35236(value, null);
        });
    }

    /**
     * Get a game rules by the corresponding key and adjust the game rule value constructor to immediately set a new
     * value after initialization.
     *
     * @param key         game rule key
     * @param valueSetter implementation for setting the value
     * @param <T>         game rule value type
     */
    public static <T extends class_1928.class_4315<T>> void setValue(class_1928.class_4313<T> key, Consumer<T> valueSetter) {
        class_1928.class_4314<T> type = (class_1928.class_4314<T>) class_1928.field_9197.get(key);
        Function<class_1928.class_4314<T>, T> originalConstructor = type.field_19415;
        type.field_19415 = (class_1928.class_4314<T> factoryType) -> {
            T ruleValue = originalConstructor.apply(factoryType);
            valueSetter.accept(ruleValue);
            return ruleValue;
        };
    }
}
