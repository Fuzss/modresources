package fuzs.puzzleslib.api.init.v3.tags;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import java.util.Map;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/**
 * A simple helper class for creating new {@link class_6862} instances via a pre-set namespace.
 * <p>
 * TODO maybe rename to KeyedTagFactory
 */
@Deprecated
public final class BoundTagFactory {
    private static final Map<String, BoundTagFactory> VALUES = Maps.newConcurrentMap();
    /**
     * Factory instance for namespace <code>minecraft</code>.
     */
    public static final BoundTagFactory MINECRAFT = make("minecraft");
    /**
     * Factory instance for namespace <code>c</code>.
     */
    public static final BoundTagFactory COMMON = make("c");
    /**
     * Factory instance for namespace <code>fabric</code>.
     */
    public static final BoundTagFactory FABRIC = make("fabric");
    /**
     * Factory instance for namespace <code>forge</code>.
     */
    public static final BoundTagFactory FORGE = make("forge");
    /**
     * Factory instance for namespace <code>curios</code>.
     */
    public static final BoundTagFactory CURIOS = make("curios");
    /**
     * Factory instance for namespace <code>trinkets</code>.
     */
    public static final BoundTagFactory TRINKETS = make("trinkets");

    private final String namespace;

    private BoundTagFactory(String namespace) {
        this.namespace = namespace;
    }

    /**
     * Construct a new factory instance backed by a provided namespace.
     *
     * @param namespace the namespace
     * @return new factory instance
     */
    public static BoundTagFactory make(String namespace) {
        return VALUES.computeIfAbsent(namespace, BoundTagFactory::new);
    }

    /**
     * Creates a new {@link class_6862} for any type of registry from a given path.
     *
     * @param registryKey key for registry to create key from
     * @param path        path for new tag key
     * @param <T>         registry type
     * @return new tag key
     */
    public <T> class_6862<T> registerTagKey(class_5321<? extends class_2378<T>> registryKey, String path) {
        return class_6862.method_40092(registryKey, ResourceLocationHelper.fromNamespaceAndPath(this.namespace, path));
    }

    /**
     * Creates a new {@link class_6862} for blocks.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_2248> registerBlockTag(String path) {
        return this.registerTagKey(class_7924.field_41254, path);
    }

    /**
     * Creates a new {@link class_6862} for items.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_1792> registerItemTag(String path) {
        return this.registerTagKey(class_7924.field_41197, path);
    }

    /**
     * Creates a new {@link class_6862} for fluids.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_3611> registerFluidTag(String path) {
        return this.registerTagKey(class_7924.field_41270, path);
    }

    /**
     * Creates a new {@link class_6862} for entity types.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_1299<?>> registerEntityTypeTag(String path) {
        return this.registerTagKey(class_7924.field_41266, path);
    }

    /**
     * Creates a new {@link class_6862} for enchantments.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_1887> registerEnchantmentTag(String path) {
        return this.registerTagKey(class_7924.field_41265, path);
    }

    /**
     * Creates a new {@link class_6862} for biomes.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_1959> registerBiomeTag(String path) {
        return this.registerTagKey(class_7924.field_41236, path);
    }

    /**
     * Creates a new {@link class_6862} for game events.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_5712> registerGameEventTag(String path) {
        return this.registerTagKey(class_7924.field_41273, path);
    }

    /**
     * Creates a new {@link class_6862} for damage types.
     *
     * @param path path for new tag key
     * @return new tag key
     */
    public class_6862<class_8110> registerDamageTypeTag(String path) {
        return this.registerTagKey(class_7924.field_42534, path);
    }
}
