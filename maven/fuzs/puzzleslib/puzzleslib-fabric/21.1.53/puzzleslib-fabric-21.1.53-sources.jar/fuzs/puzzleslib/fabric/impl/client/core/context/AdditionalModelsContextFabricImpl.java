package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.AdditionalModelsContext;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.minecraft.class_2960;
import java.util.Objects;

public final class AdditionalModelsContextFabricImpl implements AdditionalModelsContext {

    @Override
    public void registerAdditionalModel(class_2960... models) {
        Objects.requireNonNull(models, "models is null");
        Preconditions.checkState(models.length > 0, "models is empty");
        ModelLoadingPlugin.register((ModelLoadingPlugin.Context context) -> {
            for (class_2960 model : models) {
                Objects.requireNonNull(model, "model is null");
                context.addModels(model);
            }
        });
    }
}
