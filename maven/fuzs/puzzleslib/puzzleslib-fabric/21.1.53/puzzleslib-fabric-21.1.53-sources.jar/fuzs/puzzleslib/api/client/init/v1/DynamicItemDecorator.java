package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * A hook patched in right at the end of {@link net.minecraft.class_332#method_51432(class_327, class_1799, int, int, String)} with basically the same arguments.
 * <p>Required as a wrapper for the Forge equivalent <code>net.minecraftforge.client.IItemDecorator</code>.
 */
@FunctionalInterface
public interface DynamicItemDecorator {

    /**
     * Renders a decoration for an item.
     *
     * @param guiGraphics the gui graphics component
     * @param font        the font renderer instance
     * @param stack       the item stack this decoration is rendered for
     * @param itemPosX    x-position of <code>stack</code> on the screen
     * @param itemPosY    x-position of <code>stack</code> on the screen
     * @return <code>true</code> if any render state has been altered (rendering text using <code>font</code> does that too), so that we can reset that afterward
     */
    boolean renderItemDecorations(class_332 guiGraphics, class_327 font, class_1799 stack, int itemPosX, int itemPosY);
}
