package fuzs.puzzleslib.fabric.impl.core;

import fuzs.puzzleslib.api.core.v1.ModConstructor;
import fuzs.puzzleslib.api.core.v1.context.PayloadTypesContext;
import fuzs.puzzleslib.api.data.v2.AbstractRecipeProvider;
import fuzs.puzzleslib.api.data.v2.AbstractRecipeProvider.IdentifiableRecipeOutput;
import fuzs.puzzleslib.api.data.v2.recipes.TransformingRecipeOutput;
import fuzs.puzzleslib.api.data.v2.tags.AbstractTagAppender;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents;
import fuzs.puzzleslib.api.init.v3.GameRulesFactory;
import fuzs.puzzleslib.api.init.v3.registry.RegistryFactory;
import fuzs.puzzleslib.api.item.v2.ToolTypeHelper;
import fuzs.puzzleslib.api.item.v2.crafting.CombinedIngredients;
import fuzs.puzzleslib.api.network.v3.ClientboundMessage;
import fuzs.puzzleslib.api.network.v3.ServerboundMessage;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLevelEvents;
import fuzs.puzzleslib.fabric.impl.attachment.FabricDataAttachmentRegistryImpl;
import fuzs.puzzleslib.fabric.impl.core.context.PayloadTypesContextFabricImpl;
import fuzs.puzzleslib.fabric.impl.data.FabricTagAppenderV2;
import fuzs.puzzleslib.fabric.impl.data.FabricTagAppenderV3;
import fuzs.puzzleslib.fabric.impl.event.FabricEventInvokerRegistryImpl;
import fuzs.puzzleslib.fabric.impl.event.SpawnTypeMob;
import fuzs.puzzleslib.fabric.impl.init.FabricGameRulesFactory;
import fuzs.puzzleslib.fabric.impl.init.FabricRegistryFactoryV3;
import fuzs.puzzleslib.fabric.impl.init.FabricRegistryFactoryV4;
import fuzs.puzzleslib.fabric.impl.item.FabricToolTypeHelper;
import fuzs.puzzleslib.fabric.impl.item.crafting.FabricCombinedIngredients;
import fuzs.puzzleslib.impl.attachment.DataAttachmentRegistryImpl;
import fuzs.puzzleslib.impl.core.ModContext;
import fuzs.puzzleslib.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.impl.network.codec.CustomPacketPayloadAdapter;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.entity.FakePlayer;
import net.fabricmc.fabric.api.item.v1.EnchantingContext;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.fabricmc.fabric.impl.datagen.FabricTagBuilder;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1508;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1814;
import net.minecraft.class_1860;
import net.minecraft.class_1887;
import net.minecraft.class_1927;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2535;
import net.minecraft.class_2547;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3244;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_3481;
import net.minecraft.class_3495;
import net.minecraft.class_3730;
import net.minecraft.class_3908;
import net.minecraft.class_4838;
import net.minecraft.class_52;
import net.minecraft.class_5321;
import net.minecraft.class_55;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7403;
import net.minecraft.class_7699;
import net.minecraft.class_8605;
import net.minecraft.class_8609;
import net.minecraft.class_8610;
import net.minecraft.class_8705;
import net.minecraft.class_8706;
import net.minecraft.class_8709;
import net.minecraft.class_8710;
import net.minecraft.class_8735;
import net.minecraft.class_8790;
import net.minecraft.class_9129;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;

public class FabricCommonProxy implements FabricProxy {
    private final Set<String> hiddenPacks = new HashSet<>();
    private MinecraftServer minecraftServer;

    @Override
    public MinecraftServer getMinecraftServer() {
        return this.minecraftServer;
    }

    @Override
    public <T> void openMenu(class_1657 player, class_3908 menuProvider, T data) {
        player.method_17355(new ExtendedScreenHandlerFactory<>() {
            @Override
            public T getScreenOpeningData(class_3222 serverPlayer) {
                return data;
            }

            @Override
            public class_2561 method_5476() {
                return menuProvider.method_5476();
            }

            @Nullable
            @Override
            public class_1703 createMenu(int containerId, class_1661 inventory, class_1657 player) {
                return menuProvider.createMenu(containerId, inventory, player);
            }
        });
    }

    @Override
    public void openMenu(class_3222 serverPlayer, class_3908 menuProvider, BiConsumer<class_3222, class_9129> dataWriter) {
        serverPlayer.method_17355(new ExtendedScreenHandlerFactory<class_9129>() {
            @Override
            public class_9129 getScreenOpeningData(class_3222 serverPlayer) {
                class_9129 buf = new class_9129(Unpooled.buffer(),
                        serverPlayer.method_56673());
                dataWriter.accept(serverPlayer, buf);
                return buf;
            }

            @Override
            public class_2561 method_5476() {
                return menuProvider.method_5476();
            }

            @Nullable
            @Override
            public class_1703 createMenu(int i, class_1661 inventory, class_1657 player) {
                return menuProvider.createMenu(i, inventory, player);
            }
        });
    }

    @Override
    public class_3288.class_7679 createPackInfo(class_2960 resourceLocation, class_2561 descriptionComponent, class_3281 packCompatibility, class_7699 featureFlagSet, boolean hidden) {
        if (hidden) {
            this.hiddenPacks.add(resourceLocation.toString());
        }

        return new class_3288.class_7679(descriptionComponent, packCompatibility, featureFlagSet, Collections.emptyList());
    }

    @Override
    public boolean notHidden(String id) {
        return !this.hiddenPacks.contains(id);
    }

    @Override
    public class_2583 getRarityStyle(class_1814 rarity) {
        return class_2583.field_24360.method_27706(rarity.method_58413());
    }

    @Override
    public void onPlayerDestroyItem(class_1657 player, class_1799 originalItemStack, @Nullable class_1268 interactionHand) {
        // NO-OP
    }

    @Override
    public void forEachPool(class_52.class_53 lootTable, Consumer<? super class_55.class_56> lootPoolConsumer) {
        lootTable.modifyPools(lootPoolConsumer);
    }

    @Override
    public float getEnchantPowerBonus(class_2680 blockState, class_1937 level, class_2338 blockPos) {
        return blockState.method_26164(class_3481.field_44472) ? 1.0F : 0.0F;
    }

    @Override
    public boolean canApplyAtEnchantingTable(class_6880<class_1887> enchantment, class_1799 itemStack) {
        return itemStack.canBeEnchantedWith(enchantment, EnchantingContext.PRIMARY);
    }

    @SuppressWarnings("UnstableApiUsage")
    @Override
    public void setTagBuilderReplace(class_3495 builder, boolean isReplace) {
        ((FabricTagBuilder) builder).fabric_setReplace(isReplace);
    }

    @Override
    public boolean onExplosionStart(class_1937 level, class_1927 explosion) {
        return FabricLevelEvents.EXPLOSION_START.invoker().onExplosionStart(level, explosion).isInterrupt();
    }

    @MustBeInvokedByOverriders
    @Override
    public void registerAllLoadingHandlers() {
        FabricEventInvokerRegistryImpl.registerLoadingHandlers();
    }

    @MustBeInvokedByOverriders
    @Override
    public void registerAllEventHandlers() {
        FabricEventInvokerRegistryImpl.registerEventHandlers();
    }

    @MustBeInvokedByOverriders
    @Override
    public boolean hasChannel(class_2547 packetListener, class_8710.class_9154<?> type) {
        if (packetListener instanceof class_8610 serverConfigurationPacketListener) {
            return ServerConfigurationNetworking.canSend(serverConfigurationPacketListener, type);
        } else if (packetListener instanceof class_3244 serverGamePacketListener) {
            return ServerPlayNetworking.canSend(serverGamePacketListener, type);
        } else {
            return false;
        }
    }

    @MustBeInvokedByOverriders
    @Override
    public class_2535 getConnection(class_2547 packetListener) {
        return packetListener instanceof class_8609 serverPacketListener ?
                serverPacketListener.field_45013 : null;
    }

    @Override
    public class_2596<class_8705> toClientboundPacket(class_8710 payload) {
        return ServerPlayNetworking.createS2CPacket(payload);
    }

    @Override
    public class_2596<class_8706> toServerboundPacket(class_8710 payload) {
        return ClientPlayNetworking.createC2SPacket(payload);
    }

    @Override
    public void finishConfigurationTask(class_8735 packetListener, class_8605.class_8606 type) {
        ((class_8610) packetListener).completeTask(type);
    }

    @Override
    public PayloadTypesContext createPayloadTypesContext(String modId) {
        return new PayloadTypesContextFabricImpl.ServerImpl(modId);
    }

    @Override
    public <M1, M2> void registerClientReceiver(class_8710.class_9154<CustomPacketPayloadAdapter<M1>> type, BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally, Function<M1, ClientboundMessage<M2>> messageAdapter) {
        // NO-OP
    }

    @Override
    public <M1, M2> void registerServerReceiver(class_8710.class_9154<CustomPacketPayloadAdapter<M1>> type, BiConsumer<Throwable, Consumer<class_2561>> disconnectExceptionally, Function<M1, ServerboundMessage<M2>> messageAdapter) {
        ServerPlayNetworking.registerGlobalReceiver(type,
                (CustomPacketPayloadAdapter<M1> payload, ServerPlayNetworking.Context context) -> {
                    try {
                        ServerboundMessage<M2> message = messageAdapter.apply(payload.unwrap());
                        message.getHandler()
                                .handle(message.unwrap(),
                                        context.server(),
                                        context.player().field_13987,
                                        context.player(),
                                        context.player().method_51469());
                    } catch (Throwable throwable) {
                        disconnectExceptionally.accept(throwable, context.responseSender()::disconnect);
                    }
                });
    }

    @MustBeInvokedByOverriders
    @Override
    public void setupHandshakePayload(class_8710.class_9154<class_8709> payloadType) {
        ServerPlayNetworking.registerGlobalReceiver(payloadType,
                (class_8709 payload, ServerPlayNetworking.Context context) -> {
                    // NO-OP
                });
    }

    @Override
    public ModConstructorImpl<ModConstructor> getModConstructorImpl() {
        return new FabricModConstructor();
    }

    @Override
    public ModContext getModContext(String modId) {
        return new FabricModContext(modId);
    }

    @Override
    public RegistryFactory getRegistryFactoryV3() {
        return new FabricRegistryFactoryV3();
    }

    @Override
    public fuzs.puzzleslib.api.init.v4.registry.RegistryFactory getRegistryFactoryV4() {
        return new FabricRegistryFactoryV4();
    }

    @Override
    public GameRulesFactory getGameRulesFactory() {
        return new FabricGameRulesFactory();
    }

    @Override
    public ToolTypeHelper getToolTypeHelper() {
        return new FabricToolTypeHelper();
    }

    @Override
    public CombinedIngredients getCombinedIngredients() {
        return new FabricCombinedIngredients();
    }

    @Override
    public <T> AbstractTagAppender<T> getTagAppenderV2(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        return new FabricTagAppenderV2<>(tagBuilder, keyExtractor);
    }

    @Override
    public <T> fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> getTagAppenderV3(class_3495 tagBuilder, @Nullable Function<T, class_5321<T>> keyExtractor) {
        return new FabricTagAppenderV3<>(tagBuilder, keyExtractor);
    }

    @Override
    public DataAttachmentRegistryImpl getDataAttachmentRegistry() {
        return new FabricDataAttachmentRegistryImpl();
    }

    @Override
    public class_8790 getTransformingRecipeOutput(class_8790 recipeOutput, UnaryOperator<class_1860<?>> operator) {
        return new TransformingRecipeOutput() {
            @Override
            public class_8790 recipeOutput() {
                return recipeOutput;
            }

            @Override
            public UnaryOperator<class_1860<?>> operator() {
                return operator;
            }
        };
    }

    @Override
    public class_8790 getIdentifiableRecipeOutput(AbstractRecipeProvider provider, class_7403 output, class_7225.class_7874 registries, List<CompletableFuture<?>> completableFutures) {
        return provider.new IdentifiableRecipeOutput(output, registries, completableFutures) {
            // NO-OP
        };
    }

    @Override
    public boolean canEquip(class_1799 itemStack, class_1304 equipmentSlot, class_1309 livingEntity) {
        return equipmentSlot == livingEntity.method_32326(itemStack);
    }

    @Override
    public @Nullable class_3730 getMobSpawnReason(class_1308 mob) {
        return ((SpawnTypeMob) mob).puzzleslib$getSpawnType();
    }

    @Override
    public boolean isMobGriefingAllowed(class_3218 serverLevel, @Nullable class_1297 entity) {
        return serverLevel.method_8450().method_8355(class_1928.field_19388);
    }

    @Override
    public class_1297 getPartEntityParent(class_1297 entity) {
        return entity instanceof class_1508 enderDragonPart ? enderDragonPart.field_7007 : entity;
    }

    @Override
    public boolean isFakePlayer(class_3222 serverPlayer) {
        return serverPlayer instanceof FakePlayer;
    }

    @Override
    public boolean isPiglinCurrency(class_1799 itemStack) {
        return itemStack.method_31574(class_4838.field_23826);
    }

    @MustBeInvokedByOverriders
    @Override
    public void registerEventHandlers() {
        FabricProxy.super.registerEventHandlers();
        // registers for game server starting and stopping, so we can keep an instance of the server here
        ServerLifecycleEvents.STARTING.register(EventPhase.FIRST, (MinecraftServer minecraftServer) -> {
            this.minecraftServer = minecraftServer;
        });
        ServerLifecycleEvents.STOPPED.register(EventPhase.LAST, (MinecraftServer minecraftServer) -> {
            this.minecraftServer = null;
        });
    }
}
