package fuzs.puzzleslib.api.client.renderer.v1.model;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3879;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_630;

/**
 * A backport of the modern {@link class_3879} class.
 */
public abstract class RootedModel extends class_3879 {
    protected final class_630 root;
    private final List<class_630> allParts;

    public RootedModel(class_630 root, Function<class_2960, class_1921> renderType) {
        super(renderType);
        this.root = root;
        this.allParts = root.method_32088().toList();
    }

    @Override
    public final void method_2828(class_4587 poseStack, class_4588 buffer, int packedLight, int packedOverlay, int color) {
        this.root().method_22699(poseStack, buffer, packedLight, packedOverlay, color);
    }

    public final class_630 root() {
        return this.root;
    }

    public final List<class_630> allParts() {
        return this.allParts;
    }

    public final void resetPose() {
        for (class_630 modelPart : this.allParts) {
            modelPart.method_41923();
        }
    }
}
