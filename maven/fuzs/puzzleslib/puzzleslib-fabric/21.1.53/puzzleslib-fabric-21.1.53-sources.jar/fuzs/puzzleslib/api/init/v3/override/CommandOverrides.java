package fuzs.puzzleslib.api.init.v3.override;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.event.v1.entity.ServerEntityEvents;
import fuzs.puzzleslib.api.event.v1.entity.player.PlayerCopyEvents;
import fuzs.puzzleslib.api.event.v1.server.ServerLifecycleEvents;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import net.minecraft.class_1291;
import net.minecraft.class_1297;
import net.minecraft.class_3176;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_3738;
import net.minecraft.class_6880;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.function.UnaryOperator;

/**
 * Allows for registering commands that run when a world or a player are first created in a development environment.
 * <p>Will not apply any changes in a production environment.
 */
@Deprecated
public final class CommandOverrides {
    private static final String KEY_PLAYER_JOINED_WORLD = PuzzlesLibMod.id("has_seen_world").method_42094();
    private static final Map<CommandEnvironment, Collection<String>> COMMAND_OVERRIDES = Maps.newEnumMap(
            CommandEnvironment.class);

    private CommandOverrides() {

    }

    /**
     * Registers a command to run for when a world (not level) is first created.
     *
     * @param command       command to run
     * @param onlyDedicated run commands only on a dedicated server
     */
    public static void registerServerCommand(String command, boolean onlyDedicated) {
        CommandEnvironment commandEnvironment =
                onlyDedicated ? CommandEnvironment.DEDICATED_SERVER : CommandEnvironment.SERVER;
        COMMAND_OVERRIDES.computeIfAbsent(commandEnvironment, $ -> new LinkedHashSet<>()).add(command);
    }

    /**
     * Registers an <code>/effect</code> command to run for when a player joins the world for the very first time.
     * <p>
     * Players will be marked with a value retrievable via <code>/tag</code> to prevent running commands a second time.
     *
     * @param holder mob effects to apply
     */
    public static void registerEffectCommand(class_6880<class_1291> holder) {
        registerPlayerCommand("effect give @s " + holder.method_55840() + " infinite 127 true", false);
    }

    /**
     * Registers a command to run for when a player joins the world for the very first time.
     * <p>Players will be marked with a value retrievable via <code>/tag</code> to prevent running commands a second
     * time.
     *
     * @param command       command to run
     * @param onlyDedicated run commands only on a dedicated server
     */
    public static void registerPlayerCommand(String command, boolean onlyDedicated) {
        CommandEnvironment commandEnvironment =
                onlyDedicated ? CommandEnvironment.DEDICATED_PLAYER : CommandEnvironment.PLAYER;
        COMMAND_OVERRIDES.computeIfAbsent(commandEnvironment, $ -> new LinkedHashSet<>()).add(command);
    }

    @ApiStatus.Internal
    public static void registerEventHandlers() {
        ServerLifecycleEvents.STARTED.register((MinecraftServer minecraftServer) -> {
            if (minecraftServer.method_27728().method_27859().method_188() == 0 && minecraftServer.method_27728()
                    .method_194()) {
                executeCommandOverrides(minecraftServer,
                        CommandEnvironment.SERVER,
                        CommandEnvironment.DEDICATED_SERVER,
                        UnaryOperator.identity());
            }
        });
        ServerEntityEvents.LOAD.register((class_1297 entity, class_3218 serverLevel, boolean isLoadedFromDisk, @Nullable class_3730 entitySpawnReason) -> {
            // idea from Serilum's Starter Kit mod
            if (!isLoadedFromDisk && entity instanceof class_3222 serverPlayer && !serverPlayer.method_5752()
                    .contains(KEY_PLAYER_JOINED_WORLD)) {
                serverPlayer.method_5780(KEY_PLAYER_JOINED_WORLD);
                // do not check if commands are enabled for the world, the option is always off on dedicated servers
                if (serverLevel.method_8503().method_3816() || serverLevel.method_8503()
                        .method_27728()
                        .method_194()) {
                    serverLevel.method_8503().method_18858(new class_3738(serverLevel.method_8503().method_3780(), () -> {
                        String playerName = serverPlayer.method_7334().getName();
                        executeCommandOverrides(serverLevel.method_8503(),
                                CommandEnvironment.PLAYER,
                                CommandEnvironment.DEDICATED_PLAYER,
                                (String s) -> s.replaceAll("@[sp]", playerName));
                    }));
                }
            }
        });
        PlayerCopyEvents.COPY.register((class_3222 originalServerPlayer, class_3222 newServerPlayer, boolean originalStillAlive) -> {
            if (!originalStillAlive) {
                originalServerPlayer.method_5738(KEY_PLAYER_JOINED_WORLD);
            }
        });
    }

    private static void executeCommandOverrides(MinecraftServer minecraftServer, CommandEnvironment commandEnvironment, CommandEnvironment dedicatedCommandEnvironment, UnaryOperator<String> formatter) {
        for (String command : COMMAND_OVERRIDES.getOrDefault(commandEnvironment, Collections.emptySet())) {
            minecraftServer.method_3734()
                    .method_44252(minecraftServer.method_3739(), formatter.apply(command));
        }
        if (minecraftServer instanceof class_3176) {
            for (String command : COMMAND_OVERRIDES.getOrDefault(dedicatedCommandEnvironment, Collections.emptySet())) {
                minecraftServer.method_3734()
                        .method_44252(minecraftServer.method_3739(), formatter.apply(command));
            }
        }
    }

    private enum CommandEnvironment {
        DEDICATED_SERVER,
        SERVER,
        DEDICATED_PLAYER,
        PLAYER
    }
}
