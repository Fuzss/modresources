package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1935;
import net.minecraft.class_2960;
import net.minecraft.class_6395;

/**
 * register model predicates for custom item models
 */
public interface ItemModelPropertiesContext {

    /**
     * register a predicate for all items
     *
     * @param identifier predicate name
     * @param function   handler for this predicate
     */
    void registerGlobalProperty(class_2960 identifier, class_6395 function);

    /**
     * register a predicate for an <code>item</code>
     *
     * @param identifier predicate name
     * @param function   handler for this predicate
     * @param items      items to apply the model property to
     */
    void registerItemProperty(class_2960 identifier, class_6395 function, class_1935... items);
}
