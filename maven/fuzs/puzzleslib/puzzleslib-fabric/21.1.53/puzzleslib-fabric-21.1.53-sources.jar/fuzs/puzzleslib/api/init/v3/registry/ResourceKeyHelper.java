package fuzs.puzzleslib.api.init.v3.registry;

import net.minecraft.class_156;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_5321;
import net.minecraft.class_7924;

/**
 * A utility class for creating {@link class_2561 Components} from {@link class_5321 ResourceKeys}.
 */
public final class ResourceKeyHelper {

    private ResourceKeyHelper() {
        // NO-OP
    }

    /**
     * Useful for name components for various data pack registry entries.
     *
     * @param resourceKey the resource key
     * @return the component
     */
    public static class_5250 getComponent(class_5321<?> resourceKey) {
        return class_2561.method_43471(getTranslationKey(resourceKey));
    }

    /**
     * Useful for name components for various data pack registry entries.
     *
     * @param registryKey      the registry key
     * @param resourceLocation the resource location
     * @return the component
     */
    public static class_5250 getComponent(class_5321<? extends class_2378<?>> registryKey, class_2960 resourceLocation) {
        return class_2561.method_43471(getTranslationKey(registryKey, resourceLocation));
    }

    /**
     * @param resourceKey the resource key
     * @return the translation key
     */
    public static String getTranslationKey(class_5321<?> resourceKey) {
        return getTranslationKey(resourceKey.method_58273(), resourceKey.method_29177());
    }

    /**
     * @param registryKey      the registry key
     * @param resourceLocation the resource location
     * @return the translation key
     */
    public static String getTranslationKey(class_5321<? extends class_2378<?>> registryKey, class_2960 resourceLocation) {
        return class_156.method_646(class_7924.method_60915(registryKey), resourceLocation);
    }

    /**
     * Useful for attribute names from enchantment resource keys.
     *
     * @param resourceKey the resource key
     * @return the resource location
     */
    public static class_2960 getResourceLocation(class_5321<?> resourceKey) {
        return getResourceLocation(resourceKey.method_58273(), resourceKey.method_29177());
    }

    /**
     * Useful for attribute names from enchantment resource keys.
     *
     * @param registryKey      the registry key
     * @param resourceLocation the resource location
     * @return the resource location
     */
    public static class_2960 getResourceLocation(class_5321<? extends class_2378<?>> registryKey, class_2960 resourceLocation) {
        return resourceLocation.method_45138(class_7924.method_60915(registryKey) + ".");
    }
}
