package fuzs.puzzleslib.api.init.v3;

import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.server.MinecraftServer;
import java.util.function.BiConsumer;

/**
 * Helper class for registering custom game rules.
 * <p>Fabric has many custom options for game rules (mainly double and enum rules), but since they don't exist on Forge
 * we don't support them.
 */
public interface GameRulesFactory {
    /**
     * the instance
     */
    GameRulesFactory INSTANCE = ProxyImpl.get().getGameRulesFactory();

    /**
     * Register a new boolean game rule.
     *
     * @param name         name of the rule, used for the <code>/gamerule</code> command
     * @param category     category for the game rules screen shown during world creation
     * @param defaultValue the default value for the game rule
     * @return key for accessing the game rule via {@link class_1937#method_8450()}
     */
    default class_1928.class_4313<class_1928.class_4310> registerBooleanRule(String name, class_1928.class_5198 category, boolean defaultValue) {
        return this.register(name, category, this.createBooleanRule(defaultValue));
    }

    /**
     * Register a new integer game rule.
     *
     * @param name         name of the rule, used for the <code>/gamerule</code> command
     * @param category     category for the game rules screen shown during world creation
     * @param defaultValue the default value for the game rule
     * @return key for accessing the game rule via {@link class_1937#method_8450()}
     */
    default class_1928.class_4313<class_1928.class_4312> registerIntRule(String name, class_1928.class_5198 category, int defaultValue) {
        return this.register(name, category, this.createIntRule(defaultValue));
    }

    /**
     * Register a new game rule.
     *
     * @param name     name of the rule, used for the <code>/gamerule</code> command
     * @param category category for the game rules screen shown during world creation
     * @param type     game rule type from one of the factory methods
     * @param <T>      rule value type (boolean or int)
     * @return key for accessing the game rule via {@link class_1937#method_8450()}
     */
    <T extends class_1928.class_4315<T>> class_1928.class_4313<T> register(String name, class_1928.class_5198 category, class_1928.class_4314<T> type);

    /**
     * Create a new {@link net.minecraft.class_1928.class_4310}.
     *
     * @param defaultValue the default value for the game rule
     * @return the game rule
     */
    default class_1928.class_4314<class_1928.class_4310> createBooleanRule(boolean defaultValue) {
        return this.createBooleanRule(defaultValue, (MinecraftServer server, class_1928.class_4310 booleanValue) -> {
            // NO-OP
        });
    }

    /**
     * Create a new {@link net.minecraft.class_1928.class_4310}.
     *
     * @param defaultValue the default value for the game rule
     * @param callback     access to the server, useful for notifying clients of the change
     * @return the game rule
     */
    class_1928.class_4314<class_1928.class_4310> createBooleanRule(boolean defaultValue, BiConsumer<MinecraftServer, class_1928.class_4310> callback);

    /**
     * Create a new {@link net.minecraft.class_1928.class_4312}.
     *
     * @param defaultValue the default value for the game rule
     * @return the game rule
     */
    default class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue) {
        return this.createIntRule(defaultValue, Integer.MIN_VALUE);
    }

    /**
     * Create a new {@link net.minecraft.class_1928.class_4312}.
     * <p>Note that any bounds are not supported on Forge and are therefore simply ignored when creating the new game
     * rule.
     *
     * @param defaultValue the default value for the game rule
     * @param minimumValue the minimum value for this rule, usually {@link Integer#MIN_VALUE}
     * @return the game rule
     */
    default class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue, int minimumValue) {
        return this.createIntRule(defaultValue, minimumValue, Integer.MAX_VALUE);
    }

    /**
     * Create a new {@link net.minecraft.class_1928.class_4312}.
     * <p>Note that any bounds are not supported on Forge and are therefore simply ignored when creating the new game
     * rule.
     *
     * @param defaultValue the default value for the game rule
     * @param minimumValue the minimum value for this rule, usually {@link Integer#MIN_VALUE}
     * @param maximumValue the maximum value for this rule, usually {@link Integer#MAX_VALUE}
     * @return the game rule
     */
    default class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue, int minimumValue, int maximumValue) {
        return this.createIntRule(defaultValue,
                minimumValue,
                maximumValue,
                (MinecraftServer server, class_1928.class_4312 integerValue) -> {
                    // NO-OP
                });
    }

    /**
     * Create a new {@link net.minecraft.class_1928.class_4312}.
     *
     * @param defaultValue the default value for the game rule
     * @param callback     access to the server, useful for notifying clients of the change
     * @return the game rule
     */
    default class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue, BiConsumer<MinecraftServer, class_1928.class_4312> callback) {
        return this.createIntRule(defaultValue, Integer.MIN_VALUE, callback);
    }

    /**
     * Create a new {@link net.minecraft.class_1928.class_4312}.
     * <p>Note that any bounds are not supported on Forge and are therefore simply ignored when creating the new game
     * rule.
     *
     * @param defaultValue the default value for the game rule
     * @param minimumValue the minimum value for this rule, usually {@link Integer#MIN_VALUE}
     * @param callback     access to the server, useful for notifying clients of the change
     * @return the game rule
     */
    default class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue, int minimumValue, BiConsumer<MinecraftServer, class_1928.class_4312> callback) {
        return this.createIntRule(defaultValue, minimumValue, Integer.MAX_VALUE, callback);
    }

    /**
     * Create a new {@link net.minecraft.class_1928.class_4312}.
     * <p>Note that any bounds are not supported on Forge and are therefore simply ignored when creating the new game
     * rule.
     *
     * @param defaultValue the default value for the game rule
     * @param minimumValue the minimum value for this rule, usually {@link Integer#MIN_VALUE}
     * @param maximumValue the maximum value for this rule, usually {@link Integer#MAX_VALUE}
     * @param callback     access to the server, useful for notifying clients of the change
     * @return the game rule
     */
    class_1928.class_4314<class_1928.class_4312> createIntRule(int defaultValue, int minimumValue, int maximumValue, BiConsumer<MinecraftServer, class_1928.class_4312> callback);
}
