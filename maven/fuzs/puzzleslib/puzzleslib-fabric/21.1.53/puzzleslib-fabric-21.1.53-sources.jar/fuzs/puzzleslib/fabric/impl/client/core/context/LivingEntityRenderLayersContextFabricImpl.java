package fuzs.puzzleslib.fabric.impl.client.core.context;

import fuzs.puzzleslib.api.client.core.v1.context.LivingEntityRenderLayersContext;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_922;
import java.util.Objects;
import java.util.function.BiFunction;
import java.util.function.Predicate;

@Deprecated
public final class LivingEntityRenderLayersContextFabricImpl implements LivingEntityRenderLayersContext {

    @SuppressWarnings("unchecked")
    @Override
    public <E extends class_1309, T extends E, M extends class_583<T>> void registerRenderLayer(Predicate<class_1299<E>> filter, BiFunction<class_3883<T, M>, class_5617.class_5618, class_3887<T, M>> factory) {
        Objects.requireNonNull(filter, "filter is null");
        Objects.requireNonNull(factory, "render layer factory is null");
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register(
                (class_1299<? extends class_1309> entityType, class_922<?, ?> entityRenderer, LivingEntityFeatureRendererRegistrationCallback.RegistrationHelper registrationHelper, class_5617.class_5618 context) -> {
                    if (filter.test((class_1299<E>) entityType)) {
                        registrationHelper.register(factory.apply((class_3883<T, M>) entityRenderer, context));
                    }
                });
    }
}
