package fuzs.puzzleslib.api.client.packs.v1;

import fuzs.puzzleslib.api.core.v1.context.PackRepositorySourcesContext;
import fuzs.puzzleslib.api.resources.v1.AbstractModPackResources;
import org.jetbrains.annotations.Nullable;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_1011;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3268;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_7367;

/**
 * A {@link net.minecraft.class_3262} implementation for copying existing texture resources at runtime,
 * mainly in an effort to handle changed aspect ratios in entity textures with custom models.
 * <p>
 * Generally the implementation will try to pick the same texture the vanilla pack handler would (meaning the texture
 * from the top-most pack). But if the aspect ratio of that texture doesn't match the expected ratio, the original
 * texture from {@link class_3268} will be used.
 * <p>
 * To be registered via
 * {@link
 * fuzs.puzzleslib.api.client.core.v1.ClientModConstructor#onAddResourcePackFinders(PackRepositorySourcesContext)} and
 * {@link fuzs.puzzleslib.api.resources.v1.PackResourcesHelper}.
 */
@Deprecated
public class DynamicallyCopiedPackResources extends AbstractModPackResources {
    private final class_3300 resourceManager;
    private final class_3268 vanillaPackResources;
    private final Map<class_2960, TextureCopy> textures;

    protected DynamicallyCopiedPackResources(TextureCopy... textures) {
        class_310 minecraft = class_310.method_1551();
        this.resourceManager = minecraft.method_1478();
        this.vanillaPackResources = minecraft.method_45573();
        this.textures = Stream.of(textures)
                .collect(Collectors.toMap(TextureCopy::destinationLocation, Function.identity()));
    }

    @Nullable
    @Override
    public class_7367<InputStream> method_14405(class_3264 packType, class_2960 resourceLocation) {
        if (this.textures.containsKey(resourceLocation)) {
            TextureCopy textureCopy = this.textures.get(resourceLocation);
            Optional<class_3298> vanillaResource = this.resourceManager.method_14486(textureCopy.vanillaLocation());
            if (vanillaResource.isPresent()) {
                try (class_1011 nativeImage = class_1011.method_4309(vanillaResource.get().method_14482())) {
                    // check the vanilla texture aspect ratio; some mods using OptiFine change the texture file completely since they also change the model
                    // make sure to check the aspect ratio instead of absolute width / height to support higher resolution resource packs
                    // in that case fall back to the skeleton texture from the vanilla assets pack
                    if (nativeImage.method_4307() / nativeImage.method_4323() !=
                            textureCopy.vanillaImageWidth() / textureCopy.vanillaImageHeight()) {
                        return this.vanillaPackResources.method_14405(packType, textureCopy.vanillaLocation());
                    }
                } catch (IOException exception) {
                    // NO-OP
                }
                return vanillaResource.get()::method_14482;
            }
        }

        return null;
    }

    @Override
    public Set<String> method_14406(class_3264 packType) {
        return this.textures.keySet().stream().map(class_2960::method_12836).collect(Collectors.toSet());
    }

    /**
     * Provides a mod pack resources supplier for the defined data.
     *
     * @param textures texture copy data
     * @return mod pack resources supplier
     */
    public static Supplier<AbstractModPackResources> create(TextureCopy... textures) {
        return () -> {
            return new DynamicallyCopiedPackResources(textures);
        };
    }

    /**
     * Data class for texture copy information.
     *
     * @param vanillaLocation     location of the vanilla texture to copy from
     * @param destinationLocation location to copy to which will be used by the mod
     * @param vanillaImageWidth   width of the vanilla texture, might no longer match when overriden via resource packs
     * @param vanillaImageHeight  height of the vanilla texture, might no longer match when overriden via resource
     *                            packs
     */
    public record TextureCopy(class_2960 vanillaLocation,
                              class_2960 destinationLocation,
                              int vanillaImageWidth,
                              int vanillaImageHeight) {

        public TextureCopy {
            if (vanillaLocation.method_12836().equals(destinationLocation.method_12836())) {
                throw new IllegalStateException("%s and %s share same namespace".formatted(vanillaLocation,
                        destinationLocation
                ));
            }
            if (!vanillaLocation.method_12832().endsWith(".png")) {
                throw new IllegalArgumentException("%s is no texture location".formatted(vanillaLocation));
            }
            if (!destinationLocation.method_12832().endsWith(".png")) {
                throw new IllegalArgumentException("%s is no texture location".formatted(destinationLocation));
            }
        }
    }
}
