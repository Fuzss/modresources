package fuzs.puzzleslib.api.client.particle.v1;

import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_638;
import net.minecraft.class_703;
import org.jetbrains.annotations.Nullable;

/**
 * A helper class for particle related methods found in {@link net.minecraft.class_638} returning
 * the created particle. Particles will be spawned when a {@link net.minecraft.class_638} is
 * provided.
 */
@Deprecated
public final class ClientParticleHelper {

    private ClientParticleHelper() {
        // NO-OP
    }

    /**
     * Copied from
     * {@link net.minecraft.class_638#method_8406(class_2394, double, double, double, double,
     * double, double)}.
     */
    @Nullable
    public static class_703 addParticle(class_1937 level, class_2394 particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return level.field_9236 ?
                fuzs.puzzleslib.api.client.util.v1.ClientParticleHelper.addParticle((class_638) level,
                        particleData,
                        x,
                        y,
                        z,
                        xSpeed,
                        ySpeed,
                        zSpeed) : null;
    }

    /**
     * Copied from
     * {@link net.minecraft.class_638#method_8466(class_2394, boolean, double, double, double,
     * double, double, double)}.
     */
    @Nullable
    public static class_703 addParticle(class_1937 level, class_2394 particleData, boolean forceAlwaysRender, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return level.field_9236 ?
                fuzs.puzzleslib.api.client.util.v1.ClientParticleHelper.addParticle((class_638) level,
                        particleData,
                        forceAlwaysRender,
                        x,
                        y,
                        z,
                        xSpeed,
                        ySpeed,
                        zSpeed) : null;
    }

    /**
     * Copied from
     * {@link net.minecraft.class_638#method_8494(class_2394, double, double,
     * double, double, double, double)}.
     */
    @Nullable
    public static class_703 addAlwaysVisibleParticle(class_1937 level, class_2394 particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return level.field_9236 ?
                fuzs.puzzleslib.api.client.util.v1.ClientParticleHelper.addParticle((class_638) level,
                        particleData,
                        x,
                        y,
                        z,
                        xSpeed,
                        ySpeed,
                        zSpeed) : null;
    }

    /**
     * Copied from
     * {@link net.minecraft.class_638#method_17452(class_2394, boolean, double,
     * double, double, double, double, double)}.
     */
    @Nullable
    public static class_703 addAlwaysVisibleParticle(class_1937 level, class_2394 particleData, boolean ignoreRange, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return level.field_9236 ?
                fuzs.puzzleslib.api.client.util.v1.ClientParticleHelper.addParticle((class_638) level,
                        particleData,
                        ignoreRange,
                        x,
                        y,
                        z,
                        xSpeed,
                        ySpeed,
                        zSpeed) : null;
    }

    /**
     * Copied from
     * {@link net.minecraft.class_761#method_8563(class_2394, boolean, boolean, double, double,
     * double, double, double, double)}.
     */
    @Nullable
    public static class_703 addParticle(class_1937 level, class_2394 options, boolean force, boolean decreased, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return level.field_9236 ?
                fuzs.puzzleslib.api.client.util.v1.ClientParticleHelper.addParticle((class_638) level,
                        options,
                        force,
                        decreased,
                        x,
                        y,
                        z,
                        xSpeed,
                        ySpeed,
                        zSpeed) : null;
    }
}
