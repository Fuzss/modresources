package fuzs.puzzleslib.api.entity.v1;

import fuzs.puzzleslib.api.core.v1.CommonAbstractions;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1927;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2664;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_5362;
import net.minecraft.class_6880;
import org.jetbrains.annotations.Nullable;

/**
 * A helper class containing a bunch of {@link class_1927} related methods from {@link class_1937}.
 * <p>
 * The methods additionally to the explosion parameters take an {@link ExplosionFactory}, for providing a custom
 * implementation of {@link class_1927}.
 */
@Deprecated
public final class GenericExplosionHelper {

    private GenericExplosionHelper() {
        // NO-OP
    }

    /**
     * Creates and explodes an {@link class_1927} in a level.
     *
     * @param factory              provider for a custom {@link class_1927} implementation
     * @param level                the level the explosion is happening in
     * @param source               an entity that has caused the explosion, like a creeper, end crystal, or primed tnt,
     *                             or null when caused by a block like a bed
     * @param x                    explosion x-position
     * @param y                    explosion y-position
     * @param z                    explosion z-position
     * @param radius               explosion radius
     * @param explosionInteraction should the explosion destroy terrain and should destroyed blocks be dropped
     * @return the already exploded explosion instance
     */
    public static <T extends class_1927> T explode(ExplosionFactory<T> factory, class_1937 level, @Nullable class_1297 source, double x, double y, double z, float radius, class_1937.class_7867 explosionInteraction) {
        return explode(factory,
                level,
                source,
                class_1927.method_55108(level, source),
                null,
                x,
                y,
                z,
                radius,
                false,
                explosionInteraction,
                class_2398.field_11236,
                class_2398.field_11221,
                class_3417.field_15152
        );
    }

    /**
     * Creates and explodes an {@link class_1927} in a level.
     *
     * @param factory                 provider for a custom {@link class_1927} implementation
     * @param level                   the level the explosion is happening in
     * @param source                  an entity that has caused the explosion, like a creeper, end crystal, or primed
     *                                tnt, or null when caused by a block like a bed
     * @param damageSource            the damage source for hurting hit entities, will fall back to
     *                                {@link class_1927#method_55108(class_1937, class_1297)}
     * @param damageCalculator        the damage calculator, can selectively filter out entities, mainly used to allow
     *                                wind charges to not damage terrain nor entities
     * @param x                       explosion x-position
     * @param y                       explosion y-position
     * @param z                       explosion z-position
     * @param radius                  explosion radius
     * @param fire                    should the explosion spawn fire blocks in the explosion radius, used by explosion
     *                                from fireballs
     * @param explosionInteraction    should the explosion destroy terrain and should destroyed blocks be dropped
     * @param smallExplosionParticles explosion particles, usually {@link class_2398#field_11236}
     * @param largeExplosionParticles explosion particles, usually {@link class_2398#field_11221}
     * @param explosionSound          explosion particles, usually {@link class_3417#field_15152}
     * @return the already exploded explosion instance
     */
    public static <T extends class_1927> T explode(ExplosionFactory<T> factory, class_1937 level, @Nullable class_1297 source, @Nullable class_1282 damageSource, @Nullable class_5362 damageCalculator, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction, class_2394 smallExplosionParticles, class_2394 largeExplosionParticles, class_6880<class_3414> explosionSound) {
        T explosion = explode(factory,
                level,
                source,
                damageSource,
                damageCalculator,
                x,
                y,
                z,
                radius,
                fire,
                explosionInteraction,
                level.field_9236,
                smallExplosionParticles,
                largeExplosionParticles,
                explosionSound
        );

        if (!level.field_9236) {

            if (!explosion.method_46667()) {
                explosion.method_8352();
            }

            for (class_3222 serverplayer : ((class_3218) level).method_18456()) {
                if (serverplayer.method_5649(x, y, z) < 4096.0) {
                    serverplayer.field_13987.method_14364(new class_2664(x,
                            y,
                            z,
                            radius,
                            explosion.method_8346(),
                            explosion.method_8351().get(serverplayer),
                            explosion.method_55111(),
                            explosion.method_55112(),
                            explosion.method_55113(),
                            explosion.method_55114()
                    ));
                }
            }
        }

        return explosion;
    }

    private static <T extends class_1927> T explode(ExplosionFactory<T> factory, class_1937 level, @Nullable class_1297 source, @Nullable class_1282 damageSource, @Nullable class_5362 damageCalculator, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction, boolean spawnParticles, class_2394 smallExplosionParticles, class_2394 largeExplosionParticles, class_6880<class_3414> explosionSound) {
        T explosion = factory.create(level,
                source,
                damageSource,
                damageCalculator,
                x,
                y,
                z,
                radius,
                fire,
                getBlockInteraction(level, source, explosionInteraction),
                smallExplosionParticles,
                largeExplosionParticles,
                explosionSound
        );
        if (CommonAbstractions.INSTANCE.onExplosionStart(level, explosion)) {
            return explosion;
        } else {
            explosion.method_8348();
            explosion.method_8350(spawnParticles);
            return explosion;
        }
    }

    private static class_1927.class_4179 getBlockInteraction(class_1937 level, @Nullable class_1297 source, class_1937.class_7867 explosionInteraction) {
        return switch (explosionInteraction) {
            case field_40888 -> class_1927.class_4179.field_40878;
            case field_40889 -> getDestroyType(level.method_8450(), class_1928.field_40880);
            case field_40890 -> CommonAbstractions.INSTANCE.getMobGriefingRule(level, source) ?
                    getDestroyType(level.method_8450(), class_1928.field_40881) :
                    class_1927.class_4179.field_40878;
            case field_40891 -> getDestroyType(level.method_8450(), class_1928.field_40882);
            case field_51779 -> class_1927.class_4179.field_47331;
        };
    }

    private static class_1927.class_4179 getDestroyType(class_1928 gameRules, class_1928.class_4313<class_1928.class_4310> gameRule) {
        return gameRules.method_8355(gameRule) ?
                class_1927.class_4179.field_40879 :
                class_1927.class_4179.field_18687;
    }

    /**
     * Creates and explodes an {@link class_1927} in a level.
     *
     * @param factory              provider for a custom {@link class_1927} implementation
     * @param level                the level the explosion is happening in
     * @param source               an entity that has caused the explosion, like a creeper, end crystal, or primed tnt,
     *                             or null when caused by a block like a bed
     * @param x                    explosion x-position
     * @param y                    explosion y-position
     * @param z                    explosion z-position
     * @param radius               explosion radius
     * @param fire                 should the explosion spawn fire blocks in the explosion radius, used by explosion
     *                             from fireballs
     * @param explosionInteraction should the explosion destroy terrain and should destroyed blocks be dropped
     * @return the already exploded explosion instance
     */
    public static <T extends class_1927> T explode(ExplosionFactory<T> factory, class_1937 level, @Nullable class_1297 source, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction) {
        return explode(factory,
                level,
                source,
                class_1927.method_55108(level, source),
                null,
                x,
                y,
                z,
                radius,
                fire,
                explosionInteraction,
                class_2398.field_11236,
                class_2398.field_11221,
                class_3417.field_15152
        );
    }

    /**
     * Creates and explodes an {@link class_1927} in a level.
     *
     * @param factory              provider for a custom {@link class_1927} implementation
     * @param level                the level the explosion is happening in
     * @param source               an entity that has caused the explosion, like a creeper, end crystal, or primed tnt,
     *                             or null when caused by a block like a bed
     * @param damageSource         the damage source for hurting hit entities, will fall back to
     *                             {@link class_1927#method_55108(class_1937, class_1297)}
     * @param damageCalculator     the damage calculator, can selectively filter out entities, mainly used to allow wind
     *                             charges to not damage terrain nor entities
     * @param pos                  explosion position
     * @param radius               explosion radius
     * @param fire                 should the explosion spawn fire blocks in the explosion radius, used by explosion
     *                             from fireballs
     * @param explosionInteraction should the explosion destroy terrain and should destroyed blocks be dropped
     * @return the already exploded explosion instance
     */
    public static <T extends class_1927> T explode(ExplosionFactory<T> factory, class_1937 level, @Nullable class_1297 source, @Nullable class_1282 damageSource, @Nullable class_5362 damageCalculator, class_243 pos, float radius, boolean fire, class_1937.class_7867 explosionInteraction) {
        return explode(factory,
                level,
                source,
                damageSource,
                damageCalculator,
                pos.method_10216(),
                pos.method_10214(),
                pos.method_10215(),
                radius,
                fire,
                explosionInteraction,
                class_2398.field_11236,
                class_2398.field_11221,
                class_3417.field_15152
        );
    }

    /**
     * Creates and explodes an {@link class_1927} in a level.
     *
     * @param factory              provider for a custom {@link class_1927} implementation
     * @param level                the level the explosion is happening in
     * @param source               an entity that has caused the explosion, like a creeper, end crystal, or primed tnt,
     *                             or null when caused by a block like a bed
     * @param damageSource         the damage source for hurting hit entities, will fall back to
     *                             {@link class_1927#method_55108(class_1937, class_1297)}
     * @param damageCalculator     the damage calculator, can selectively filter out entities, mainly used to allow wind
     *                             charges to not damage terrain nor entities
     * @param x                    explosion x-position
     * @param y                    explosion y-position
     * @param z                    explosion z-position
     * @param radius               explosion radius
     * @param fire                 should the explosion spawn fire blocks in the explosion radius, used by explosion
     *                             from fireballs
     * @param explosionInteraction should the explosion destroy terrain and should destroyed blocks be dropped
     * @return the already exploded explosion instance
     */
    public static <T extends class_1927> T explode(ExplosionFactory<T> factory, class_1937 level, @Nullable class_1297 source, @Nullable class_1282 damageSource, @Nullable class_5362 damageCalculator, double x, double y, double z, float radius, boolean fire, class_1937.class_7867 explosionInteraction) {
        return explode(factory,
                level,
                source,
                damageSource,
                damageCalculator,
                x,
                y,
                z,
                radius,
                fire,
                explosionInteraction,
                class_2398.field_11236,
                class_2398.field_11221,
                class_3417.field_15152
        );
    }

    /**
     * A simple reference for an {@link class_1927} constructor.
     */
    @FunctionalInterface
    public interface ExplosionFactory<T extends class_1927> {

        /**
         * Creates a custom {@link class_1927} implementation.
         *
         * @param level                   the level the explosion is happening in
         * @param source                  an entity that has caused the explosion, like a creeper, end crystal, or
         *                                primed tnt, or null when caused by a block like a bed
         * @param damageSource            the damage source for hurting hit entities, will fall back to
         *                                {@link class_1927#method_55108(class_1937, class_1297)}
         * @param damageCalculator        the damage calculator, can selectively filter out entities, mainly used to
         *                                allow wind charges to not damage terrain nor entities
         * @param x                       explosion x-position
         * @param y                       explosion y-position
         * @param z                       explosion z-position
         * @param radius                  explosion radius
         * @param fire                    should the explosion spawn fire blocks in the explosion radius, used by
         *                                explosion from fireballs
         * @param blockInteraction        should the explosion destroy terrain and should destroyed blocks be dropped
         * @param smallExplosionParticles explosion particles, usually {@link class_2398#field_11236}
         * @param largeExplosionParticles explosion particles, usually {@link class_2398#field_11221}
         * @param explosionSound          explosion particles, usually {@link class_3417#field_15152}
         * @return the created explosion instance
         */
        T create(class_1937 level, @Nullable class_1297 source, @Nullable class_1282 damageSource, @Nullable class_5362 damageCalculator, double x, double y, double z, float radius, boolean fire, class_1927.class_4179 blockInteraction, class_2394 smallExplosionParticles, class_2394 largeExplosionParticles, class_6880<class_3414> explosionSound);
    }
}
