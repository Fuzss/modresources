package fuzs.puzzleslib.api.event.v1.entity.player;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

@FunctionalInterface
public interface AfterChangeDimensionCallback {
    EventInvoker<AfterChangeDimensionCallback> EVENT = EventInvoker.lookup(AfterChangeDimensionCallback.class);

    /**
     * Called after a player has been moved to different world.
     *
     * @param player the player
     * @param from   the original world the player was in
     * @param to     the new world the player was moved to
     */
    void onAfterChangeDimension(class_3222 player, class_3218 from, class_3218 to);
}
