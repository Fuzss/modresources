package fuzs.puzzleslib.api.config.v3.serialization;

import fuzs.puzzleslib.api.data.v2.tags.AbstractTagAppender;
import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.api.init.v3.registry.RegistryHelper;
import fuzs.puzzleslib.impl.config.serialization.EnumProvider;
import fuzs.puzzleslib.impl.config.serialization.RegistryProvider;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import fuzs.puzzleslib.impl.data.SortingTagBuilder;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3495;
import net.minecraft.class_5321;

/**
 * A collection of certain values, usually backed by something like a {@link class_2378}.
 *
 * @param <T> the type of value
 */
public interface KeyedValueProvider<T> {

    /**
     * Create a new provider backed by a registry.
     *
     * @param registryKey key for retrieving backing registry
     * @param <T>         the type of value
     * @return the provider
     */
    static <T> KeyedValueProvider<T> registryEntries(class_5321<? extends class_2378<? super T>> registryKey) {
        return new RegistryProvider<>(registryKey);
    }

    /**
     * Create a new provider backed by a registry.
     *
     * @param enumClazz class for retrieving enum constants
     * @param <T>       the type of value
     * @return the provider
     */
    static <T extends Enum<T>> KeyedValueProvider<T> enumConstants(Class<T> enumClazz) {
        return enumConstants(enumClazz, "minecraft");
    }

    /**
     * Create a new provider backed by a registry.
     *
     * @param enumClazz class for retrieving enum constants
     * @param modId     namespace for resource locations
     * @param <T>       the type of value
     * @return the provider
     */
    static <T extends Enum<T>> KeyedValueProvider<T> enumConstants(Class<T> enumClazz, String modId) {
        return new EnumProvider<>(enumClazz, modId);
    }

    /**
     * Converts a bunch of entries from a registry to their respective key as string.
     *
     * @param registryKey registry to get entry keys from
     * @param entries     entries to convert to string
     * @param <T>         type of value
     * @return entries as string list
     */
    @SafeVarargs
    static <T> List<String> toString(class_5321<? extends class_2378<? super T>> registryKey, T... entries) {
        return toString(KeyedValueProvider.registryEntries(registryKey), entries);
    }

    /**
     * Creates an {@link AbstractTagAppender} instance that can be converted to a string list by calling
     * {@link AbstractTagAppender#asStringList()}.
     *
     * @param registryKey the registry to get entry keys from
     * @param <T>         the type of values
     * @return the tag appender
     */
    @Deprecated
    static <T> AbstractTagAppender<T> tagAppender(class_5321<? extends class_2378<? super T>> registryKey) {
        class_2378<T> registry = RegistryHelper.findNullableBuiltInRegistry(registryKey);
        Function<T, class_5321<T>> keyExtractor =
                registry != null ? (T t) -> RegistryHelper.getResourceKeyOrThrow(registry, t) : null;
        return ProxyImpl.get().getTagAppenderV2(new SortingTagBuilder(), keyExtractor);
    }

    /**
     * Creates an {@link AbstractTagAppender} instance that can be converted to a string list by calling
     * {@link AbstractTagAppender#asStringList()}.
     *
     * @param registryKey the registry to get entry keys from
     * @param <T>         the type of values
     * @return the tag appender
     */
    static <T> fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tags(class_5321<? extends class_2378<? super T>> registryKey) {
        return tags(new SortingTagBuilder(), registryKey);
    }

    /**
     * Creates an {@link AbstractTagAppender} instance that can be converted to a string list by calling
     * {@link AbstractTagAppender#asStringList()}.
     *
     * @param tagBuilder  the tag builder
     * @param registryKey the registry to get entry keys from
     * @param <T>         the type of values
     * @return the tag appender
     */
    static <T> fuzs.puzzleslib.api.data.v3.tags.AbstractTagAppender<T> tags(class_3495 tagBuilder, class_5321<? extends class_2378<? super T>> registryKey) {
        Optional<class_2378<T>> optional = LookupHelper.getRegistry(registryKey);
        Function<T, class_5321<T>> keyExtractor = optional.isPresent() ?
                (T t) -> optional.flatMap((class_2378<T> registry) -> registry.method_29113(t)).orElseThrow(() -> {
                    return new IllegalStateException("Missing value in " + registryKey + ": " + t);
                }) : null;
        return ProxyImpl.get().getTagAppenderV3(tagBuilder, keyExtractor);
    }

    /**
     * Converts a bunch of enum constants to their respective key as string.
     *
     * @param enumClazz class for retrieving enum constants
     * @param entries   entries to convert to string
     * @param <T>       type of value
     * @return entries as string list
     */
    @SafeVarargs
    static <T extends Enum<T>> List<String> toString(Class<T> enumClazz, T... entries) {
        return toString(enumClazz, "minecraft", entries);
    }

    /**
     * Converts a bunch of enum constants to their respective key as string.
     *
     * @param enumClazz class for retrieving enum constants
     * @param modId     namespace for resource locations
     * @param entries   entries to convert to string
     * @param <T>       type of value
     * @return entries as string list
     */
    @SafeVarargs
    static <T extends Enum<T>> List<String> toString(Class<T> enumClazz, String modId, T... entries) {
        return toString(KeyedValueProvider.enumConstants(enumClazz, modId), entries);
    }

    /**
     * Converts a bunch of entries to their respective key as string via a {@link KeyedValueProvider}.
     *
     * @param valueProvider provider instance
     * @param entries       entries to convert to string
     * @param <T>           type of value
     * @return entries as string list
     */
    @SafeVarargs
    static <T> List<String> toString(KeyedValueProvider<T> valueProvider, T... entries) {
        return Stream.of(entries)
                .peek(Objects::requireNonNull)
                .map(valueProvider::getKey)
                .filter(Objects::nonNull)
                .map(class_2960::toString)
                .collect(Collectors.toList());
    }

    /**
     * Get a value via the provider.
     *
     * @param name registered identifier
     * @return the value corresponding to the identifier
     */
    Optional<T> getValue(class_2960 name);

    /**
     * Get am identifier via the provider.
     *
     * @param value registered value
     * @return the identifier corresponding to the value
     */
    class_2960 getKey(T value);

    /**
     * Stream of all values paired with identifier available through this provider.
     *
     * @return all values including corresponding identifier
     */
    Stream<Map.Entry<class_2960, T>> stream();

    /**
     * Stream of all values available through this provider.
     *
     * @return all values
     */
    Stream<T> streamValues();

    /**
     * Name of this provider, mainly used for debugging purposes.
     *
     * @return provider name
     */
    String name();
}
