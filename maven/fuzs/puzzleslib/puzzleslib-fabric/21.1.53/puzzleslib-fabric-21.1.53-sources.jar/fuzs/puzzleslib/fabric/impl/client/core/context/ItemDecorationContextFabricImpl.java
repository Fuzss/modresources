package fuzs.puzzleslib.fabric.impl.client.core.context;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.client.core.v1.context.ItemDecorationContext;
import fuzs.puzzleslib.fabric.api.client.event.v1.registry.ItemDecoratorRegistry;
import fuzs.puzzleslib.api.client.init.v1.DynamicItemDecorator;
import java.util.Objects;
import net.minecraft.class_1935;

public final class ItemDecorationContextFabricImpl implements ItemDecorationContext {

    @Override
    public void registerItemDecorator(DynamicItemDecorator decorator, class_1935... items) {
        Objects.requireNonNull(decorator, "decorator is null");
        Objects.requireNonNull(items, "items is null");
        Preconditions.checkState(items.length > 0, "items is empty");
        for (class_1935 item : items) {
            Objects.requireNonNull(item, "item is null");
            ItemDecoratorRegistry.INSTANCE.register(item, decorator);
        }
    }
}
