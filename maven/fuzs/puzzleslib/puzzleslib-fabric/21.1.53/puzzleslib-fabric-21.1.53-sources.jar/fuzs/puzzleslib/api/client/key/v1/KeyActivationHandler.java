package fuzs.puzzleslib.api.client.key.v1;

import fuzs.puzzleslib.impl.client.key.KeyActivationHandlerImpl;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_310;
import net.minecraft.class_437;

/**
 * A storage class for handling activated key mappings for different types of {@link KeyActivationContext}.
 */
@FunctionalInterface
public interface KeyActivationHandler {

    /**
     * A basic activation handler from an activation context that does not register any events.
     *
     * @param activationContext activation context
     * @return activation handler
     */
    static KeyActivationHandler direct(KeyActivationContext activationContext) {
        return () -> activationContext;
    }

    /**
     * An activation handler in builder-like format.
     *
     * @return activation handler
     */
    static KeyActivationHandler of() {
        return new KeyActivationHandlerImpl(null, null, null);
    }

    /**
     * An activation handler for {@link KeyActivationContext#GAME}.
     *
     * @param gameHandler handler for processing the key press at the beginning of each client tick
     * @return activation handler
     */
    static KeyActivationHandler forGame(Consumer<class_310> gameHandler) {
        Objects.requireNonNull(gameHandler, "game handler is null");
        return new KeyActivationHandlerImpl(gameHandler, null, null);
    }

    /**
     * An activation handler for {@link KeyActivationContext#SCREEN}.
     *
     * @param screenHandler handler for processing the key press in {@link class_437#method_25404(int, int, int)}
     * @return activation handler
     */
    static KeyActivationHandler forScreen(Consumer<class_437> screenHandler) {
        return forScreen(class_437.class, screenHandler);
    }

    /**
     * An activation handler for {@link KeyActivationContext#SCREEN}.
     *
     * @param screenType    screen super type to register the screen handler for
     * @param screenHandler handler for processing the key press in {@link class_437#method_25404(int, int, int)}
     * @param <T>           screen super type
     * @return activation handler
     */
    static <T extends class_437> KeyActivationHandler forScreen(Class<T> screenType, Consumer<T> screenHandler) {
        Objects.requireNonNull(screenType, "screen type is null");
        Objects.requireNonNull(screenHandler, "screen handler is null");
        return new KeyActivationHandlerImpl(null, screenType, screenHandler);
    }

    /**
     * @return activation context based on what handlers are present
     */
    KeyActivationContext getActivationContext();

    /**
     * @return handler for processing the key press at the beginning of each client tick
     */
    @Nullable
    default Consumer<class_310> gameHandler() {
        return null;
    }

    /**
     * @return screen super type to register the screen handler for
     */
    @Nullable
    default Class<? extends class_437> screenType() {
        return null;
    }

    /**
     * @return handler for processing the key press in {@link class_437#method_25404(int, int, int)}
     */
    @Nullable
    default Consumer<? extends class_437> screenHandler() {
        return null;
    }

    /**
     * @param gameHandler handler for processing the key press at the beginning of each client tick
     * @return builder instance
     */
    default KeyActivationHandler withGameHandler(Consumer<class_310> gameHandler) {
        return this;
    }

    /**
     * @param screenHandler handler for processing the key press in {@link class_437#method_25404(int, int, int)}
     * @return builder instance
     */
    default KeyActivationHandler withScreenHandler(Consumer<class_437> screenHandler) {
        return this.withScreenHandler(class_437.class, screenHandler);
    }

    /**
     * @param screenType    screen super type to register the screen handler for
     * @param screenHandler handler for processing the key press in {@link class_437#method_25404(int, int, int)}
     * @param <T>           screen super type
     * @return builder instance
     */
    default <T extends class_437> KeyActivationHandler withScreenHandler(Class<T> screenType, Consumer<T> screenHandler) {
        return this;
    }
}
