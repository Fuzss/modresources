package fuzs.puzzleslib.api.client.data.v2.models;

import net.minecraft.class_2960;
import net.minecraft.class_4730;

public record MaterialMapper(class_2960 sheet, String prefix) {
    public class_4730 apply(class_2960 name) {
        return new class_4730(this.sheet, name.method_45138(this.prefix + "/"));
    }

    public class_4730 defaultNamespaceApply(String name) {
        return this.apply(class_2960.method_60656(name));
    }
}
