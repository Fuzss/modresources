package fuzs.puzzleslib.fabric.impl.client.event;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.client.event.v1.*;
import fuzs.puzzleslib.api.client.event.v1.entity.ClientEntityLevelEvents;
import fuzs.puzzleslib.api.client.event.v1.entity.player.*;
import fuzs.puzzleslib.api.client.event.v1.gui.*;
import fuzs.puzzleslib.api.client.event.v1.level.ClientChunkEvents;
import fuzs.puzzleslib.api.client.event.v1.level.ClientLevelEvents;
import fuzs.puzzleslib.api.client.event.v1.level.ClientLevelTickEvents;
import fuzs.puzzleslib.api.client.event.v1.renderer.*;
import fuzs.puzzleslib.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.fabric.api.client.event.v1.*;
import fuzs.puzzleslib.fabric.api.core.v1.resources.FabricReloadListener;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLifecycleEvents;
import fuzs.puzzleslib.impl.client.event.ModelLoadingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelModifier;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelResolver;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockApplyCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPickBlockGatherCallback;
import net.fabricmc.fabric.api.event.client.player.ClientPreAttackCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.class_1086;
import net.minecraft.class_1087;
import net.minecraft.class_1088;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_239;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3264;
import net.minecraft.class_3302;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_437;
import net.minecraft.class_5617;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_922;
import net.minecraft.class_9779;
import net.minecraft.client.resources.model.*;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;

import static fuzs.puzzleslib.fabric.api.event.v1.core.FabricEventInvokerRegistry.INSTANCE;

@SuppressWarnings("unchecked")
public final class FabricClientEventInvokers {
    // a custom item stack used for identity matching to be able to cancel our pick block event
    private static final class_1799 INTERRUPT_PICK_ITEM_STACK = new class_1799(class_1802.field_20391);

    static {
        ClientPickBlockApplyCallback.EVENT.register((class_1657 player, class_239 result, class_1799 stack) -> {
            // match via reference identity so this can only be our dummy stack
            return stack == INTERRUPT_PICK_ITEM_STACK ? class_1799.field_8037 : stack;
        });
    }

    public static void registerLoadingHandlers() {
        INSTANCE.register(AddResourcePackReloadListenersCallback.class,
                FabricLifecycleEvents.LOAD_COMPLETE,
                callback -> {
                    return () -> {
                        callback.onAddResourcePackReloadListeners((class_2960 resourceLocation, class_3302 reloadListener) -> {
                            ResourceManagerHelper.get(class_3264.field_14188)
                                    .registerReloadListener(new FabricReloadListener(resourceLocation, reloadListener));
                        });
                    };
                });
        INSTANCE.register(ScreenOpeningCallback.class, FabricGuiEvents.SCREEN_OPENING);
        INSTANCE.register(ModelEvents.ModifyUnbakedModel.class,
                (ModelEvents.ModifyUnbakedModel callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        Map<class_2960, class_1100> additionalModels = Maps.newHashMap();
                        pluginContext.modifyModelBeforeBake()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (class_1100 model, ModelModifier.BeforeBake.Context context) -> {
                                            // no need to include additional models in the model getter like on Forge, this is done automatically on Fabric via the model resolving callback
                                            if (context.topLevelId() != null) {
                                                EventResultHolder<class_1100> result = callback.onModifyUnbakedModel(
                                                        context.topLevelId(),
                                                        () -> model,
                                                        ModelLoadingHelper.getUnbakedTopLevelModel(context.loader()),
                                                        additionalModels::put);
                                                return result.getInterrupt().orElse(model);
                                            } else {
                                                return model;
                                            }
                                        });
                        pluginContext.resolveModel().register((ModelResolver.Context context) -> {
                            return additionalModels.get(context.id());
                        });
                    });
                });
        INSTANCE.register(ModelEvents.ModifyBakedModel.class,
                (ModelEvents.ModifyBakedModel callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyModelAfterBake()
                                .register(ModelModifier.OVERRIDE_PHASE,
                                        (@Nullable class_1087 model, ModelModifier.AfterBake.Context context) -> {
                                            if (model != null) {
                                                Map<class_1091, class_1087> models = context.loader()
                                                        .method_4734();
                                                EventResultHolder<class_1087> result = callback.onModifyBakedModel(
                                                        context.topLevelId(),
                                                        () -> model,
                                                        context::baker,
                                                        (class_1091 resourceLocation) -> {
                                                            return models.containsKey(resourceLocation) ?
                                                                    models.get(resourceLocation) : context.baker()
                                                                    .method_45873(resourceLocation.comp_2875(),
                                                                            class_1086.field_5350);
                                                        },
                                                        models::putIfAbsent);
                                                return result.getInterrupt().orElse(model);
                                            } else {
                                                return null;
                                            }
                                        });
                    });
                });
        INSTANCE.register(ModelEvents.AddAdditionalBakedModel.class,
                (ModelEvents.AddAdditionalBakedModel callback, @Nullable Object o) -> {
                    ModelLoadingPlugin.register((ModelLoadingPlugin.Context pluginContext) -> {
                        pluginContext.modifyModelAfterBake()
                                .register((@Nullable class_1087 model, ModelModifier.AfterBake.Context context) -> {
                                    // all we want is access to the top level baked models map to be able to insert our own models
                                    // since the missing model is guaranteed to be baked at some point hijack the event to get to the map
                                    if (context.topLevelId().equals(class_1088.field_52276)) {
                                        Map<class_1091, class_1087> models = context.loader()
                                                .method_4734();
                                        // using the baker from the context will print the wrong model for missing textures (missing model), but that's how it is
                                        callback.onAddAdditionalBakedModel(models::putIfAbsent,
                                                (class_1091 resourceLocation) -> {
                                                    return models.containsKey(resourceLocation) ?
                                                            models.get(resourceLocation) : context.baker()
                                                            .method_45873(resourceLocation.comp_2875(), class_1086.field_5350);
                                                },
                                                context::baker);
                                    }

                                    return model;
                                });
                    });
                });
        INSTANCE.register(ModelEvents.CompleteModelLoading.class, FabricClientEvents.COMPLETE_MODEL_LOADING);
        INSTANCE.register(ClientLifecycleEvents.Started.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STARTED,
                (ClientLifecycleEvents.Started callback) -> {
                    return callback::onClientStarted;
                });
        INSTANCE.register(ClientLifecycleEvents.Stopping.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents.CLIENT_STOPPING,
                (ClientLifecycleEvents.Stopping callback) -> {
                    return callback::onClientStopping;
                });
        INSTANCE.register(ClientSetupCallback.class, (ClientSetupCallback callback, @Nullable Object context) -> {
            callback.onClientSetup();
        });
        INSTANCE.register(AddLivingEntityRenderLayersCallback.class,
                LivingEntityFeatureRendererRegistrationCallback.EVENT,
                (AddLivingEntityRenderLayersCallback callback) -> {
                    return (class_1299<? extends class_1309> entityType, class_922<?, ?> entityRenderer, LivingEntityFeatureRendererRegistrationCallback.RegistrationHelper registrationHelper, class_5617.class_5618 context) -> {
                        callback.addLivingEntityRenderLayers(entityType, entityRenderer, context);
                    };
                });
    }

    public static void registerEventHandlers() {
        INSTANCE.register(ClientTickEvents.Start.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_CLIENT_TICK,
                callback -> {
                    return callback::onStartClientTick;
                });
        INSTANCE.register(ClientTickEvents.End.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK,
                callback -> {
                    return callback::onEndClientTick;
                });
        INSTANCE.register(RenderGuiCallback.class, HudRenderCallback.EVENT, callback -> {
            return (class_332 drawContext, class_9779 tickCounter) -> {
                callback.onRenderGui(class_310.method_1551(), drawContext, tickCounter);
            };
        });
        INSTANCE.register(RenderGuiEvents.Before.class, FabricGuiEvents.BEFORE_RENDER_GUI);
        INSTANCE.register(RenderGuiEvents.After.class, HudRenderCallback.EVENT, callback -> {
            return (class_332 drawContext, class_9779 tickCounter) -> {
                callback.onAfterRenderGui(class_310.method_1551().field_1705, drawContext, tickCounter);
            };
        });
        INSTANCE.register(ItemTooltipCallback.class,
                net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback.EVENT,
                callback -> {
                    return (class_1799 stack, class_1792.class_9635 tooltipContext, class_1836 context, List<class_2561> lines) -> {
                        callback.onItemTooltip(stack, lines, tooltipContext, class_310.method_1551().field_1724, context);
                    };
                });
        INSTANCE.register(RenderNameTagCallback.class, FabricRendererEvents.RENDER_NAME_TAG);
        INSTANCE.register(ContainerScreenEvents.Background.class, FabricGuiEvents.CONTAINER_SCREEN_BACKGROUND);
        INSTANCE.register(ContainerScreenEvents.Foreground.class, FabricGuiEvents.CONTAINER_SCREEN_FOREGROUND);
        INSTANCE.register(InventoryMobEffectsCallback.class, FabricGuiEvents.INVENTORY_MOB_EFFECTS);
        INSTANCE.register(ComputeFovModifierCallback.class, FabricClientPlayerEvents.COMPUTE_FOV_MODIFIER);
        INSTANCE.register(ScreenEvents.BeforeInit.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT,
                (callback, context) -> {
                    Objects.requireNonNull(context, "context is null");
                    return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (!((Class<?>) context).isInstance(screen)) return;
                        callback.onBeforeInit(minecraft,
                                screen,
                                scaledWidth,
                                scaledHeight,
                                Collections.unmodifiableList(Screens.getButtons(screen)));
                    };
                });
        INSTANCE.register(ScreenEvents.AfterInit.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT,
                (callback, context) -> {
                    Objects.requireNonNull(context, "context is null");
                    return (class_310 minecraft, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (!((Class<?>) context).isInstance(screen)) return;
                        List<class_339> widgets = Screens.getButtons(screen);
                        callback.onAfterInit(minecraft,
                                screen,
                                scaledWidth,
                                scaledHeight,
                                Collections.unmodifiableList(widgets),
                                (UnaryOperator<class_339>) (class_339 abstractWidget) -> {
                                    widgets.add(abstractWidget);
                                    return abstractWidget;
                                },
                                (Consumer<class_339>) widgets::remove);
                    };
                });
        registerScreenEvent(ScreenEvents.Remove.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.Remove.class,
                callback -> {
                    return callback::onRemove;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::remove);
        registerScreenEvent(ScreenEvents.BeforeRender.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BeforeRender.class,
                callback -> {
                    return callback::onBeforeRender;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::beforeRender);
        registerScreenEvent(ScreenEvents.AfterRender.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AfterRender.class,
                callback -> {
                    return callback::onAfterRender;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenEvents::afterRender);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseClick.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseClick.class,
                callback -> {
                    return (screen, mouseX, mouseY, button) -> {
                        return callback.onBeforeMouseClick(screen, mouseX, mouseY, button).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseClick);
        registerScreenEvent(ScreenMouseEvents.AfterMouseClick.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseClick.class,
                callback -> {
                    return callback::onAfterMouseClick;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseClick);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseRelease.class,
                callback -> {
                    return (screen, mouseX, mouseY, button) -> {
                        return callback.onBeforeMouseRelease(screen, mouseX, mouseY, button).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseRelease);
        registerScreenEvent(ScreenMouseEvents.AfterMouseRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseRelease.class,
                callback -> {
                    return callback::onAfterMouseRelease;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseRelease);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseScroll.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AllowMouseScroll.class,
                callback -> {
                    return (class_437 screen, double mouseX, double mouseY, double horizontalAmount, double verticalAmount) -> {
                        return callback.onBeforeMouseScroll(screen, mouseX, mouseY, horizontalAmount, verticalAmount)
                                .isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::allowMouseScroll);
        registerScreenEvent(ScreenMouseEvents.AfterMouseScroll.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.AfterMouseScroll.class,
                callback -> {
                    return callback::onAfterMouseScroll;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents::afterMouseScroll);
        registerScreenEvent(ScreenMouseEvents.BeforeMouseDrag.class,
                ExtraScreenMouseEvents.AllowMouseDrag.class,
                callback -> {
                    return (class_437 screen, double mouseX, double mouseY, int button, double dragX, double dragY) -> {
                        return callback.onBeforeMouseDrag(screen, mouseX, mouseY, button, dragX, dragY).isPass();
                    };
                },
                ExtraScreenMouseEvents::allowMouseDrag);
        registerScreenEvent(ScreenMouseEvents.AfterMouseDrag.class,
                ExtraScreenMouseEvents.AfterMouseDrag.class,
                callback -> {
                    return callback::onAfterMouseDrag;
                },
                ExtraScreenMouseEvents::afterMouseDrag);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyPress.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyPress.class,
                callback -> {
                    return (class_437 screen, int key, int scancode, int modifiers) -> {
                        return callback.onBeforeKeyPress(screen, key, scancode, modifiers).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyPress.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyPress.class,
                callback -> {
                    return callback::onAfterKeyPress;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyPress);
        registerScreenEvent(ScreenKeyboardEvents.BeforeKeyRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AllowKeyRelease.class,
                callback -> {
                    return (class_437 screen, int key, int scancode, int modifiers) -> {
                        return callback.onBeforeKeyRelease(screen, key, scancode, modifiers).isPass();
                    };
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::allowKeyRelease);
        registerScreenEvent(ScreenKeyboardEvents.AfterKeyRelease.class,
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents.AfterKeyRelease.class,
                callback -> {
                    return callback::onAfterKeyRelease;
                },
                net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents::afterKeyRelease);
        INSTANCE.register(RenderGuiLayerEvents.Before.class, (context, applyToInvoker, removeInvoker) -> {
            Objects.requireNonNull(context, "context is null");
            applyToInvoker.accept(FabricGuiEvents.beforeRenderGuiElement(((class_2960) context)));
        });
        INSTANCE.register(RenderGuiLayerEvents.After.class, (context, applyToInvoker, removeInvoker) -> {
            Objects.requireNonNull(context, "context is null");
            applyToInvoker.accept(FabricGuiEvents.afterRenderGuiElement(((class_2960) context)));
        });
        INSTANCE.register(CustomizeChatPanelCallback.class, FabricGuiEvents.CUSTOMIZE_CHAT_PANEL);
        INSTANCE.register(ClientEntityLevelEvents.Load.class, FabricClientEntityEvents.ENTITY_LOAD);
        INSTANCE.register(ClientEntityLevelEvents.Unload.class, ClientEntityEvents.ENTITY_UNLOAD, callback -> {
            return callback::onEntityUnload;
        });
        INSTANCE.register(InputEvents.MouseClick.class, FabricClientEvents.MOUSE_CLICK);
        INSTANCE.register(InputEvents.MouseScroll.class, FabricClientEvents.MOUSE_SCROLL);
        INSTANCE.register(InputEvents.KeyPress.class, FabricClientEvents.KEY_PRESS);
        INSTANCE.register(RenderLivingEvents.Before.class, FabricRendererEvents.BEFORE_RENDER_LIVING);
        INSTANCE.register(RenderLivingEvents.After.class, FabricRendererEvents.AFTER_RENDER_LIVING);
        INSTANCE.register(RenderPlayerEvents.Before.class, FabricRendererEvents.BEFORE_RENDER_PLAYER);
        INSTANCE.register(RenderPlayerEvents.After.class, FabricRendererEvents.AFTER_RENDER_PLAYER);
        INSTANCE.register(RenderHandEvents.MainHand.class, FabricRendererEvents.RENDER_MAIN_HAND);
        INSTANCE.register(RenderHandEvents.OffHand.class, FabricRendererEvents.RENDER_OFF_HAND);
        INSTANCE.register(ComputeCameraAnglesCallback.class, FabricRendererEvents.COMPUTE_CAMERA_ANGLES);
        INSTANCE.register(ClientLevelTickEvents.Start.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.START_WORLD_TICK,
                callback -> {
                    return (class_638 world) -> {
                        callback.onStartLevelTick(class_310.method_1551(), world);
                    };
                });
        INSTANCE.register(ClientLevelTickEvents.End.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_WORLD_TICK,
                callback -> {
                    return (class_638 world) -> {
                        callback.onEndLevelTick(class_310.method_1551(), world);
                    };
                });
        INSTANCE.register(ClientChunkEvents.Load.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_LOAD,
                callback -> {
                    return callback::onChunkLoad;
                });
        INSTANCE.register(ClientChunkEvents.Unload.class,
                net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents.CHUNK_UNLOAD,
                callback -> {
                    return callback::onChunkUnload;
                });
        INSTANCE.register(ClientPlayerNetworkEvents.LoggedIn.class, FabricClientPlayerEvents.PLAYER_LOGGED_IN);
        INSTANCE.register(ClientPlayerNetworkEvents.LoggedOut.class, FabricClientPlayerEvents.PLAYER_LOGGED_OUT);
        INSTANCE.register(ClientPlayerCopyCallback.class, FabricClientPlayerEvents.PLAYER_COPY);
        INSTANCE.register(InteractionInputEvents.Attack.class, ClientPreAttackCallback.EVENT, callback -> {
            return (class_310 minecraft, class_746 player, int clickCount) -> {
                if (minecraft.field_1771 <= 0 && minecraft.field_1765 != null) {
                    if (clickCount != 0) {
                        if (!player.method_3144()) {
                            class_1799 itemInHand = player.method_5998(class_1268.field_5808);
                            if (itemInHand.method_45435(minecraft.field_1687.method_45162())) {
                                return callback.onAttackInteraction(minecraft, player, minecraft.field_1765)
                                        .isInterrupt();
                            }
                        }
                    } else {
                        if (!player.method_6115() && minecraft.field_1765.method_17783() == class_239.class_240.field_1332) {
                            if (!minecraft.field_1687.method_22347(((class_3965) minecraft.field_1765).method_17777())) {
                                return callback.onAttackInteraction(minecraft, player, minecraft.field_1765)
                                        .isInterrupt();
                            }
                        }
                    }
                }
                return false;
            };
        });
        INSTANCE.register(InteractionInputEvents.Use.class, UseBlockCallback.EVENT, (callback, context) -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_3965 hitResult) -> {
                // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                if (!level.field_9236) return class_1269.field_5811;
                class_310 minecraft = class_310.method_1551();
                EventResult result = callback.onUseInteraction(minecraft,
                        (class_746) player,
                        hand,
                        minecraft.field_1765);
                // when interrupted cancel the interaction without the server being notified
                return result.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
            };
        }, EventPhase::early, true);
        INSTANCE.register(InteractionInputEvents.Use.class, UseEntityCallback.EVENT, (callback, context) -> {
            return (class_1657 player, class_1937 level, class_1268 hand, class_1297 entity, @Nullable class_3966 hitResult) -> {
                // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                if (!level.field_9236) return class_1269.field_5811;
                class_310 minecraft = class_310.method_1551();
                EventResult result = callback.onUseInteraction(minecraft,
                        (class_746) player,
                        hand,
                        minecraft.field_1765);
                // when interrupted cancel the interaction without the server being notified
                return result.isInterrupt() ? class_1269.field_5814 : class_1269.field_5811;
            };
        }, EventPhase::early, true);
        INSTANCE.register(InteractionInputEvents.Use.class, UseItemCallback.EVENT, (callback, context) -> {
            return (class_1657 player, class_1937 level, class_1268 hand) -> {
                // this is only fired client-side to mimic InputEvent$InteractionKeyMappingTriggered on Forge
                // proper handling of the Fabric callback with the server-side component is implemented elsewhere
                if (!level.field_9236) return class_1271.method_22430(class_1799.field_8037);
                class_310 minecraft = class_310.method_1551();
                EventResult result = callback.onUseInteraction(minecraft,
                        (class_746) player,
                        hand,
                        minecraft.field_1765);
                // when interrupted cancel the interaction without the server being notified
                return result.isInterrupt() ? class_1271.method_22431(class_1799.field_8037) :
                        class_1271.method_22430(class_1799.field_8037);
            };
        }, EventPhase::early, true);
        INSTANCE.register(InteractionInputEvents.Pick.class, ClientPickBlockGatherCallback.EVENT, callback -> {
            return (class_1657 player, class_239 hitResult) -> {
                // add in more checks that also run on Forge
                if (hitResult != null && hitResult.method_17783() != class_239.class_240.field_1333) {
                    class_310 minecraft = class_310.method_1551();
                    EventResult result = callback.onPickInteraction(minecraft, (class_746) player, hitResult);
                    // this uses a second event to filter out this custom item stack again to be able to cancel the interaction
                    // otherwise just returning empty will do nothing and let the behavior continue
                    return result.isInterrupt() ? INTERRUPT_PICK_ITEM_STACK : class_1799.field_8037;
                }
                return class_1799.field_8037;
            };
        });
        INSTANCE.register(ClientLevelEvents.Load.class, FabricClientLevelEvents.LOAD_LEVEL);
        INSTANCE.register(ClientLevelEvents.Unload.class, FabricClientLevelEvents.UNLOAD_LEVEL);
        INSTANCE.register(MovementInputUpdateCallback.class, FabricClientPlayerEvents.MOVEMENT_INPUT_UPDATE);
        INSTANCE.register(RenderBlockOverlayCallback.class, FabricRendererEvents.RENDER_BLOCK_OVERLAY);
        INSTANCE.register(FogEvents.Render.class, FabricRendererEvents.RENDER_FOG);
        INSTANCE.register(FogEvents.ComputeColor.class, FabricRendererEvents.COMPUTE_FOG_COLOR);
        INSTANCE.register(RenderTooltipCallback.class, FabricGuiEvents.RENDER_TOOLTIP);
        INSTANCE.register(RenderHighlightCallback.class, WorldRenderEvents.BEFORE_BLOCK_OUTLINE, callback -> {
            return (WorldRenderContext context, @Nullable class_239 hitResult) -> {
                if (hitResult == null || hitResult.method_17783() == class_239.class_240.field_1333
                        || hitResult.method_17783() == class_239.class_240.field_1332 && !context.blockOutlines()) {
                    return true;
                }
                class_310 minecraft = class_310.method_1551();
                if (!(minecraft.method_1560() instanceof class_1657) || minecraft.field_1690.field_1842) return true;
                EventResult result = callback.onRenderHighlight(context.worldRenderer(),
                        context.camera(),
                        context.gameRenderer(),
                        hitResult,
                        context.tickCounter(),
                        context.matrixStack(),
                        context.consumers(),
                        context.world());
                return result.isPass();
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterTerrain.class, WorldRenderEvents.BEFORE_ENTITIES, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterTerrain(context.worldRenderer(),
                        context.camera(),
                        context.gameRenderer(),
                        context.tickCounter(),
                        context.matrixStack(),
                        context.projectionMatrix(),
                        context.frustum(),
                        context.world());
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterEntities.class, WorldRenderEvents.AFTER_ENTITIES, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterEntities(context.worldRenderer(),
                        context.camera(),
                        context.gameRenderer(),
                        context.tickCounter(),
                        context.matrixStack(),
                        context.projectionMatrix(),
                        context.frustum(),
                        context.world());
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterTranslucent.class, WorldRenderEvents.AFTER_TRANSLUCENT, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterTranslucent(context.worldRenderer(),
                        context.camera(),
                        context.gameRenderer(),
                        context.tickCounter(),
                        context.matrixStack(),
                        context.projectionMatrix(),
                        context.frustum(),
                        context.world());
            };
        });
        INSTANCE.register(RenderLevelEvents.AfterLevel.class, WorldRenderEvents.END, callback -> {
            return (WorldRenderContext context) -> {
                callback.onRenderLevelAfterLevel(context.worldRenderer(),
                        context.camera(),
                        context.gameRenderer(),
                        context.tickCounter(),
                        context.matrixStack(),
                        context.projectionMatrix(),
                        context.frustum(),
                        context.world());
            };
        });
        INSTANCE.register(GameRenderEvents.Before.class, FabricRendererEvents.BEFORE_GAME_RENDER);
        INSTANCE.register(GameRenderEvents.After.class, FabricRendererEvents.AFTER_GAME_RENDER);
        INSTANCE.register(AddToastCallback.class, FabricGuiEvents.ADD_TOAST);
        INSTANCE.register(GatherDebugTextEvents.Left.class, FabricGuiEvents.GATHER_LEFT_DEBUG_TEXT);
        INSTANCE.register(GatherDebugTextEvents.Right.class, FabricGuiEvents.GATHER_RIGHT_DEBUG_TEXT);
        INSTANCE.register(ComputeFieldOfViewCallback.class, FabricRendererEvents.COMPUTE_FIELD_OF_VIEW);
        INSTANCE.register(ChatMessageReceivedCallback.class, FabricClientEvents.CHAT_MESSAGE_RECEIVED);
        INSTANCE.register(GatherEffectScreenTooltipCallback.class, FabricGuiEvents.GATHER_EFFECT_SCREEN_TOOLTIP);
    }

    private static <T, E> void registerScreenEvent(Class<T> clazz, Class<E> eventType, Function<T, E> converter, Function<class_437, Event<E>> eventGetter) {
        INSTANCE.register(clazz,
                eventType,
                converter,
                (Object context, Consumer<Event<E>> applyToInvoker, Consumer<Event<E>> removeInvoker) -> {
                    // we need to keep our own event invokers during the whole pre-init phase to guarantee phase ordering is applied correctly,
                    // since this is managed in the event invokers and there seems to be no way to handle it with just the Fabric event
                    // (since the Fabric event doesn't allow for retrieving already applied event phase orders),
                    // so we register all screen events during pre-init, which allows post-init to already clear our internal map again
                    net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.BEFORE_INIT.register((class_310 client, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (((Class<?>) context).isInstance(screen)) applyToInvoker.accept(eventGetter.apply(screen));
                    });
                    net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((class_310 client, class_437 screen, int scaledWidth, int scaledHeight) -> {
                        if (((Class<?>) context).isInstance(screen)) removeInvoker.accept(eventGetter.apply(screen));
                    });
                });
    }
}
