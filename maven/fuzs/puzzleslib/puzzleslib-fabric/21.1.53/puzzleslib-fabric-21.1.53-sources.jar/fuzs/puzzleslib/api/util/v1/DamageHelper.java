package fuzs.puzzleslib.api.util.v1;

import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_4538;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import org.jetbrains.annotations.Nullable;

/**
 * A small helper class for creating new {@link class_1282 DamageSources}, as vanilla's
 * {@link net.minecraft.class_8109} class does not allow for creating custom damage types.
 */
public final class DamageHelper {

    private DamageHelper() {
        // NO-OP
    }

    /**
     * Looks up a damage type holder in the provided registry access.
     *
     * @param entity      the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    public static class_6880<class_8110> lookup(class_1297 entity, class_5321<class_8110> resourceKey) {
        return LookupHelper.lookup(entity, class_7924.field_42534, resourceKey);
    }

    /**
     * Looks up a damage type holder in the provided registry access.
     *
     * @param levelReader the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    public static class_6880<class_8110> lookup(class_4538 levelReader, class_5321<class_8110> resourceKey) {
        return LookupHelper.lookup(levelReader, class_7924.field_42534, resourceKey);
    }

    /**
     * Looks up a damage type holder in the provided registry access.
     *
     * @param registries  the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    public static class_6880<class_8110> lookup(class_7225.class_7874 registries, class_5321<class_8110> resourceKey) {
        return LookupHelper.lookup(registries, class_7924.field_42534, resourceKey);
    }

    /**
     * Creates a new {@link class_1282}.
     *
     * @param level      the registry access
     * @param damageType the damage type key
     * @return the new {@link class_1282}
     */
    public static class_1282 damageSource(class_4538 level, class_5321<class_8110> damageType) {
        return damageSource(level, damageType, null, null);
    }

    /**
     * Creates a new {@link class_1282}.
     *
     * @param level        the registry access
     * @param damageType   the damage type key
     * @param directEntity the entity directly responsible for causing damage, like the mob attacking the player, or the
     *                     arrow hitting the target
     * @return the new {@link class_1282}
     */
    public static class_1282 damageSource(class_4538 level, class_5321<class_8110> damageType, @Nullable class_1297 directEntity) {
        return damageSource(level, damageType, directEntity, directEntity);
    }

    /**
     * Creates a new {@link class_1282}.
     *
     * @param level         the registry access
     * @param damageType    the damage type key
     * @param directEntity  the entity directly responsible for causing damage, like the mob attacking the player, or
     *                      the arrow hitting the target
     * @param causingEntity the entity that is responsible for causing damage to the target, like the player that shot
     *                      the arrow
     * @return the new {@link class_1282}
     */
    public static class_1282 damageSource(class_4538 level, class_5321<class_8110> damageType, @Nullable class_1297 directEntity, @Nullable class_1297 causingEntity) {
        return damageSource(level.method_30349(), damageType, directEntity, causingEntity);
    }

    /**
     * Creates a new {@link class_1282}.
     *
     * @param registries    the registry access
     * @param damageType    the damage type key
     * @param directEntity  the entity directly responsible for causing damage, like the mob attacking the player, or
     *                      the arrow hitting the target
     * @param causingEntity the entity that is responsible for causing damage to the target, like the player that shot
     *                      the arrow
     * @return the new {@link class_1282}
     */
    public static class_1282 damageSource(class_5455 registries, class_5321<class_8110> damageType, @Nullable class_1297 directEntity, @Nullable class_1297 causingEntity) {
        return new class_1282(lookup(registries, damageType), directEntity, causingEntity);
    }
}
