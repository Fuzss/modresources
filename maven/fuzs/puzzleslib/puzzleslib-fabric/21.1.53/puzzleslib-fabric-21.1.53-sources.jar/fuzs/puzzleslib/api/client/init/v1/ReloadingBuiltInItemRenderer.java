package fuzs.puzzleslib.api.client.init.v1;

import net.minecraft.class_4013;

/**
 * {@link BuiltinItemRenderer} that additionally implements {@link class_4013} allowing for listening to resource reloads.
 */
public interface ReloadingBuiltInItemRenderer extends BuiltinItemRenderer, class_4013 {

}
