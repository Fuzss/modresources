package fuzs.puzzleslib.api.data.v2.recipes;

import fuzs.puzzleslib.api.data.v2.AbstractRecipeProvider;
import fuzs.puzzleslib.impl.item.CopyComponentsRecipe;
import fuzs.puzzleslib.impl.item.CopyComponentsShapedRecipe;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_1865;
import net.minecraft.class_1869;
import net.minecraft.class_1935;
import net.minecraft.class_2447;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7800;
import net.minecraft.class_8790;
import org.jetbrains.annotations.Nullable;

public class CopyComponentsShapedRecipeBuilder extends class_2447 {
    private class_1856 copyFrom;

    public CopyComponentsShapedRecipeBuilder(class_7800 recipeCategory, class_1935 result, int count) {
        super(recipeCategory, result, count);
    }

    public static CopyComponentsShapedRecipeBuilder method_10437(class_7800 category, class_1935 result) {
        return method_10436(category, result, 1);
    }

    public static CopyComponentsShapedRecipeBuilder method_10436(class_7800 category, class_1935 result, int count) {
        return new CopyComponentsShapedRecipeBuilder(category, result, count);
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_10433(Character symbol, class_6862<class_1792> tag) {
        super.method_10433(symbol, tag);
        return this;
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_10434(Character symbol, class_1935 item) {
        super.method_10434(symbol, item);
        return this;
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_10428(Character symbol, class_1856 ingredient) {
        super.method_10428(symbol, ingredient);
        return this;
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_10439(String pattern) {
        super.method_10439(pattern);
        return this;
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_33530(String criterionName, class_175<?> criterionTrigger) {
        super.method_10429(criterionName, criterionTrigger);
        return this;
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_10435(@Nullable String groupName) {
        super.method_10435(groupName);
        return this;
    }

    @Override
    public CopyComponentsShapedRecipeBuilder method_49380(boolean bl) {
        super.method_49380(bl);
        return this;
    }

    public CopyComponentsShapedRecipeBuilder copyFrom(class_1935 copyFrom) {
        return this.copyFrom(class_1856.method_8091(copyFrom));
    }

    public CopyComponentsShapedRecipeBuilder copyFrom(class_1856 copyFrom) {
        this.copyFrom = copyFrom;
        return this;
    }

    @Override
    public void method_17972(class_8790 recipeOutput, class_2960 id) {
        super.method_17972(TransformingRecipeOutput.transformed(recipeOutput, (class_1860<?> recipe) -> {
            // some weird hack to get the proper mod id for the serializer
            String modId =
                    recipeOutput instanceof AbstractRecipeProvider.IdentifiableRecipeOutput identifiableRecipeOutput ?
                            identifiableRecipeOutput.getModId() : id.method_12836();
            class_1865<?> recipeSerializer = CopyComponentsRecipe.getModSerializer(modId,
                    CopyComponentsRecipe.SHAPED_RECIPE_SERIALIZER_ID);
            return new CopyComponentsShapedRecipe(recipeSerializer,
                    (class_1869) recipe,
                    CopyComponentsShapedRecipeBuilder.this.copyFrom);
        }), id);
    }
}
