package fuzs.puzzleslib.fabric.impl.event;

import net.minecraft.class_1266;
import net.minecraft.class_1315;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import org.jetbrains.annotations.Nullable;

/**
 * An extension to {@link net.minecraft.class_1308} that stores the {@link class_3730} the mob was initially
 * spawned with when
 * {@link net.minecraft.class_1308#method_5943(class_5425, class_1266, class_3730,
 * class_1315)} was called.
 * <p>
 * The implementation is just like Forge, but also allows for setting the spawn type in case e.g.
 * {@link net.minecraft.class_1308#method_5943(class_5425, class_1266, class_3730,
 * class_1315)} was overridden without calling super.
 */
public interface SpawnTypeMob {

    @Nullable
    class_3730 puzzleslib$getSpawnType();

    void puzzleslib$setSpawnType(@Nullable class_3730 mobSpawnType);
}
