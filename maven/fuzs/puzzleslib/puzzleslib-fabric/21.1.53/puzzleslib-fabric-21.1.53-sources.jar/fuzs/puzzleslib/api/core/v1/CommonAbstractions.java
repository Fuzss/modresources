package fuzs.puzzleslib.api.core.v1;

import fuzs.puzzleslib.api.init.v3.registry.LookupHelper;
import fuzs.puzzleslib.api.init.v3.tags.TagFactory;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import net.minecraft.class_1266;
import net.minecraft.class_1268;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_3281;
import net.minecraft.class_3288;
import net.minecraft.class_3730;
import net.minecraft.class_3908;
import net.minecraft.class_5425;
import net.minecraft.class_6880;
import net.minecraft.class_7699;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.function.BiConsumer;

/**
 * Useful methods for gameplay related things that require mod loader specific abstractions.
 */
@Deprecated
public interface CommonAbstractions {
    CommonAbstractions INSTANCE = new CommonAbstractions() {
        // NO-OP
    };

    /**
     * Get the current game server which is captured to allow retrieval from anywhere.
     *
     * @return current game server, null when not in a world
     */
    default MinecraftServer getMinecraftServer() {
        return ProxyImpl.get().getMinecraftServer();
    }

    /**
     * Checks if the connected client declared the ability to receive a specific type of packet.
     *
     * @param serverPlayer the server player
     * @param type         the packet type
     * @return if the connected client has declared the ability to receive a specific type of packet
     */
    default boolean hasChannel(class_3222 serverPlayer, class_8710.class_9154<?> type) {
        return ProxyImpl.get().hasChannel(serverPlayer.field_13987, type);
    }

    /**
     * Opens a menu on both client and server while also providing additional data.
     *
     * @param serverPlayer player to open menu for
     * @param menuProvider menu factory
     * @param dataWriter   additional data added via {@link class_9129}
     */
    default void openMenu(class_3222 serverPlayer, class_3908 menuProvider, BiConsumer<class_3222, class_9129> dataWriter) {
        ProxyImpl.get().openMenu(serverPlayer, menuProvider, dataWriter);
    }

    /**
     * Get the parent mob from a possible mob part entity, like
     * {@link net.minecraft.class_1508}.
     * <p>
     * NeoForge allows extending this, so we need this abstraction.
     *
     * @param entity the mob, possibly a mob part
     * @return the parent mob for the part, otherwise the original entity
     */
    default class_1297 getPartEntityParent(class_1297 entity) {
        return ProxyImpl.get().getPartEntityParent(entity);
    }

    /**
     * Is the entity type considered a boss mob like {@link class_1299#field_6116} and {@link class_1299#field_6119} in
     * vanilla.
     * <p>
     * A common property of such entities usually is {@link class_1309#method_61113(class_1937, class_1937)} returns
     * <code>false</code>.
     *
     * @param type the entity type
     * @return is it a boss mob
     */
    default boolean isBossMob(class_1299<?> type) {
        return type.method_20210(TagFactory.COMMON.registerEntityTypeTag("bosses"));
    }

    /**
     * Returns the enchanting power provided by a block. An enchanting power of 15 is required for level 30 enchants,
     * each bookshelf block provides exactly one enchanting power.
     *
     * @param state the block state at the given position
     * @param level the level
     * @param pos   the block position in the level
     * @return enchanting power, usually zero for blocks other than bookshelves
     */
    default float getEnchantPowerBonus(class_2680 state, class_1937 level, class_2338 pos) {
        return ProxyImpl.get().getEnchantPowerBonus(state, level, pos);
    }

    /**
     * Returns if an entity can equip some form of item in a certain slot.
     *
     * @param stack  the stack to be equipped
     * @param slot   the slot the stack is trying to be equipped to
     * @param entity the entity trying to equip
     * @return is equipping this <code>stack</code> to <code>slot</code> allowed for <code>entity</code>
     */
    default boolean canEquip(class_1799 stack, class_1304 slot, class_1309 entity) {
        return ProxyImpl.get().canEquip(stack, slot, entity);
    }

    /**
     * Called before an entity drops loot for determining the level of
     * {@link net.minecraft.class_1893#field_9110} to apply when generating drops.
     *
     * @param target       the entity that has been killed
     * @param attacker     another entity responsible for killing the entity
     * @param damageSource the damage source the entity has been killed by
     * @return the level of looting to apply when generating drops
     */
    default int getMobLootingLevel(class_1297 target, @Nullable class_1297 attacker, @Nullable class_1282 damageSource) {
        if (attacker instanceof class_1309 livingEntity) {
            class_6880<class_1887> enchantment = LookupHelper.lookupEnchantment(target, class_1893.field_9110);
            return class_1890.method_8203(enchantment, livingEntity);
        } else {
            return 0;
        }
    }

    /**
     * Called when a <code>mobGriefing</code> game rule check is required instead of vanilla's
     * <code>level.getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)</code>, allowing for a dedicated Forge event
     * to run.
     *
     * @param level  the level mob griefing is happening in
     * @param entity the entity responsible for triggering the game rule check
     * @return is mob griefing allows to happen
     */
    default boolean getMobGriefingRule(class_1937 level, @Nullable class_1297 entity) {
        return level instanceof class_3218 serverLevel && ProxyImpl.get().isMobGriefingAllowed(serverLevel, entity);
    }

    /**
     * A trigger for running a Forge event for destroying an item.
     *
     * @param player            the player destroying the item
     * @param originalItemStack the item stack before being destroyed
     * @param interactionHand   the hand holding the destroyed stack
     */
    default void onPlayerDestroyItem(class_1657 player, class_1799 originalItemStack, @Nullable class_1268 interactionHand) {
        ProxyImpl.get().onPlayerDestroyItem(player, originalItemStack, interactionHand);
    }

    /**
     * Retrieves a {@link class_3730} from a {@link class_1308} if it has been set during
     * {@link class_1308#method_5943(class_5425, class_1266, class_3730, class_1315)}.
     * <p>Note that the spawn type is saved with the mob, so it persists across chunk and level reloads.
     *
     * @param mob the mob
     * @return the spawn type or null if none has been set
     */
    default @Nullable class_3730 getMobSpawnType(class_1308 mob) {
        return ProxyImpl.get().getMobSpawnReason(mob);
    }

    /**
     * Creates a new {@link class_3288.class_7679} instance with additional parameters only supported on NeoForge.
     *
     * @param id                the pack identifier
     * @param description       the pack description component
     * @param packCompatibility the pack version, ideally retrieved from
     *                          {@link net.minecraft.class_6489#method_48017(class_3264)}
     * @param features          the feature flags provided by this pack
     * @param hidden            controls whether the pack is hidden from user-facing screens like the resource pack and
     *                          data pack selection screens
     * @return the created pack info instance
     */
    default class_3288.class_7679 createPackInfo(class_2960 id, class_2561 description, class_3281 packCompatibility, class_7699 features, boolean hidden) {
        return ProxyImpl.get().createPackInfo(id, description, packCompatibility, features, hidden);
    }

    /**
     * Can the given enchanted be applied to an item stack via enchanting (in an enchanting table).
     *
     * @param enchantment the enchantment to check
     * @param itemStack   the item stack trying to receive the enchantment
     * @return is the application allowed
     */
    default boolean canApplyAtEnchantingTable(class_6880<class_1887> enchantment, class_1799 itemStack) {
        return ProxyImpl.get().canApplyAtEnchantingTable(enchantment, itemStack);
    }

    /**
     * Can the given enchantment be applied to enchanted books.
     *
     * @param enchantment the enchantment to check
     * @return is the application allowed
     */
    default boolean isAllowedOnBooks(class_6880<class_1887> enchantment) {
        return true;
    }

    /**
     * Tests if an enchanted book can be put onto an item stack.
     *
     * @param inputStack the item stack to enchant
     * @param bookStack  the book stack to enchant the item with
     * @return is combining both stacks allowed
     */
    default boolean isBookEnchantable(class_1799 inputStack, class_1799 bookStack) {
        return true;
    }

    /**
     * Called just before an {@link class_1927} is about to be executed for a level.
     *
     * @param level     the level the explosion is happening in
     * @param explosion the explosion that is about to start
     * @return <code>true</code> to mark the explosion as handled, {@link class_1927#method_8348()} is not called
     */
    default boolean onExplosionStart(class_1937 level, class_1927 explosion) {
        return ProxyImpl.get().onExplosionStart(level, explosion);
    }
}
