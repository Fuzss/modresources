package fuzs.puzzleslib.api.client.core.v1.context;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_322;
import net.minecraft.class_326;
import org.jetbrains.annotations.Nullable;

/**
 * Register custom item/block color providers, like tint getters for leaves or grass.
 *
 * @param <T> provider type, either {@link class_322} or {@link class_326}
 * @param <P> object type supported by provider, either {@link class_2248} or {@link class_1792}
 */
public interface ColorProvidersContext<T, P> {

    /**
     * Register a new <code>provider</code> for a number of <code>objects</code>.
     *
     * @param provider provider type, either {@link class_322} or {@link class_326}
     * @param objects  object types supported by provider, either {@link class_2248} or {@link class_1792}
     */
    @SuppressWarnings("unchecked")
    void registerColorProvider(P provider, T... objects);

    /**
     * Provides access to already registered providers, might be incomplete during registration,
     * but is good to use in either {@link class_322} or {@link class_326} as long as it doesn't try to retrieve itself.
     *
     * @return access to {@link net.minecraft.class_324} or {@link net.minecraft.class_325}
     */
    @Nullable P getProvider(T object);
}
