package fuzs.puzzleslib.api.client.core.v1.context;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.api.client.init.v1.ArmorModelSet;
import org.apache.commons.lang3.mutable.MutableObject;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Supplier;
import net.minecraft.class_5601;
import net.minecraft.class_5607;

/**
 * Register layer definitions for entity models.
 */
public interface LayerDefinitionsContext {

    /**
     * @param modelLayer    the model layer location
     * @param layerSupplier the layer definition supplier
     */
    void registerLayerDefinition(class_5601 modelLayer, Supplier<class_5607> layerSupplier);

    /**
     * @param modelLayerSet    the model layer location set
     * @param layerSetSupplier the layer definition set supplier
     * @see ArmorModelSet#putFrom(ArmorModelSet, ImmutableMap.Builder)
     */
    default void registerArmorDefinition(ArmorModelSet<class_5601> modelLayerSet, Supplier<ArmorModelSet<class_5607>> layerSetSupplier) {
        ArmorModelSet<MutableObject<class_5607>> mutableLayerSet = new ArmorModelSet<>(new MutableObject<>(),
                new MutableObject<>(),
                new MutableObject<>(),
                new MutableObject<>());
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                ArmorModelSet::head,
                ArmorModelSet::chest,
                ArmorModelSet::legs,
                ArmorModelSet::feet);
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                ArmorModelSet::chest,
                ArmorModelSet::head,
                ArmorModelSet::legs,
                ArmorModelSet::feet);
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                ArmorModelSet::legs,
                ArmorModelSet::head,
                ArmorModelSet::chest,
                ArmorModelSet::feet);
        this.registerArmorDefinition(modelLayerSet,
                mutableLayerSet,
                layerSetSupplier,
                ArmorModelSet::feet,
                ArmorModelSet::head,
                ArmorModelSet::chest,
                ArmorModelSet::legs);
    }

    private void registerArmorDefinition(ArmorModelSet<class_5601> modelLayerSet, ArmorModelSet<MutableObject<class_5607>> mutableLayerSet, Supplier<ArmorModelSet<class_5607>> layerSetSupplier, ArmorModelSetGetter primaryGetter, ArmorModelSetGetter secondaryGetter, ArmorModelSetGetter tertiaryGetter, ArmorModelSetGetter quaternaryGetter) {
        this.registerLayerDefinition(primaryGetter.apply(modelLayerSet), () -> {
            return this.storeArmorModelLayers(mutableLayerSet,
                    layerSetSupplier,
                    primaryGetter,
                    secondaryGetter,
                    tertiaryGetter,
                    quaternaryGetter);
        });
    }

    /**
     * This implementation tries to create the armor models just once from the supplier, then stores all remaining three
     * models until they are used.
     * <p>
     * Since {@link class_5607} registration is likely to run sequentially in order this should work to reduce
     * overhead and avoid recreating models unnecessarily.
     */
    private class_5607 storeArmorModelLayers(ArmorModelSet<MutableObject<class_5607>> mutableLayerSet, Supplier<ArmorModelSet<class_5607>> layerSetSupplier, ArmorModelSetGetter primaryGetter, ArmorModelSetGetter secondaryGetter, ArmorModelSetGetter tertiaryGetter, ArmorModelSetGetter quaternaryGetter) {
        class_5607 layerDefinition = primaryGetter.apply(mutableLayerSet).getValue();
        if (layerDefinition != null) {
            primaryGetter.apply(mutableLayerSet).setValue(null);
            return layerDefinition;
        } else {
            ArmorModelSet<class_5607> armorModelSet = layerSetSupplier.get();
            secondaryGetter.apply(mutableLayerSet).setValue(secondaryGetter.apply(armorModelSet));
            tertiaryGetter.apply(mutableLayerSet).setValue(tertiaryGetter.apply(armorModelSet));
            quaternaryGetter.apply(mutableLayerSet).setValue(quaternaryGetter.apply(armorModelSet));
            return primaryGetter.apply(armorModelSet);
        }
    }

    @ApiStatus.Internal
    @FunctionalInterface
    interface ArmorModelSetGetter {
        <T> T apply(ArmorModelSet<T> armorModelSet);
    }
}
