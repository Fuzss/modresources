package fuzs.puzzleslib.api.container.v1;

import net.minecraft.class_1263;
import net.minecraft.class_1799;
import org.jetbrains.annotations.ApiStatus;

/**
 * A simple {@link class_1263} implementation taking care of slot range checks and container updates.
 */
public interface SimpleContainerImpl extends class_1263 {

    @Override
    default boolean method_5442() {
        for (int i = 0; i < this.method_5439(); i++) {
            if (!this.method_5438(i).method_7960()) {
                return false;
            }
        }
        return true;
    }

    @Override
    default class_1799 method_5438(int slot) {
        return slot >= 0 && slot < this.method_5439() ? this.getContainerItem(slot) : class_1799.field_8037;
    }

    /**
     * Raw implementation for returning an item from the container without additional checks.
     *
     * @param slot the slot index
     * @return the item stack
     */
    @ApiStatus.OverrideOnly
    class_1799 getContainerItem(int slot);

    @Override
    default class_1799 method_5434(int slot, int amount) {
        if (slot >= 0 && slot < this.method_5439() && !this.getContainerItem(slot).method_7960() && amount > 0) {
            class_1799 itemStack = this.removeContainerItem(slot, amount);
            if (!itemStack.method_7960()) this.method_5431();
            return itemStack;
        } else {
            return class_1799.field_8037;
        }
    }

    /**
     * Raw implementation for removing a specific item amount from the container without additional checks.
     *
     * @param slot   the slot index
     * @param amount the item amount to remove
     * @return the removed item stack
     */
    @ApiStatus.OverrideOnly
    class_1799 removeContainerItem(int slot, int amount);

    @Override
    default class_1799 method_5441(int slot) {
        return slot >= 0 && slot < this.method_5439() ? this.removeContainerItemNoUpdate(slot) : class_1799.field_8037;
    }

    /**
     * Raw implementation for removing an item from the container without additional checks.
     *
     * @param slot the slot index
     * @return the removed item stack
     */
    @ApiStatus.OverrideOnly
    class_1799 removeContainerItemNoUpdate(int slot);

    @Override
    default void method_5447(int slot, class_1799 itemStack) {
        if (slot >= 0 && slot < this.method_5439()) {
            this.setContainerItem(slot, itemStack);
            if (!itemStack.method_7960() && itemStack.method_7947() > this.method_5444()) {
                itemStack.method_7939(this.method_5444());
            }
            this.method_5431();
        }
    }

    /**
     * Raw implementation for placing an item to the container without additional checks.
     *
     * @param slot      the slot index
     * @param itemStack the item stack
     */
    @ApiStatus.OverrideOnly
    void setContainerItem(int slot, class_1799 itemStack);

    @Override
    default void method_5448() {
        for (int i = 0; i < this.method_5439(); i++) {
            this.setContainerItem(i, class_1799.field_8037);
        }
        this.method_5431();
    }
}
