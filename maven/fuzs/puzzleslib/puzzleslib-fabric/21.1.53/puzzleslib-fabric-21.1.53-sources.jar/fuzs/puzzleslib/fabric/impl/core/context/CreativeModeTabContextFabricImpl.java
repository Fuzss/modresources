package fuzs.puzzleslib.fabric.impl.core.context;

import fuzs.puzzleslib.api.core.v1.context.CreativeModeTabContext;
import fuzs.puzzleslib.api.item.v2.CreativeModeTabConfigurator;
import fuzs.puzzleslib.impl.item.CreativeModeTabConfiguratorImpl;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_2378;
import net.minecraft.class_7923;

@Deprecated
public final class CreativeModeTabContextFabricImpl implements CreativeModeTabContext {

    @Override
    public void registerCreativeModeTab(CreativeModeTabConfigurator configurator) {
        class_1761.class_7913 builder = FabricItemGroup.builder();
        ((CreativeModeTabConfiguratorImpl) configurator).configure(builder);
        class_2378.method_10230(class_7923.field_44687,
                ((CreativeModeTabConfiguratorImpl) configurator).getResourceLocation(),
                builder.method_47324()
        );
    }
}
