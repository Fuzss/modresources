package fuzs.puzzleslib.api.client.renderer.v1.special;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5599;
import org.jetbrains.annotations.Nullable;

/**
 * Copied from Minecraft 1.21.8.
 */
public interface SpecialModelRenderer<T> {
    void render(@Nullable T argument, class_4587 poseStack, class_4597 bufferSource, int lightCoords, int overlayCoords, boolean hasFoil);

    @Nullable T extractArgument(class_1799 itemStack);

    interface Unbaked<T> {
        @Nullable SpecialModelRenderer<T> bake(class_5599 modelSet);

        MapCodec<? extends Unbaked<T>> type();
    }
}
