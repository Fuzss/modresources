package fuzs.puzzleslib.api.core.v1.resources;

import net.minecraft.class_2960;
import net.minecraft.class_3302;

/**
 * Allows for providing an identifier for a reload listener by wrapping it in an effort to help with debugging.
 */
@Deprecated
public interface NamedReloadListener extends class_3302 {

    /**
     * @return the identifier for this reload listener
     */
    class_2960 identifier();

    @Override
    default String method_22322() {
        return this.identifier().toString();
    }
}
