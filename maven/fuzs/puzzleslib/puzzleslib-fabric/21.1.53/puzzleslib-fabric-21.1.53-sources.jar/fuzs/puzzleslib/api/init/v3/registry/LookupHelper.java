package fuzs.puzzleslib.api.init.v3.registry;

import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_1297;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_4538;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7225;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/**
 * A few shortcuts for looking up holders in a registry from a registry access.
 */
public final class LookupHelper {

    private LookupHelper() {
        // NO-OP
    }

    /**
     * Finds a registry for the provided {@link class_5321} in {@link class_7923#field_41167}.
     *
     * @param registryKey the registry key
     * @param <T>         registry value type
     * @return the registry
     */
    @SuppressWarnings("unchecked")
    public static <T> Optional<class_2378<T>> getRegistry(class_5321<? extends class_2378<? super T>> registryKey) {
        Objects.requireNonNull(registryKey, "registry key is null");
        return ((class_2378<class_2378<T>>) class_7923.field_41167).method_31189((class_5321<class_2378<T>>) registryKey);
    }

    /**
     * Looks up a holder in the provided registry access.
     *
     * @param entity      the registry access for retrieving the registry
     * @param registryKey the registry key
     * @param resourceKey the value key
     * @param <T>         registry value type
     * @return the holder from the registry
     */
    public static <T> class_6880<T> lookup(class_1297 entity, class_5321<? extends class_2378<? extends T>> registryKey, class_5321<T> resourceKey) {
        Objects.requireNonNull(entity, "entity is null");
        return lookup(entity.method_56673(), registryKey, resourceKey);
    }

    /**
     * Looks up a holder in the provided registry access.
     *
     * @param level       the registry access for retrieving the registry
     * @param registryKey the registry key
     * @param resourceKey the value key
     * @param <T>         registry value type
     * @return the holder from the registry
     */
    public static <T> class_6880<T> lookup(class_4538 level, class_5321<? extends class_2378<? extends T>> registryKey, class_5321<T> resourceKey) {
        Objects.requireNonNull(level, "level is null");
        return lookup(level.method_30349(), registryKey, resourceKey);
    }

    /**
     * Looks up a holder in the provided registry access.
     *
     * @param registries  the registry access for retrieving the registry
     * @param registryKey the registry key
     * @param resourceKey the value key
     * @param <T>         registry value type
     * @return the holder from the registry
     */
    public static <T> class_6880<T> lookup(class_7225.class_7874 registries, class_5321<? extends class_2378<? extends T>> registryKey, class_5321<T> resourceKey) {
        Objects.requireNonNull(registries, "registries is null");
        Objects.requireNonNull(registryKey, "registry key is null");
        Objects.requireNonNull(resourceKey, "resource key is null");
        return registries.method_46762(registryKey).method_46747(resourceKey);
    }

    /**
     * Looks up an enchantment holder in the provided registry access.
     *
     * @param entity      the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    @Deprecated
    public static class_6880<class_1887> lookupEnchantment(class_1297 entity, class_5321<class_1887> resourceKey) {
        return lookup(entity.method_56673(), class_7924.field_41265, resourceKey);
    }

    /**
     * Looks up an enchantment holder in the provided registry access.
     *
     * @param levelReader the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    @Deprecated
    public static class_6880<class_1887> lookupEnchantment(class_4538 levelReader, class_5321<class_1887> resourceKey) {
        return lookup(levelReader.method_30349(), class_7924.field_41265, resourceKey);
    }

    /**
     * Looks up an enchantment holder in the provided registry access.
     *
     * @param registries  the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    @Deprecated
    public static class_6880<class_1887> lookupEnchantment(class_7225.class_7874 registries, class_5321<class_1887> resourceKey) {
        return registries.method_46762(class_7924.field_41265).method_46747(resourceKey);
    }

    /**
     * Looks up a damage type holder in the provided registry access.
     *
     * @param entity      the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    @Deprecated
    public static class_6880<class_8110> lookupDamageType(class_1297 entity, class_5321<class_8110> resourceKey) {
        return lookup(entity.method_56673(), class_7924.field_42534, resourceKey);
    }

    /**
     * Looks up a damage type holder in the provided registry access.
     *
     * @param levelReader the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    @Deprecated
    public static class_6880<class_8110> lookupDamageType(class_4538 levelReader, class_5321<class_8110> resourceKey) {
        return lookup(levelReader.method_30349(), class_7924.field_42534, resourceKey);
    }

    /**
     * Looks up a damage type holder in the provided registry access.
     *
     * @param registries  the registry access for retrieving the registry
     * @param resourceKey the value key
     * @return the holder from the registry
     */
    @Deprecated
    public static class_6880<class_8110> lookupDamageType(class_7225.class_7874 registries, class_5321<class_8110> resourceKey) {
        return registries.method_46762(class_7924.field_42534).method_46747(resourceKey);
    }
}
