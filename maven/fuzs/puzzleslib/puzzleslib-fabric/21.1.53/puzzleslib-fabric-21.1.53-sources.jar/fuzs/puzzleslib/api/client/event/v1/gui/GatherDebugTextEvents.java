package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public final class GatherDebugTextEvents {
    public static final EventInvoker<Left> LEFT = EventInvoker.lookup(Left.class);
    public static final EventInvoker<Right> RIGHT = EventInvoker.lookup(Right.class);

    private GatherDebugTextEvents() {

    }

    @FunctionalInterface
    public interface Left {

        /**
         * An event that runs just before rendering all game information text lines on the left side of the debug screen
         * overlay in {@link net.minecraft.class_340#method_1847(class_332)}.
         *
         * @param window       game window instance
         * @param guiGraphics  gui graphics instance
         * @param deltaTracker current partial tick time
         * @param lines        game information text lines about to be rendered
         */
        void onGatherLeftDebugText(class_1041 window, class_332 guiGraphics, class_9779 deltaTracker, List<String> lines);
    }

    @FunctionalInterface
    public interface Right {

        /**
         * An event that runs just before rendering all system information text lines on the right side of the debug
         * screen overlay in
         * {@link net.minecraft.class_340#method_1848(class_332)}.
         *
         * @param window       game window instance
         * @param guiGraphics  gui graphics instance
         * @param deltaTracker current partial tick time
         * @param lines        system information text lines about to be rendered
         */
        void onGatherRightDebugText(class_1041 window, class_332 guiGraphics, class_9779 deltaTracker, List<String> lines);
    }
}
