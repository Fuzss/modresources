package fuzs.puzzleslib.api.client.gui.v2.components.tooltip;

import fuzs.puzzleslib.impl.client.gui.TooltipBuilderImpl;
import java.time.Duration;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_339;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_8000;

/**
 * A builder implementation for handling {@link net.minecraft.class_7919} with some extras.
 */
public interface TooltipBuilder {

    /**
     * Creates a new builder instance.
     *
     * @return the builder instance
     */
    static TooltipBuilder create() {
        return new TooltipBuilderImpl();
    }

    /**
     * Creates a new builder instance.
     *
     * @param lines the tooltip lines
     * @return the builder instance
     */
    static TooltipBuilder create(class_5348... lines) {
        return new TooltipBuilderImpl(lines);
    }

    /**
     * Creates a new builder instance.
     *
     * @param lines the tooltip lines
     * @return the builder instance
     */
    static TooltipBuilder create(List<? extends class_5348> lines) {
        return new TooltipBuilderImpl(lines);
    }

    /**
     * Adds text lines to the tooltip.
     *
     * @param lines the tooltip lines
     * @return the builder instance
     */
    TooltipBuilder addLines(class_5348... lines);

    /**
     * Adds text lines to the tooltip.
     *
     * @param lines the tooltip lines
     * @return the builder instance
     */
    TooltipBuilder addLines(List<? extends class_5348> lines);

    /**
     * Set text lines for the tooltip.
     * <p>
     * This allows for dynamically updating the tooltip.
     * <p>
     * Lines are cached internally if they do not change from invoking the supplier.
     *
     * @param supplier the tooltip lines
     * @return the builder instance
     */
    TooltipBuilder setLines(Supplier<List<? extends class_5348>> supplier);

    /**
     * Set a custom delay it takes for the tooltip to appear.
     *
     * @param delay the delay
     * @return the builder instance
     */
    TooltipBuilder setDelay(Duration delay);

    /**
     * Set a custom factory for positioning the tooltip around a widget.
     * <p>
     * Usually behaves differently depending on if the tooltip was triggered by the widget being hovered by the cursor,
     * or after becoming selected from navigating via keyboards keys.
     * <p>
     * The vanilla behavior is available as a function parameter.
     *
     * @param factory the factory
     * @return the builder instance
     */
    TooltipBuilder setTooltipPositionerFactory(BiFunction<class_8000, class_339, class_8000> factory);

    /**
     * Split text lines on the tooltip.
     *
     * @return the builder instance
     */
    TooltipBuilder splitLines();

    /**
     * Split text lines on the tooltip by the specified width.
     *
     * @param maxWidth the width to split lines at
     * @return the builder instance
     */
    TooltipBuilder splitLines(int maxWidth);

    /**
     * Prepare tooltip lines for rendering on the tooltip, like splitting by a specified with.
     *
     * @param processor the processor function
     * @return the builder instance
     */
    TooltipBuilder setTooltipLineProcessor(Function<List<? extends class_5348>, List<class_5481>> processor);

    /**
     * Builds the tooltip instance and attaches it to a widget.
     * <p>
     * Can be called multiple times for different widgets.
     *
     * @param abstractWidget the widget to attach the built tooltip to
     */
    void build(class_339 abstractWidget);
}
