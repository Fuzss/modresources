package fuzs.puzzleslib.api.init.v3.tags;

import com.google.common.collect.Maps;
import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_5712;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.minecraft.class_8110;

/**
 * A simple helper class for creating new {@link class_6862} instances with a pre-set registry via {@link class_5321}.
 *
 * @param <T> base type for tags produced by this factory instance
 */
@Deprecated
public final class TypedTagFactory<T> {
    private static final Map<class_5321<class_2378<?>>, TypedTagFactory<?>> VALUES = Maps.newConcurrentMap();
    /**
     * Factory instance of type {@link class_2248}.
     */
    public static final TypedTagFactory<class_2248> BLOCK = make(class_7924.field_41254);
    /**
     * Factory instance of type {@link class_1792}.
     */
    public static final TypedTagFactory<class_1792> ITEM = make(class_7924.field_41197);
    /**
     * Factory instance of type {@link class_3611}.
     */
    public static final TypedTagFactory<class_3611> FLUID = make(class_7924.field_41270);
    /**
     * Factory instance of type {@link class_1299}.
     */
    public static final TypedTagFactory<class_1299<?>> ENTITY_TYPE = make(class_7924.field_41266);
    /**
     * Factory instance of type {@link class_1887}.
     */
    public static final TypedTagFactory<class_1887> ENCHANTMENT = make(class_7924.field_41265);
    /**
     * Factory instance of type {@link class_1959}.
     */
    public static final TypedTagFactory<class_1959> BIOME = make(class_7924.field_41236);
    /**
     * Factory instance of type {@link class_5712}.
     */
    public static final TypedTagFactory<class_5712> GAME_EVENT = make(class_7924.field_41273);
    /**
     * Factory instance of type {@link class_8110}.
     */
    public static final TypedTagFactory<class_8110> DAMAGE_TYPE = make(class_7924.field_42534);

    private final class_5321<class_2378<T>> registryKey;

    private TypedTagFactory(class_5321<class_2378<T>> registryKey) {
        this.registryKey = registryKey;
    }

    /**
     * Construct a new factory instance backed by a provided registry key.
     *
     * @param registryKey the registry key
     * @param <T>         tag base type
     * @return new factory instance
     */
    @SuppressWarnings("unchecked")
    public static <T> TypedTagFactory<T> make(class_5321<class_2378<T>> registryKey) {
        return ((Map<class_5321<class_2378<T>>, TypedTagFactory<T>>) (Map<?, ?>) VALUES).computeIfAbsent(registryKey, TypedTagFactory::new);
    }

    /**
     * Creates a new tag key using a custom namespace.
     *
     * @param namespace the tag key namespace
     * @param path      the tag key path
     * @return the tag key
     */
    public class_6862<T> make(String namespace, String path) {
        Objects.requireNonNull(namespace, "namespace is null");
        Objects.requireNonNull(path, "path is null");
        return this.make(ResourceLocationHelper.fromNamespaceAndPath(namespace, path));
    }

    /**
     * Creates a new tag key using a custom namespace.
     *
     * @param resourceLocation the tag key location
     * @return the tag key
     */
    public class_6862<T> make(class_2960 resourceLocation) {
        Objects.requireNonNull(resourceLocation, "resource location is null");
        return class_6862.method_40092(this.registryKey, resourceLocation);
    }

    /**
     * Creates a new tag key using the <code>minecraft</code> namespace.
     *
     * @param path the tag key path
     * @return the tag key
     */
    public class_6862<T> minecraft(String path) {
        return this.make("minecraft", path);
    }

    /**
     * Creates a new tag key using the <code>c</code> namespace.
     * <p>This namespace is used by Fabric Api.
     *
     * @param path the tag key path
     * @return the tag key
     */
    public class_6862<T> common(String path) {
        return this.make("c", path);
    }

    /**
     * Creates a new tag key using the <code>fabric</code> namespace.
     * <p>This namespace is present in Fabric Api, but is rarely used.
     *
     * @param path the tag key path
     * @return the tag key
     */
    public class_6862<T> fabric(String path) {
        return this.make("fabric", path);
    }

    /**
     * Creates a new tag key using the <code>forge</code> namespace.
     * <p>This namespace is used by Minecraft Forge.
     *
     * @param path the tag key path
     * @return the tag key
     */
    public class_6862<T> forge(String path) {
        return this.make("forge", path);
    }

    /**
     * Creates a new tag key using the <code>curios</code> namespace.
     * <p>This namespace is used by the Curios mod.
     *
     * @param path the tag key path
     * @return the tag key
     */
    public class_6862<T> curios(String path) {
        return this.make("curios", path);
    }

    /**
     * Creates a new tag key using the <code>trinkets</code> namespace.
     * <p>This namespace is used by the Trinkets mod.
     *
     * @param path the tag key path
     * @return the tag key
     */
    public class_6862<T> trinkets(String path) {
        return this.make("trinkets", path);
    }
}
