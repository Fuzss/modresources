package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import fuzs.puzzleslib.api.event.v1.data.DefaultedValue;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_897;

public interface RenderNameTagCallback {
    EventInvoker<RenderNameTagCallback> EVENT = EventInvoker.lookup(RenderNameTagCallback.class);

    /**
     * Fires before the name tag of an entity is tried to be rendered, in addition to preventing the name tag from
     * rendering, rendering can also be forced.
     *
     * @param entity            the entity the name tag is rendered for
     * @param content           the entity display name retrieved from {@link class_1297#method_5476()}, controls the
     *                          name that is rendered for both {@link EventResult#ALLOW} and {@link EventResult#PASS}
     * @param entityRenderer    {@link class_897} instance
     * @param poseStack         the current {@link class_4587}
     * @param multiBufferSource the current {@link class_4597}
     * @param packedLight       packet light the entity is rendered with
     * @param partialTick       current partial tick time
     * @return {@link EventResult#ALLOW} to force the name tag to render, ignoring the need for a custom name to be set,
     *         as well as ignoring other restrictions such as distance and team affiliation,
     *         <p>
     *         {@link EventResult#DENY} to prevent any name tag from showing,
     *         <p>
     *         {@link EventResult#PASS} vanilla checks required for the name tag to render are performed
     */
    EventResult onRenderNameTag(class_1297 entity, DefaultedValue<class_2561> content, class_897<?> entityRenderer, class_4587 poseStack, class_4597 multiBufferSource, int packedLight, float partialTick);
}
