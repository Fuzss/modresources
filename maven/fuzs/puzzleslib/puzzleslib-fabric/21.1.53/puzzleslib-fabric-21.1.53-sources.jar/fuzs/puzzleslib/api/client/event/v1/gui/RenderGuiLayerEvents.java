package fuzs.puzzleslib.api.client.event.v1.gui;

import fuzs.puzzleslib.api.core.v1.utility.ResourceLocationHelper;
import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Events for managing all the rendering in {@link net.minecraft.class_329#method_1753(class_332, class_9779)}.
 * <p>
 * Respects {@link net.minecraft.class_315#field_1842}, for rendering custom gui layers regardless of that setting use
 * {@link RenderGuiEvents.After}.
 * <p>
 * This is modelled after NeoForge's system for handling individual gui layers, for convenience all ids are the same as
 * the ones used there.
 * <p>
 * Note that the implementation on Fabric runs before any actual vanilla gui layers are drawn with similar z-offsets.
 * This is unfortunately necessary to support a proper rendering order that can correctly update
 * {@link fuzs.puzzleslib.api.client.core.v1.ClientAbstractions#getGuiLeftHeight(class_329)} &amp;
 * {@link fuzs.puzzleslib.api.client.core.v1.ClientAbstractions#getGuiRightHeight(class_329)} while running. Also some gui
 * layer events currently cannot be cancelled on Fabric as they are not yet fully implemented.
 * <p>
 * TODO replace {@link class_310} argument with {@link net.minecraft.class_329}
 */
public final class RenderGuiLayerEvents {
    private static final List<class_2960> VANILLA_GUI_LAYERS = new ArrayList<>();
    public static final List<class_2960> VANILLA_GUI_LAYERS_VIEW = Collections.unmodifiableList(
            VANILLA_GUI_LAYERS);
    public static final class_2960 CAMERA_OVERLAYS = register("camera_overlays");
    public static final class_2960 CROSSHAIR = register("crosshair");
    public static final class_2960 HOTBAR = register("hotbar");
    public static final class_2960 JUMP_METER = register("jump_meter");
    public static final class_2960 EXPERIENCE_BAR = register("experience_bar");
    public static final class_2960 PLAYER_HEALTH = register("player_health");
    public static final class_2960 ARMOR_LEVEL = register("armor_level");
    public static final class_2960 FOOD_LEVEL = register("food_level");
    public static final class_2960 VEHICLE_HEALTH = register("vehicle_health");
    public static final class_2960 AIR_LEVEL = register("air_level");
    public static final class_2960 SELECTED_ITEM_NAME = register("selected_item_name");
    public static final class_2960 SPECTATOR_TOOLTIP = register("spectator_tooltip");
    public static final class_2960 EXPERIENCE_LEVEL = register("experience_level");
    public static final class_2960 EFFECTS = register("effects");
    public static final class_2960 BOSS_OVERLAY = register("boss_overlay");
    public static final class_2960 SLEEP_OVERLAY = register("sleep_overlay");
    public static final class_2960 DEMO_OVERLAY = register("demo_overlay");
    public static final class_2960 DEBUG_OVERLAY = register("debug_overlay");
    public static final class_2960 SCOREBOARD_SIDEBAR = register("scoreboard_sidebar");
    public static final class_2960 OVERLAY_MESSAGE = register("overlay_message");
    public static final class_2960 TITLE = register("title");
    public static final class_2960 CHAT = register("chat");
    public static final class_2960 TAB_LIST = register("tab_list");
    public static final class_2960 SUBTITLE_OVERLAY = register("subtitle_overlay");
    public static final class_2960 SAVING_INDICATOR = register("saving_indicator");

    private RenderGuiLayerEvents() {
        // NO-OP
    }

    public static EventInvoker<Before> before(class_2960 resourceLocation) {
        Objects.requireNonNull(resourceLocation, "resource location is null");
        return EventInvoker.lookup(Before.class, resourceLocation);
    }

    public static EventInvoker<After> after(class_2960 resourceLocation) {
        Objects.requireNonNull(resourceLocation, "resource location is null");
        return EventInvoker.lookup(After.class, resourceLocation);
    }

    private static class_2960 register(String path) {
        return register(ResourceLocationHelper.withDefaultNamespace(path));
    }

    private static class_2960 register(class_2960 resourceLocation) {
        VANILLA_GUI_LAYERS.add(resourceLocation);
        return resourceLocation;
    }

    @FunctionalInterface
    public interface Before {

        /**
         * Called before a gui element is rendered, allows for cancelling rendering.
         *
         * @param minecraft    minecraft singleton instance
         * @param guiGraphics  the gui graphics component
         * @param deltaTracker partial tick time
         * @return {@link EventResult#INTERRUPT} to prevent the element from rendering, {@link EventResult#PASS} to
         *         allow the element to render normally
         */
        EventResult onBeforeRenderGuiLayer(class_310 minecraft, class_332 guiGraphics, class_9779 deltaTracker);
    }

    @FunctionalInterface
    public interface After {

        /**
         * Called after a gui element is rendered.
         *
         * @param minecraft    minecraft singleton instance
         * @param guiGraphics  the gui graphics component
         * @param deltaTracker partial tick time
         */
        void onAfterRenderGuiLayer(class_310 minecraft, class_332 guiGraphics, class_9779 deltaTracker);
    }
}
