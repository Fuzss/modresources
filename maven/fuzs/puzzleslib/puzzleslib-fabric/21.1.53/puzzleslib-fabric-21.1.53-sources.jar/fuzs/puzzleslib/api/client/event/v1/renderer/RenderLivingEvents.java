package fuzs.puzzleslib.api.client.event.v1.renderer;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1309;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_583;
import net.minecraft.class_922;

public final class RenderLivingEvents {
    public static final EventInvoker<Before> BEFORE = EventInvoker.lookup(Before.class);
    public static final EventInvoker<After> AFTER = EventInvoker.lookup(After.class);

    private RenderLivingEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Before {

        /**
         * Called before a living entity model is rendered, allows for applying transformations to the {@link class_4587}, or for completely taking over rendering as a whole.
         *
         * @param entity            the entity that is rendering
         * @param renderer          the used {@link class_922} instance
         * @param poseStack         the current {@link class_4587}
         * @param multiBufferSource the current {@link class_4597}
         * @param packedLight       packet light the entity is rendered with
         * @param partialTick       current partial tick time
         * @return {@link EventResult#INTERRUPT} to prevent the player model from rendering, this allows for taking over complete player rendering,
         * {@link EventResult#PASS} to allow the player model to render
         */
        <T extends class_1309, M extends class_583<T>> EventResult onBeforeRenderEntity(T entity, class_922<T, M> renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight);
    }

    @FunctionalInterface
    public interface After {

        /**
         * Called after a living entity model is rendered, allows for cleaning up transformations applied to the {@link class_4587}.
         *
         * @param entity            the entity that is rendering
         * @param renderer          the used {@link class_922} instance
         * @param poseStack         the current {@link class_4587}
         * @param multiBufferSource the current {@link class_4597}
         * @param packedLight       packet light the entity is rendered with
         * @param partialTick       current partial tick time
         */
        <T extends class_1309, M extends class_583<T>> void onAfterRenderEntity(T entity, class_922<T, M> renderer, float partialTick, class_4587 poseStack, class_4597 multiBufferSource, int packedLight);
    }
}
