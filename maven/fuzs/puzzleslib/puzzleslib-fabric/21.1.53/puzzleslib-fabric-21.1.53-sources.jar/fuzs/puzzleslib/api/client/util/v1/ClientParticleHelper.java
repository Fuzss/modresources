package fuzs.puzzleslib.api.client.util.v1;

import net.minecraft.class_128;
import net.minecraft.class_129;
import net.minecraft.class_148;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2509;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;

/**
 * A helper class for particle-related methods found in {@link class_638} returning the created particle.
 * <p>
 * Particles will only be spawned when a client-level instance is provided.
 */
public final class ClientParticleHelper {

    private ClientParticleHelper() {
        // NO-OP
    }

    /**
     * @see net.minecraft.class_761#method_3276(class_2394, double, double, double, double,
     *         double, double)
     */
    @Nullable
    public static class_703 addParticle(class_638 clientLevel, class_2394 particleOptions, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return addParticle(clientLevel,
                particleOptions,
                particleOptions.method_10295().method_10299(),
                false,
                x,
                y,
                z,
                xSpeed,
                ySpeed,
                zSpeed);
    }

    /**
     * @see net.minecraft.class_761#method_8563(class_2394, boolean, boolean, double,
     *         double, double, double, double, double)
     */
    @Nullable
    public static class_703 addParticle(class_638 clientLevel, class_2394 particleOptions, boolean forceAlwaysRender, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return addParticle(clientLevel,
                particleOptions,
                particleOptions.method_10295().method_10299() || forceAlwaysRender,
                false,
                x,
                y,
                z,
                xSpeed,
                ySpeed,
                zSpeed);
    }

    /**
     * @see class_638#method_8494(class_2394, double, double, double, double, double, double)
     */
    @Nullable
    public static class_703 addAlwaysVisibleParticle(class_638 clientLevel, class_2394 particleOptions, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return addParticle(clientLevel, particleOptions, false, true, x, y, z, xSpeed, ySpeed, zSpeed);
    }

    /**
     * @see class_638#method_17452(class_2394, boolean, double, double, double, double, double,
     *         double)
     */
    @Nullable
    public static class_703 addAlwaysVisibleParticle(class_638 clientLevel, class_2394 particleOptions, boolean ignoreRange, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return addParticle(clientLevel,
                particleOptions,
                particleOptions.method_10295().method_10299() || ignoreRange,
                true,
                x,
                y,
                z,
                xSpeed,
                ySpeed,
                zSpeed);
    }

    /**
     * Copied from
     * {@link net.minecraft.class_761#method_8563(class_2394, boolean, boolean, double, double,
     * double, double, double, double)}.
     */
    @Nullable
    public static class_703 addParticle(class_638 clientLevel, class_2394 options, boolean force, boolean decreased, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        try {
            return clientLevel.field_17780.method_3288(options,
                    force,
                    decreased,
                    x,
                    y,
                    z,
                    xSpeed,
                    ySpeed,
                    zSpeed);
        } catch (Throwable throwable) {
            class_128 crashReport = class_128.method_560(throwable, "Exception while adding particle");
            class_129 crashReportCategory = crashReport.method_562("Particle being added");
            crashReportCategory.method_578("ID", class_7923.field_41180.method_10221(options.method_10295()));
            crashReportCategory.method_577("Parameters",
                    () -> class_2398.field_25125.encodeStart(clientLevel.method_30349()
                            .method_57093(class_2509.field_11560), options).toString());
            crashReportCategory.method_577("Position", () -> class_129.method_583(clientLevel, x, y, z));
            throw new class_148(crashReport);
        }
    }
}
