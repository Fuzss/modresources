package fuzs.puzzleslib.fabric.impl.biome;

import com.google.common.collect.Iterables;
import fuzs.puzzleslib.api.biome.v1.GenerationSettingsContext;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.minecraft.class_2893;
import net.minecraft.class_2922;
import net.minecraft.class_5321;
import net.minecraft.class_5485;
import net.minecraft.class_6796;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import java.util.List;

public record GenerationSettingsContextFabric(class_5485 generationSettings, BiomeModificationContext.GenerationSettingsContext context) implements GenerationSettingsContext {

    @Override
    public boolean removeFeature(class_2893.class_2895 step, class_5321<class_6796> featureKey) {
        return this.context.removeFeature(step, featureKey);
    }

    @Override
    public void addFeature(class_2893.class_2895 step, class_5321<class_6796> featureKey) {
        this.context.addFeature(step, featureKey);
    }

    @Override
    public void addCarver(class_2893.class_2894 step, class_5321<class_2922<?>> carverKey) {
        this.context.addCarver(step, carverKey);
    }

    @Override
    public boolean removeCarver(class_2893.class_2894 step, class_5321<class_2922<?>> carverKey) {
        return this.context.removeCarver(step, carverKey);
    }

    @Override
    public Iterable<class_6880<class_6796>> getFeatures(class_2893.class_2895 stage) {
        List<class_6885<class_6796>> featureSteps = this.generationSettings.method_30983();
        if (stage.ordinal() >= featureSteps.size()) return List.of();
        return Iterables.unmodifiableIterable(featureSteps.get(stage.ordinal()));
    }

    @Override
    public Iterable<class_6880<class_2922<?>>> getCarvers(class_2893.class_2894 stage) {
        return Iterables.unmodifiableIterable(this.generationSettings.method_30976(stage));
    }
}
