package fuzs.puzzleslib.api.entity.v1;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import fuzs.puzzleslib.api.core.v2.ClientAsset;
import net.minecraft.class_2960;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

/**
 * Copied from Minecraft 26.1.
 */
public record ModelAndTexture<T>(T model, ClientAsset.ResourceTexture asset) {
    public ModelAndTexture(T model, class_2960 assetId) {
        this(model, new ClientAsset.ResourceTexture(assetId));
    }

    public static <T> MapCodec<ModelAndTexture<T>> codec(Codec<T> modelCodec, T defaultModel) {
        return RecordCodecBuilder.mapCodec(i -> i.group(modelCodec.optionalFieldOf("model", defaultModel)
                                .forGetter(ModelAndTexture::model),
                        ClientAsset.ResourceTexture.DEFAULT_FIELD_CODEC.forGetter(ModelAndTexture::asset))
                .apply(i, ModelAndTexture::new));
    }

    public static <T> class_9139<class_9129, ModelAndTexture<T>> streamCodec(class_9139<? super class_9129, T> modelCodec) {
        return class_9139.method_56435(modelCodec,
                ModelAndTexture::model,
                ClientAsset.ResourceTexture.STREAM_CODEC,
                ModelAndTexture::asset,
                ModelAndTexture::new);
    }
}
