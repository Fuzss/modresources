package fuzs.puzzleslib.api.core.v1;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import fuzs.puzzleslib.impl.core.proxy.ProxyImpl;
import java.util.List;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_634;

/**
 * Proxy base class for client and server implementations mainly used for handling content not present on a physical
 * server.
 */
public interface Proxy {
    Proxy INSTANCE = class_156.method_656(() -> {
        if (ModLoaderEnvironment.INSTANCE.isClient()) {
            return ServiceProviderHelper.load(ClientProxyImpl.class);
        } else {
            return ServiceProviderHelper.load(ProxyImpl.class);
        }
    });

    /**
     * @return client player from Minecraft singleton when on physical client, otherwise null
     */
    class_1657 getClientPlayer();

    /**
     * @return client level from Minecraft singleton when on physical client, otherwise null
     */
    class_1937 getClientLevel();

    /**
     * @return the connection to the server on physical client, otherwise null
     */
    class_634 getClientPacketListener();

    /**
     * Used to check if the control key (command on Mac) is pressed, useful for item tooltips.
     * <p>
     * Always returns <code>false</code> on the server side.
     */
    boolean hasControlDown();

    /**
     * Used to check if the shift key is pressed, useful for item tooltips.
     * <p>
     * Always returns <code>false</code> on the server side.
     *
     * @return is the shift key pressed
     */
    boolean hasShiftDown();

    /**
     * Used to check if the alt key is pressed, useful for item tooltips.
     * <p>
     * Always returns <code>false</code> on the server side.
     *
     * @return is the alt key pressed
     */
    boolean hasAltDown();

    /**
     * Split a text component into multiple parts depending on a predefined max width.
     * <p>
     * Most useful for constructing item tooltips in
     * {@link net.minecraft.class_1792#method_7851(class_1799, class_1792.class_9635, List, class_1836)}.
     * <p>
     * Always returns the unmodified component on the server side.
     *
     * @param component the component to split
     * @return the split component
     */
    List<class_2561> splitTooltipLines(class_2561 component);
}
