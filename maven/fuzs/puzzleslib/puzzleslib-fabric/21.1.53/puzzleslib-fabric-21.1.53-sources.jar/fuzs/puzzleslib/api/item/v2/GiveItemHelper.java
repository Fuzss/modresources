package fuzs.puzzleslib.api.item.v2;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import fuzs.puzzleslib.impl.PuzzlesLib;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.Collections;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2165;
import net.minecraft.class_2168;
import net.minecraft.class_2290;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3068;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

/**
 * A helper class for giving items to the player just like the {@code /give} command does, meaning the item is either
 * added to the player inventory, or dropped on the ground if no available inventory space is found.
 */
public final class GiveItemHelper {

    private GiveItemHelper() {
        // NO-OP
    }

    /**
     * Gives an {@link class_1799} to a {@link class_3222} using the same mechanics as {@link class_3068}.
     *
     * @param itemStack    the item stack to give to the player
     * @param serverPlayer the player to give the item stack to
     */
    public static void giveItem(class_1799 itemStack, class_3222 serverPlayer) {
        giveItem(createEmptyCommandSource(serverPlayer.method_51469()), itemStack, Collections.singleton(serverPlayer));
    }

    /**
     * Gives an {@link class_1799} to some {@link class_3222 ServerPlayers} using the same mechanics as
     * {@link class_3068}.
     *
     * @param itemStack     the item stack to give to the players
     * @param serverPlayers the players to give the item stack to
     */
    public static void giveItem(class_1799 itemStack, Collection<class_3222> serverPlayers) {
        class_3222 serverPlayer = serverPlayers.iterator().next();
        giveItem(createEmptyCommandSource(serverPlayer.method_51469()), itemStack, serverPlayers);
    }

    static void giveItem(class_2168 commandSourceStack, class_1799 itemStack, Collection<class_3222> serverPlayers) {
        try {
            class_2290 itemInput = new class_2290(itemStack.method_41409(), itemStack.method_57380());
            class_3068.method_13401(commandSourceStack, itemInput, serverPlayers, itemStack.method_7947());
        } catch (CommandSyntaxException exception) {
            PuzzlesLib.LOGGER.warn("Failed to give {} to players {}", itemStack, serverPlayers, exception);
        }
    }

    static class_2168 createEmptyCommandSource(class_3218 serverLevel) {
        return createEmptyCommandSource(serverLevel, 2);
    }

    static class_2168 createEmptyCommandSource(class_3218 serverLevel, int permissionLevel) {
        return createEmptyCommandSource(serverLevel, null, permissionLevel);
    }

    static class_2168 createEmptyCommandSource(class_3218 serverLevel, @Nullable class_1297 entity, int permissionLevel) {
        return new class_2168(class_2165.field_17395,
                class_243.field_1353,
                class_241.field_1340,
                serverLevel,
                permissionLevel,
                "Empty",
                class_2561.method_43470("Empty"),
                serverLevel.method_8503(),
                entity).method_9217();
    }
}
