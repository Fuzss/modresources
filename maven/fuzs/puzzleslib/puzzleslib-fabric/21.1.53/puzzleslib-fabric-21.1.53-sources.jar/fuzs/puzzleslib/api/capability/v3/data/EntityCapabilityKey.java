package fuzs.puzzleslib.api.capability.v3.data;

import fuzs.puzzleslib.api.network.v3.PlayerSet;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import fuzs.puzzleslib.impl.capability.ClientboundEntityCapabilityMessage;
import net.minecraft.class_1297;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

/**
 * Convenient {@link CapabilityKey} implementation for {@link class_1297}.
 *
 * @param <T> entity type
 * @param <C> capability component type
 */
@ApiStatus.NonExtendable
public interface EntityCapabilityKey<T extends class_1297, C extends CapabilityComponent<T>> extends CapabilityKey<T, C> {

    /**
     * Set a behaviour for automatically syncing capability components to tracking remotes
     *
     * @return the sync strategy
     */
    SyncStrategy getSyncStrategy();

    /**
     * Set how capability data should be handled when entity data is copied.
     *
     * @return the copy strategy
     */
    CopyStrategy getCopyStrategy();

    @Override
    default void setChanged(C capabilityComponent, @Nullable PlayerSet playerSet) {
        if (capabilityComponent.getHolder().method_37908().field_9236) {
            playerSet = PlayerSet.ofNone();
        } else if (playerSet == null) {
            playerSet = this.getSyncStrategy().getPlayerSet(capabilityComponent.getHolder());
        }

        PuzzlesLibMod.NETWORK.sendMessage(playerSet, this.toPacket(capabilityComponent));
    }

    @Override
    default ClientboundEntityCapabilityMessage toPacket(C capabilityComponent) {
        return new ClientboundEntityCapabilityMessage(this.identifier(),
                capabilityComponent.getHolder().method_5628(),
                capabilityComponent.toCompoundTag(capabilityComponent.getHolder().method_56673())
        );
    }

    /**
     * A builder-like subclass used during registration for setting additional properties.
     *
     * @param <T> entity type
     * @param <C> capability component type
     */
    interface Mutable<T extends class_1297, C extends CapabilityComponent<T>> extends EntityCapabilityKey<T, C> {

        /**
         * Set a sync strategy for this capability component.
         * <p>The default value is {@link SyncStrategy#MANUAL}.
         * <p>Can only be called once with something other than the default value.
         *
         * @param syncStrategy the new sync strategy
         * @return this capability key instance
         */
        Mutable<T, C> setSyncStrategy(SyncStrategy syncStrategy);

        /**
         * Set a copy strategy for this capability component.
         * <p>The default value is {@link CopyStrategy#NEVER}.
         * <p>Can only be called once with something other than the default value.
         *
         * @param copyStrategy the new copy strategy
         * @return this capability key instance
         */
        Mutable<T, C> setCopyStrategy(CopyStrategy copyStrategy);
    }
}
