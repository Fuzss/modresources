package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.common.api.event.v1.data.MutableValue;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Animal.class)
abstract class AnimalFabricMixin extends AgeableMob {

    protected AnimalFabricMixin(EntityType<? extends AgeableMob> entityType, Level level) {
        super(entityType, level);
    }

    @ModifyVariable(method = "spawnChildFromBreeding", at = @At("STORE"))
    public AgeableMob spawnChildFromBreeding(@Nullable AgeableMob offspring, ServerLevel level, Animal partner) {
        MutableValue<AgeableMob> defaultedChild = MutableValue.fromValue(offspring);
        if (FabricLivingEvents.BABY_ENTITY_SPAWN.invoker()
                .onBabyEntitySpawn(this, partner, defaultedChild)
                .isInterrupt()) {
            this.setAge(6000);
            partner.setAge(6000);
            this.resetLove();
            partner.resetLove();
            return null;
        } else {
            return defaultedChild.get();
        }
    }

    @Shadow
    public abstract void resetLove();
}
