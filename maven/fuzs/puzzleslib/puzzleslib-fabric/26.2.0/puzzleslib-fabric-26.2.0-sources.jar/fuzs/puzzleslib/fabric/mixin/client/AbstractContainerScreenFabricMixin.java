package fuzs.puzzleslib.fabric.mixin.client;

import fuzs.puzzleslib.fabric.api.client.event.v1.FabricGuiEvents;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractContainerScreen.class)
abstract class AbstractContainerScreenFabricMixin extends Screen {

    protected AbstractContainerScreenFabricMixin(Component component) {
        super(component);
    }

    @Inject(method = "extractContents",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/client/gui/screens/inventory/AbstractContainerScreen;extractLabels(Lnet/minecraft/client/gui/GuiGraphicsExtractor;II)V",
                     shift = At.Shift.AFTER))
    public void renderContents(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a, CallbackInfo callback) {
        FabricGuiEvents.EXTRACT_CONTAINER_SCREEN_CONTENTS.invoker()
                .onExtractContainerScreenContents(AbstractContainerScreen.class.cast(this), graphics, mouseX, mouseY);
    }
}
