package fuzs.puzzleslib.fabric.mixin;

import fuzs.puzzleslib.common.impl.event.EventImplHelper;
import fuzs.puzzleslib.fabric.api.event.v1.FabricLivingEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.equine.AbstractHorse;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractHorse.class)
abstract class AbstractHorseFabricMixin extends Animal {

    protected AbstractHorseFabricMixin(EntityType<? extends Animal> entityType, Level level) {
        super(entityType, level);
    }

    @Inject(method = "executeRidersJump",
            at = @At(value = "FIELD",
                     target = "Lnet/minecraft/world/entity/animal/equine/AbstractHorse;needsSync:Z",
                     shift = At.Shift.AFTER,
                     opcode = Opcodes.PUTFIELD))
    public void executeRidersJump(float amount, Vec3 input, CallbackInfo callback) {
        EventImplHelper.onLivingJump(FabricLivingEvents.LIVING_JUMP.invoker(), this);
    }
}
