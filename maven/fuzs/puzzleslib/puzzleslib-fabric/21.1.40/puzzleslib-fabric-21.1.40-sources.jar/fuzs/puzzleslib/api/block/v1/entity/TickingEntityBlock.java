package fuzs.puzzleslib.api.block.v1.entity;

import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_5558;

/**
 * A simple extension to {@link class_2343} for a default implementation of {@link class_2343#method_31645(class_1937, class_2680, class_2591)}.
 * @param <T> type of the corresponding {@link class_2586}
 */
public interface TickingEntityBlock<T extends class_2586 & TickingBlockEntity> extends class_2343 {

    /**
     * Get the {@link class_2591} for this block.
     *
     * @return tne block entity type token
     */
    class_2591<? extends T> getBlockEntityType();

    @Override
    default class_2586 method_10123(class_2338 pos, class_2680 state) {
        return this.getBlockEntityType().method_11032(pos, state);
    }

    @Nullable
    @Override
    default <BE extends class_2586> class_5558<BE> method_31645(class_1937 level, class_2680 state, class_2591<BE> blockEntityType) {
        // due to the type bounds in TickingEntityBlock this guarantees we have a TickingBlockEntity instance
        if (this.getBlockEntityType().equals(blockEntityType)) {
            Consumer<TickingBlockEntity> ticker = level.field_9236 ? TickingBlockEntity::clientTick : TickingBlockEntity::serverTick;
            return (class_1937 $, class_2338 blockPos, class_2680 blockState, BE blockEntity) -> {
                // no need to pass on anything, the block entity instance already has all those parameters
                ticker.accept((TickingBlockEntity) blockEntity);
            };
        }

        return null;
    }
}
