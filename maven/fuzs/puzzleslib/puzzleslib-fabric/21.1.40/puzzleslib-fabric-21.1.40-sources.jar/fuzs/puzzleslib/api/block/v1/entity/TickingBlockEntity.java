package fuzs.puzzleslib.api.block.v1.entity;

import net.minecraft.class_1937;

/**
 * A utility interface for extending {@link net.minecraft.class_2586}, allowing to implement
 * non-static tick methods.
 * <p>
 * Inspired by <a
 * href="https://github.com/Shadows-of-Fire/Placebo/blob/1.20/src/main/java/dev/shadowsoffire/placebo/block_entity/TickingBlockEntity.java">TickingBlockEntity.java</a>.
 */
public interface TickingBlockEntity {

    /**
     * Ticks the block entity on the client-side (meaning when {@link class_1937#field_9236}) is <code>true</code>.
     * <p>
     * Used in vanilla e.g. for animating the book in
     * {@link net.minecraft.class_2605}.
     */
    default void clientTick() {
        // NO-OP
    }

    /**
     * Ticks the block entity on the server-side (meaning when {@link class_1937#field_9236}) is <code>false</code>.
     * <p>
     * Used in vanilla e.g. for running cooking logic in
     * {@link net.minecraft.class_3866}.
     */
    default void serverTick() {
        // NO-OP
    }
}
