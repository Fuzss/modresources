package fuzs.puzzleslib.api.network.v4;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1923;
import net.minecraft.class_1937;
import net.minecraft.class_2382;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3898;
import net.minecraft.class_5321;
import net.minecraft.class_5629;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.Consumer;

/**
 * A distributor for client-bound packets.
 */
@FunctionalInterface
public interface PlayerSet {

    /**
     * Send a packet to clients.
     *
     * @param serverPlayerConsumer the action to apply to all server players
     */
    void apply(Consumer<class_3222> serverPlayerConsumer);

    /**
     * Send a message from the server to no player.
     */
    static PlayerSet ofNone() {
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            // NO-OP
        };
    }

    /**
     * Send a message from the server to an entity.
     * <p>
     * When the entity is not a {@link class_3222} no message is sent.
     *
     * @param entity entity to send to
     */
    static PlayerSet ofEntity(class_1297 entity) {
        Objects.requireNonNull(entity, "entity is null");
        return entity instanceof class_3222 serverPlayer ? ofPlayer(serverPlayer) : ofNone();
    }

    /**
     * Send a message from the server to a player.
     *
     * @param serverPlayer player to send to
     */
    static PlayerSet ofPlayer(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            serverPlayerConsumer.accept(serverPlayer);
        };
    }

    /**
     * Send a message from the server to all players on the server.
     *
     * @param serverPlayer player to exclude from sending to
     */
    static PlayerSet ofOthers(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            serverPlayer.method_37908()
                    .method_8503()
                    .method_3760()
                    .method_14571()
                    .forEach((class_3222 currentServerPlayer) -> {
                        if (currentServerPlayer != serverPlayer) {
                            ofPlayer(currentServerPlayer).apply(serverPlayerConsumer);
                        }
                    });
        };
    }

    /**
     * Send a message from the server to all players on the server.
     *
     * @param minecraftServer server for retrieving the player list
     */
    static PlayerSet ofAll(MinecraftServer minecraftServer) {
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            minecraftServer.method_3760().method_14571().forEach((class_3222 serverPlayer) -> {
                ofPlayer(serverPlayer).apply(serverPlayerConsumer);
            });
        };
    }

    /**
     * Send a message from the server to all players in a level.
     *
     * @param level the level
     */
    static PlayerSet inLevel(class_1937 level) {
        Objects.requireNonNull(level, "level is null");
        return level instanceof class_3218 serverLevel ? inLevel(serverLevel) : ofNone();
    }

    /**
     * Send a message from the server to all players in a level.
     *
     * @param serverLevel the level
     */
    static PlayerSet inLevel(class_3218 serverLevel) {
        Objects.requireNonNull(serverLevel, "server level is null");
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            for (class_3222 serverPlayer : serverLevel.method_18456()) {
                ofPlayer(serverPlayer).apply(serverPlayerConsumer);
            }
        };
    }

    /**
     * Send a message from the server to all players near a given position.
     *
     * @param position    source position
     * @param serverLevel the current level
     */
    static PlayerSet nearPosition(class_2382 position, class_3218 serverLevel) {
        Objects.requireNonNull(position, "position is null");
        return nearPosition(position.method_10263(), position.method_10264(), position.method_10260(), serverLevel);
    }

    /**
     * Send a message from the server to all players near a given position.
     *
     * @param posX        source position x
     * @param posY        source position y
     * @param posZ        source position z
     * @param serverLevel the current level
     */
    static PlayerSet nearPosition(double posX, double posY, double posZ, class_3218 serverLevel) {
        return nearPosition(null, posX, posY, posZ, 64.0, serverLevel);
    }

    /**
     * Send a message from the server to all players near a given position.
     * <p>
     * The implementation is copied from
     * {@link net.minecraft.class_3324#method_14605(class_1657, double, double, double, double, class_5321,
     * class_2596)}.
     *
     * @param excludePlayer exclude player having caused this event
     * @param posX          source position x
     * @param posY          source position y
     * @param posZ          source position z
     * @param distance      Euclidean distance from source to receive the message
     * @param serverLevel   the current level
     */
    static PlayerSet nearPosition(@Nullable class_3222 excludePlayer, double posX, double posY, double posZ, double distance, class_3218 serverLevel) {
        Objects.requireNonNull(serverLevel, "server level is null");
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            for (class_3222 serverPlayer : serverLevel.method_8503().method_3760().method_14571()) {
                if (serverPlayer != excludePlayer && serverPlayer.method_37908().method_27983() == serverLevel.method_27983()) {
                    double deltaX = posX - serverPlayer.method_23317();
                    double deltaY = posY - serverPlayer.method_23318();
                    double deltaZ = posZ - serverPlayer.method_23321();
                    if (deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ < distance * distance) {
                        ofPlayer(serverPlayer).apply(serverPlayerConsumer);
                    }
                }
            }
        };
    }

    /**
     * Send a message from the server to all players tracking a block entity at a certain block position.
     *
     * @param blockEntity the block entity a player must track to receive this message
     */
    static PlayerSet nearBlockEntity(class_2586 blockEntity) {
        Objects.requireNonNull(blockEntity, "block entity is null");
        class_1937 level = blockEntity.method_10997();
        Objects.requireNonNull(level, "block entity level is null");
        return level.method_8608() ? PlayerSet.ofNone() : nearPosition(blockEntity.method_11016(), (class_3218) level);
    }

    /**
     * Send a message from the server to all players tracking a chunk.
     *
     * @param levelChunk the chunk a player must track to receive this message
     */
    static PlayerSet nearChunk(class_2818 levelChunk) {
        Objects.requireNonNull(levelChunk, "chunk is null");
        return levelChunk.method_12200().method_8608() ? PlayerSet.ofNone() :
                nearChunk((class_3218) levelChunk.method_12200(), levelChunk.method_12004());
    }

    /**
     * Send a message from the server to all players tracking a chunk.
     *
     * @param serverLevel the level containing the chunk
     * @param chunkPos    the chunk pos a player must track to receive this message
     */
    static PlayerSet nearChunk(class_3218 serverLevel, class_1923 chunkPos) {
        Objects.requireNonNull(serverLevel, "server level is null");
        Objects.requireNonNull(chunkPos, "chunk pos is null");
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            serverLevel.method_14178().field_17254.method_17210(chunkPos, false).forEach((class_3222 serverPlayer) -> {
                ofPlayer(serverPlayer).apply(serverPlayerConsumer);
            });
        };
    }

    /**
     * Send a message from the server to all players tracking a given entity.
     * <p>
     * When the entity is a player, it will receive the message as well, otherwise use
     * {@link #nearPlayer(class_3222)}.
     * <p>
     * The implementation is copied from
     * {@link net.minecraft.class_3215#sendToTrackingPlayersAndSelf(Entity, Packet)}.
     *
     * @param entity the tracked entity
     */
    static PlayerSet nearEntity(class_1297 entity) {
        Objects.requireNonNull(entity, "entity is null");
        return entity.method_37908().method_8608() ? PlayerSet.ofNone() : (Consumer<class_3222> serverPlayerConsumer) -> {
            class_3898 chunkMap = ((class_3218) entity.method_37908()).method_14178().field_17254;
            class_3898.class_3208 trackedEntity = chunkMap.field_18242.get(entity.method_5628());
            if (trackedEntity != null) {
                for (class_5629 serverPlayerConnection : trackedEntity.field_18250) {
                    ofPlayer(serverPlayerConnection.method_32311()).apply(serverPlayerConsumer);
                }
                if (entity instanceof class_3222 serverPlayer) {
                    ofPlayer(serverPlayer).apply(serverPlayerConsumer);
                }
            }
        };
    }

    /**
     * Send a message from the server to all other players tracking a given player.
     * <p>
     * The player will not receive the message, for that use {@link #nearEntity(class_1297)}.
     * <p>
     * The implementation is copied from
     * {@link net.minecraft.class_3215#sendToTrackingPlayers(Entity, Packet)}.
     *
     * @param serverPlayer the tracked player
     */
    static PlayerSet nearPlayer(class_3222 serverPlayer) {
        Objects.requireNonNull(serverPlayer, "server player is null");
        return (Consumer<class_3222> serverPlayerConsumer) -> {
            class_3898 chunkMap = serverPlayer.method_51469().method_14178().field_17254;
            class_3898.class_3208 trackedEntity = chunkMap.field_18242.get(serverPlayer.method_5628());
            if (trackedEntity != null) {
                for (class_5629 serverPlayerConnection : trackedEntity.field_18250) {
                    ofPlayer(serverPlayerConnection.method_32311()).apply(serverPlayerConsumer);
                }
            }
        };
    }
}
