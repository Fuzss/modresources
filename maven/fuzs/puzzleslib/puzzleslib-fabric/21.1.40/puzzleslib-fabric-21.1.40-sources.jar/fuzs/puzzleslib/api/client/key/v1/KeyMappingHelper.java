package fuzs.puzzleslib.api.client.key.v1;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * A small helper class for retrieving the registered {@link KeyActivationContext} for a {@link class_304}.
 */
public interface KeyMappingHelper {
    KeyMappingHelper INSTANCE = ClientProxyImpl.get().getKeyMappingActivationHelper();

    /**
     * Retrieve the registered {@link KeyActivationContext} for a {@link class_304}, will default to
     * {@link KeyActivationContext#UNIVERSAL}.
     *
     * @param keyMapping the key mapping
     * @return an activation context for key mappings
     */
    KeyActivationContext getKeyActivationContext(class_304 keyMapping);

    /**
     * Tests if two key mappings can coexist without interfering with each other.
     *
     * @param keyMapping      one key mapping
     * @param otherKeyMapping the other key mapping
     * @return can both key mappings coexist without interfering with each other
     */
    default boolean isConflictingWith(class_304 keyMapping, class_304 otherKeyMapping) {
        return this.getKeyActivationContext(keyMapping)
                .isConflictingWith(this.getKeyActivationContext(otherKeyMapping));
    }

    /**
     * Register an unbound modded key mapping with a custom category.
     *
     * @param resourceLocation key mapping identifier for defining name and category keys
     * @return key mapping instance
     */
    static class_304 registerUnboundKeyMapping(class_2960 resourceLocation) {
        return registerKeyMapping(resourceLocation, class_3675.field_16237.method_1444());
    }

    /**
     * Register a modded key mapping with a custom category.
     *
     * @param resourceLocation key mapping identifier for defining name and category keys
     * @param keyCode          the default key, get the value from {@link net.minecraft.class_3675}
     * @return key mapping instance
     */
    static class_304 registerKeyMapping(class_2960 resourceLocation, int keyCode) {
        return new class_304("key." + resourceLocation.method_12832(),
                keyCode,
                "key.categories." + resourceLocation.method_12836());
    }

    /**
     * Checks if a key mapping is pressed.
     * <p>
     * NeoForge replaces the vanilla call to {@link class_304#matches(KeyEvent)} in a few places to account for key
     * activation contexts (game &amp; screen environments).
     *
     * @param keyMapping the key mapping
     * @param keyEvent   the key event
     * @return is the key mapping pressed
     */
    static boolean isKeyActiveAndMatches(class_304 keyMapping, int keyCode, int scanCode) {
        return ClientProxyImpl.get().isKeyActiveAndMatches(keyMapping, keyCode, scanCode);
    }

    /**
     * Checks if a key mapping is pressed.
     * <p>
     * Similar to {@link class_304#matches(KeyEvent)}, but for code points.
     * <p>
     * Useful when working with {@link net.minecraft.class_309#charTyped(long, CharacterEvent)}.
     *
     * @param keyMapping the key mapping
     * @param codePoint  the code point
     * @return is the key mapping pressed
     */
    static boolean matchesCodePoint(class_304 keyMapping, int codePoint) {
        if (keyMapping.field_1655.method_1442() == class_3675.class_307.field_1668 && !keyMapping.method_1415()) {
            String string = new String(Character.toChars(codePoint));
            String keyName = GLFW.glfwGetKeyName(keyMapping.field_1655.method_1444(), -1);
            return keyName != null && keyName.equalsIgnoreCase(string);
        } else {
            return false;
        }
    }
}
