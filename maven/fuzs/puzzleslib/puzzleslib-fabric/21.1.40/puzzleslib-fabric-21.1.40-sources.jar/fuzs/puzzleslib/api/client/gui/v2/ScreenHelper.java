package fuzs.puzzleslib.api.client.gui.v2;

import fuzs.puzzleslib.impl.client.core.proxy.ClientProxyImpl;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_329;

/**
 * A {@link net.minecraft.class_437} related helper class.
 */
public final class ScreenHelper {

    private ScreenHelper() {
        // NO-OP
    }

    /**
     * Get the current partial tick time; respecting whether the game is paused.
     *
     * @return the current partial tick time
     */
    public static float getPartialTick() {
        return class_310.method_1551().method_60646().method_60637(false);
    }

    /**
     * @return the current mouse x-position
     */
    public static int getMouseX() {
        class_310 minecraft = class_310.method_1551();
        return (int) (minecraft.field_1729.method_1603() * minecraft.method_22683().method_4486() / minecraft.method_22683()
                .method_4480());
    }

    /**
     * @return the current mouse y-position
     */
    public static int getMouseY() {
        class_310 minecraft = class_310.method_1551();
        return (int) (minecraft.field_1729.method_1604() * minecraft.method_22683().method_4502() / minecraft.method_22683()
                .method_4507());
    }

    /**
     * Checks if the mouse cursor is hovering in a defined region.
     *
     * @param posX   the x-start of the hover area
     * @param posY   the y-start of the hover area
     * @param width  the width from x-start of the hover area
     * @param height the height from y-start of the hover area
     * @param mouseX the mouse x-position
     * @param mouseY the mouse y-position
     * @return is the mouse cursor hovering the defined region
     */
    public static boolean isHovering(int posX, int posY, int width, int height, double mouseX, double mouseY) {
        return mouseX >= posX && mouseX < posX + width && mouseY >= posY && mouseY < posY + height;
    }

    /**
     * Can a mob effect render in the player inventory via
     * {@link net.minecraft.client.gui.screens.inventory.EffectsInInventory}.
     *
     * @param mobEffect the mob effect
     * @return is rendering permitted
     */
    public static boolean isEffectVisibleInInventory(class_1293 mobEffect) {
        return ClientProxyImpl.get().isEffectVisibleInInventory(mobEffect);
    }

    /**
     * Can a mob effect render in the {@link class_329}.
     *
     * @param mobEffect the mob effect
     * @return is rendering permitted
     */
    public static boolean isEffectVisibleInGui(class_1293 mobEffect) {
        return ClientProxyImpl.get().isEffectVisibleInGui(mobEffect);
    }
}
