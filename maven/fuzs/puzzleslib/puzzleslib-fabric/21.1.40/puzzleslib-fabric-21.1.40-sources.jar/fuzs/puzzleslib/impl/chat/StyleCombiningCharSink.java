package fuzs.puzzleslib.impl.chat;

import fuzs.puzzleslib.api.util.v1.ComponentHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5224;
import net.minecraft.class_5250;

public class StyleCombiningCharSink implements class_5224 {
    private final List<Map.Entry<StringBuilder, class_2583>> stringBuilders;

    public StyleCombiningCharSink() {
        this.stringBuilders = new ArrayList<>(List.of(Map.entry(new StringBuilder(), class_2583.field_24360)));
    }

    @Override
    public boolean accept(int width, class_2583 style, int codePoint) {
        Map.Entry<StringBuilder, class_2583> entry = this.stringBuilders.getLast();
        StringBuilder stringBuilder;

        // do not sanitise the style here already, so we can check for equality
        if (entry.getValue() == style || entry.getValue().method_10967() && style.method_10967()) {
            stringBuilder = entry.getKey();
        } else {
            stringBuilder = new StringBuilder();
            this.stringBuilders.add(Map.entry(stringBuilder, style));
        }

        stringBuilder.appendCodePoint(codePoint);
        return true;
    }

    public class_2561 getAsComponent() {
        Stream.Builder<class_5250> builder = Stream.builder();
        this.iterate((String string, class_2583 style) -> {
            builder.accept(class_2561.method_43470(string).method_27696(style));
        });

        return builder.build().reduce(class_5250::method_10852).orElseGet(class_2561::method_43473);
    }

    public String getAsString() {
        StringBuilder builder = new StringBuilder();
        this.iterate((String string, class_2583 style) -> {
            if (!style.method_10967()) {
                builder.append(ComponentHelper.getAsString(style));
            }

            builder.append(string);

            if (!style.method_10967()) {
                builder.append(class_124.field_1070);
            }
        });

        return builder.toString();
    }

    private void iterate(BiConsumer<String, class_2583> componentConsumer) {
        for (Map.Entry<StringBuilder, class_2583> entry : this.stringBuilders) {
            if (!entry.getKey().isEmpty() || !entry.getValue().method_10967()) {
                class_2583 style = ComponentHelper.sanitizeLegacyFormat(entry.getValue());
                componentConsumer.accept(entry.getKey().toString(), style);
            }
        }
    }

    @FunctionalInterface
    public interface FormattedContentComposer<T> extends Function<StyleCombiningCharSink, T> {

    }
}
