package fuzs.puzzleslib.impl.attachment;

import io.netty.buffer.ByteBuf;
import java.util.Optional;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundEntityDataAttachmentMessage<V>(class_9154<ClientboundEntityDataAttachmentMessage<V>> messageType,
                                                        int entityId,
                                                        Optional<V> value) implements class_8710 {

    public static <V> class_9139<? super class_9129, ClientboundEntityDataAttachmentMessage<V>> streamCodec(class_9154<ClientboundEntityDataAttachmentMessage<V>> type, class_9139<? super class_9129, V> valueStreamCodec) {
        return class_9139.method_56435(class_9135.field_48550,
                ClientboundEntityDataAttachmentMessage::entityId,
                class_9135.method_56382((class_9139<ByteBuf, V>) valueStreamCodec),
                ClientboundEntityDataAttachmentMessage::value,
                (Integer entityId, Optional<V> value) -> {
                    return new ClientboundEntityDataAttachmentMessage<>(type, entityId, value);
                }
        );
    }

    @Override
    public class_9154<ClientboundEntityDataAttachmentMessage<V>> method_56479() {
        return this.messageType;
    }
}
