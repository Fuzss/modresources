package fuzs.puzzleslib.api.util.v1;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.*;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_5699;

/**
 * Additional codecs similar to {@link class_5699}.
 */
public final class CodecExtras {
    /**
     * A codec version of the serialization methods in {@link net.minecraft.class_1262}.
     */
    public static final Codec<class_2371<class_1799>> NON_NULL_ITEM_STACK_LIST_CODEC = nonNullList(class_1799.field_24671,
            Predicate.not(class_1799::method_7960),
            class_1799.field_8037);
    /**
     * Adapted from {@link class_2487#field_25128}.
     */
    public static final Codec<class_2499> LIST_TAG_CODEC = Codec.PASSTHROUGH.comapFlatMap((Dynamic<?> dynamic) -> {
        class_2520 tag = dynamic.convert(class_2509.field_11560).getValue();
        return tag instanceof class_2499 listTag ?
                DataResult.success(listTag == dynamic.getValue() ? listTag.method_10612() : listTag) :
                DataResult.error(() -> "Not a list tag: " + tag);
    }, (class_2499 listTag) -> new Dynamic<>(class_2509.field_11560, listTag.method_10612()));

    private CodecExtras() {
        // NO-OP
    }

    /**
     * Creates a codec for {@link class_2371}. List elements are stored together with their index.
     *
     * @param codec        the list element codec
     * @param filter       a filter for skipping empty elements, like empty item stacks
     * @param defaultValue the default empty value for the list
     * @param <T>          the list element type
     * @return the codec
     */
    public static <T> Codec<class_2371<T>> nonNullList(Codec<T> codec, Predicate<T> filter, @Nullable T defaultValue) {
        return RecordCodecBuilder.create(instance -> {
            return instance.group(class_5699.field_33441.fieldOf("size").forGetter(class_2371::size),
                    Codec.mapPair(class_5699.field_33441.fieldOf("slot"), codec.fieldOf("item"))
                            .codec()
                            .listOf()
                            .fieldOf("items")
                            .forGetter((class_2371<T> items) -> {
                                return IntStream.range(0, items.size())
                                        .mapToObj(index -> new Pair<>(index, items.get(index)))
                                        .filter(pair -> filter.test(pair.getSecond()))
                                        .toList();
                            })).apply(instance, (Integer size, List<Pair<Integer, T>> items) -> {
                class_2371<T> nonNullList = defaultValue != null ? class_2371.method_10213(size, defaultValue) :
                        class_2371.method_37434(size);
                for (Pair<Integer, T> pair : items) {
                    nonNullList.set(pair.getFirst(), pair.getSecond());
                }
                return nonNullList;
            });
        });
    }

    /**
     * A helper for turning results from {@link Encoder#encode(Object, DynamicOps, Object)} and
     * {@link Encoder#encodeStart(DynamicOps, Object)} into {@link class_2487} when
     * serializing using {@link class_2509}.
     * <p>
     * To be used with {@link Codec#flatMap(Function)}.
     *
     * @return the mapping function
     */
    public static Function<class_2520, DataResult<class_2487>> mapCompoundTag() {
        return (class_2520 tag) -> {
            return tag instanceof class_2487 compoundTag ? DataResult.success(compoundTag) :
                    DataResult.error(() -> "Not a compound tag: " + tag);
        };
    }

    /**
     * Creates a codec for a set of elements. Similar to {@link Codec#list(Codec)}.
     * <p>
     * Copied from {@code net.neoforged.neoforge.common.util.NeoForgeExtraCodecs#setOf}.
     *
     * @param codec the single element codec
     * @param <T>   the list element type
     * @return the list codec
     */
    public static <T> Codec<Set<T>> setOf(Codec<T> codec) {
        return Codec.list(codec).xmap(ImmutableSet::copyOf, ImmutableList::copyOf);
    }

    /**
     * A map codec that allows for key values that are not encoded as {@link net.minecraft.class_2519}, unlike
     * {@link Codec#unboundedMap(Codec, Codec)}.
     *
     * @param keyCodec   the map key codec
     * @param valueCodec the map value codec
     * @param <K>        the map key type
     * @param <V>        the map value type
     * @return the codec
     */
    public static <K, V> Codec<Map<K, V>> mapOf(Codec<K> keyCodec, Codec<V> valueCodec) {
        return mapOf(keyCodec.fieldOf("key"), valueCodec.fieldOf("value"));
    }

    /**
     * A map codec that allows for key values that are not encoded as {@link net.minecraft.class_2519}, unlike
     * {@link Codec#unboundedMap(Codec, Codec)}
     *
     * @param keyCodec   the map key codec
     * @param valueCodec the map value codec
     * @param <K>        the map key type
     * @param <V>        the map value type
     * @return the codec
     */
    public static <K, V> Codec<Map<K, V>> mapOf(MapCodec<K> keyCodec, MapCodec<V> valueCodec) {
        return Codec.mapPair(keyCodec, valueCodec).codec().listOf().xmap((List<Pair<K, V>> list) -> {
                    return list.stream()
                            .collect(ImmutableMap.<Pair<K, V>, K, V>toImmutableMap(Pair::getFirst, Pair::getSecond));
                },
                (Map<K, V> map) -> map.entrySet()
                        .stream()
                        .map((Map.Entry<K, V> entry) -> new Pair<>(entry.getKey(), entry.getValue()))
                        .toList());
    }

    /**
     * Creates a codec from a decoder. The returned codec can only decode, and will throw on any attempt to encode.
     * <p>
     * Copied from {@code net.neoforged.neoforge.common.util.NeoForgeExtraCodecs#decodeOnly}.
     *
     * @param decoder the decoder
     * @param <A>     the element type
     * @return the codec
     */
    public static <A> Codec<A> decodeOnly(Decoder<A> decoder) {
        return Codec.of(Codec.unit(() -> {
            throw new UnsupportedOperationException("Cannot encode with decode-only codec! Decoder:" + decoder);
        }), decoder, "DecodeOnly[" + decoder + "]");
    }

    /**
     * Create an {@link Enum} codec.
     *
     * @param enumClazz the enum class
     * @param <E>       the enum type
     * @return the codec
     */
    public static <E extends Enum<E>> Codec<E> fromEnum(Class<E> enumClazz) {
        return fromEnum(enumClazz::getEnumConstants);
    }

    /**
     * Create an {@link Enum} codec.
     *
     * @param enumValues the enum values
     * @param <E>        the enum type
     * @return the codec
     */
    public static <E extends Enum<E>> Codec<E> fromEnum(Supplier<E[]> enumValues) {
        return fromEnumWithMapping(enumValues, (E enumConstant) -> enumConstant.name().toLowerCase(Locale.ROOT));
    }

    /**
     * Create an {@link Enum} codec.
     *
     * @param enumValues  the enum values
     * @param keyFunction the string key extractor
     * @param <E>         the enum type
     * @return the codec
     */
    public static <E extends Enum<E>> Codec<E> fromEnumWithMapping(Supplier<E[]> enumValues, Function<E, String> keyFunction) {
        E[] enums = enumValues.get();
        Function<String, E> function = Arrays.stream(enums)
                .collect(ImmutableMap.toImmutableMap(keyFunction, Function.identity()))::get;
        return Codec.stringResolver(keyFunction, function);
    }
}
