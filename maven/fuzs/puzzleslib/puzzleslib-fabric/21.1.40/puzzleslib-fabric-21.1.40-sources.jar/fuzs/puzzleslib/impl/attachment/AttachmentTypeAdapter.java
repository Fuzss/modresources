package fuzs.puzzleslib.impl.attachment;

import net.minecraft.class_2960;

public interface AttachmentTypeAdapter<T, A> {

    class_2960 resourceLocation();

    boolean hasData(T holder);

    A getData(T holder);

    A setData(T holder, A value);

    A removeData(T holder);
}
