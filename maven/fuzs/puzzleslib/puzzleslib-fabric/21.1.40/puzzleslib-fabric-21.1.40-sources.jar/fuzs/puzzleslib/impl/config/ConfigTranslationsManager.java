package fuzs.puzzleslib.impl.config;

import com.electronwill.nightconfig.core.UnmodifiableConfig;
import fuzs.puzzleslib.impl.PuzzlesLibMod;
import net.minecraft.class_1078;
import net.minecraft.class_124;
import net.minecraft.class_2477;
import net.minecraft.class_2960;
import net.minecraft.class_3300;
import net.minecraft.class_3302;
import net.minecraft.class_4013;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import java.util.function.Function;

public final class ConfigTranslationsManager {
    public static final Map<String, String> TRANSLATIONS = new ConcurrentHashMap<>();

    private ConfigTranslationsManager() {
        // NO-OP
    }

    public static void onAddResourcePackReloadListeners(BiConsumer<class_2960, class_3302> consumer) {
        consumer.accept(PuzzlesLibMod.id("config_translations"),
                (class_4013) (class_3300 resourceManager) -> {
                    if (class_2477.method_10517() instanceof class_1078 clientLanguage) {
                        if (!(clientLanguage.field_5330 instanceof HashMap<String, String>)) {
                            clientLanguage.field_5330 = new HashMap<>(clientLanguage.field_5330);
                        }
                        TRANSLATIONS.forEach(clientLanguage.field_5330::putIfAbsent);
                    }
                });
    }

    public static void addModConfig(String modId, String configType, String fileName, ModConfigSpec configSpec) {
        addConfigTitle(modId);
        addConfigFile(modId, fileName, configType);
        addConfigValues(modId, configSpec.getSpec(), new ArrayList<>(), configSpec::getLevelComment);
    }

    static void addConfigValues(String modId, UnmodifiableConfig config, List<String> path, Function<List<String>, @Nullable String> levelCommentGetter) {
        for (UnmodifiableConfig.Entry entry : config.entrySet()) {
            addConfigValue(modId, entry.getKey());
            String comment;
            if (entry.getValue() instanceof ModConfigSpec.ValueSpec valueSpec) {
                comment = valueSpec.getComment();
            } else if (entry.getValue() instanceof UnmodifiableConfig) {
                path = new ArrayList<>(path);
                path.add(entry.getKey());
                comment = levelCommentGetter.apply(path);
                addConfigValues(modId, entry.getValue(), path, levelCommentGetter);
            } else {
                comment = null;
            }
            addConfigValueComment(modId, entry.getKey(), comment);
            addConfigValueButton(modId, entry.getKey());
        }
    }

    public static void addConfigTitle(String modId) {
        TRANSLATIONS.put(modId + ".configuration.title", "%s Configuration");
    }

    public static void addConfigFile(String modId, String fileName, String configType) {
        configType = getCapitalizedString(configType);
        fileName = fileName.replaceAll("[^a-zA-Z0-9]+", ".")
                .replaceFirst("^\\.", "")
                .replaceFirst("\\.$", "")
                .toLowerCase();
        TRANSLATIONS.put(modId + ".configuration.section." + fileName, configType + " Settings");
        TRANSLATIONS.put(modId + ".configuration.section." + fileName + ".title",
                "%s " + configType + " Configuration");
    }

    public static void addConfigValue(String modId, String valueName) {
        Objects.requireNonNull(valueName, "value name is null");
        addConfigValue(modId, Collections.singletonList(valueName));
    }

    public static void addConfigValue(String modId, List<String> valuePath) {
        TRANSLATIONS.put(modId + ".configuration." + valuePath.getLast(), getCapitalizedString(valuePath.getLast()));
    }

    public static void addConfigValueComment(String modId, String valueName, @Nullable String comment) {
        Objects.requireNonNull(valueName, "value name is null");
        addConfigValueComment(modId,
                Collections.singletonList(valueName),
                comment != null ? Arrays.asList(comment.split("\\R")) : Collections.emptyList());
    }

    public static void addConfigValueComment(String modId, List<String> valuePath, List<String> comments) {
        String value = String.join(System.lineSeparator(), getStylizedStrings(comments));
        // also put in empty strings, as translations are expected for config values without a comment as well
        TRANSLATIONS.put(modId + ".configuration." + valuePath.getLast() + ".tooltip", value);
    }

    public static void addConfigValueButton(String modId, String valueName) {
        Objects.requireNonNull(valueName, "value name is null");
        addConfigValueButton(modId, Collections.singletonList(valueName));
    }

    public static void addConfigValueButton(String modId, List<String> valuePath) {
        TRANSLATIONS.put(valuePath.getLast() + ".button", "Edit...");
        TRANSLATIONS.put(modId + ".configuration." + valuePath.getLast() + ".button", "Edit...");
    }

    static String getCapitalizedString(String s) {
        String[] strings = s.toLowerCase().split("[\\s_]+");
        StringJoiner joiner = new StringJoiner(" ");
        for (String string : strings) {
            joiner.add(StringUtils.capitalize(string));
        }
        return joiner.toString().replace(" And ", " & ").replace(" Or ", " / ");
    }

    static List<String> getStylizedStrings(List<String> strings) {
        strings = new ArrayList<>(strings);
        for (int i = 0; i < strings.size(); i++) {
            class_124 chatFormatting = i % 2 == 0 ? class_124.field_1054 : class_124.field_1065;
            strings.set(i, chatFormatting + strings.get(i) + class_124.field_1070);
        }
        return strings;
    }
}
