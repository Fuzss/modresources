package fuzs.puzzleslib.api.network.v4;

import fuzs.puzzleslib.api.network.v4.message.Message;
import fuzs.puzzleslib.api.util.v1.EntityHelper;
import org.jetbrains.annotations.ApiStatus;

import java.util.Objects;
import java.util.function.Consumer;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_3222;
import net.minecraft.class_8705;
import net.minecraft.class_8706;
import net.minecraft.class_8710;

/**
 * Helper class for sending {@link Message Messages}, {@link class_8710 CustomPacketPayloads} and
 * {@link class_2596 Packets} to the server and clients.
 */
public final class MessageSender {

    private MessageSender() {
        // NO-OP
    }

    /**
     * Send a message to the server.
     *
     * @param message the message to send
     */
    public static void broadcast(Message<? extends Message.Context<? extends class_8706>> message) {
        Objects.requireNonNull(message, "message is null");
        broadcast((class_8710) message);
    }

    /**
     * Send a payload to the server.
     *
     * @param payload the payload to send
     */
    @ApiStatus.Experimental
    public static void broadcast(class_8710 payload) {
        Objects.requireNonNull(payload, "payload is null");
        if (NetworkingHelper.hasChannel(NetworkingHelper.getClientPacketListener(), payload.method_56479())) {
            broadcast(NetworkingHelper.toServerboundPacket(payload));
        }
    }

    /**
     * Send a packet to the server.
     *
     * @param packet the packet to send
     */
    public static void broadcast(class_2596<?> packet) {
        Objects.requireNonNull(packet, "packet is null");
        class_2602 packetListener = NetworkingHelper.getClientPacketListener();
        class_2535 connection = NetworkingHelper.getConnection(packetListener);
        connection.method_10743(packet);
    }

    /**
     * Send a message to clients.
     *
     * @param playerSet the players to send to
     * @param message   the message to send
     */
    public static void broadcast(PlayerSet playerSet, Message<? extends Message.Context<? extends class_8705>> message) {
        Objects.requireNonNull(playerSet, "player set is null");
        Objects.requireNonNull(message, "message is null");
        broadcast(playerSet, (class_8710) message);
    }

    /**
     * Send a payload to clients.
     *
     * @param playerSet the players to send to
     * @param payload   the payload to send
     */
    @ApiStatus.Experimental
    public static void broadcast(PlayerSet playerSet, class_8710 payload) {
        Objects.requireNonNull(playerSet, "player set is null");
        Objects.requireNonNull(payload, "payload is null");
        broadcast((Consumer<class_3222> serverPlayerConsumer) -> {
            playerSet.apply((class_3222 serverPlayer) -> {
                if (NetworkingHelper.hasChannel(serverPlayer.field_13987, payload.method_56479())) {
                    serverPlayerConsumer.accept(serverPlayer);
                }
            });
        }, NetworkingHelper.toClientboundPacket(payload));
    }

    /**
     * Send a packet to clients.
     *
     * @param playerSet the players to send to
     * @param packet    the packet to send
     */
    public static void broadcast(PlayerSet playerSet, class_2596<?> packet) {
        Objects.requireNonNull(playerSet, "player set is null");
        Objects.requireNonNull(packet, "packet is null");
        playerSet.apply((class_3222 serverPlayer) -> {
            if (!EntityHelper.isFakePlayer(serverPlayer)) {
                serverPlayer.field_13987.method_14364(packet);
            }
        });
    }
}
