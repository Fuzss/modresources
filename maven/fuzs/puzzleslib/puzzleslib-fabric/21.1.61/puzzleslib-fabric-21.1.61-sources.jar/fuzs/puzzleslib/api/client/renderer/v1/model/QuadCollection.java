package fuzs.puzzleslib.api.client.renderer.v1.model;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Multimap;
import org.jetbrains.annotations.Nullable;

import java.util.Collection;
import java.util.List;
import net.minecraft.class_2350;
import net.minecraft.class_777;

/**
 * Copied from Minecraft 26.2.
 */
public class QuadCollection {
    public static final QuadCollection EMPTY = new QuadCollection(List.of(),
            List.of(),
            List.of(),
            List.of(),
            List.of(),
            List.of(),
            List.of(),
            List.of());
    private final List<class_777> all;
    private final List<class_777> unculled;
    private final List<class_777> north;
    private final List<class_777> south;
    private final List<class_777> east;
    private final List<class_777> west;
    private final List<class_777> up;
    private final List<class_777> down;

    private QuadCollection(List<class_777> all, List<class_777> unculled, List<class_777> north, List<class_777> south, List<class_777> east, List<class_777> west, List<class_777> up, List<class_777> down) {
        this.all = all;
        this.unculled = unculled;
        this.north = north;
        this.south = south;
        this.east = east;
        this.west = west;
        this.up = up;
        this.down = down;
    }

    public List<class_777> getQuads(@Nullable class_2350 direction) {
        return switch (direction) {
            case null -> this.unculled;
            case field_11043 -> this.north;
            case field_11035 -> this.south;
            case field_11034 -> this.east;
            case field_11039 -> this.west;
            case field_11036 -> this.up;
            case field_11033 -> this.down;
        };
    }

    public List<class_777> getAll() {
        return this.all;
    }

    public static class Builder {
        private final ImmutableList.Builder<class_777> unculledFaces = ImmutableList.builder();
        private final Multimap<class_2350, class_777> culledFaces = ArrayListMultimap.create();

        public Builder addCulledFace(class_2350 direction, class_777 quad) {
            this.culledFaces.put(direction, quad);
            return this;
        }

        public Builder addUnculledFace(class_777 quad) {
            this.unculledFaces.add(quad);
            return this;
        }

        public Builder addAll(QuadCollection quadCollection) {
            this.culledFaces.putAll(class_2350.field_11036, quadCollection.up);
            this.culledFaces.putAll(class_2350.field_11033, quadCollection.down);
            this.culledFaces.putAll(class_2350.field_11043, quadCollection.north);
            this.culledFaces.putAll(class_2350.field_11035, quadCollection.south);
            this.culledFaces.putAll(class_2350.field_11034, quadCollection.east);
            this.culledFaces.putAll(class_2350.field_11039, quadCollection.west);
            this.unculledFaces.addAll(quadCollection.unculled);
            return this;
        }

        private static QuadCollection createFromSublists(List<class_777> all, int unculledCount, int northCount, int southCount, int eastCount, int westCount, int upCount, int downCount) {
            int index = 0;
            List<class_777> unculled = all.subList(index, index += unculledCount);
            List<class_777> north = all.subList(index, index += northCount);
            List<class_777> south = all.subList(index, index += southCount);
            List<class_777> east = all.subList(index, index += eastCount);
            List<class_777> west = all.subList(index, index += westCount);
            List<class_777> up = all.subList(index, index += upCount);
            List<class_777> down = all.subList(index, index + downCount);
            return new QuadCollection(all, unculled, north, south, east, west, up, down);
        }

        public QuadCollection build() {
            ImmutableList<class_777> unculledFaces = this.unculledFaces.build();
            if (this.culledFaces.isEmpty()) {
                return unculledFaces.isEmpty() ? QuadCollection.EMPTY : new QuadCollection(unculledFaces,
                        unculledFaces,
                        List.of(),
                        List.of(),
                        List.of(),
                        List.of(),
                        List.of(),
                        List.of());
            }

            ImmutableList.Builder<class_777> quads = ImmutableList.builder();
            quads.addAll(unculledFaces);
            Collection<class_777> north = this.culledFaces.get(class_2350.field_11043);
            quads.addAll(north);
            Collection<class_777> south = this.culledFaces.get(class_2350.field_11035);
            quads.addAll(south);
            Collection<class_777> east = this.culledFaces.get(class_2350.field_11034);
            quads.addAll(east);
            Collection<class_777> west = this.culledFaces.get(class_2350.field_11039);
            quads.addAll(west);
            Collection<class_777> up = this.culledFaces.get(class_2350.field_11036);
            quads.addAll(up);
            Collection<class_777> down = this.culledFaces.get(class_2350.field_11033);
            quads.addAll(down);
            return createFromSublists(quads.build(),
                    unculledFaces.size(),
                    north.size(),
                    south.size(),
                    east.size(),
                    west.size(),
                    up.size(),
                    down.size());
        }
    }
}
