package fuzs.puzzleslib.api.event.v1.level;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.random.Weighted;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.levelgen.structure.Structure;

import java.util.List;

@FunctionalInterface
public interface GatherPotentialSpawnsCallback {
    EventInvoker<GatherPotentialSpawnsCallback> EVENT = EventInvoker.lookup(GatherPotentialSpawnsCallback.class);

    /**
     * Fires when building a list of all possible entities that can spawn at the specified location.
     *
     * @param serverLevel      the current level instance
     * @param structureManager the structure manager, used for applying {@link Structure#spawnOverrides()}
     * @param chunkGenerator   the chunk generator for calling
     *                         {@link ChunkGenerator#getMobsAt(Holder, StructureManager, MobCategory, BlockPos)}
     * @param mobCategory      the mob category to retrieve potential spawns for
     * @param blockPos         the block position the spawn attempt is made at
     * @param mobs             the vanilla list of mobs available for the given position
     */
    void onGatherPotentialSpawns(ServerLevel serverLevel, StructureManager structureManager, ChunkGenerator chunkGenerator, MobCategory mobCategory, BlockPos blockPos, List<Weighted<MobSpawnSettings.SpawnerData>> mobs);
}
