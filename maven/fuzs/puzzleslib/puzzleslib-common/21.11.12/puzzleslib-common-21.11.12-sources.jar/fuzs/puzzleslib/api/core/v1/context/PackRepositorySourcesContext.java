package fuzs.puzzleslib.api.core.v1.context;

import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.repository.RepositorySource;

/**
 * Register custom and built-in data &amp; resource packs.
 */
public interface PackRepositorySourcesContext {

    /**
     * Register an additional {@link RepositorySource} when a new
     * {@link net.minecraft.server.packs.repository.PackRepository} is created.
     * <p>
     * Context can be used for registering both client (for resource packs) and server (for data packs) repository
     * sources.
     *
     * @param repositorySource the repository source to add
     */
    void registerRepositorySource(RepositorySource repositorySource);

    /**
     * Register a built-in pack bundled with the mod.
     * <ul>
     *     <li>Data pack path: {@code data/<modId>/datapacks/<path>}</li>
     *     <li>Resource pack path: {@code assets/<modId>/resourcepacks/<path>}</li>
     * </ul>
     *
     * @param identifier       the name of the pack in the {@code resources} directory
     * @param displayName            the name component for the created pack
     * @param shouldAddAutomatically is this pack always enabled and cannot be turned off
     */
    void registerBuiltInPack(Identifier identifier, Component displayName, boolean shouldAddAutomatically);
}
