package fuzs.puzzleslib.common.impl.core.context;

import fuzs.puzzleslib.common.impl.PuzzlesLib;
import fuzs.puzzleslib.common.impl.core.ModContext;
import net.minecraft.resources.Identifier;
import org.apache.commons.lang3.function.Consumers;

import java.util.function.Consumer;
import java.util.function.Supplier;

public interface ModConstructorImpl<T> {

    void construct(String modId, T modConstructor);

    static <T> void construct(Identifier identifier, Supplier<T> modConstructorSupplier, Supplier<ModConstructorImpl<T>> constructionSupplier) {
        construct(identifier, modConstructorSupplier, constructionSupplier, Consumers.nop());
    }

    static <T> void construct(Identifier identifier, Supplier<T> modConstructorSupplier, Supplier<ModConstructorImpl<T>> constructionSupplier, Consumer<ModContext> runBeforeConstruction) {
        PuzzlesLib.LOGGER.info("Constructing components for {}", identifier);
        // build first to force the class being loaded for executing buildable elements
        T modConstructor = modConstructorSupplier.get();
        ModContext modContext = ModContext.get(identifier.getNamespace());
        runBeforeConstruction.accept(modContext);
        constructionSupplier.get().construct(identifier.getNamespace(), modConstructor);
    }
}
