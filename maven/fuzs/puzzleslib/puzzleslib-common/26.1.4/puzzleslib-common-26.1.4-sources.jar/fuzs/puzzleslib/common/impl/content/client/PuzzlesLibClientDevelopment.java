package fuzs.puzzleslib.common.impl.content.client;

import com.google.common.collect.ImmutableMap;
import com.mojang.blaze3d.platform.InputConstants;
import fuzs.puzzleslib.common.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.common.api.client.core.v1.context.GuiLayersContext;
import fuzs.puzzleslib.common.api.client.event.v1.gui.AddToastCallback;
import fuzs.puzzleslib.common.api.client.event.v1.gui.ScreenEvents;
import fuzs.puzzleslib.common.api.client.event.v1.gui.ScreenMouseEvents;
import fuzs.puzzleslib.common.api.client.event.v1.gui.ScreenOpeningCallback;
import fuzs.puzzleslib.common.api.client.gui.v2.ScreenHelper;
import fuzs.puzzleslib.common.api.event.v1.core.EventResult;
import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.common.impl.content.ServerPropertiesHelper;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.debug.DebugScreenEntries;
import net.minecraft.client.gui.components.debug.DebugScreenEntryStatus;
import net.minecraft.client.gui.components.debug.DebugScreenProfile;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.components.toasts.SystemToast;
import net.minecraft.client.gui.components.toasts.Toast;
import net.minecraft.client.gui.components.toasts.ToastManager;
import net.minecraft.client.gui.screens.LoadingOverlay;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.gui.screens.inventory.CreativeModeInventoryScreen;
import net.minecraft.client.gui.screens.worldselection.CreateWorldScreen;
import net.minecraft.client.gui.screens.worldselection.WorldCreationUiState;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.client.tutorial.TutorialSteps;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.storage.LevelSummary;
import net.minecraft.world.scores.DisplaySlot;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.Scoreboard;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Stream;

public class PuzzlesLibClientDevelopment implements ClientModConstructor {
    private static final Map<Identifier, DebugScreenEntryStatus> DEFAULT_DEBUG_SCREEN_PROFILE = Stream.of(
                    DebugScreenEntries.BIOME,
                    DebugScreenEntries.CHUNK_RENDER_STATS,
                    DebugScreenEntries.ENTITY_RENDER_STATS,
                    DebugScreenEntries.ENTITY_SPAWN_COUNTS,
                    DebugScreenEntries.FPS,
                    DebugScreenEntries.GAME_VERSION,
                    DebugScreenEntries.LIGHT_LEVELS,
                    DebugScreenEntries.LOCAL_DIFFICULTY,
                    DebugScreenEntries.LOOKING_AT_BLOCK_STATE,
                    DebugScreenEntries.LOOKING_AT_ENTITY,
                    DebugScreenEntries.LOOKING_AT_FLUID_STATE,
                    DebugScreenEntries.MEMORY,
                    DebugScreenEntries.PARTICLE_RENDER_STATS,
                    DebugScreenEntries.PLAYER_POSITION,
                    DebugScreenEntries.PLAYER_SECTION_POSITION,
                    DebugScreenEntries.SYSTEM_SPECS,
                    DebugScreenEntries.TPS)
            .collect(ImmutableMap.toImmutableMap(Function.identity(),
                    (Identifier identifier) -> DebugScreenEntryStatus.IN_OVERLAY));

    @Override
    public void onConstructMod() {
        registerEventHandlers();
        DebugScreenEntries.PROFILES = ImmutableMap.<DebugScreenProfile, Map<Identifier, DebugScreenEntryStatus>>builder()
                .putAll(DebugScreenEntries.PROFILES)
                .put(DebugScreenProfile.DEFAULT, DEFAULT_DEBUG_SCREEN_PROFILE)
                .buildKeepingLast();
    }

    private static void registerEventHandlers() {
        ScreenOpeningCallback.EVENT.register((@Nullable Screen oldScreen, @Nullable Screen newScreen) -> {
            if (newScreen instanceof TitleScreen screen) {
                screen.fading = false;
            } else if (newScreen instanceof CreateWorldScreen screen) {
                screen.getUiState().setGameMode(WorldCreationUiState.SelectedGameMode.CREATIVE);
                screen.getUiState().setAllowCommands(true);
            }

            return EventResultHolder.pass();
        });
        ScreenEvents.beforeInit(TitleScreen.class)
                .register((TitleScreen screen, int screenWidth, int screenHeight, List<AbstractWidget> widgets) -> {
                    if (screen.minecraft.getOverlay() instanceof LoadingOverlay loadingOverlay
                            && loadingOverlay.fadeOutStart != 0L) {
                        loadingOverlay.fadeOutStart = 0L;
                    }
                });
        AddToastCallback.EVENT.register((ToastManager toastManager, Toast toast) -> {
            if (toast instanceof SystemToast systemToast
                    && systemToast.getToken() == SystemToast.SystemToastId.UNSECURE_SERVER_WARNING) {
                // block the annoying unsecure server warning when joining a multiplayer server in offline mode
                return EventResult.INTERRUPT;
            } else {
                return EventResult.PASS;
            }
        });
        // required for EditBox mixin to work properly on all screens like ChatScreen
        ScreenMouseEvents.beforeMouseClick(Screen.class)
                .register((Screen screen, MouseButtonEvent mouseButtonEvent) -> {
                    for (GuiEventListener guiEventListener : screen.children()) {
                        if (guiEventListener instanceof EditBox && guiEventListener.mouseClicked(mouseButtonEvent,
                                ScreenHelper.isDoubleClick(mouseButtonEvent))) {
                            screen.setFocused(guiEventListener);
                            if (mouseButtonEvent.button() == InputConstants.MOUSE_BUTTON_LEFT) {
                                screen.setDragging(true);
                            }

                            return EventResult.INTERRUPT;
                        }
                    }

                    return EventResult.PASS;
                });
        ScreenMouseEvents.beforeMouseRelease(Screen.class)
                .register((Screen screen, MouseButtonEvent mouseButtonEvent) -> {
                    screen.setDragging(false);
                    return screen.getChildAt(mouseButtonEvent.x(), mouseButtonEvent.y())
                            .filter(EditBox.class::isInstance)
                            .filter((GuiEventListener guiEventListener) -> {
                                return guiEventListener.mouseReleased(mouseButtonEvent);
                            })
                            .isPresent() ? EventResult.INTERRUPT : EventResult.PASS;
                });
        ScreenMouseEvents.beforeMouseDrag(Screen.class)
                .register((Screen screen, MouseButtonEvent mouseButtonEvent, double dragX, double dragY) -> {
                    return screen.getFocused() instanceof EditBox && screen.isDragging()
                            && mouseButtonEvent.button() == InputConstants.MOUSE_BUTTON_LEFT && screen.getFocused()
                            .mouseDragged(mouseButtonEvent, dragX, dragY) ? EventResult.INTERRUPT : EventResult.PASS;
                });
    }

    @Override
    public void onClientSetup() {
        CreativeModeInventoryScreen.selectedTab = BuiltInRegistries.CREATIVE_MODE_TAB.getValueOrThrow(CreativeModeTabs.SEARCH);
        initializeScreenSkipper();
    }

    private static void initializeScreenSkipper() {
        // skip backup option when upgrading a world
        ScreenSkipper.create()
                .setTitleComponent("selectWorld.backupQuestion."
                        + LevelSummary.BackupStatus.FILE_FIXING_REQUIRED.getTranslationKey())
                .setButtonComponent("selectWorld.backupJoinSkipButton")
                .build();
        ScreenSkipper.create()
                .setTitleComponent("upgradeWorld.done")
                .setButtonComponent(CommonComponents.GUI_YES)
                .setLastTitleComponent("selectWorld.backupQuestion."
                        + LevelSummary.BackupStatus.FILE_FIXING_REQUIRED.getTranslationKey())
                .build();
        // skip experimental settings warning when loading a world
        ScreenSkipper.create()
                .setTitleComponent("selectWorld.backupQuestion.experimental")
                .setButtonComponent("selectWorld.backupJoinSkipButton")
                .build();
        ScreenSkipper.create()
                .setTitleComponent("selectWorld.warning.experimental.title")
                .setButtonComponent(CommonComponents.GUI_YES)
                .build();
        // launch directly into the key binds screen from the control button
        ScreenSkipper.create()
                .setTitleComponent("controls.title")
                .setButtonComponent("controls.keybinds")
                .setLastTitleComponent("options.title")
                .build();
    }

    public static void setupGameOptions(Options options) {
        Minecraft minecraft = Minecraft.getInstance();
        Objects.requireNonNull(minecraft, "minecraft is null");
        // disable to prevent some options from accessing fields that have not yet been initialised
        boolean running = minecraft.running;
        minecraft.running = false;
        initializeGameOptions(options);
        minecraft.running = running;
        // no need to save preemptively, we will just apply our settings again if necessary
    }

    public static void initializeGameOptions(Options options) {
        boolean optionsStillMissing = !options.getFile().exists();
        unbindKey(options.keyLoadHotbarActivator, optionsStillMissing);
        unbindKey(options.keySaveHotbarActivator, optionsStillMissing);
        unbindKey(options.keyCommand, optionsStillMissing);
        unbindKey(options.keySocialInteractions, optionsStillMissing);
        unbindKey(options.keyAdvancements, optionsStillMissing);
        unbindKey(options.keyQuickActions, optionsStillMissing);
        unbindKey(options.keyFullscreen, optionsStillMissing);
        if (optionsStillMissing) {
            options.renderDistance().set(16);
            options.framerateLimit().set(60);
            options.narratorHotkey().set(false);
            options.advancedItemTooltips = true;
            options.tutorialStep = TutorialSteps.NONE;
            options.joinedFirstServer = true;
            options.operatorItemsTab().set(true);
            options.realmsNotifications().set(false);
            options.showSubtitles().set(true);
            options.guiScale().set(8);
            options.onboardAccessibility = false;
            options.skipMultiplayerWarning = true;
            options.damageTiltStrength().set(0.0);
            options.lastMpIp = ServerPropertiesHelper.getHostAddress()
                    .map((String string) -> string + ":25565")
                    .orElse("");
        }
    }

    private static void unbindKey(KeyMapping keyMapping, boolean optionsStillMissing) {
        keyMapping.defaultKey = InputConstants.UNKNOWN;
        if (optionsStillMissing) {
            keyMapping.setKey(InputConstants.UNKNOWN);
        }
    }

    @Override
    public void onRegisterGuiLayers(GuiLayersContext context) {
        context.replaceGuiLayer(GuiLayersContext.PLAYER_LIST, (GuiLayersContext.Layer layer) -> {
            return (GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker) -> {
                Minecraft minecraft = Minecraft.getInstance();
                Scoreboard scoreboard = minecraft.level.getScoreboard();
                Objective objective = scoreboard.getDisplayObjective(DisplaySlot.LIST);
                if (minecraft.options.keyPlayerList.isDown() && minecraft.isLocalServer()
                        && minecraft.player.connection.getListedOnlinePlayers().size() <= 1 && objective == null) {
                    minecraft.gui.tabList.setVisible(true);
                    minecraft.gui.tabList.extractRenderState(guiGraphics, guiGraphics.guiWidth(), scoreboard, null);
                } else {
                    layer.extractRenderState(guiGraphics, deltaTracker);
                }
            };
        });
    }
}
