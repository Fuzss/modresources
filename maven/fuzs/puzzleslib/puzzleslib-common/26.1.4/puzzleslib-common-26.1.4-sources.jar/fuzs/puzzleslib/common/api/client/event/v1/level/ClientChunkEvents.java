package fuzs.puzzleslib.common.api.client.event.v1.level;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.level.chunk.LevelChunk;

public final class ClientChunkEvents {
    public static final EventInvoker<Load> LOAD = EventInvoker.lookup(Load.class);
    public static final EventInvoker<Unload> UNLOAD = EventInvoker.lookup(Unload.class);

    private ClientChunkEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Load {

        /**
         * Fires before a client chunk is loaded.
         *
         * @param clientLevel the client level the chunk is in
         * @param chunk       the chunk being loaded
         */
        void onChunkLoad(ClientLevel clientLevel, LevelChunk chunk);
    }

    @FunctionalInterface
    public interface Unload {

        /**
         * Fires before a client chunk is unloaded.
         *
         * @param clientLevel the client level the chunk is in
         * @param chunk       the chunk being unloaded
         */
        void onChunkUnload(ClientLevel clientLevel, LevelChunk chunk);
    }
}
