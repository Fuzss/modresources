package fuzs.puzzleslib.common.api.data.v2;

import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.Lifecycle;
import fuzs.puzzleslib.common.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.common.api.init.v3.family.BlockSetFamily;
import fuzs.puzzleslib.common.api.init.v3.family.BlockSetVariant;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.minecraft.core.*;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.data.loot.EntityLootSubProvider;
import net.minecraft.data.loot.LootTableSubProvider;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.util.ProblemReporter;
import net.minecraft.util.Util;
import net.minecraft.util.context.ContextKeySet;
import net.minecraft.world.RandomSequence;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.RandomSupport;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.ValidationContextSource;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.functions.CopyComponentsFunction;
import net.minecraft.world.level.storage.loot.parameters.LootContextParamSets;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import org.apache.commons.lang3.StringUtils;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public final class AbstractLootProvider {

    private AbstractLootProvider() {
        // NO-OP
    }

    public static abstract class Blocks extends BlockLootSubProvider implements LootTableDataProvider {
        /**
         * @see #generateFor(BlockSetFamily, Map)
         */
        public static final Map<BlockSetVariant, BiConsumer<AbstractLootProvider.Blocks, Block>> VARIANT_PROVIDERS = ImmutableMap.<BlockSetVariant, BiConsumer<AbstractLootProvider.Blocks, Block>>builder()
                .put(BlockSetVariant.CHISELED, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.CRACKED, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.POLISHED, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.CUT, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.MOSAIC, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.STAIRS, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.SLAB, (AbstractLootProvider.Blocks provider, Block block) -> {
                    provider.add(block, provider::createSlabItemTable);
                })
                .put(BlockSetVariant.WALL, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.FENCE, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.FENCE_GATE, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.DOOR, (AbstractLootProvider.Blocks provider, Block block) -> {
                    provider.add(block, provider::createDoorTable);
                })
                .put(BlockSetVariant.TRAPDOOR, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.BUTTON, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.PRESSURE_PLATE, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.SIGN, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.HANGING_SIGN, BlockLootSubProvider::dropSelf)
                .put(BlockSetVariant.SHELF, BlockLootSubProvider::dropSelf)
                .build();

        private final Set<ResourceKey<LootTable>> skipValidation = new HashSet<>();
        private final PackOutput.PathProvider pathProvider;
        private final CompletableFuture<HolderLookup.Provider> registries;
        private final String modId;

        public Blocks(DataProviderContext context) {
            this(context.getModId(), context.getPackOutput(), context.getRegistries());
        }

        public Blocks(String modId, PackOutput packOutput, CompletableFuture<HolderLookup.Provider> registries) {
            // we set the correct lookup provider just before we run data generation, it is not available here yet
            super(Collections.emptySet(), FeatureFlags.REGISTRY.allFlags(), RegistryAccess.EMPTY);
            this.pathProvider = packOutput.createRegistryElementsPathProvider(Registries.LOOT_TABLE);
            this.registries = registries;
            this.modId = modId;
        }

        @Override
        public CompletableFuture<?> run(CachedOutput output) {
            return this.registries.thenApply((HolderLookup.Provider registries) -> {
                return super.registries = registries;
            }).thenCompose((HolderLookup.Provider registries) -> {
                return this.run(output, registries);
            }).thenRun(() -> {
                super.registries = RegistryAccess.EMPTY;
            });
        }

        @Override
        public String getName() {
            return "Block Loot Tables";
        }

        @Override
        public final void generate() {
            this.addLootTables();
        }

        public abstract void addLootTables();

        @Override
        public void generate(BiConsumer<ResourceKey<LootTable>, LootTable.Builder> consumer) {
            this.generate();
            Set<ResourceKey<LootTable>> lootTables = new HashSet<>();
            this.getRegistryEntries().forEach((Holder.Reference<Block> holder) -> {
                Optional<ResourceKey<LootTable>> optional = holder.value().getLootTable();
                if (optional.isPresent()) {
                    ResourceKey<LootTable> resourceKey = optional.get();
                    if (lootTables.add(resourceKey)) {
                        LootTable.Builder builder = this.map.remove(resourceKey);
                        if (builder != null) {
                            consumer.accept(resourceKey, builder);
                        } else if (!this.skipValidationFor(resourceKey)) {
                            throw new IllegalStateException("Missing loot table '%s' for '%s'".formatted(optional,
                                    holder.key().identifier()));
                        }
                    }
                }
            });
            if (!this.map.isEmpty()) {
                throw new IllegalStateException("Created block loot tables for non-blocks: " + this.map.keySet());
            }
        }

        @Override
        public HolderLookup.Provider registries() {
            Preconditions.checkState(super.registries != RegistryAccess.EMPTY, "registry access is empty");
            return super.registries;
        }

        @Override
        public PackOutput.PathProvider pathProvider() {
            return this.pathProvider;
        }

        @Override
        public ContextKeySet paramSet() {
            return LootContextParamSets.BLOCK;
        }

        @Override
        public boolean skipValidationFor(ResourceKey<LootTable> resourceKey) {
            return this.skipValidation.contains(resourceKey);
        }

        public void skipValidation(Identifier identifier) {
            this.skipValidation(ResourceKey.create(Registries.LOOT_TABLE, identifier));
        }

        public void skipValidation(ResourceKey<LootTable> resourceKey) {
            this.skipValidation.add(resourceKey);
        }

        public void skipValidation(Block block) {
            block.getLootTable().ifPresent(this::skipValidation);
        }

        public void dropNothing(Block block) {
            this.add(block, noDrop());
        }

        public void dropNameable(Block block) {
            this.add(block, this::createNameableBlockEntityTable);
        }

        public LootTable.Builder createHeadDrop(Block block) {
            // explosion condition is not applied on purpose; all vanilla heads are explosion-resistant
            return LootTable.lootTable()
                    .withPool(LootPool.lootPool()
                            .setRolls(ConstantValue.exactly(1.0F))
                            .add(LootItem.lootTableItem(block)
                                    .apply(CopyComponentsFunction.copyComponentsFromBlockEntity(LootContextParams.BLOCK_ENTITY)
                                            .include(DataComponents.NOTE_BLOCK_SOUND)
                                            .include(DataComponents.CUSTOM_NAME)))
                            .unwrap());
        }

        public final void generateFor(BlockSetFamily blockSetFamily, Map<BlockSetVariant, BiConsumer<AbstractLootProvider.Blocks, Block>> variants) {
            blockSetFamily.getBlockVariants().forEach((BlockSetVariant variant, Holder.Reference<Block> block) -> {
                BiConsumer<AbstractLootProvider.Blocks, Block> provider = variants.get(variant);
                if (provider != null) {
                    provider.accept(this, block.value());
                }
            });
        }

        protected Stream<Holder.Reference<Block>> getRegistryEntries() {
            return BuiltInRegistries.BLOCK.listElements()
                    .filter((Holder.Reference<Block> holder) -> holder.key()
                            .identifier()
                            .getNamespace()
                            .equals(this.modId));
        }
    }

    public abstract static class EntityTypes extends EntityLootSubProvider implements LootTableDataProvider {
        private final Set<ResourceKey<LootTable>> skipValidation = new HashSet<>();
        private final PackOutput.PathProvider pathProvider;
        private final CompletableFuture<HolderLookup.Provider> registries;
        private final String modId;

        public EntityTypes(DataProviderContext context) {
            this(context.getModId(), context.getPackOutput(), context.getRegistries());
        }

        public EntityTypes(String modId, PackOutput packOutput, CompletableFuture<HolderLookup.Provider> registries) {
            // we set the correct lookup provider just before we run data generation, it is not available here yet
            super(FeatureFlags.REGISTRY.allFlags(), RegistryAccess.EMPTY);
            this.pathProvider = packOutput.createRegistryElementsPathProvider(Registries.LOOT_TABLE);
            this.registries = registries;
            this.modId = modId;
        }

        @Override
        public CompletableFuture<?> run(CachedOutput output) {
            return this.registries.thenCompose((HolderLookup.Provider registries) -> {
                super.registries = registries;
                return this.run(output, registries).thenRun(() -> {
                    super.registries = RegistryAccess.EMPTY;
                });
            });
        }

        @Override
        public String getName() {
            return "Entity Type Loot Tables";
        }

        @Override
        public final void generate() {
            this.addLootTables();
        }

        public abstract void addLootTables();

        @Override
        public void generate(BiConsumer<ResourceKey<LootTable>, LootTable.Builder> consumer) {
            this.generate();
            Set<ResourceKey<LootTable>> lootTables = new HashSet<>();
            this.getRegistryEntries().forEach((Holder.Reference<EntityType<?>> holder) -> {
                EntityType<?> entityType = holder.value();
                Map<ResourceKey<LootTable>, LootTable.Builder> map = this.map.remove(entityType);
                if (this.canHaveLootTable(entityType)) {
                    Optional<ResourceKey<LootTable>> optional = entityType.getDefaultLootTable();
                    if (optional.isPresent()) {
                        ResourceKey<LootTable> resourceKey = optional.get();
                        if (!this.skipValidationFor(resourceKey) && (map == null || !map.containsKey(resourceKey))) {
                            throw new IllegalStateException(String.format(Locale.ROOT,
                                    "Missing loot table '%s' for '%s'",
                                    resourceKey,
                                    holder.key().identifier()));
                        }
                    }
                    if (map != null) {
                        map.forEach((identifier, builder) -> {
                            if (!lootTables.add(identifier)) {
                                throw new IllegalStateException(String.format(Locale.ROOT,
                                        "Duplicate loot table '%s' for '%s'",
                                        identifier,
                                        holder.key().identifier()));
                            } else {
                                consumer.accept(identifier, builder);
                            }
                        });
                    }
                } else if (map != null) {
                    throw new IllegalStateException(String.format(Locale.ROOT,
                            "Weird loot table(s) '%s' for '%s', not a LivingEntity so should not have loot",
                            map.keySet()
                                    .stream()
                                    .map(ResourceKey::identifier)
                                    .map(Identifier::toString)
                                    .collect(Collectors.joining(",")),
                            holder.key().identifier()));
                }
            });
            if (!this.map.isEmpty()) {
                throw new IllegalStateException(
                        "Created loot tables for entities not supported by data pack: " + this.map.keySet());
            }
        }

        @Override
        public HolderLookup.Provider registries() {
            Preconditions.checkState(super.registries != RegistryAccess.EMPTY, "registry access is empty");
            return super.registries;
        }

        @Override
        public PackOutput.PathProvider pathProvider() {
            return this.pathProvider;
        }

        @Override
        public ContextKeySet paramSet() {
            return LootContextParamSets.ENTITY;
        }

        @Override
        public boolean skipValidationFor(ResourceKey<LootTable> resourceKey) {
            return this.skipValidation.contains(resourceKey);
        }

        public void skipValidation(Identifier identifier) {
            this.skipValidation(ResourceKey.create(Registries.LOOT_TABLE, identifier));
        }

        public void skipValidation(ResourceKey<LootTable> resourceKey) {
            this.skipValidation.add(resourceKey);
        }

        public void skipValidation(EntityType<?> entityType) {
            entityType.getDefaultLootTable().ifPresent(this::skipValidation);
        }

        protected boolean canHaveLootTable(EntityType<?> entityType) {
            return entityType.getCategory() != MobCategory.MISC;
        }

        protected Stream<Holder.Reference<EntityType<?>>> getRegistryEntries() {
            return BuiltInRegistries.ENTITY_TYPE.listElements()
                    .filter((Holder.Reference<EntityType<?>> holder) -> holder.key()
                            .identifier()
                            .getNamespace()
                            .equals(this.modId));
        }
    }

    public static abstract class Simple implements LootTableDataProvider {
        private final Map<ResourceKey<LootTable>, LootTable.Builder> values = new LinkedHashMap<>();
        private final Set<ResourceKey<LootTable>> skipValidation = new HashSet<>();
        private final ContextKeySet paramSet;
        private final PackOutput.PathProvider pathProvider;
        private final CompletableFuture<HolderLookup.Provider> registries;
        private HolderLookup.Provider registryAccess;

        public Simple(ContextKeySet paramSet, DataProviderContext context) {
            this(paramSet, context.getPackOutput(), context.getRegistries());
        }

        public Simple(ContextKeySet paramSet, PackOutput packOutput, CompletableFuture<HolderLookup.Provider> registries) {
            this.paramSet = paramSet;
            this.pathProvider = packOutput.createRegistryElementsPathProvider(Registries.LOOT_TABLE);
            this.registries = registries;
            this.registryAccess = RegistryAccess.EMPTY;
        }

        @Override
        public CompletableFuture<?> run(CachedOutput output) {
            return this.registries.thenCompose((HolderLookup.Provider registries) -> {
                this.registryAccess = registries;
                return this.run(output, registries).thenRun(() -> {
                    this.registryAccess = RegistryAccess.EMPTY;
                });
            });
        }

        @Override
        public String getName() {
            // multiple data providers cannot have the same name, so handle this like so
            return String.join(" ", StringUtils.splitByCharacterTypeCamelCase(this.getClass().getSimpleName()));
        }

        @Override
        public void generate(BiConsumer<ResourceKey<LootTable>, LootTable.Builder> exporter) {
            this.addLootTables();
            this.values.forEach(exporter);
        }

        @Override
        public HolderLookup.Provider registries() {
            Preconditions.checkState(this.registryAccess != RegistryAccess.EMPTY, "registry access is empty");
            return this.registryAccess;
        }

        @Override
        public PackOutput.PathProvider pathProvider() {
            return this.pathProvider;
        }

        @Override
        public ContextKeySet paramSet() {
            return this.paramSet;
        }

        @Override
        public boolean skipValidationFor(ResourceKey<LootTable> resourceKey) {
            return this.skipValidation.contains(resourceKey);
        }

        public void skipValidation(Identifier identifier) {
            this.skipValidation(ResourceKey.create(Registries.LOOT_TABLE, identifier));
        }

        public void skipValidation(ResourceKey<LootTable> resourceKey) {
            this.skipValidation.add(resourceKey);
        }

        protected void add(ResourceKey<LootTable> table, LootTable.Builder builder) {
            this.values.put(table, builder);
        }

        public abstract void addLootTables();
    }

    public interface LootTableDataProvider extends DataProvider, LootTableSubProvider {

        HolderLookup.Provider registries();

        PackOutput.PathProvider pathProvider();

        ContextKeySet paramSet();

        boolean skipValidationFor(ResourceKey<LootTable> resourceKey);

        default CompletableFuture<?> run(CachedOutput output, HolderLookup.Provider registries) {
            DefaultedMappedRegistry<LootTable> registry = new DefaultedMappedRegistry<>("empty",
                    Registries.LOOT_TABLE,
                    Lifecycle.experimental(),
                    false);
            ResourceKey<LootTable> defaultKey = ResourceKey.create(Registries.LOOT_TABLE, registry.getDefaultKey());
            registry.register(defaultKey, LootTable.EMPTY, RegistrationInfo.BUILT_IN);
            Map<RandomSupport.Seed128bit, Identifier> seeds = new Object2ObjectOpenHashMap<>();
            this.generate((ResourceKey<LootTable> resourceKey, LootTable.Builder builder) -> {
                Identifier identifier = resourceKey.identifier();
                Identifier oldIdentifier = seeds.put(RandomSequence.seedForKey(identifier), identifier);
                if (oldIdentifier != null) {
                    Util.logAndPauseIfInIde(
                            "Loot table random sequence seed collision on " + oldIdentifier + " and " + resourceKey);
                }

                builder.setRandomSequence(identifier);
                LootTable lootTable = builder.setParamSet(this.paramSet()).build();
                registry.register(resourceKey, lootTable, RegistrationInfo.BUILT_IN);
            });

            registry.freeze();
            this.validate(registry);

            return CompletableFuture.allOf(registry.entrySet()
                    .stream()
                    .filter((Map.Entry<ResourceKey<LootTable>, LootTable> entry) -> {
                        return entry.getKey() != defaultKey;
                    })
                    .map((Map.Entry<ResourceKey<LootTable>, LootTable> entry) -> {
                        ResourceKey<LootTable> resourceKey = entry.getKey();
                        LootTable lootTable = entry.getValue();
                        Path path = this.pathProvider().json(resourceKey.identifier());
                        return DataProvider.saveStable(output, registries, LootTable.DIRECT_CODEC, lootTable, path);
                    })
                    .toArray(CompletableFuture[]::new));
        }

        default void validate(Registry<LootTable> registry) {
            ProblemReporter.Collector collector = new ProblemReporter.Collector();
            HolderGetter.Provider registries = new RegistryAccess.ImmutableRegistryAccess(List.of(registry)).freeze();
            ValidationContextSource validationContext = new ValidationContextSource(collector, registries);
            registry.listElements().forEach((Holder.Reference<LootTable> holder) -> {
                this.validate(holder, validationContext);
            });
            if (!collector.isEmpty()) {
                collector.forEach((string, problem) -> LOGGER.warn("Found validation problem in {}: {}",
                        string,
                        problem.description()));
                throw new IllegalStateException("Failed to validate loot tables, see logs");
            }
        }

        default void validate(Holder.Reference<LootTable> holder, ValidationContextSource validationContext) {
            if (!this.skipValidationFor(holder.key())) {
                holder.value()
                        .validate(validationContext.context(holder.value().getParamSet())
                                .enterElement(new ProblemReporter.RootElementPathElement(holder.key()), holder.key()));
            }
        }
    }
}
