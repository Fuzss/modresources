package fuzs.puzzleslib.common.api.client.core.v1.context;

import net.minecraft.client.gui.render.pip.PictureInPictureRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.state.gui.pip.PictureInPictureRenderState;

import java.util.function.Function;

/**
 * Register renderers for custom gui elements, like an entity or the enchanting table book.
 * <p>
 * Requires the additional creation of a custom gui render state, which must be registered in
 * {@link
 * net.minecraft.client.renderer.state.gui.GuiRenderState#addPicturesInPictureState(PictureInPictureRenderState)}.
 */
public interface PictureInPictureRenderersContext {

    /**
     * @param renderStateClazz                the render state class type
     * @param pictureInPictureRendererFactory the factory for the custom renderer
     * @param <T>                             the supported render state
     */
    <T extends PictureInPictureRenderState> void registerPictureInPictureRenderer(Class<T> renderStateClazz, Function<MultiBufferSource.BufferSource, PictureInPictureRenderer<T>> pictureInPictureRendererFactory);
}
