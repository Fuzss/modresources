package fuzs.puzzleslib.common.api.data.v2;

import fuzs.puzzleslib.common.api.data.v2.core.DataProviderContext;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.advancements.AdvancementType;
import net.minecraft.advancements.DisplayInfo;
import net.minecraft.core.ClientAsset;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.data.advancements.AdvancementSubProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.ItemStackTemplate;
import org.jspecify.annotations.Nullable;

import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public abstract class AbstractAdvancementProvider implements DataProvider, AdvancementSubProvider {
    private final String modId;
    private final PackOutput.PathProvider pathProvider;
    private final CompletableFuture<HolderLookup.Provider> registries;

    public AbstractAdvancementProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput(), context.getRegistries());
    }

    public AbstractAdvancementProvider(String modId, PackOutput packOutput, CompletableFuture<HolderLookup.Provider> registries) {
        this.modId = modId;
        this.pathProvider = packOutput.createRegistryElementsPathProvider(Registries.ADVANCEMENT);
        this.registries = registries;
    }

    protected static DisplayInfo display(ItemStackTemplate itemStack, Identifier identifier) {
        return display(itemStack, identifier, AdvancementType.TASK);
    }

    protected static DisplayInfo display(ItemStackTemplate itemStack, Identifier identifier, AdvancementType advancementType) {
        return display(itemStack, identifier, null, advancementType, false);
    }

    protected static DisplayInfo display(ItemStackTemplate itemStack, Identifier identifier, @Nullable Identifier background, AdvancementType advancementType, boolean hidden) {
        return display(itemStack, identifier, background, advancementType, true, true, hidden);
    }

    protected static DisplayInfo display(ItemStackTemplate itemStack, Identifier identifier, @Nullable Identifier background, AdvancementType advancementType, boolean showToast, boolean announceChat, boolean hidden) {
        AdvancementToken advancementToken = new AdvancementToken(identifier);
        return new DisplayInfo(itemStack,
                advancementToken.title(),
                advancementToken.description(),
                Optional.ofNullable(background).map(ClientAsset.ResourceTexture::new),
                advancementType,
                true,
                true,
                hidden);
    }

    @Override
    public final CompletableFuture<?> run(CachedOutput output) {
        return this.registries.thenCompose((HolderLookup.Provider registries) -> {
            Set<Identifier> set = new HashSet<>();
            List<CompletableFuture<?>> list = new ArrayList<>();
            Consumer<AdvancementHolder> consumer = (AdvancementHolder holder) -> {
                Identifier identifier = Identifier.fromNamespaceAndPath(this.modId, holder.id().getPath());
                if (!set.add(identifier)) {
                    throw new IllegalStateException("Duplicate advancement " + identifier);
                } else {
                    Path path = this.pathProvider.json(identifier);
                    list.add(DataProvider.saveStable(output, registries, Advancement.CODEC, holder.value(), path));
                }
            };

            this.generate(registries, consumer);
            return CompletableFuture.allOf(list.toArray(CompletableFuture[]::new));
        });
    }

    @Override
    public final void generate(HolderLookup.Provider registries, Consumer<AdvancementHolder> writer) {
        this.addAdvancements(registries, writer);
    }

    public abstract void addAdvancements(HolderLookup.Provider registries, Consumer<AdvancementHolder> writer);

    @Override
    public String getName() {
        return "Advancements";
    }

    public record AdvancementToken(Identifier id) {

        public Component title() {
            return Component.translatable(this.id.toLanguageKey("advancements", "title"));
        }

        public Component description() {
            return Component.translatable(this.id.toLanguageKey("advancements", "description"));
        }

        public AdvancementHolder asParent() {
            // workaround for getting the proper parent id,
            // the advancement holder from saving the builder always has the `minecraft` namespace set
            // (which we replace when running the data generator which happens later though)
            return new AdvancementHolder(this.id, null);
        }

        public String name() {
            return this.id.getPath();
        }
    }
}
