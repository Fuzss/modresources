package fuzs.puzzleslib.impl.init;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.api.core.v1.ModLoader;
import fuzs.puzzleslib.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.api.init.v3.registry.RegistryManager;
import fuzs.puzzleslib.api.util.v1.ARGB;
import fuzs.puzzleslib.api.util.v1.HSV;
import fuzs.puzzleslib.impl.core.Freezable;
import fuzs.puzzleslib.impl.item.CreativeModeTabHelper;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;

public abstract class RegistryManagerImpl implements RegistryManager, Freezable {
    protected final String modId;
    protected Set<ModLoader> allowedModLoaders = EnumSet.allOf(ModLoader.class);

    protected RegistryManagerImpl(String modId) {
        this.modId = modId;
        Preconditions.checkArgument(StringUtils.isNotEmpty(modId), "mod id is invalid");
    }

    @Override
    public ResourceLocation makeKey(String path) {
        Preconditions.checkArgument(StringUtils.isNotEmpty(path), "path is invalid");
        return ResourceLocation.fromNamespaceAndPath(this.modId, path);
    }

    @Override
    public RegistryManager whenOn(ModLoader... allowedModLoaders) {
        Preconditions.checkState(allowedModLoaders.length > 0, "mod loaders is empty");
        this.allowedModLoaders = EnumSet.copyOf(Arrays.asList(allowedModLoaders));
        return this;
    }

    @Override
    public final <T> Holder.Reference<T> register(final ResourceKey<? extends Registry<? super T>> registryKey, String path, Supplier<T> supplier) {
        this.isWritableOrThrow();
        return this.register(registryKey, path, supplier, false);
    }

    public final <T> Holder.Reference<T> register(final ResourceKey<? extends Registry<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Preconditions.checkArgument(StringUtils.isNotEmpty(path), "path is invalid");
        Objects.requireNonNull(supplier, "supplier is null");
        Holder.Reference<T> holder;
        if (!this.allowedModLoaders.contains(ModLoaderEnvironment.INSTANCE.getModLoader())) {
            holder = this.registerLazily(registryKey, path);
        } else {
            holder = this.getHolderReference(registryKey, path, supplier, skipRegistration);
        }
        this.allowedModLoaders = EnumSet.allOf(ModLoader.class);
        Objects.requireNonNull(holder, "holder is null");
        return holder;
    }

    protected abstract <T> Holder.Reference<T> getHolderReference(ResourceKey<? extends Registry<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration);

    @Override
    public Holder.Reference<Item> registerLegacySpawnEggItem(Holder<? extends EntityType<? extends Mob>> entityTypeHolder, int backgroundColor) {
        return this.registerLegacySpawnEggItem(entityTypeHolder,
                backgroundColor,
                this.generateSpawnEggHighlightColor(backgroundColor));
    }

    /**
     * @author ChatGPT
     */
    private int generateSpawnEggHighlightColor(int backgroundColor) {
        // Convert base color to HSB
        int hsv = HSV.rgbToHsv(ARGB.redFloat(backgroundColor),
                ARGB.greenFloat(backgroundColor),
                ARGB.blueFloat(backgroundColor));
        // Modify saturation and brightness
        float saturation = Math.min(1.0F, HSV.saturationFloat(hsv) * 1.2F);
        float value = Math.max(0.0F, HSV.valueFloat(hsv) * 0.75F);
        // Convert back to RGB
        return Mth.hsvToRgb(HSV.hueFloat(hsv), saturation, value);
    }

    @Override
    public Holder.Reference<CreativeModeTab> registerCreativeModeTab(String path, Supplier<ItemStack> iconSupplier, CreativeModeTab.DisplayItemsGenerator displayItems, boolean withSearchBar) {
        return this.register(Registries.CREATIVE_MODE_TAB, path, () -> {
            CreativeModeTab.Builder builder = this.getCreativeModeTabBuilder(withSearchBar);
            ResourceLocation resourceLocation = this.makeKey(path);
            builder.title(CreativeModeTabHelper.getTitle(resourceLocation));
            builder.icon(iconSupplier);
            builder.displayItems(displayItems);
            return builder.build();
        });
    }

    protected abstract CreativeModeTab.Builder getCreativeModeTabBuilder(boolean withSearchBar);
}
