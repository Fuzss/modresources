package fuzs.puzzleslib.api.core.v1.context;

import com.google.common.base.Preconditions;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.repository.RepositorySource;

import java.util.Objects;

/**
 * Register custom and built-in data &amp; resource packs.
 */
public interface PackRepositorySourcesContext {

    @Deprecated(forRemoval = true)
    default void addRepositorySource(RepositorySource repositorySource) {
        this.registerRepositorySource(repositorySource);
    }

    @Deprecated(forRemoval = true)
    default void addRepositorySource(RepositorySource... repositorySources) {
        Objects.requireNonNull(repositorySources, "repository sources is null");
        Preconditions.checkState(repositorySources.length > 0, "repository sources is empty");
        for (RepositorySource repositorySource : repositorySources) {
            this.registerRepositorySource(repositorySource);
        }
    }

    /**
     * Register an additional {@link RepositorySource} when a new
     * {@link net.minecraft.server.packs.repository.PackRepository} is created.
     * <p>
     * Context can be used for registering both client (for resource packs) and server (for data packs) repository
     * sources.
     *
     * @param repositorySource the repository source to add
     */
    void registerRepositorySource(RepositorySource repositorySource);

    /**
     * Register a built-in pack bundled with the mod.
     * <ul>
     *     <li>Data pack path: {@code data/<modId>/datapacks/<path>}</li>
     *     <li>Resource pack path: {@code assets/<modId>/resourcepacks/<path>}</li>
     * </ul>
     *
     * @param resourceLocation the name of the pack in the {@code resources} directory
     */
    default void registerBuiltInPack(ResourceLocation resourceLocation) {
        Objects.requireNonNull(resourceLocation, "resource location is null");
        this.registerBuiltInPack(resourceLocation, Component.literal(resourceLocation.toString()), false);
    }

    /**
     * Register a built-in pack bundled with the mod.
     * <ul>
     *     <li>Data pack path: {@code data/<modId>/datapacks/<path>}</li>
     *     <li>Resource pack path: {@code assets/<modId>/resourcepacks/<path>}</li>
     * </ul>
     *
     * @param resourceLocation       the name of the pack in the {@code resources} directory
     * @param displayName            the name component for the created pack
     * @param shouldAddAutomatically is this pack always enabled and cannot be turned off
     */
    void registerBuiltInPack(ResourceLocation resourceLocation, Component displayName, boolean shouldAddAutomatically);
}
