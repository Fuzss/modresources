package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;

@FunctionalInterface
public interface ItemTooltipCallback {
    EventInvoker<ItemTooltipCallback> EVENT = EventInvoker.lookup(ItemTooltipCallback.class);

    /**
     * Called at the end of item tooltip gathering in {@link class_1799#method_7950(class_1657, class_1836)}.
     * <p>Allows for both appending additional tooltip lines, and removing / replacing existing lines.
     *
     * @param stack   the item stack owning this tooltip
     * @param player  the player looking at the tooltip, is null when search trees are created
     * @param lines   the tooltip lines
     * @param context tooltip flag context
     */
    void onItemTooltip(class_1799 stack, @Nullable class_1657 player, List<class_2561> lines, class_1836 context);
}
