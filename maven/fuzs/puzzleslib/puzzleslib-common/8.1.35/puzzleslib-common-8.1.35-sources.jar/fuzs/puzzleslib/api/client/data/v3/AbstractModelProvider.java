package fuzs.puzzleslib.api.client.data.v3;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.gson.JsonElement;
import fuzs.puzzleslib.api.client.data.v3.models.ModelLocationHelper;
import fuzs.puzzleslib.api.data.v2.core.DataProviderContext;
import fuzs.puzzleslib.mixin.client.accessor.BlockModelGeneratorsAccessor;
import fuzs.puzzleslib.mixin.client.accessor.ModelTemplatesAccessor;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.*;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2405;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4917;
import net.minecraft.class_4940;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;

public abstract class AbstractModelProvider implements class_2405 {
    public static final class_4942 SPAWN_EGG = ModelTemplatesAccessor.puzzleslib$callCreateItem("template_spawn_egg");

    private final String modId;
    private final class_7784.class_7489 blockStatePathProvider;
    private final class_7784.class_7489 modelPathProvider;
    private final Set<Object> skipValidation = Sets.newHashSet();

    public AbstractModelProvider(DataProviderContext context) {
        this(context.getModId(), context.getPackOutput());
    }

    public AbstractModelProvider(String modId, class_7784 packOutput) {
        this.modId = modId;
        this.blockStatePathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "blockstates");
        this.modelPathProvider = packOutput.method_45973(class_7784.class_7490.field_39368, "models");
    }

    public void addBlockModels(class_4910 builder) {
        // NO-OP
    }

    public void addItemModels(class_4915 builder) {
        // NO-OP
    }

    protected boolean skipValidation() {
        return false;
    }

    protected void skipBlock(class_2248 block) {
        this.skipValidation.add(block);
    }

    protected void skipItem(class_1792 item) {
        this.skipValidation.add(item);
    }

    @Override
    public CompletableFuture<?> method_10319(class_7403 output) {
        Map<class_2248, class_4917> generators = Maps.newHashMap();
        Consumer<class_4917> blockStateOutput = generator -> {
            class_2248 block = generator.method_25743();
            class_4917 blockstategenerator = generators.put(block, generator);
            if (blockstategenerator != null) {
                throw new IllegalStateException("Duplicate block state definition for " + block);
            }
        };
        Map<class_2960, Supplier<JsonElement>> models = Maps.newHashMap();
        Set<class_1792> skippedAutoModels = Sets.newHashSet();
        BiConsumer<class_2960, Supplier<JsonElement>> modelOutput = (resourceLocation, supplier) -> {
            if (models.put(resourceLocation, supplier) != null) {
                throw new IllegalStateException("Duplicate model definition for " + resourceLocation);
            }
        };
        class_4910 blockModelGenerators = new class_4910(blockStateOutput,
                modelOutput,
                skippedAutoModels::add);
        ((BlockModelGeneratorsAccessor) blockModelGenerators).puzzleslib$setNonOrientableTrapdoor(new ArrayList<>(((BlockModelGeneratorsAccessor) blockModelGenerators).puzzleslib$getNonOrientableTrapdoor()));
        ((BlockModelGeneratorsAccessor) blockModelGenerators).puzzleslib$setTexturedModels(new HashMap<>(((BlockModelGeneratorsAccessor) blockModelGenerators).puzzleslib$getTexturedModels()));
        this.addBlockModels(blockModelGenerators);
        this.addItemModels(new class_4915(modelOutput));
        List<class_2248> missingBlocks;
        if (!this.skipValidation()) {
            missingBlocks = class_7923.field_41175.method_29722().stream().filter(entry -> {
                return entry.getKey().method_29177().method_12836().equals(this.modId) &&
                        !generators.containsKey(entry.getValue());
            }).map(Map.Entry::getValue).filter(Predicate.not(this.skipValidation::contains)).toList();
        } else {
            missingBlocks = Collections.emptyList();
        }
        if (!missingBlocks.isEmpty()) {
            throw new IllegalStateException("Missing block state definitions for " + missingBlocks);
        } else {
            class_7923.field_41175.method_29722().forEach(entry -> {
                class_1792 item = class_1792.field_8003.get(entry.getValue());
                if (item != null) {
                    if (!entry.getKey().method_29177().method_12836().equals(this.modId) ||
                            skippedAutoModels.contains(item)) {
                        return;
                    }

                    class_2960 resourcelocation = class_4941.method_25840(item);
                    if (!models.containsKey(resourcelocation)) {
                        models.put(resourcelocation,
                                new class_4940(class_4941.method_25842(entry.getValue())));
                    }
                }
            });
            List<class_1792> missingItems;
            if (!this.skipValidation()) {
                missingItems = class_7923.field_41178.method_29722().stream().filter(entry -> {
                    return entry.getKey().method_29177().method_12836().equals(this.modId) &&
                            !models.containsKey(ModelLocationHelper.getItemModel(entry.getKey().method_29177()));
                }).map(Map.Entry::getValue).filter(Predicate.not(this.skipValidation::contains)).toList();
            } else {
                missingItems = Collections.emptyList();
            }
            if (!missingItems.isEmpty()) {
                throw new IllegalStateException("Missing item models for " + missingItems);
            } else {
                return CompletableFuture.allOf(saveCollection(output, generators, block -> {
                    return this.blockStatePathProvider.method_44107(block.method_40142().method_40237().method_29177());
                }), saveCollection(output, models, this.modelPathProvider::method_44107));
            }
        }
    }

    private static <T> CompletableFuture<?> saveCollection(class_7403 output, Map<T, ? extends Supplier<JsonElement>> map, Function<T, Path> pathExtractor) {
        return CompletableFuture.allOf(map.entrySet().stream().map((entry) -> {
            Path path = pathExtractor.apply(entry.getKey());
            JsonElement jsonElement = entry.getValue().get();
            return class_2405.method_10320(output, jsonElement, path);
        }).toArray(CompletableFuture[]::new));
    }

    @Override
    public final String method_10321() {
        return "Model Definitions";
    }
}
