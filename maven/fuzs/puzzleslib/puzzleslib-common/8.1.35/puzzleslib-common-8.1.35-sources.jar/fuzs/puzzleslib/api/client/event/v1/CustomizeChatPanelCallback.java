package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.data.MutableInt;
import net.minecraft.class_1041;
import net.minecraft.class_332;

@FunctionalInterface
public interface CustomizeChatPanelCallback {
    EventInvoker<CustomizeChatPanelCallback> EVENT = EventInvoker.lookup(CustomizeChatPanelCallback.class);

    /**
     * Called before the chat panel is drawn, allows for changing x- and y-position.
     *
     * @param window      the main window where gui components are drawn in
     * @param guiGraphics the gui graphics component
     * @param partialTick tick delta time
     * @param posX        x-position of the chat panel overlay from screen left
     * @param posY        y-position of the chat panel overlay from screen top
     */
    void onRenderChatPanel(class_1041 window, class_332 guiGraphics, float partialTick, MutableInt posX, MutableInt posY);
}
