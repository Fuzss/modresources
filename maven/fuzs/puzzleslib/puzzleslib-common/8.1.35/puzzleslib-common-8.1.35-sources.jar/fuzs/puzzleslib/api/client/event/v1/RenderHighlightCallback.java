package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_239;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_638;
import net.minecraft.class_757;
import net.minecraft.class_761;

@FunctionalInterface
public interface RenderHighlightCallback {
    EventInvoker<RenderHighlightCallback> EVENT = EventInvoker.lookup(RenderHighlightCallback.class);

    /**
     * Fires before the highlight outline for the current hit result is attempted to be drawn.
     * <p>Vanilla only handles this in case the hit result is {@link class_239.class_240#field_1332}, but the callback also allows for handling {@link class_239.class_240#field_1331}.
     *
     * @param levelRenderer     the level renderer instance
     * @param camera            the camera instance
     * @param gameRenderer      the game renderer instance
     * @param hitResult         the hit result to render the highlight outline for, this can be either {@link class_239.class_240#field_1332} or {@link class_239.class_240#field_1331}
     * @param tickDelta         partial tick time
     * @param poseStack         current pose stack
     * @param multiBufferSource the buffer source
     * @param level             the current client level
     * @return {@link EventResult#INTERRUPT} to prevent the highlight from rendering, allowing for custom rendering,
     * {@link EventResult#PASS} to allow vanilla outline rendering to happen
     */
    EventResult onRenderHighlight(class_761 levelRenderer, class_4184 camera, class_757 gameRenderer, class_239 hitResult, float tickDelta, class_4587 poseStack, class_4597 multiBufferSource, class_638 level);
}
