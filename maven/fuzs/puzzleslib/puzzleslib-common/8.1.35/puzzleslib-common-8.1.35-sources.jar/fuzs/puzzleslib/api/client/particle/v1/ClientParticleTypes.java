package fuzs.puzzleslib.api.client.particle.v1;

import fuzs.puzzleslib.impl.client.particle.ClientParticleTypesImpl;
import net.minecraft.class_2394;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_703;
import org.jetbrains.annotations.Nullable;

/**
 * A fully client-side particle factory registration helper for particle types that have not been registered in common and will not be present on dedicated servers.
 * <p>Intended for client-only mods to allow for custom particles, which would otherwise be unavailable playing on dedicated servers if registered normally due to registry sync (at least on Forge).
 */
public interface ClientParticleTypes {
    ClientParticleTypes INSTANCE = new ClientParticleTypesImpl();

    /**
     * A convenient overload for {@link #createParticle(class_2960, class_2394, double, double, double, double, double, double)} that does not require a likely useless {@link class_2394} instance.
     */
    default @Nullable class_703 createParticle(class_2960 identifier, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
        return this.createParticle(identifier, new class_2400(false), x, y, z, xSpeed, ySpeed, zSpeed);
    }

    /**
     * The fully client-side alternative to {@link net.minecraft.class_702#method_3056(class_2394, double, double, double, double, double, double)}.
     */
    @Nullable class_703 createParticle(class_2960 identifier, class_2394 particleData, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed);
}
