package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_310;
import net.minecraft.class_332;

@FunctionalInterface
public interface RenderGuiCallback {
    EventInvoker<RenderGuiCallback> EVENT = EventInvoker.lookup(RenderGuiCallback.class);

    /**
     * Called at the end of {@link net.minecraft.class_329#method_1753(class_332, float)} after vanilla has drawn all elements.
     * <p>Allows for rendering additional elements on the screen.
     *
     * @param minecraft    minecraft singleton instance
     * @param guiGraphics the gui graphics component
     * @param tickDelta    partial tick time
     * @param screenWidth  window width
     * @param screenHeight window height
     */
    void onRenderGui(class_310 minecraft, class_332 guiGraphics, float tickDelta, int screenWidth, int screenHeight);
}
