package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import net.minecraft.class_310;
import net.minecraft.class_757;

public final class GameRenderEvents {
    public static final EventInvoker<Before> BEFORE = EventInvoker.lookup(Before.class);
    public static final EventInvoker<After> AFTER = EventInvoker.lookup(After.class);

    private GameRenderEvents() {

    }

    @FunctionalInterface
    public interface Before {

        /**
         * Fires before the game and level are rendered in {@link class_757#method_3192(float, long, boolean)}.
         *
         * @param minecraft    minecraft singleton instance
         * @param gameRenderer game renderer instance
         * @param tickDelta    partial tick time, different when the game is paused
         */
        void onBeforeGameRender(class_310 minecraft, class_757 gameRenderer, float tickDelta);
    }

    @FunctionalInterface
    public interface After {

        /**
         * Fires after the game and level are rendered in {@link class_757#method_3192(float, long, boolean)}.
         *
         * @param minecraft    minecraft singleton instance
         * @param gameRenderer game renderer instance
         * @param tickDelta    partial tick time, different when the game is paused
         */
        void onAfterGameRender(class_310 minecraft, class_757 gameRenderer, float tickDelta);
    }
}
