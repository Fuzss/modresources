package fuzs.puzzleslib.api.block.v1;

import fuzs.puzzleslib.api.event.v1.server.TagsUpdatedCallback;
import fuzs.puzzleslib.mixin.accessor.BlockAccessor;
import fuzs.puzzleslib.mixin.accessor.BlockItemAccessor;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_6862;
import net.minecraft.class_7923;

/**
 * A helper class containing utilities for replacing an existing block by modifying the corresponding {@link class_1747} and copying block tags.
 */
public final class BlockConversionHelper {

    private BlockConversionHelper() {

    }

    /**
     * Allows for updating both a {@link class_2248} and corresponding {@link class_1747} simultaneously.
     *
     * @param item  the block item to update
     * @param block the block to update
     */
    public static void setBlockItemBlock(class_1747 item, class_2248 block) {
        setItemForBlock(block, item);
        setBlockForItem(item, block);
    }

    /**
     * Allows for updating the stored {@link class_1792} on a {@link class_2248}.
     * <p>Note that the implementation is not restricted to {@link class_1747}.
     *
     * @param block the block to set the new item for
     * @param item  the new item
     */
    public static void setItemForBlock(class_2248 block, class_1792 item) {
        Objects.requireNonNull(block, "block " + (item != null ? "for item '" + class_7923.field_41178.method_10221(item) + "' " : "") + "is null");
        Objects.requireNonNull(item, "item for block '" + class_7923.field_41175.method_10221(block) + "' is null");
        class_1792.field_8003.put(block, item);
        ((BlockAccessor) block).puzzleslib$setItem(item);
    }

    /**
     * Allows for updating the stored {@link class_2248} on a {@link class_1747}.
     * <p>Useful for switching the corresponding block implementation without the need to modify the original block.
     *
     * @param item  the block item to set the new block for
     * @param block the new block
     */
    public static void setBlockForItem(class_1747 item, class_2248 block) {
        Objects.requireNonNull(item, "item " + (block != null ? "for block '" + class_7923.field_41175.method_10221(block) + "' " : "") + "is null");
        Objects.requireNonNull(block, "block for item '" + class_7923.field_41178.method_10221(item) + "' is null");
        class_2248 oldBlock = item.method_7711();
        // block can somehow be null on Forge apparently
        if (oldBlock != null) ((BlockAccessor) oldBlock).puzzleslib$setItem(item);
        ((BlockItemAccessor) item).puzzleslib$setBlock(block);
    }

    /**
     * Allows for copying tags bound to one block to another.
     * <p>Ideally called after tags have been updated like in {@link TagsUpdatedCallback}.
     *
     * @param from the source block to copy tags from
     * @param to   the target block to copy tags to
     */
    @SuppressWarnings("deprecation")
    public static void copyBoundTags(class_2248 from, class_2248 to) {
        Objects.requireNonNull(from, "source " + (to != null ? "for target '" + class_7923.field_41175.method_10221(to) + "' " : "") + "is null");
        Objects.requireNonNull(to, "target for source '" + class_7923.field_41175.method_10221(from) + "' is null");
        if (to.method_40142().method_40228().findAny().isPresent()) {
            throw new IllegalStateException("target block tags not empty");
        }
        List<class_6862<class_2248>> tagKeys = from.method_40142().method_40228().toList();
        to.method_40142().method_40235(tagKeys);
    }
}
