package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5684;
import net.minecraft.class_8000;

public final class ScreenTooltipEvents {
    public static final EventInvoker<Render> RENDER = EventInvoker.lookup(Render.class);

    private ScreenTooltipEvents() {

    }

    @FunctionalInterface
    public interface Render {

        /**
         * Called just before a tooltip is drawn on a screen, allows for preventing the tooltip from drawing.
         *
         * @param guiGraphics  the gui graphics instance
         * @param mouseX       x position of the mouse cursor
         * @param mouseY       y position of the mouse cursor
         * @param screenWidth  current width of the screen
         * @param screenHeight current height of the screen
         * @param font         the font instance
         * @param components   components to render in the tooltip
         * @param positioner   positioner for placing the tooltip in relation to provided mouse coordinates
         * @return {@link EventResult#INTERRUPT} to prevent the tooltip from rendering, allows for fully taking over rendering,
         * {@link EventResult#PASS} to allow the vanilla tooltip to render as usual
         */
        EventResult onRenderTooltip(class_332 guiGraphics, int mouseX, int mouseY, int screenWidth, int screenHeight, class_327 font, List<class_5684> components, class_8000 positioner);
    }
}
