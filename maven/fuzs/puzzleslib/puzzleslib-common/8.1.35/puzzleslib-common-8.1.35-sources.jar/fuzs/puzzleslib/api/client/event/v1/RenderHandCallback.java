package fuzs.puzzleslib.api.client.event.v1;

import fuzs.puzzleslib.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.api.event.v1.core.EventResult;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;

@FunctionalInterface
public interface RenderHandCallback {
    EventInvoker<RenderHandCallback> EVENT = EventInvoker.lookup(RenderHandCallback.class);

    /**
     * Called before one of the player's hands is rendered in first-person mode.
     * <p>The event is fired for both hands separately, the current hand can be retrieved from <code>hand</code>.
     * <p>Allows for cancelling rendering of the hand.
     *
     * @param player            the local player instance used for first-person rendering
     * @param hand              the {@link class_1268} that is being rendered as part of this event
     * @param stack             the {@link class_1799} held in the hand
     * @param poseStack         the current {@link class_4587}
     * @param multiBufferSource the current {@link class_4597}
     * @param packedLight       packet light the hand is rendered with
     * @param partialTick       current partial tick time
     * @param interpolatedPitch the pitch interpolated for current tick delta from {@link class_1657#method_36455()}
     * @param swingProgress     the forward swing state of the hand from attacking / mining, originally retrieved from {@link class_1657#method_6055(float)}
     * @param equipProgress     the height the hand is rendered at, changes when switching between hotbar items and after triggering the attack cool-down, originally retrieved from {@link class_1657#method_7261(float)}
     * @return {@link EventResult#INTERRUPT} to prevent the specific hand from rendering,
     * {@link EventResult#PASS} to allow the hand to render normally
     */
    EventResult onRenderHand(class_1657 player, class_1268 hand, class_1799 stack, class_4587 poseStack, class_4597 multiBufferSource, int packedLight, float partialTick, float interpolatedPitch, float swingProgress, float equipProgress);
}
