package fuzs.puzzleslib.neoforge.impl.client.core.context;

import fuzs.puzzleslib.common.api.client.core.v1.context.PictureInPictureRenderersContext;
import net.minecraft.client.gui.render.pip.PictureInPictureRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.state.gui.pip.PictureInPictureRenderState;
import net.neoforged.neoforge.client.event.RegisterPictureInPictureRenderersEvent;

import java.util.Objects;
import java.util.function.Function;

public record PictureInPictureRenderersContextNeoForgeImpl(RegisterPictureInPictureRenderersEvent event) implements PictureInPictureRenderersContext {

    @Override
    public <T extends PictureInPictureRenderState> void registerPictureInPictureRenderer(Class<T> renderStateClazz, Function<MultiBufferSource.BufferSource, PictureInPictureRenderer<T>> pictureInPictureRendererFactory) {
        Objects.requireNonNull(renderStateClazz, "class is null");
        Objects.requireNonNull(pictureInPictureRendererFactory, "factory is null");
        this.event.register(renderStateClazz, pictureInPictureRendererFactory);
    }
}
