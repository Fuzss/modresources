# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and this project adheres
to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v21.1.62-mc1.21.1] - 2026-09-29

### Fixed

- Always rebind mutable capability components on retrieval to fix desync issues

## [v21.1.61-mc1.21.1] - 2026-09-13

### Added

- Backport `MutableBakedQuad`
- Backport `QuadCollection`
- Add some required `QuadUtils` helpers

## [v21.1.60-mc1.21.1] - 2026-09-07

### Added

- Backport `ColorCollection`
- Backport `VariantUtils`
- Backport `ProjectileHelper`
- Backport `EntityHelper::dropFromGiftLootTable` & `EntityHelper::dropFromShearingLootTable`

## [v21.1.59-mc1.21.1] - 2026-09-06

### Added

- Backport `ServerResourcesLoadCallback` & `ClientTagsUpdatedCallback`

## [v21.1.58-mc1.21.1] - 2026-09-05

### Added

- Backport `BlockStateResolverContext`
- Backport `AbstractMenuSelectionList`

## [v21.1.57-mc1.21.1] - 2026-09-02

### Added

- Backport updated `RangedSliderButton`

## [v21.1.56-mc1.21.1] - 2026-08-31

### Added

- Backport modern `ParticleProvider`
- Backport `TrimPatternBuilder`
- Backport `RegistryManager::registerCreativeModeTab`

### Changed

- Delay setting up handshake payloads to avoid registering `IModBusEvents` too early on NeoForge
- Set spawn cost in `SpawnerDataBuilder`

## [v21.1.55-mc1.21.1] - 2026-08-13

### Added

- Backport modern vanilla input classes (most importantly `InputWithModifiers`)
- Backport modern `SimpleJsonResourceReloadListener`
- Backport modern `DataProvider` methods
- Backport `AbstractWidgetsContainerScreen`
- Backport updated `ScreenOpeningCallback`
- Backport updated `GuiGraphicsHelper`

### Changed

- Update `EventResult#value` type

## [v21.1.54-mc1.21.1] - 2026-07-02

### Changed

- Ship an access transformer instead of a class tweaker file for backwards compatibility on Fabric

## [v21.1.53-mc1.21.1] - 2026-07-01

### Changed

- Use Multiloader Convention Plugins v1.1

## [v21.1.52-mc1.21.1] - 2026-06-15

### Fixed

- Fix `NetworkingHelper::hasChannel` not checking `Connection::isConnected` on NeoForge

## [v21.1.51-mc1.21.1] - 2026-05-30

### Changed

- Make registry syncing more lenient for vanilla clients on Fabric

### Fixed

- Fix crash when trying to open a config screen for a config which is not loaded

## [v21.1.50-mc1.21.1] - 2026-05-28

### Changed

- Support registering stripple blocks without an `axis` property on Fabric

## [v21.1.49-mc1.21.1] - 2026-05-27

### Fixed

- Fix wrong sign type being passed to the `BlockSetVariant#HANGING_SIGN` item

## [v21.1.48-mc1.21.1] - 2026-05-27

### Added

- Backport `ChunkSectionLayer` from Minecraft 1.21.11
- Backport missing `BlockSetFamily` related methods in `AbstractRecipeProvider` & `AbstractTagProvider`

## [v21.1.47-mc1.21.1] - 2026-05-26

### Added

- Backport `BlockSetFamily`
- Backport `BlockSetVariant`
- Backport `ClientBlockSetFamily`

### Fixed

- Fix `RenderTypeHelper::getRenderType` not calling the proper method on NeoForge

## [v21.1.46-mc1.21.1] - 2026-05-23

### Fixed

- Fix wrong `MeshDefinition` parameter in `LayerDefinition::create`

## [v21.1.45-mc1.21.1] - 2026-05-23

### Added

- Backport `ModelAndTexture` from Minecraft 26.1
- Backport `ClientAsset` from Minecraft 26.1
- Backport `LateBoundIdMapper` from Minecraft 26.1
- Backport `SpecialModelRenderer` from Minecraft 26.1
- Backport some codecs in `CodecExtras` from Minecraft 26.1

### Fixed

- Make sure our custom `LayerDefinition` stores a custom `MeshDefinition`, not the vanilla variant

## [v21.1.44-mc1.21.1] - 2026-05-21

### Added

- Backport updated `AbstractTagAppender`

### Fixed

- Fix tag generation failing when including tags from other namespaces

## [v21.1.43-mc1.21.1] - 2026-05-21

### Added

- Add `TransformingForwardingList`
- Add some helper methods to `ShapesHelper`
- Add some helper methods to `AbstractRecipeProvider`

## [v21.1.42-mc1.21.1] - 2026-05-20

### Added

- Add custom `LayerDefinition` from Minecraft 26.1

### Changed

- Backport internal development tools

### Fixed

- Fix custom `PartDefinition` `ClassCastException`

## [v21.1.41-mc1.21.1] - 2026-05-19

### Added

- Add `DataAttachmentType::remove`
- Backport `EntityDamageImmunityCallback`
- Backport `StopSleepInBedCallback`
- Backport `ServerEntityEvents`, deprecating `ServerEntityLevelEvents`
- Backport `ConfigHolder::registerConfigurationScreen`
- Backport `ContainerMenuHelper::openMenu`
- Backport `TickingBlockEntity::clientTick` and `TickingBlockEntity::serverTick` methods with additional context

### Changed

- Replace internal `ConfigurationScreen` with a custom version which also handles translations among other things
- Backport attachment syncing
- Backport updated `ComponentHelper` & `StyleCombiningCharSink`

### Removed

- Remove `ConfigTranslationsManager`, translations are now handled directly on the config screen

### Fixed

- Fix `EventResultHolder` not accepting a `null` value
- Fix config lists not being allowed empty in some cases

## [v21.1.40-mc1.21.1] - 2025-12-09

### Changed

- Major backport of many features from Puzzles Lib for Minecraft 1.21.10

## [v21.1.39-mc1.21.1] - 2025-10-23

### Changed

- Add access widener for `CreativeModeInventoryScreen$SlotWrapper`

## [v21.1.38-mc1.21.1] - 2025-08-11

### Added

- Add `PackRepositorySourcesContext::registerBuiltInPack`
- Support built-in packs in `DataProviderHelper`

## [v21.1.37-mc1.21.1] - 2025-08-05

### Fixed

- Fix `ShieldBlockCallback` being called even when not actively blocking on NeoForge

## [v21.1.36-mc1.21.1] - 2025-05-04

### Changed

- Allow `DataProviderHelper` to support `RegistrySetBuilder`

## [v21.1.35-mc1.21.1] - 2025-05-04

### Removed

- Remove unused breathing and drowning event implementations on Fabric to improve compatibility with Lunar Client

## [v21.1.34-mc1.21.1] - 2025-04-25

### Changed

- Improve compatibility with other mods injecting into the `Gui` class on Fabric

## [v21.1.33-mc1.21.1] - 2025-03-16

### Fixed

- Fix `ModelPart$Vertex` & `ModelPart$Polygon` being inaccessible on NeoForge

## [v21.1.32-mc1.21.1] - 2025-03-14

### Changed

- Add a bunch of safety checks for casting in event invokers

## [v21.1.31-mc1.21.1] - 2025-03-13

### Added

- Add `ModConstructor::onRegisterGameplayContent`
- Add `ModelLocationHelper` & `ModelTemplateHelper`
- Add `ResourceKeyHelper`
- Add `AbstractDatapackRegistriesProvider`

## [v21.1.30-mc1.21.1] - 2025-03-11

### Fixed

- Fix a rare start-up crash when registering generated config translations on NeoForge

## [v21.1.29-mc1.21.1] - 2025-03-09

### Fixed

- Fix CommonAbstractions::hasChannel crashing for invalid players on NeoForge

## [v21.1.28-mc1.21.1] - 2025-02-25

### Added

- Backport new block, item and creative mode tab registration methods to `RegistryManager`
- Backport `CompostableBlocksContext`

### Changed

- Update `FabricEventFactory` to handle faulty return values more leniently

## [v21.1.27-mc1.21.1] - 2025-01-17

### Fixed

- Fix network packets executing with one tick delay on Fabric

## [v21.1.26-mc1.21.1] - 2025-01-16

### Changed

- Allow setting empty lines for `TooltipBuilder` to prevent the tooltip from drawing

### Fixed

- Fix unable to set a new widget tooltip using vanilla methods when `TooltipBuilder` has been used for the widget

## [v21.1.25-mc1.21.1] - 2025-01-10

### Fixed

- Avoid unnecessarily high memory usage from holding on to top level model locations after model events have completed
- Wrap `BlockStateModelLoader` in a `WeakReference` to avoid holding on to it when it is no longer needed

## [v21.1.24-mc1.21.1] - 2024-12-22

### Changed

- Adjust `RangedSliderButton` implementation to no longer require an access widener to help compatibility with
  the [Cloth Config](https://modrinth.com/mod/cloth-config) mod

## [v21.1.23-mc1.21.1] - 2024-10-24

### Changed

- Support using `AbstractTagAppender` as string list builder

## [v21.1.22-mc1.21.1] - 2024-10-22

### Added

- Add `ChangeEntitySizeCallback`
- Add `RegistryManager::registerAttribute`

### Changed

- Expand `LivingEntityRenderLayersContext` with some additional methods

## [v21.1.21-mc1.21.1] - 2024-10-10

### Changed

- Allow `PlayerSet` to handle a provided client level more leniently

## [v21.1.20-mc1.21.1] - 2024-10-10

### Added

- Add `CommonAbstractions::getPartEntityParent`

### Fixed

- Fix removed data attachments failing to synchronize to clients

## [v21.1.19-mc1.21.1] - 2024-10-05

### Changed

- Replace `ClientParticleTypes` with `ClientParticleHelper`

## [v21.1.18-mc1.21.1] - 2024-10-04

### Changed

- Add more helper methods to `GuiGraphicsHelper`

### Fixed

- Fix `DynamicPackResources` failing to generate some resources

## [v21.1.17-mc1.21.1] - 2024-10-01

### Added

- Add `ClientAbstractions::hasChannel` & `CommonAbstractions::hasChannel`

### Changed

- Network messages are no longer sent to clients & servers that do not understand them

## [v21.1.16-mc1.21.1] - 2024-09-30

### Changed

- `RenderGuiLayerEvents` no longer fire when the hud is hidden via `F1`

## [v21.1.15-mc1.21.1] - 2024-09-30

### Changed

- Slight `RenderGuiEvents` adjustments

### Fixed

- Fix some gui layers from other mods failing to render

## [v21.1.14-mc1.21.1] - 2024-09-29

### Added

- Add `RenderGuiEvents`, replacing `RenderGuiCallback`

## [v21.1.13-mc1.21.1] - 2024-09-29

### Changed

- Overhaul `RenderGuiLayerEvents` implementation on Fabric

## [v21.1.12-mc1.21.1] - 2024-09-29

### Added

- Add `NeoForgeCapabilityHelper::registerItemContainer`
- Add `GuiGraphicsHelper::blitTiledSprite`
- Add a bunch of helper methods to `ClientAbstractions` for handling `Gui#leftHeight` &amp; `Gui#rightHeight`

### Changed

- Minor `ConfigTranslationsManager` improvements

### Removed

- Remove `ModLoaderEnvironment::getObjectShareAccess`

## [v21.1.11-mc1.21.1] - 2024-09-25

### Added

- Add `CodecExtras`
- Add some helper methods to `ItemModelDisplayOverrides`
- Add enum helpers to `ExtraStreamCodecs`
- Add some helper methods to `CreativeModeTabConfigurator`
- Add helper methods to `ShapesHelper` for rotating shapes horizontally

### Changed

- Allow for compatibility with Minecraft 1.21 on Fabric if enabled
  via [dependency overrides](https://fabricmc.net/wiki/tutorial:dependency_overrides)
- Allow `RegistryManager::registerBlockItem` to take an `Item$Properties` supplier

### Fixed

- Fix `RenderHighlightCallback` crashing on NeoForge

## [v21.1.10-mc1.21.1] - 2024-09-20

### Changed

- Allow `ItemModelDisplayOverrides` to accept both `ResourceLocation` as well as `ModelResourceLocation`

## [v21.1.9-mc1.21.1] - 2024-09-18

### Added

- Add `TooltipBuilder::setTooltipLineProcessor`

## [v21.1.8-mc1.21.1] - 2024-09-18

### Changed

- Pass original `ClientTooltipPositioner` to tooltip positioner factory in `TooltipBuilder`

## [v21.1.7-mc1.21.1] - 2024-09-17

### Fixed

- Fix `LivingDropsCallback` failing to capture player drops on Fabric
- Fix some keybinds failing to trigger properly on Fabric

## [v21.1.6-mc1.21.1] - 2024-09-17

### Changed

- Overhaul `AbstractRegistriesDatapackGenerator` so that generated registry values can be used in other data providers

## [v21.1.5-mc1.21.1] - 2024-09-16

### Added

- Add new data attachment api

### Changed

- Revert codec support for capabilities, use attachments for that
- Rename `PlayerSet::notify` to `PlayerSet::broadcast`

## [v21.1.4-mc1.21.1] - 2024-09-14

### Changed

- Support codecs for capabilities
- Simplify `ModelLayerFactory` implementation

## [v21.1.3-mc1.21.1] - 2024-09-13

### Added

- Add `ScreenSkipper`
- Add `GsonCodecHelper`
- Add `TagFactory`

## [v21.1.2-mc1.21.1] - 2024-09-12

### Added

- Add `RegistryManager::registerTrimMaterial` and `RegistryManager::registerLootTable`

## [v21.1.1-mc1.21.1] - 2024-09-11

### Added

- Add `RegistryManager::registerDataComponentType`

### Changed

- Minor updates for `ConfigTranslationsManager`
- Hide some annoying toast messages in development environments

### Removed

- Remove `BlockEntityHelper`

## [v21.1.0-mc1.21.1] - 2024-09-10

- Port to Minecraft 1.21.1
