package fuzs.puzzleslib.common.api.client.data.v2.models;

import net.minecraft.client.data.models.BlockModelGenerators;
import net.minecraft.client.data.models.ItemModelGenerators;
import net.minecraft.client.data.models.model.*;
import net.minecraft.client.renderer.item.ItemModel;
import net.minecraft.client.renderer.special.ChestSpecialRenderer;
import net.minecraft.client.renderer.special.ShieldSpecialRenderer;
import net.minecraft.client.renderer.special.SpecialModelRenderer;
import net.minecraft.client.resources.model.sprite.Material;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SkullBlock;

import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;

public final class ItemModelGenerationHelper {
    public static final ModelTemplate HORN = ModelTemplateHelper.createItemModelTemplate(Identifier.withDefaultNamespace(
            "goat_horn"), TextureSlot.LAYER0);
    public static final ModelTemplate TOOTING_HORN = ModelTemplateHelper.createItemModelTemplate(Identifier.withDefaultNamespace(
            "tooting_goat_horn"), TextureSlot.LAYER0);
    public static final ModelTemplate SHIELD_MODEL_TEMPLATE = ModelTemplateHelper.createItemModelTemplate(Identifier.withDefaultNamespace(
            "shield"), TextureSlot.PARTICLE);
    public static final ModelTemplate SHIELD_BLOCKING_MODEL_TEMPLATE = ModelTemplateHelper.createItemModelTemplate(
            Identifier.withDefaultNamespace("shield_blocking"),
            TextureSlot.PARTICLE);

    private ItemModelGenerationHelper() {
        // NO-OP
    }

    public static void generateFlatItem(Item item, ModelTemplate modelTemplate, ItemModelGenerators itemModelGenerators) {
        itemModelGenerators.itemModelOutput.accept(item,
                ItemModelUtils.plainModel(createFlatItemModel(item, modelTemplate, itemModelGenerators.modelOutput)));
    }

    public static Identifier createFlatItemModel(Item item, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return createFlatItemModel(item, item, modelTemplate, modelOutput);
    }

    public static void generateFlatItem(Item item, Item layerItem, ModelTemplate modelTemplate, ItemModelGenerators itemModelGenerators) {
        itemModelGenerators.itemModelOutput.accept(item,
                ItemModelUtils.plainModel(createFlatItemModel(item,
                        layerItem,
                        modelTemplate,
                        itemModelGenerators.modelOutput)));
    }

    public static Identifier createFlatItemModel(Item item, Item layerItem, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return createFlatItemModel(item, ModelLocationHelper.getItemTexture(layerItem), modelTemplate, modelOutput);
    }

    public static void generateFlatItem(Item item, Material layer0Location, ModelTemplate modelTemplate, ItemModelGenerators itemModelGenerators) {
        itemModelGenerators.itemModelOutput.accept(item,
                ItemModelUtils.plainModel(createFlatItemModel(item,
                        layer0Location,
                        modelTemplate,
                        itemModelGenerators.modelOutput)));
    }

    public static Identifier createFlatItemModel(Item item, Material layer0Location, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return createFlatItemModel(ModelLocationHelper.getItemModel(item), layer0Location, modelTemplate, modelOutput);
    }

    public static Identifier createFlatItemModel(Identifier identifier, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return createFlatItemModel(identifier, new Material(identifier), modelTemplate, modelOutput);
    }

    public static Identifier createFlatItemModel(Identifier identifier, Material layer0Location, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return modelTemplate.create(identifier, TextureMapping.layer0(layer0Location), modelOutput);
    }

    public static void generateLayeredItem(Item item, Material layer0Location, Material layer1Location, ModelTemplate modelTemplate, ItemModelGenerators itemModelGenerators) {
        itemModelGenerators.itemModelOutput.accept(item,
                ItemModelUtils.plainModel(createLayeredItemModel(item,
                        layer0Location,
                        layer1Location,
                        modelTemplate,
                        itemModelGenerators.modelOutput)));
    }

    public static Identifier createLayeredItemModel(Item item, Material layer0Location, Material layer1Location, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return createLayeredItemModel(ModelLocationHelper.getItemModel(item),
                layer0Location,
                layer1Location,
                modelTemplate,
                modelOutput);
    }

    public static Identifier createLayeredItemModel(Identifier identifier, Material layer0Location, Material layer1Location, ModelTemplate modelTemplate, BiConsumer<Identifier, ModelInstance> modelOutput) {
        return modelTemplate.create(identifier, TextureMapping.layered(layer0Location, layer1Location), modelOutput);
    }

    /**
     * @see ItemModelGenerators#generateBow(Item)
     */
    public static void generateBow(Item item, ItemModelGenerators itemModelGenerators) {
        itemModelGenerators.createFlatItemModel(item, ModelTemplates.BOW);
        itemModelGenerators.generateBow(item);
    }

    /**
     * @see ItemModelGenerators#generateGoatHorn(Item)
     */
    public static void generateHorn(Item item, ItemModelGenerators itemModelGenerators) {
        ItemModel.Unbaked normal = ItemModelUtils.plainModel(itemModelGenerators.createFlatItemModel(item, HORN));
        ItemModel.Unbaked tooting = ItemModelUtils.plainModel(createFlatItemModel(ModelLocationHelper.getItemModel(item,
                "_tooting"), ModelLocationHelper.getItemTexture(item), TOOTING_HORN, itemModelGenerators.modelOutput));
        itemModelGenerators.generateBooleanDispatch(item, ItemModelUtils.isUsingItem(), tooting, normal);
    }

    /**
     * @see BlockModelGenerators#createHead(Block, Block, SkullBlock.Type, Identifier)
     */
    public static void generateHead(Block headBlock, Block wallHeadBlock, SkullBlock.Type type, BlockModelGenerators blockModelGenerators) {
        blockModelGenerators.createHead(headBlock,
                wallHeadBlock,
                type,
                ModelLocationUtils.decorateItemModelLocation("template_skull"));
    }

    /**
     * @see ItemModelGenerators#generateShield(Item)
     */
    public static void generateShield(Item item, Block particleBlock, Supplier<SpecialModelRenderer.Unbaked<?>> specialModelSupplier, ItemModelGenerators itemModelGenerators) {
        Identifier normalModel = SHIELD_MODEL_TEMPLATE.create(ModelLocationHelper.getItemModel(item),
                TextureMapping.particle(particleBlock),
                itemModelGenerators.modelOutput);
        Identifier blockingModel = SHIELD_BLOCKING_MODEL_TEMPLATE.create(ModelLocationHelper.getItemModel(item,
                "_blocking"), TextureMapping.particle(particleBlock), itemModelGenerators.modelOutput);
        ItemModel.Unbaked normal = ItemModelUtils.specialModel(normalModel, specialModelSupplier.get());
        ItemModel.Unbaked blocking = ItemModelUtils.specialModel(blockingModel, specialModelSupplier.get());
        itemModelGenerators.itemModelOutput.accept(item,
                ItemModelUtils.conditional(ShieldSpecialRenderer.DEFAULT_TRANSFORMATION,
                        ItemModelUtils.isUsingItem(),
                        blocking,
                        normal));
    }

    /**
     * @see BlockModelGenerators#createChest(Block, Block, Identifier, boolean)
     */
    public static void generateChest(Block chestBlock, Block particleBlock, Identifier itemTexture, boolean useGiftTexture, Function<Identifier, SpecialModelRenderer.Unbaked<?>> unbakedRendererFactory, BlockModelGenerators blockModelGenerators) {
        blockModelGenerators.createParticleOnlyBlock(chestBlock, particleBlock);
        Item chestItem = chestBlock.asItem();
        Identifier itemModelBase = ModelTemplates.CHEST_INVENTORY.create(chestItem,
                TextureMapping.particle(particleBlock),
                blockModelGenerators.modelOutput);
        ItemModel.Unbaked baseModel = ItemModelUtils.specialModel(itemModelBase,
                unbakedRendererFactory.apply(itemTexture));
        if (useGiftTexture) {
            ItemModel.Unbaked giftModel = ItemModelUtils.specialModel(itemModelBase,
                    new ChestSpecialRenderer.Unbaked(ChestSpecialRenderer.CHRISTMAS.single()));
            blockModelGenerators.itemModelOutput.accept(chestItem, ItemModelUtils.isXmas(giftModel, baseModel));
        } else {
            blockModelGenerators.itemModelOutput.accept(chestItem, baseModel);
        }
    }
}
