package fuzs.puzzleslib.common.api.client.event.v1.entity;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.common.api.event.v1.core.EventResult;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;

public final class ClientEntityEvents {
    public static final EventInvoker<Load> LOAD = EventInvoker.lookup(Load.class);
    public static final EventInvoker<Unload> UNLOAD = EventInvoker.lookup(Unload.class);

    private ClientEntityEvents() {
        // NO-OP
    }

    @FunctionalInterface
    public interface Load {

        /**
         * Fired when an entity is added to the level on the client.
         *
         * @param entity the entity that is being loaded
         * @param level  the level the entity is loaded in
         * @return <ul>
         *         <li>{@link EventResult#INTERRUPT INTERRUPT} to prevent the entity from being added to the level</li>
         *         <li>{@link EventResult#PASS PASS} for the entity to be added normally</li>
         *         </ul>
         */
        EventResult onEntityLoad(Entity entity, ClientLevel level);
    }

    @FunctionalInterface
    public interface Unload {

        /**
         * Fired when an entity is removed from the level on the client.
         *
         * @param entity the entity that is being unloaded
         * @param level  the level the entity is unloaded in
         */
        void onEntityUnload(Entity entity, ClientLevel level);
    }
}
