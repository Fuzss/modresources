package fuzs.puzzleslib.neoforge.impl.biome;

import fuzs.puzzleslib.common.api.biome.v1.ClimateSettingsContext;
import net.minecraft.world.level.biome.Biome;
import net.neoforged.neoforge.common.world.ClimateSettingsBuilder;
import org.jspecify.annotations.NonNull;

import java.util.Objects;

public record ClimateSettingsContextNeoForge(ClimateSettingsBuilder context) implements ClimateSettingsContext {

    @Override
    public void hasPrecipitation(boolean hasPrecipitation) {
        this.context.setHasPrecipitation(hasPrecipitation);
    }

    @Override
    public boolean hasPrecipitation() {
        return this.context.hasPrecipitation();
    }

    @Override
    public void setTemperature(float temperature) {
        this.context.setTemperature(temperature);
    }

    @Override
    public float getTemperature() {
        return this.context.getTemperature();
    }

    @Override
    public void setTemperatureModifier(Biome.@NonNull TemperatureModifier temperatureModifier) {
        Objects.requireNonNull(temperatureModifier, "temperature modifier is null");
        this.context.setTemperatureModifier(temperatureModifier);
    }

    @Override
    public void setDownfall(float downfall) {
        this.context.setDownfall(downfall);
    }
}
