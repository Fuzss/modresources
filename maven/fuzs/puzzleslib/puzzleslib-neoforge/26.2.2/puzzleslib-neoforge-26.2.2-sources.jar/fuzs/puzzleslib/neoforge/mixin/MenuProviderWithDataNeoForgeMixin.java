package fuzs.puzzleslib.neoforge.mixin;

import fuzs.puzzleslib.common.api.container.v1.MenuProviderWithData;
import fuzs.puzzleslib.common.impl.event.EventImplHelper;
import fuzs.puzzleslib.neoforge.impl.init.MenuTypeWithData;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(MenuProviderWithData.class)
public interface MenuProviderWithDataNeoForgeMixin<T> extends MenuProvider {
    @Shadow
    T getMenuData(@Nullable ServerPlayer serverPlayer);

    @Override
    default void writeClientSideData(AbstractContainerMenu abstractContainerMenu, RegistryFriendlyByteBuf buf) {
        Player player = EventImplHelper.getPlayerFromContainerMenu(abstractContainerMenu);
        MenuTypeWithData.encodeMenuData(abstractContainerMenu, buf, this.getMenuData((ServerPlayer) player));
    }
}
