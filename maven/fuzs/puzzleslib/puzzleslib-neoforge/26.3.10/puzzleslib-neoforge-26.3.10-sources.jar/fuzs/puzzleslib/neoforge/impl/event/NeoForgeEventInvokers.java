package fuzs.puzzleslib.neoforge.impl.event;

import com.google.common.base.Suppliers;
import fuzs.puzzleslib.common.api.event.v1.*;
import fuzs.puzzleslib.common.api.event.v1.core.EventResult;
import fuzs.puzzleslib.common.api.event.v1.core.EventResultHolder;
import fuzs.puzzleslib.common.api.event.v1.data.*;
import fuzs.puzzleslib.common.api.event.v1.entity.*;
import fuzs.puzzleslib.common.api.event.v1.entity.living.*;
import fuzs.puzzleslib.common.api.event.v1.entity.player.*;
import fuzs.puzzleslib.common.api.event.v1.level.*;
import fuzs.puzzleslib.common.api.event.v1.server.*;
import fuzs.puzzleslib.common.impl.PuzzlesLib;
import fuzs.puzzleslib.common.impl.event.EventImplHelper;
import fuzs.puzzleslib.common.impl.event.PotentialSpawnsList;
import fuzs.puzzleslib.neoforge.api.core.v1.NeoForgeModContainerHelper;
import fuzs.puzzleslib.neoforge.api.event.v1.ModifyEnchantmentsEvent;
import fuzs.puzzleslib.neoforge.mixin.accessor.EntityNeoForgeAccessor;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerConfigurationPacketListenerImpl;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.TriState;
import net.minecraft.util.random.Weighted;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.GrindstoneMenu;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.block.GameMasterBlock;
import net.minecraft.world.level.gamerules.GameRule;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent;
import net.neoforged.neoforge.event.*;
import net.neoforged.neoforge.event.entity.*;
import net.neoforged.neoforge.event.entity.EntityEvent;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.event.entity.living.*;
import net.neoforged.neoforge.event.entity.player.*;
import net.neoforged.neoforge.event.level.*;
import net.neoforged.neoforge.event.level.block.BreakBlockEvent;
import net.neoforged.neoforge.event.server.ServerAboutToStartEvent;
import net.neoforged.neoforge.event.server.ServerStartedEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import net.neoforged.neoforge.event.tick.EntityTickEvent;
import net.neoforged.neoforge.event.tick.LevelTickEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import net.neoforged.neoforge.network.event.RegisterConfigurationTasksEvent;
import net.neoforged.neoforge.registries.ModifyRegistriesEvent;
import net.neoforged.neoforge.registries.RegisterEvent;
import net.neoforged.neoforge.registries.callback.AddCallback;
import net.neoforged.neoforge.registries.callback.BakeCallback;
import org.jspecify.annotations.Nullable;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static fuzs.puzzleslib.neoforge.api.event.v1.core.NeoForgeEventInvokerRegistry.INSTANCE;

@SuppressWarnings("CodeBlock2Expr")
public final class NeoForgeEventInvokers {

    private NeoForgeEventInvokers() {
        // NO-OP
    }

    public static void registerLoadingHandlers() {
        INSTANCE.register(CommonSetupCallback.class,
                FMLCommonSetupEvent.class,
                (CommonSetupCallback callback, FMLCommonSetupEvent event) -> {
                    event.enqueueWork(callback::onCommonSetup);
                });
        INSTANCE.register(LoadCompleteCallback.class,
                FMLLoadCompleteEvent.class,
                (LoadCompleteCallback callback, FMLLoadCompleteEvent event) -> {
                    event.enqueueWork(callback::onLoadComplete);
                });
        INSTANCE.register(RegistryEntryAddedCallback.class,
                ModifyRegistriesEvent.class,
                NeoForgeEventInvokers::onRegistryEntryAdded);
        INSTANCE.register(AddBlockEntityTypeBlocksCallback.class,
                BlockEntityTypeAddBlocksEvent.class,
                (AddBlockEntityTypeBlocksCallback callback, BlockEntityTypeAddBlocksEvent event) -> {
                    callback.onAddBlockEntityTypeBlocks(event::modify);
                });
        INSTANCE.register(BuildCreativeModeTabContentsCallback.class,
                BuildCreativeModeTabContentsEvent.class,
                (BuildCreativeModeTabContentsCallback callback, BuildCreativeModeTabContentsEvent event, @Nullable Object context) -> {
                    Objects.requireNonNull(context, "context is null");
                    ResourceKey<CreativeModeTab> resourceKey = (ResourceKey<CreativeModeTab>) context;
                    if (resourceKey == event.getTabKey()) {
                        callback.onBuildCreativeModeTabContents(event.getTab(), event.getParameters(), event);
                    }
                });
        INSTANCE.register(RegisterConfigurationTasksCallback.class,
                RegisterConfigurationTasksEvent.class,
                (RegisterConfigurationTasksCallback callback, RegisterConfigurationTasksEvent event) -> {
                    ServerConfigurationPacketListenerImpl listener = (ServerConfigurationPacketListenerImpl) event.getListener();
                    callback.onRegisterConfigurationTasks(listener.server, listener, event::register);
                });
    }

    @SuppressWarnings("unchecked")
    private static <T> void onRegistryEntryAdded(RegistryEntryAddedCallback<T> callback, ModifyRegistriesEvent event, @Nullable Object context) {
        Objects.requireNonNull(context, "context is null");
        ResourceKey<? extends Registry<T>> resourceKey = (ResourceKey<? extends Registry<T>>) context;
        Registry<T> registry = event.getRegistry(resourceKey);
        boolean[] loadComplete = new boolean[1];
        registry.addCallback((AddCallback<T>) (Registry<T> callbackRegistry, int _, ResourceKey<T> key, T value) -> {
            if (!loadComplete[0]) {
                try {
                    callback.onRegistryEntryAdded(callbackRegistry,
                            key.identifier(),
                            value,
                            onRegistryEntryAdded(registry));
                } catch (Exception exception) {
                    PuzzlesLib.LOGGER.error("Failed to run registry entry added callback", exception);
                }
            }
        });
        registry.addCallback((BakeCallback<T>) (Registry<T> _) -> {
            // prevent add callback from running after loading has completed, Forge still fires the callback when syncing registries,
            // but that doesn't allow for adding content
            loadComplete[0] = true;
        });
        // store all event invocations for vanilla game content already registered before the registration event runs
        // the add callback above won't trigger for those as they are already registered when mods are constructed
        // we cannot run those directly as registries are frozen when this fires
        Queue<Consumer<BiConsumer<Identifier, Supplier<T>>>> callbacks = new LinkedList<>();
        for (Map.Entry<ResourceKey<T>, T> entry : registry.entrySet()) {
            callbacks.offer((BiConsumer<Identifier, Supplier<T>> consumer) -> {
                try {
                    callback.onRegistryEntryAdded(registry, entry.getKey().identifier(), entry.getValue(), consumer);
                } catch (Exception exception) {
                    PuzzlesLib.LOGGER.error("Failed to run registry entry added callback", exception);
                }
            });
        }
        // active mod event bus is no longer available when ModifyRegistriesEvent fires,
        // so just use the Puzzles Lib event bus for everything
        IEventBus eventBus = NeoForgeModContainerHelper.getModEventBus(PuzzlesLib.MOD_ID);
        eventBus.addListener((final RegisterEvent eventX) -> {
            if (eventX.getRegistryKey() != resourceKey) {
                return;
            }

            Consumer<BiConsumer<Identifier, Supplier<T>>> consumer;
            while ((consumer = callbacks.poll()) != null) {
                consumer.accept(onRegistryEntryAdded((Registry<T>) eventX.getRegistry()));
            }
        });
    }

    private static <T> BiConsumer<Identifier, Supplier<T>> onRegistryEntryAdded(Registry<T> registry) {
        return (Identifier identifier, Supplier<T> supplier) -> {
            try {
                T t = supplier.get();
                Objects.requireNonNull(t, "entry is null");
                Registry.register(registry, identifier, t);
            } catch (Exception exception) {
                PuzzlesLib.LOGGER.error("Failed to register new entry", exception);
            }
        };
    }

    public static void registerEventHandlers() {
        INSTANCE.register(PlayerInteractEvents.UseBlock.class,
                PlayerInteractEvent.RightClickBlock.class,
                (PlayerInteractEvents.UseBlock callback, PlayerInteractEvent.RightClickBlock event) -> {
                    callback.onUseBlock(event.getEntity(), event.getLevel(), event.getHand(), event.getHitVec())
                            .ifInterrupt((InteractionResult interactionResult) -> {
                                event.setCancellationResult(interactionResult);
                                event.setCanceled(true);
                            });
                });
        INSTANCE.register(PlayerInteractEvents.AttackBlock.class,
                PlayerInteractEvent.LeftClickBlock.class,
                (PlayerInteractEvents.AttackBlock callback, PlayerInteractEvent.LeftClickBlock event) -> {
                    if (callback.onAttackBlock(event.getEntity(),
                            event.getLevel(),
                            event.getHand(),
                            event.getPos(),
                            event.getFace()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(PlayerInteractEvents.UseItem.class,
                PlayerInteractEvent.RightClickItem.class,
                (PlayerInteractEvents.UseItem callback, PlayerInteractEvent.RightClickItem event) -> {
                    callback.onUseItem(event.getEntity(), event.getLevel(), event.getHand())
                            .ifInterrupt((InteractionResult interactionResult) -> {
                                event.setCancellationResult(interactionResult);
                                event.setCanceled(true);
                            });
                });
        INSTANCE.register(PlayerInteractEvents.UseEntity.class,
                PlayerInteractEvent.EntityInteract.class,
                (PlayerInteractEvents.UseEntity callback, PlayerInteractEvent.EntityInteract event) -> {
                    callback.onUseEntity(event.getEntity(),
                            event.getLevel(),
                            event.getHand(),
                            event.getTarget(),
                            event.getLocation()).ifInterrupt((InteractionResult interactionResult) -> {
                        event.setCancellationResult(interactionResult);
                        event.setCanceled(true);
                    });
                });
        INSTANCE.register(PlayerInteractEvents.AttackEntity.class,
                AttackEntityEvent.class,
                (PlayerInteractEvents.AttackEntity callback, AttackEntityEvent event) -> {
                    if (callback.onAttackEntity(event.getEntity(),
                            event.getEntity().level(),
                            InteractionHand.MAIN_HAND,
                            event.getTarget()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(PickupExperienceCallback.class,
                PlayerXpEvent.PickupXp.class,
                (PickupExperienceCallback callback, PlayerXpEvent.PickupXp event) -> {
                    if (callback.onPickupExperience(event.getEntity(), event.getOrb()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(UseBoneMealCallback.class,
                BonemealEvent.class,
                (UseBoneMealCallback callback, BonemealEvent event) -> {
                    EventResult eventResult = callback.onUseBoneMeal(event.getLevel(),
                            event.getPos(),
                            event.getState(),
                            event.getStack());
                    if (eventResult.isInterrupt()) {
                        event.setSuccessful(eventResult.getAsBoolean());
                    }
                });
        INSTANCE.register(LivingExperienceDropCallback.class,
                LivingExperienceDropEvent.class,
                (LivingExperienceDropCallback callback, LivingExperienceDropEvent event) -> {
                    MutableInt droppedExperience = MutableInt.fromEvent(event::setDroppedExperience,
                            event::getDroppedExperience);
                    if (callback.onLivingExperienceDrop(event.getEntity(),
                            event.getAttackingPlayer(),
                            droppedExperience).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(BlockEvents.Break.class,
                BreakBlockEvent.class,
                (BlockEvents.Break callback, BreakBlockEvent event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    if (!(event.getPlayer() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    // match Fabric implementation
                    if (event.getState().getBlock() instanceof GameMasterBlock
                            && !serverPlayer.canUseGameMasterBlocks()) {
                        return;
                    }

                    GameType gameType = serverPlayer.gameMode.getGameModeForPlayer();
                    if (serverPlayer.blockActionRestricted((Level) event.getLevel(), event.getPos(), gameType)) {
                        return;
                    }

                    EventResult eventResult = callback.onBreakBlock(serverLevel,
                            event.getPos(),
                            event.getState(),
                            serverPlayer,
                            serverPlayer.getMainHandItem());
                    if (eventResult.isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(BlockEvents.DropExperience.class,
                BlockDropsEvent.class,
                (BlockEvents.DropExperience callback, BlockDropsEvent event) -> {
                    if (!(event.getBreaker() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    MutableInt experienceAmount = MutableInt.fromEvent(event::setDroppedExperience,
                            event::getDroppedExperience);
                    callback.onDropExperience(event.getLevel(),
                            event.getPos(),
                            event.getState(),
                            serverPlayer,
                            event.getTool(),
                            experienceAmount);
                });
        INSTANCE.register(PlayerTickEvents.Start.class,
                PlayerTickEvent.Pre.class,
                (PlayerTickEvents.Start callback, PlayerTickEvent.Pre event) -> {
                    callback.onStartPlayerTick(event.getEntity());
                });
        INSTANCE.register(PlayerTickEvents.End.class,
                PlayerTickEvent.Post.class,
                (PlayerTickEvents.End callback, PlayerTickEvent.Post event) -> {
                    callback.onEndPlayerTick(event.getEntity());
                });
        INSTANCE.register(LivingFallCallback.class,
                LivingFallEvent.class,
                (LivingFallCallback callback, LivingFallEvent event) -> {
                    MutableDouble fallDistance = MutableDouble.fromEvent(event::setDistance, event::getDistance);
                    MutableFloat damageMultiplier = MutableFloat.fromEvent(event::setDamageMultiplier,
                            event::getDamageMultiplier);
                    if (callback.onLivingFall(event.getEntity(), fallDistance, damageMultiplier).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(RegisterCommandsCallback.class,
                RegisterCommandsEvent.class,
                (RegisterCommandsCallback callback, RegisterCommandsEvent event) -> {
                    callback.onRegisterCommands(event.getDispatcher(),
                            event.getBuildContext(),
                            event.getCommandSelection());
                });
        INSTANCE.register(LootTableLoadCallback.class,
                LootTableLoadEvent.class,
                (LootTableLoadCallback callback, LootTableLoadEvent event) -> {
                    callback.onLootTableLoad(event.getName(),
                            new LootTableBackedBuilder(event.getTable()),
                            event.getRegistries());
                });
        INSTANCE.register(ModifyEnchantmentsCallback.class,
                ModifyEnchantmentsEvent.class,
                (ModifyEnchantmentsCallback callback, ModifyEnchantmentsEvent event) -> {
                    callback.onModifyEnchantment(event.getResourceKey(), event.getBuilder(), event.getLookupProvider());
                });
        INSTANCE.register(ItemEntityEvents.Touch.class,
                ItemEntityPickupEvent.Pre.class,
                (ItemEntityEvents.Touch callback, ItemEntityPickupEvent.Pre event) -> {
                    EventResult eventResult = callback.onItemTouch(event.getPlayer(), event.getItemEntity());
                    if (eventResult.isInterrupt()) {
                        event.setCanPickup(eventResult.getAsBoolean() ? TriState.TRUE : TriState.FALSE);
                    }
                });
        INSTANCE.register(ItemEntityEvents.Pickup.class,
                ItemEntityPickupEvent.Post.class,
                (ItemEntityEvents.Pickup callback, ItemEntityPickupEvent.Post event) -> {
                    callback.onItemPickup(event.getPlayer(), event.getItemEntity(), event.getOriginalStack());
                });
        INSTANCE.register(CreateAnvilResultCallback.class,
                AnvilUpdateEvent.class,
                (CreateAnvilResultCallback callback, AnvilUpdateEvent event) -> {
                    MutableValue<ItemStack> outputItemStack = MutableValue.fromEvent((ItemStack output) -> {
                        Objects.requireNonNull(output, "output is null");
                        event.setOutput(output);
                    }, event::getOutput);
                    MutableInt enchantmentLevelCost = MutableInt.fromEvent(event::setXpCost, event::getXpCost);
                    MutableInt repairMaterialCost = MutableInt.fromEvent(event::setMaterialCost,
                            event::getMaterialCost);
                    if (callback.onCreateAnvilResult(event.getPlayer(),
                            event.getLeft(),
                            event.getRight(),
                            outputItemStack,
                            event.getName(),
                            enchantmentLevelCost,
                            repairMaterialCost).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(CreateGrindstoneResultCallback.class,
                GrindstoneEvent.OnPlaceItem.class,
                (CreateGrindstoneResultCallback callback, GrindstoneEvent.OnPlaceItem event) -> {
                    Map.Entry<GrindstoneMenu, Player> entry = NeoForgeEventImplHelper.getGrindstoneMenuFromInputs(event.getTopItem(),
                            event.getBottomItem());
                    if (entry != null) {
                        Supplier<ItemStack> outputItemStackSupplier = Suppliers.memoize(() -> entry.getKey()
                                .computeResult(event.getTopItem(), event.getBottomItem()));
                        MutableValue<ItemStack> outputItemStack = MutableValue.fromEvent((ItemStack output) -> {
                            Objects.requireNonNull(output, "output is null");
                            event.setOutput(output);
                        }, () -> {
                            return !event.getOutput().isEmpty() ? event.getOutput() : outputItemStackSupplier.get();
                        });
                        MutableInt experiencePointReward = MutableInt.fromEvent(event::setXp, event::getXp);
                        EventResult eventResult = callback.onCreateGrindstoneResult(entry.getValue(),
                                event.getTopItem(),
                                event.getBottomItem(),
                                outputItemStack,
                                experiencePointReward);
                        if (eventResult.isInterrupt()) {
                            event.setCanceled(true);
                        }
                    }
                });
        INSTANCE.register(LivingDropsCallback.class,
                LivingDropsEvent.class,
                (LivingDropsCallback callback, LivingDropsEvent event) -> {
                    if (callback.onLivingDrops(event.getEntity(),
                            event.getSource(),
                            event.getDrops(),
                            event.isRecentlyHit()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(EntityTickEvents.Start.class,
                EntityTickEvent.Pre.class,
                (EntityTickEvents.Start callback, EntityTickEvent.Pre event) -> {
                    if (callback.onStartEntityTick(event.getEntity()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(EntityTickEvents.End.class,
                EntityTickEvent.Post.class,
                (EntityTickEvents.End callback, EntityTickEvent.Post event) -> {
                    callback.onEndEntityTick(event.getEntity());
                });
        INSTANCE.register(ArrowLooseCallback.class,
                ArrowLooseEvent.class,
                (ArrowLooseCallback callback, ArrowLooseEvent event) -> {
                    MutableInt timeHeld = MutableInt.fromEvent(event::setCharge, event::getCharge);
                    if (callback.onArrowLoose(event.getEntity(), event.getBow(), event.getLevel(), timeHeld)
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(LivingHurtCallback.class,
                LivingDamageEvent.Pre.class,
                (LivingHurtCallback callback, LivingDamageEvent.Pre event) -> {
                    MutableFloat damageAmount = MutableFloat.fromEvent(event::setNewDamage, event::getNewDamage);
                    if (callback.onLivingHurt(event.getEntity(), event.getSource(), damageAmount).isInterrupt()) {
                        // this effectively cancels the event
                        event.setNewDamage(0.0F);
                    }
                });
        INSTANCE.register(UseItemEvents.Start.class,
                LivingEntityUseItemEvent.Start.class,
                (UseItemEvents.Start callback, LivingEntityUseItemEvent.Start event) -> {
                    MutableInt useDuration = MutableInt.fromEvent(event::setDuration, event::getDuration);
                    if (callback.onUseItemStart(event.getEntity(), event.getItem(), event.getHand(), useDuration)
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(UseItemEvents.Tick.class,
                LivingEntityUseItemEvent.Tick.class,
                (UseItemEvents.Tick callback, LivingEntityUseItemEvent.Tick event) -> {
                    MutableInt useItemRemaining = MutableInt.fromEvent(event::setDuration, event::getDuration);
                    if (callback.onUseItemTick(event.getEntity(), event.getItem(), event.getHand(), useItemRemaining)
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(UseItemEvents.Stop.class,
                LivingEntityUseItemEvent.Stop.class,
                (UseItemEvents.Stop callback, LivingEntityUseItemEvent.Stop event) -> {
                    // Forge event also supports changing duration, but it remains unused
                    if (callback.onUseItemStop(event.getEntity(), event.getItem(), event.getHand(), event.getDuration())
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(UseItemEvents.Finish.class,
                LivingEntityUseItemEvent.Finish.class,
                (UseItemEvents.Finish callback, LivingEntityUseItemEvent.Finish event) -> {
                    MutableValue<ItemStack> itemStack = MutableValue.fromEvent((ItemStack result) -> {
                        Objects.requireNonNull(result, "result is null");
                        event.setResultStack(result);
                    }, event::getResultStack);
                    callback.onUseItemFinish(event.getEntity(), itemStack, event.getItem(), event.getHand());
                });
        INSTANCE.register(ShieldBlockCallback.class,
                LivingShieldBlockEvent.class,
                (ShieldBlockCallback callback, LivingShieldBlockEvent event) -> {
                    if (!event.getBlocked()) {
                        return;
                    }

                    MutableFloat blockedDamage = MutableFloat.fromEvent(event::setBlockedDamage,
                            event::getBlockedDamage);
                    if (callback.onShieldBlock(event.getEntity(), event.getDamageSource(), blockedDamage)
                            .isInterrupt()) {
                        event.setBlocked(true);
                    }
                });
        INSTANCE.register(ServerResourcesLoadCallback.class,
                TagsUpdatedEvent.ServerDataLoad.class,
                (ServerResourcesLoadCallback callback, TagsUpdatedEvent.ServerDataLoad event) -> {
                    callback.onServerResourcesLoad(event.getServerResources(), event.getRegistries());
                });
        INSTANCE.register(ExplosionEvents.Start.class,
                ExplosionEvent.Start.class,
                (ExplosionEvents.Start callback, ExplosionEvent.Start event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    if (callback.onExplosionStart(serverLevel, event.getExplosion()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(ExplosionEvents.Detonate.class,
                ExplosionEvent.Detonate.class,
                (ExplosionEvents.Detonate callback, ExplosionEvent.Detonate event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onExplosionDetonate(serverLevel,
                            event.getExplosion(),
                            event.getAffectedBlocks(),
                            event.getAffectedEntities());
                });
        INSTANCE.register(SyncDataPackContentsCallback.class,
                OnDatapackSyncEvent.class,
                (SyncDataPackContentsCallback callback, OnDatapackSyncEvent event) -> {
                    event.getRelevantPlayers().forEach((ServerPlayer player) -> {
                        callback.onSyncDataPackContents(player, event.getPlayer() != null);
                    });
                });
        INSTANCE.register(ServerLifecycleEvents.Starting.class,
                ServerAboutToStartEvent.class,
                (ServerLifecycleEvents.Starting callback, ServerAboutToStartEvent event) -> {
                    callback.onServerStarting(event.getServer());
                });
        INSTANCE.register(ServerLifecycleEvents.Started.class,
                ServerStartedEvent.class,
                (ServerLifecycleEvents.Started callback, ServerStartedEvent event) -> {
                    callback.onServerStarted(event.getServer());
                });
        INSTANCE.register(ServerLifecycleEvents.Stopping.class,
                ServerStoppingEvent.class,
                (ServerLifecycleEvents.Stopping callback, ServerStoppingEvent event) -> {
                    callback.onServerStopping(event.getServer());
                });
        INSTANCE.register(ServerLifecycleEvents.Stopped.class,
                ServerStoppedEvent.class,
                (ServerLifecycleEvents.Stopped callback, ServerStoppedEvent event) -> {
                    callback.onServerStopped(event.getServer());
                });
        INSTANCE.register(PlaySoundEvents.AtPosition.class,
                PlayLevelSoundEvent.AtPosition.class,
                (PlaySoundEvents.AtPosition callback, PlayLevelSoundEvent.AtPosition event) -> {
                    MutableValue<Holder<SoundEvent>> soundEvent = MutableValue.fromEvent(event::setSound,
                            event::getSound);
                    MutableValue<SoundSource> soundSource = MutableValue.fromEvent(event::setSource, event::getSource);
                    MutableFloat soundVolume = MutableFloat.fromEvent(event::setNewVolume, event::getNewVolume);
                    MutableFloat soundPitch = MutableFloat.fromEvent(event::setNewPitch, event::getNewPitch);
                    if (callback.onPlaySoundAtPosition(event.getLevel(),
                            event.getPosition(),
                            soundEvent,
                            soundSource,
                            soundVolume,
                            soundPitch).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(PlaySoundEvents.AtEntity.class,
                PlayLevelSoundEvent.AtEntity.class,
                (PlaySoundEvents.AtEntity callback, PlayLevelSoundEvent.AtEntity event) -> {
                    MutableValue<Holder<SoundEvent>> soundEvent = MutableValue.fromEvent(event::setSound,
                            event::getSound);
                    MutableValue<SoundSource> soundSource = MutableValue.fromEvent(event::setSource, event::getSource);
                    MutableFloat soundVolume = MutableFloat.fromEvent(event::setNewVolume, event::getNewVolume);
                    MutableFloat soundPitch = MutableFloat.fromEvent(event::setNewPitch, event::getNewPitch);
                    if (callback.onPlaySoundAtEntity(event.getLevel(),
                            event.getEntity(),
                            soundEvent,
                            soundSource,
                            soundVolume,
                            soundPitch).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        // For NeoForge these use the same event, as the chunk access deadlock is fixed by the mod loader itself.
        INSTANCE.register(ServerEntityEvents.Join.class,
                EntityJoinLevelEvent.class,
                (ServerEntityEvents.Join callback, EntityJoinLevelEvent event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    EntitySpawnReason entitySpawnReason =
                            event.getEntity() instanceof Mob mob ? mob.getSpawnType() : null;
                    if (callback.onEntityJoin(event.getEntity(), serverLevel, event.loadedFromDisk(), entitySpawnReason)
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(ServerEntityEvents.Load.class,
                EntityJoinLevelEvent.class,
                (ServerEntityEvents.Load callback, EntityJoinLevelEvent event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    boolean removed = event.getEntity().isRemoved();
                    EntitySpawnReason entitySpawnReason =
                            event.getEntity() instanceof Mob mob ? mob.getSpawnType() : null;
                    callback.onEntityLoad(event.getEntity(), serverLevel, event.loadedFromDisk(), entitySpawnReason);
                    // Solely marking the entity as removed does nothing with the current event on NeoForge.
                    if (!removed && event.getEntity().isRemoved()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(ServerEntityEvents.Unload.class,
                EntityLeaveLevelEvent.class,
                (ServerEntityEvents.Unload callback, EntityLeaveLevelEvent event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onEntityUnload(event.getEntity(), serverLevel);
                });
        INSTANCE.register(LivingDeathCallback.class,
                LivingDeathEvent.class,
                (LivingDeathCallback callback, LivingDeathEvent event) -> {
                    if (callback.onLivingDeath(event.getEntity(), event.getSource()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(PlayerTrackingEvents.Start.class,
                PlayerEvent.StartTracking.class,
                (PlayerTrackingEvents.Start callback, PlayerEvent.StartTracking event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onStartTracking(event.getTarget(), serverPlayer);
                });
        INSTANCE.register(PlayerTrackingEvents.Stop.class,
                PlayerEvent.StopTracking.class,
                (PlayerTrackingEvents.Stop callback, PlayerEvent.StopTracking event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onStopTracking(event.getTarget(), serverPlayer);
                });
        INSTANCE.register(PlayerNetworkEvents.Join.class,
                PlayerEvent.PlayerLoggedInEvent.class,
                (PlayerNetworkEvents.Join callback, PlayerEvent.PlayerLoggedInEvent event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onPlayerJoin(serverPlayer);
                });
        INSTANCE.register(PlayerNetworkEvents.Leave.class,
                PlayerEvent.PlayerLoggedOutEvent.class,
                (PlayerNetworkEvents.Leave callback, PlayerEvent.PlayerLoggedOutEvent event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onPlayerLeave(serverPlayer);
                });
        INSTANCE.register(AfterChangeDimensionCallback.class,
                PlayerEvent.PlayerChangedDimensionEvent.class,
                (AfterChangeDimensionCallback callback, PlayerEvent.PlayerChangedDimensionEvent event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    ServerLevel originalLevel = serverPlayer.level().getServer().getLevel(event.getFrom());
                    ServerLevel newLevel = serverPlayer.level().getServer().getLevel(event.getTo());
                    Objects.requireNonNull(originalLevel, "original level is null");
                    Objects.requireNonNull(newLevel, "new level is null");
                    callback.onAfterChangeDimension(serverPlayer, originalLevel, newLevel);
                });
        INSTANCE.register(BabyEntitySpawnCallback.class,
                BabyEntitySpawnEvent.class,
                (BabyEntitySpawnCallback callback, BabyEntitySpawnEvent event) -> {
                    MutableValue<AgeableMob> child = MutableValue.fromEvent(event::setChild, event::getChild);
                    if (callback.onBabyEntitySpawn(event.getParentA(), event.getParentB(), child).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(AnimalTameCallback.class,
                AnimalTameEvent.class,
                (AnimalTameCallback callback, AnimalTameEvent event) -> {
                    if (callback.onAnimalTame(event.getAnimal(), event.getTamer()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(LivingAttackCallback.class,
                LivingIncomingDamageEvent.class,
                (LivingAttackCallback callback, LivingIncomingDamageEvent event) -> {
                    if (callback.onLivingAttack(event.getEntity(), event.getSource(), event.getAmount())
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(PlayerCopyEvents.Copy.class,
                PlayerEvent.Clone.class,
                (PlayerCopyEvents.Copy callback, PlayerEvent.Clone event) -> {
                    if (!(event.getOriginal() instanceof ServerPlayer originalServerPlayer)) {
                        return;
                    }

                    if (!(event.getEntity() instanceof ServerPlayer newServerPlayer)) {
                        return;
                    }

                    callback.onCopy(originalServerPlayer, newServerPlayer, !event.isWasDeath());
                });
        INSTANCE.register(PlayerCopyEvents.Respawn.class,
                PlayerEvent.PlayerRespawnEvent.class,
                (PlayerCopyEvents.Respawn callback, PlayerEvent.PlayerRespawnEvent event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onRespawn(serverPlayer, event.isEndConquered());
                });
        INSTANCE.register(ServerTickEvents.Start.class,
                ServerTickEvent.Pre.class,
                (ServerTickEvents.Start callback, ServerTickEvent.Pre event) -> {
                    callback.onStartServerTick(event.getServer());
                });
        INSTANCE.register(ServerTickEvents.End.class,
                ServerTickEvent.Post.class,
                (ServerTickEvents.End callback, ServerTickEvent.Post event) -> {
                    callback.onEndServerTick(event.getServer());
                });
        INSTANCE.register(ServerLevelTickEvents.Start.class,
                LevelTickEvent.Pre.class,
                (ServerLevelTickEvents.Start callback, LevelTickEvent.Pre event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onStartLevelTick(serverLevel.getServer(), serverLevel);
                });
        INSTANCE.register(ServerLevelTickEvents.End.class,
                LevelTickEvent.Post.class,
                (ServerLevelTickEvents.End callback, LevelTickEvent.Post event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onEndLevelTick(serverLevel.getServer(), serverLevel);
                });
        INSTANCE.register(ServerLevelEvents.Load.class,
                LevelEvent.Load.class,
                (ServerLevelEvents.Load callback, LevelEvent.Load event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onLevelLoad(serverLevel.getServer(), serverLevel);
                });
        INSTANCE.register(ServerLevelEvents.Unload.class,
                LevelEvent.Unload.class,
                (ServerLevelEvents.Unload callback, LevelEvent.Unload event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onLevelUnload(serverLevel.getServer(), serverLevel);
                });
        INSTANCE.register(ServerChunkEvents.Load.class,
                ChunkEvent.Load.class,
                (ServerChunkEvents.Load callback, ChunkEvent.Load event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onChunkLoad(serverLevel, event.getChunk(), event.isNewChunk());
                });
        INSTANCE.register(ServerChunkEvents.Unload.class,
                ChunkEvent.Unload.class,
                (ServerChunkEvents.Unload callback, ChunkEvent.Unload event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    callback.onChunkUnload(serverLevel, event.getChunk());
                });
        INSTANCE.register(ItemEntityEvents.Toss.class,
                ItemTossEvent.class,
                (ItemEntityEvents.Toss callback, ItemTossEvent event) -> {
                    if (!(event.getPlayer() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    if (callback.onItemToss(serverPlayer, event.getEntity().getItem()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(LivingKnockBackCallback.class,
                LivingKnockBackEvent.class,
                (LivingKnockBackCallback callback, LivingKnockBackEvent event) -> {
                    MutableDouble strength = MutableDouble.fromEvent((double v) -> event.setStrength((float) v),
                            event::getStrength);
                    MutableDouble ratioX = MutableDouble.fromEvent(event::setRatioX, event::getRatioX);
                    MutableDouble ratioZ = MutableDouble.fromEvent(event::setRatioZ, event::getRatioZ);
                    if (callback.onLivingKnockBack(event.getEntity(), strength, ratioX, ratioZ).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(ProjectileImpactCallback.class,
                ProjectileImpactEvent.class,
                (ProjectileImpactCallback callback, ProjectileImpactEvent event) -> {
                    if (callback.onProjectileImpact(event.getProjectile(), event.getRayTraceResult()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(CalculateBlockBreakSpeedCallback.class,
                PlayerEvent.BreakSpeed.class,
                (CalculateBlockBreakSpeedCallback callback, PlayerEvent.BreakSpeed event) -> {
                    MutableFloat breakSpeed = MutableFloat.fromEvent(event::setNewSpeed, event::getNewSpeed);
                    if (callback.onCalculateBlockBreakSpeed(event.getEntity(), event.getState(), breakSpeed)
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(MobEffectEvents.Affects.class,
                MobEffectEvent.Applicable.class,
                (MobEffectEvents.Affects callback, MobEffectEvent.Applicable event) -> {
                    EventResult eventResult = callback.onMobEffectAffects(event.getEntity(), event.getEffectInstance());
                    if (eventResult.isInterrupt()) {
                        event.setResult(eventResult.getAsBoolean() ? MobEffectEvent.Applicable.Result.APPLY :
                                MobEffectEvent.Applicable.Result.DO_NOT_APPLY);
                    }
                });
        INSTANCE.register(MobEffectEvents.Apply.class,
                MobEffectEvent.Added.class,
                (MobEffectEvents.Apply callback, MobEffectEvent.Added event) -> {
                    callback.onMobEffectApply(event.getEntity(),
                            event.getEffectInstance(),
                            event.getOldEffectInstance(),
                            event.getEffectSource());
                });
        INSTANCE.register(MobEffectEvents.Remove.class,
                MobEffectEvent.Remove.class,
                (MobEffectEvents.Remove callback, MobEffectEvent.Remove event) -> {
                    if (event.getEffectInstance() == null) {
                        return;
                    }

                    if (callback.onMobEffectRemove(event.getEntity(), event.getEffectInstance()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(MobEffectEvents.Expire.class,
                MobEffectEvent.Expired.class,
                (MobEffectEvents.Expire callback, MobEffectEvent.Expired event) -> {
                    if (callback.onMobEffectExpire(event.getEntity(), event.getEffectInstance()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(LivingJumpCallback.class,
                LivingEvent.LivingJumpEvent.class,
                (LivingJumpCallback callback, LivingEvent.LivingJumpEvent event) -> {
                    EventImplHelper.onLivingJump(callback, event.getEntity());
                });
        INSTANCE.register(CalculateLivingVisibilityCallback.class,
                LivingEvent.LivingVisibilityEvent.class,
                (CalculateLivingVisibilityCallback callback, LivingEvent.LivingVisibilityEvent event) -> {
                    callback.onCalculateLivingVisibility(event.getEntity(),
                            event.getLookingEntity(),
                            MutableDouble.fromEvent((double visibilityModifier) -> {
                                event.modifyVisibility(visibilityModifier / event.getVisibilityModifier());
                            }, event::getVisibilityModifier));
                });
        INSTANCE.register(LivingChangeTargetCallback.class,
                LivingChangeTargetEvent.class,
                (LivingChangeTargetCallback callback, LivingChangeTargetEvent event) -> {
                    MutableValue<@Nullable LivingEntity> target = MutableValue.fromEvent(event::setNewAboutToBeSetTarget,
                            event::getNewAboutToBeSetTarget);
                    if (callback.onLivingChangeTarget(event.getEntity(), target).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(CheckMobDespawnCallback.class,
                MobDespawnEvent.class,
                (CheckMobDespawnCallback callback, MobDespawnEvent event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    EventResult eventResult = callback.onCheckMobDespawn(event.getEntity(), serverLevel);
                    if (eventResult.isInterrupt()) {
                        event.setResult(eventResult.getAsBoolean() ? MobDespawnEvent.Result.ALLOW :
                                MobDespawnEvent.Result.DENY);
                    }
                });
        INSTANCE.register(GatherPotentialSpawnsCallback.class,
                LevelEvent.PotentialSpawns.class,
                (GatherPotentialSpawnsCallback callback, LevelEvent.PotentialSpawns event) -> {
                    if (!(event.getLevel() instanceof ServerLevel serverLevel)) {
                        return;
                    }

                    List<Weighted<MobSpawnSettings.SpawnerData>> mobs = new PotentialSpawnsList<>(event::getSpawnerDataList,
                            (Weighted<MobSpawnSettings.SpawnerData> spawnerData) -> {
                                int size = event.getSpawnerDataList().size();
                                event.addSpawnerData(spawnerData);
                                return size != event.getSpawnerDataList().size();
                            },
                            (Weighted<MobSpawnSettings.SpawnerData> spawnerData) -> {
                                int size = event.getSpawnerDataList().size();
                                event.removeSpawnerData(spawnerData);
                                return size != event.getSpawnerDataList().size();
                            });
                    callback.onGatherPotentialSpawns(serverLevel,
                            serverLevel.structureManager(),
                            serverLevel.getChunkSource().getGenerator(),
                            event.getMobCategory(),
                            event.getPos(),
                            mobs);
                });
        INSTANCE.register(EntityRidingEvents.Start.class,
                EntityMountEvent.class,
                (EntityRidingEvents.Start callback, EntityMountEvent event) -> {
                    if (event.isDismounting()) {
                        return;
                    }

                    // same implementation as Fabric
                    if (!((EntityNeoForgeAccessor) event.getEntityMounting()).puzzleslib$canRide(event.getEntityBeingMounted())) {
                        return;
                    }

                    if (!((EntityNeoForgeAccessor) event.getEntityBeingMounted()).puzzleslib$canAddPassenger(event.getEntityMounting())) {
                        return;
                    }

                    if (callback.onStartRiding(event.getLevel(),
                            event.getEntityMounting(),
                            event.getEntityBeingMounted()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(EntityRidingEvents.Stop.class,
                EntityMountEvent.class,
                (EntityRidingEvents.Stop callback, EntityMountEvent event) -> {
                    if (event.isMounting()) {
                        return;
                    }

                    if (callback.onStopRiding(event.getLevel(), event.getEntity(), event.getEntityBeingMounted())
                            .isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(ServerChunkEvents.Watch.class,
                ChunkWatchEvent.Watch.class,
                (ServerChunkEvents.Watch callback, ChunkWatchEvent.Watch event) -> {
                    callback.onChunkWatch(event.getPlayer(), event.getChunk(), event.getLevel());
                });
        INSTANCE.register(ServerChunkEvents.Unwatch.class,
                ChunkWatchEvent.UnWatch.class,
                (ServerChunkEvents.Unwatch callback, ChunkWatchEvent.UnWatch event) -> {
                    callback.onChunkUnwatch(event.getPlayer(), event.getPos(), event.getLevel());
                });
        INSTANCE.register(LivingEquipmentChangeCallback.class,
                LivingEquipmentChangeEvent.class,
                (LivingEquipmentChangeCallback callback, LivingEquipmentChangeEvent event) -> {
                    callback.onLivingEquipmentChange(event.getEntity(),
                            event.getSlot(),
                            event.getFrom(),
                            event.getTo());
                });
        INSTANCE.register(LivingConversionCallback.class,
                LivingConversionEvent.Post.class,
                (LivingConversionCallback callback, LivingConversionEvent.Post event) -> {
                    callback.onLivingConversion(event.getEntity(), event.getOutcome());
                });
        INSTANCE.register(ContainerEvents.Open.class,
                PlayerContainerEvent.Open.class,
                (ContainerEvents.Open callback, PlayerContainerEvent.Open event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onContainerOpen(serverPlayer, event.getContainer());
                });
        INSTANCE.register(ContainerEvents.Close.class,
                PlayerContainerEvent.Close.class,
                (ContainerEvents.Close callback, PlayerContainerEvent.Close event) -> {
                    if (!(event.getEntity() instanceof ServerPlayer serverPlayer)) {
                        return;
                    }

                    callback.onContainerClose(serverPlayer, event.getContainer());
                });
        INSTANCE.register(LookingAtEndermanCallback.class,
                EndermanAngerEvent.class,
                (LookingAtEndermanCallback callback, EndermanAngerEvent event) -> {
                    if (callback.onLookingAtEndermanCallback(event.getEntity(), event.getPlayer()).isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(RefreshEntityDimensionsCallback.class,
                EntityEvent.Size.class,
                (RefreshEntityDimensionsCallback callback, EntityEvent.Size event) -> {
                    EventResultHolder<EntityDimensions> eventResult = callback.onRefreshEntityDimensions(event.getEntity(),
                            event.getPose(),
                            event.getOldSize());
                    eventResult.ifInterrupt(event::setNewSize);
                });
        INSTANCE.register(PickProjectileCallback.class,
                LivingGetProjectileEvent.class,
                (PickProjectileCallback callback, LivingGetProjectileEvent event) -> {
                    MutableValue<ItemStack> ammoItemStack = MutableValue.fromEvent((ItemStack projectile) -> {
                        Objects.requireNonNull(projectile, "projectile is null");
                        event.setProjectileItemStack(projectile);
                    }, event::getProjectileItemStack);
                    callback.onPickProjectile(event.getEntity(), event.getProjectileWeaponItemStack(), ammoItemStack);
                });
        INSTANCE.register(EnderPearlTeleportCallback.class,
                EntityTeleportEvent.EnderPearl.class,
                (EnderPearlTeleportCallback callback, EntityTeleportEvent.EnderPearl event) -> {
                    EventResult eventResult = callback.onEnderPearlTeleport(event.getPlayer(),
                            event.getTarget(),
                            event.getPearlEntity(),
                            MutableFloat.fromEvent(event::setAttackDamage, event::getAttackDamage),
                            event.getHitResult());
                    if (eventResult.isInterrupt()) {
                        event.setCanceled(true);
                    }
                });
        INSTANCE.register(GameRuleUpdatedCallback.class,
                GameRuleChangedEvent.class,
                (GameRuleUpdatedCallback callback, GameRuleChangedEvent event, @Nullable Object context) -> {
                    Objects.requireNonNull(context, "context is null");
                    GameRule<?> gameRule = (GameRule<?>) context;
                    if (gameRule == event.getGameRule()) {
                        callback.onGameRuleUpdated(event.getServer(), event.getGameRule(), event.getNewValue());
                    }
                });
        INSTANCE.register(StopSleepInBedCallback.class,
                PlayerWakeUpEvent.class,
                (StopSleepInBedCallback callback, PlayerWakeUpEvent event) -> {
                    if (event.getEntity() instanceof ServerPlayer serverPlayer) {
                        callback.onStopSleepInBed(serverPlayer, !event.wakeImmediately() && !event.updateLevel());
                    }
                });
        INSTANCE.register(EntityDamageImmunityCallback.class,
                EntityInvulnerabilityCheckEvent.class,
                (EntityDamageImmunityCallback callback, EntityInvulnerabilityCheckEvent event) -> {
                    MutableBoolean isInvulnerable = MutableBoolean.fromEvent(event::setInvulnerable,
                            event::isInvulnerable);
                    callback.onEntityDamageImmunity(event.getEntity(), event.getSource(), isInvulnerable);
                });
        INSTANCE.register(ItemClickBehaviorCallback.class,
                ItemStackedOnOtherEvent.class,
                (ItemClickBehaviorCallback callback, ItemStackedOnOtherEvent event) -> {
                    EventResult eventResult = callback.onItemClickBehavior(event.getStackedOnItem(),
                            event.getSlot(),
                            event.getCarriedItem(),
                            event.getCarriedSlotAccess(),
                            event.getClickAction(),
                            event.getPlayer());
                    if (eventResult.isInterrupt()) {
                        event.cancelWithResult(!eventResult.getAsBoolean());
                    }
                });
    }
}
