package fuzs.puzzleslib.common.impl.init;

import com.google.common.base.Preconditions;
import fuzs.puzzleslib.common.api.core.v1.ModLoader;
import fuzs.puzzleslib.common.api.core.v1.ModLoaderEnvironment;
import fuzs.puzzleslib.common.api.init.v3.registry.RegistryManager;
import fuzs.puzzleslib.common.impl.core.Freezable;
import fuzs.puzzleslib.common.impl.item.CreativeModeTabHelper;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemStackLinkedSet;
import org.apache.commons.lang3.StringUtils;

import java.util.*;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;

public abstract class RegistryManagerImpl implements RegistryManager, Freezable {
    protected final String modId;
    protected Set<ModLoader> allowedModLoaders = EnumSet.allOf(ModLoader.class);

    protected RegistryManagerImpl(String modId) {
        this.modId = modId;
        Preconditions.checkArgument(StringUtils.isNotEmpty(modId), "mod id is invalid");
    }

    @Override
    public Identifier makeKey(String path) {
        Preconditions.checkArgument(StringUtils.isNotEmpty(path), "path is invalid");
        return Identifier.fromNamespaceAndPath(this.modId, path);
    }

    @Override
    public RegistryManager whenOn(ModLoader... allowedModLoaders) {
        Preconditions.checkState(allowedModLoaders.length > 0, "mod loaders is empty");
        this.allowedModLoaders = EnumSet.copyOf(Arrays.asList(allowedModLoaders));
        return this;
    }

    @Override
    public final <T> Holder.Reference<T> register(final ResourceKey<? extends Registry<? super T>> registryKey, String path, Supplier<T> supplier) {
        this.isWritableOrThrow();
        return this.register(registryKey, path, supplier, false);
    }

    public final <T> Holder.Reference<T> register(final ResourceKey<? extends Registry<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration) {
        Objects.requireNonNull(registryKey, "registry key is null");
        Preconditions.checkArgument(StringUtils.isNotEmpty(path), "path is invalid");
        Objects.requireNonNull(supplier, "supplier is null");
        Holder.Reference<T> holder;
        if (!this.allowedModLoaders.contains(ModLoaderEnvironment.INSTANCE.getModLoader())) {
            holder = this.registerLazily(registryKey, path);
        } else {
            holder = this.getHolderReference(registryKey, path, supplier, skipRegistration);
        }

        this.allowedModLoaders = EnumSet.allOf(ModLoader.class);
        Objects.requireNonNull(holder, "holder is null");
        return holder;
    }

    protected abstract <T> Holder.Reference<T> getHolderReference(ResourceKey<? extends Registry<? super T>> registryKey, String path, Supplier<T> supplier, boolean skipRegistration);

    /**
     * @see net.minecraft.world.item.CreativeModeTab.ItemDisplayBuilder#accept(ItemStack,
     *         CreativeModeTab.TabVisibility)
     */
    @Override
    public Holder.Reference<CreativeModeTab> registerCreativeModeTab(String path, Supplier<ItemStack> iconSupplier, UnaryOperator<CreativeModeTab.DisplayItemsGenerator> displayItems, boolean hasSearchBar) {
        return this.register(Registries.CREATIVE_MODE_TAB, path, () -> {
            CreativeModeTab.Builder builder = this.getCreativeModeTabBuilder(hasSearchBar);
            builder.title(CreativeModeTabHelper.getTitle(this.makeKey(path)));
            builder.icon(iconSupplier);
            builder.displayItems((CreativeModeTab.ItemDisplayParameters parameters, CreativeModeTab.Output output) -> {
                Collection<ItemStack> tabContents = ItemStackLinkedSet.createTypeAndComponentsSet();
                displayItems.apply(CreativeModeTabHelper.getDisplayItems(this.modId))
                        .accept(parameters, (ItemStack itemStack, CreativeModeTab.TabVisibility tabVisibility) -> {
                            if (!tabContents.contains(itemStack)
                                    || tabVisibility == CreativeModeTab.TabVisibility.SEARCH_TAB_ONLY) {
                                tabContents.add(itemStack);
                                output.accept(itemStack, tabVisibility);
                            }
                        });
            });
            return builder.build();
        });
    }

    protected abstract CreativeModeTab.Builder getCreativeModeTabBuilder(boolean hasSearchBar);
}
