package fuzs.puzzleslib.common.api.event.v1.server;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.common.impl.core.proxy.ProxyImpl;
import net.minecraft.core.HolderGetter;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;

import java.util.Objects;
import java.util.function.Consumer;

@FunctionalInterface
public interface LootTableLoadCallback {
    EventInvoker<LootTableLoadCallback> EVENT = EventInvoker.lookup(LootTableLoadCallback.class);

    /**
     * Runs for every loot table upon loading, allows for modifying the loot table.
     *
     * @param identifier the loot table id
     * @param lootTable  the loot table builder instance
     * @param registries the registry access
     */
    void onLootTableLoad(Identifier identifier, LootTable.Builder lootTable, HolderGetter.Provider registries);

    /**
     * Allows for modifying each existing loot pool in a loot table.
     * <p>
     * Can only be used inside {@link LootTableLoadCallback}.
     *
     * @param table        the loot table builder instance
     * @param poolConsumer the consumer to apply to each loot pool inside
     */
    static void forEachPool(LootTable.Builder table, Consumer<? super LootPool.Builder> poolConsumer) {
        Objects.requireNonNull(table, "loot table is null");
        Objects.requireNonNull(poolConsumer, "loot pool consumer is null");
        ProxyImpl.get().forEachPool(table, poolConsumer);
    }
}
