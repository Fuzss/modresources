package fuzs.puzzleslib.common.api.client.event.v1.renderer;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.common.api.event.v1.data.MutableFloat;
import net.minecraft.client.Camera;

@FunctionalInterface
public interface ComputeFieldOfViewCallback {
    EventInvoker<ComputeFieldOfViewCallback> EVENT = EventInvoker.lookup(ComputeFieldOfViewCallback.class);

    /**
     * Runs after the field of view is calculated, based on the game setting, but before in-game effects such as nausea
     * are applied.
     *
     * @param camera      the client camera instance
     * @param partialTick the partial tick
     * @param fieldOfView the field of view value
     */
    void onComputeFieldOfView(Camera camera, float partialTick, MutableFloat fieldOfView);
}
