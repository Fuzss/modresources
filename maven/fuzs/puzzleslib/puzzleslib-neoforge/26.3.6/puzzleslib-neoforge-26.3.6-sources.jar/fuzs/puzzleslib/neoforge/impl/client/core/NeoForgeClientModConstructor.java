package fuzs.puzzleslib.neoforge.impl.client.core;

import fuzs.puzzleslib.common.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.common.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.neoforge.api.core.v1.NeoForgeModContainerHelper;
import fuzs.puzzleslib.neoforge.impl.client.core.context.*;
import fuzs.puzzleslib.neoforge.impl.core.context.AbstractNeoForgeContext;
import net.minecraft.server.packs.PackType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.event.AddPackFindersEvent;

public final class NeoForgeClientModConstructor implements ModConstructorImpl<ClientModConstructor> {

    @Override
    public void construct(String modId, ClientModConstructor modConstructor) {
        NeoForgeModContainerHelper.getOptionalModEventBus(modId).ifPresent((IEventBus eventBus) -> {
            ParticleProvidersContextNeoForgeImpl[] particleProvidersContext = new ParticleProvidersContextNeoForgeImpl[1];
            ItemModelsContextNeoForgeImpl[] itemModelsContext = new ItemModelsContextNeoForgeImpl[1];
            modConstructor.onConstructMod();
            eventBus.addListener((final FMLClientSetupEvent event) -> {
                event.enqueueWork(modConstructor::onClientSetup);
            });
            eventBus.addListener((final RegisterItemModelsEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(itemModelsContext,
                        ItemModelsContextNeoForgeImpl::new,
                        modConstructor::onRegisterItemModels).registerForEvent(event);
            });
            eventBus.addListener((final RegisterSpecialModelRendererEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(itemModelsContext,
                        ItemModelsContextNeoForgeImpl::new,
                        modConstructor::onRegisterItemModels).registerForEvent(event);
            });
            eventBus.addListener((final RegisterColorHandlersEvent.ItemTintSources event) -> {
                AbstractNeoForgeContext.computeIfAbsent(itemModelsContext,
                        ItemModelsContextNeoForgeImpl::new,
                        modConstructor::onRegisterItemModels).registerForEvent(event);
            });
            eventBus.addListener((final RegisterSelectItemModelPropertyEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(itemModelsContext,
                        ItemModelsContextNeoForgeImpl::new,
                        modConstructor::onRegisterItemModels).registerForEvent(event);
            });
            eventBus.addListener((final RegisterConditionalItemModelPropertyEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(itemModelsContext,
                        ItemModelsContextNeoForgeImpl::new,
                        modConstructor::onRegisterItemModels).registerForEvent(event);
            });
            eventBus.addListener((final RegisterRangeSelectItemModelPropertyEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(itemModelsContext,
                        ItemModelsContextNeoForgeImpl::new,
                        modConstructor::onRegisterItemModels).registerForEvent(event);
            });
            eventBus.addListener((final RegisterMenuScreensEvent event) -> {
                modConstructor.onRegisterMenuScreens(new MenuScreensContextNeoForgeImpl(event));
            });
            eventBus.addListener((final EntityRenderersEvent.RegisterRenderers event) -> {
                modConstructor.onRegisterEntityRenderers(new EntityRenderersContextNeoForgeImpl(event));
                modConstructor.onRegisterBlockEntityRenderers(new BlockEntityRenderersContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterClientTooltipComponentFactoriesEvent event) -> {
                modConstructor.onRegisterClientTooltipComponents(new ClientTooltipComponentsContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterParticleProvidersEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(particleProvidersContext,
                        ParticleProvidersContextNeoForgeImpl::new,
                        modConstructor::onRegisterParticleProviders).registerForEvent(event);
            });
            eventBus.addListener((final RegisterParticleGroupsEvent event) -> {
                AbstractNeoForgeContext.computeIfAbsent(particleProvidersContext,
                        ParticleProvidersContextNeoForgeImpl::new,
                        modConstructor::onRegisterParticleProviders).registerForEvent(event);
            });
            eventBus.addListener((final EntityRenderersEvent.RegisterLayerDefinitions event) -> {
                modConstructor.onRegisterLayerDefinitions(new LayerDefinitionsContextNeoForgeImpl(event));
            });
            eventBus.addListener((final ModelEvent.ModifyBakingResult event) -> {
                modConstructor.onRegisterBlockStateResolver(new BlockStateResolverContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterEntitySpectatorShadersEvent event) -> {
                modConstructor.onRegisterEntitySpectatorShaders(new EntitySpectatorShadersContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterBlockModelsEvent event) -> {
                modConstructor.onRegisterBuiltInBlockModels(new BuiltInBlockModelsContextNeoForgeImpl(event));
            });
            eventBus.addListener((final EntityRenderersEvent.CreateSkullModels event) -> {
                modConstructor.onRegisterSkullRenderers(new SkullRenderersContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterKeyMappingsEvent event) -> {
                modConstructor.onRegisterKeyMappings(new KeyMappingsContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterColorHandlersEvent.BlockTintSources event) -> {
                modConstructor.onRegisterBlockColorProviders(new BlockColorsContextNeoForgeImpl(event));
            });
            eventBus.addListener((final AddPackFindersEvent event) -> {
                if (event.getPackType() == PackType.CLIENT_RESOURCES) {
                    modConstructor.onAddResourcePackFinders(new ResourcePackSourcesContextNeoForgeImpl(event));
                }
            });
            eventBus.addListener((final RegisterRenderPipelinesEvent event) -> {
                modConstructor.onRegisterRenderPipelines(new RenderPipelinesContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterGuiLayersEvent event) -> {
                modConstructor.onRegisterGuiLayers(new GuiLayersContextNeoForgeImpl(event));
            });
            eventBus.addListener((final RegisterPictureInPictureRenderersEvent event) -> {
                modConstructor.onRegisterPictureInPictureRenderers(new PictureInPictureRenderersContextNeoForgeImpl(
                        event));
            });
            eventBus.addListener((final AddClientReloadListenersEvent event) -> {
                modConstructor.onAddResourcePackReloadListeners(new ResourcePackReloadListenersContextNeoForgeImpl(event));
            });
        });
    }
}
