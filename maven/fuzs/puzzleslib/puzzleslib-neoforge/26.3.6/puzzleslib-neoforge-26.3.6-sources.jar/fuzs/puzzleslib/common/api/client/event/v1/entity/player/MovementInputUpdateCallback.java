package fuzs.puzzleslib.common.api.client.event.v1.entity.player;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import net.minecraft.client.player.ClientInput;
import net.minecraft.client.player.LocalPlayer;

@FunctionalInterface
public interface MovementInputUpdateCallback {
    EventInvoker<MovementInputUpdateCallback> EVENT = EventInvoker.lookup(MovementInputUpdateCallback.class);

    /**
     * Called after the {@link ClientInput} has ticked for the {@link LocalPlayer}.
     *
     * @param player the local player instance
     * @param input  the input instance for that player
     */
    void onMovementInputUpdate(LocalPlayer player, ClientInput input);
}
