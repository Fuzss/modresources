package fuzs.puzzleslib.common.impl.client.core.proxy;

import fuzs.puzzleslib.common.api.client.core.v1.ClientModConstructor;
import fuzs.puzzleslib.common.api.client.key.v1.KeyMappingHelper;
import fuzs.puzzleslib.common.api.client.renderer.v2.model.MutableBakedQuad;
import fuzs.puzzleslib.common.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.common.impl.core.proxy.ProxyImpl;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipComponent;
import net.minecraft.client.gui.screens.inventory.tooltip.ClientTooltipPositioner;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.resources.model.geometry.BakedQuad;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.resources.Identifier;
import net.minecraft.server.TickTask;
import net.minecraft.util.context.ContextKey;
import net.minecraft.util.thread.BlockableEventLoop;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.tooltip.TooltipComponent;
import net.minecraft.world.level.Level;
import org.jspecify.annotations.Nullable;

import java.util.List;
import java.util.Objects;

public interface ClientProxyImpl extends ProxyImpl {

    static ClientProxyImpl get() {
        return (ClientProxyImpl) ProxyImpl.INSTANCE;
    }

    ModConstructorImpl<ClientModConstructor> getClientModConstructorImpl();

    KeyMappingHelper getKeyMappingActivationHelper();

    @Nullable <T> T getRenderStateData(Object state, ContextKey<T> key);

    <T> void setRenderStateData(Object state, ContextKey<T> key, @Nullable T value);

    boolean isKeyActiveAndMatches(KeyMapping keyMapping, KeyEvent keyEvent);

    ClientTooltipComponent createImageComponent(TooltipComponent imageComponent);

    boolean onRenderTooltip(GuiGraphicsExtractor guiGraphics, Font font, int mouseX, int mouseY, List<ClientTooltipComponent> components, ClientTooltipPositioner positioner);

    MutableBakedQuad getMutableBakedQuad(BakedQuad bakedQuad);

    boolean isEffectVisibleInInventory(MobEffectInstance mobEffect);

    boolean isEffectVisibleInGui(MobEffectInstance mobEffect);

    int getLeftStatusBarHeight(Identifier layerId);

    int getRightStatusBarHeight(Identifier layerId);

    @Override
    default BlockableEventLoop<? super TickTask> getBlockableEventLoop(Level level) {
        if (level.isClientSide()) {
            return Minecraft.getInstance();
        } else {
            return ProxyImpl.super.getBlockableEventLoop(level);
        }
    }

    @Override
    default RegistryAccess getRegistryAccess() {
        return Minecraft.getInstance().getConnection() != null ?
                Minecraft.getInstance().getConnection().registryAccess() : null;
    }

    @Override
    default Player getClientPlayer() {
        return Minecraft.getInstance().player;
    }

    @Override
    default Level getClientLevel() {
        return Minecraft.getInstance().level;
    }

    @Override
    default ClientGamePacketListener getClientPacketListener() {
        ClientPacketListener clientPacketListener = Minecraft.getInstance().getConnection();
        Objects.requireNonNull(clientPacketListener, "client packet listener is null");
        return clientPacketListener;
    }

    @Override
    default boolean hasControlDown() {
        return Minecraft.getInstance().hasControlDown();
    }

    @Override
    default boolean hasShiftDown() {
        return Minecraft.getInstance().hasShiftDown();
    }

    @Override
    default boolean hasAltDown() {
        return Minecraft.getInstance().hasAltDown();
    }
}
