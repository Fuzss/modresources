package fuzs.puzzleslib.common.impl.event.data.event;

import fuzs.puzzleslib.common.impl.event.data.DefaultedFloat;

import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class EventDefaultedFloat extends EventMutableFloat implements DefaultedFloat {
    private final Supplier<Float> defaultSupplier;
    private boolean dirty;

    public EventDefaultedFloat(Consumer<Float> consumer, Supplier<Float> supplier, Supplier<Float> defaultSupplier) {
        super(consumer, supplier);
        this.defaultSupplier = defaultSupplier;
    }

    @Override
    public void accept(float value) {
        this.dirty = true;
        super.accept(value);
    }

    @Override
    public float getAsDefaultFloat() {
        return this.defaultSupplier.get();
    }

    @Override
    public Optional<Float> getAsOptionalFloat() {
        return this.dirty ? Optional.of(this.getAsFloat()) : Optional.empty();
    }
}
