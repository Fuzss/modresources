package fuzs.puzzleslib.common.impl.event.data.value;

import fuzs.puzzleslib.common.api.event.v1.data.MutableBoolean;

public class ValueMutableBoolean implements MutableBoolean {
    private boolean value;

    public ValueMutableBoolean(boolean value) {
        this.value = value;
    }

    @Override
    public void accept(boolean value) {
        this.value = value;
    }

    @Override
    public boolean getAsBoolean() {
        return this.value;
    }

    @Override
    public String toString() {
        return "MutableBoolean[" + this.getAsBoolean() + "]";
    }
}
