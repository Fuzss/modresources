package fuzs.puzzleslib.common.api.client.event.v1.gui;

import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import java.util.Objects;

@SuppressWarnings("unchecked")
public final class ScreenEvents {

    private ScreenEvents() {
        // NO-OP
    }

    public static <T extends Screen> EventInvoker<BeforeInit<T>> beforeInit(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeInit<T>>) (Class<?>) BeforeInit.class, screen);
    }

    public static <T extends Screen> EventInvoker<AfterInit<T>> afterInit(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterInit<T>>) (Class<?>) AfterInit.class, screen);
    }

    public static <T extends Screen> EventInvoker<Remove<T>> remove(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<Remove<T>>) (Class<?>) Remove.class, screen);
    }

    public static <T extends Screen> EventInvoker<BeforeExtract<T>> beforeExtract(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<BeforeExtract<T>>) (Class<?>) BeforeExtract.class, screen);
    }

    public static <T extends Screen> EventInvoker<AfterBackground<T>> afterBackground(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterBackground<T>>) (Class<?>) AfterBackground.class, screen);
    }

    public static <T extends Screen> EventInvoker<AfterForeground<T>> afterForeground(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterForeground<T>>) (Class<?>) AfterForeground.class, screen);
    }

    public static <T extends Screen> EventInvoker<AfterExtract<T>> afterExtract(Class<T> screen) {
        Objects.requireNonNull(screen, "screen type is null");
        return EventInvoker.lookup((Class<AfterExtract<T>>) (Class<?>) AfterExtract.class, screen);
    }

    @FunctionalInterface
    public interface BeforeInit<T extends Screen> {

        /**
         * Called before widgets on a {@link Screen} are cleared and rebuilt by calling {@link Screen#init()}, usually
         * triggered by the screen opening or being resized.
         * <p>
         * As opposed to Forge, this callback cannot be cancelled, and therefore also does not allow for manipulating
         * widgets, as those will be cleared anyway.
         * <p>
         *
         * @param screen       the screen that is rebuilding widgets
         * @param screenWidth  width of the window
         * @param screenHeight height of the window
         */
        void onBeforeInit(T screen, int screenWidth, int screenHeight);
    }

    @FunctionalInterface
    public interface AfterInit<T extends Screen> {

        /**
         * Called after widgets on a {@link Screen} have been cleared and rebuilt by calling {@link Screen#init()},
         * usually triggered by the screen opening or being resized.
         * <p>
         * This callback allows for manipulating widgets on the screen, allowing for both additions and removals, as
         * well as modifications to existing widgets.
         *
         * @param screen       the screen that is rebuilding widgets
         * @param screenWidth  width of the window
         * @param screenHeight height of the window
         */
        void onAfterInit(T screen, int screenWidth, int screenHeight);
    }

    @FunctionalInterface
    public interface Remove<T extends Screen> {

        /**
         * Runs before a screen is removed in {@link Screen#removed()}.
         *
         * @param screen the currently displayed screen
         */
        void onRemove(T screen);
    }

    @FunctionalInterface
    public interface BeforeExtract<T extends Screen> {

        /**
         * Runs before a screen is extracted in
         * {@link Screen#extractRenderStateWithTooltipAndSubtitles(GuiGraphicsExtractor, int, int, float)}.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onBeforeExtract(T screen, GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick);
    }

    @FunctionalInterface
    public interface AfterBackground<T extends Screen> {

        /**
         * Runs after a screen's background is extracted in
         * {@link Screen#extractBackground(GuiGraphicsExtractor, int, int, float)}.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onAfterBackground(T screen, GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick);
    }

    @FunctionalInterface
    public interface AfterForeground<T extends Screen> {

        /**
         * Runs after a screen's foreground is extracted in
         * {@link
         * net.minecraft.client.gui.screens.inventory.AbstractContainerScreen#extractContents(GuiGraphicsExtractor, int,
         * int, float)} or via {@link GuiGraphicsExtractor#extractDeferredElements(int, int, float)} for generic
         * screens.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onAfterForeground(T screen, GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick);
    }

    @FunctionalInterface
    public interface AfterExtract<T extends Screen> {

        /**
         * Runs after a screen is extracted in
         * {@link Screen#extractRenderStateWithTooltipAndSubtitles(GuiGraphicsExtractor, int, int, float)}.
         *
         * @param screen      the currently displayed screen
         * @param guiGraphics the gui graphics component
         * @param mouseX      the x-position of the mouse
         * @param mouseY      the y-position of the mouse
         * @param partialTick the partial tick time
         */
        void onAfterExtract(T screen, GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick);
    }
}
