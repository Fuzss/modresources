package fuzs.puzzleslib.common.api.event.v1.core;

import org.jspecify.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * An extension to {@link EventResult} allowing to attach any kind of value to the result.
 * <p>
 * The implementation can be used similarly to Java's {@link Optional} class, allowing for functional patterns.
 * <p>
 * Implementation is remotely similar to <a
 * href="https://github.com/architectury/architectury-api/blob/1.19.3/common/src/main/java/dev/architectury/event/CompoundEventResult.java">CompoundEventResult.java</a>
 * from Architectury API.
 *
 * @param <T> the holder value type
 */
public final class EventResultHolder<T> {
    private static final EventResultHolder<?> PASS = new EventResultHolder<>();

    private final EventResult result;
    @Nullable
    private final T value;

    /**
     * internal constructor
     */
    private EventResultHolder() {
        this.result = EventResult.PASS;
        this.value = null;
    }

    /**
     * internal constructor
     */
    private EventResultHolder(EventResult result, @Nullable T value) {
        Objects.requireNonNull(result, "result is null");
        this.result = result;
        this.value = value;
    }

    /**
     * @param <T> the holder value type
     * @return the {@link EventResult#PASS} holder
     */
    @SuppressWarnings("unchecked")
    public static <T> EventResultHolder<T> pass() {
        return (EventResultHolder<T>) PASS;
    }

    /**
     * @param value the held value
     * @param <T>   the holder value type
     * @return the {@link EventResult#INTERRUPT} holder
     */
    public static <T> EventResultHolder<T> interrupt(@Nullable T value) {
        return new EventResultHolder<>(EventResult.INTERRUPT, value);
    }

    /**
     * @param value the held value
     * @param <T>   the holder value type
     * @return the {@link EventResult#ALLOW} holder
     */
    public static <T> EventResultHolder<T> allow(@Nullable T value) {
        return new EventResultHolder<>(EventResult.ALLOW, value);
    }

    /**
     * @param value the held value
     * @param <T>   the holder value type
     * @return the {@link EventResult#DENY} holder
     */
    public static <T> EventResultHolder<T> deny(@Nullable T value) {
        return new EventResultHolder<>(EventResult.DENY, value);
    }

    /**
     * @return does this result prevent the vanilla behavior from running
     */
    public boolean isInterrupt() {
        return this.result.isInterrupt();
    }

    /**
     * @return does this result allow for events to continue processing and for vanilla behavior to apply
     */
    public boolean isPass() {
        return this.result.isPass();
    }

    /**
     * @param action action to run if {@link #result} is {@link EventResult#INTERRUPT}
     * @return this instance
     */
    public EventResultHolder<T> ifInterrupt(final Consumer<? super T> action) {
        Objects.requireNonNull(action, "action is null");
        if (this.isInterrupt()) {
            action.accept(this.value);
        }

        return this;
    }

    /**
     * @param action action to run if {@link #result} is {@link EventResult#ALLOW}
     * @return this instance
     */
    public EventResultHolder<T> ifAllow(final Consumer<? super T> action) {
        Objects.requireNonNull(action, "action is null");
        if (this.isInterrupt() && this.result.getAsBoolean()) {
            action.accept(this.value);
        }

        return this;
    }

    /**
     * @param action action to run if {@link #result} is {@link EventResult#DENY}
     * @return this instance
     */
    public EventResultHolder<T> ifDeny(final Consumer<? super T> action) {
        Objects.requireNonNull(action, "action is null");
        if (this.isInterrupt() && !this.result.getAsBoolean()) {
            action.accept(this.value);
        }

        return this;
    }

    /**
     * @param filter tests the contained value
     * @return this instance if <code>filter</code> succeeds, otherwise {@link #pass()}
     */
    public EventResultHolder<T> filter(Predicate<? super T> filter) {
        Objects.requireNonNull(filter, "filter is null");
        if (!this.isInterrupt()) {
            return this;
        } else {
            return filter.test(this.value) ? this : pass();
        }
    }

    /**
     * @param mapper mapping transformer for {@link #value}
     * @param <U>    data type for new value
     * @return new holder containing the mapped value, {@link #result} is unchanged
     */
    public <U> EventResultHolder<U> map(final Function<? super T, ? extends U> mapper) {
        Objects.requireNonNull(mapper, "mapper is null");
        if (!this.isInterrupt()) {
            return pass();
        } else {
            return new EventResultHolder<>(this.result, mapper.apply(this.value));
        }
    }

    /**
     * @param mapper mapping transformer for {@link #value}
     * @param <U>    data type for new value
     * @return new holder containing the mapped value, {@link #result} is unchanged
     */
    @SuppressWarnings("unchecked")
    public <U> EventResultHolder<U> flatMap(final Function<? super T, ? extends EventResultHolder<? extends U>> mapper) {
        Objects.requireNonNull(mapper, "mapper is null");
        if (!this.isInterrupt()) {
            return pass();
        } else {
            EventResultHolder<U> holder = (EventResultHolder<U>) mapper.apply(this.value);
            Objects.requireNonNull(holder, "holder is null");
            return holder;
        }
    }

    /**
     * @return optional value if {@link #result} is {@link EventResult#INTERRUPT}
     */
    public Optional<T> getInterrupt() {
        if (!this.isInterrupt()) {
            return Optional.empty();
        } else {
            return Optional.ofNullable(this.value);
        }
    }

    /**
     * @return optional value if {@link #result} is {@link EventResult#ALLOW}
     */
    public Optional<T> getAllow() {
        if (!this.isInterrupt() || !this.result.getAsBoolean()) {
            return Optional.empty();
        } else {
            return Optional.ofNullable(this.value);
        }
    }

    /**
     * @return optional value if {@link #result} is {@link EventResult#DENY}
     */
    public Optional<T> getDeny() {
        if (!this.isInterrupt() || this.result.getAsBoolean()) {
            return Optional.empty();
        } else {
            return Optional.ofNullable(this.value);
        }
    }
}
