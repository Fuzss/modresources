package fuzs.puzzleslib.neoforge.impl.client.core.context;

import com.mojang.renderpearl.api.pipeline.RenderPipeline;
import fuzs.puzzleslib.common.api.client.core.v1.context.RenderPipelinesContext;
import net.neoforged.neoforge.client.event.RegisterRenderPipelinesEvent;

import java.util.Objects;

public record RenderPipelinesContextNeoForgeImpl(RegisterRenderPipelinesEvent event) implements RenderPipelinesContext {

    @Override
    public void registerRenderPipeline(RenderPipeline renderPipeline) {
        Objects.requireNonNull(renderPipeline, "render pipeline is null");
        this.event.registerPipeline(renderPipeline);
    }
}
