package fuzs.puzzleslib.neoforge.impl.client.core.context;

import com.google.common.collect.ImmutableMap;
import fuzs.puzzleslib.common.api.client.core.v1.context.GuiLayersContext;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.Hud;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RenderGuiLayerEvent;
import net.neoforged.neoforge.client.gui.GuiLayer;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.NeoForge;

import java.util.Map;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.ToIntFunction;
import java.util.function.UnaryOperator;

public record GuiLayersContextNeoForgeImpl(RegisterGuiLayersEvent event) implements GuiLayersContext {
    private static final Map<Identifier, Identifier> VANILLA_GUI_LAYERS = ImmutableMap.<Identifier, Identifier>builder()
            .put(CAMERA_OVERLAYS, VanillaGuiLayers.CAMERA_OVERLAYS)
            .put(CROSSHAIR, VanillaGuiLayers.CROSSHAIR)
            .put(HOTBAR, VanillaGuiLayers.HOTBAR)
            .put(INFO_BAR, VanillaGuiLayers.CONTEXTUAL_INFO_BAR_BACKGROUND)
            .put(PLAYER_HEALTH, VanillaGuiLayers.PLAYER_HEALTH)
            .put(ARMOR_LEVEL, VanillaGuiLayers.ARMOR_LEVEL)
            .put(FOOD_LEVEL, VanillaGuiLayers.FOOD_LEVEL)
            .put(VEHICLE_HEALTH, VanillaGuiLayers.VEHICLE_HEALTH)
            .put(AIR_LEVEL, VanillaGuiLayers.AIR_LEVEL)
            .put(HELD_ITEM_TOOLTIP, VanillaGuiLayers.SELECTED_ITEM_NAME)
            .put(EXPERIENCE_LEVEL, VanillaGuiLayers.EXPERIENCE_LEVEL)
            .put(SPECTATOR_TOOLTIP, VanillaGuiLayers.SPECTATOR_TOOLTIP)
            .put(STATUS_EFFECTS, VanillaGuiLayers.EFFECTS)
            .put(BOSS_BAR, VanillaGuiLayers.BOSS_OVERLAY)
            .put(SLEEP_OVERLAY, VanillaGuiLayers.SLEEP_OVERLAY)
            .put(DEMO_TIMER, VanillaGuiLayers.DEMO_OVERLAY)
            .put(SCOREBOARD, VanillaGuiLayers.SCOREBOARD_SIDEBAR)
            .put(OVERLAY_MESSAGE, VanillaGuiLayers.OVERLAY_MESSAGE)
            .put(TITLE, VanillaGuiLayers.TITLE)
            .put(CHAT, VanillaGuiLayers.CHAT)
            .put(PLAYER_LIST, VanillaGuiLayers.TAB_LIST)
            .put(SUBTITLES, VanillaGuiLayers.SUBTITLE_OVERLAY)
            .build();

    @Override
    public void registerGuiLayer(Identifier layerId, GuiLayersContext.Layer guiLayer) {
        Objects.requireNonNull(layerId, "layer id is null");
        Objects.requireNonNull(guiLayer, "gui layer is null");
        this.event.registerAboveAll(layerId, guiLayer::extractRenderState);
    }

    @Override
    public void registerGuiLayer(Identifier layerId, Identifier otherLayerId, GuiLayersContext.Layer guiLayer) {
        Objects.requireNonNull(layerId, "layer id is null");
        Objects.requireNonNull(otherLayerId, "other layer id is null");
        Objects.requireNonNull(guiLayer, "gui layer is null");
        // only check for vanilla layers, it simplifies the implementation and is all we need
        if (VANILLA_GUI_LAYERS.containsKey(layerId)) {
            this.event.registerAbove(VANILLA_GUI_LAYERS.get(layerId), otherLayerId, guiLayer::extractRenderState);
        } else if (VANILLA_GUI_LAYERS.containsKey(otherLayerId)) {
            this.event.registerBelow(VANILLA_GUI_LAYERS.get(otherLayerId), layerId, guiLayer::extractRenderState);
        } else {
            throw new RuntimeException("Unknown gui layers: " + layerId + ", " + otherLayerId);
        }
    }

    @Override
    public void replaceGuiLayer(Identifier layerId, UnaryOperator<GuiLayersContext.Layer> guiLayerFactory) {
        Objects.requireNonNull(layerId, "layer id is null");
        Objects.requireNonNull(guiLayerFactory, "gui layer factory is null");
        // only check for vanilla layers, it simplifies the implementation and is all we need
        if (VANILLA_GUI_LAYERS.containsKey(layerId)) {
            layerId = VANILLA_GUI_LAYERS.get(layerId);
            boolean isSleepOverlay = layerId.equals(VanillaGuiLayers.SLEEP_OVERLAY);
            this.event.wrapLayer(layerId, (GuiLayer guiLayer) -> {
                return (GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker) -> {
                    // render condition is not inherited from the parent, add it back manually,
                    // since all are known for vanilla layers
                    if (isSleepOverlay || !Minecraft.getInstance().gui.hud.isHidden()) {
                        guiLayerFactory.apply(guiLayer::render).extractRenderState(guiGraphics, deltaTracker);
                    }
                };
            });
        } else {
            throw new RuntimeException("Unknown gui layer: " + layerId);
        }
    }

    @Override
    public void addLeftStatusBarHeightProvider(Identifier layerId, ToIntFunction<Player> heightProvider) {
        this.addStatusBarHeight(layerId, heightProvider, (Hud hud, Integer height) -> {
            hud.leftHeight += height;
        });
    }

    @Override
    public void addRightStatusBarHeightProvider(Identifier layerId, ToIntFunction<Player> heightProvider) {
        this.addStatusBarHeight(layerId, heightProvider, (Hud hud, Integer height) -> {
            hud.rightHeight += height;
        });
    }

    private void addStatusBarHeight(Identifier identifier, ToIntFunction<Player> heightProvider, BiConsumer<Hud, Integer> heightConsumer) {
        Objects.requireNonNull(identifier, "layer id is null");
        Objects.requireNonNull(heightProvider, "height provider is null");
        NeoForge.EVENT_BUS.addListener((final RenderGuiLayerEvent.Post event) -> {
            if (event.getName().equals(identifier)) {
                Hud hud = Minecraft.getInstance().gui.hud;
                if (hud.getCameraPlayer() != null) {
                    heightConsumer.accept(hud, heightProvider.applyAsInt(hud.getCameraPlayer()));
                }
            }
        });
    }
}
