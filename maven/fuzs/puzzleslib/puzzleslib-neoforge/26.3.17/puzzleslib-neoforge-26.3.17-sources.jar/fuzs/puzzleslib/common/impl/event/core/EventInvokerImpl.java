package fuzs.puzzleslib.common.impl.event.core;

import com.google.common.base.Suppliers;
import com.google.common.collect.Maps;
import com.google.common.collect.Queues;
import fuzs.puzzleslib.common.api.event.v1.core.EventInvoker;
import fuzs.puzzleslib.common.api.event.v1.core.EventPhase;
import fuzs.puzzleslib.common.impl.PuzzlesLib;
import fuzs.puzzleslib.common.impl.core.proxy.ProxyImpl;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Supplier;

public final class EventInvokerImpl {
    private static final Map<Class<?>, EventInvokerLike<?>> EVENT_INVOKER_LOOKUP = Collections.synchronizedMap(Maps.newIdentityHashMap());
    private static final Queue<Runnable> DEFERRED_INVOKER_REGISTRATIONS = Queues.newConcurrentLinkedQueue();
    private static final AtomicBoolean INITIALIZED_EVENT_INVOKERS = new AtomicBoolean();

    static {
        // initialize events required during start-up early, all other events are initialized when loading has completed
        ProxyImpl.get().registerAllLoadingHandlers();
    }

    private EventInvokerImpl() {
        // NO-OP
    }

    public static void initialize() {
        if (!INITIALIZED_EVENT_INVOKERS.get()) {
            // initialize most of the events as late as possible to avoid loading many classes very early,
            // and being blamed for possible class loading errors that follow
            ProxyImpl.get().registerAllEventHandlers();
            INITIALIZED_EVENT_INVOKERS.set(true);
            while (!DEFERRED_INVOKER_REGISTRATIONS.isEmpty()) {
                DEFERRED_INVOKER_REGISTRATIONS.poll().run();
            }
        }
    }

    public static <T> EventInvoker<T> softLookup(Class<T> clazz, @Nullable Object context) {
        Objects.requireNonNull(clazz, "type is null");
        Supplier<EventInvoker<T>> invoker = Suppliers.memoize(() -> EventInvokerImpl.lookup(clazz, context));
        return (EventPhase phase, T callback) -> {
            if (!INITIALIZED_EVENT_INVOKERS.get() && !EVENT_INVOKER_LOOKUP.containsKey(clazz)) {
                DEFERRED_INVOKER_REGISTRATIONS.offer(() -> {
                    invoker.get().register(phase, callback);
                });
            } else {
                // due to static initializers the invoker might not be present in the lookup just yet
                invoker.get().register(phase, callback);
            }
        };
    }

    @SuppressWarnings("unchecked")
    private static <T> EventInvoker<T> lookup(Class<T> clazz, @Nullable Object context) {
        Objects.requireNonNull(clazz, "type is null");
        EventInvokerLike<T> invokerLike = (EventInvokerLike<T>) EVENT_INVOKER_LOOKUP.get(clazz);
        Objects.requireNonNull(invokerLike, "invoker is null for type " + clazz);
        EventInvoker<T> invoker = invokerLike.asEventInvoker(context);
        Objects.requireNonNull(invoker, "invoker is null for type " + clazz);
        return invoker;
    }

    @SuppressWarnings("unchecked")
    public static <T> void register(Class<T> clazz, EventInvokerLike<T> invoker, boolean joinInvokers) {
        if (joinInvokers) {
            EventInvokerLike<T> other = (EventInvokerLike<T>) EVENT_INVOKER_LOOKUP.get(clazz);
            if (other != null) {
                invoker = join(invoker, other);
            }
        }

        if (EVENT_INVOKER_LOOKUP.put(clazz, invoker) != null && !joinInvokers) {
            PuzzlesLib.LOGGER.warn("Overriding existing event invoker for type {}", clazz);
        }
    }

    private static <T> EventInvokerLike<T> join(EventInvokerLike<T> invoker, EventInvokerLike<T> other) {
        return (@Nullable Object context) -> (EventPhase phase, T callback) -> {
            invoker.asEventInvoker(context).register(phase, callback);
            other.asEventInvoker(context).register(phase, callback);
        };
    }

    @FunctionalInterface
    public interface EventInvokerLike<T> {

        EventInvoker<T> asEventInvoker(@Nullable Object context);
    }
}
