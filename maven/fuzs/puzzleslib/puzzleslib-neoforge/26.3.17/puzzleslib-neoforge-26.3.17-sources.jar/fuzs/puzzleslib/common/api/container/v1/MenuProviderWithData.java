package fuzs.puzzleslib.common.api.container.v1;

import fuzs.puzzleslib.common.api.init.v3.registry.MenuSupplierWithData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;

/**
 * A custom {@link MenuProvider} for menu types registered via {@link MenuSupplierWithData}.
 *
 * @param <T> the menu data type
 */
public interface MenuProviderWithData<T> extends MenuProvider {
    /**
     * @param player the player opening the menu, potentially {@code null} when unable to retrieve from inventory slots
     * @return the menu data
     */
    T getMenuData(ServerPlayer player);
}
