package fuzs.puzzleslib.neoforge.impl.core;

import fuzs.puzzleslib.common.api.core.v1.ModConstructor;
import fuzs.puzzleslib.common.api.core.v1.context.PayloadTypesContext;
import fuzs.puzzleslib.common.api.data.v2.AbstractRecipeProvider;
import fuzs.puzzleslib.common.api.data.v2.recipes.TransformingRecipeOutput;
import fuzs.puzzleslib.common.api.data.v2.tags.AbstractTagAppender;
import fuzs.puzzleslib.common.api.init.v3.registry.RegistryFactory;
import fuzs.puzzleslib.common.api.item.v2.ToolTypeHelper;
import fuzs.puzzleslib.common.api.item.v2.crafting.CombinedIngredients;
import fuzs.puzzleslib.common.impl.attachment.DataAttachmentRegistryImpl;
import fuzs.puzzleslib.common.impl.core.ModContext;
import fuzs.puzzleslib.common.impl.core.context.ModConstructorImpl;
import fuzs.puzzleslib.neoforge.api.event.v1.core.NeoForgeEventInvokerRegistry;
import fuzs.puzzleslib.neoforge.impl.attachment.NeoForgeDataAttachmentRegistryImpl;
import fuzs.puzzleslib.neoforge.impl.core.context.PayloadTypesContextNeoForgeImpl;
import fuzs.puzzleslib.neoforge.impl.data.NeoForgeTagAppender;
import fuzs.puzzleslib.neoforge.impl.event.ForwardingLootPoolBuilder;
import fuzs.puzzleslib.neoforge.impl.event.ForwardingLootTableBuilder;
import fuzs.puzzleslib.neoforge.impl.event.NeoForgeEventInvokerRegistryImpl;
import fuzs.puzzleslib.neoforge.impl.event.NeoForgeEventInvokers;
import fuzs.puzzleslib.neoforge.impl.init.MenuTypeWithData;
import fuzs.puzzleslib.neoforge.impl.init.NeoForgeRegistryFactory;
import fuzs.puzzleslib.neoforge.impl.item.NeoForgeToolTypeHelper;
import fuzs.puzzleslib.neoforge.impl.item.crafting.NeoForgeCombinedIngredients;
import fuzs.puzzleslib.neoforge.mixin.accessor.PackNeoForgeAccessor;
import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementHolder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.RecipeOutput;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientCommonPacketListener;
import net.minecraft.network.protocol.common.ServerCommonPacketListener;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.network.protocol.configuration.ServerConfigurationPacketListener;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ConfigurationTask;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackCompatibility;
import net.minecraft.tags.TagBuilder;
import net.minecraft.tags.TagEntry;
import net.minecraft.tags.TagFile;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.flag.FeatureFlagSet;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.neoforged.neoforge.common.conditions.ICondition;
import net.neoforged.neoforge.common.extensions.ICommonPacketListener;
import net.neoforged.neoforge.entity.PartEntity;
import net.neoforged.neoforge.event.EventHooks;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.server.ServerLifecycleHooks;
import org.jetbrains.annotations.MustBeInvokedByOverriders;
import org.jspecify.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;

public class NeoForgeCommonProxy implements NeoForgeProxy {

    @Override
    public MinecraftServer getMinecraftServer() {
        return ServerLifecycleHooks.getCurrentServer();
    }

    @Override
    public <T> void openMenu(Player player, MenuProvider menuProvider, T data) {
        player.openMenu(new MenuProvider() {
            @Override
            public void writeClientSideData(AbstractContainerMenu containerMenu, RegistryFriendlyByteBuf buf) {
                MenuTypeWithData.encodeMenuData(containerMenu, buf, data);
            }

            @Override
            public Component getDisplayName() {
                return menuProvider.getDisplayName();
            }

            @Nullable
            @Override
            public AbstractContainerMenu createMenu(int containerId, Inventory inventory, Player player) {
                return menuProvider.createMenu(containerId, inventory, player);
            }
        });
    }

    @Override
    public Pack.Metadata createPackInfo(Identifier identifier, Component descriptionComponent, PackCompatibility packCompatibility, FeatureFlagSet featureFlagSet, boolean isHidden) {
        return new Pack.Metadata(descriptionComponent,
                packCompatibility,
                featureFlagSet,
                Collections.emptyList(),
                isHidden);
    }

    @Override
    public boolean isPackHidden(Pack pack) {
        return pack.isHidden();
    }

    @Override
    public void setPackHidden(Pack pack, boolean isHidden) {
        // NeoForge copies the hidden property from the metadata section, so only changing the metadata is not enough.
        ((PackNeoForgeAccessor) pack).puzzleslib$setHidden(isHidden);
    }

    @Override
    public Style getRarityStyle(Rarity rarity) {
        return rarity.getStyleModifier().apply(Style.EMPTY);
    }

    @Override
    public void onPlayerDestroyItem(Player player, ItemStack originalItemStack, @Nullable InteractionHand interactionHand) {
        EventHooks.onPlayerDestroyItem(player, originalItemStack, interactionHand);
    }

    @Override
    public void forEachPool(LootTable.Builder lootTable, Consumer<? super LootPool.Builder> lootPoolConsumer) {
        if (lootTable instanceof ForwardingLootTableBuilder) {
            for (LootPool lootPool : lootTable.build().pools) {
                lootPoolConsumer.accept(new ForwardingLootPoolBuilder(lootPool));
            }
        } else {
            throw new UnsupportedOperationException("Must be ForwardingLootTableBuilder");
        }
    }

    @Override
    public float getEnchantPowerBonus(BlockState blockState, Level level, BlockPos blockPos) {
        return blockState.getEnchantPowerBonus(level, blockPos);
    }

    @Override
    public boolean canApplyAtEnchantingTable(Holder<Enchantment> enchantment, ItemStack itemStack) {
        return itemStack.isPrimaryItemFor(enchantment);
    }

    @MustBeInvokedByOverriders
    @Override
    public void registerAllLoadingHandlers() {
        NeoForgeEventInvokers.registerLoadingHandlers();
    }

    @MustBeInvokedByOverriders
    @Override
    public void registerAllEventHandlers() {
        ((NeoForgeEventInvokerRegistryImpl) NeoForgeEventInvokerRegistry.INSTANCE).freezeModBusEvents();
        NeoForgeEventInvokers.registerEventHandlers();
    }

    @Override
    public boolean hasChannel(PacketListener packetListener, CustomPacketPayload.Type<?> type) {
        return packetListener instanceof ICommonPacketListener commonPacketListener
                && commonPacketListener.getConnection().isConnected() && commonPacketListener.hasChannel(type);
    }

    @Override
    public Connection getConnection(PacketListener packetListener) {
        return ((ICommonPacketListener) packetListener).getConnection();
    }

    @Override
    public Packet<ClientCommonPacketListener> toClientboundPacket(CustomPacketPayload payload) {
        return payload.toVanillaClientbound();
    }

    @Override
    public Packet<ServerCommonPacketListener> toServerboundPacket(CustomPacketPayload payload) {
        return payload.toVanillaServerbound();
    }

    @Override
    public void finishConfigurationTask(ServerConfigurationPacketListener packetListener, ConfigurationTask.Type type) {
        packetListener.finishCurrentTask(type);
    }

    @Override
    public PayloadTypesContext createPayloadTypesContext(String modId, RegisterPayloadHandlersEvent event) {
        return new PayloadTypesContextNeoForgeImpl.ServerImpl(modId, event);
    }

    @Override
    public ModConstructorImpl<ModConstructor> getModConstructorImpl() {
        return new NeoForgeModConstructor();
    }

    @Override
    public ModContext getModContext(String modId) {
        return new NeoForgeModContext(modId);
    }

    @Override
    public RegistryFactory getRegistryFactory() {
        return new NeoForgeRegistryFactory();
    }

    @Override
    public ToolTypeHelper getToolTypeHelper() {
        return new NeoForgeToolTypeHelper();
    }

    @Override
    public CombinedIngredients getCombinedIngredients() {
        return new NeoForgeCombinedIngredients();
    }

    @Override
    public List<TagEntry> getTagFileRemovals(TagFile tagFile) {
        return tagFile.remove();
    }

    @Override
    public <T> AbstractTagAppender<T> getTagAppender(TagBuilder tagBuilder, @Nullable Function<T, ResourceKey<T>> keyExtractor) {
        return new NeoForgeTagAppender<>(tagBuilder, keyExtractor);
    }

    @Override
    public DataAttachmentRegistryImpl getDataAttachmentRegistry() {
        return new NeoForgeDataAttachmentRegistryImpl();
    }

    @Override
    public RecipeOutput getTransformingRecipeOutput(RecipeOutput recipeOutput, UnaryOperator<Recipe<?>> operator) {
        return new TransformingRecipeOutput() {
            @Override
            public RecipeOutput recipeOutput() {
                return recipeOutput;
            }

            @Override
            public UnaryOperator<Recipe<?>> operator() {
                return operator;
            }

            @Override
            public void accept(ResourceKey<Recipe<?>> key, Recipe<?> recipe, @Nullable AdvancementHolder advancement, ICondition... conditions) {
                this.accept(key, recipe, advancement);
            }
        };
    }

    @Override
    public RecipeOutput getRecipeProviderOutput(CachedOutput output, String modId, PackOutput packOutput, HolderLookup.Provider registries, Consumer<CompletableFuture<?>> consumer) {
        return new AbstractRecipeProvider.RecipeOutputImpl(output, modId, packOutput, registries, consumer) {
            @Override
            public void accept(ResourceKey<Recipe<?>> key, Recipe<?> recipe, @Nullable AdvancementHolder advancement, ICondition... conditions) {
                this.accept(key, recipe, advancement);
            }
        };
    }

    @Override
    public RecipeOutput getThrowingRecipeOutput() {
        return new RecipeOutput() {
            @Override
            public void accept(ResourceKey<Recipe<?>> resourceKey, Recipe<?> recipe, @Nullable AdvancementHolder advancementHolder, ICondition... conditions) {
                throw new UnsupportedOperationException();
            }

            @Override
            public Advancement.Builder advancement() {
                throw new UnsupportedOperationException();
            }

            @Override
            public void includeRootAdvancement() {
                throw new UnsupportedOperationException();
            }
        };
    }

    @Override
    public void synchronizeRecipeSerializer(Holder<? extends RecipeSerializer<?>> serializer) {
        // NO-OP
    }

    @Override
    public boolean canEquip(ItemStack itemStack, EquipmentSlot equipmentSlot, LivingEntity livingEntity) {
        return itemStack.canEquip(equipmentSlot, livingEntity);
    }

    @Override
    public @Nullable EntitySpawnReason getMobSpawnReason(Mob mob) {
        return mob.getSpawnType();
    }

    @Override
    public boolean isMobGriefingAllowed(ServerLevel serverLevel, @Nullable Entity entity) {
        return EventHooks.canEntityGrief(serverLevel, entity);
    }

    @Override
    public Entity getPartEntityParent(Entity entity) {
        return entity instanceof PartEntity<?> partEntity ? partEntity.getParent() : entity;
    }

    @Override
    public boolean isFakePlayer(ServerPlayer serverPlayer) {
        return serverPlayer.isFakePlayer();
    }

    @Override
    public boolean isPiglinCurrency(ItemStack itemStack) {
        return itemStack.isPiglinCurrency();
    }
}
