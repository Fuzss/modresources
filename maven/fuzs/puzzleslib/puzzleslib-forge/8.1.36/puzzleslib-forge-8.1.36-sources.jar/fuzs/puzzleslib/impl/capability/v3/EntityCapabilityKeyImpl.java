package fuzs.puzzleslib.impl.capability.v3;

import fuzs.puzzleslib.api.capability.v3.data.CapabilityComponent;
import fuzs.puzzleslib.api.capability.v3.data.CopyStrategy;
import fuzs.puzzleslib.api.capability.v3.data.EntityCapabilityKey;
import fuzs.puzzleslib.api.capability.v3.data.SyncStrategy;
import fuzs.puzzleslib.api.event.v1.entity.living.LivingConversionCallback;
import fuzs.puzzleslib.api.event.v1.entity.player.PlayerEvents;
import fuzs.puzzleslib.api.network.v3.PlayerSet;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;

import java.util.Optional;

public interface EntityCapabilityKeyImpl<T extends Entity, C extends CapabilityComponent<T>> extends EntityCapabilityKey.Mutable<T, C> {

    @Override
    default Mutable<T, C> setSyncStrategy(SyncStrategy syncStrategy) {
        if (this.getSyncStrategy() != SyncStrategy.MANUAL) {
            throw new IllegalStateException("Sync strategy has already been set!");
        } else {
            if (syncStrategy != SyncStrategy.MANUAL) {
                PlayerEvents.LOGGED_IN.register((ServerPlayer serverPlayer) -> {
                    this.getIfProvided(serverPlayer).ifPresent(capabilityComponent -> {
                        capabilityComponent.setChanged(PlayerSet.ofPlayer(serverPlayer));
                    });
                });
                PlayerEvents.AFTER_CHANGE_DIMENSION.register((ServerPlayer serverPlayer, ServerLevel from, ServerLevel to) -> {
                    this.getIfProvided(serverPlayer).ifPresent(capabilityComponent -> {
                        capabilityComponent.setChanged(PlayerSet.ofPlayer(serverPlayer));
                    });
                });
                PlayerEvents.RESPAWN.register((ServerPlayer serverPlayer, boolean originalStillAlive) -> {
                    this.getIfProvided(serverPlayer).ifPresent(capabilityComponent -> {
                        capabilityComponent.setChanged(PlayerSet.ofPlayer(serverPlayer));
                    });
                });
                if (syncStrategy == SyncStrategy.TRACKING) {
                    PlayerEvents.START_TRACKING.register((Entity trackedEntity, ServerPlayer serverPlayer) -> {
                        this.getIfProvided(trackedEntity).ifPresent(capabilityComponent -> {
                            capabilityComponent.setChanged(PlayerSet.ofPlayer(serverPlayer));
                        });
                    });
                }
            }
            return this;
        }
    }

    @Override
    default Mutable<T, C> setCopyStrategy(CopyStrategy copyStrategy) {
        if (this.getCopyStrategy() != CopyStrategy.NEVER) {
            throw new IllegalStateException("Copy strategy has already been set!");
        } else if (copyStrategy == CopyStrategy.ALWAYS) {
            LivingConversionCallback.EVENT.register((LivingEntity originalEntity, LivingEntity newEntity) -> {
                Optional<C> originalCapability = this.getIfProvided(originalEntity);
                Optional<C> newCapability = this.getIfProvided(newEntity);
                if (originalCapability.isPresent() && newCapability.isPresent()) {
                    this.getCopyStrategy()
                            .copy(originalEntity, originalCapability.get(), newEntity, newCapability.get(), false);
                }
            });
        }
        return this;
    }

    default void initialize() {
        PlayerEvents.COPY.register((ServerPlayer originalPlayer, ServerPlayer newPlayer, boolean originalStillAlive) -> {
            Optional<C> originalCapability = this.getIfProvided(originalPlayer);
            Optional<C> newCapability = this.getIfProvided(newPlayer);
            if (originalCapability.isPresent() && newCapability.isPresent()) {
                this.getCopyStrategy()
                        .copy(originalPlayer,
                                originalCapability.get(),
                                newPlayer,
                                newCapability.get(),
                                originalStillAlive);
            }
        });
    }
}
