# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v1.1.2] - 2026-04-02

### Changed

- Relax Minecraft version constraints for published artifacts and when uploading
- Set additional CurseForge metadata when uploading

## [v1.1.1] - 2026-03-31

### Fixed

- Fix NeoForge runs

## [v1.1.0] - 2026-03-24

### Changed

- Replace Architectury Loom with Loom and Mod Dev Gradle
