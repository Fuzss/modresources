package fuzs.multiloader.neoforge

import fuzs.multiloader.extension.*
import fuzs.multiloader.metadata.LinkProvider
import fuzs.multiloader.metadata.ModLoaderProvider
import fuzs.multiloader.neoforge.toml.NeoForgeModsTomlSpec
import fuzs.multiloader.neoforge.toml.NeoForgeModsTomlTask
import kotlin.jvm.optionals.getOrNull

fun NeoForgeModsTomlTask.setupModsTomlTask() {
    val multiLoaderExtension = project.extensions.getByType(MultiLoaderExtension::class.java)
    outputFile.set(project.layout.buildDirectory.file("generated/resources/META-INF/neoforge.mods.toml"))

    toml {
        license.set(project.mod.license)
        project.metadata.links
            .firstOrNull { it.name == LinkProvider.GITHUB }
            ?.url()
            ?.let {
                // This checks for the license on the current version branch
                // but links to main as we do not know the name of the version branch.
                if (project.rootProject.file("LICENSE.md").exists()) {
                    licenseURL.set("$it/blob/main/LICENSE.md")
                }

                issueTrackerURL.set("$it/issues")
            }

        mod {
            modId.set(project.mod.id)
            displayName.set(project.mod.name)
            description.set(project.mod.description)
            version.set(project.mod.version)
            authors.set(project.mod.authors.joinToString(", "))

            if (project.commonProject.file("src/main/resources/pack.png").exists()) {
                iconFile.set("pack.png")
                logoFile.set("pack.png")
            } else if (project.commonProject.file("src/main/resources/mod_logo.png").exists()) {
                iconFile.set("mod_logo.png")
                logoFile.set("mod_logo.png")
            }

            project.metadata.links
                .minByOrNull { it.name.index }
                ?.url()
                ?.let { displayURL.set(it) }

            project.metadata.links
                .sortedBy { it.name.index }
                .map { it.updateUrl(project.mod.id) }
                .firstOrNull()
                ?.let { updateJSONURL.set(it) }

            multiLoaderExtension.modFile.orNull?.enumExtensions?.orNull?.let { enumExtensions.set(it) }
        }

        listOf(project.commonProject, project).forEach {
            mixin("${it.mod.id}.${it.name.lowercase()}.mixins.json")
        }

        addDependencies()

        multiLoaderExtension.modFile.orNull?.toml?.orNull?.execute(this)
    }
}

private fun NeoForgeModsTomlTask.addDependencies() {
    fun version(alias: String): String? =
        project.versionCatalog.findVersion(alias).getOrNull()?.requiredVersion?.let { "[${it},)" }

    toml {
        dependency(project.mod.id) {
            this.modId.set("minecraft")
            this.type.set(NeoForgeModsTomlSpec.DependencySpec.Type.REQUIRED)
            project.gameVersion.takeIf(::releaseVersion)
                ?.let { version -> "[${project.lowerBoundVersion(version)},${project.upperBoundVersion(version)})" }
                ?.let(this.versionRange::set)
            this.referralUrl.set("https://www.minecraft.net/")
        }

        dependency(project.mod.id) {
            this.modId.set("neoforge")
            this.type.set(NeoForgeModsTomlSpec.DependencySpec.Type.REQUIRED)
            version("neoforge.min")?.let { this.versionRange.set(it) }
            this.referralUrl.set("https://neoforged.net/")
        }

        for ((name, type, platforms) in project.metadata.dependencies) {
            if (platforms.any { it.matches(ModLoaderProvider.NEOFORGE) }) {
                val metadata = project.rootProject.externalMods.mods[name]
                val id = metadata?.mod?.id ?: name
                val url = metadata?.links
                    ?.minByOrNull { it.name.index }
                    ?.url()
                when (name) {
                    "puzzleslib" -> dependency(project.mod.id) {
                        this.modId.set(id)
                        this.type.set(NeoForgeModsTomlSpec.DependencySpec.Type.REQUIRED)
                        version("puzzleslib.min")?.let { this.versionRange.set(it) }
                        url?.let { this.referralUrl.set(it) }
                    }

                    else -> dependency(project.mod.id) {
                        this.modId.set(id)
                        when {
                            type.required -> this.type.set(NeoForgeModsTomlSpec.DependencySpec.Type.REQUIRED)
                            type.optional -> this.type.set(NeoForgeModsTomlSpec.DependencySpec.Type.OPTIONAL)
                            type.unsupported -> this.type.set(NeoForgeModsTomlSpec.DependencySpec.Type.INCOMPATIBLE)
                        }

                        url?.let { this.referralUrl.set(it) }
                    }
                }
            }
        }
    }
}
