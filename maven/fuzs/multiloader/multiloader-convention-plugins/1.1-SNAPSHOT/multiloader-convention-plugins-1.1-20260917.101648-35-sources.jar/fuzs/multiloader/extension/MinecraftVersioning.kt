package fuzs.multiloader.extension

import org.gradle.api.Project
import java.lang.module.ModuleDescriptor

// In Minecraft 1.21.5 data generation was split into client & server components, older versions still use the unified configuration.
val SPLIT_DATA_GENERATION_VERSION: ModuleDescriptor.Version = ModuleDescriptor.Version.parse("1.21.5")

// Release versions contain only digits and dots, e.g. 1.21.1, 26.1, 26.1.2.
private val RELEASE_VERSION_REGEX = Regex("^\\d+(\\.\\d+){1,2}$")

fun releaseVersion(version: String): Boolean {
    return RELEASE_VERSION_REGEX.matches(version)
}

// This Minecraft version uses the 1.x.x-based versioning scheme.
fun legacyVersioning(version: String): Boolean {
    return version.startsWith("1.")
}

fun baseVersion(version: String, skipPatchComponent: Boolean = false): MutableList<String> {
    require(releaseVersion(version)) { "Version must be a release version: $version" }

    val parts = version.split(".").toMutableList()
    require(parts.size >= 2) { "Version must have at least MAJOR.MINOR" }

    parts.add("0")
    parts.subList(if (skipPatchComponent) 2 else 3, parts.size).clear()
    return parts
}

fun Project.artifactVersion(version: String): String {
    require(releaseVersion(version)) { "Version must be a release version: $version" }

    if (strictVersioning(version)) {
        return version
    } else {
        val parts = baseVersion(version, true)
        parts.add("x")
        return parts.joinToString(".")
    }
}

fun supportedVersions(version: String): List<String> {
    require(releaseVersion(version)) { "Version must be a release version: $version" }

    val parts: List<String> = baseVersion(version)
    val versions = mutableListOf<MutableList<String>>()
    for (patch in 0..parts.last().toInt()) {
        versions.add(parts.toMutableList().also { parts -> parts[parts.lastIndex] = patch.toString() })
    }

    return versions.map { parts ->
        if (parts.last() == "0") parts.removeLast()
        parts.joinToString(".")
    }
}

fun Project.lowerBoundVersion(version: String): String {
    require(releaseVersion(version)) { "Version must be a release version: $version" }

    if (strictVersioning(version)) {
        return version
    } else {
        val parts = baseVersion(version, true)
        return parts.joinToString(".")
    }
}

fun Project.upperBoundVersion(version: String): String {
    require(releaseVersion(version)) { "Version must be a release version: $version" }

    val parts = baseVersion(version, !strictVersioning(version))
    parts[parts.lastIndex] = (parts.last().toInt() + 1).toString()
    return parts.joinToString(".")
}
