package fuzs.multiloader.classtweaker

import org.gradle.api.DefaultTask
import org.gradle.api.file.RegularFileProperty
import org.gradle.api.provider.Property
import org.gradle.api.provider.SetProperty
import org.gradle.api.tasks.*

@CacheableTask
abstract class GenerateClassTweakerTask : DefaultTask() {
    @get:InputFile
    @get:PathSensitive(PathSensitivity.RELATIVE)
    abstract val inputFile: RegularFileProperty

    @get:OutputFile
    abstract val outputFile: RegularFileProperty

    @get:Input
    abstract val accessLevels: SetProperty<String>

    @get:Input
    abstract val header: Property<String>

    init {
        accessLevels.convention(CLASS_TWEAKER_ACCESS_LEVELS.keys)
        header.convention(CLASS_TWEAKER_NAMED_HEADER)
    }

    @TaskAction
    fun generateClassTweaker() {
        generateClassTweakerFile(
            inputFile.get().asFile,
            outputFile.get().asFile,
            accessLevels.get(), header.get()
        )
    }
}
