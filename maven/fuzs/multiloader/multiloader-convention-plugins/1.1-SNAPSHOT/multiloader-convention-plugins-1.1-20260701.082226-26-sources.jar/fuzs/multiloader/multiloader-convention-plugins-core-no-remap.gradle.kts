package fuzs.multiloader

configurations {
    create("modApi") {
        this@configurations.named("api") {
            extendsFrom(this@create)
        }
    }

    create("modImplementation") {
        this@configurations.named("implementation") {
            extendsFrom(this@create)
        }
    }

    create("modCompileOnly") {
        this@configurations.named("compileOnly") {
            extendsFrom(this@create)
        }
    }

    create("modCompileOnlyApi") {
        this@configurations.named("compileOnlyApi") {
            extendsFrom(this@create)
        }
    }

    create("modRuntimeOnly") {
        this@configurations.named("runtimeOnly") {
            extendsFrom(this@create)
        }
    }
}
