package fuzs.multiloader.classtweaker

import fuzs.multiloader.extension.commonProject
import fuzs.multiloader.extension.mod
import org.gradle.api.GradleException
import org.gradle.api.Project
import org.gradle.api.file.RegularFile
import org.gradle.api.provider.Provider
import org.gradle.api.tasks.SourceSet
import java.io.File

val TRANSITIVE_ACCESS_WIDENER_ACCESS_LEVELS: Map<String, String> = mapOf(
    "transitive-accessible" to "public",
    "transitive-extendable" to "public-f",
    "transitive-mutable" to "public-f"
)
val TRANSITIVE_CLASS_TWEAKER_ACCESS_LEVELS: Map<String, String> = TRANSITIVE_ACCESS_WIDENER_ACCESS_LEVELS + mapOf(
    "transitive-inject-interface" to "",
    "transitive-extend-enum" to ""
)
val CLASS_TWEAKER_ACCESS_LEVELS: Map<String, String> = mapOf(
    "accessible" to "public",
    "extendable" to "public-f",
    "mutable" to "public-f",
    "inject-interface" to "",
    "extend-enum" to ""
) + TRANSITIVE_CLASS_TWEAKER_ACCESS_LEVELS
private const val COLUMN_SEPARATOR: String = " "
val CLASS_TWEAKER_OFFICIAL_HEADER: String = listOf("classTweaker", "v2", "official").joinToString(COLUMN_SEPARATOR)
val CLASS_TWEAKER_NAMED_HEADER: String = listOf("classTweaker", "v2", "named").joinToString(COLUMN_SEPARATOR)
val ACCESS_WIDENER_NAMED_HEADER: String = listOf("accessWidener", "v2", "named").joinToString(COLUMN_SEPARATOR)

val Project.classTweakerFile: File
    get() = project.commonProject.file("src/main/resources/${mod.id}.classtweaker")

val Project.accessWidenerFile: File
    get() = project.commonProject.file("src/main/resources/${mod.id}.accesswidener")

val Project.templateClassTweakerFile: File
    get() = if (accessWidenerFile.exists()) accessWidenerFile else classTweakerFile

val Project.generatedClassTweakerFile: Provider<RegularFile>
    get() = project.layout.buildDirectory.file("generated/resources/${mod.id}.classtweaker")

val Project.generatedTransitiveAccessWidenerFile: Provider<RegularFile>
    get() = project.layout.buildDirectory.file("generated/resources/META-INF/${mod.id}.accesswidener")

val Project.generatedAccessTransformerFile: Provider<RegularFile>
    get() = project.layout.buildDirectory.file("generated/resources/META-INF/accesstransformer.cfg")

val Project.generatedTransitiveAccessTransformerFile: Provider<RegularFile>
    get() = project.layout.buildDirectory.file("generated/accesstransformers/${SourceSet.MAIN_SOURCE_SET_NAME}/accesstransformer.cfg")

fun generateClassTweakerFile(
    inputFile: File,
    outputFile: File,
    accessLevels: Set<String> = CLASS_TWEAKER_ACCESS_LEVELS.keys,
    header: String = CLASS_TWEAKER_OFFICIAL_HEADER
) {
    generateClassTweakerFile(inputFile, outputFile, accessLevels) { lines ->
        lines.map { line ->
            line.replace(Regex("\\s+"), COLUMN_SEPARATOR)
        }
            .toMutableList().also { lines ->
                lines.addFirst(header)
            }
    }
}

fun generateAccessTransformerFile(
    inputFile: File,
    outputFile: File,
    accessLevels: Map<String, String> = CLASS_TWEAKER_ACCESS_LEVELS
) {
    generateClassTweakerFile(inputFile, outputFile, accessLevels.keys) { lines ->
        lines.mapNotNull { line ->
            val entry = line.split(Regex("\\s+"))

            if (entry.size < 3) {
                throw GradleException("Invalid entry: $line")
            }

            val modifier = accessLevels[entry[0]] ?: throw GradleException("Invalid entry: $line")

            if (modifier.isBlank()) {
                return@mapNotNull null
            }

            val type = entry[1]
            val owner = entry[2].replace('/', '.')

            when (type) {
                "class" -> {
                    check(entry.size == 3) { "Invalid entry: $line" }
                    listOf(modifier, owner)
                }

                "field" -> {
                    check(entry.size == 5) { "Invalid entry: $line" }
                    val name = entry[3]
                    listOf(modifier, owner, name)
                }

                "method" -> {
                    check(entry.size == 5) { "Invalid entry: $line" }
                    val name = entry[3]
                    val desc = entry[4]
                    listOf(modifier, owner, "$name$desc")
                }

                else -> {
                    throw GradleException("Invalid entry: $line")
                }
            }
        }
            .map { lines ->
                lines.joinToString(COLUMN_SEPARATOR)
            }
            .toList()
    }
}

private fun generateClassTweakerFile(
    inputFile: File,
    outputFile: File,
    accessLevels: Set<String> = CLASS_TWEAKER_ACCESS_LEVELS.keys,
    transformer: (Sequence<String>) -> List<String>
) {
    val lines = inputFile.readLines()
        .asSequence()
        .map { line ->
            val index = line.indexOf('#')
            if (index != -1) line.substring(0, index) else line
        }
        .map(String::trim)
        .filter(String::isNotEmpty)
        .filter { line ->
            accessLevels.any(line::startsWith)
        }

    val text = transformer.invoke(lines).joinToString("\n")
    outputFile.parentFile.mkdirs()
    outputFile.writeText(text)
}
