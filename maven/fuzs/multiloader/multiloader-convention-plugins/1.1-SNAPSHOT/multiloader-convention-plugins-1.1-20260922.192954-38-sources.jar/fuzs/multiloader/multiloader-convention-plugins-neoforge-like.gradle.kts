package fuzs.multiloader

import fuzs.multiloader.classtweaker.*
import fuzs.multiloader.extension.mod
import fuzs.multiloader.extension.validateSources
import fuzs.multiloader.extension.versionCatalog
import gradle.kotlin.dsl.accessors._77647340e1cb244fa958b25834155aa6.main
import gradle.kotlin.dsl.accessors._77647340e1cb244fa958b25834155aa6.sourceSets
import kotlin.jvm.optionals.getOrNull

plugins {
    id("fuzs.multiloader.multiloader-convention-plugins-core")
    id("fuzs.multiloader.multiloader-convention-plugins-core-no-remap")
    id("net.neoforged.moddev")
}

generateAccessTransformerFile(templateClassTweakerFile, generatedAccessTransformerFile.get().asFile)

configurations {
    named("accessTransformers") {
        extendsFrom(
            named("modApi").get(),
            named("modImplementation").get(),
            named("modCompileOnly").get(),
            named("modCompileOnlyApi").get()
        )
    }
}

neoForge {
    accessTransformers {
        files.setFrom(generatedAccessTransformerFile)
        publish(generatedTransitiveAccessTransformerFile)
    }

    validateAccessTransformers.set(validateSources)

    parchment {
        versionCatalog.findVersion("parchment.minecraft").getOrNull()?.requiredVersion?.let(minecraftVersion::set)
        versionCatalog.findVersion("parchment.version").getOrNull()?.requiredVersion?.let(mappingsVersion::set)
    }

    mods {
        create(mod.id) {
            sourceSet(sourceSets.main.get())
        }
    }
}

val generateTransitiveAccessTransformerFile =
    tasks.register<GenerateAccessTransformerTask>("generateTransitiveAccessTransformerFile") {
        inputFile.set(templateClassTweakerFile)
        outputFile.set(generatedTransitiveAccessTransformerFile)
        accessLevels.set(TRANSITIVE_CLASS_TWEAKER_ACCESS_LEVELS)
    }

tasks.named("copyAccessTransformersPublications") {
    dependsOn(generateTransitiveAccessTransformerFile)
}
