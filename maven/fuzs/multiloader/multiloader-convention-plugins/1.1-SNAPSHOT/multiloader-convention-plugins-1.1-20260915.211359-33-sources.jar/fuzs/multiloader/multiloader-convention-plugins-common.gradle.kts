package fuzs.multiloader

import fuzs.multiloader.architectury.ArchitecturyCommonJsonTask
import fuzs.multiloader.classtweaker.*
import fuzs.multiloader.extension.defaultDependencies
import fuzs.multiloader.extension.expectPlatform
import fuzs.multiloader.extension.validateSources
import fuzs.multiloader.extension.versionCatalog
import fuzs.multiloader.metadata.ModLoaderProvider
import org.gradle.api.internal.tasks.JvmConstants
import kotlin.jvm.optionals.getOrNull

plugins {
    id("fuzs.multiloader.multiloader-convention-plugins-neoforge-like")
}

project.expectPlatform(ModLoaderProvider.COMMON)

neoForge {
    enable {
        neoFormVersion = versionCatalog.findVersion("neoform").get().requiredVersion
        isDisableRecompilation = !validateSources
    }
}

dependencies {
    compileOnly(versionCatalog.findLibrary("mixin.common").get())
    compileOnly(versionCatalog.findLibrary("mixinextras.common").get())

    if (defaultDependencies) {
        versionCatalog.findLibrary("multiloaderaccesswideners.common")
            .getOrNull()
            ?.let { accessTransformers(it) { isTransitive = false } }
    }
}

val generateTransitiveAccessWidenerFile =
    tasks.register<GenerateClassTweakerTask>("generateTransitiveAccessWidenerFile") {
        inputFile.set(templateClassTweakerFile)
        outputFile.set(generatedTransitiveAccessWidenerFile)
        accessLevels.set(TRANSITIVE_ACCESS_WIDENER_ACCESS_LEVELS.keys)
        header.set(ACCESS_WIDENER_NAMED_HEADER)
    }

val generateArchitecturyCommonJson = tasks.register<ArchitecturyCommonJsonTask>("generateArchitecturyCommonJson") {
    outputFile.set(layout.buildDirectory.file("generated/resources/architectury.common.json"))
    json {
        accessWidener.set(
            generatedTransitiveAccessWidenerFile.get().asFile
                .relativeTo(project.layout.buildDirectory.dir("generated/resources").get().asFile)
                .invariantSeparatorsPath
        )
    }
}

tasks.named<ProcessResources>(JvmConstants.PROCESS_RESOURCES_TASK_NAME) {
    dependsOn(generateTransitiveAccessWidenerFile, generateArchitecturyCommonJson)
    exclude("*.classtweaker", "*.accesswidener", "**/*.cfg")
}
