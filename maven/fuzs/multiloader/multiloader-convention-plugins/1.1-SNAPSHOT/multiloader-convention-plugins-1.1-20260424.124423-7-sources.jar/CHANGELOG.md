# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v1.1.6] - 2026-04-24

### Changed

- Set `validateAccessTransformers` to `false` by default in Mod Dev Gradle
- The Tiny Takeover Spotless task now migrates common packages from Puzzles Lib

## [v1.1.5] - 2026-04-20

### Changed

- Set caching strategies for custom tasks

### Fixed

- Fix `runtimeOnly` and `modRuntimeOnly` configurations on NeoForge

## [v1.1.4] - 2026-04-15

### Added

- Add a basic Spotless task for Tiny Takeover

### Changed

- Update to Fabric Loom 1.16
- Remove the project name from publication display names
- Point the common Mixin package to the updated location

### Fixed

- Fix `accesstransformer` publications by enabling the `GenerateModuleMetadata` task

## [v1.1.3] - 2026-04-02

### Changed

- Add `minecraft` version to `metadata.json`

## [v1.1.2] - 2026-04-02

### Changed

- Relax Minecraft version constraints for published artifacts and when uploading
- Set additional CurseForge metadata when uploading

## [v1.1.1] - 2026-03-31

### Fixed

- Fix NeoForge runs

## [v1.1.0] - 2026-03-24

### Changed

- Replace Architectury Loom with Loom and Mod Dev Gradle
