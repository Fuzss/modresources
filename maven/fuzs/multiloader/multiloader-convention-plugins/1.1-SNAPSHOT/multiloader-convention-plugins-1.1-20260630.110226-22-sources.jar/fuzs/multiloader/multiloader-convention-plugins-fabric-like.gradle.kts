package fuzs.multiloader

import fuzs.multiloader.classtweaker.*
import fuzs.multiloader.extension.expectPlatform
import fuzs.multiloader.extension.remappingRequired
import fuzs.multiloader.fabric.setupModJsonTask
import fuzs.multiloader.metadata.ModLoaderProvider
import net.fabricmc.loom.task.FabricModJsonV1Task
import org.gradle.api.internal.tasks.JvmConstants

plugins {
    id("fuzs.multiloader.multiloader-convention-plugins-platform")
}

project.expectPlatform(ModLoaderProvider.FABRIC)
generateClassTweakerFile(
    templateClassTweakerFile,
    generatedClassTweakerFile.get().asFile,
    header = if (remappingRequired) CLASS_TWEAKER_NAMED_HEADER else CLASS_TWEAKER_OFFICIAL_HEADER
)

repositories {
    maven {
        name = "Modmuss"
        url = uri("https://maven.modmuss50.me/")
    }
    maven {
        name = "Ladysnake Libs"
        url = uri("https://maven.ladysnake.org/releases/")
    }
    maven {
        name = "jamieswhiteshirt"
        url = uri("https://maven.jamieswhiteshirt.com/libs-release/")
    }
}

val generateModJson = tasks.register<FabricModJsonV1Task>("generateModJson") {
    setupModJsonTask()
}

tasks.named<ProcessResources>(JvmConstants.PROCESS_RESOURCES_TASK_NAME) {
    dependsOn(generateModJson)
}

tasks.register("${project.name.lowercase()}-sources") {
    group = "multiloader/sources"
    val task = tasks.named("genSourcesWithVineflower")
    description = task.get().description
    dependsOn(task)
}

tasks.register("${project.name.lowercase()}-validate") {
    group = "multiloader/sources"
    val task = tasks.named("validateAccessWidener")
    description = task.get().description
    dependsOn(task)
}
