package fuzs.multiloader.plugin

import fuzs.multiloader.extension.legacyVersioning
import org.gradle.api.Plugin
import org.gradle.api.Project

class FabricConventionPlugin : Plugin<Project> {
    override fun apply(project: Project) = with(project) {
        val projectLibs: String = providers.gradleProperty("project.libs").get()
        val minecraftVersion: String = projectLibs.substringBeforeLast('-')

        val pluginId = if (legacyVersioning(minecraftVersion)) {
            "fuzs.multiloader.multiloader-convention-plugins-fabric-loom-remap"
        } else {
            "fuzs.multiloader.multiloader-convention-plugins-fabric-loom"
        }

        pluginManager.apply(pluginId)
        pluginManager.apply("multiloader-convention-plugins-fabric-like")
    }
}
