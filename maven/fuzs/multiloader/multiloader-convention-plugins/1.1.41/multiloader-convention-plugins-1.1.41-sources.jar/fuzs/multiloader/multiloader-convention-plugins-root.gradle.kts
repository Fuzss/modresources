package fuzs.multiloader

import fuzs.multiloader.discord.*
import fuzs.multiloader.extension.*
import fuzs.multiloader.metadata.LinkProvider
import fuzs.multiloader.metadata.loadMetadata
import fuzs.multiloader.task.IncrementBuildNumber
import kotlinx.serialization.json.Json
import me.modmuss50.mpp.PublishModTask
import java.time.Instant

plugins {
    id("me.modmuss50.mod-publish-plugin")
}

afterEvaluate {
    project.layout.buildDirectory.dir("run/server").get().asFile.mkdirs()
    val metadata = loadMetadata()
    val json = Json { prettyPrint = true }
    val output = project.layout.projectDirectory.file("metadata.json").asFile
    output.writeText(json.encodeToString(metadata))
}

tasks.register<IncrementBuildNumber>("incrementBuildNumber") {
    description = "Increments the development build number for locally built JARs."
    val propertiesFile = layout.buildDirectory.file("build.properties")
    // Check file existence here, as the property requires it when set.
    if (propertiesFile.orNull?.asFile?.exists() == true) {
        inputFile.set(propertiesFile)
    }

    outputFile.set(propertiesFile)
}

tasks.withType<PublishModTask>().configureEach {
    notCompatibleWithConfigurationCache("The plugin stores a reference to the Gradle project object.")
    val versionString = project.changelogVersion
    doFirst {
        verifyChangelogVersion(file("CHANGELOG.md"), versionString)
    }
}

publishMods {
    displayName.set("v${mod.version}-mc${minecraftVersion}")
    type.set(STABLE)
    version.set(mod.version)

    // Only include the relevant changelog section.
    val changelogSections = file("CHANGELOG.md").readText().split(Regex("(?m)^## \\["), limit = 3)
    changelog.set("## [" + changelogSections.getOrNull(1)?.trim())
    dryRun.set(debugRemoteUploads)

    project.metadata.links.firstOrNull { it.name == LinkProvider.GITHUB }?.let { link ->
        providers.gradleProperty("fuzs.multiloader.remote.${link.name.name.lowercase()}.token").orNull?.let { token ->
            github {
                accessToken.set(token)
                repository.set(link.url().removePrefix(link.name.baseUrl))
                commitish.set(minecraftVersion)
                tagName.set("v${mod.version}-mc${minecraftVersion}")

                allowEmptyFiles = true
            }
        }
    }
}

tasks.withType<DiscordWebhookTask>().configureEach {
    val versionString = project.changelogVersion
    doFirst {
        verifyChangelogVersion(project.file("CHANGELOG.md"), versionString)
    }
}

tasks.register<DiscordWebhookTask>("sendDiscordWebhook") {
    description = "Sends the Discord release announcement for the current version."
    val discordChannel = providers.gradleProperty("fuzs.multiloader.remote.discord.channel")
    val discordToken = providers.gradleProperty("fuzs.multiloader.remote.discord.token")
    onlyIf { discordChannel.isPresent && discordToken.isPresent }

    val changelogFile = file("CHANGELOG.md")

    payload {
        channel.set(discordChannel.get())
        token.set(discordToken.get())
        val epochSeconds = System.currentTimeMillis() / 1000
        content.set("<t:$epochSeconds:R>")
        flags.set(MessageFlags.SUPPRESS_NOTIFICATIONS)
        debug.set(debugRemoteUploads)

        embed {
            title.set("[$minecraftVersion] ${mod.name} v${mod.version}")
            description.set(mod.description)
            metadata.links.firstOrNull { it.name == LinkProvider.MODRINTH }?.url()?.let { url.set(it) }
            timestamp.set(Instant.now().toString())
            color.set(5814783)

            val footerValues = listOf(mod.name, "v${mod.version}", minecraftVersion)
            footer(footerValues.joinToString(" \u2022 "))
            image("https://raw.githubusercontent.com/Fuzss/modresources/main/pages/data/${mod.id}/banner.png")
            thumbnail("https://raw.githubusercontent.com/Fuzss/modresources/main/pages/data/${mod.id}/logo.png")

            author("Fuzs") {
                url.set("https://modrinth.com/user/Fuzs")
                iconUrl.set("https://raw.githubusercontent.com/Fuzss/modresources/main/pages/commons/avatar.png")
            }

            parseChangelogFields(changelogFile).forEach { field(it.key, it.value) }

            val downloadLinks = metadata.links.mapNotNull {
                when (it.name) {
                    LinkProvider.CURSEFORGE -> "<:CurseForge:893088361634471948> [CurseForge](${it.url()})"
                    LinkProvider.MODRINTH -> "<:modrinth:1176378033578459206> [Modrinth](${it.url()})"
                    else -> null
                }
            }

            if (downloadLinks.isNotEmpty()) {
                field("\uD83D\uDCE5 Downloads", downloadLinks.joinToString("\n")) {
                    inline.set(true)
                }
            }

            metadata.links.firstOrNull { it.name == LinkProvider.GITHUB }?.url()?.let {
                field(
                    "<:github:1422695832951455814> GitHub", listOf(
                        "\uD83D\uDC68\u200D\uD83D\uDCBB [Source]($it)", "\u26A0\uFE0F [Issues]($it/issues)"
                    ).joinToString("\n")
                ) {
                    inline.set(true)
                }
            }

            field("\uD83D\uDCAC Support", "<:Fuzs:993195872131235881> <#917550806922846299>") {
                inline.set(true)
            }
        }
    }
}

if (project.platformProjects.isNotEmpty()) {
    tasks.register("all-build") {
        group = "multiloader/build"
        description = "Builds every loader project."
        dependsOn(project.platformProjects.map { it.tasks.named("build") })
    }
}

if (project.platformProjects.isNotEmpty() && providers.gradleProperty("fuzs.multiloader.build.output").isPresent) {
    tasks.register("all-copy") {
        group = "multiloader/build"
        description = "Builds and copies the development JARs of every loader project to the configured build output directory."
        dependsOn(project.platformProjects.map { it.tasks.named("copyDevelopmentJar") })
    }
}

if (project.subprojects.isNotEmpty()) {
    tasks.register("all-clean") {
        group = "multiloader/build"
        description = "Cleans every loader project."
        dependsOn(project.subprojects.map { it.tasks.named("clean") })
    }
}

if (project.subprojects.isNotEmpty()) {
    tasks.register("all-publish") {
        group = "multiloader/publish"
        description = "Publishes every project to the mod resources Maven repository."
        dependsOn(project.subprojects.map { it.tasks.named("publishMavenJavaPublicationToFuzsModResourcesRepository") })
    }
}

if (metadata.links.firstOrNull { it.name == LinkProvider.CURSEFORGE } != null && project.platformProjects.isNotEmpty()) {
    tasks.register("all-curseforge") {
        group = "multiloader/remote"
        description = "Uploads every loader project to CurseForge."
        dependsOn(project.platformProjects.map { it.tasks.named("publishCurseforge") })
    }
}

if (metadata.links.firstOrNull { it.name == LinkProvider.GITHUB } != null && project.platformProjects.isNotEmpty()) {
    tasks.register("all-github") {
        group = "multiloader/remote"
        description = "Uploads every loader project to GitHub."
        dependsOn(project.platformProjects.map { it.tasks.named("publishGithub") })
    }
}

if (metadata.links.firstOrNull { it.name == LinkProvider.MODRINTH } != null && project.platformProjects.isNotEmpty()) {
    tasks.register("all-modrinth") {
        group = "multiloader/remote"
        description = "Uploads every loader project to Modrinth."
        dependsOn(project.platformProjects.map { it.tasks.named("publishModrinth") })
    }
}

if (metadata.links.isNotEmpty()) {
    tasks.register("all-discord") {
        group = "multiloader/remote"
        description = "Sends the Discord release announcement."
        dependsOn(tasks.named("sendDiscordWebhook"))
    }
}

if (metadata.links.isNotEmpty()) {
    project.platformProjects.forEach {
        project.tasks.register("${it.name.lowercase()}-all") {
            group = "multiloader/remote"
            description = "Uploads the ${it.name.lowercase()} platform to every configured provider."
            dependsOn(it.tasks.named("publishMods"))
        }
    }
}

if (metadata.links.isNotEmpty() && project.platformProjects.isNotEmpty()) {
    tasks.register("all-all") {
        group = "multiloader/remote"
        description = "Uploads every project to all configured providers and sends the Discord announcement."
        dependsOn(project.platformProjects.map { it.tasks.named("publishMods") })
        dependsOn(tasks.named("sendDiscordWebhook"))
    }
}

tasks.register("all-java-apply") {
    group = "multiloader/spotless"
    description = "Applies Java formatting across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessJavaApply") })
}

tasks.register("all-java-check") {
    group = "multiloader/spotless"
    description = "Checks Java formatting across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessJavaCheck") })
}

tasks.register("all-tinytakeover-apply") {
    group = "multiloader/spotless"
    description = "Applies the TinyTakeover code migration across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessTinyTakeoverApply") })
}

tasks.register("all-tinytakeover-check") {
    group = "multiloader/spotless"
    description = "Checks the TinyTakeover code migration across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessTinyTakeoverCheck") })
}

tasks.register("all-mountsofmayhem-apply") {
    group = "multiloader/spotless"
    description = "Applies the MountsOfMayhem code migration across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessMountsOfMayhemApply") })
}

tasks.register("all-mountsofmayhem-check") {
    group = "multiloader/spotless"
    description = "Checks the MountsOfMayhem code migration across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessMountsOfMayhemCheck") })
}

tasks.register("all-thecopperage-apply") {
    group = "multiloader/spotless"
    description = "Applies the TheCopperAge code migration across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessTheCopperAgeApply") })
}

tasks.register("all-thecopperage-check") {
    group = "multiloader/spotless"
    description = "Checks the TheCopperAge code migration across all projects."
    dependsOn(project.subprojects.map { it.tasks.named("spotlessTheCopperAgeCheck") })
}
