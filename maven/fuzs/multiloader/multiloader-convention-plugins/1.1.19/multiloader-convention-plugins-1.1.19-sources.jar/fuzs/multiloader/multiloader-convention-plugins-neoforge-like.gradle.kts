package fuzs.multiloader

import fuzs.multiloader.classtweaker.*
import fuzs.multiloader.extension.versionCatalog
import org.gradle.api.internal.tasks.JvmConstants
import kotlin.jvm.optionals.getOrNull

plugins {
    id("fuzs.multiloader.multiloader-convention-plugins-core")
    id("fuzs.multiloader.multiloader-convention-plugins-core-no-remap")
    id("net.neoforged.moddev")
}

generateAccessTransformerFile(templateClassTweakerFile, generatedAccessTransformerFile.get().asFile)

configurations {
    named("accessTransformers") {
        extendsFrom(
            named("modApi").get(),
            named("modImplementation").get(),
            named("modCompileOnly").get(),
            named("modCompileOnlyApi").get()
        )
    }
}

neoForge {
    validateAccessTransformers.set(true)
    accessTransformers {
        files.setFrom(generatedAccessTransformerFile)
        publish(generatedTransitiveAccessTransformerFile)
    }

    parchment {
        versionCatalog.findVersion("parchment.minecraft")
            .getOrNull()
            ?.requiredVersion
            ?.let(minecraftVersion::set)
        versionCatalog.findVersion("parchment.version")
            .getOrNull()
            ?.requiredVersion
            ?.let(mappingsVersion::set)
    }
}

tasks.named<ProcessResources>(JvmConstants.PROCESS_RESOURCES_TASK_NAME) {
    exclude("**/*.classtweaker", "**/*.accesstransformer")
}

val generateTransitiveAccessTransformerFile =
    tasks.register<GenerateAccessTransformerTask>("generateTransitiveAccessTransformerFile") {
        inputFile.set(templateClassTweakerFile)
        outputFile.set(generatedTransitiveAccessTransformerFile)
        accessLevels.set(TRANSITIVE_CLASS_TWEAKER_ACCESS_LEVELS)
    }

tasks.named("copyAccessTransformersPublications") {
    dependsOn(generateTransitiveAccessTransformerFile)
}
