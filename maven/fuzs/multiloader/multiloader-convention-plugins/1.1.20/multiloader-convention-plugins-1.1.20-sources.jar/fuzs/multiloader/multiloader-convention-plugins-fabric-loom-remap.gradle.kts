package fuzs.multiloader

import fuzs.multiloader.classtweaker.generatedClassTweakerFile
import fuzs.multiloader.extension.minecraftVersion
import fuzs.multiloader.extension.mod
import fuzs.multiloader.extension.versionCatalog

plugins {
    id("fuzs.multiloader.multiloader-convention-plugins-fabric-like")
    id("net.fabricmc.fabric-loom-remap")
}

loom {
    accessWidenerPath.set(project.generatedClassTweakerFile)

    decompilers {
        get("vineflower").apply {
            // Shows the method name of lambdas in a comment.
            options.put("mark-corresponding-synthetics", "1")
        }
    }

    runs {
        configureEach {
            name("${project.name} ${this.name.replaceFirstChar { it.titlecase() }} ${project.minecraftVersion}")
            runDir("../run")
            ideConfigGenerated(true)
            vmArgs(
                "-Xms1G",
                "-Xmx4G",
                "-Dmixin.debug.export=true",
                "-Dlog4j2.configurationFile=${
                    this@configureEach.javaClass.classLoader.getResource("log4j.xml")
                        ?: throw IllegalStateException("log4j.xml not found in plugin resources")
                }",
                "-Dfabric-tag-conventions-v2.missingTagTranslationWarning=silenced",
                "-Dfabric-tag-conventions-v1.legacyTagWarning=silenced",
                "-Dpuzzleslib.isDevelopmentEnvironment=true",
                "-D${mod.id}.isDevelopmentEnvironment=true"
            )

            if (System.getProperty("os.name").startsWith("Mac")) {
                vmArgs("-XstartOnFirstThread")
            }
        }

        named("client") {
            client()
        }

        named("server") {
            server()
            runDir("../run/server")
            programArgs("--nogui")
        }
    }
}

dependencies {
    minecraft("com.mojang:minecraft:${versionCatalog.findVersion("game").get()}")

    @Suppress("UnstableApiUsage")
    mappings(loom.layered {
        officialMojangMappings {
            nameSyntheticMembers = true
        }

        parchment(
            "org.parchmentmc.data:parchment-${
                versionCatalog.findVersion("parchment.minecraft").get()
            }:${versionCatalog.findVersion("parchment.version").get()}@zip"
        )
    })
}
