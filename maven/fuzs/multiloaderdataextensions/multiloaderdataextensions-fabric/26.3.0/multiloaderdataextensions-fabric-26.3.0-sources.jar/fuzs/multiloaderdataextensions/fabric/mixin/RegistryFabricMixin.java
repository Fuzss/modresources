package fuzs.multiloaderdataextensions.fabric.mixin;

import net.minecraft.core.Registry;
import fuzs.multiloaderdataextensions.fabric.neoforge.registries.IRegistryExtension;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(Registry.class)
interface RegistryFabricMixin<T> extends IRegistryExtension<T> {

}
