/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package net.neoforged.neoforge.registries;

import fuzs.multiloaderdataextensions.common.impl.MultiloaderDataExtensions;
import io.netty.util.AttributeKey;
import net.fabricmc.fabric.api.networking.v1.ServerConfigurationNetworking;
import net.minecraft.core.Registry;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.RegistryDataLoader;
import net.minecraft.resources.ResourceKey;
import net.neoforged.neoforge.network.configuration.RegistryDataMapNegotiation;
import net.neoforged.neoforge.network.payload.KnownRegistryDataMapsReplyPayload;
import net.neoforged.neoforge.registries.datamaps.DataMapType;
import org.jetbrains.annotations.ApiStatus;
import org.jspecify.annotations.Nullable;

import java.util.Collection;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

@ApiStatus.Internal
public class RegistryManager {
    private static Map<ResourceKey<Registry<?>>, Map<Identifier, DataMapType<?, ?>>> dataMaps = new IdentityHashMap<>();

    @Nullable public static <R> DataMapType<R, ?> getDataMap(ResourceKey<? extends Registry<R>> registry, Identifier key) {
        final var map = dataMaps.get(registry);
        return map == null ? null : (DataMapType<R, ?>) map.get(key);
    }

    /**
     * {@return a view of all registered data maps}
     */
    public static Map<ResourceKey<Registry<?>>, Map<Identifier, DataMapType<?, ?>>> getDataMaps() {
        return dataMaps;
    }

    /**
     * Register a registry data map.
     *
     * @param type the data map type to register
     * @param <T>  the type of the data map
     * @param <R>  the type of the registry
     * @throws IllegalArgumentException      if a type with the same ID has already been registered for that registry
     * @throws UnsupportedOperationException if the registry is a non-synced datapack registry and the data map is
     *                                       synced
     */
    public static <T, R> void registerDataMap(DataMapType<R, T> type) {
        final var registry = type.registryKey();
        if (RegistryDataLoader.WORLDGEN_REGISTRIES.stream().anyMatch(data -> data.key().equals(registry))) {
            if (type.networkCodec() != null && RegistryDataLoader.SYNCHRONIZED_REGISTRIES.stream()
                    .noneMatch(data -> data.key().equals(registry))) {
                throw new UnsupportedOperationException(
                        "Cannot register synced data map " + type.id() + " for datapack registry " + registry.identifier()
                                + " that is not synced!");
            }
        }

        final var map = dataMaps.computeIfAbsent((ResourceKey) registry, k -> new HashMap<>());
        if (map.containsKey(type.id())) {
            throw new IllegalArgumentException(
                    "Tried to register data map type with ID " + type.id() + " to registry " + registry.identifier()
                            + " twice");
        }
        map.put(type.id(), type);
    }

    public static final AttributeKey<Map<ResourceKey<? extends Registry<?>>, Collection<Identifier>>> ATTRIBUTE_KNOWN_DATA_MAPS = AttributeKey.valueOf(
            MultiloaderDataExtensions.id("known_data_maps").toString());

    @ApiStatus.Internal
    public static void handleKnownDataMapsReply(final KnownRegistryDataMapsReplyPayload payload, final ServerConfigurationNetworking.Context context) {
        context.packetListener().connection.channel.pipeline()
                .lastContext()
                .attr(ATTRIBUTE_KNOWN_DATA_MAPS)
                .set(payload.dataMaps());
        context.packetListener().completeTask(RegistryDataMapNegotiation.TYPE);
    }
}
