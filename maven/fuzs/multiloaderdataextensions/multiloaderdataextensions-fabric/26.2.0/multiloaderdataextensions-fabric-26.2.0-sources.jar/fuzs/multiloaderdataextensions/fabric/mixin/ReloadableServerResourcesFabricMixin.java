package fuzs.multiloaderdataextensions.fabric.mixin;

import fuzs.multiloaderdataextensions.fabric.impl.MultiloaderDataExtensionsFabric;
import net.minecraft.server.ReloadableServerResources;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ReloadableServerResources.class)
abstract class ReloadableServerResourcesFabricMixin {

    @ModifyVariable(method = "lambda$loadResources$2(Lnet/minecraft/server/ReloadableServerRegistries$LoadResult;Lnet/minecraft/world/flag/FeatureFlagSet;Lnet/minecraft/commands/Commands$CommandSelection;Ljava/util/List;Lnet/minecraft/server/permissions/PermissionSet;Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/concurrent/Executor;Ljava/util/concurrent/Executor;Ljava/util/List;)Ljava/util/concurrent/CompletionStage;",
                    at = @At(value = "STORE", ordinal = 0))
    private static ReloadableServerResources loadResources(ReloadableServerResources result) {
        MultiloaderDataExtensionsFabric.setReloadableServerResources(result);
        return result;
    }
}
