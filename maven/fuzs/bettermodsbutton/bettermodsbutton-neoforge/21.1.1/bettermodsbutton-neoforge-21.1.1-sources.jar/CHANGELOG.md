# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v21.1.1-1.21.1] - 2026-10-21

### Fixed

- Collapse branding in-dev only to prevent a crash due to the mod config not yet being available

## [v21.1.0-1.21.1] - 2024-09-10

- Ported to Minecraft 1.21.1
