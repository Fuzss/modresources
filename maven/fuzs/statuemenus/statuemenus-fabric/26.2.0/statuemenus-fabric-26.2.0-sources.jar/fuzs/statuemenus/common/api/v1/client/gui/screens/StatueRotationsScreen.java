package fuzs.statuemenus.common.api.v1.client.gui.screens;

import fuzs.statuemenus.common.api.v1.client.gui.components.ConfirmationImageButton;
import fuzs.statuemenus.common.api.v1.client.gui.components.slider.AbstractSquareSliderButton;
import fuzs.statuemenus.common.api.v1.client.gui.components.slider.SquareSliderButton;
import fuzs.statuemenus.common.api.v1.network.client.data.DataSyncHandler;
import fuzs.statuemenus.common.api.v1.world.inventory.StatueHolder;
import fuzs.statuemenus.common.api.v1.world.inventory.data.PosePartMutator;
import fuzs.statuemenus.common.api.v1.world.inventory.data.StatuePose;
import fuzs.statuemenus.common.api.v1.world.inventory.data.StatueScreenType;
import fuzs.statuemenus.common.impl.StatueMenus;
import fuzs.statuemenus.common.impl.client.gui.components.TooltipSuppliers;
import net.minecraft.client.gui.ComponentPath;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.navigation.FocusNavigationEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.core.Rotations;
import net.minecraft.locale.Language;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import org.jspecify.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;

public class StatueRotationsScreen extends AbstractStatueScreen {
    public static final WidgetSprites TICK_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/tick_button"),
            StatueMenus.id("container/statue/tick_button_disabled"),
            StatueMenus.id("container/statue/tick_button_highlighted"));
    public static final WidgetSprites TICK_BUTTON_LARGE_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/tick_button_large"),
            StatueMenus.id("container/statue/tick_button_large_disabled"),
            StatueMenus.id("container/statue/tick_button_large_highlighted"));
    public static final WidgetSprites LOCK_CLOSED_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/lock_closed_button"),
            StatueMenus.id("container/statue/lock_closed_button_disabled"),
            StatueMenus.id("container/statue/lock_closed_button_highlighted"));
    public static final WidgetSprites LOCK_OPEN_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/lock_open_button"),
            StatueMenus.id("container/statue/lock_open_button_disabled"),
            StatueMenus.id("container/statue/lock_open_button_highlighted"));
    public static final WidgetSprites MIRROR_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/mirror_button"),
            StatueMenus.id("container/statue/mirror_button_disabled"),
            StatueMenus.id("container/statue/mirror_button_highlighted"));
    public static final WidgetSprites RANDOMIZE_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/randomize_button"),
            StatueMenus.id("container/statue/randomize_button_disabled"),
            StatueMenus.id("container/statue/randomize_button_highlighted"));
    public static final WidgetSprites COPY_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/copy_button"),
            StatueMenus.id("container/statue/copy_button_disabled"),
            StatueMenus.id("container/statue/copy_button_highlighted"));
    public static final WidgetSprites PASTE_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/paste_button"),
            StatueMenus.id("container/statue/paste_button_disabled"),
            StatueMenus.id("container/statue/paste_button_highlighted"));
    public static final WidgetSprites RESET_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/reset_button"),
            StatueMenus.id("container/statue/reset_button_disabled"),
            StatueMenus.id("container/statue/reset_button_highlighted"));
    public static final String TIP_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id().toLanguageKey("screen", "tip");
    public static final String UNLIMITED_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id()
            .toLanguageKey("screen", "unlimited");
    public static final String LIMITED_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id()
            .toLanguageKey("screen", "limited");
    public static final String RESET_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id().toLanguageKey("screen", "reset");
    public static final String RANDOMIZE_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id()
            .toLanguageKey("screen", "randomize");
    public static final String PASTE_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id().toLanguageKey("screen", "paste");
    public static final String COPY_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id().toLanguageKey("screen", "copy");
    public static final String MIRROR_TRANSLATION_KEY = StatueScreenType.ROTATIONS.id()
            .toLanguageKey("screen", "mirror");

    private static boolean clampRotations = true;
    @Nullable
    private static StatuePose clipboard;
    private final AbstractWidget[] lockButtons = new AbstractWidget[2];
    private StatuePose currentPose;

    public StatueRotationsScreen(StatueHolder holder, Inventory inventory, Component component, DataSyncHandler dataSyncHandler) {
        super(holder, inventory, component, dataSyncHandler);
        this.inventoryEntityX = 80;
        this.inventoryEntityY = 58;
        this.smallInventoryEntity = true;
        this.currentPose = StatuePose.fromEntity(holder.getStatueEntity());
    }

    protected List<PosePartMutator> getPosePartMutators() {
        return PosePartMutator.TYPES;
    }

    protected StatuePose setupRandomPose(StatuePose statuePose) {
        return statuePose.withBodyPose(new Rotations(0.0F, 0.0F, 0.0F));
    }

    @Override
    protected void init() {
        super.init();
        this.lockButtons[0] = Util.make(this.addRenderableWidget(new ImageButton(this.leftPos + 83,
                this.topPos + 10,
                20,
                20,
                LOCK_OPEN_BUTTON_SPRITES,
                (Button button) -> {
                    clampRotations = true;
                    this.toggleLockButtons();
                    this.refreshLiveButtons();
                })), (AbstractWidget widget) -> {
            widget.setTooltip(Tooltip.create(Component.translatable(UNLIMITED_TRANSLATION_KEY)));
        });
        this.lockButtons[1] = Util.make(this.addRenderableWidget(new ImageButton(this.leftPos + 83,
                this.topPos + 10,
                20,
                20,
                LOCK_CLOSED_BUTTON_SPRITES,
                (Button button) -> {
                    clampRotations = false;
                    this.toggleLockButtons();
                    this.refreshLiveButtons();
                })), (AbstractWidget widget) -> {
            widget.setTooltip(Tooltip.create(Component.translatable(LIMITED_TRANSLATION_KEY)));
        });
        Tooltip tooltip = this.getTipComponent();
        if (tooltip != null) {
            this.addRenderableWidget(new ImageButton(this.leftPos + 107,
                    this.topPos + 10,
                    20,
                    20,
                    QUESTION_MARK_SPRITES,
                    Function.identity()::apply) {

                @Nullable
                @Override
                public ComponentPath nextFocusPath(FocusNavigationEvent event) {
                    return null;
                }

                @Override
                public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean doubleClick) {
                    return false;
                }
            }).setTooltip(tooltip);
        }
        this.addRenderableWidget(new ConfirmationImageButton(this.leftPos + 83,
                this.topPos + 34,
                20,
                20,
                RANDOMIZE_BUTTON_SPRITES,
                TICK_BUTTON_SPRITES,
                (Button button) -> {
                    StatuePose statuePose = StatuePose.randomize(this.getPosePartMutators(), clampRotations);
                    this.setCurrentPose(this.setupRandomPose(statuePose));
                })).setTooltip(Tooltip.create(Component.translatable(RANDOMIZE_TRANSLATION_KEY)));
        this.addRenderableWidget(new ConfirmationImageButton(this.leftPos + 107,
                this.topPos + 34,
                20,
                20,
                RESET_BUTTON_SPRITES,
                TICK_BUTTON_SPRITES,
                (Button button) -> {
                    this.setCurrentPose(StatuePose.EMPTY);
                })).setTooltip(Tooltip.create(Component.translatable(RESET_TRANSLATION_KEY)));
        this.addRenderableWidget(new ConfirmationImageButton(this.leftPos + 83,
                this.topPos + 134,
                44,
                20,
                MIRROR_BUTTON_SPRITES,
                TICK_BUTTON_LARGE_SPRITES,
                (Button button) -> {
                    this.setCurrentPose(this.currentPose.mirror());
                })).setTooltip(Tooltip.create(Component.translatable(MIRROR_TRANSLATION_KEY)));
        AbstractWidget[] pasteButton = new AbstractWidget[1];
        this.addRenderableWidget(new ConfirmationImageButton(this.leftPos + 83,
                this.topPos + 158,
                20,
                20,
                COPY_BUTTON_SPRITES,
                TICK_BUTTON_SPRITES,
                (Button button) -> {
                    clipboard = this.currentPose;
                    pasteButton[0].active = true;
                })).setTooltip(Tooltip.create(Component.translatable(COPY_TRANSLATION_KEY)));
        pasteButton[0] = Util.make(this.addRenderableWidget(new ConfirmationImageButton(this.leftPos + 107,
                this.topPos + 158,
                20,
                20,
                PASTE_BUTTON_SPRITES,
                TICK_BUTTON_SPRITES,
                (Button button) -> {
                    if (clipboard != null) {
                        this.setCurrentPose(clipboard);
                    }
                })), (ConfirmationImageButton widget) -> {
            widget.setTooltip(Tooltip.create(Component.translatable(PASTE_TRANSLATION_KEY)));
            widget.active = clipboard != null;
        });
        List<PosePartMutator> posePartMutators = this.getPosePartMutators();
        for (int i = 0; i < posePartMutators.size(); i++) {
            PosePartMutator mutator = posePartMutators.get(i);
            boolean isLeft = i % 2 == 0;
            this.addRenderableWidget(new SquareSliderButton(this.leftPos + 23 + i % 2 * 110,
                    this.topPos + 7 + i / 2 * 60,
                    54,
                    54) {
                {
                    this.active = StatueRotationsScreen.this.isPosePartMutatorActive(mutator,
                            StatueRotationsScreen.this.holder.getEntity());
                    TooltipSuppliers.applyRotationsTooltip(this, isLeft, () -> {
                        List<Component> lines = new ArrayList<>();
                        lines.add(Component.translatable(mutator.getTranslationKey()));
                        lines.add(mutator.getAxisComponent(StatueRotationsScreen.this.currentPose, 0));
                        lines.add(mutator.getAxisComponent(StatueRotationsScreen.this.currentPose, 1));
                        return lines;
                    });
                }

                @Override
                public void refreshValues() {
                    this.horizontalValue = mutator.getNormalizedRotationsAtAxis(1,
                            StatueRotationsScreen.this.currentPose,
                            clampRotations);
                    this.verticalValue = mutator.getNormalizedRotationsAtAxis(0,
                            StatueRotationsScreen.this.currentPose,
                            clampRotations);
                }

                @Override
                protected void applyValue() {
                    super.applyValue();
                    StatueRotationsScreen.this.currentPose = mutator.setRotationsAtAxis(1,
                            StatueRotationsScreen.this.currentPose,
                            this.horizontalValue,
                            clampRotations);
                    StatueRotationsScreen.this.currentPose = mutator.setRotationsAtAxis(0,
                            StatueRotationsScreen.this.currentPose,
                            this.verticalValue,
                            clampRotations);
                }

                @Override
                public void clearDirty(boolean isDirty) {
                    super.clearDirty(isDirty);
                    if (isDirty) {
                        StatueRotationsScreen.this.setCurrentPose(StatueRotationsScreen.this.currentPose);
                    }
                }
            });
            this.addRenderableWidget(new SquareSliderButton(this.leftPos + 6 + i % 2 * 183,
                    this.topPos + 7 + i / 2 * 60,
                    15,
                    54) {
                {
                    this.active = StatueRotationsScreen.this.isPosePartMutatorActive(mutator,
                            StatueRotationsScreen.this.holder.getEntity());
                    TooltipSuppliers.applyRotationsTooltip(this, isLeft, () -> {
                        List<Component> lines = new ArrayList<>();
                        lines.add(Component.translatable(mutator.getTranslationKey()));
                        lines.add(mutator.getAxisComponent(StatueRotationsScreen.this.currentPose, 2));
                        return lines;
                    });
                }

                @Override
                protected void applyValue() {
                    super.applyValue();
                    StatueRotationsScreen.this.currentPose = mutator.setRotationsAtAxis(2,
                            StatueRotationsScreen.this.currentPose,
                            this.verticalValue,
                            clampRotations);
                }

                @Override
                public void refreshValues() {
                    this.verticalValue = mutator.getNormalizedRotationsAtAxis(2,
                            StatueRotationsScreen.this.currentPose,
                            clampRotations);
                }

                @Override
                protected boolean isHorizontalValueLocked() {
                    return true;
                }

                @Override
                protected boolean isVerticalValueLocked() {
                    return false;
                }

                @Override
                public void clearDirty(boolean isDirty) {
                    super.clearDirty(isDirty);
                    if (isDirty) {
                        StatueRotationsScreen.this.setCurrentPose(StatueRotationsScreen.this.currentPose);
                    }
                }
            });
            this.toggleLockButtons();
        }
    }

    @Nullable
    private Tooltip getTipComponent() {
        List<Component> components = new ArrayList<>();
        for (int i = 1; Language.getInstance().has(TIP_TRANSLATION_KEY + i); i++) {
            components.add(Component.translatable(TIP_TRANSLATION_KEY + i));
        }

        Collections.shuffle(components);
        return components.stream().findAny().map(Tooltip::create).orElse(null);
    }

    private void toggleLockButtons() {
        this.lockButtons[0].visible = !clampRotations;
        this.lockButtons[1].visible = clampRotations;
    }

    @Override
    protected StatuePose getPoseOverride() {
        return this.currentPose;
    }

    @Override
    protected boolean withCloseButton() {
        return false;
    }

    @Override
    public StatueScreenType getScreenType() {
        return StatueScreenType.ROTATIONS;
    }

    private void setCurrentPose(StatuePose pose) {
        this.dataSyncHandler.sendPose(pose);
        StatuePose lastSyncedPose = this.dataSyncHandler.getLastSyncedPose();
        this.currentPose = lastSyncedPose != null ? lastSyncedPose : pose;
        this.refreshLiveButtons();
    }

    private void refreshLiveButtons() {
        for (GuiEventListener child : this.children()) {
            if (child instanceof AbstractSquareSliderButton button) {
                button.refreshValues();
            }
        }
    }

    protected boolean isPosePartMutatorActive(PosePartMutator posePartMutator, LivingEntity livingEntity) {
        return true;
    }
}
