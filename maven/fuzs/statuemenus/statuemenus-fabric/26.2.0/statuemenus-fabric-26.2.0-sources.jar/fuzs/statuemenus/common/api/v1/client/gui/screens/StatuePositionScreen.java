package fuzs.statuemenus.common.api.v1.client.gui.screens;

import fuzs.puzzleslib.common.api.client.gui.v2.tooltip.TooltipBuilder;
import fuzs.puzzleslib.common.api.util.v1.CommonHelper;
import fuzs.statuemenus.common.api.v1.client.gui.components.ConfirmationImageButton;
import fuzs.statuemenus.common.api.v1.client.gui.components.slider.ImageSliderButton;
import fuzs.statuemenus.common.api.v1.client.gui.components.ImageTextButton;
import fuzs.statuemenus.common.api.v1.helper.ScaleAttributeHelper;
import fuzs.statuemenus.common.api.v1.network.client.data.DataSyncHandler;
import fuzs.statuemenus.common.api.v1.world.inventory.StatueHolder;
import fuzs.statuemenus.common.api.v1.world.inventory.data.StatueScreenType;
import fuzs.statuemenus.common.impl.StatueMenus;
import fuzs.statuemenus.common.impl.world.inventory.StatuePoses;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.util.Util;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import org.jspecify.annotations.Nullable;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.OptionalDouble;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

public class StatuePositionScreen extends StatueButtonsScreen {
    public static final WidgetSprites BUTTON_SPRITES = new WidgetSprites(StatueMenus.id("container/statue/button"),
            StatueMenus.id("container/statue/button_disabled"),
            StatueMenus.id("container/statue/button_highlighted"));
    public static final WidgetSprites UP_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id("container/statue/up_button"),
            StatueMenus.id("container/statue/up_button_disabled"),
            StatueMenus.id("container/statue/up_button_highlighted"));
    public static final WidgetSprites DOWN_BUTTON_SPRITES = new WidgetSprites(StatueMenus.id(
            "container/statue/down_button"),
            StatueMenus.id("container/statue/down_button_disabled"),
            StatueMenus.id("container/statue/down_button_highlighted"));
    public static final String SCALE_TRANSLATION_KEY = StatueScreenType.POSITION.id().toLanguageKey("screen", "scale");
    public static final String ROTATION_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "rotation");
    public static final String POSITION_X_TRANSLATION_KEY = StatueScreenType.POSITION.id().toLanguageKey("screen", "x");
    public static final String POSITION_Y_TRANSLATION_KEY = StatueScreenType.POSITION.id().toLanguageKey("screen", "y");
    public static final String POSITION_Z_TRANSLATION_KEY = StatueScreenType.POSITION.id().toLanguageKey("screen", "z");
    public static final String INCREMENT_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "increment");
    public static final String DECREMENT_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "decrement");
    public static final String PIXELS_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "pixels");
    public static final String BLOCKS_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "blocks");
    public static final String DEGREES_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "degrees");
    public static final String MOVE_BY_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "move_by");
    public static final String CENTERED_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "centered");
    public static final String CENTERED_DESCRIPTION_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "centered.description");
    public static final String CORNERED_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "cornered");
    public static final String CORNERED_DESCRIPTION_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "cornered.description");
    public static final String ALIGNED_TRANSLATION_KEY = StatueScreenType.POSITION.id()
            .toLanguageKey("screen", "aligned");
    protected static final ArmorStandWidgetFactory<StatuePositionScreen> SCALE_WIDGET_FACTORY = (StatuePositionScreen screen, LivingEntity livingEntity) -> {
        return screen.new ScaleWidget(Component.translatable(SCALE_TRANSLATION_KEY),
                livingEntity::getScale,
                screen.dataSyncHandler::sendScale) {
            @Override
            protected OptionalDouble getDefaultValue() {
                return OptionalDouble.of(fromLogarithmicValue(ScaleAttributeHelper.DEFAULT_SCALE));
            }
        };
    };
    protected static final ArmorStandWidgetFactory<StatuePositionScreen> ROTATION_WIDGET_FACTORY = (StatuePositionScreen screen, LivingEntity livingEntity) -> {
        return screen.new SliderWidget(Component.translatable(ROTATION_TRANSLATION_KEY),
                livingEntity::getYRot,
                screen.dataSyncHandler::sendRotation);
    };
    protected static final ArmorStandWidgetFactory<StatuePositionScreen> POSITION_INCREMENT_WIDGET_FACTORY = (StatuePositionScreen screen, LivingEntity livingEntity) -> {
        return screen.new PositionControlsWidget();
    };
    protected static final ArmorStandWidgetFactory<StatuePositionScreen> POSITION_X_WIDGET_FACTORY = (StatuePositionScreen screen, LivingEntity livingEntity) -> {
        return screen.new PositionComponentWidget(POSITION_X_TRANSLATION_KEY, livingEntity::getX, (double x) -> {
            screen.dataSyncHandler.sendPosition(x, livingEntity.getY(), livingEntity.getZ());
        });
    };
    protected static final ArmorStandWidgetFactory<StatuePositionScreen> POSITION_Y_WIDGET_FACTORY = (StatuePositionScreen screen, LivingEntity livingEntity) -> {
        return screen.new PositionComponentWidget(POSITION_Y_TRANSLATION_KEY, livingEntity::getY, (double y) -> {
            screen.dataSyncHandler.sendPosition(livingEntity.getX(), y, livingEntity.getZ());
        });
    };
    protected static final ArmorStandWidgetFactory<StatuePositionScreen> POSITION_Z_WIDGET_FACTORY = (StatuePositionScreen screen, LivingEntity livingEntity) -> {
        return screen.new PositionComponentWidget(POSITION_Z_TRANSLATION_KEY, livingEntity::getZ, (double z) -> {
            screen.dataSyncHandler.sendPosition(livingEntity.getX(), livingEntity.getY(), z);
        });
    };
    private static final DecimalFormat BLOCK_INCREMENT_FORMAT = Util.make(new DecimalFormat("#.####"),
            (DecimalFormat decimalFormat) -> {
                decimalFormat.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ROOT));
            });
    private static final double[] INCREMENTS = {0.0625, 0.25, 0.5, 1.0};

    private static double currentIncrement = INCREMENTS[0];

    public StatuePositionScreen(StatueHolder holder, Inventory inventory, Component component, DataSyncHandler dataSyncHandler) {
        super(holder, inventory, component, dataSyncHandler);
    }

    @Override
    protected List<ArmorStandWidget> buildWidgets(LivingEntity livingEntity) {
        return buildWidgets(this,
                livingEntity,
                List.of(SCALE_WIDGET_FACTORY,
                        ROTATION_WIDGET_FACTORY,
                        POSITION_INCREMENT_WIDGET_FACTORY,
                        POSITION_X_WIDGET_FACTORY,
                        POSITION_Y_WIDGET_FACTORY,
                        POSITION_Z_WIDGET_FACTORY));
    }

    @Override
    protected boolean withCloseButton() {
        return false;
    }

    @Override
    public StatueScreenType getScreenType() {
        return StatueScreenType.POSITION;
    }

    private static Component getPixelIncrementComponent(double increment) {
        return Component.translatable(PIXELS_TRANSLATION_KEY, getBlockPixelIncrement(increment));
    }

    private static Component getBlockIncrementComponent(double increment) {
        return Component.translatable(BLOCKS_TRANSLATION_KEY, BLOCK_INCREMENT_FORMAT.format(increment));
    }

    private static int getBlockPixelIncrement(double increment) {
        return (int) Math.round(increment * 16.0);
    }

    protected class ScaleWidget extends SliderWidget {
        static final double LOGARITHMIC_SCALE = 2.0;
        static final double LOGARITHMIC_SCALE_POW = Math.pow(10.0, -LOGARITHMIC_SCALE);

        public ScaleWidget(Component title, DoubleSupplier currentValue, Consumer<Float> newValue) {
            super(title, currentValue, newValue, -1.0);
        }

        @Override
        protected double getCurrentValue() {
            return fromLogarithmicValue(this.valueGetter.getAsDouble());
        }

        @Override
        protected void setNewValue(double newValue) {
            this.valueSetter.accept(toLogarithmicValue(newValue));
        }

        @Override
        protected Component getTooltipComponent(double mouseValue) {
            mouseValue = toLogarithmicValue(mouseValue);
            mouseValue = (int) (mouseValue * 100.0F) / 100.0F;
            mouseValue = Mth.clamp(mouseValue, ScaleAttributeHelper.MIN_SCALE, ScaleAttributeHelper.MAX_SCALE);
            return Component.literal(StatuePoses.ROTATION_FORMAT.format(mouseValue));
        }

        @Override
        protected void applyClientValue(double newValue) {
            ScaleAttributeHelper.setScale(StatuePositionScreen.this.getHolder().getEntity(),
                    toLogarithmicValue(newValue));
        }

        public static double fromLogarithmicValue(double value) {
            value = Mth.inverseLerp(value, ScaleAttributeHelper.MIN_SCALE, ScaleAttributeHelper.MAX_SCALE);
            return (Math.log10(value + LOGARITHMIC_SCALE_POW) + LOGARITHMIC_SCALE) / LOGARITHMIC_SCALE;
        }

        public static float toLogarithmicValue(double value) {
            value = Math.pow(10.0, value * LOGARITHMIC_SCALE - LOGARITHMIC_SCALE) - LOGARITHMIC_SCALE_POW;
            return (float) Mth.lerp(value, ScaleAttributeHelper.MIN_SCALE, ScaleAttributeHelper.MAX_SCALE);
        }
    }

    protected class SliderWidget extends ArmorStandWidget {
        protected final DoubleSupplier valueGetter;
        protected final Consumer<Float> valueSetter;
        private final double snapInterval;
        @Nullable
        protected ImageSliderButton sliderButton;
        @Nullable
        protected Button resetButton;

        public SliderWidget(Component title, DoubleSupplier valueGetter, Consumer<Float> valueSetter) {
            this(title, valueGetter, valueSetter, StatuePoses.DEGREES_SNAP_INTERVAL);
        }

        public SliderWidget(Component title, DoubleSupplier valueGetter, Consumer<Float> valueSetter, double snapInterval) {
            super(title);
            this.valueGetter = valueGetter;
            this.valueSetter = valueSetter;
            this.snapInterval = snapInterval;
        }

        protected double getCurrentValue() {
            return fromWrappedDegrees(this.valueGetter.getAsDouble());
        }

        protected void setNewValue(double newValue) {
            this.valueSetter.accept(toWrappedDegrees(newValue));
        }

        protected OptionalDouble getDefaultValue() {
            return OptionalDouble.empty();
        }

        protected Component getTooltipComponent(double mouseValue) {
            return Component.translatable(DEGREES_TRANSLATION_KEY,
                    StatuePoses.ROTATION_FORMAT.format(toWrappedDegrees(mouseValue)));
        }

        public static double fromWrappedDegrees(double value) {
            return (Mth.wrapDegrees(value) + 180.0) / 360.0;
        }

        public static float toWrappedDegrees(double value) {
            return (float) Mth.wrapDegrees(value * 360.0 - 180.0);
        }

        protected void applyClientValue(double newValue) {
            // NO-OP
        }

        @Override
        public void reset() {
            if (this.sliderButton != null) {
                this.sliderButton.setRawValue(this.getCurrentValue());
            }
        }

        @Override
        public void tick() {
            super.tick();
            this.setupButtonVisibility();
        }

        @Override
        public void setVisible(boolean visible) {
            super.setVisible(visible);
            if (visible) {
                this.setupButtonVisibility();
            }
        }

        private void setupButtonVisibility() {
            if (this.toggleButton != null && this.resetButton != null) {
                this.resetButton.visible = CommonHelper.hasAltDown();
                this.toggleButton.visible = !this.resetButton.visible;
            }
        }

        @Override
        public void init(int posX, int posY) {
            super.init(posX, posY);
            this.sliderButton = new ImageSliderButton(posX + 76, posY + 1, 90, 20, this.getCurrentValue()) {
                @Override
                protected double getSnapInterval() {
                    return SliderWidget.this.snapInterval;
                }

                @Override
                public void extractWidgetRenderState(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, float partialTick) {
                    super.extractWidgetRenderState(guiGraphics, mouseX, mouseY, partialTick);
                    double mouseValue = StatuePoses.snapValue((mouseX - this.getX()) / (double) this.getWidth(),
                            this.getSnapInterval());
                    this.setTooltip(Tooltip.create(StatuePositionScreen.SliderWidget.this.getTooltipComponent(mouseValue)));
                }

                @Override
                protected void applyValue() {
                    super.applyValue();
                    SliderWidget.this.applyClientValue(this.value);
                }

                @Override
                public void clearDirty(boolean isDirty) {
                    super.clearDirty(isDirty);
                    if (isDirty) {
                        SliderWidget.this.setNewValue(this.value);
                    }
                }
            };
            this.addRenderableWidget(this.sliderButton);
            if (this.getDefaultValue().isPresent()) {
                this.resetButton = this.addRenderableWidget(new ConfirmationImageButton(posX + 174,
                        posY + 1,
                        20,
                        20,
                        StatueRotationsScreen.RESET_BUTTON_SPRITES,
                        StatueRotationsScreen.TICK_BUTTON_SPRITES,
                        (Button button) -> {
                            this.getDefaultValue().ifPresent((double value) -> {
                                this.setNewValue(value);
                                this.applyClientValue(value);
                                this.reset();
                            });
                        }));
                this.resetButton.setTooltip(Tooltip.create(Component.translatable(StatueRotationsScreen.RESET_TRANSLATION_KEY)));
                this.setupButtonVisibility();
            }
        }

        @Override
        protected boolean supportsToggleButton() {
            return true;
        }
    }

    private class PositionControlsWidget extends ArmorStandWidget {

        public PositionControlsWidget() {
            super(Component.translatable(MOVE_BY_TRANSLATION_KEY));
        }

        @Override
        public void init(int posX, int posY) {
            super.init(posX, posY);
            for (int i = 0; i < INCREMENTS.length; i++) {
                double increment = INCREMENTS[i];
                AbstractWidget widget = this.addRenderableWidget(new ImageTextButton(
                        posX + 76 + i * 24 + (i > 1 ? 1 : 0), posY + 1, 20, 20, BUTTON_SPRITES, (Button button) -> {
                    this.setActiveIncrement(button, increment);
                }, Component.literal(String.valueOf(getBlockPixelIncrement(increment)))));
                TooltipBuilder.create(getPixelIncrementComponent(increment), getBlockIncrementComponent(increment))
                        .build(widget);
                if (increment == currentIncrement) {
                    widget.active = false;
                }
            }
        }

        @Override
        protected boolean supportsToggleButton() {
            return true;
        }

        private void setActiveIncrement(AbstractWidget source, double increment) {
            currentIncrement = increment;
            for (GuiEventListener widget : this.children()) {
                if (widget instanceof AbstractWidget abstractWidget) {
                    abstractWidget.active = widget != source;
                }
            }
        }

        @Override
        public boolean alwaysVisible(@Nullable ArmorStandWidget activeWidget) {
            return !(activeWidget instanceof SliderWidget);
        }
    }

    private class PositionComponentWidget extends ArmorStandWidget {
        private final DoubleSupplier currentValue;
        private final DoubleConsumer newValue;

        private EditBox editBox;
        private int ticks;

        public PositionComponentWidget(String translationKey, DoubleSupplier currentValue, DoubleConsumer newValue) {
            super(Component.translatable(translationKey));
            this.currentValue = currentValue;
            this.newValue = newValue;
        }

        @Override
        public void tick() {
            super.tick();
            // armor stand position might change externally, so we update occasionally
            if (--this.ticks <= 0 && this.editBox != null) {
                this.ticks = 10;
                this.editBox.setValue(BLOCK_INCREMENT_FORMAT.format(this.getPositionValue()));
            }
        }

        @Override
        public void init(int posX, int posY) {
            super.init(posX, posY);
            this.editBox = new EditBox(StatuePositionScreen.this.font,
                    posX + 77,
                    posY,
                    66,
                    22,
                    StatuePositionScreen.this.getHolder().getEntity().getType().getDescription());
            this.editBox.setMaxLength(50);
            this.editBox.setEditable(false);
            this.editBox.setTextColorUneditable(0XFFE0E0E0);
            this.editBox.setValue(BLOCK_INCREMENT_FORMAT.format(this.getPositionValue()));
            this.addRenderableOnly(this.editBox);
            AbstractWidget incrementButton = this.addRenderableWidget(new ImageButton(posX + 149,
                    posY + 1,
                    20,
                    10,
                    UP_BUTTON_SPRITES,
                    (Button button) -> {
                        this.setPositionValue(this.getPositionValue() + currentIncrement);
                    }));
            TooltipBuilder.create()
                    .setLines(() -> Collections.singletonList(Component.translatable(INCREMENT_TRANSLATION_KEY,
                            getPixelIncrementComponent(currentIncrement))))
                    .build(incrementButton);
            AbstractWidget decrementButton = this.addRenderableWidget(new ImageButton(posX + 149,
                    posY + 11,
                    20,
                    10,
                    DOWN_BUTTON_SPRITES,
                    (Button button) -> {
                        this.setPositionValue(this.getPositionValue() - currentIncrement);
                    }));
            TooltipBuilder.create()
                    .setLines(() -> Collections.singletonList(Component.translatable(DECREMENT_TRANSLATION_KEY,
                            getPixelIncrementComponent(currentIncrement))))
                    .build(decrementButton);
        }

        @Override
        protected boolean supportsToggleButton() {
            return true;
        }

        private double getPositionValue() {
            return roundWithPrecision(this.currentValue.getAsDouble(), 16.0, 4);
        }

        private static double roundWithPrecision(double toRound, double roundingPrecision, int decimalPlaces) {
            toRound = Math.round(toRound * roundingPrecision) / roundingPrecision;
            final double power = Math.pow(10, decimalPlaces);
            return Math.round(toRound * power) / power;
        }

        private void setPositionValue(double newValue) {
            this.ticks = 20;
            newValue = Math.round(newValue * 16.0) / 16.0;
            if (this.getPositionValue() != newValue) {
                this.editBox.setValue(BLOCK_INCREMENT_FORMAT.format(newValue));
                this.newValue.accept(newValue);
            }
        }

        @Override
        public boolean alwaysVisible(@Nullable ArmorStandWidget activeWidget) {
            return activeWidget instanceof PositionControlsWidget || super.alwaysVisible(activeWidget);
        }
    }
}
