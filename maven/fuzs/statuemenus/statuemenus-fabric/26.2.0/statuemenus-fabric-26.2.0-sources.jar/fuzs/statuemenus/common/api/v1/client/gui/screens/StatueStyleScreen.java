package fuzs.statuemenus.common.api.v1.client.gui.screens;

import fuzs.statuemenus.common.api.v1.client.gui.components.CheckboxTextButton;
import fuzs.statuemenus.common.api.v1.network.client.data.DataSyncHandler;
import fuzs.statuemenus.common.api.v1.world.inventory.StatueHolder;
import fuzs.statuemenus.common.api.v1.world.inventory.data.StatueScreenType;
import fuzs.statuemenus.common.api.v1.world.inventory.data.StatueStyleOption;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Util;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;

import java.util.List;

public abstract class StatueStyleScreen<T extends LivingEntity> extends StatueTickBoxScreen<StatueStyleOption<? super T>> {
    public static final Component TEXT_BOX_HINT_TRANSLATION_KEY = Component.translatable(StatueScreenType.STYLE.id()
            .toLanguageKey("screen", "hint")).withStyle(EditBox.SEARCH_HINT_STYLE);
    public static final Component TEXT_BOX_TOOLTIP_TRANSLATION_KEY = Component.translatable(StatueScreenType.STYLE.id()
            .toLanguageKey("screen", "tooltip"));

    public StatueStyleScreen(StatueHolder holder, Inventory inventory, Component component, DataSyncHandler dataSyncHandler) {
        super(holder, inventory, component, dataSyncHandler);
    }

    protected abstract List<StatueStyleOption<? super T>> getStyleOptions();

    @Override
    protected List<StatueStyleOption<? super T>> getAllTickBoxValues() {
        return this.getStyleOptions()
                .stream()
                .filter((StatueStyleOption<? super T> option) -> option.mayEdit((T) this.holder.getEntity(),
                        this.minecraft.player))
                .toList();
    }

    @Override
    protected AbstractWidget makeTickBoxWidget(LivingEntity livingEntity, int buttonStartY, int index, StatueStyleOption<? super T> option) {
        return Util.make(new CheckboxTextButton(this.leftPos + 96,
                this.topPos + buttonStartY + index * 22,
                102,
                20,
                (Button button) -> {
                    this.dataSyncHandler.sendStyleOption(option, !option.getOption((T) livingEntity));
                },
                Component.translatable(option.getTranslationKey())) {
            @Override
            protected boolean isTicked() {
                return option.getOption((T) livingEntity);
            }
        }, (CheckboxTextButton button) -> {
            button.setTooltip(Tooltip.create(Component.translatable(option.getDescriptionKey())));
        });
    }

    @Override
    protected void syncNameChange(String input) {
        this.dataSyncHandler.sendName(input);
    }

    @Override
    protected int getNameMaxLength() {
        return 50;
    }

    @Override
    protected String getNameValue() {
        return this.holder.getEntity().hasCustomName() ? this.holder.getEntity().getCustomName().getString() : "";
    }

    @Override
    protected Component getNameHint() {
        return TEXT_BOX_HINT_TRANSLATION_KEY;
    }

    @Override
    protected Component getNameTooltip() {
        return TEXT_BOX_TOOLTIP_TRANSLATION_KEY;
    }
}
